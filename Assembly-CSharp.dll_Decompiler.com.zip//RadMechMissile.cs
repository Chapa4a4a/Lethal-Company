using System;
using GameNetcodeStuff;
using UnityEngine;

public class RadMechMissile : MonoBehaviour
{
	private float currentMissileSpeed = 0.35f;

	public RadMechAI RadMechScript;

	private bool hitWall = true;

	private float despawnTimer;

	private Random missileFlyRandom;

	private float forwardDistance;

	private float lastRotationDistance;

	private void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		missileFlyRandom = new Random((int)(((Component)this).transform.position.x + ((Component)this).transform.position.y) + RadMechScript.missilesFired);
		hitWall = false;
	}

	private void FixedUpdate()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		if (hitWall)
		{
			return;
		}
		if (despawnTimer < 5f && (Object)(object)RadMechScript != (Object)null)
		{
			despawnTimer += Time.deltaTime;
			CheckCollision();
			Transform transform = ((Component)this).transform;
			transform.position += ((Component)this).transform.forward * RadMechScript.missileSpeed * currentMissileSpeed;
			forwardDistance += RadMechScript.missileSpeed * currentMissileSpeed;
			if (forwardDistance - lastRotationDistance > 2f)
			{
				lastRotationDistance = forwardDistance;
				Transform transform2 = ((Component)this).transform;
				transform2.rotation *= Quaternion.Euler(new Vector3(15f * RadMechScript.missileWarbleLevel * (float)(missileFlyRandom.NextDouble() * 2.0 - 1.0), 7f * RadMechScript.missileWarbleLevel * (float)(missileFlyRandom.NextDouble() * 2.0 - 1.0), 15f * RadMechScript.missileWarbleLevel * (float)(missileFlyRandom.NextDouble() * 2.0 - 1.0)));
			}
			currentMissileSpeed += 0.05f;
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void CheckCollision()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val = default(RaycastHit);
		if (!Physics.Raycast(((Component)this).transform.position, ((Component)this).transform.forward, ref val, 0.6f * currentMissileSpeed, 526592, (QueryTriggerInteraction)1) && !Physics.Raycast(((Component)this).transform.position, ((Component)this).transform.forward, ref val, 0.6f * currentMissileSpeed, 8, (QueryTriggerInteraction)2))
		{
			return;
		}
		if (((Component)((RaycastHit)(ref val)).collider).gameObject.layer == 19)
		{
			EnemyAICollisionDetect component = ((Component)((RaycastHit)(ref val)).collider).GetComponent<EnemyAICollisionDetect>();
			if ((Object)(object)component != (Object)null && (Object)(object)component.mainScript == (Object)(object)RadMechScript)
			{
				return;
			}
		}
		bool calledByClient = false;
		if (((Component)((RaycastHit)(ref val)).collider).gameObject.layer == 3)
		{
			PlayerControllerB component2 = ((Component)((RaycastHit)(ref val)).collider).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)component2 != (Object)null && (Object)(object)component2 == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				calledByClient = true;
			}
		}
		hitWall = true;
		RadMechScript.StartExplosion(((Component)this).transform.position - ((Component)this).transform.forward * 0.5f, ((Component)this).transform.forward, calledByClient);
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}
}
