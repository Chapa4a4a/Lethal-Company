using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class TetraChemicalItem : GrabbableObject
{
	private PlayerControllerB previousPlayerHeldBy;

	private Coroutine useTZPCoroutine;

	private bool emittingGas;

	private float fuel = 1f;

	public AudioSource localHelmetSFX;

	public AudioSource thisAudioSource;

	public AudioClip twistCanSFX;

	public AudioClip releaseGasSFX;

	public AudioClip holdCanSFX;

	public AudioClip removeCanSFX;

	public AudioClip outOfGasSFX;

	private bool triedUsingWithoutFuel;

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		if (buttonDown)
		{
			isBeingUsed = true;
			if (fuel <= 0f)
			{
				if (!triedUsingWithoutFuel)
				{
					triedUsingWithoutFuel = true;
					thisAudioSource.PlayOneShot(outOfGasSFX);
					WalkieTalkie.TransmitOneShotAudio(thisAudioSource, outOfGasSFX);
					previousPlayerHeldBy.playerBodyAnimator.SetTrigger("shakeItem");
				}
				return;
			}
			previousPlayerHeldBy = playerHeldBy;
			useTZPCoroutine = ((MonoBehaviour)this).StartCoroutine(UseTZPAnimation());
		}
		else
		{
			isBeingUsed = false;
			if (triedUsingWithoutFuel)
			{
				triedUsingWithoutFuel = false;
			}
			else if (useTZPCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(useTZPCoroutine);
				emittingGas = false;
				previousPlayerHeldBy.activatingItem = false;
				thisAudioSource.Stop();
				localHelmetSFX.Stop();
				thisAudioSource.PlayOneShot(removeCanSFX);
			}
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			previousPlayerHeldBy.activatingItem = buttonDown;
			previousPlayerHeldBy.playerBodyAnimator.SetBool("useTZPItem", buttonDown);
		}
	}

	private IEnumerator UseTZPAnimation()
	{
		thisAudioSource.PlayOneShot(holdCanSFX);
		WalkieTalkie.TransmitOneShotAudio(previousPlayerHeldBy.itemAudio, holdCanSFX);
		yield return (object)new WaitForSeconds(0.75f);
		emittingGas = true;
		HUDManager.Instance.gasHelmetAnimator.SetBool("gasEmitting", true);
		if (((NetworkBehaviour)this).IsOwner)
		{
			localHelmetSFX.Play();
			localHelmetSFX.PlayOneShot(twistCanSFX);
		}
		else
		{
			thisAudioSource.clip = releaseGasSFX;
			thisAudioSource.Play();
			thisAudioSource.PlayOneShot(twistCanSFX);
		}
		WalkieTalkie.TransmitOneShotAudio(previousPlayerHeldBy.itemAudio, twistCanSFX);
	}

	public override void Update()
	{
		if (emittingGas)
		{
			if ((Object)(object)previousPlayerHeldBy == (Object)null || !isHeld || fuel <= 0f)
			{
				emittingGas = false;
				thisAudioSource.Stop();
				localHelmetSFX.Stop();
				RunOutOfFuelServerRpc();
			}
			previousPlayerHeldBy.drunknessInertia = Mathf.Clamp(previousPlayerHeldBy.drunknessInertia + Time.deltaTime / 1.75f * previousPlayerHeldBy.drunknessSpeed, 0.1f, 3f);
			previousPlayerHeldBy.increasingDrunknessThisFrame = true;
			fuel -= Time.deltaTime / 38f;
		}
		base.Update();
	}

	public override void EquipItem()
	{
		base.EquipItem();
		StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			previousPlayerHeldBy = playerHeldBy;
		}
	}

	[ServerRpc]
	public void RunOutOfFuelServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1607080184u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1607080184u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			RunOutOfFuelClientRpc();
		}
	}

	[ClientRpc]
	public void RunOutOfFuelClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3625530963u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3625530963u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				itemUsedUp = true;
				emittingGas = false;
				fuel = 0f;
				thisAudioSource.Stop();
				localHelmetSFX.Stop();
			}
		}
	}

	public override void DiscardItem()
	{
		emittingGas = false;
		thisAudioSource.Stop();
		localHelmetSFX.Stop();
		playerHeldBy.playerBodyAnimator.ResetTrigger("shakeItem");
		previousPlayerHeldBy.playerBodyAnimator.SetBool("useTZPItem", false);
		if ((Object)(object)previousPlayerHeldBy != (Object)null)
		{
			previousPlayerHeldBy.activatingItem = false;
		}
		base.DiscardItem();
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_TetraChemicalItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1607080184u, new RpcReceiveHandler(__rpc_handler_1607080184));
		NetworkManager.__rpc_func_table.Add(3625530963u, new RpcReceiveHandler(__rpc_handler_3625530963));
	}

	private static void __rpc_handler_1607080184(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((TetraChemicalItem)(object)target).RunOutOfFuelServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3625530963(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TetraChemicalItem)(object)target).RunOutOfFuelClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "TetraChemicalItem";
	}
}
