using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;

public class InteractTrigger : NetworkBehaviour
{
	[Header("Aesthetics")]
	public Sprite hoverIcon;

	public string hoverTip;

	[Space(5f)]
	public Sprite disabledHoverIcon;

	public string disabledHoverTip;

	[Header("Interaction")]
	public bool interactable = true;

	public bool oneHandedItemAllowed = true;

	public bool twoHandedItemAllowed;

	[Space(5f)]
	public bool holdInteraction;

	public float timeToHold = 0.5f;

	public float timeToHoldSpeedMultiplier = 1f;

	public string holdTip;

	public bool isBeingHeldByPlayer;

	public InteractEventFloat holdingInteractEvent;

	[Space(5f)]
	public bool touchTrigger;

	public bool triggerOnce;

	private bool hasTriggered;

	[Header("Misc")]
	public bool interactCooldown = true;

	public float cooldownTime = 1f;

	[HideInInspector]
	public float currentCooldownValue;

	public bool disableTriggerMesh = true;

	[Space(5f)]
	public bool RandomChanceTrigger;

	public int randomChancePercentage;

	[Header("Events")]
	public InteractEvent onInteractEarlyOtherClients;

	public InteractEvent onInteract;

	public InteractEvent onInteractEarly;

	public InteractEvent onStopInteract;

	public InteractEvent onCancelAnimation;

	[Header("Special Animation")]
	public bool specialCharacterAnimation;

	public bool stopAnimationManually;

	public string stopAnimationString = "SA_stopAnimation";

	public bool hidePlayerItem;

	public bool isPlayingSpecialAnimation;

	public float animationWaitTime = 2f;

	public string animationString;

	[Space(5f)]
	public bool lockPlayerPosition;

	public Transform playerPositionNode;

	public Transform lockedPlayer;

	public bool clampLooking;

	public bool setVehicleAnimation;

	public float minVerticalClamp;

	public float maxVerticalClamp;

	public float horizontalClamp;

	public bool allowUseWhileInAnimation;

	public Transform overridePlayerParent;

	private bool usedByOtherClient;

	private StartOfRound playersManager;

	private float updateInterval = 1f;

	[Header("Ladders")]
	public bool isLadder;

	public Transform topOfLadderPosition;

	public bool useRaycastToGetTopPosition;

	public Transform bottomOfLadderPosition;

	public Transform ladderHorizontalPosition;

	[Space(5f)]
	public Transform ladderPlayerPositionNode;

	public bool usingLadder;

	private bool atBottomOfLadder;

	private Vector3 moveVelocity;

	private PlayerControllerB playerScriptInSpecialAnimation;

	private Coroutine useLadderCoroutine;

	private int playerUsingId;

	private bool isGettingDestroyed;

	public void StopInteraction()
	{
		if (isBeingHeldByPlayer && currentCooldownValue <= 0f)
		{
			isBeingHeldByPlayer = false;
			((UnityEvent<PlayerControllerB>)onStopInteract).Invoke((PlayerControllerB)null);
		}
	}

	public void HoldInteractNotFilled()
	{
		((UnityEvent<float>)holdingInteractEvent).Invoke(HUDManager.Instance.holdFillAmount / timeToHold);
		if (!specialCharacterAnimation && !isLadder)
		{
			if (!isBeingHeldByPlayer)
			{
				((UnityEvent<PlayerControllerB>)onInteractEarly).Invoke((PlayerControllerB)null);
			}
			isBeingHeldByPlayer = true;
		}
	}

	public void Interact(Transform playerTransform)
	{
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		if ((triggerOnce && hasTriggered) || StartOfRound.Instance.firingPlayersCutsceneRunning)
		{
			return;
		}
		hasTriggered = true;
		if (RandomChanceTrigger && Random.Range(0, 101) > randomChancePercentage)
		{
			return;
		}
		if (!interactable || isPlayingSpecialAnimation || usingLadder)
		{
			if (usingLadder)
			{
				CancelLadderAnimation();
			}
			return;
		}
		PlayerControllerB component = ((Component)playerTransform).GetComponent<PlayerControllerB>();
		if (component.inSpecialInteractAnimation && !component.isClimbingLadder && !allowUseWhileInAnimation)
		{
			return;
		}
		if (interactCooldown)
		{
			if (currentCooldownValue >= 0f)
			{
				return;
			}
			currentCooldownValue = cooldownTime;
		}
		if (!specialCharacterAnimation && !isLadder)
		{
			((UnityEvent<PlayerControllerB>)onInteract).Invoke(component);
			return;
		}
		component.ResetFallGravity();
		if (isLadder)
		{
			if (component.isInHangarShipRoom)
			{
				return;
			}
			ladderPlayerPositionNode.position = new Vector3(ladderHorizontalPosition.position.x, Mathf.Clamp(component.thisPlayerBody.position.y, bottomOfLadderPosition.position.y + 0.3f, topOfLadderPosition.position.y - 2.2f), ladderHorizontalPosition.position.z);
			if (!LadderPositionObstructed(component))
			{
				if (useLadderCoroutine != null)
				{
					((MonoBehaviour)this).StopCoroutine(useLadderCoroutine);
				}
				useLadderCoroutine = ((MonoBehaviour)this).StartCoroutine(ladderClimbAnimation(component));
			}
		}
		else
		{
			((MonoBehaviour)this).StartCoroutine(specialInteractAnimation(component));
		}
	}

	private bool LadderPositionObstructed(PlayerControllerB playerController)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val2 = default(RaycastHit);
		if (((Component)playerController).transform.position.y >= topOfLadderPosition.position.y - 0.5f)
		{
			RaycastHit val = default(RaycastHit);
			if (Physics.Linecast(((Component)playerController.gameplayCamera).transform.position, ladderPlayerPositionNode.position + Vector3.up * 2.8f, ref val, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				return true;
			}
		}
		else if (Physics.Linecast(((Component)playerController.gameplayCamera).transform.position, ladderPlayerPositionNode.position, ref val2, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			return true;
		}
		return false;
	}

	private IEnumerator ladderClimbAnimation(PlayerControllerB playerController)
	{
		((UnityEvent<PlayerControllerB>)onInteractEarly).Invoke((PlayerControllerB)null);
		lockedPlayer = playerController.thisPlayerBody;
		playerScriptInSpecialAnimation = playerController;
		if (hidePlayerItem && (Object)(object)playerScriptInSpecialAnimation.currentlyHeldObjectServer != (Object)null)
		{
			playerScriptInSpecialAnimation.currentlyHeldObjectServer.EnableItemMeshes(enable: false);
		}
		SetUsingLadderOnLocalClient(isUsing: true);
		hoverTip = "Let go : [LMB]";
		if (!playerController.isTestingPlayer)
		{
			playerController.UpdateSpecialAnimationValue(specialAnimation: true, (short)ladderPlayerPositionNode.eulerAngles.y, 0f, climbingLadder: true);
		}
		playerController.enteringSpecialAnimation = true;
		playerController.inSpecialInteractAnimation = true;
		playerController.currentTriggerInAnimationWith = this;
		playerController.isCrouching = false;
		playerController.playerBodyAnimator.SetBool("crouching", false);
		playerController.playerBodyAnimator.SetTrigger("EnterLadder");
		((Collider)playerController.thisController).enabled = false;
		float timer2 = 0f;
		while (timer2 <= animationWaitTime)
		{
			yield return null;
			timer2 += Time.deltaTime;
			playerController.thisPlayerBody.position = Vector3.Lerp(playerController.thisPlayerBody.position, ladderPlayerPositionNode.position, Mathf.SmoothStep(0f, 1f, timer2 / animationWaitTime));
			lockedPlayer.rotation = Quaternion.Lerp(lockedPlayer.rotation, ladderPlayerPositionNode.rotation, Mathf.SmoothStep(0f, 1f, timer2 / animationWaitTime));
		}
		playerController.TeleportPlayer(ladderPlayerPositionNode.position, withRotation: false, 0f, allowInteractTrigger: true);
		Debug.Log((object)"Finished snapping to ladder");
		playerController.playerBodyAnimator.SetBool("ClimbingLadder", true);
		playerController.isClimbingLadder = true;
		playerController.enteringSpecialAnimation = false;
		playerController.ladderCameraHorizontal = 0f;
		playerController.clampCameraRotation = bottomOfLadderPosition.eulerAngles;
		int finishClimbingLadder = 0;
		while (finishClimbingLadder == 0)
		{
			yield return null;
			if (playerController.thisPlayerBody.position.y < bottomOfLadderPosition.position.y)
			{
				finishClimbingLadder = 1;
			}
			else if (playerController.thisPlayerBody.position.y + 2f > topOfLadderPosition.position.y)
			{
				finishClimbingLadder = 2;
			}
		}
		playerController.isClimbingLadder = false;
		playerController.playerBodyAnimator.SetBool("ClimbingLadder", false);
		if (finishClimbingLadder == 1)
		{
			ladderPlayerPositionNode.position = bottomOfLadderPosition.position;
		}
		else if (!useRaycastToGetTopPosition)
		{
			ladderPlayerPositionNode.position = topOfLadderPosition.position;
		}
		else
		{
			Ray val = default(Ray);
			((Ray)(ref val))._002Ector(((Component)playerController).transform.position + Vector3.up, topOfLadderPosition.position + Vector3.up - ((Component)playerController).transform.position + Vector3.up);
			RaycastHit val2 = default(RaycastHit);
			if (Physics.Linecast(((Component)playerController).transform.position + Vector3.up, topOfLadderPosition.position + Vector3.up, ref val2, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				Debug.DrawLine(((Component)playerController).transform.position + Vector3.up, topOfLadderPosition.position + Vector3.up, Color.red, 10f);
				ladderPlayerPositionNode.position = ((Ray)(ref val)).GetPoint(Mathf.Max(((RaycastHit)(ref val2)).distance - 1.2f, 0f));
				Debug.DrawRay(ladderPlayerPositionNode.position, Vector3.up * 0.5f, Color.yellow, 10f);
			}
			else
			{
				Debug.DrawLine(((Component)playerController).transform.position + Vector3.up, topOfLadderPosition.position + Vector3.up, Color.green, 10f);
				ladderPlayerPositionNode.position = topOfLadderPosition.position;
			}
		}
		timer2 = 0f;
		float shorterWaitTime = animationWaitTime / 2f;
		while (timer2 <= shorterWaitTime)
		{
			yield return null;
			timer2 += Time.deltaTime;
			playerController.thisPlayerBody.position = Vector3.Lerp(playerController.thisPlayerBody.position, ladderPlayerPositionNode.position, Mathf.SmoothStep(0f, 1f, timer2 / shorterWaitTime));
			playerController.thisPlayerBody.rotation = Quaternion.Lerp(playerController.thisPlayerBody.rotation, ladderPlayerPositionNode.rotation, Mathf.SmoothStep(0f, 1f, timer2 / shorterWaitTime));
			((Component)playerController.gameplayCamera).transform.rotation = Quaternion.Slerp(((Component)playerController.gameplayCamera).transform.rotation, ((Component)playerController.gameplayCamera).transform.parent.rotation, Mathf.SmoothStep(0f, 1f, timer2 / shorterWaitTime));
		}
		((Component)playerController.gameplayCamera).transform.localEulerAngles = Vector3.zero;
		Debug.Log((object)"Finished ladder sequence");
		playerController.UpdateSpecialAnimationValue(specialAnimation: false, 0);
		playerController.inSpecialInteractAnimation = false;
		((Collider)playerController.thisController).enabled = true;
		SetUsingLadderOnLocalClient(isUsing: false);
		hoverTip = "Use ladder : [LMB]";
		lockedPlayer = null;
		currentCooldownValue = cooldownTime;
		((UnityEvent<PlayerControllerB>)onInteract).Invoke((PlayerControllerB)null);
	}

	public void CancelAnimationExternally()
	{
		if (isLadder)
		{
			CancelLadderAnimation();
		}
		else
		{
			StopSpecialAnimation();
		}
	}

	public void CancelLadderAnimation()
	{
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		if (useLadderCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(useLadderCoroutine);
		}
		((UnityEvent<PlayerControllerB>)onCancelAnimation).Invoke(playerScriptInSpecialAnimation);
		playerScriptInSpecialAnimation.currentTriggerInAnimationWith = null;
		playerScriptInSpecialAnimation.isClimbingLadder = false;
		((Collider)playerScriptInSpecialAnimation.thisController).enabled = true;
		playerScriptInSpecialAnimation.playerBodyAnimator.SetBool("ClimbingLadder", false);
		((Component)playerScriptInSpecialAnimation.gameplayCamera).transform.localEulerAngles = Vector3.zero;
		playerScriptInSpecialAnimation.UpdateSpecialAnimationValue(specialAnimation: false, 0);
		playerScriptInSpecialAnimation.inSpecialInteractAnimation = false;
		SetUsingLadderOnLocalClient(isUsing: false);
		lockedPlayer = null;
		currentCooldownValue = cooldownTime;
		if (hidePlayerItem && (Object)(object)playerScriptInSpecialAnimation.currentlyHeldObjectServer != (Object)null)
		{
			playerScriptInSpecialAnimation.currentlyHeldObjectServer.EnableItemMeshes(enable: true);
		}
		((UnityEvent<PlayerControllerB>)onInteract).Invoke((PlayerControllerB)null);
	}

	private void SetUsingLadderOnLocalClient(bool isUsing)
	{
		usingLadder = isUsing;
		if (isUsing)
		{
			hoverTip = "Let go : [LMB]";
		}
		else
		{
			hoverTip = "Climb : [LMB]";
		}
	}

	private IEnumerator specialInteractAnimation(PlayerControllerB playerController)
	{
		UpdateUsedByPlayerServerRpc((int)playerController.playerClientId);
		((UnityEvent<PlayerControllerB>)onInteractEarly).Invoke((PlayerControllerB)null);
		isPlayingSpecialAnimation = true;
		lockedPlayer = playerController.thisPlayerBody;
		playerScriptInSpecialAnimation = playerController;
		if (clampLooking)
		{
			playerScriptInSpecialAnimation.minVerticalClamp = minVerticalClamp;
			playerScriptInSpecialAnimation.maxVerticalClamp = maxVerticalClamp;
			playerScriptInSpecialAnimation.horizontalClamp = horizontalClamp;
			playerScriptInSpecialAnimation.clampLooking = true;
		}
		if (Object.op_Implicit((Object)(object)overridePlayerParent))
		{
			playerScriptInSpecialAnimation.overridePhysicsParent = overridePlayerParent;
		}
		if (setVehicleAnimation)
		{
			playerScriptInSpecialAnimation.inVehicleAnimation = true;
		}
		if (hidePlayerItem && (Object)(object)playerScriptInSpecialAnimation.currentlyHeldObjectServer != (Object)null)
		{
			playerScriptInSpecialAnimation.currentlyHeldObjectServer.EnableItemMeshes(enable: false);
		}
		playerController.Crouch(crouch: false);
		playerController.UpdateSpecialAnimationValue(specialAnimation: true, (short)playerPositionNode.eulerAngles.y);
		playerController.inSpecialInteractAnimation = true;
		playerController.currentTriggerInAnimationWith = this;
		playerController.playerBodyAnimator.ResetTrigger(animationString);
		playerController.playerBodyAnimator.SetTrigger(animationString);
		HUDManager.Instance.ClearControlTips();
		if (!stopAnimationManually)
		{
			yield return (object)new WaitForSeconds(animationWaitTime);
			StopSpecialAnimation();
		}
	}

	public override void OnDestroy()
	{
		Debug.Log((object)("Interact trigger destroying! name: " + ((Object)((Component)this).gameObject).name));
		if (setVehicleAnimation)
		{
			Debug.Log((object)"This trigger sets vehicle animation!");
		}
		isGettingDestroyed = true;
		if (setVehicleAnimation)
		{
			Debug.Log((object)$"Disable vehicle animation... lockedPlayer null?: {(Object)(object)lockedPlayer == (Object)null}");
			if ((Object)(object)lockedPlayer != (Object)null)
			{
				Debug.Log((object)("lockedPlayer: " + ((Object)((Component)lockedPlayer).gameObject).name));
			}
			if ((Object)(object)lockedPlayer != (Object)null && (Object)(object)lockedPlayer == (Object)(object)((Component)GameNetworkManager.Instance.localPlayerController).transform)
			{
				Debug.Log((object)"Sending disable invehicleanimation RPC");
				GameNetworkManager.Instance.localPlayerController.DisableInVehicleAnimationSync();
			}
		}
		StopSpecialAnimation();
		((NetworkBehaviour)this).OnDestroy();
	}

	public void StopSpecialAnimation()
	{
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"lockedPlayer null?: {(Object)(object)lockedPlayer == (Object)null}");
		if ((Object)(object)lockedPlayer != (Object)null)
		{
			Debug.Log((object)$"is lockedPlayer me? : {(Object)(object)lockedPlayer == (Object)(object)((Component)GameNetworkManager.Instance.localPlayerController).transform}");
			Debug.Log((object)("lockedPlayer: " + ((Object)((Component)lockedPlayer).gameObject).name));
		}
		if ((Object)(object)lockedPlayer == (Object)null || (Object)(object)lockedPlayer != (Object)(object)((Component)GameNetworkManager.Instance.localPlayerController).transform)
		{
			return;
		}
		Debug.Log((object)$"Stop special animation on {((Object)((Component)this).gameObject).name}, by {lockedPlayer}; {GameNetworkManager.Instance.localPlayerController}");
		if (!isGettingDestroyed && isPlayingSpecialAnimation && stopAnimationManually && (Object)(object)lockedPlayer != (Object)null)
		{
			Debug.Log((object)$"Calling stop animation function StopUsing server rpc for player: {GameNetworkManager.Instance.localPlayerController.playerClientId}");
			StopUsingServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
		if ((Object)(object)lockedPlayer != (Object)null)
		{
			PlayerControllerB component = ((Component)lockedPlayer).GetComponent<PlayerControllerB>();
			((UnityEvent<PlayerControllerB>)onCancelAnimation).Invoke(component);
			if (hidePlayerItem && (Object)(object)component.currentlyHeldObjectServer != (Object)null)
			{
				component.currentlyHeldObjectServer.EnableItemMeshes(enable: true);
			}
			isPlayingSpecialAnimation = false;
			component.inSpecialInteractAnimation = false;
			if (component.clampLooking)
			{
				((Component)component.gameplayCamera).transform.localEulerAngles = Vector3.zero;
			}
			component.clampLooking = false;
			component.inVehicleAnimation = false;
			if (Object.op_Implicit((Object)(object)overridePlayerParent) && (Object)(object)component.overridePhysicsParent == (Object)(object)overridePlayerParent)
			{
				component.overridePhysicsParent = null;
			}
			component.currentTriggerInAnimationWith = null;
			if (component.isClimbingLadder)
			{
				CancelLadderAnimation();
				component.isClimbingLadder = false;
			}
			Debug.Log((object)"Stop special animation F");
			if (stopAnimationManually)
			{
				component.playerBodyAnimator.SetTrigger(stopAnimationString);
			}
			component.UpdateSpecialAnimationValue(specialAnimation: false, 0);
			lockedPlayer = null;
			currentCooldownValue = cooldownTime;
			((UnityEvent<PlayerControllerB>)onInteract).Invoke((PlayerControllerB)null);
			Debug.Log((object)"Stop special animation G");
			if (component.isHoldingObject && (Object)(object)component.currentlyHeldObjectServer != (Object)null)
			{
				component.currentlyHeldObjectServer.SetControlTipsForItem();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void UpdateUsedByPlayerServerRpc(int playerNum)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1430497838u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerNum);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1430497838u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				UpdateUsedByPlayerClientRpc(playerNum);
			}
		}
	}

	[ClientRpc]
	private void UpdateUsedByPlayerClientRpc(int playerNum)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3458599252u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerNum);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3458599252u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			((UnityEvent<PlayerControllerB>)onInteractEarlyOtherClients).Invoke(StartOfRound.Instance.allPlayerScripts[playerNum]);
			Debug.Log((object)("Update used by player client rpc has been called for interact trigger: " + ((Object)((Component)this).gameObject).name));
			if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerNum] != (Object)(object)GameNetworkManager.Instance.localPlayerController && (Object)(object)lockedPlayer == (Object)(object)((Component)GameNetworkManager.Instance.localPlayerController).transform)
			{
				Debug.Log((object)"Client is getting kicked off of interacttrigger animation");
				StopSpecialAnimation();
			}
			if (hidePlayerItem && (Object)(object)StartOfRound.Instance.allPlayerScripts[playerNum].currentlyHeldObjectServer != (Object)null)
			{
				StartOfRound.Instance.allPlayerScripts[playerNum].currentlyHeldObjectServer.EnableItemMeshes(enable: false);
				playerUsingId = playerNum;
			}
			if (specialCharacterAnimation && setVehicleAnimation)
			{
				StartOfRound.Instance.allPlayerScripts[playerNum].inVehicleAnimation = true;
				StartOfRound.Instance.allPlayerScripts[playerNum].syncFullCameraRotation = ((Component)StartOfRound.Instance.allPlayerScripts[playerNum].gameplayCamera).transform.localEulerAngles;
				lockedPlayer = ((Component)StartOfRound.Instance.allPlayerScripts[playerNum]).transform;
				playerScriptInSpecialAnimation = StartOfRound.Instance.allPlayerScripts[playerNum];
			}
			if (stopAnimationManually)
			{
				isPlayingSpecialAnimation = true;
				StartOfRound.Instance.allPlayerScripts[playerNum].currentTriggerInAnimationWith = this;
			}
			else
			{
				((MonoBehaviour)this).StartCoroutine(isSpecialAnimationPlayingTimer(playerNum));
			}
		}
	}

	private IEnumerator isSpecialAnimationPlayingTimer(int playerNum)
	{
		StartOfRound.Instance.allPlayerScripts[playerNum].currentTriggerInAnimationWith = this;
		isPlayingSpecialAnimation = true;
		yield return (object)new WaitForSeconds(animationWaitTime);
		StartOfRound.Instance.allPlayerScripts[playerNum].currentTriggerInAnimationWith = null;
		isPlayingSpecialAnimation = false;
	}

	[ServerRpc(RequireOwnership = false)]
	private void StopUsingServerRpc(int playerUsing)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(880620475u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerUsing);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 880620475u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StopUsingClientRpc(playerUsing);
			}
		}
	}

	[ClientRpc]
	private void StopUsingClientRpc(int playerUsing)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(953330655u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerUsing);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 953330655u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)StartOfRound.Instance.allPlayerScripts[playerUsing]))
		{
			StartOfRound.Instance.allPlayerScripts[playerUsing].inVehicleAnimation = false;
			if ((Object)(object)lockedPlayer == (Object)(object)((Component)StartOfRound.Instance.allPlayerScripts[playerUsing]).transform)
			{
				lockedPlayer = null;
			}
			if ((Object)(object)playerScriptInSpecialAnimation == (Object)(object)StartOfRound.Instance.allPlayerScripts[playerUsing])
			{
				playerScriptInSpecialAnimation = null;
			}
			SetInteractTriggerNotInAnimation(playerUsing);
		}
	}

	public void SetInteractTriggerNotInAnimation(int playerUsing = -1)
	{
		if (playerUsing == -1)
		{
			playerUsing = playerUsingId;
		}
		isPlayingSpecialAnimation = false;
		if (playerUsing != -1)
		{
			StartOfRound.Instance.allPlayerScripts[playerUsing].inVehicleAnimation = false;
			if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerUsing].currentlyHeldObjectServer != (Object)null)
			{
				StartOfRound.Instance.allPlayerScripts[playerUsing].currentlyHeldObjectServer.EnableItemMeshes(enable: true);
			}
			StartOfRound.Instance.allPlayerScripts[playerUsing].currentTriggerInAnimationWith = null;
			playerUsingId = -1;
		}
	}

	private void LateUpdate()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		if (isPlayingSpecialAnimation && (Object)(object)lockedPlayer != (Object)null && !playerScriptInSpecialAnimation.isPlayerDead && lockPlayerPosition)
		{
			lockedPlayer.localPosition = Vector3.Lerp(lockedPlayer.localPosition, lockedPlayer.parent.InverseTransformPoint(playerPositionNode.position), Time.deltaTime * 20f);
			lockedPlayer.rotation = Quaternion.Lerp(lockedPlayer.rotation, playerPositionNode.rotation, Time.deltaTime * 20f);
		}
	}

	private void OnEnable()
	{
		if (interactCooldown)
		{
			currentCooldownValue = cooldownTime;
		}
	}

	private void Update()
	{
		if (currentCooldownValue >= 0f)
		{
			currentCooldownValue -= Time.deltaTime;
		}
		if (isPlayingSpecialAnimation)
		{
			if ((Object)(object)lockedPlayer != (Object)null && playerScriptInSpecialAnimation.isPlayerDead)
			{
				StopSpecialAnimation();
			}
		}
		else if (usingLadder && (Object)(object)playerScriptInSpecialAnimation != (Object)null && playerScriptInSpecialAnimation.isPlayerDead)
		{
			CancelLadderAnimation();
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (touchTrigger && ((Component)other).gameObject.CompareTag("Player") && Object.op_Implicit((Object)(object)((Component)other).gameObject.GetComponent<PlayerControllerB>()) && ((NetworkBehaviour)((Component)other).gameObject.GetComponent<PlayerControllerB>()).IsOwner)
		{
			Interact(((Component)other).gameObject.GetComponent<PlayerControllerB>().thisPlayerBody);
		}
	}

	private void Start()
	{
		if (disableTriggerMesh && Object.op_Implicit((Object)(object)((Component)this).gameObject.GetComponent<MeshRenderer>()))
		{
			((Renderer)((Component)this).gameObject.GetComponent<MeshRenderer>()).enabled = false;
		}
		playersManager = Object.FindObjectOfType<StartOfRound>();
	}

	public void SetInteractionToHold(bool mustHold)
	{
		holdInteraction = mustHold;
	}

	public void SetInteractionToHoldOpposite(bool mustHold)
	{
		holdInteraction = !mustHold;
	}

	public void SetRandomTimeToHold(float min, float max)
	{
		timeToHold = Random.Range(min, max);
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_InteractTrigger()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1430497838u, new RpcReceiveHandler(__rpc_handler_1430497838));
		NetworkManager.__rpc_func_table.Add(3458599252u, new RpcReceiveHandler(__rpc_handler_3458599252));
		NetworkManager.__rpc_func_table.Add(880620475u, new RpcReceiveHandler(__rpc_handler_880620475));
		NetworkManager.__rpc_func_table.Add(953330655u, new RpcReceiveHandler(__rpc_handler_953330655));
	}

	private static void __rpc_handler_1430497838(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerNum = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((InteractTrigger)(object)target).UpdateUsedByPlayerServerRpc(playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3458599252(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerNum = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((InteractTrigger)(object)target).UpdateUsedByPlayerClientRpc(playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_880620475(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerUsing = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerUsing);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((InteractTrigger)(object)target).StopUsingServerRpc(playerUsing);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_953330655(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerUsing = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerUsing);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((InteractTrigger)(object)target).StopUsingClientRpc(playerUsing);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "InteractTrigger";
	}
}
