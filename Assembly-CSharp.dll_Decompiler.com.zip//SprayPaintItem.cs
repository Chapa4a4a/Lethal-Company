using System;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Rendering.HighDefinition;

public class SprayPaintItem : GrabbableObject
{
	public AudioSource sprayAudio;

	public AudioClip spraySFX;

	public AudioClip sprayNeedsShakingSFX;

	public AudioClip sprayStart;

	public AudioClip sprayStop;

	public AudioClip sprayCanEmptySFX;

	public AudioClip sprayCanNeedsShakingSFX;

	public AudioClip sprayCanShakeEmptySFX;

	public AudioClip[] sprayCanShakeSFX;

	public ParticleSystem sprayParticle;

	public ParticleSystem sprayCanNeedsShakingParticle;

	private bool isSpraying;

	private float sprayInterval;

	public float sprayIntervalSpeed = 0.2f;

	private Vector3 previousSprayPosition;

	public static List<GameObject> sprayPaintDecals = new List<GameObject>();

	public static int sprayPaintDecalsIndex;

	public GameObject sprayPaintPrefab;

	public int maxSprayPaintDecals = 1000;

	private float sprayCanTank = 1f;

	private float sprayCanShakeMeter;

	public static DecalProjector previousSprayDecal;

	private float shakingCanTimer;

	private bool tryingToUseEmptyCan;

	public Material[] sprayCanMats;

	public Material[] particleMats;

	private int sprayCanMatsIndex;

	private RaycastHit sprayHit;

	public bool debugSprayPaint;

	private int addSprayPaintWithFrameDelay;

	private DecalProjector delayedSprayPaintDecal;

	private int sprayPaintMask = 605030721;

	private bool makingAudio;

	private float audioInterval;

	[Space(5f)]
	public bool isWeedKillerSprayBottle;

	private Transform killingWeed;

	private Collider[] weedColliders;

	private float killWeedSpeed = 1f;

	private float addVehicleHPInterval;

	public override void Start()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		weedColliders = (Collider[])(object)new Collider[3];
		sprayHit = default(RaycastHit);
		if (!isWeedKillerSprayBottle)
		{
			Random random = new Random(StartOfRound.Instance.randomMapSeed + 151);
			sprayCanMatsIndex = random.Next(0, sprayCanMats.Length);
			((Renderer)((Component)sprayParticle).GetComponent<ParticleSystemRenderer>()).material = particleMats[sprayCanMatsIndex];
			((Renderer)((Component)sprayCanNeedsShakingParticle).GetComponent<ParticleSystemRenderer>()).material = particleMats[sprayCanMatsIndex];
		}
	}

	public override void LoadItemSaveData(int saveData)
	{
		base.LoadItemSaveData(saveData);
		sprayCanTank = (float)saveData / 100f;
	}

	public override int GetItemDataToSave()
	{
		return (int)(sprayCanTank * 100f);
	}

	public override void EquipItem()
	{
		base.EquipItem();
		playerHeldBy.equippedUsableItemQE = true;
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		if (buttonDown)
		{
			Debug.Log((object)"Start using spray");
			if (sprayCanTank <= 0f || sprayCanShakeMeter <= 0f)
			{
				Debug.Log((object)"Spray empty");
				if (isSpraying)
				{
					StopSpraying();
				}
				PlayCanEmptyEffect(sprayCanTank <= 0f);
			}
			else
			{
				Debug.Log((object)"Spray not empty");
				StartSpraying();
			}
			return;
		}
		Debug.Log((object)"Stop using spray");
		if (tryingToUseEmptyCan)
		{
			addVehicleHPInterval = 0f;
			tryingToUseEmptyCan = false;
			sprayAudio.Stop();
			sprayCanNeedsShakingParticle.Stop(true, (ParticleSystemStopBehavior)1);
		}
		if (isWeedKillerSprayBottle)
		{
			sprayCanShakeMeter = 1f;
		}
		if (isSpraying)
		{
			StopSpraying();
		}
	}

	private void PlayCanEmptyEffect(bool isEmpty)
	{
		if (tryingToUseEmptyCan)
		{
			return;
		}
		tryingToUseEmptyCan = true;
		if (!isEmpty)
		{
			if (sprayCanNeedsShakingParticle.isPlaying)
			{
				sprayCanNeedsShakingParticle.Stop(true, (ParticleSystemStopBehavior)0);
			}
			sprayCanNeedsShakingParticle.Play();
			sprayAudio.clip = sprayNeedsShakingSFX;
			sprayAudio.Play();
		}
		else
		{
			sprayAudio.PlayOneShot(sprayCanEmptySFX);
		}
	}

	public override void ItemInteractLeftRight(bool right)
	{
		base.ItemInteractLeftRight(right);
		Debug.Log((object)$"interact {right} ; {(Object)(object)playerHeldBy == (Object)null}; {isSpraying}");
		if (!isWeedKillerSprayBottle && !right && !((Object)(object)playerHeldBy == (Object)null) && !isSpraying)
		{
			if (sprayCanTank <= 0f)
			{
				sprayAudio.PlayOneShot(sprayCanShakeEmptySFX);
				WalkieTalkie.TransmitOneShotAudio(sprayAudio, sprayCanShakeEmptySFX);
			}
			else
			{
				RoundManager.PlayRandomClip(sprayAudio, sprayCanShakeSFX);
				WalkieTalkie.TransmitOneShotAudio(sprayAudio, sprayCanShakeEmptySFX);
			}
			playerHeldBy.playerBodyAnimator.SetTrigger("shakeItem");
			sprayCanShakeMeter = Mathf.Min(sprayCanShakeMeter + 0.15f, 1f);
		}
	}

	public override void LateUpdate()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		base.LateUpdate();
		if (isWeedKillerSprayBottle && (Object)(object)killingWeed != (Object)null)
		{
			killingWeed.localScale *= 1f - killWeedSpeed * Time.deltaTime;
			if (killingWeed.localScale.x < 0.5f)
			{
				KillWeedServerRpc(((Component)killingWeed).transform.position);
				Object.FindObjectOfType<MoldSpreadManager>().DestroyMoldAtPosition(((Component)killingWeed).transform.position, playEffect: true);
				killingWeed = null;
			}
		}
		if (makingAudio)
		{
			if (audioInterval <= 0f)
			{
				audioInterval = 1f;
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 10f, 0.65f, 0, isInShipRoom && StartOfRound.Instance.hangarDoorsClosed);
			}
			else
			{
				audioInterval -= Time.deltaTime;
			}
		}
		if (addSprayPaintWithFrameDelay > 1)
		{
			addSprayPaintWithFrameDelay--;
		}
		else if (addSprayPaintWithFrameDelay == 1)
		{
			addSprayPaintWithFrameDelay = 0;
			((Behaviour)delayedSprayPaintDecal).enabled = true;
		}
		if (isSpraying && isHeld)
		{
			if (isWeedKillerSprayBottle)
			{
				Debug.Log((object)"Spraying, depleting tank");
				sprayCanTank = Mathf.Max(sprayCanTank - Time.deltaTime / 15f, 0f);
				sprayCanShakeMeter = Mathf.Max(sprayCanShakeMeter - Time.deltaTime * 2f, 0f);
			}
			else
			{
				sprayCanTank = Mathf.Max(sprayCanTank - Time.deltaTime / 30f, 0f);
				sprayCanShakeMeter = Mathf.Max(sprayCanShakeMeter - Time.deltaTime / 10f, 0f);
			}
			if (sprayCanTank <= 0f || sprayCanShakeMeter <= 0f)
			{
				isSpraying = false;
				StopSpraying();
				PlayCanEmptyEffect(sprayCanTank <= 0f);
			}
			else
			{
				if (!((NetworkBehaviour)this).IsOwner)
				{
					return;
				}
				if (sprayInterval <= 0f)
				{
					if (isWeedKillerSprayBottle)
					{
						sprayInterval = sprayIntervalSpeed;
						TrySprayingWeedKillerBottle();
					}
					else if (TrySpraying())
					{
						sprayInterval = sprayIntervalSpeed;
					}
					else
					{
						sprayInterval = 0.037f;
					}
				}
				else
				{
					sprayInterval -= Time.deltaTime;
				}
			}
		}
		else if (isWeedKillerSprayBottle)
		{
			StopKillingWeedLocalClient();
		}
	}

	private void TrySprayingWeedKillerBottle()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position - ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward * 0.7f;
		if (!Physics.Raycast(val, ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward, ref sprayHit, 4.5f, 1073807616, (QueryTriggerInteraction)2))
		{
			return;
		}
		if (((Component)((RaycastHit)(ref sprayHit)).collider).gameObject.layer == 16 && ((Component)((RaycastHit)(ref sprayHit)).collider).gameObject.CompareTag("MoldSporeCollider"))
		{
			StartKillingWeedLocalClient(((Component)((RaycastHit)(ref sprayHit)).collider).transform);
			return;
		}
		StopKillingWeedLocalClient();
		if (addVehicleHPInterval <= 0f)
		{
			addVehicleHPInterval = 0.3f;
			VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
			if ((Object)(object)vehicleController != (Object)null && Vector3.Distance(((RaycastHit)(ref sprayHit)).point, vehicleController.oilPipePoint.position) < 5f)
			{
				if (vehicleController.carHP >= vehicleController.baseCarHP)
				{
					vehicleController.AddTurboBoost();
					Debug.Log((object)"Add turbo boost");
				}
				else
				{
					vehicleController.AddEngineOil();
					Debug.Log((object)"Add turbo boost");
				}
			}
			Debug.DrawRay(((RaycastHit)(ref sprayHit)).point, Vector3.up * 0.5f, Color.red, 1f);
			Debug.DrawLine(val, ((RaycastHit)(ref sprayHit)).point, Color.green, 5f);
		}
		else
		{
			addVehicleHPInterval -= Time.deltaTime;
		}
	}

	private void StopKillingWeedLocalClient()
	{
		if (!((Object)(object)killingWeed == (Object)null))
		{
			killingWeed = null;
			StopKillingWeedServerRpc();
		}
	}

	private void StartKillingWeedLocalClient(Transform newWeed)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)killingWeed == (Object)(object)((Component)((RaycastHit)(ref sprayHit)).collider).transform))
		{
			killingWeed = newWeed;
			StartKillingWeedServerRpc(((Component)newWeed).transform.position);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StartKillingWeedServerRpc(Vector3 atPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1299951927u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref atPosition);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1299951927u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StartKillingWeedClientRpc(atPosition);
			}
		}
	}

	[ClientRpc]
	public void StartKillingWeedClientRpc(Vector3 atPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1284445210u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref atPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1284445210u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner && Physics.OverlapSphereNonAlloc(atPosition, 0.25f, weedColliders, 65536, (QueryTriggerInteraction)2) > 0)
			{
				killingWeed = ((Component)weedColliders[0]).transform;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StopKillingWeedServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3462977352u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3462977352u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StopKillingWeedClientRpc();
			}
		}
	}

	[ClientRpc]
	public void StopKillingWeedClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1040528291u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1040528291u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				killingWeed = null;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KillWeedServerRpc(Vector3 weedPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3734429847u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref weedPos);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3734429847u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				KillWeedClientRpc(weedPos);
			}
		}
	}

	[ClientRpc]
	public void KillWeedClientRpc(Vector3 weedPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1393841103u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref weedPos);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1393841103u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				Object.FindObjectOfType<MoldSpreadManager>().DestroyMoldAtPosition(weedPos, playEffect: true);
			}
		}
	}

	public bool TrySpraying()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		Debug.DrawRay(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward, Color.magenta, 0.05f);
		if (AddSprayPaintLocal(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position + ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward * 1f, ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward))
		{
			SprayPaintServerRpc(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position + ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward * 1f, ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward);
			return true;
		}
		return false;
	}

	[ServerRpc]
	public void SprayPaintServerRpc(Vector3 sprayPos, Vector3 sprayRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Invalid comparison between Unknown and I4
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(629055349u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref sprayPos);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref sprayRot);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 629055349u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SprayPaintClientRpc(sprayPos, sprayRot);
		}
	}

	[ClientRpc]
	public void SprayPaintClientRpc(Vector3 sprayPos, Vector3 sprayRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3280104832u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref sprayPos);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref sprayRot);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3280104832u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				AddSprayPaintLocal(sprayPos, sprayRot);
			}
		}
	}

	private void ToggleSprayCollisionOnHolder(bool enable)
	{
		if ((Object)(object)playerHeldBy == (Object)null)
		{
			Debug.Log((object)"playerheldby is null!!!!!");
		}
		else if (!enable)
		{
			for (int i = 0; i < playerHeldBy.bodyPartSpraypaintColliders.Length; i++)
			{
				playerHeldBy.bodyPartSpraypaintColliders[i].enabled = false;
				((Component)playerHeldBy.bodyPartSpraypaintColliders[i]).gameObject.layer = 2;
			}
		}
		else
		{
			for (int j = 0; j < playerHeldBy.bodyPartSpraypaintColliders.Length; j++)
			{
				playerHeldBy.bodyPartSpraypaintColliders[j].enabled = false;
				((Component)playerHeldBy.bodyPartSpraypaintColliders[j]).gameObject.layer = 29;
			}
		}
	}

	private bool AddSprayPaintLocal(Vector3 sprayPos, Vector3 sprayRot)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0504: Unknown result type (might be due to invalid IL or missing references)
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_0535: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)playerHeldBy == (Object)null)
		{
			return false;
		}
		ToggleSprayCollisionOnHolder(enable: false);
		if ((Object)(object)RoundManager.Instance.mapPropsContainer == (Object)null)
		{
			RoundManager.Instance.mapPropsContainer = GameObject.FindGameObjectWithTag("MapPropsContainer");
		}
		Ray val = default(Ray);
		((Ray)(ref val))._002Ector(sprayPos, sprayRot);
		if (!Physics.Raycast(val, ref sprayHit, 7f, sprayPaintMask, (QueryTriggerInteraction)2))
		{
			ToggleSprayCollisionOnHolder(enable: true);
			return false;
		}
		if (Vector3.Distance(((RaycastHit)(ref sprayHit)).point, previousSprayPosition) < 0.175f)
		{
			ToggleSprayCollisionOnHolder(enable: true);
			return false;
		}
		if (debugSprayPaint)
		{
			Debug.DrawRay(sprayPos, sprayRot * 7f, Color.green, 5f);
		}
		int num = -1;
		Transform val2;
		if (((Component)((RaycastHit)(ref sprayHit)).collider).gameObject.layer == 11 || ((Component)((RaycastHit)(ref sprayHit)).collider).gameObject.layer == 8 || ((Component)((RaycastHit)(ref sprayHit)).collider).gameObject.layer == 0)
		{
			val2 = ((!playerHeldBy.isInElevator && !StartOfRound.Instance.inShipPhase && !((Object)(object)RoundManager.Instance.mapPropsContainer == (Object)null)) ? RoundManager.Instance.mapPropsContainer.transform : StartOfRound.Instance.elevatorTransform);
		}
		else
		{
			if (debugSprayPaint)
			{
				Debug.Log((object)("spray paint parenting to this object : " + ((Object)((Component)((RaycastHit)(ref sprayHit)).collider).gameObject).name));
				Debug.Log((object)$"{((Component)((RaycastHit)(ref sprayHit)).collider).tag}; {((Component)((RaycastHit)(ref sprayHit)).collider).tag.Length}");
			}
			if (((Component)((RaycastHit)(ref sprayHit)).collider).tag.StartsWith("PlayerBody"))
			{
				switch (((Component)((RaycastHit)(ref sprayHit)).collider).tag)
				{
				case "PlayerBody":
					num = 0;
					break;
				case "PlayerBody1":
					num = 1;
					break;
				case "PlayerBody2":
					num = 2;
					break;
				case "PlayerBody3":
					num = 3;
					break;
				}
				if (num == (int)playerHeldBy.playerClientId)
				{
					ToggleSprayCollisionOnHolder(enable: true);
					return false;
				}
			}
			else if (((Component)((RaycastHit)(ref sprayHit)).collider).tag.StartsWith("PlayerRagdoll"))
			{
				switch (((Component)((RaycastHit)(ref sprayHit)).collider).tag)
				{
				case "PlayerRagdoll":
					num = 0;
					break;
				case "PlayerRagdoll1":
					num = 1;
					break;
				case "PlayerRagdoll2":
					num = 2;
					break;
				case "PlayerRagdoll3":
					num = 3;
					break;
				}
			}
			val2 = ((Component)((RaycastHit)(ref sprayHit)).collider).transform;
		}
		sprayPaintDecalsIndex = (sprayPaintDecalsIndex + 1) % maxSprayPaintDecals;
		DecalProjector val3 = null;
		GameObject val4;
		if (sprayPaintDecals.Count <= sprayPaintDecalsIndex)
		{
			if (debugSprayPaint)
			{
				Debug.Log((object)"Adding to spray paint decals pool");
			}
			for (int i = 0; i < 200; i++)
			{
				if (sprayPaintDecals.Count >= maxSprayPaintDecals)
				{
					break;
				}
				val4 = Object.Instantiate<GameObject>(sprayPaintPrefab, val2);
				sprayPaintDecals.Add(val4);
				val3 = val4.GetComponent<DecalProjector>();
				if ((Object)(object)val3.material != (Object)(object)sprayCanMats[sprayCanMatsIndex])
				{
					val3.material = sprayCanMats[sprayCanMatsIndex];
				}
			}
		}
		if (debugSprayPaint)
		{
			Debug.Log((object)$"Spraypaint B {sprayPaintDecals.Count}; index: {sprayPaintDecalsIndex}");
		}
		if ((Object)(object)sprayPaintDecals[sprayPaintDecalsIndex] == (Object)null)
		{
			Debug.LogError((object)$"ERROR: spray paint at index {sprayPaintDecalsIndex} is null; creating new object in its place");
			val4 = Object.Instantiate<GameObject>(sprayPaintPrefab, val2);
			sprayPaintDecals[sprayPaintDecalsIndex] = val4;
		}
		else
		{
			if (!sprayPaintDecals[sprayPaintDecalsIndex].activeSelf)
			{
				sprayPaintDecals[sprayPaintDecalsIndex].SetActive(true);
			}
			val4 = sprayPaintDecals[sprayPaintDecalsIndex];
		}
		val3 = val4.GetComponent<DecalProjector>();
		if ((Object)(object)val3.material != (Object)(object)sprayCanMats[sprayCanMatsIndex])
		{
			val3.material = sprayCanMats[sprayCanMatsIndex];
		}
		if (debugSprayPaint)
		{
			Debug.Log((object)$"decal player num: {num}");
		}
		switch (num)
		{
		case 0:
			val3.decalLayerMask = (DecalLayerEnum)16;
			break;
		case 1:
			val3.decalLayerMask = (DecalLayerEnum)32;
			break;
		case 2:
			val3.decalLayerMask = (DecalLayerEnum)64;
			break;
		case 3:
			val3.decalLayerMask = (DecalLayerEnum)128;
			break;
		case -1:
			val3.decalLayerMask = (DecalLayerEnum)1;
			break;
		}
		val4.transform.position = ((Ray)(ref val)).GetPoint(((RaycastHit)(ref sprayHit)).distance - 0.1f);
		val4.transform.forward = sprayRot;
		if ((Object)(object)val4.transform.parent != (Object)(object)val2)
		{
			val4.transform.SetParent(val2);
		}
		previousSprayPosition = ((RaycastHit)(ref sprayHit)).point;
		addSprayPaintWithFrameDelay = 2;
		delayedSprayPaintDecal = val3;
		ToggleSprayCollisionOnHolder(enable: true);
		return true;
	}

	public void StartSpraying()
	{
		sprayAudio.clip = spraySFX;
		sprayAudio.Play();
		sprayParticle.Play(true);
		isSpraying = true;
		sprayAudio.PlayOneShot(sprayStart);
	}

	public void StopSpraying()
	{
		sprayAudio.Stop();
		sprayParticle.Stop(true, (ParticleSystemStopBehavior)1);
		isSpraying = false;
		sprayAudio.PlayOneShot(sprayStop);
	}

	public override void PocketItem()
	{
		base.PocketItem();
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.activatingItem = false;
			playerHeldBy.equippedUsableItemQE = false;
		}
		StopSpraying();
	}

	public override void DiscardItem()
	{
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.activatingItem = false;
			playerHeldBy.equippedUsableItemQE = false;
		}
		base.DiscardItem();
		StopSpraying();
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_SprayPaintItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1299951927u, new RpcReceiveHandler(__rpc_handler_1299951927));
		NetworkManager.__rpc_func_table.Add(1284445210u, new RpcReceiveHandler(__rpc_handler_1284445210));
		NetworkManager.__rpc_func_table.Add(3462977352u, new RpcReceiveHandler(__rpc_handler_3462977352));
		NetworkManager.__rpc_func_table.Add(1040528291u, new RpcReceiveHandler(__rpc_handler_1040528291));
		NetworkManager.__rpc_func_table.Add(3734429847u, new RpcReceiveHandler(__rpc_handler_3734429847));
		NetworkManager.__rpc_func_table.Add(1393841103u, new RpcReceiveHandler(__rpc_handler_1393841103));
		NetworkManager.__rpc_func_table.Add(629055349u, new RpcReceiveHandler(__rpc_handler_629055349));
		NetworkManager.__rpc_func_table.Add(3280104832u, new RpcReceiveHandler(__rpc_handler_3280104832));
	}

	private static void __rpc_handler_1299951927(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 atPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref atPosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SprayPaintItem)(object)target).StartKillingWeedServerRpc(atPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1284445210(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 atPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref atPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SprayPaintItem)(object)target).StartKillingWeedClientRpc(atPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3462977352(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SprayPaintItem)(object)target).StopKillingWeedServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1040528291(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SprayPaintItem)(object)target).StopKillingWeedClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3734429847(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 weedPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref weedPos);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SprayPaintItem)(object)target).KillWeedServerRpc(weedPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1393841103(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 weedPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref weedPos);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SprayPaintItem)(object)target).KillWeedClientRpc(weedPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_629055349(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 sprayPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref sprayPos);
			Vector3 sprayRot = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref sprayRot);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SprayPaintItem)(object)target).SprayPaintServerRpc(sprayPos, sprayRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3280104832(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 sprayPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref sprayPos);
			Vector3 sprayRot = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref sprayRot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SprayPaintItem)(object)target).SprayPaintClientRpc(sprayPos, sprayRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "SprayPaintItem";
	}
}
