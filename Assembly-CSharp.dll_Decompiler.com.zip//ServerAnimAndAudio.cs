using Unity.Netcode;

public struct ServerAnimAndAudio : INetworkSerializable
{
	public string animationString;

	public NetworkObjectReference animatorObj;

	public NetworkObjectReference audioObj;

	public unsafe void NetworkSerialize<T>(BufferSerializer<T> serializer) where T : IReaderWriter
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		serializer.SerializeValue(ref animationString, false);
		((BufferSerializer<NetworkObjectReference>*)(&serializer))->SerializeValue<NetworkObjectReference>(ref animatorObj, default(ForNetworkSerializable));
		((BufferSerializer<NetworkObjectReference>*)(&serializer))->SerializeValue<NetworkObjectReference>(ref audioObj, default(ForNetworkSerializable));
	}
}
