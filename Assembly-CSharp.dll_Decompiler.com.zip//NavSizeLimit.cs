using System;

[Serializable]
public enum NavSizeLimit
{
	NoLimit,
	MediumSpaces,
	SmallSpaces
}
