using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class Turret : NetworkBehaviour, IHittable
{
	[Header("Effects")]
	public AudioSource mainAudio;

	[Header("Effects")]
	public AudioSource bulletCollisionAudio;

	[Header("Effects")]
	public AudioSource farAudio;

	public AudioClip firingSFX;

	public AudioClip chargingSFX;

	public AudioClip detectPlayerSFX;

	public AudioClip firingFarSFX;

	public AudioClip bulletsHitWallSFX;

	public AudioClip turretActivate;

	public AudioClip turretDeactivate;

	public ParticleSystem bulletParticles;

	public Animator turretAnimator;

	[Header("Variables")]
	public bool turretActive = true;

	[Space(5f)]
	public TurretMode turretMode;

	private TurretMode turretModeLastFrame;

	public Transform turretRod;

	public float targetRotation;

	public float rotationSpeed = 20f;

	public Transform turnTowardsObjectCompass;

	public Transform forwardFacingPos;

	public Transform aimPoint;

	public Transform centerPoint;

	public PlayerControllerB targetPlayerWithRotation;

	public Transform targetTransform;

	private bool targetingDeadPlayer;

	public float rotationRange = 45f;

	public float currentRotation;

	public bool rotatingOnInterval = true;

	private bool rotatingRight;

	private float switchRotationTimer;

	private bool hasLineOfSight;

	private float lostLOSTimer;

	private bool wasTargetingPlayerLastFrame;

	private RaycastHit hit;

	private int wallAndPlayerMask = 2824;

	private float turretInterval;

	private string previousHitLog;

	private bool rotatingSmoothly = true;

	private Ray shootRay;

	private Coroutine fadeBulletAudioCoroutine;

	public Transform tempTransform;

	private bool rotatingClockwise;

	private float berserkTimer;

	public AudioSource berserkAudio;

	private bool enteringBerserkMode;

	private void Start()
	{
		rotationRange = Mathf.Abs(rotationRange);
		rotationSpeed = 28f;
	}

	private IEnumerator FadeBulletAudio()
	{
		float initialVolume = bulletCollisionAudio.volume;
		for (int i = 0; i <= 30; i++)
		{
			yield return (object)new WaitForSeconds(0.012f);
			bulletCollisionAudio.volume = Mathf.Lerp(initialVolume, 0f, (float)i / 30f);
		}
		bulletCollisionAudio.Stop();
	}

	private void Update()
	{
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_0796: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0468: Unknown result type (might be due to invalid IL or missing references)
		//IL_0473: Unknown result type (might be due to invalid IL or missing references)
		//IL_0478: Unknown result type (might be due to invalid IL or missing references)
		//IL_047d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_0834: Unknown result type (might be due to invalid IL or missing references)
		//IL_083f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0850: Unknown result type (might be due to invalid IL or missing references)
		//IL_081e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0441: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0455: Unknown result type (might be due to invalid IL or missing references)
		//IL_045b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0423: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06db: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_072a: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0686: Unknown result type (might be due to invalid IL or missing references)
		//IL_068c: Unknown result type (might be due to invalid IL or missing references)
		if (!turretActive)
		{
			wasTargetingPlayerLastFrame = false;
			turretMode = TurretMode.Detection;
			targetPlayerWithRotation = null;
			return;
		}
		if ((Object)(object)targetPlayerWithRotation != (Object)null)
		{
			if (!wasTargetingPlayerLastFrame)
			{
				wasTargetingPlayerLastFrame = true;
				if (turretMode == TurretMode.Detection)
				{
					turretMode = TurretMode.Charging;
				}
			}
			SetTargetToPlayerBody();
			TurnTowardsTargetIfHasLOS();
		}
		else if (wasTargetingPlayerLastFrame)
		{
			wasTargetingPlayerLastFrame = false;
			turretMode = TurretMode.Detection;
		}
		switch (turretMode)
		{
		case TurretMode.Detection:
			if (turretModeLastFrame != 0)
			{
				turretModeLastFrame = TurretMode.Detection;
				rotatingClockwise = false;
				mainAudio.Stop();
				farAudio.Stop();
				berserkAudio.Stop();
				if (fadeBulletAudioCoroutine != null)
				{
					((MonoBehaviour)this).StopCoroutine(fadeBulletAudioCoroutine);
				}
				fadeBulletAudioCoroutine = ((MonoBehaviour)this).StartCoroutine(FadeBulletAudio());
				bulletParticles.Stop(true, (ParticleSystemStopBehavior)1);
				rotationSpeed = 28f;
				rotatingSmoothly = true;
				turretAnimator.SetInteger("TurretMode", 0);
				turretInterval = Random.Range(0f, 0.15f);
			}
			if (!((NetworkBehaviour)this).IsServer)
			{
				break;
			}
			if (switchRotationTimer >= 7f)
			{
				switchRotationTimer = 0f;
				bool setRotateRight = !rotatingRight;
				SwitchRotationClientRpc(setRotateRight);
				SwitchRotationOnInterval(setRotateRight);
			}
			else
			{
				switchRotationTimer += Time.deltaTime;
			}
			if (turretInterval >= 0.25f)
			{
				turretInterval = 0f;
				PlayerControllerB playerControllerB = CheckForPlayersInLineOfSight(1.35f, angleRangeCheck: true);
				if ((Object)(object)playerControllerB != (Object)null && !playerControllerB.isPlayerDead)
				{
					targetPlayerWithRotation = playerControllerB;
					SwitchTurretMode(1);
					SwitchTargetedPlayerClientRpc((int)playerControllerB.playerClientId, setModeToCharging: true);
				}
			}
			else
			{
				turretInterval += Time.deltaTime;
			}
			break;
		case TurretMode.Charging:
			if (turretModeLastFrame != TurretMode.Charging)
			{
				turretModeLastFrame = TurretMode.Charging;
				rotatingClockwise = false;
				mainAudio.PlayOneShot(detectPlayerSFX);
				berserkAudio.Stop();
				WalkieTalkie.TransmitOneShotAudio(mainAudio, detectPlayerSFX);
				rotationSpeed = 95f;
				rotatingSmoothly = false;
				lostLOSTimer = 0f;
				turretAnimator.SetInteger("TurretMode", 1);
			}
			if (!((NetworkBehaviour)this).IsServer)
			{
				break;
			}
			if (turretInterval >= 1.5f)
			{
				turretInterval = 0f;
				Debug.Log((object)"Charging timer is up, setting to firing mode");
				if (!hasLineOfSight)
				{
					Debug.Log((object)"hasLineOfSight is false");
					targetPlayerWithRotation = null;
					RemoveTargetedPlayerClientRpc();
				}
				else
				{
					SwitchTurretMode(2);
					SetToModeClientRpc(2);
				}
			}
			else
			{
				turretInterval += Time.deltaTime;
			}
			break;
		case TurretMode.Firing:
			if (turretModeLastFrame != TurretMode.Firing)
			{
				turretModeLastFrame = TurretMode.Firing;
				berserkAudio.Stop();
				RoundManager.Instance.PlayAudibleNoise(((Component)mainAudio).transform.position, 15f, 0.9f);
				mainAudio.clip = firingSFX;
				mainAudio.Play();
				farAudio.clip = firingFarSFX;
				farAudio.Play();
				bulletParticles.Play(true);
				bulletCollisionAudio.Play();
				if (fadeBulletAudioCoroutine != null)
				{
					((MonoBehaviour)this).StopCoroutine(fadeBulletAudioCoroutine);
				}
				bulletCollisionAudio.volume = 1f;
				rotatingSmoothly = false;
				lostLOSTimer = 0f;
				turretAnimator.SetInteger("TurretMode", 2);
			}
			if (turretInterval >= 0.21f)
			{
				turretInterval = 0f;
				if ((Object)(object)CheckForPlayersInLineOfSight(3f) == (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					if (GameNetworkManager.Instance.localPlayerController.health > 50)
					{
						GameNetworkManager.Instance.localPlayerController.DamagePlayer(50, hasDamageSFX: true, callRPC: true, CauseOfDeath.Gunshots);
					}
					else
					{
						GameNetworkManager.Instance.localPlayerController.KillPlayer(aimPoint.forward * 40f, spawnBody: true, CauseOfDeath.Gunshots);
					}
				}
				shootRay = new Ray(aimPoint.position, aimPoint.forward);
				if (Physics.Raycast(shootRay, ref hit, 30f, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
				{
					((Component)bulletCollisionAudio).transform.position = ((Ray)(ref shootRay)).GetPoint(((RaycastHit)(ref hit)).distance - 0.5f);
				}
			}
			else
			{
				turretInterval += Time.deltaTime;
			}
			break;
		case TurretMode.Berserk:
			if (turretModeLastFrame != TurretMode.Berserk)
			{
				turretModeLastFrame = TurretMode.Berserk;
				turretAnimator.SetInteger("TurretMode", 1);
				berserkTimer = 1.3f;
				berserkAudio.Play();
				rotationSpeed = 77f;
				enteringBerserkMode = true;
				rotatingSmoothly = true;
				lostLOSTimer = 0f;
				wasTargetingPlayerLastFrame = false;
				targetPlayerWithRotation = null;
			}
			if (enteringBerserkMode)
			{
				berserkTimer -= Time.deltaTime;
				if (berserkTimer <= 0f)
				{
					enteringBerserkMode = false;
					rotatingClockwise = true;
					berserkTimer = 9f;
					turretAnimator.SetInteger("TurretMode", 2);
					mainAudio.clip = firingSFX;
					mainAudio.Play();
					farAudio.clip = firingFarSFX;
					farAudio.Play();
					bulletParticles.Play(true);
					bulletCollisionAudio.Play();
					if (fadeBulletAudioCoroutine != null)
					{
						((MonoBehaviour)this).StopCoroutine(fadeBulletAudioCoroutine);
					}
					bulletCollisionAudio.volume = 1f;
				}
				break;
			}
			if (turretInterval >= 0.21f)
			{
				turretInterval = 0f;
				if ((Object)(object)CheckForPlayersInLineOfSight(3f) == (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					if (GameNetworkManager.Instance.localPlayerController.health > 50)
					{
						GameNetworkManager.Instance.localPlayerController.DamagePlayer(50, hasDamageSFX: true, callRPC: true, CauseOfDeath.Gunshots);
					}
					else
					{
						GameNetworkManager.Instance.localPlayerController.KillPlayer(aimPoint.forward * 40f, spawnBody: true, CauseOfDeath.Gunshots);
					}
				}
				shootRay = new Ray(aimPoint.position, aimPoint.forward);
				if (Physics.Raycast(shootRay, ref hit, 30f, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
				{
					((Component)bulletCollisionAudio).transform.position = ((Ray)(ref shootRay)).GetPoint(((RaycastHit)(ref hit)).distance - 0.5f);
				}
			}
			else
			{
				turretInterval += Time.deltaTime;
			}
			if (((NetworkBehaviour)this).IsServer)
			{
				berserkTimer -= Time.deltaTime;
				if (berserkTimer <= 0f)
				{
					SwitchTurretMode(0);
					SetToModeClientRpc(0);
				}
			}
			break;
		}
		if (rotatingClockwise)
		{
			turnTowardsObjectCompass.localEulerAngles = new Vector3(-180f, turretRod.localEulerAngles.y - Time.deltaTime * 20f, 180f);
			turretRod.rotation = Quaternion.RotateTowards(turretRod.rotation, turnTowardsObjectCompass.rotation, rotationSpeed * Time.deltaTime);
			return;
		}
		if (rotatingSmoothly)
		{
			turnTowardsObjectCompass.localEulerAngles = new Vector3(-180f, Mathf.Clamp(targetRotation, 0f - rotationRange, rotationRange), 180f);
		}
		turretRod.rotation = Quaternion.RotateTowards(turretRod.rotation, turnTowardsObjectCompass.rotation, rotationSpeed * Time.deltaTime);
	}

	private void SetTargetToPlayerBody()
	{
		if (targetPlayerWithRotation.isPlayerDead)
		{
			if (!targetingDeadPlayer)
			{
				targetingDeadPlayer = true;
			}
			if ((Object)(object)targetPlayerWithRotation.deadBody != (Object)null)
			{
				targetTransform = ((Component)targetPlayerWithRotation.deadBody.bodyParts[5]).transform;
			}
		}
		else
		{
			targetingDeadPlayer = false;
			targetTransform = ((Component)targetPlayerWithRotation.gameplayCamera).transform;
		}
	}

	private void TurnTowardsTargetIfHasLOS()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		bool flag = true;
		if (targetingDeadPlayer || Vector3.Angle(targetTransform.position - centerPoint.position, forwardFacingPos.forward) > rotationRange)
		{
			flag = false;
		}
		if (Physics.Linecast(aimPoint.position, targetTransform.position, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
		{
			flag = false;
		}
		if (flag)
		{
			hasLineOfSight = true;
			lostLOSTimer = 0f;
			tempTransform.position = targetTransform.position;
			Transform obj = tempTransform;
			obj.position -= Vector3.up * 0.15f;
			turnTowardsObjectCompass.LookAt(tempTransform);
			return;
		}
		if (hasLineOfSight)
		{
			hasLineOfSight = false;
			lostLOSTimer = 0f;
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		lostLOSTimer += Time.deltaTime;
		if (lostLOSTimer >= 2f)
		{
			lostLOSTimer = 0f;
			Debug.Log((object)"Turret: LOS timer ended on server. checking for new player target");
			PlayerControllerB playerControllerB = CheckForPlayersInLineOfSight();
			if ((Object)(object)playerControllerB != (Object)null)
			{
				targetPlayerWithRotation = playerControllerB;
				SwitchTargetedPlayerClientRpc((int)playerControllerB.playerClientId);
				Debug.Log((object)"Turret: Got new player target");
			}
			else
			{
				Debug.Log((object)"Turret: No new player to target; returning to detection mode.");
				targetPlayerWithRotation = null;
				RemoveTargetedPlayerClientRpc();
			}
		}
	}

	public PlayerControllerB CheckForPlayersInLineOfSight(float radius = 2f, bool angleRangeCheck = false)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = aimPoint.forward;
		val = Quaternion.Euler(0f, (float)(int)(0f - rotationRange) / radius, 0f) * val;
		float num = rotationRange / radius * 2f;
		for (int i = 0; i <= 6; i++)
		{
			shootRay = new Ray(centerPoint.position, val);
			if (Physics.Raycast(shootRay, ref hit, 30f, 1051400, (QueryTriggerInteraction)1))
			{
				if (((Component)((RaycastHit)(ref hit)).transform).CompareTag("Player"))
				{
					PlayerControllerB component = ((Component)((RaycastHit)(ref hit)).transform).GetComponent<PlayerControllerB>();
					if (!((Object)(object)component == (Object)null))
					{
						if (angleRangeCheck && Vector3.Angle(((Component)component).transform.position + Vector3.up * 1.75f - centerPoint.position, forwardFacingPos.forward) > rotationRange)
						{
							return null;
						}
						return component;
					}
					continue;
				}
				if ((turretMode == TurretMode.Firing || (turretMode == TurretMode.Berserk && !enteringBerserkMode)) && ((Component)((RaycastHit)(ref hit)).transform).tag.StartsWith("PlayerRagdoll"))
				{
					Rigidbody component2 = ((Component)((RaycastHit)(ref hit)).transform).GetComponent<Rigidbody>();
					if ((Object)(object)component2 != (Object)null)
					{
						component2.AddForce(((Vector3)(ref val)).normalized * 42f, (ForceMode)1);
					}
				}
			}
			val = Quaternion.Euler(0f, num / 6f, 0f) * val;
		}
		return null;
	}

	[ClientRpc]
	public void SwitchRotationClientRpc(bool setRotateRight)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2426770061u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setRotateRight, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2426770061u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				SwitchRotationOnInterval(setRotateRight);
			}
		}
	}

	public void SwitchRotationOnInterval(bool setRotateRight)
	{
		if (rotatingRight)
		{
			rotatingRight = false;
			targetRotation = rotationRange;
		}
		else
		{
			rotatingRight = true;
			targetRotation = 0f - rotationRange;
		}
	}

	[ClientRpc]
	public void SwitchTargetedPlayerClientRpc(int playerId, bool setModeToCharging = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(866050294u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setModeToCharging, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 866050294u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
		{
			targetPlayerWithRotation = StartOfRound.Instance.allPlayerScripts[playerId];
			if (setModeToCharging)
			{
				SwitchTurretMode(1);
			}
		}
	}

	[ClientRpc]
	public void RemoveTargetedPlayerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2800017671u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2800017671u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				targetPlayerWithRotation = null;
			}
		}
	}

	[ClientRpc]
	public void SetToModeClientRpc(int mode)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3335553538u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, mode);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3335553538u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				SwitchTurretMode(mode);
			}
		}
	}

	private void SwitchTurretMode(int mode)
	{
		turretMode = (TurretMode)mode;
	}

	public void ToggleTurretEnabled(bool enabled)
	{
		if (turretActive != enabled)
		{
			ToggleTurretEnabledLocalClient(enabled);
			ToggleTurretServerRpc(enabled);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ToggleTurretServerRpc(bool enabled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2339273208u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enabled, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2339273208u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ToggleTurretClientRpc(enabled);
			}
		}
	}

	[ClientRpc]
	public void ToggleTurretClientRpc(bool enabled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1135819343u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enabled, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1135819343u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && turretActive != enabled)
			{
				ToggleTurretEnabledLocalClient(enabled);
			}
		}
	}

	private void ToggleTurretEnabledLocalClient(bool enabled)
	{
		turretActive = enabled;
		turretAnimator.SetBool("turretActive", turretActive);
		if (enabled)
		{
			mainAudio.PlayOneShot(turretActivate);
			WalkieTalkie.TransmitOneShotAudio(mainAudio, turretActivate);
		}
		else
		{
			mainAudio.PlayOneShot(turretDeactivate);
			WalkieTalkie.TransmitOneShotAudio(mainAudio, turretDeactivate);
		}
	}

	bool IHittable.Hit(int force, Vector3 hitDirection, PlayerControllerB playerWhoHit, bool playHitSFX, int hitID = -1)
	{
		if (turretMode == TurretMode.Berserk || turretMode == TurretMode.Firing)
		{
			return false;
		}
		SwitchTurretMode(3);
		EnterBerserkModeServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		return true;
	}

	[ServerRpc(RequireOwnership = false)]
	public void EnterBerserkModeServerRpc(int playerWhoTriggered)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4195711963u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4195711963u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				EnterBerserkModeClientRpc(playerWhoTriggered);
			}
		}
	}

	[ClientRpc]
	public void EnterBerserkModeClientRpc(int playerWhoTriggered)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1436540455u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1436540455u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerWhoTriggered != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				SwitchTurretMode(3);
			}
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_Turret()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2426770061u, new RpcReceiveHandler(__rpc_handler_2426770061));
		NetworkManager.__rpc_func_table.Add(866050294u, new RpcReceiveHandler(__rpc_handler_866050294));
		NetworkManager.__rpc_func_table.Add(2800017671u, new RpcReceiveHandler(__rpc_handler_2800017671));
		NetworkManager.__rpc_func_table.Add(3335553538u, new RpcReceiveHandler(__rpc_handler_3335553538));
		NetworkManager.__rpc_func_table.Add(2339273208u, new RpcReceiveHandler(__rpc_handler_2339273208));
		NetworkManager.__rpc_func_table.Add(1135819343u, new RpcReceiveHandler(__rpc_handler_1135819343));
		NetworkManager.__rpc_func_table.Add(4195711963u, new RpcReceiveHandler(__rpc_handler_4195711963));
		NetworkManager.__rpc_func_table.Add(1436540455u, new RpcReceiveHandler(__rpc_handler_1436540455));
	}

	private static void __rpc_handler_2426770061(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool setRotateRight = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setRotateRight, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Turret)(object)target).SwitchRotationClientRpc(setRotateRight);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_866050294(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			bool setModeToCharging = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setModeToCharging, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Turret)(object)target).SwitchTargetedPlayerClientRpc(playerId, setModeToCharging);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2800017671(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Turret)(object)target).RemoveTargetedPlayerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3335553538(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int toModeClientRpc = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref toModeClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Turret)(object)target).SetToModeClientRpc(toModeClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2339273208(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enabled = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enabled, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((Turret)(object)target).ToggleTurretServerRpc(enabled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1135819343(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enabled = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enabled, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Turret)(object)target).ToggleTurretClientRpc(enabled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4195711963(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((Turret)(object)target).EnterBerserkModeServerRpc(playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1436540455(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Turret)(object)target).EnterBerserkModeClientRpc(playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "Turret";
	}
}
