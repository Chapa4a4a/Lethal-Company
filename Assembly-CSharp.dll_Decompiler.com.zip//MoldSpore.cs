using UnityEngine;

public class MoldSpore
{
	public Vector3 spawnPosition;

	public bool markedForDestruction;

	public bool destroyedByPlayer;

	public int generationId;

	public MoldSpore(Vector3 spawnPos, bool marked, int genID)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		spawnPosition = spawnPos;
		markedForDestruction = marked;
		generationId = genID;
	}
}
