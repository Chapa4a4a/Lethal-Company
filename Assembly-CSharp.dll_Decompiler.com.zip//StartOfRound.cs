using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Dissonance;
using Dissonance.Integrations.Unity_NFGO;
using GameNetcodeStuff;
using Steamworks;
using Steamworks.Data;
using TMPro;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.Events;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Video;

public class StartOfRound : NetworkBehaviour
{
	public bool shouldApproveConnection;

	public bool allowLocalPlayerDeath = true;

	[Space(3f)]
	public int connectedPlayersAmount;

	public int thisClientPlayerId;

	public List<ulong> fullyLoadedPlayers = new List<ulong>(4);

	public int livingPlayers = 4;

	private bool mostRecentlyJoinedClient;

	public bool allPlayersDead;

	public Dictionary<ulong, int> ClientPlayerList = new Dictionary<ulong, int>();

	public List<ulong> KickedClientIds = new List<ulong>();

	public int daysPlayersSurvivedInARow;

	[Space(5f)]
	private bool hasHostSpawned;

	public bool inShipPhase = true;

	public float timeSinceRoundStarted;

	public bool shipIsLeaving;

	public bool displayedLevelResults;

	public bool newGameIsLoading;

	private int playersRevived;

	public EndOfGameStats gameStats;

	private bool localPlayerWasMostProfitableThisRound;

	[Header("Important objects")]
	public Camera spectateCamera;

	public AudioListener audioListener;

	[HideInInspector]
	public bool overrideSpectateCamera;

	public GameObject[] allPlayerObjects;

	public PlayerControllerB[] allPlayerScripts;

	public Transform[] playerSpawnPositions;

	public Transform outsideShipSpawnPosition;

	public Transform notSpawnedPosition;

	public Transform propsContainer;

	public Transform elevatorTransform;

	public Transform playersContainer;

	public Transform groundOutsideShipSpawnPosition;

	public Transform shipLandingPosition;

	public Transform outsideDoorPosition;

	public PlayerControllerB localPlayerController;

	public List<PlayerControllerB> OtherClients = new List<PlayerControllerB>();

	[Space(3f)]
	public UnlockablesList unlockablesList;

	public AudioClip changeSuitSFX;

	public GameObject suitPrefab;

	public int suitsPlaced;

	public Transform rightmostSuitPosition;

	[Space(5f)]
	public GameObject playerPrefab;

	public GameObject ragdollGrabbableObjectPrefab;

	public List<GameObject> playerRagdolls = new List<GameObject>();

	public GameObject playerBloodPrefab;

	public Transform bloodObjectsContainer;

	public Camera introCamera;

	public Camera activeCamera;

	public SimpleEvent CameraSwitchEvent = new SimpleEvent();

	public SimpleEvent StartNewRoundEvent = new SimpleEvent();

	public PlayerEvent PlayerJumpEvent = new PlayerEvent();

	public PlayerEvent PlayerMoveInputEvent = new PlayerEvent();

	public SimpleEvent LocalPlayerDamagedEvent = new SimpleEvent();

	public SimpleEvent ShipPowerSurgedEvent = new SimpleEvent();

	public GameObject testRoom;

	public GameObject testRoomPrefab;

	public Transform testRoomSpawnPosition;

	public bool localClientHasControl;

	public RuntimeAnimatorController localClientAnimatorController;

	public RuntimeAnimatorController otherClientsAnimatorController;

	public int playersMask = 8;

	[NonSerialized]
	public int collidersAndRoomMask = 1107298560;

	[NonSerialized]
	public int collidersAndRoomMaskAndPlayers = 1107298568;

	[NonSerialized]
	public int collidersAndRoomMaskAndDefault = 1107298561;

	[NonSerialized]
	public int collidersRoomMaskDefaultAndPlayers = 1107298569;

	[NonSerialized]
	public int collidersRoomDefaultAndFoliage = 1107299585;

	[NonSerialized]
	public int allPlayersCollideWithMask = -1111790665;

	[NonSerialized]
	public int walkableSurfacesMask = 1375734025;

	[Header("Physics")]
	public Collider[] PlayerPhysicsColliders;

	public List<PlayerPhysicsRegion> CurrentPlayerPhysicsRegions = new List<PlayerPhysicsRegion>();

	[Header("Ship Animations")]
	public NetworkObject shipAnimatorObject;

	public Animator shipAnimator;

	public AudioSource shipAmbianceAudio;

	public AudioSource ship3DAudio;

	public AudioClip shipDepartSFX;

	public AudioClip shipArriveSFX;

	public AudioSource shipDoorAudioSource;

	public AudioSource speakerAudioSource;

	public AudioClip suckedIntoSpaceSFX;

	public AudioClip airPressureSFX;

	public AudioClip[] shipCreakSFX;

	public AudioClip alarmSFX;

	public AudioClip firedVoiceSFX;

	public AudioClip openingHangarDoorAudio;

	public AudioClip allPlayersDeadAudio;

	public AudioClip shipIntroSpeechSFX;

	public AudioClip disableSpeakerSFX;

	public AudioClip zeroDaysLeftAlertSFX;

	public bool shipLeftAutomatically;

	public DialogueSegment[] openingDoorDialogue;

	public DialogueSegment[] gameOverDialogue;

	public DialogueSegment[] shipLeavingOnMidnightDialogue;

	public bool shipDoorsEnabled;

	public bool shipHasLanded;

	public Animator shipDoorsAnimator;

	public bool hangarDoorsClosed = true;

	private Coroutine shipTravelCoroutine;

	public ShipLights shipRoomLights;

	public AnimatedObjectTrigger closetLeftDoor;

	public AnimatedObjectTrigger closetRightDoor;

	public GameObject starSphereObject;

	public Dictionary<int, GameObject> SpawnedShipUnlockables = new Dictionary<int, GameObject>();

	public Transform gameOverCameraHandle;

	public Transform freeCinematicCameraTurnCompass;

	public Camera freeCinematicCamera;

	[Header("Players fired animation")]
	public bool firingPlayersCutsceneRunning;

	public bool suckingPlayersOutOfShip;

	private bool choseRandomFlyDirForPlayer;

	private Vector3 randomFlyDir = Vector3.zero;

	public float suckingPower;

	public bool suckingFurnitureOutOfShip;

	public Transform middleOfShipNode;

	public Transform shipDoorNode;

	public Transform middleOfSpaceNode;

	public Transform moveAwayFromShipNode;

	[Header("Level selection")]
	public GameObject currentPlanetPrefab;

	public Animator currentPlanetAnimator;

	public Animator outerSpaceSunAnimator;

	public Transform planetContainer;

	public SelectableLevel[] levels;

	public SelectableLevel currentLevel;

	public int currentLevelID;

	public bool isChallengeFile;

	public bool hasSubmittedChallengeRank;

	public int defaultPlanet;

	public bool travellingToNewLevel;

	public AnimationCurve planetsWeatherRandomCurve;

	public int maxShipItemCapacity = 45;

	public int currentShipItemCount;

	[Header("Ship Monitors")]
	public TextMeshProUGUI screenLevelDescription;

	public VideoPlayer screenLevelVideoReel;

	public TextMeshProUGUI mapScreenPlayerName;

	public Image mapScreenPlayerNameBG;

	public ManualCameraRenderer mapScreen;

	public GameObject objectCodePrefab;

	public GameObject itemRadarIconPrefab;

	public GameObject keyRadarIconPrefab;

	[Space(5f)]
	public Image deadlineMonitorBGImage;

	public Image profitQuotaMonitorBGImage;

	public TextMeshProUGUI deadlineMonitorText;

	public TextMeshProUGUI profitQuotaMonitorText;

	public GameObject upperMonitorsCanvas;

	public Canvas radarCanvas;

	[Header("Randomization")]
	public int randomMapSeed;

	public bool overrideRandomSeed;

	public int overrideSeedNumber;

	public AnimationCurve objectFallToGroundCurve;

	public AnimationCurve objectFallToGroundCurveNoBounce;

	public AnimationCurve playerSinkingCurve;

	[Header("Voice chat")]
	public DissonanceComms voiceChatModule;

	public float averageVoiceAmplitude;

	public int movingAverageLength = 20;

	public int averageCount;

	private float voiceChatNoiseCooldown;

	public bool updatedPlayerVoiceEffectsThisFrame;

	[Header("Player Audios")]
	public AudioMixerGroup playersVoiceMixerGroup;

	public FootstepSurface[] footstepSurfaces;

	public string[] naturalSurfaceTags;

	public AudioClip[] statusEffectClips;

	public AudioClip HUDSystemAlertSFX;

	public AudioClip playerJumpSFX;

	public AudioClip playerHitGroundSoft;

	public AudioClip playerHitGroundHard;

	public AudioClip damageSFX;

	public AudioClip fallDamageSFX;

	public AudioClip bloodGoreSFX;

	[Space(5f)]
	public float drowningTimer;

	[HideInInspector]
	public bool playedDrowningSFX;

	public AudioClip[] bodyCollisionSFX;

	public AudioClip playerFallDeath;

	public AudioClip hitPlayerSFX;

	private Coroutine fadeVolumeCoroutine;

	public List<DecalProjector> snowFootprintsPooledObjects = new List<DecalProjector>();

	public GameObject footprintDecal;

	public int currentFootprintIndex;

	public GameObject explosionPrefab;

	public float fearLevel;

	public bool fearLevelIncreasing;

	[Header("Company building game loop")]
	public float companyBuyingRate = 1f;

	public int hoursSinceLastCompanyVisit;

	public AudioClip companyVisitMusic;

	public bool localPlayerUsingController;

	private bool subscribedToConnectionApproval;

	public Collider shipBounds;

	public Collider shipInnerRoomBounds;

	public Collider shipStrictInnerRoomBounds;

	private Coroutine updateVoiceEffectsCoroutine;

	public ReverbPreset shipReverb;

	public AnimationCurve drunknessSpeedEffect;

	public AnimationCurve drunknessSideEffect;

	private float updatePlayerVoiceInterval;

	public Volume blackSkyVolume;

	[Space(5f)]
	public AllItemsList allItemsList;

	public InteractEvent playerTeleportedEvent;

	[Space(3f)]
	public string[] randomNames;

	public float timeAtStartOfRun;

	public float playerLookMagnitudeThisFrame;

	public float timeAtMakingLastPersonalMovement;

	public Transform[] insideShipPositions;

	public int scrapCollectedLastRound;

	[Header("Vehicles")]
	public bool magnetOn;

	public ParticleSystem magnetParticle;

	public AudioSource magnetAudio;

	public Transform magnetPoint;

	public AudioClip magnetOffAudio;

	public AudioClip magnetOnAudio;

	public bool isObjectAttachedToMagnet;

	public AnimatedObjectTrigger magnetLever;

	[Space(3f)]
	public GameObject[] VehiclesList;

	public VehicleController attachedVehicle;

	public static StartOfRound Instance { get; private set; }

	public void SetMagnetOn(bool on)
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		if (magnetOn != on)
		{
			magnetOn = on;
			if (on)
			{
				magnetParticle.Play(true);
				magnetAudio.clip = magnetOnAudio;
			}
			else
			{
				isObjectAttachedToMagnet = false;
				magnetAudio.clip = magnetOffAudio;
			}
			magnetAudio.Play();
			if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position, ((Component)magnetAudio).transform.position) < 8f && !GameNetworkManager.Instance.localPlayerController.isInElevator)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
				PlayerControllerB playerControllerB = GameNetworkManager.Instance.localPlayerController;
				playerControllerB.externalForceAutoFade += ((Component)magnetAudio).transform.position - ((Component)GameNetworkManager.Instance.localPlayerController).transform.position;
			}
			SetMagnetOnServerRpc(on);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetMagnetOnServerRpc(bool on)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3212216718u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref on, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3212216718u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetMagnetOnClientRpc(on);
			}
		}
	}

	[ClientRpc]
	public void SetMagnetOnClientRpc(bool on)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2773812843u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref on, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2773812843u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && magnetOn != on)
		{
			magnetOn = on;
			if (on)
			{
				magnetParticle.Play(true);
				magnetAudio.clip = magnetOnAudio;
			}
			else
			{
				isObjectAttachedToMagnet = false;
				magnetAudio.clip = magnetOffAudio;
			}
			magnetAudio.Play();
		}
	}

	public void InstantiateFootprintsPooledObjects()
	{
		int num = 250;
		for (int i = 0; i < num; i++)
		{
			GameObject val = Object.Instantiate<GameObject>(footprintDecal, bloodObjectsContainer);
			snowFootprintsPooledObjects.Add(val.GetComponent<DecalProjector>());
		}
	}

	private void ResetPooledObjects(bool destroy = false)
	{
		for (int i = 0; i < snowFootprintsPooledObjects.Count; i++)
		{
			if (!((Object)(object)snowFootprintsPooledObjects[i] == (Object)null))
			{
				((Behaviour)snowFootprintsPooledObjects[i]).enabled = false;
			}
		}
		if (SprayPaintItem.sprayPaintDecals == null)
		{
			return;
		}
		for (int num = SprayPaintItem.sprayPaintDecals.Count - 1; num >= 0; num--)
		{
			if ((destroy || !((Object)(object)SprayPaintItem.sprayPaintDecals[num] != (Object)null) || !SprayPaintItem.sprayPaintDecals[num].transform.IsChildOf(elevatorTransform)) && !((Object)(object)SprayPaintItem.sprayPaintDecals[num] == (Object)null))
			{
				Object.Destroy((Object)(object)SprayPaintItem.sprayPaintDecals[num]);
				SprayPaintItem.sprayPaintDecals.RemoveAt(num);
			}
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("RadarCodeUIObject");
		for (int num2 = array.Length - 1; num2 >= 0; num2--)
		{
			Object.Destroy((Object)(object)array[num2]);
		}
	}

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
			timeAtStartOfRun = Time.realtimeSinceStartup;
		}
		else
		{
			Object.Destroy((Object)(object)((Component)Instance).gameObject);
			Instance = this;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void PlayerLoadedServerRpc(ulong clientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4249638645u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clientId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4249638645u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				fullyLoadedPlayers.Add(clientId);
				PlayerLoadedClientRpc(clientId);
			}
		}
	}

	[ClientRpc]
	private void PlayerLoadedClientRpc(ulong clientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(462348217u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clientId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 462348217u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				fullyLoadedPlayers.Add(clientId);
			}
		}
	}

	[ClientRpc]
	private void ResetPlayersLoadedValueClientRpc(bool landingShip = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(161788012u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref landingShip, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 161788012u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		fullyLoadedPlayers.Clear();
		if (landingShip)
		{
			if ((Object)(object)currentPlanetAnimator != (Object)null)
			{
				currentPlanetAnimator.SetTrigger("LandOnPlanet");
			}
			Object.FindObjectOfType<StartMatchLever>().triggerScript.interactable = false;
			Object.FindObjectOfType<StartMatchLever>().triggerScript.disabledHoverTip = "[Wait for ship to land]";
		}
	}

	private void SceneManager_OnLoadComplete1(ulong clientId, string sceneName, LoadSceneMode loadSceneMode)
	{
		DisableSpatializationOnAllAudio();
		if (sceneName == currentLevel.sceneName)
		{
			if (!shipDoorsEnabled)
			{
				((Behaviour)HUDManager.Instance.loadingText).enabled = true;
				((Behaviour)HUDManager.Instance.loadingDarkenScreen).enabled = true;
			}
			((TMP_Text)HUDManager.Instance.loadingText).text = "Waiting for crew...";
		}
		ClientPlayerList.TryGetValue(clientId, out var value);
		if (value == 0 || !((NetworkBehaviour)this).IsServer)
		{
			PlayerLoadedServerRpc(clientId);
		}
	}

	private void SceneManager_OnUnloadComplete(ulong clientId, string sceneName)
	{
		if (sceneName == currentLevel.sceneName)
		{
			if ((Object)(object)currentPlanetPrefab != (Object)null)
			{
				currentPlanetPrefab.SetActive(true);
				((Component)outerSpaceSunAnimator).gameObject.SetActive(true);
				currentPlanetAnimator.SetTrigger("LeavePlanet");
			}
			ClientPlayerList.TryGetValue(clientId, out var value);
			if (value == 0 || !((NetworkBehaviour)this).IsServer)
			{
				PlayerLoadedServerRpc(clientId);
			}
		}
	}

	private void SceneManager_OnLoad(ulong clientId, string sceneName, LoadSceneMode loadSceneMode, AsyncOperation asyncOperation)
	{
		Debug.Log((object)"Loading scene");
		Debug.Log((object)("Scene that began loading: " + sceneName));
		if (!(sceneName != "SampleSceneRelay") || !(sceneName != "MainMenu"))
		{
			return;
		}
		if ((Object)(object)currentPlanetPrefab != (Object)null)
		{
			currentPlanetPrefab.SetActive(false);
		}
		((Component)outerSpaceSunAnimator).gameObject.SetActive(false);
		if (currentLevel.sceneName != sceneName)
		{
			for (int i = 0; i < levels.Length; i++)
			{
				if (levels[i].sceneName == sceneName)
				{
					ChangeLevel(i);
				}
			}
		}
		((Behaviour)HUDManager.Instance.loadingText).enabled = true;
		((TMP_Text)HUDManager.Instance.loadingText).text = "LOADING WORLD...";
	}

	private void OnEnable()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Expected O, but got Unknown
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Expected O, but got Unknown
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Expected O, but got Unknown
		Debug.Log((object)"Enabling connection callbacks in StartOfRound");
		if ((Object)(object)NetworkManager.Singleton != (Object)null)
		{
			Debug.Log((object)"Began listening to SceneManager_OnLoadComplete1 on this client");
			try
			{
				NetworkManager.Singleton.SceneManager.OnLoadComplete += new OnLoadCompleteDelegateHandler(SceneManager_OnLoadComplete1);
				NetworkManager.Singleton.SceneManager.OnLoad += new OnLoadDelegateHandler(SceneManager_OnLoad);
				NetworkManager.Singleton.SceneManager.OnUnloadComplete += new OnUnloadCompleteDelegateHandler(SceneManager_OnUnloadComplete);
			}
			catch (Exception arg)
			{
				Debug.LogError((object)$"Error returned when subscribing to scenemanager callbacks!: {arg}");
				GameNetworkManager.Instance.disconnectionReasonMessage = "An error occured when syncing the scene! The host might not have loaded in.";
				GameNetworkManager.Instance.Disconnect();
				return;
			}
			_ = ((NetworkBehaviour)this).IsServer;
		}
		else
		{
			GameNetworkManager.Instance.disconnectionReasonMessage = "Your connection timed out before you could load in. Try again?";
			GameNetworkManager.Instance.Disconnect();
		}
	}

	private void OnDisable()
	{
		Debug.Log((object)"DISABLING connection callbacks in round manager");
		if ((Object)(object)NetworkManager.Singleton != (Object)null)
		{
			_ = subscribedToConnectionApproval;
		}
	}

	private void Start()
	{
		Debug.Log((object)1107298560);
		Debug.Log((object)collidersAndRoomMask);
		TimeOfDay.Instance.globalTime = 100f;
		IngamePlayerSettings.Instance.RefreshAndDisplayCurrentMicrophone();
		HUDManager.Instance.SetNearDepthOfFieldEnabled(enabled: true);
		((MonoBehaviour)this).StartCoroutine(StartSpatialVoiceChat());
		NetworkObject[] array = Object.FindObjectsOfType<NetworkObject>(true);
		for (int i = 0; i < array.Length; i++)
		{
			array[i].DontDestroyWithOwner = true;
		}
		if (((NetworkBehaviour)this).IsServer)
		{
			SetTimeAndPlanetToSavedSettings();
			LoadUnlockables();
			LoadShipGrabbableItems();
			LoadAttachedVehicle();
			SetMapScreenInfoToCurrentLevel();
			Object.FindObjectOfType<Terminal>().RotateShipDecorSelection();
			TimeOfDay timeOfDay = Object.FindObjectOfType<TimeOfDay>();
			if (currentLevel.planetHasTime && timeOfDay.GetDayPhase(timeOfDay.CalculatePlanetTime(currentLevel) / timeOfDay.totalTime) == DayMode.Midnight)
			{
				Object.FindObjectOfType<StartMatchLever>().triggerScript.disabledHoverTip = "Too late on moon to land!";
				Object.FindObjectOfType<StartMatchLever>().triggerScript.interactable = false;
			}
			else
			{
				Object.FindObjectOfType<StartMatchLever>().triggerScript.interactable = true;
			}
		}
		SwitchMapMonitorPurpose(displayInfo: true);
		DisableSpatializationOnAllAudio();
		SetDiscordStatusDetails();
	}

	private void DisableSpatializationOnAllAudio()
	{
		AudioSource[] array = Object.FindObjectsOfType<AudioSource>();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].spatialize = false;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void BuyShipUnlockableServerRpc(int unlockableID, int newGroupCreditsAmount)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3953483456u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, unlockableID);
			BytePacker.WriteValueBitPacked(val2, newGroupCreditsAmount);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3953483456u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			Debug.Log((object)$"Purchasing ship unlockable on host: {unlockableID}");
			if (unlockablesList.unlockables[unlockableID].hasBeenUnlockedByPlayer || newGroupCreditsAmount > Object.FindObjectOfType<Terminal>().groupCredits)
			{
				Debug.Log((object)"Unlockable was already unlocked! Setting group credits back to server's amount on all clients.");
				BuyShipUnlockableClientRpc(Object.FindObjectOfType<Terminal>().groupCredits);
			}
			else
			{
				Object.FindObjectOfType<Terminal>().groupCredits = newGroupCreditsAmount;
				BuyShipUnlockableClientRpc(newGroupCreditsAmount, unlockableID);
				UnlockShipObject(unlockableID);
			}
		}
	}

	[ClientRpc]
	public void BuyShipUnlockableClientRpc(int newGroupCreditsAmount, int unlockableID = -1)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(418581783u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, newGroupCreditsAmount);
			BytePacker.WriteValueBitPacked(val2, unlockableID);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 418581783u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)NetworkManager.Singleton == (Object)null) && !((NetworkBehaviour)this).NetworkManager.ShutdownInProgress && !((NetworkBehaviour)this).IsServer)
		{
			if (unlockableID != -1)
			{
				unlockablesList.unlockables[unlockableID].hasBeenUnlockedByPlayer = true;
			}
			Object.FindObjectOfType<Terminal>().groupCredits = newGroupCreditsAmount;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ReturnUnlockableFromStorageServerRpc(int unlockableID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3380566632u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, unlockableID);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3380566632u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost) || !unlockablesList.unlockables[unlockableID].inStorage)
		{
			return;
		}
		if (unlockablesList.unlockables[unlockableID].spawnPrefab)
		{
			if (SpawnedShipUnlockables.ContainsKey(unlockableID))
			{
				return;
			}
			PlaceableShipObject[] array = Object.FindObjectsOfType<PlaceableShipObject>();
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i].unlockableID == unlockableID)
				{
					return;
				}
			}
			SpawnUnlockable(unlockableID, useSavedPositionData: false);
		}
		else
		{
			PlaceableShipObject[] array2 = Object.FindObjectsOfType<PlaceableShipObject>();
			for (int j = 0; j < array2.Length; j++)
			{
				if (array2[j].unlockableID == unlockableID)
				{
					array2[j].parentObject.disableObject = false;
					break;
				}
			}
		}
		unlockablesList.unlockables[unlockableID].inStorage = false;
		ReturnUnlockableFromStorageClientRpc(unlockableID);
	}

	[ClientRpc]
	public void ReturnUnlockableFromStorageClientRpc(int unlockableID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1076853239u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, unlockableID);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1076853239u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || (Object)(object)NetworkManager.Singleton == (Object)null || ((NetworkBehaviour)this).NetworkManager.ShutdownInProgress || ((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		unlockablesList.unlockables[unlockableID].inStorage = false;
		PlaceableShipObject[] array = Object.FindObjectsOfType<PlaceableShipObject>();
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].unlockableID == unlockableID)
			{
				array[i].parentObject.disableObject = false;
			}
		}
	}

	private void UnlockShipObject(int unlockableID)
	{
		if (!unlockablesList.unlockables[unlockableID].hasBeenUnlockedByPlayer && !unlockablesList.unlockables[unlockableID].alreadyUnlocked)
		{
			Debug.Log((object)$"Set unlockable #{unlockableID}: {unlockablesList.unlockables[unlockableID].unlockableName}, to unlocked!");
			unlockablesList.unlockables[unlockableID].hasBeenUnlockedByPlayer = true;
			SpawnUnlockable(unlockableID);
		}
	}

	private void LoadAttachedVehicle()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		int num = ES3.Load<int>("AttachedVehicleID", GameNetworkManager.Instance.currentSaveFileName, -1);
		Debug.Log((object)$"Loaded vehicle ID: {num}");
		if (num != -1)
		{
			if (num > VehiclesList.Length)
			{
				Debug.LogError((object)$"Saved Vehicle ID of {num} was larger than the vehicles array length. you buffoon");
				return;
			}
			GameObject val = Object.Instantiate<GameObject>(VehiclesList[num], magnetPoint.position + magnetPoint.forward * 5f, Quaternion.identity, RoundManager.Instance.VehiclesContainer);
			attachedVehicle = val.GetComponent<VehicleController>();
			isObjectAttachedToMagnet = true;
			((NetworkBehaviour)attachedVehicle).NetworkObject.Spawn(false);
			magnetOn = true;
			magnetLever.initialBoolState = true;
			magnetLever.setInitialState = true;
			magnetLever.SetInitialState();
		}
	}

	private void LoadUnlockables()
	{
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			if (ES3.KeyExists("LuckyFurniture", GameNetworkManager.Instance.currentSaveFileName))
			{
				int[] array = ES3.Load<int[]>("LuckyFurniture", GameNetworkManager.Instance.currentSaveFileName);
				if (array != null && array.Length != 0)
				{
					TimeOfDay.Instance.furniturePlacedAtQuotaStart = array.ToList();
					TimeOfDay.Instance.CalculateLuckValue();
				}
			}
			if (ES3.KeyExists("UnlockedShipObjects", GameNetworkManager.Instance.currentSaveFileName))
			{
				int[] array2 = ES3.Load<int[]>("UnlockedShipObjects", GameNetworkManager.Instance.currentSaveFileName);
				for (int i = 0; i < array2.Length; i++)
				{
					if (unlockablesList.unlockables[array2[i]].alreadyUnlocked && !unlockablesList.unlockables[array2[i]].IsPlaceable)
					{
						continue;
					}
					UnlockableItem unlockableItem = unlockablesList.unlockables[array2[i]];
					if (!unlockableItem.alreadyUnlocked)
					{
						unlockableItem.hasBeenUnlockedByPlayer = true;
					}
					Debug.Log((object)("item name: " + unlockableItem.unlockableName));
					if (ES3.KeyExists("ShipUnlockStored_" + unlockableItem.unlockableName, GameNetworkManager.Instance.currentSaveFileName) && ES3.Load<bool>("ShipUnlockStored_" + unlockableItem.unlockableName, GameNetworkManager.Instance.currentSaveFileName, false))
					{
						Debug.Log((object)"Item unlock is stored");
						if (ES3.KeyExists("ShipUnlockMoved_" + unlockableItem.unlockableName, GameNetworkManager.Instance.currentSaveFileName))
						{
							Debug.Log((object)"Item was moved previously, has position/rotation data.");
							unlockableItem.placedPosition = ES3.Load<Vector3>("ShipUnlockPos_" + unlockableItem.unlockableName, GameNetworkManager.Instance.currentSaveFileName, Vector3.zero);
							unlockableItem.placedRotation = ES3.Load<Vector3>("ShipUnlockRot_" + unlockableItem.unlockableName, GameNetworkManager.Instance.currentSaveFileName, Vector3.zero);
							Debug.Log((object)$"Item {unlockableItem.unlockableName} pos: {unlockableItem.placedPosition}; {unlockableItem.placedRotation}; spawn prefab: {unlockableItem.spawnPrefab}");
							if (!unlockableItem.spawnPrefab)
							{
								Debug.Log((object)"Looking for corresponding object in scene");
								PlaceableShipObject[] array3 = Object.FindObjectsOfType<PlaceableShipObject>();
								for (int j = 0; j < array3.Length; j++)
								{
									if (array3[j].unlockableID == array2[i])
									{
										Debug.Log((object)"Placing stored object");
										ShipBuildModeManager.Instance.PlaceShipObject(unlockableItem.placedPosition, unlockableItem.placedRotation, array3[j], placementSFX: false);
									}
								}
							}
						}
						unlockableItem.inStorage = true;
					}
					else
					{
						SpawnUnlockable(array2[i]);
					}
				}
				PlaceableShipObject[] array4 = Object.FindObjectsOfType<PlaceableShipObject>();
				for (int k = 0; k < array4.Length; k++)
				{
					if (!unlockablesList.unlockables[array4[k].unlockableID].spawnPrefab && unlockablesList.unlockables[array4[k].unlockableID].inStorage)
					{
						array4[k].parentObject.disableObject = true;
						Debug.Log((object)"DISABLE OBJECT A");
					}
				}
			}
			for (int l = 0; l < unlockablesList.unlockables.Count; l++)
			{
				if ((l != 0 || !isChallengeFile) && (unlockablesList.unlockables[l].alreadyUnlocked || (unlockablesList.unlockables[l].unlockedInChallengeFile && isChallengeFile)) && !unlockablesList.unlockables[l].IsPlaceable)
				{
					SpawnUnlockable(l);
				}
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error attempting to load ship unlockables on the host: {arg}");
		}
	}

	private void SpawnUnlockable(int unlockableIndex, bool useSavedPositionData = true)
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = null;
		UnlockableItem unlockableItem = unlockablesList.unlockables[unlockableIndex];
		Debug.Log((object)$"unlockable index: {unlockableIndex}; {unlockablesList.unlockables[unlockableIndex].unlockableName}");
		switch (unlockableItem.unlockableType)
		{
		case 0:
		{
			val = Object.Instantiate<GameObject>(suitPrefab, rightmostSuitPosition.position + rightmostSuitPosition.forward * 0.18f * (float)suitsPlaced, rightmostSuitPosition.rotation, (Transform)null);
			val.GetComponent<UnlockableSuit>().syncedSuitID.Value = unlockableIndex;
			val.GetComponent<NetworkObject>().Spawn(false);
			AutoParentToShip component = val.gameObject.GetComponent<AutoParentToShip>();
			component.overrideOffset = true;
			component.positionOffset = new Vector3(-2.45f, 2.75f, -8.41f) + rightmostSuitPosition.forward * 0.18f * (float)suitsPlaced;
			component.rotationOffset = new Vector3(0f, 90f, 0f);
			SyncSuitsServerRpc();
			suitsPlaced++;
			break;
		}
		case 1:
			if (unlockableItem.spawnPrefab)
			{
				Debug.Log((object)("Instantiating prefab for item " + unlockableItem.unlockableName));
				val = Object.Instantiate<GameObject>(unlockableItem.prefabObject, elevatorTransform.position, Quaternion.identity, (Transform)null);
			}
			else
			{
				Debug.Log((object)("Placing scene object at saved position: " + unlockablesList.unlockables[unlockableIndex].unlockableName));
				PlaceableShipObject[] array = Object.FindObjectsOfType<PlaceableShipObject>();
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i].unlockableID == unlockableIndex)
					{
						val = ((Component)array[i].parentObject).gameObject;
					}
				}
				if ((Object)(object)val == (Object)null)
				{
					return;
				}
			}
			if (!useSavedPositionData && unlockablesList.unlockables[unlockableIndex].placedPosition != Vector3.zero && unlockablesList.unlockables[unlockableIndex].placedRotation != Vector3.zero)
			{
				Vector3 placedPosition = unlockablesList.unlockables[unlockableIndex].placedPosition;
				Vector3 placedRotation = unlockablesList.unlockables[unlockableIndex].placedRotation;
				Debug.Log((object)$"use saved position data false; pos: {placedPosition}; rot: {placedRotation}");
				ShipBuildModeManager.Instance.PlaceShipObject(placedPosition, placedRotation, val.GetComponentInChildren<PlaceableShipObject>(), placementSFX: false);
			}
			else if (ES3.KeyExists("ShipUnlockMoved_" + unlockableItem.unlockableName, GameNetworkManager.Instance.currentSaveFileName))
			{
				Vector3 placedPosition = ES3.Load<Vector3>("ShipUnlockPos_" + unlockableItem.unlockableName, GameNetworkManager.Instance.currentSaveFileName, Vector3.zero);
				Vector3 placedRotation = ES3.Load<Vector3>("ShipUnlockRot_" + unlockableItem.unlockableName, GameNetworkManager.Instance.currentSaveFileName, Vector3.zero);
				Debug.Log((object)$"Loading placed object position as: {placedPosition}");
				ShipBuildModeManager.Instance.PlaceShipObject(placedPosition, placedRotation, val.GetComponentInChildren<PlaceableShipObject>(), placementSFX: false);
			}
			if (!val.GetComponent<NetworkObject>().IsSpawned)
			{
				val.GetComponent<NetworkObject>().Spawn(false);
			}
			break;
		}
		if ((Object)(object)val != (Object)null)
		{
			SpawnedShipUnlockables.Add(unlockableIndex, val);
		}
	}

	[ServerRpc]
	public void SyncSuitsServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1846610026u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1846610026u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncSuitsClientRpc();
		}
	}

	[ClientRpc]
	public void SyncSuitsClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2369901769u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2369901769u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				PositionSuitsOnRack();
			}
		}
	}

	private void LoadShipGrabbableItems()
	{
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		if (!ES3.KeyExists("shipGrabbableItemIDs", GameNetworkManager.Instance.currentSaveFileName))
		{
			Debug.Log((object)"Key 'shipGrabbableItems' does not exist");
			return;
		}
		int[] array = ES3.Load<int[]>("shipGrabbableItemIDs", GameNetworkManager.Instance.currentSaveFileName);
		Vector3[] array2 = ES3.Load<Vector3[]>("shipGrabbableItemPos", GameNetworkManager.Instance.currentSaveFileName);
		if (array == null || array2 == null)
		{
			Debug.LogError((object)"Ship items list loaded from file returns a null value!");
			return;
		}
		Debug.Log((object)$"Ship grabbable items list loaded. Count: {array.Length}");
		bool flag = ES3.KeyExists("shipScrapValues", GameNetworkManager.Instance.currentSaveFileName);
		int[] array3 = null;
		if (flag)
		{
			array3 = ES3.Load<int[]>("shipScrapValues", GameNetworkManager.Instance.currentSaveFileName);
		}
		int[] array4 = null;
		bool flag2 = false;
		if (ES3.KeyExists("shipItemSaveData", GameNetworkManager.Instance.currentSaveFileName))
		{
			flag2 = true;
			array4 = ES3.Load<int[]>("shipItemSaveData", GameNetworkManager.Instance.currentSaveFileName);
		}
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < array.Length; i++)
		{
			if (allItemsList.itemsList.Count >= array[i])
			{
				Debug.Log((object)$"Item {allItemsList.itemsList[array[i]].itemName} #{i} spawn position: {array2[i]}");
				Bounds bounds = shipBounds.bounds;
				if (!((Bounds)(ref bounds)).Contains(array2[i]))
				{
					array2[i] = playerSpawnPositions[1].position;
					array2[i].x += Random.Range(-0.7f, 0.7f);
					array2[i].z += Random.Range(2f, 2f);
					array2[i].y += 0.5f;
					Debug.Log((object)$"Item was outside ship bounds; new position: {array2[i]}");
				}
				Debug.DrawRay(array2[i], Vector3.up * 0.5f, Color.magenta, 10f);
				GrabbableObject component = Object.Instantiate<GameObject>(allItemsList.itemsList[array[i]].spawnPrefab, array2[i], Quaternion.identity, elevatorTransform).GetComponent<GrabbableObject>();
				component.fallTime = 0f;
				component.scrapPersistedThroughRounds = true;
				component.isInElevator = true;
				component.isInShipRoom = true;
				if (flag && allItemsList.itemsList[array[i]].isScrap)
				{
					Debug.Log((object)$"Setting scrap value for item: {((Object)((Component)component).gameObject).name}: {array3[num]}");
					component.SetScrapValue(array3[num]);
					num++;
				}
				if (flag2 && component.itemProperties.saveItemVariable && num2 < array4.Length)
				{
					Debug.Log((object)$"Loading item save data for item: {((Component)component).gameObject}: {array4[num2]}");
					component.LoadItemSaveData(array4[num2]);
					num2++;
				}
				((NetworkBehaviour)component).NetworkObject.Spawn(false);
			}
		}
	}

	private void SetTimeAndPlanetToSavedSettings()
	{
		string currentSaveFileName = GameNetworkManager.Instance.currentSaveFileName;
		int levelID;
		if (currentSaveFileName == "LCChallengeFile")
		{
			Random random = new Random(GameNetworkManager.Instance.GetWeekNumber() + 2);
			randomMapSeed = random.Next(0, 100000000);
			hasSubmittedChallengeRank = ES3.Load<bool>("SubmittedScore", currentSaveFileName, false);
			isChallengeFile = true;
			UnlockableSuit.SwitchSuitForAllPlayers(24);
			SelectableLevel[] array = levels.Where((SelectableLevel x) => x.planetHasTime).ToArray();
			levelID = array[random.Next(0, array.Length)].levelID;
		}
		else
		{
			isChallengeFile = false;
			randomMapSeed = ES3.Load<int>("RandomSeed", currentSaveFileName, 0);
			levelID = ES3.Load<int>("CurrentPlanetID", currentSaveFileName, defaultPlanet);
		}
		ChangeLevel(levelID);
		ChangePlanet();
		if (isChallengeFile)
		{
			TimeOfDay.Instance.totalTime = TimeOfDay.Instance.lengthOfHours * (float)TimeOfDay.Instance.numberOfHours;
			TimeOfDay.Instance.timeUntilDeadline = TimeOfDay.Instance.totalTime;
			TimeOfDay.Instance.profitQuota = 200;
		}
		else
		{
			TimeOfDay.Instance.timesFulfilledQuota = ES3.Load<int>("QuotasPassed", currentSaveFileName, 0);
			TimeOfDay.Instance.profitQuota = ES3.Load<int>("ProfitQuota", currentSaveFileName, TimeOfDay.Instance.quotaVariables.startingQuota);
			TimeOfDay.Instance.totalTime = TimeOfDay.Instance.lengthOfHours * (float)TimeOfDay.Instance.numberOfHours;
			TimeOfDay.Instance.timeUntilDeadline = ES3.Load<int>("DeadlineTime", currentSaveFileName, (int)(TimeOfDay.Instance.totalTime * (float)TimeOfDay.Instance.quotaVariables.deadlineDaysAmount));
			TimeOfDay.Instance.quotaFulfilled = ES3.Load<int>("QuotaFulfilled", currentSaveFileName, 0);
			TimeOfDay.Instance.SetBuyingRateForDay();
			gameStats.daysSpent = ES3.Load<int>("Stats_DaysSpent", currentSaveFileName, 0);
			gameStats.deaths = ES3.Load<int>("Stats_Deaths", currentSaveFileName, 0);
			gameStats.scrapValueCollected = ES3.Load<int>("Stats_ValueCollected", currentSaveFileName, 0);
			gameStats.allStepsTaken = ES3.Load<int>("Stats_StepsTaken", currentSaveFileName, 0);
		}
		TimeOfDay.Instance.UpdateProfitQuotaCurrentTime();
		LoadPlanetsMoldSpreadData();
		SetPlanetsWeather();
		Object.FindObjectOfType<Terminal>().SetItemSales();
		if (gameStats.daysSpent == 0 && !isChallengeFile)
		{
			PlayFirstDayShipAnimation(waitForMenuToClose: true);
		}
		if (TimeOfDay.Instance.timeUntilDeadline > 0f && TimeOfDay.Instance.daysUntilDeadline <= 0 && TimeOfDay.Instance.timesFulfilledQuota <= 0)
		{
			((MonoBehaviour)this).StartCoroutine(playDaysLeftAlertSFXDelayed());
		}
	}

	private IEnumerator StartSpatialVoiceChat()
	{
		yield return (object)new WaitUntil((Func<bool>)(() => localClientHasControl && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null));
		for (int i = 0; i < allPlayerObjects.Length; i++)
		{
			if (Object.op_Implicit((Object)(object)allPlayerObjects[i].GetComponent<NfgoPlayer>()) && !allPlayerObjects[i].GetComponent<NfgoPlayer>().IsTracking)
			{
				allPlayerObjects[i].GetComponent<NfgoPlayer>().VoiceChatTrackingStart();
			}
		}
		float startTime = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => HUDManager.Instance.hasSetSavedValues || Time.realtimeSinceStartup - startTime > 5f));
		if (!HUDManager.Instance.hasSetSavedValues)
		{
			Debug.LogError((object)"Failure to set local player level! Skipping sync.");
		}
		else
		{
			HUDManager.Instance.SyncAllPlayerLevelsServerRpc(HUDManager.Instance.localPlayerLevel, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
		HUDManager.Instance.DisableLocalBadgeMesh();
		yield return (object)new WaitForSeconds(12f);
		UpdatePlayerVoiceEffects();
	}

	private IEnumerator UpdatePlayerVoiceEffectsOnDelay()
	{
		yield return (object)new WaitForSeconds(12f);
		UpdatePlayerVoiceEffects();
	}

	public void KickPlayer(int playerObjToKick)
	{
		if ((!allPlayerScripts[playerObjToKick].isPlayerControlled && !allPlayerScripts[playerObjToKick].isPlayerDead) || !((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (!GameNetworkManager.Instance.disableSteam)
		{
			ulong playerSteamId = Instance.allPlayerScripts[playerObjToKick].playerSteamId;
			if (!KickedClientIds.Contains(playerSteamId))
			{
				KickedClientIds.Add(playerSteamId);
			}
		}
		NetworkManager.Singleton.DisconnectClient(allPlayerScripts[playerObjToKick].actualClientId);
		HUDManager.Instance.AddTextToChatOnServer($"[playerNum{playerObjToKick}] was kicked.");
	}

	public void OnLocalDisconnect()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Expected O, but got Unknown
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Expected O, but got Unknown
		if (!GameNetworkManager.Instance.disableSteam)
		{
			SteamFriends.ClearRichPresence();
		}
		if ((Object)(object)NetworkManager.Singleton != (Object)null)
		{
			if (NetworkManager.Singleton.SceneManager != null)
			{
				NetworkManager.Singleton.SceneManager.OnLoadComplete -= new OnLoadCompleteDelegateHandler(SceneManager_OnLoadComplete1);
				NetworkManager.Singleton.SceneManager.OnLoad -= new OnLoadDelegateHandler(SceneManager_OnLoad);
			}
			else
			{
				Debug.Log((object)"Scene manager is null");
			}
		}
	}

	public void OnClientDisconnect(ulong clientId)
	{
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		if (ClientPlayerList == null || !ClientPlayerList.ContainsKey(clientId))
		{
			Debug.Log((object)"Disconnection callback called for a client id which isn't in ClientPlayerList; ignoring. This is likely due to an unapproved connection.");
			return;
		}
		if ((Object)(object)NetworkManager.Singleton == (Object)null || (Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			GameNetworkManager.Instance.disconnectReason = 1;
			GameNetworkManager.Instance.Disconnect();
			return;
		}
		if (clientId == NetworkManager.Singleton.LocalClientId || clientId == GameNetworkManager.Instance.localPlayerController.actualClientId)
		{
			Debug.Log((object)"Disconnect callback called for local client; ignoring.");
			return;
		}
		Debug.Log((object)"Client disconnected from server");
		if (!ClientPlayerList.TryGetValue(clientId, out var value))
		{
			Debug.LogError((object)"Could not get player object number from client id on disconnect!");
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			Debug.Log((object)$"player disconnected c; {clientId}");
			Debug.Log((object)ClientPlayerList.Count);
			for (int i = 0; i < ClientPlayerList.Count; i++)
			{
				ClientPlayerList.TryGetValue((ulong)i, out var value2);
				Debug.Log((object)$"client id: {i} ; player object id: {value2}");
			}
			Debug.Log((object)$"disconnecting client id: {clientId}");
			if (ClientPlayerList.TryGetValue(clientId, out var value3) && value3 == 0)
			{
				Debug.Log((object)"Host disconnected!");
				Debug.Log((object)GameNetworkManager.Instance.isDisconnecting);
				if (!GameNetworkManager.Instance.isDisconnecting)
				{
					Debug.Log((object)"Host quit! Ending game for client.");
					GameNetworkManager.Instance.disconnectReason = 1;
					GameNetworkManager.Instance.Disconnect();
					return;
				}
			}
			OnPlayerDC(value, clientId);
			return;
		}
		if (fullyLoadedPlayers.Contains(clientId))
		{
			fullyLoadedPlayers.Remove(clientId);
		}
		if (RoundManager.Instance.playersFinishedGeneratingFloor.Contains(clientId))
		{
			RoundManager.Instance.playersFinishedGeneratingFloor.Remove(clientId);
		}
		GrabbableObject[] array = Object.FindObjectsOfType<GrabbableObject>();
		for (int j = 0; j < array.Length; j++)
		{
			if (!array[j].isHeld)
			{
				array[j].heldByPlayerOnServer = false;
			}
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		List<ulong> list = new List<ulong>();
		foreach (KeyValuePair<ulong, int> clientPlayer in ClientPlayerList)
		{
			if (clientPlayer.Key != clientId)
			{
				list.Add(clientPlayer.Key);
			}
		}
		ClientRpcParams val = default(ClientRpcParams);
		val.Send = new ClientRpcSendParams
		{
			TargetClientIds = list.ToArray()
		};
		ClientRpcParams clientRpcParams = val;
		OnPlayerDC(value, clientId);
		OnClientDisconnectClientRpc(value, clientId, clientRpcParams);
	}

	[ClientRpc]
	public void OnClientDisconnectClientRpc(int playerObjectNumber, ulong clientId, ClientRpcParams clientRpcParams = default(ClientRpcParams))
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				FastBufferWriter val = ((NetworkBehaviour)this).__beginSendClientRpc(475465488u, clientRpcParams, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val, playerObjectNumber);
				BytePacker.WriteValueBitPacked(val, clientId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val, 475465488u, clientRpcParams, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				OnPlayerDC(playerObjectNumber, clientId);
			}
		}
	}

	public void OnPlayerDC(int playerObjectNumber, ulong clientId)
	{
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)"Calling OnPlayerDC!");
		if (!ClientPlayerList.ContainsKey(clientId))
		{
			Debug.Log((object)"disconnect: clientId key already removed!");
			return;
		}
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null && clientId == GameNetworkManager.Instance.localPlayerController.actualClientId)
		{
			Debug.Log((object)"OnPlayerDC: Local client is disconnecting so return.");
			return;
		}
		if (((NetworkBehaviour)this).NetworkManager.ShutdownInProgress || (Object)(object)NetworkManager.Singleton == (Object)null)
		{
			Debug.Log((object)"Shutdown is in progress, returning");
			return;
		}
		Debug.Log((object)"Player DC'ing 2");
		if (((NetworkBehaviour)this).IsServer && ClientPlayerList.TryGetValue(clientId, out var value))
		{
			HUDManager.Instance.AddTextToChatOnServer($"[playerNum{allPlayerScripts[value].playerClientId}] disconnected.");
		}
		if (!allPlayerScripts[playerObjectNumber].isPlayerDead)
		{
			livingPlayers--;
		}
		ClientPlayerList.Remove(clientId);
		connectedPlayersAmount--;
		Debug.Log((object)"Player DC'ing 3");
		PlayerControllerB component = allPlayerObjects[playerObjectNumber].GetComponent<PlayerControllerB>();
		try
		{
			component.sentPlayerValues = false;
			component.isPlayerControlled = false;
			component.isPlayerDead = false;
			if (!inShipPhase)
			{
				component.disconnectedMidGame = true;
				if (livingPlayers == 0)
				{
					allPlayersDead = true;
					ShipLeaveAutomatically();
				}
			}
			component.DropAllHeldItems(itemsFall: true, disconnecting: true);
			Debug.Log((object)"Teleporting disconnected player out");
			component.TeleportPlayer(notSpawnedPosition.position);
			UnlockableSuit.SwitchSuitForPlayer(component, 0, playAudio: false);
			if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
			{
				HUDManager.Instance.UpdateBoxesSpectateUI();
			}
			if (!NetworkManager.Singleton.ShutdownInProgress && ((NetworkBehaviour)this).IsServer)
			{
				((Component)component).gameObject.GetComponent<NetworkObject>().RemoveOwnership();
			}
			QuickMenuManager quickMenuManager = Object.FindObjectOfType<QuickMenuManager>();
			if ((Object)(object)quickMenuManager != (Object)null)
			{
				quickMenuManager.RemoveUserFromPlayerList(playerObjectNumber);
			}
			Debug.Log((object)$"Current players after dc: {connectedPlayersAmount}");
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while handling player disconnect!: {arg}");
		}
	}

	public void OnClientConnect(ulong clientId)
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		Debug.Log((object)"player connected");
		Debug.Log((object)$"connected players #: {connectedPlayersAmount}");
		try
		{
			List<int> list = ClientPlayerList.Values.ToList();
			Debug.Log((object)$"Connecting new player on host; clientId: {clientId}");
			int num = 0;
			for (int i = 1; i < 4; i++)
			{
				if (!list.Contains(i))
				{
					num = i;
					break;
				}
			}
			allPlayerScripts[num].actualClientId = clientId;
			allPlayerObjects[num].GetComponent<NetworkObject>().ChangeOwnership(clientId);
			Debug.Log((object)$"New player assigned object id: {allPlayerObjects[num]}");
			List<ulong> list2 = new List<ulong>();
			for (int j = 0; j < allPlayerObjects.Length; j++)
			{
				NetworkObject component = allPlayerObjects[j].GetComponent<NetworkObject>();
				if (!component.IsOwnedByServer)
				{
					list2.Add(component.OwnerClientId);
				}
				else if (j == 0)
				{
					list2.Add(NetworkManager.Singleton.LocalClientId);
				}
				else
				{
					list2.Add(999uL);
				}
			}
			int groupCredits = Object.FindObjectOfType<Terminal>().groupCredits;
			int profitQuota = TimeOfDay.Instance.profitQuota;
			int quotaFulfilled = TimeOfDay.Instance.quotaFulfilled;
			int timeUntilDeadline = (int)TimeOfDay.Instance.timeUntilDeadline;
			OnPlayerConnectedClientRpc(clientId, connectedPlayersAmount, list2.ToArray(), num, groupCredits, currentLevelID, profitQuota, timeUntilDeadline, quotaFulfilled, randomMapSeed, isChallengeFile);
			ClientPlayerList.Add(clientId, num);
			Debug.Log((object)$"client id connecting: {clientId} ; their corresponding player object id: {num}");
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error occured in OnClientConnected! Shutting server down. clientId: {clientId}. Error: {arg}");
			GameNetworkManager.Instance.disconnectionReasonMessage = "Error occured when a player attempted to join the server! Restart the application and please report the glitch!";
			GameNetworkManager.Instance.Disconnect();
		}
	}

	[ClientRpc]
	private void OnPlayerConnectedClientRpc(ulong clientId, int connectedPlayers, ulong[] connectedPlayerIdsOrdered, int assignedPlayerObjectId, int serverMoneyAmount, int levelID, int profitQuota, int timeUntilDeadline, int quotaFulfilled, int randomSeed, bool isChallenge)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0377: Unknown result type (might be due to invalid IL or missing references)
		//IL_037c: Unknown result type (might be due to invalid IL or missing references)
		//IL_037e: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(886676601u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, clientId);
			BytePacker.WriteValueBitPacked(val2, connectedPlayers);
			bool flag = connectedPlayerIdsOrdered != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<ulong>(connectedPlayerIdsOrdered, default(ForPrimitives));
			}
			BytePacker.WriteValueBitPacked(val2, assignedPlayerObjectId);
			BytePacker.WriteValueBitPacked(val2, serverMoneyAmount);
			BytePacker.WriteValueBitPacked(val2, levelID);
			BytePacker.WriteValueBitPacked(val2, profitQuota);
			BytePacker.WriteValueBitPacked(val2, timeUntilDeadline);
			BytePacker.WriteValueBitPacked(val2, quotaFulfilled);
			BytePacker.WriteValueBitPacked(val2, randomSeed);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isChallenge, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 886676601u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			Debug.Log((object)$"NEW CLIENT JOINED THE SERVER!!; clientId: {clientId}");
			if ((Object)(object)NetworkManager.Singleton == (Object)null)
			{
				return;
			}
			if (clientId == NetworkManager.Singleton.LocalClientId && GameNetworkManager.Instance.localClientWaitingForApproval)
			{
				GameNetworkManager.Instance.localClientWaitingForApproval = false;
			}
			if (!((NetworkBehaviour)this).IsServer)
			{
				ClientPlayerList.Clear();
				for (int i = 0; i < connectedPlayerIdsOrdered.Length; i++)
				{
					if (connectedPlayerIdsOrdered[i] == 999)
					{
						Debug.Log((object)$"Skipping at index {i}");
						continue;
					}
					ClientPlayerList.Add(connectedPlayerIdsOrdered[i], i);
					Debug.Log((object)$"adding value to ClientPlayerList at value of index {i}: {connectedPlayerIdsOrdered[i]}");
				}
				if (!ClientPlayerList.ContainsKey(clientId))
				{
					Debug.Log((object)$"Successfully added new client id {clientId} and connected to object {assignedPlayerObjectId}");
					ClientPlayerList.Add(clientId, assignedPlayerObjectId);
				}
				else
				{
					Debug.Log((object)"ClientId already in ClientPlayerList!");
				}
				Debug.Log((object)$"clientplayerlist count for client: {ClientPlayerList.Count}");
				Terminal terminal = Object.FindObjectOfType<Terminal>();
				terminal.groupCredits = serverMoneyAmount;
				TimeOfDay timeOfDay = Object.FindObjectOfType<TimeOfDay>();
				timeOfDay.globalTime = 100f;
				ChangeLevel(levelID);
				ChangePlanet();
				isChallengeFile = isChallenge;
				randomMapSeed = randomSeed;
				terminal.RotateShipDecorSelection();
				SetPlanetsWeather();
				Object.FindObjectOfType<Terminal>().SetItemSales();
				SetMapScreenInfoToCurrentLevel();
				TimeOfDay.Instance.profitQuota = profitQuota;
				TimeOfDay.Instance.timeUntilDeadline = timeUntilDeadline;
				timeOfDay.SetBuyingRateForDay();
				TimeOfDay.Instance.quotaFulfilled = quotaFulfilled;
				TimeOfDay.Instance.UpdateProfitQuotaCurrentTime();
			}
			connectedPlayersAmount = connectedPlayers + 1;
			Debug.Log((object)("New player: " + ((Object)allPlayerObjects[assignedPlayerObjectId]).name));
			PlayerControllerB playerControllerB = allPlayerScripts[assignedPlayerObjectId];
			Vector3 val3 = (playerControllerB.serverPlayerPosition = GetPlayerSpawnPosition(assignedPlayerObjectId));
			playerControllerB.actualClientId = clientId;
			playerControllerB.isInElevator = true;
			playerControllerB.isInHangarShipRoom = true;
			playerControllerB.parentedToElevatorLastFrame = false;
			allPlayerScripts[assignedPlayerObjectId].TeleportPlayer(val3);
			((MonoBehaviour)this).StartCoroutine(setPlayerToSpawnPosition(allPlayerObjects[assignedPlayerObjectId].transform, val3));
			for (int j = 0; j < connectedPlayersAmount + 1; j++)
			{
				if (j == 0 || !((NetworkBehaviour)allPlayerScripts[j]).IsOwnedByServer)
				{
					allPlayerScripts[j].isPlayerControlled = true;
				}
			}
			playerControllerB.isPlayerControlled = true;
			livingPlayers = connectedPlayersAmount + 1;
			Debug.Log((object)$"Connected players (joined clients) amount after connection: {connectedPlayersAmount}");
			if (NetworkManager.Singleton.LocalClientId == clientId)
			{
				Debug.Log((object)$"Asking server to sync already-held objects. Our client id: {NetworkManager.Singleton.LocalClientId}");
				mostRecentlyJoinedClient = true;
				if (isChallengeFile)
				{
					UnlockableSuit.SwitchSuitForAllPlayers(24);
				}
				HUDManager.Instance.SetSavedValues(assignedPlayerObjectId);
				SyncAlreadyHeldObjectsServerRpc((int)NetworkManager.Singleton.LocalClientId);
			}
			else
			{
				Debug.Log((object)$"This client is not the client who just joined. Our client id: {NetworkManager.Singleton.LocalClientId}; joining client id: {clientId}");
				mostRecentlyJoinedClient = false;
				if (updateVoiceEffectsCoroutine != null)
				{
					((MonoBehaviour)this).StopCoroutine(updateVoiceEffectsCoroutine);
				}
				updateVoiceEffectsCoroutine = ((MonoBehaviour)this).StartCoroutine(UpdatePlayerVoiceEffectsOnDelay());
				if (!((Component)playerControllerB).gameObject.GetComponentInChildren<NfgoPlayer>().IsTracking)
				{
					((Component)playerControllerB).gameObject.GetComponentInChildren<NfgoPlayer>().VoiceChatTrackingStart();
				}
			}
			if (GameNetworkManager.Instance.disableSteam)
			{
				QuickMenuManager quickMenuManager = Object.FindObjectOfType<QuickMenuManager>();
				for (int k = 0; k < allPlayerScripts.Length; k++)
				{
					if (allPlayerScripts[k].isPlayerControlled || allPlayerScripts[k].isPlayerDead)
					{
						quickMenuManager.AddUserToPlayerList(0uL, allPlayerScripts[k].playerUsername, (int)allPlayerScripts[k].playerClientId);
					}
				}
			}
			SetDiscordStatusDetails();
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Failed to assign new player with client id #{clientId}: {arg}");
			GameNetworkManager.Instance.disconnectionReasonMessage = "An error occured while spawning into the game. Please report the glitch!";
			GameNetworkManager.Instance.Disconnect();
		}
	}

	private Vector3 GetPlayerSpawnPosition(int playerNum, bool simpleTeleport = false)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		if (simpleTeleport)
		{
			return playerSpawnPositions[0].position;
		}
		Debug.DrawRay(playerSpawnPositions[playerNum].position, Vector3.up, Color.red, 15f);
		if (!Physics.CheckSphere(playerSpawnPositions[playerNum].position, 0.2f, 67108864, (QueryTriggerInteraction)1))
		{
			return playerSpawnPositions[playerNum].position;
		}
		if (!Physics.CheckSphere(playerSpawnPositions[playerNum].position + Vector3.up, 0.2f, 67108864, (QueryTriggerInteraction)1))
		{
			return playerSpawnPositions[playerNum].position + Vector3.up * 0.5f;
		}
		for (int i = 0; i < playerSpawnPositions.Length; i++)
		{
			if (i != playerNum)
			{
				Debug.DrawRay(playerSpawnPositions[i].position, Vector3.up, Color.green, 15f);
				if (!Physics.CheckSphere(playerSpawnPositions[i].position, 0.12f, -67108865, (QueryTriggerInteraction)1))
				{
					return playerSpawnPositions[i].position;
				}
				if (!Physics.CheckSphere(playerSpawnPositions[i].position + Vector3.up, 0.12f, 67108864, (QueryTriggerInteraction)1))
				{
					return playerSpawnPositions[i].position + Vector3.up * 0.5f;
				}
			}
		}
		Random random = new Random(65);
		float y = playerSpawnPositions[0].position.y;
		Vector3 val = default(Vector3);
		for (int j = 0; j < 15; j++)
		{
			Bounds bounds = shipInnerRoomBounds.bounds;
			int minValue = (int)((Bounds)(ref bounds)).min.x;
			bounds = shipInnerRoomBounds.bounds;
			float num = random.Next(minValue, (int)((Bounds)(ref bounds)).max.x);
			bounds = shipInnerRoomBounds.bounds;
			int minValue2 = (int)((Bounds)(ref bounds)).min.z;
			bounds = shipInnerRoomBounds.bounds;
			((Vector3)(ref val))._002Ector(num, y, (float)random.Next(minValue2, (int)((Bounds)(ref bounds)).max.z));
			val = ((Component)shipInnerRoomBounds).transform.InverseTransformPoint(val);
			Debug.DrawRay(val, Vector3.up, Color.yellow, 15f);
			if (!Physics.CheckSphere(val, 0.12f, 67108864, (QueryTriggerInteraction)1))
			{
				return playerSpawnPositions[j].position;
			}
		}
		return playerSpawnPositions[0].position + Vector3.up * 0.5f;
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncAlreadyHeldObjectsServerRpc(int joiningClientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(682230258u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, joiningClientId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 682230258u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		Debug.Log((object)"Syncing already-held objects on server");
		try
		{
			GrabbableObject[] array = Object.FindObjectsByType<GrabbableObject>((FindObjectsInactive)0, (FindObjectsSortMode)0);
			List<NetworkObjectReference> list = new List<NetworkObjectReference>();
			List<int> list2 = new List<int>();
			List<int> list3 = new List<int>();
			List<int> list4 = new List<int>();
			for (int i = 0; i < array.Length; i++)
			{
				if (!array[i].isHeld)
				{
					continue;
				}
				list2.Add((int)array[i].playerHeldBy.playerClientId);
				list.Add(NetworkObjectReference.op_Implicit(((NetworkBehaviour)array[i]).NetworkObject));
				Debug.Log((object)$"Object #{i} is held");
				for (int j = 0; j < array[i].playerHeldBy.ItemSlots.Length; j++)
				{
					if ((Object)(object)array[i].playerHeldBy.ItemSlots[j] == (Object)(object)array[i])
					{
						list3.Add(j);
						Debug.Log((object)$"Item slot index for item #{i}: {j}");
					}
				}
				if (array[i].isPocketed)
				{
					list4.Add(list.Count - 1);
					Debug.Log((object)$"Object #{i} is pocketed");
				}
			}
			Debug.Log((object)$"pocketed objects count: {list4.Count}");
			Debug.Log((object)$"held objects count: {list.Count}");
			List<int> list5 = new List<int>();
			for (int k = 0; k < array.Length; k++)
			{
				if (array[k].itemProperties.isScrap)
				{
					list5.Add(array[k].scrapValue);
				}
			}
			if (list.Count > 0)
			{
				SyncAlreadyHeldObjectsClientRpc(list.ToArray(), list2.ToArray(), list3.ToArray(), list4.ToArray(), joiningClientId);
			}
			else
			{
				SyncShipUnlockablesServerRpc();
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while syncing players' already held objects in server! Skipping. Error: {arg}");
			SyncShipUnlockablesServerRpc();
		}
	}

	[ClientRpc]
	public void SyncAlreadyHeldObjectsClientRpc(NetworkObjectReference[] gObjects, int[] playersHeldBy, int[] itemSlotNumbers, int[] isObjectPocketed, int syncWithClient)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1613265729u, val, (RpcDelivery)0);
			bool flag = gObjects != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(gObjects, default(ForNetworkSerializable));
			}
			bool flag2 = playersHeldBy != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag2, default(ForPrimitives));
			if (flag2)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(playersHeldBy, default(ForPrimitives));
			}
			bool flag3 = itemSlotNumbers != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag3, default(ForPrimitives));
			if (flag3)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(itemSlotNumbers, default(ForPrimitives));
			}
			bool flag4 = isObjectPocketed != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag4, default(ForPrimitives));
			if (flag4)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(isObjectPocketed, default(ForPrimitives));
			}
			BytePacker.WriteValueBitPacked(val2, syncWithClient);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1613265729u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || syncWithClient != (int)NetworkManager.Singleton.LocalClientId)
		{
			return;
		}
		Debug.Log((object)"Syncing already-held objects on client");
		Debug.Log((object)$"held objects count: {gObjects.Length}");
		Debug.Log((object)$"pocketed objects count: {isObjectPocketed.Length}");
		try
		{
			NetworkObject val3 = default(NetworkObject);
			for (int i = 0; i < gObjects.Length; i++)
			{
				if (((NetworkObjectReference)(ref gObjects[i])).TryGet(ref val3, (NetworkManager)null))
				{
					GrabbableObject component = ((Component)val3).gameObject.GetComponent<GrabbableObject>();
					component.isHeld = true;
					allPlayerScripts[playersHeldBy[i]].ItemSlots[itemSlotNumbers[i]] = component;
					component.parentObject = allPlayerScripts[playersHeldBy[i]].serverItemHolder;
					bool flag5 = false;
					Debug.Log((object)$"isObjectPocketed length: {isObjectPocketed.Length}");
					Debug.Log((object)$"iii {i}");
					for (int j = 0; j < isObjectPocketed.Length; j++)
					{
						Debug.Log((object)$"bbb {j} ; {isObjectPocketed[j]}");
						if (isObjectPocketed[j] == i)
						{
							Debug.Log((object)("Pocketing object for player: " + ((Object)((Component)allPlayerScripts[playersHeldBy[i]]).gameObject).name));
							component.isPocketed = true;
							component.EnableItemMeshes(enable: false);
							component.EnablePhysics(enable: false);
							flag5 = true;
							break;
						}
					}
					if (!flag5)
					{
						allPlayerScripts[playersHeldBy[i]].currentlyHeldObjectServer = component;
						allPlayerScripts[playersHeldBy[i]].isHoldingObject = true;
						allPlayerScripts[playersHeldBy[i]].twoHanded = component.itemProperties.twoHanded;
						allPlayerScripts[playersHeldBy[i]].twoHandedAnimation = component.itemProperties.twoHandedAnimation;
						allPlayerScripts[playersHeldBy[i]].currentItemSlot = itemSlotNumbers[i];
					}
				}
				else
				{
					Debug.LogError((object)$"Syncing already held objects: Unable to get network object from reference for GObject; net object id: {((NetworkObjectReference)(ref gObjects[i])).NetworkObjectId}");
				}
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while syncing players' already held objects to client from server: {arg}");
		}
		SyncShipUnlockablesServerRpc();
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncShipUnlockablesServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(744998938u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 744998938u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			int[] array = new int[4];
			for (int i = 0; i < 4; i++)
			{
				array[i] = allPlayerScripts[i].currentSuitID;
			}
			bool[] array2 = new bool[unlockablesList.unlockables.Count];
			List<Vector3> list = new List<Vector3>();
			List<Vector3> list2 = new List<Vector3>();
			List<int> list3 = new List<int>();
			for (int j = 0; j < unlockablesList.unlockables.Count; j++)
			{
				if (unlockablesList.unlockables[j].hasBeenUnlockedByPlayer)
				{
					array2[j] = true;
				}
				else
				{
					array2[j] = false;
				}
				list.Add(unlockablesList.unlockables[j].placedPosition);
				list2.Add(unlockablesList.unlockables[j].placedRotation);
				if (unlockablesList.unlockables[j].unlockableType != 0 && (unlockablesList.unlockables[j].hasBeenUnlockedByPlayer || unlockablesList.unlockables[j].alreadyUnlocked) && unlockablesList.unlockables[j].inStorage)
				{
					Debug.Log((object)("Server: '" + unlockablesList.unlockables[j].unlockableName + "' is in storage"));
					list3.Add(j);
				}
			}
			GrabbableObject[] array3 = (from x in Object.FindObjectsByType<GrabbableObject>((FindObjectsInactive)0, (FindObjectsSortMode)0)
				orderby Vector3.Distance(((Component)x).transform.position, Vector3.zero)
				select x).ToArray();
			List<int> list4 = new List<int>();
			List<int> list5 = new List<int>();
			for (int k = 0; k < array3.Length; k++)
			{
				if (k > 500)
				{
					Debug.Log((object)"Attempted to sync more than 500 scrap values which is not allowed");
					break;
				}
				if (array3[k].itemProperties.saveItemVariable)
				{
					list5.Add(array3[k].GetItemDataToSave());
				}
				if (array3[k].itemProperties.isScrap)
				{
					list4.Add(array3[k].scrapValue);
				}
			}
			int vehicleID = -1;
			if ((Object)(object)attachedVehicle != (Object)null)
			{
				vehicleID = attachedVehicle.vehicleID;
			}
			for (int l = 0; l < allPlayerScripts.Length; l++)
			{
				UnlockableSuit.SwitchSuitForPlayer(allPlayerScripts[l], array[l], playAudio: false);
			}
			SyncShipUnlockablesClientRpc(array, shipRoomLights.areLightsOn, list.ToArray(), list2.ToArray(), array2, list3.ToArray(), list4.ToArray(), list5.ToArray(), vehicleID);
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while syncing unlockables in server. Quitting server: {arg}");
			GameNetworkManager.Instance.disconnectionReasonMessage = "An error occured while syncing ship objects! The file may be corrupted. Please report the glitch!";
			GameNetworkManager.Instance.Disconnect();
		}
	}

	private void PositionSuitsOnRack()
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		UnlockableSuit[] array = Object.FindObjectsOfType<UnlockableSuit>();
		Debug.Log((object)$"Suits: {array.Length}");
		for (int i = 0; i < array.Length; i++)
		{
			Debug.Log((object)$"Suit #{i}: {array[i].suitID}");
			AutoParentToShip component = ((Component)array[i]).gameObject.GetComponent<AutoParentToShip>();
			component.overrideOffset = true;
			component.positionOffset = new Vector3(-2.45f, 2.75f, -8.41f) + rightmostSuitPosition.forward * 0.18f * (float)i;
			component.rotationOffset = new Vector3(0f, 90f, 0f);
			Debug.Log((object)$"pos: {component.positionOffset}; rot: {component.rotationOffset}");
		}
		Object.FindObjectsOfType<UnlockableSuit>(true);
	}

	[ClientRpc]
	public void SyncShipUnlockablesClientRpc(int[] playerSuitIDs, bool shipLightsOn, Vector3[] placeableObjectPositions, Vector3[] placeableObjectRotations, bool[] unlockedObjects, int[] storedItems, int[] scrapValues, int[] itemSaveData, int vehicleID = -1)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_046c: Unknown result type (might be due to invalid IL or missing references)
		//IL_047a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_04de: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0503: Unknown result type (might be due to invalid IL or missing references)
		//IL_0694: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_057f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0590: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(765506029u, val, (RpcDelivery)0);
			bool flag = playerSuitIDs != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(playerSuitIDs, default(ForPrimitives));
			}
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref shipLightsOn, default(ForPrimitives));
			bool flag2 = placeableObjectPositions != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag2, default(ForPrimitives));
			if (flag2)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(placeableObjectPositions);
			}
			bool flag3 = placeableObjectRotations != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag3, default(ForPrimitives));
			if (flag3)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(placeableObjectRotations);
			}
			bool flag4 = unlockedObjects != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag4, default(ForPrimitives));
			if (flag4)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(unlockedObjects, default(ForPrimitives));
			}
			bool flag5 = storedItems != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag5, default(ForPrimitives));
			if (flag5)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(storedItems, default(ForPrimitives));
			}
			bool flag6 = scrapValues != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag6, default(ForPrimitives));
			if (flag6)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(scrapValues, default(ForPrimitives));
			}
			bool flag7 = itemSaveData != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag7, default(ForPrimitives));
			if (flag7)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(itemSaveData, default(ForPrimitives));
			}
			BytePacker.WriteValueBitPacked(val2, vehicleID);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 765506029u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			GrabbableObject[] array = (from x in Object.FindObjectsByType<GrabbableObject>((FindObjectsInactive)0, (FindObjectsSortMode)0)
				orderby Vector3.Distance(((Component)x).transform.position, Vector3.zero)
				select x).ToArray();
			try
			{
				int num = 0;
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i].itemProperties.saveItemVariable)
					{
						array[i].LoadItemSaveData(itemSaveData[num]);
						num++;
					}
				}
			}
			catch (Exception arg)
			{
				Debug.Log((object)$"Error while attempting to sync item save data from host: {arg}");
			}
			try
			{
				int num2 = 0;
				for (int j = 0; j < array.Length; j++)
				{
					if (array[j].itemProperties.isScrap)
					{
						if (num2 >= scrapValues.Length)
						{
							break;
						}
						array[j].SetScrapValue(scrapValues[num2]);
						num2++;
					}
				}
				for (int k = 0; k < array.Length; k++)
				{
					if ((Object)(object)((Component)array[k]).transform.parent == (Object)null)
					{
						Vector3 position = ((Component)array[k]).transform.position;
						((Component)array[k]).transform.parent = elevatorTransform;
						array[k].targetFloorPosition = elevatorTransform.InverseTransformPoint(position);
					}
				}
			}
			catch (Exception arg2)
			{
				Debug.LogError((object)$"Error while syncing scrap objects to this client from server: {arg2}");
			}
			try
			{
				for (int l = 0; l < allPlayerScripts.Length; l++)
				{
					UnlockableSuit.SwitchSuitForPlayer(allPlayerScripts[l], playerSuitIDs[l], playAudio: false);
				}
				PositionSuitsOnRack();
				bool flag8 = false;
				PlaceableShipObject[] array2 = Object.FindObjectsByType<PlaceableShipObject>((FindObjectsSortMode)0);
				Debug.Log((object)"syncing unlockables...");
				for (int m = 0; m < unlockablesList.unlockables.Count; m++)
				{
					Debug.Log((object)$"Index: {m} position: {placeableObjectPositions[m]}; {placeableObjectRotations[m]}");
					if (unlockedObjects[m])
					{
						unlockablesList.unlockables[m].hasBeenUnlockedByPlayer = true;
					}
					if (unlockablesList.unlockables[m].unlockableType == 0)
					{
						continue;
					}
					unlockablesList.unlockables[m].placedPosition = placeableObjectPositions[m];
					unlockablesList.unlockables[m].placedRotation = placeableObjectRotations[m];
					if (storedItems.Contains(m))
					{
						unlockablesList.unlockables[m].inStorage = true;
					}
					for (int n = 0; n < array2.Length; n++)
					{
						if (array2[n].unlockableID == m)
						{
							Debug.Log((object)$"Found existing object {n} with unlockable id {m}: {((Object)((Component)array2[n].parentObject).gameObject).name}. Synced position: {placeableObjectPositions[m]} with rotation {placeableObjectRotations[m]}.");
							if (unlockablesList.unlockables[m].placedPosition != Vector3.zero)
							{
								ShipBuildModeManager.Instance.PlaceShipObject(placeableObjectPositions[m], placeableObjectRotations[m], array2[n], placementSFX: false);
							}
							if (unlockablesList.unlockables[m].inStorage && !unlockablesList.unlockables[m].spawnPrefab)
							{
								array2[n].parentObject.disableObject = true;
							}
							break;
						}
					}
				}
				if (mostRecentlyJoinedClient && flag8 && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
				{
					GameNetworkManager.Instance.localPlayerController.TeleportPlayer(GetPlayerSpawnPosition((int)GameNetworkManager.Instance.localPlayerController.playerClientId));
				}
			}
			catch (Exception arg3)
			{
				Debug.LogError((object)$"Error while syncing unlockables in ship to this client from server: {arg3}");
			}
			try
			{
				if (vehicleID != -1)
				{
					isObjectAttachedToMagnet = true;
					magnetOn = true;
					magnetLever.initialBoolState = true;
					magnetLever.setInitialState = true;
					magnetLever.SetInitialState();
					VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
					if (vehicleController.vehicleID == vehicleID)
					{
						attachedVehicle = vehicleController;
						attachedVehicle.magnetedToShip = true;
						attachedVehicle.StartMagneting();
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogError((object)ex);
			}
		}
		try
		{
			for (int num3 = 0; num3 < 4; num3++)
			{
				if (!allPlayerScripts[num3].isPlayerControlled && !allPlayerScripts[num3].isPlayerDead)
				{
					return;
				}
				allPlayerScripts[num3].currentSuitID = playerSuitIDs[num3];
				Material suitMaterial = unlockablesList.unlockables[playerSuitIDs[num3]].suitMaterial;
				((Renderer)allPlayerScripts[num3].thisPlayerModel).sharedMaterial = suitMaterial;
				((Renderer)allPlayerScripts[num3].thisPlayerModelLOD1).sharedMaterial = suitMaterial;
				((Renderer)allPlayerScripts[num3].thisPlayerModelLOD2).sharedMaterial = suitMaterial;
				((Renderer)allPlayerScripts[num3].thisPlayerModelArms).sharedMaterial = suitMaterial;
			}
		}
		catch (Exception arg4)
		{
			Debug.LogError((object)$"Error while syncing player suit materials from server to client: {arg4}");
		}
		HUDManager.Instance.SyncAllPlayerLevelsServerRpc();
		shipRoomLights.SetShipLightsOnLocalClientOnly(shipLightsOn);
		if ((Object)(object)Object.FindObjectOfType<TVScript>() != (Object)null)
		{
			Object.FindObjectOfType<TVScript>().SyncTVServerRpc();
		}
	}

	public void StartTrackingAllPlayerVoices()
	{
		for (int i = 0; i < allPlayerScripts.Length; i++)
		{
			if ((allPlayerScripts[i].isPlayerControlled || Instance.allPlayerScripts[i].isPlayerDead) && !((Component)allPlayerScripts[i]).gameObject.GetComponentInChildren<NfgoPlayer>().IsTracking)
			{
				Debug.Log((object)("Starting voice tracking for player: " + allPlayerScripts[i].playerUsername));
				((Component)allPlayerScripts[i]).gameObject.GetComponentInChildren<NfgoPlayer>().VoiceChatTrackingStart();
			}
		}
	}

	private IEnumerator setPlayerToSpawnPosition(Transform playerBody, Vector3 spawnPos)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < 50; i++)
		{
			yield return null;
			yield return null;
			playerBody.position = spawnPos;
			if (Vector3.Distance(playerBody.position, spawnPos) < 6f)
			{
				break;
			}
		}
	}

	private void Update()
	{
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)GameNetworkManager.Instance == (Object)null)
		{
			return;
		}
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
		{
			PlayerControllerB spectatedPlayerScript = GameNetworkManager.Instance.localPlayerController;
			if (spectatedPlayerScript.isPlayerDead && (Object)(object)spectatedPlayerScript.spectatedPlayerScript != (Object)null)
			{
				spectatedPlayerScript = spectatedPlayerScript.spectatedPlayerScript;
			}
			if (spectatedPlayerScript.isInsideFactory)
			{
				blackSkyVolume.weight = 1f;
			}
			else
			{
				blackSkyVolume.weight = 0f;
			}
			if (suckingPlayersOutOfShip)
			{
				upperMonitorsCanvas.SetActive(false);
				SuckLocalPlayerOutOfShipDoor();
			}
			else if (!inShipPhase)
			{
				timeSinceRoundStarted += Time.deltaTime;
				upperMonitorsCanvas.SetActive(GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom);
			}
			else
			{
				upperMonitorsCanvas.SetActive(true);
			}
			if (IngamePlayerSettings.Instance.settings.pushToTalk)
			{
				voiceChatModule.IsMuted = !IngamePlayerSettings.Instance.playerInput.actions.FindAction("VoiceButton", false).IsPressed() && !GameNetworkManager.Instance.localPlayerController.speakingToWalkieTalkie;
				((Behaviour)HUDManager.Instance.PTTIcon).enabled = IngamePlayerSettings.Instance.settings.micEnabled && !voiceChatModule.IsMuted;
			}
			else
			{
				voiceChatModule.IsMuted = !IngamePlayerSettings.Instance.settings.micEnabled;
				((Behaviour)HUDManager.Instance.PTTIcon).enabled = false;
			}
			DetectVoiceChatAmplitude();
		}
		if (((NetworkBehaviour)this).IsServer && !hasHostSpawned)
		{
			hasHostSpawned = true;
			ClientPlayerList.Add(NetworkManager.Singleton.LocalClientId, connectedPlayersAmount);
			allPlayerObjects[0].GetComponent<NetworkObject>().ChangeOwnership(NetworkManager.Singleton.LocalClientId);
			allPlayerObjects[0].GetComponent<PlayerControllerB>().isPlayerControlled = true;
			livingPlayers = connectedPlayersAmount + 1;
			allPlayerObjects[0].GetComponent<PlayerControllerB>().TeleportPlayer(GetPlayerSpawnPosition(0));
			GameNetworkManager.Instance.SetLobbyJoinable(joinable: true);
		}
	}

	private string NoPunctuation(string input)
	{
		return new string(input.Where((char c) => char.IsLetter(c)).ToArray());
	}

	private void SuckLocalPlayerOutOfShipDoor()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		suckingPower += Time.deltaTime * 2f;
		GameNetworkManager.Instance.localPlayerController.fallValue = 0f;
		GameNetworkManager.Instance.localPlayerController.fallValueUncapped = 0f;
		if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, middleOfShipNode.position) < 25f)
		{
			if (Physics.Linecast(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, shipDoorNode.position, collidersAndRoomMask))
			{
				GameNetworkManager.Instance.localPlayerController.externalForces = Vector3.Normalize(middleOfShipNode.position - ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) * 350f;
			}
			else
			{
				GameNetworkManager.Instance.localPlayerController.externalForces = Vector3.Normalize(middleOfSpaceNode.position - ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) * (350f / Vector3.Distance(moveAwayFromShipNode.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position)) * (suckingPower / 2.25f);
			}
			return;
		}
		if (!choseRandomFlyDirForPlayer)
		{
			choseRandomFlyDirForPlayer = true;
			randomFlyDir = new Vector3(-1f, 0f, Random.Range(-0.7f, 0.7f));
		}
		GameNetworkManager.Instance.localPlayerController.externalForces = Vector3.Scale(Vector3.one, randomFlyDir) * 70f;
	}

	private void DetectVoiceChatAmplitude()
	{
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null || GameNetworkManager.Instance.localPlayerController.isPlayerDead || voiceChatModule.IsMuted || !((Behaviour)voiceChatModule).enabled || (Object)(object)voiceChatModule == (Object)null)
		{
			return;
		}
		VoicePlayerState val = voiceChatModule.FindPlayer(voiceChatModule.LocalPlayerName);
		averageCount++;
		if (averageCount > movingAverageLength)
		{
			averageVoiceAmplitude += (val.Amplitude - averageVoiceAmplitude) / (float)(movingAverageLength + 1);
		}
		else
		{
			averageVoiceAmplitude += val.Amplitude;
			if (averageCount == movingAverageLength)
			{
				averageVoiceAmplitude /= averageCount;
			}
		}
		float num = val.Amplitude / Mathf.Clamp(averageVoiceAmplitude, 0.008f, 0.5f);
		if (val.IsSpeaking && voiceChatNoiseCooldown <= 0f && num > 3f)
		{
			RoundManager.Instance.PlayAudibleNoise(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, Mathf.Clamp(3f * num, 3f, 36f), Mathf.Clamp(num / 7f, 0.6f, 0.9f), 0, hangarDoorsClosed && GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom, 75);
			voiceChatNoiseCooldown = 0.2f;
		}
		voiceChatNoiseCooldown -= Time.deltaTime;
	}

	public void ShipLeaveAutomatically(bool leavingOnMidnight = false)
	{
		if (!shipLeftAutomatically && !shipIsLeaving)
		{
			shipLeftAutomatically = true;
			((MonoBehaviour)this).StartCoroutine(gameOverAnimation(leavingOnMidnight));
		}
	}

	public void SetSpectateCameraToGameOverMode(bool enableGameOver, PlayerControllerB localPlayer = null)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		overrideSpectateCamera = enableGameOver;
		if (enableGameOver)
		{
			((Component)spectateCamera).transform.SetParent(gameOverCameraHandle, false);
		}
		else
		{
			((Component)spectateCamera).transform.SetParent(localPlayer.spectateCameraPivot, false);
		}
		((Component)spectateCamera).transform.localEulerAngles = Vector3.zero;
		((Component)spectateCamera).transform.localPosition = Vector3.zero;
	}

	public void SwitchCamera(Camera newCamera)
	{
		if ((Object)(object)newCamera != (Object)(object)spectateCamera)
		{
			((Behaviour)spectateCamera).enabled = false;
		}
		((Behaviour)newCamera).enabled = true;
		activeCamera = newCamera;
		Object.FindObjectOfType<StormyWeather>(true).SwitchCamera(newCamera);
		((UnityEvent)CameraSwitchEvent).Invoke();
	}

	private IEnumerator gameOverAnimation(bool leavingOnMidnight)
	{
		yield return (object)new WaitUntil((Func<bool>)(() => shipHasLanded));
		if (leavingOnMidnight)
		{
			HUDManager.Instance.ReadDialogue(shipLeavingOnMidnightDialogue);
		}
		((Behaviour)HUDManager.Instance.shipLeavingEarlyIcon).enabled = false;
		StartMatchLever startMatchLever = Object.FindObjectOfType<StartMatchLever>();
		startMatchLever.triggerScript.animationString = "SA_PushLeverBack";
		startMatchLever.leverHasBeenPulled = false;
		startMatchLever.triggerScript.interactable = false;
		startMatchLever.leverAnimatorObject.SetBool("pullLever", false);
		ShipLeave();
		yield return (object)new WaitForSeconds(1.5f);
		SetSpectateCameraToGameOverMode(enableGameOver: true);
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			GameNetworkManager.Instance.localPlayerController.SetSpectatedPlayerEffects(allPlayersDead: true);
		}
		yield return (object)new WaitForSeconds(1f);
		if (!leavingOnMidnight)
		{
			HUDManager.Instance.ReadDialogue(gameOverDialogue);
		}
		Debug.Log((object)$"Is in elevator D?: {GameNetworkManager.Instance.localPlayerController.isInElevator}");
		yield return (object)new WaitForSeconds(9.5f);
		if (!leavingOnMidnight)
		{
			HUDManager.Instance.UIAudio.PlayOneShot(allPlayersDeadAudio);
			HUDManager.Instance.gameOverAnimator.SetTrigger("allPlayersDead");
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StartGameServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1089447320u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1089447320u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (fullyLoadedPlayers.Count >= connectedPlayersAmount + 1 && !travellingToNewLevel)
			{
				StartGame();
			}
			else
			{
				Object.FindObjectOfType<StartMatchLever>().CancelStartGameClientRpc();
			}
		}
	}

	public void StartGame()
	{
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (inShipPhase)
		{
			if (!GameNetworkManager.Instance.gameHasStarted)
			{
				GameNetworkManager.Instance.LeaveLobbyAtGameStart();
				GameNetworkManager.Instance.gameHasStarted = true;
			}
			inShipPhase = false;
			fullyLoadedPlayers.Clear();
			ResetPlayersLoadedValueClientRpc(landingShip: true);
			Object.FindObjectOfType<StartMatchLever>().triggerScript.disabledHoverTip = "[Wait for ship to land]";
			Object.FindObjectOfType<StartMatchLever>().triggerScript.interactable = false;
			currentPlanetAnimator.SetTrigger("LandOnPlanet");
			if (overrideRandomSeed)
			{
				randomMapSeed = overrideSeedNumber;
			}
			else if (isChallengeFile)
			{
				randomMapSeed = new Random(GameNetworkManager.Instance.GetWeekNumber() + 51016).Next(0, 100000000);
				Debug.Log((object)$"RANDOM MAP SEED: {randomMapSeed}");
			}
			else
			{
				ChooseNewRandomMapSeed();
			}
			((NetworkBehaviour)this).NetworkManager.SceneManager.LoadScene(currentLevel.sceneName, (LoadSceneMode)1);
			Debug.Log((object)"LOADING GAME!!!!!");
			((MonoBehaviour)this).StartCoroutine(OpenShipDoors());
		}
		else
		{
			Debug.Log((object)"Attempted to start game on server but we are not in ship phase");
		}
	}

	public void ChooseNewRandomMapSeed()
	{
		randomMapSeed = Random.Range(1, 100000000);
	}

	private IEnumerator OpenShipDoors()
	{
		Debug.Log((object)"Waiting for all players to load!");
		yield return (object)new WaitUntil((Func<bool>)(() => fullyLoadedPlayers.Count >= GameNetworkManager.Instance.connectedPlayers));
		yield return (object)new WaitForSeconds(0.5f);
		RoundManager.Instance.LoadNewLevel(randomMapSeed, currentLevel);
	}

	public IEnumerator openingDoorsSequence()
	{
		((UnityEvent)StartNewRoundEvent).Invoke();
		yield return (object)new WaitForSeconds(1f);
		HUDManager.Instance.LevellingAudio.Stop();
		StartMatchLever leverScript = Object.FindObjectOfType<StartMatchLever>();
		leverScript.triggerScript.timeToHold = 0.7f;
		leverScript.triggerScript.interactable = false;
		displayedLevelResults = false;
		Instance.StartTrackingAllPlayerVoices();
		if (!GameNetworkManager.Instance.gameHasStarted)
		{
			GameNetworkManager.Instance.LeaveLobbyAtGameStart();
			GameNetworkManager.Instance.gameHasStarted = true;
		}
		Object.FindObjectOfType<QuickMenuManager>().DisableInviteFriendsButton();
		if (!GameNetworkManager.Instance.disableSteam)
		{
			SteamFriends.SetRichPresence("moonname", currentLevel.PlanetName);
			GameNetworkManager.Instance.SetSteamFriendGrouping(GameNetworkManager.Instance.steamLobbyName, connectedPlayersAmount + 1, "#Status_Landed");
		}
		timeSinceRoundStarted = 0f;
		shipLeftAutomatically = false;
		ResetStats();
		inShipPhase = false;
		SwitchMapMonitorPurpose();
		SetPlayerObjectExtrapolate(enable: false);
		((Component)shipAnimatorObject).gameObject.GetComponent<Animator>().SetTrigger("OpenShip");
		if (currentLevel.currentWeather != LevelWeatherType.None)
		{
			WeatherEffect weatherEffect = TimeOfDay.Instance.effects[(int)currentLevel.currentWeather];
			weatherEffect.effectEnabled = true;
			if ((Object)(object)weatherEffect.effectPermanentObject != (Object)null)
			{
				weatherEffect.effectPermanentObject.SetActive(true);
			}
		}
		yield return null;
		yield return (object)new WaitForSeconds(0.2f);
		if (TimeOfDay.Instance.currentLevelWeather != LevelWeatherType.None && !currentLevel.overrideWeather)
		{
			TimeOfDay.Instance.effects[(int)TimeOfDay.Instance.currentLevelWeather].effectEnabled = true;
		}
		shipDoorsEnabled = true;
		if (currentLevel.planetHasTime)
		{
			TimeOfDay.Instance.currentDayTimeStarted = true;
			TimeOfDay.Instance.movingGlobalTimeForward = true;
		}
		Object.FindObjectOfType<HangarShipDoor>().SetDoorButtonsEnabled(doorButtonsEnabled: true);
		TeleportPlayerInShipIfOutOfRoomBounds();
		yield return (object)new WaitForSeconds(0.05f);
		Debug.Log((object)$"startofround: {currentLevel.levelID}; {hoursSinceLastCompanyVisit}");
		if (currentLevel.levelID == 3 && hoursSinceLastCompanyVisit >= 0)
		{
			hoursSinceLastCompanyVisit = 0;
			TimeOfDay.Instance.TimeOfDayMusic.volume = 0.6f;
			Debug.Log((object)"Playing time of day music");
			TimeOfDay.Instance.PlayTimeMusicDelayed(companyVisitMusic, 1f);
		}
		((Behaviour)HUDManager.Instance.loadingText).enabled = false;
		((Behaviour)HUDManager.Instance.loadingDarkenScreen).enabled = false;
		shipDoorAudioSource.PlayOneShot(openingHangarDoorAudio, 1f);
		yield return (object)new WaitForSeconds(0.8f);
		shipDoorsAnimator.SetBool("Closed", false);
		yield return (object)new WaitForSeconds(5f);
		HUDManager.Instance.planetIntroAnimator.SetTrigger("introAnimation");
		if (isChallengeFile)
		{
			((TMP_Text)HUDManager.Instance.planetInfoHeaderText).text = "CELESTIAL BODY: " + GameNetworkManager.Instance.GetNameForWeekNumber();
		}
		else
		{
			((TMP_Text)HUDManager.Instance.planetInfoHeaderText).text = "CELESTIAL BODY: " + currentLevel.PlanetName;
		}
		((TMP_Text)HUDManager.Instance.planetInfoSummaryText).text = currentLevel.LevelDescription;
		((TMP_Text)HUDManager.Instance.planetRiskLevelText).text = currentLevel.riskLevel;
		yield return (object)new WaitForSeconds(10f);
		if (currentLevel.spawnEnemiesAndScrap && currentLevel.planetHasTime)
		{
			HUDManager.Instance.quotaAnimator.SetBool("visible", true);
			TimeOfDay.Instance.currentDayTime = TimeOfDay.Instance.CalculatePlanetTime(currentLevel);
			TimeOfDay.Instance.RefreshClockUI();
		}
		yield return (object)new WaitForSeconds(4f);
		OnShipLandedMiscEvents();
		SetPlayerObjectExtrapolate(enable: false);
		shipHasLanded = true;
		leverScript.triggerScript.animationString = "SA_PushLeverBack";
		leverScript.triggerScript.interactable = true;
		leverScript.hasDisplayedTimeWarning = false;
	}

	private void OnShipLandedMiscEvents()
	{
		if (TimeOfDay.Instance.currentLevelWeather == LevelWeatherType.Eclipsed)
		{
			HUDManager.Instance.DisplayTip("Weather alert!", "You have landed in an eclipse. Exercise caution!", isWarning: true, useSave: true, "LC_EclipseTip");
		}
		int num = ES3.Load<int>("TimesLanded", "LCGeneralSaveData", 0);
		ES3.Save<int>("TimesLanded", num + 1, "LCGeneralSaveData");
	}

	public void ForcePlayerIntoShip()
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (!GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom)
		{
			GameNetworkManager.Instance.localPlayerController.isInElevator = true;
			GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom = true;
			GameNetworkManager.Instance.localPlayerController.TeleportPlayer(GetPlayerSpawnPosition((int)GameNetworkManager.Instance.localPlayerController.playerClientId));
		}
	}

	public void SetPlayerObjectExtrapolate(bool enable)
	{
		if (enable)
		{
			((Component)localPlayerController).GetComponent<Rigidbody>().interpolation = (RigidbodyInterpolation)2;
		}
		else
		{
			((Component)localPlayerController).GetComponent<Rigidbody>().interpolation = (RigidbodyInterpolation)0;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void EndGameServerRpc(int playerClientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2028434619u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerClientId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2028434619u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && shipHasLanded && !shipLeftAutomatically && (!shipIsLeaving || playerClientId == 0))
			{
				Object.FindObjectOfType<StartMatchLever>().triggerScript.interactable = false;
				shipHasLanded = false;
				EndGameClientRpc(playerClientId);
			}
		}
	}

	[ClientRpc]
	public void EndGameClientRpc(int playerClientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(794862467u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerClientId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 794862467u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				HUDManager.Instance.AddTextToChatOnServer($"[playerNum{playerClientId}] started the ship.");
				ShipLeave();
			}
		}
	}

	private void ShipLeave()
	{
		shipHasLanded = false;
		shipIsLeaving = true;
		shipAnimator.ResetTrigger("ShipLeave");
		shipAnimator.SetTrigger("ShipLeave");
		_ = localPlayerController.isInElevator;
	}

	public void ShipHasLeft()
	{
		shipDoorsAnimator.SetBool("Closed", true);
		Object.FindObjectOfType<HangarShipDoor>().SetDoorButtonsEnabled(doorButtonsEnabled: false);
		if (((NetworkBehaviour)this).IsServer)
		{
			((MonoBehaviour)this).StartCoroutine(unloadSceneForAllPlayers());
		}
	}

	private IEnumerator unloadSceneForAllPlayers()
	{
		yield return (object)new WaitForSeconds(2f);
		fullyLoadedPlayers.Clear();
		((NetworkBehaviour)this).NetworkManager.SceneManager.UnloadScene(SceneManager.GetSceneAt(1));
		yield return null;
		yield return (object)new WaitUntil((Func<bool>)(() => fullyLoadedPlayers.Count >= GameNetworkManager.Instance.connectedPlayers));
		mapScreen.gotCaveNodes = false;
		playersRevived = 0;
		int bodiesInShip = GetBodiesInShip();
		if (connectedPlayersAmount + 1 - livingPlayers == 0 && RoundManager.Instance.valueOfFoundScrapItems > 30)
		{
			daysPlayersSurvivedInARow++;
		}
		else
		{
			daysPlayersSurvivedInARow = 0;
		}
		EndOfGameClientRpc(scrapCollectedOnServer: scrapCollectedLastRound = ((livingPlayers != 0) ? GetValueOfAllScrap(onlyScrapCollected: true, onlyNewScrap: true) : 0), bodiesInsured: bodiesInShip, daysPlayersSurvived: daysPlayersSurvivedInARow, connectedPlayersOnServer: connectedPlayersAmount);
	}

	private int GetBodiesInShip()
	{
		int num = 0;
		DeadBodyInfo[] array = Object.FindObjectsOfType<DeadBodyInfo>();
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].isInShip)
			{
				num++;
			}
		}
		return num;
	}

	[ClientRpc]
	public void EndOfGameClientRpc(int bodiesInsured, int daysPlayersSurvived, int connectedPlayersOnServer, int scrapCollectedOnServer)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2659636069u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, bodiesInsured);
			BytePacker.WriteValueBitPacked(val2, daysPlayersSurvived);
			BytePacker.WriteValueBitPacked(val2, connectedPlayersOnServer);
			BytePacker.WriteValueBitPacked(val2, scrapCollectedOnServer);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2659636069u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			SoundManager.Instance.playingOutsideMusic = false;
			scrapCollectedLastRound = scrapCollectedOnServer;
			((Behaviour)Object.FindObjectOfType<AudioListener>()).enabled = true;
			if (currentLevel.planetHasTime)
			{
				WritePlayerNotes();
				HUDManager.Instance.FillEndGameStats(gameStats, scrapCollectedOnServer);
			}
			Object.FindObjectOfType<StartMatchLever>().triggerScript.animationString = "SA_PullLever";
			daysPlayersSurvivedInARow = daysPlayersSurvived;
			((MonoBehaviour)this).StartCoroutine(EndOfGame(bodiesInsured, connectedPlayersOnServer, scrapCollectedOnServer));
		}
	}

	private IEnumerator fadeVolume(float finalVolume)
	{
		float initialVolume = AudioListener.volume;
		for (int i = 0; i < 20; i++)
		{
			yield return (object)new WaitForSeconds(0.015f);
			AudioListener.volume = Mathf.Lerp(initialVolume, finalVolume, (float)i / 20f);
		}
	}

	public void ResetStats()
	{
		for (int i = 0; i < gameStats.allPlayerStats.Length; i++)
		{
			gameStats.allPlayerStats[i].damageTaken = 0;
			gameStats.allPlayerStats[i].jumps = 0;
			gameStats.allPlayerStats[i].playerNotes.Clear();
			gameStats.allPlayerStats[i].stepsTaken = 0;
			gameStats.allPlayerStats[i].turnAmount = 0;
		}
	}

	public void WritePlayerNotes()
	{
		for (int i = 0; i < gameStats.allPlayerStats.Length; i++)
		{
			gameStats.allPlayerStats[i].isActivePlayer = allPlayerScripts[i].disconnectedMidGame || allPlayerScripts[i].isPlayerDead || allPlayerScripts[i].isPlayerControlled;
		}
		int num = 0;
		int num2 = 0;
		for (int j = 0; j < gameStats.allPlayerStats.Length; j++)
		{
			if (gameStats.allPlayerStats[j].isActivePlayer && (j == 0 || gameStats.allPlayerStats[j].stepsTaken < num))
			{
				num = gameStats.allPlayerStats[j].stepsTaken;
				num2 = j;
			}
		}
		if (connectedPlayersAmount > 0 && num > 10)
		{
			gameStats.allPlayerStats[num2].playerNotes.Add("The laziest employee.");
		}
		num = 0;
		for (int k = 0; k < gameStats.allPlayerStats.Length; k++)
		{
			if (gameStats.allPlayerStats[k].isActivePlayer && gameStats.allPlayerStats[k].turnAmount > num)
			{
				num = gameStats.allPlayerStats[k].turnAmount;
				num2 = k;
			}
		}
		if (connectedPlayersAmount > 0)
		{
			gameStats.allPlayerStats[num2].playerNotes.Add("The most paranoid employee.");
		}
		num = 0;
		for (int l = 0; l < gameStats.allPlayerStats.Length; l++)
		{
			if (gameStats.allPlayerStats[l].isActivePlayer && !allPlayerScripts[l].isPlayerDead && gameStats.allPlayerStats[l].damageTaken > num)
			{
				num = gameStats.allPlayerStats[l].damageTaken;
				num2 = l;
			}
		}
		if (connectedPlayersAmount > 0)
		{
			gameStats.allPlayerStats[num2].playerNotes.Add("Sustained the most injuries.");
		}
		num = 0;
		for (int m = 0; m < gameStats.allPlayerStats.Length; m++)
		{
			if (gameStats.allPlayerStats[m].isActivePlayer && gameStats.allPlayerStats[m].profitable > num)
			{
				num = gameStats.allPlayerStats[m].profitable;
				num2 = m;
			}
		}
		if (connectedPlayersAmount > 0 && num > 50)
		{
			if (num2 == (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				localPlayerWasMostProfitableThisRound = true;
			}
			gameStats.allPlayerStats[num2].playerNotes.Add("Most profitable");
		}
	}

	private IEnumerator EndOfGame(int bodiesInsured = 0, int connectedPlayersOnServer = 0, int scrapCollected = 0)
	{
		if (!GameNetworkManager.Instance.disableSteam)
		{
			SteamFriends.SetRichPresence("moonname", currentLevel.PlanetName);
			GameNetworkManager.Instance.SetSteamFriendGrouping(GameNetworkManager.Instance.steamLobbyName, connectedPlayersAmount + 1, "#Status_Orbiting");
		}
		shipDoorsEnabled = false;
		Debug.Log((object)$"Scrap collected: {scrapCollected}");
		if (currentLevel.currentWeather != LevelWeatherType.None)
		{
			WeatherEffect weatherEffect = TimeOfDay.Instance.effects[(int)currentLevel.currentWeather];
			if (weatherEffect != null && (Object)(object)weatherEffect.effectPermanentObject != (Object)null)
			{
				weatherEffect.effectPermanentObject.SetActive(false);
			}
		}
		TimeOfDay.Instance.currentWeatherVariable = 0f;
		TimeOfDay.Instance.currentWeatherVariable2 = 0f;
		TimeOfDay.Instance.DisableAllWeather(deactivateObjects: true);
		TimeOfDay.Instance.currentLevelWeather = LevelWeatherType.None;
		TimeOfDay.Instance.movingGlobalTimeForward = false;
		TimeOfDay.Instance.currentDayTimeStarted = false;
		TimeOfDay.Instance.currentDayTime = 0f;
		TimeOfDay.Instance.dayMode = DayMode.Dawn;
		gameStats.daysSpent++;
		((Behaviour)HUDManager.Instance.shipLeavingEarlyIcon).enabled = false;
		HUDManager.Instance.HideHUD(hide: true);
		HUDManager.Instance.quotaAnimator.SetBool("visible", false);
		yield return (object)new WaitForSeconds(1f);
		if (currentLevel.planetHasTime)
		{
			if (isChallengeFile)
			{
				HUDManager.Instance.endgameStatsAnimator.SetTrigger("displayStatsChallenge");
			}
			else
			{
				HUDManager.Instance.endgameStatsAnimator.SetTrigger("displayStats");
			}
		}
		SwitchMapMonitorPurpose(displayInfo: true);
		yield return (object)new WaitForSeconds(1f);
		RoundManager.Instance.DespawnPropsAtEndOfRound(isChallengeFile);
		RoundManager.Instance.bakedNavMesh = false;
		try
		{
			Object.FindObjectOfType<MoldSpreadManager>().RemoveAllMold();
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Error despawning mold: {arg}");
		}
		if (isChallengeFile)
		{
			ResetShipFurniture(onlyClearBoughtFurniture: true, despawnProps: false);
		}
		if (isChallengeFile)
		{
			Terminal terminal = Object.FindObjectOfType<Terminal>();
			terminal.groupCredits = terminal.startingCreditsAmount;
		}
		RoundManager.Instance.scrapCollectedThisRound.Clear();
		ResetPooledObjects();
		if (currentLevel.planetHasTime)
		{
			yield return (object)new WaitForSeconds(8f);
			HUDManager.Instance.SetPlayerLevel(GameNetworkManager.Instance.localPlayerController.isPlayerDead, localPlayerWasMostProfitableThisRound, allPlayersDead);
			if (isChallengeFile)
			{
				HUDManager.Instance.FillChallengeResultsStats(scrapCollected);
				yield return (object)new WaitForSeconds(2f);
			}
			displayedLevelResults = true;
		}
		localPlayerWasMostProfitableThisRound = false;
		int playersDead = connectedPlayersAmount + 1 - livingPlayers;
		ReviveDeadPlayers();
		RoundManager.Instance.ResetEnemyVariables();
		yield return (object)new WaitForSeconds(3f);
		if (playersDead > 0 && !isChallengeFile)
		{
			HUDManager.Instance.endgameStatsAnimator.SetTrigger("displayPenalty");
			HUDManager.Instance.ApplyPenalty(playersDead, bodiesInsured);
			yield return (object)new WaitForSeconds(4f);
		}
		PassTimeToNextDay(connectedPlayersOnServer);
		yield return (object)new WaitForSeconds(1.7f);
		HUDManager.Instance.HideHUD(hide: false);
		shipIsLeaving = false;
		if (((NetworkBehaviour)this).IsServer)
		{
			playersRevived++;
			yield return (object)new WaitUntil((Func<bool>)(() => playersRevived >= GameNetworkManager.Instance.connectedPlayers));
			playersRevived = 0;
			bool flag = TimeOfDay.Instance.timeUntilDeadline <= 0f;
			if ((float)(TimeOfDay.Instance.profitQuota - TimeOfDay.Instance.quotaFulfilled) <= 0f || isChallengeFile)
			{
				if (!isChallengeFile)
				{
					TimeOfDay.Instance.SetNewProfitQuota();
				}
				AllPlayersHaveRevivedClientRpc();
			}
			else if (flag)
			{
				FirePlayersAfterDeadlineClientRpc(GetEndgameStatsInOrder());
			}
			else
			{
				AllPlayersHaveRevivedClientRpc();
			}
		}
		else
		{
			PlayerHasRevivedServerRpc();
		}
	}

	private int[] GetEndgameStatsInOrder()
	{
		return new int[4] { gameStats.daysSpent, gameStats.scrapValueCollected, gameStats.deaths, gameStats.allStepsTaken };
	}

	private void PassTimeToNextDay(int connectedPlayersOnServer = 0)
	{
		if (isChallengeFile)
		{
			TimeOfDay.Instance.globalTime = 100f;
			SetMapScreenInfoToCurrentLevel();
			return;
		}
		float num = TimeOfDay.Instance.globalTimeAtEndOfDay - TimeOfDay.Instance.globalTime;
		_ = TimeOfDay.Instance.totalTime / TimeOfDay.Instance.lengthOfHours;
		if (currentLevel.planetHasTime || TimeOfDay.Instance.daysUntilDeadline <= 0)
		{
			TimeOfDay.Instance.timeUntilDeadline -= num;
			TimeOfDay.Instance.OnDayChanged();
		}
		TimeOfDay.Instance.globalTime = 100f;
		TimeOfDay.Instance.UpdateProfitQuotaCurrentTime();
		if (currentLevel.planetHasTime)
		{
			HUDManager.Instance.DisplayDaysLeft((int)Mathf.Floor(TimeOfDay.Instance.timeUntilDeadline / TimeOfDay.Instance.totalTime));
		}
		Object.FindObjectOfType<Terminal>().SetItemSales();
		SetMapScreenInfoToCurrentLevel();
		if (TimeOfDay.Instance.timeUntilDeadline > 0f && TimeOfDay.Instance.daysUntilDeadline <= 0 && TimeOfDay.Instance.timesFulfilledQuota <= 0)
		{
			((MonoBehaviour)this).StartCoroutine(playDaysLeftAlertSFXDelayed());
		}
	}

	private IEnumerator playDaysLeftAlertSFXDelayed()
	{
		yield return (object)new WaitForSeconds(3f);
		Instance.speakerAudioSource.PlayOneShot(zeroDaysLeftAlertSFX);
	}

	[ClientRpc]
	public void AllPlayersHaveRevivedClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1043433721u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1043433721u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SetShipReadyToLand();
			}
		}
	}

	private void AutoSaveShipData()
	{
		HUDManager.Instance.saveDataIconAnimatorB.SetTrigger("save");
		GameNetworkManager.Instance.SaveGame();
	}

	[ServerRpc]
	public void ManuallyEjectPlayersServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1482204640u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1482204640u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && inShipPhase && !isChallengeFile && !firingPlayersCutsceneRunning && fullyLoadedPlayers.Count >= GameNetworkManager.Instance.connectedPlayers)
		{
			GameNetworkManager.Instance.gameHasStarted = true;
			firingPlayersCutsceneRunning = true;
			FirePlayersAfterDeadlineClientRpc(GetEndgameStatsInOrder());
		}
	}

	[ClientRpc]
	public void FirePlayersAfterDeadlineClientRpc(int[] endGameStats, bool abridgedVersion = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2721053021u, val, (RpcDelivery)0);
			bool flag = endGameStats != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(endGameStats, default(ForPrimitives));
			}
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref abridgedVersion, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2721053021u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			firingPlayersCutsceneRunning = true;
			if (Object.FindObjectOfType<Terminal>().terminalInUse)
			{
				Object.FindObjectOfType<Terminal>().QuitTerminal();
			}
			if (GameNetworkManager.Instance.localPlayerController.inSpecialInteractAnimation && (Object)(object)GameNetworkManager.Instance.localPlayerController.currentTriggerInAnimationWith != (Object)null)
			{
				GameNetworkManager.Instance.localPlayerController.currentTriggerInAnimationWith.StopSpecialAnimation();
			}
			((TMP_Text)HUDManager.Instance.EndOfRunStatsText).text = $"Days on the job: {endGameStats[0]}\n" + $"Scrap value collected: {endGameStats[1]}\n" + $"Deaths: {endGameStats[2]}\n" + $"Steps taken: {endGameStats[3]}";
			gameStats.daysSpent = 0;
			gameStats.scrapValueCollected = 0;
			gameStats.deaths = 0;
			gameStats.allStepsTaken = 0;
			SetDiscordStatusDetails();
			((MonoBehaviour)this).StartCoroutine(playersFiredGameOver(abridgedVersion));
		}
	}

	private IEnumerator playersFiredGameOver(bool abridgedVersion)
	{
		yield return (object)new WaitForSeconds(5f);
		((Component)shipAnimatorObject).gameObject.GetComponent<Animator>().SetBool("AlarmRinging", true);
		shipRoomLights.SetShipLightsOnLocalClientOnly(setLightsOn: false);
		speakerAudioSource.PlayOneShot(firedVoiceSFX);
		shipDoorAudioSource.PlayOneShot(alarmSFX);
		yield return (object)new WaitForSeconds(9.37f);
		shipDoorsAnimator.SetBool("OpenInOrbit", true);
		shipDoorAudioSource.PlayOneShot(airPressureSFX);
		starSphereObject.SetActive(true);
		starSphereObject.transform.position = ((Component)GameNetworkManager.Instance.localPlayerController).transform.position;
		yield return (object)new WaitForSeconds(0.25f);
		suckingPlayersOutOfShip = true;
		suckingFurnitureOutOfShip = true;
		PlaceableShipObject[] array = Object.FindObjectsOfType<PlaceableShipObject>();
		for (int i = 0; i < array.Length; i++)
		{
			if ((Object)(object)array[i].parentObject == (Object)null)
			{
				Debug.Log((object)("Error! No parentObject for placeable object: " + unlockablesList.unlockables[array[i].unlockableID].unlockableName));
				continue;
			}
			array[i].parentObject.StartSuckingOutOfShip();
			if (unlockablesList.unlockables[array[i].unlockableID].spawnPrefab)
			{
				Collider[] componentsInChildren = ((Component)array[i].parentObject).GetComponentsInChildren<Collider>();
				for (int j = 0; j < componentsInChildren.Length; j++)
				{
					componentsInChildren[j].enabled = false;
				}
			}
		}
		GameNetworkManager.Instance.localPlayerController.inSpecialInteractAnimation = true;
		GameNetworkManager.Instance.localPlayerController.DropAllHeldItems();
		HUDManager.Instance.UIAudio.PlayOneShot(suckedIntoSpaceSFX);
		yield return (object)new WaitForSeconds(6f);
		SoundManager.Instance.SetDiageticMixerSnapshot(3, 2f);
		HUDManager.Instance.ShowPlayersFiredScreen(show: true);
		Object.FindObjectOfType<Terminal>().ClearBoughtItems();
		yield return (object)new WaitForSeconds(2f);
		starSphereObject.SetActive(false);
		shipDoorAudioSource.Stop();
		speakerAudioSource.Stop();
		suckingFurnitureOutOfShip = false;
		if (((NetworkBehaviour)this).IsServer)
		{
			GameNetworkManager.Instance.ResetSavedGameValues();
		}
		Debug.Log((object)"Calling reset ship!");
		ResetShip();
		Object.FindObjectOfType<Terminal>().SetItemSales();
		yield return (object)new WaitForSeconds(6f);
		((Component)shipAnimatorObject).gameObject.GetComponent<Animator>().SetBool("AlarmRinging", false);
		GameNetworkManager.Instance.localPlayerController.TeleportPlayer(playerSpawnPositions[GameNetworkManager.Instance.localPlayerController.playerClientId].position);
		shipDoorsAnimator.SetBool("OpenInOrbit", false);
		currentPlanetPrefab.transform.position = ((Component)planetContainer).transform.position;
		suckingPlayersOutOfShip = false;
		choseRandomFlyDirForPlayer = false;
		suckingPower = 0f;
		shipRoomLights.SetShipLightsOnLocalClientOnly(setLightsOn: true);
		yield return (object)new WaitForSeconds(2f);
		if (((NetworkBehaviour)this).IsServer)
		{
			playersRevived++;
			yield return (object)new WaitUntil((Func<bool>)(() => playersRevived >= GameNetworkManager.Instance.connectedPlayers));
			playersRevived = 0;
			EndPlayersFiredSequenceClientRpc();
		}
		else
		{
			PlayerHasRevivedServerRpc();
		}
	}

	public void ResetShip()
	{
		TimeOfDay.Instance.globalTime = 100f;
		TimeOfDay.Instance.profitQuota = TimeOfDay.Instance.quotaVariables.startingQuota;
		TimeOfDay.Instance.quotaFulfilled = 0;
		TimeOfDay.Instance.timesFulfilledQuota = 0;
		TimeOfDay.Instance.timeUntilDeadline = (int)(TimeOfDay.Instance.totalTime * (float)TimeOfDay.Instance.quotaVariables.deadlineDaysAmount);
		TimeOfDay.Instance.UpdateProfitQuotaCurrentTime();
		randomMapSeed++;
		Debug.Log((object)"Reset ship 0");
		companyBuyingRate = 0.3f;
		ChangeLevel(defaultPlanet);
		ChangePlanet();
		SetMapScreenInfoToCurrentLevel();
		Terminal terminal = Object.FindObjectOfType<Terminal>();
		if ((Object)(object)terminal != (Object)null)
		{
			terminal.groupCredits = TimeOfDay.Instance.quotaVariables.startingCredits;
		}
		ResetShipFurniture();
		ResetMoldStates();
		ResetPooledObjects(destroy: true);
		TimeOfDay.Instance.OnDayChanged();
	}

	private void ResetMoldStates()
	{
		Object.FindObjectOfType<MoldSpreadManager>().ResetMoldData();
		for (int i = 0; i < levels.Length; i++)
		{
			levels[i].moldSpreadIterations = 0;
			levels[i].moldStartPosition = -1;
		}
	}

	private void ResetShipFurniture(bool onlyClearBoughtFurniture = false, bool despawnProps = true)
	{
		Debug.Log((object)"Resetting ship furniture");
		if (((NetworkBehaviour)this).IsServer)
		{
			for (int i = 0; i < unlockablesList.unlockables.Count; i++)
			{
				if (unlockablesList.unlockables[i].alreadyUnlocked || !unlockablesList.unlockables[i].spawnPrefab)
				{
					continue;
				}
				if (!SpawnedShipUnlockables.TryGetValue(i, out var value))
				{
					SpawnedShipUnlockables.Remove(i);
					continue;
				}
				if ((Object)(object)value == (Object)null)
				{
					SpawnedShipUnlockables.Remove(i);
					continue;
				}
				SpawnedShipUnlockables.Remove(i);
				NetworkObject component = value.GetComponent<NetworkObject>();
				if ((Object)(object)component != (Object)null && component.IsSpawned)
				{
					component.Despawn(true);
				}
			}
			if (despawnProps)
			{
				RoundManager.Instance.DespawnPropsAtEndOfRound(despawnAllItems: true);
			}
			closetLeftDoor.SetBoolOnClientOnly(setTo: false);
			closetRightDoor.SetBoolOnClientOnly(setTo: false);
		}
		ShipTeleporter.hasBeenSpawnedThisSession = false;
		ShipTeleporter.hasBeenSpawnedThisSessionInverse = false;
		if (!onlyClearBoughtFurniture)
		{
			PlaceableShipObject[] array = Object.FindObjectsOfType<PlaceableShipObject>();
			for (int j = 0; j < array.Length; j++)
			{
				if (unlockablesList.unlockables[array[j].unlockableID].alreadyUnlocked && !unlockablesList.unlockables[array[j].unlockableID].spawnPrefab)
				{
					array[j].parentObject.disableObject = false;
					ShipBuildModeManager.Instance.ResetShipObjectToDefaultPosition(array[j]);
				}
			}
		}
		GameNetworkManager.Instance.ResetUnlockablesListValues(onlyClearBoughtFurniture);
		for (int k = 0; k < allPlayerScripts.Length; k++)
		{
			SoundManager.Instance.playerVoicePitchTargets[k] = 1f;
			allPlayerScripts[k].ResetPlayerBloodObjects();
			if (isChallengeFile)
			{
				UnlockableSuit.SwitchSuitForPlayer(allPlayerScripts[k], 24);
			}
			else
			{
				UnlockableSuit.SwitchSuitForPlayer(allPlayerScripts[k], 0);
			}
		}
	}

	[ClientRpc]
	public void EndPlayersFiredSequenceClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1068504982u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1068504982u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			firingPlayersCutsceneRunning = false;
			timeAtStartOfRun = Time.realtimeSinceStartup;
			ReviveDeadPlayers();
			SoundManager.Instance.SetDiageticMixerSnapshot(0, 0.25f);
			HUDManager.Instance.ShowPlayersFiredScreen(show: false);
			GameNetworkManager.Instance.localPlayerController.inSpecialInteractAnimation = false;
			SetShipReadyToLand();
			SetDiscordStatusDetails();
			if (!isChallengeFile)
			{
				PlayFirstDayShipAnimation();
			}
		}
	}

	private void PlayFirstDayShipAnimation(bool waitForMenuToClose = false)
	{
		((MonoBehaviour)this).StartCoroutine(firstDayAnimation(waitForMenuToClose));
	}

	private IEnumerator firstDayAnimation(bool waitForMenuToClose)
	{
		yield return (object)new WaitForSeconds(5.5f);
		if (waitForMenuToClose)
		{
			QuickMenuManager quickMenu = Object.FindObjectOfType<QuickMenuManager>();
			yield return (object)new WaitUntil((Func<bool>)(() => !quickMenu.isMenuOpen));
			yield return (object)new WaitForSeconds(0.2f);
		}
		speakerAudioSource.PlayOneShot(shipIntroSpeechSFX);
	}

	public void DisableShipSpeaker()
	{
		DisableShipSpeakerLocalClient();
		StopShipSpeakerServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
	}

	[ServerRpc(RequireOwnership = false)]
	public void StopShipSpeakerServerRpc(int playerWhoTriggered)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2441193238u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2441193238u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StopShipSpeakerClientRpc(playerWhoTriggered);
			}
		}
	}

	[ClientRpc]
	public void StopShipSpeakerClientRpc(int playerWhoTriggered)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(907290724u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 907290724u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				DisableShipSpeakerLocalClient();
			}
		}
	}

	private void DisableShipSpeakerLocalClient()
	{
		if (speakerAudioSource.isPlaying)
		{
			speakerAudioSource.Stop();
			speakerAudioSource.PlayOneShot(disableSpeakerSFX);
		}
	}

	public void LoadPlanetsMoldSpreadData()
	{
		for (int i = 0; i < levels.Length; i++)
		{
			int num = ES3.Load<int>($"Level{levels[i].levelID}Mold", GameNetworkManager.Instance.currentSaveFileName, 0);
			levels[i].moldSpreadIterations = num;
			int num2 = ((num > 0) ? ES3.Load<int>($"Level{levels[i].levelID}MoldOrigin", GameNetworkManager.Instance.currentSaveFileName, -1) : (-1));
			levels[i].moldStartPosition = num2;
			Debug.Log((object)$"Loading from data: for {levels[i].PlanetName}: iterations at {num}, starting at node #{num2}");
		}
	}

	public void SetPlanetsWeather(int connectedPlayersOnServer = 0)
	{
		for (int i = 0; i < levels.Length; i++)
		{
			levels[i].currentWeather = LevelWeatherType.None;
			if (levels[i].overrideWeather)
			{
				levels[i].currentWeather = levels[i].overrideWeatherType;
			}
		}
		Random random = new Random(randomMapSeed + 35);
		List<SelectableLevel> list = levels.ToList();
		float num = 1f;
		if (connectedPlayersOnServer + 1 > 1 && daysPlayersSurvivedInARow > 2 && daysPlayersSurvivedInARow % 3 == 0)
		{
			num = (float)random.Next(15, 25) / 10f;
		}
		float num2 = Mathf.Clamp(planetsWeatherRandomCurve.Evaluate((float)random.NextDouble()) * num, 0f, 1f);
		Debug.Log((object)$"Weather chance: {num2}; {num}");
		int num3 = Mathf.Clamp((int)(num2 * ((float)levels.Length - 2f)), 0, levels.Length);
		for (int j = 0; j < num3; j++)
		{
			SelectableLevel selectableLevel = list[random.Next(0, list.Count)];
			if (selectableLevel.randomWeathers != null && selectableLevel.randomWeathers.Length != 0)
			{
				selectableLevel.currentWeather = selectableLevel.randomWeathers[random.Next(0, selectableLevel.randomWeathers.Length)].weatherType;
			}
			list.Remove(selectableLevel);
		}
	}

	private void SetShipReadyToLand()
	{
		if (Instance.isChallengeFile)
		{
			hasSubmittedChallengeRank = true;
			TimeOfDay.Instance.timeUntilDeadline = TimeOfDay.Instance.totalTime;
		}
		inShipPhase = true;
		shipLeftAutomatically = false;
		SetDiscordStatusDetails();
		if (currentLevel.planetHasTime && TimeOfDay.Instance.GetDayPhase(TimeOfDay.Instance.CalculatePlanetTime(currentLevel) / TimeOfDay.Instance.totalTime) == DayMode.Midnight)
		{
			Object.FindObjectOfType<StartMatchLever>().triggerScript.disabledHoverTip = "Too late on moon to land!";
		}
		else
		{
			Object.FindObjectOfType<StartMatchLever>().triggerScript.interactable = true;
		}
		((TMP_Text)HUDManager.Instance.loadingText).text = "";
		AutoSaveShipData();
		((MonoBehaviour)this).StartCoroutine(playRandomShipAudio());
		SoundManager.Instance.ResetRandomSeed();
	}

	private IEnumerator playRandomShipAudio()
	{
		Random shipRandom = new Random(randomMapSeed);
		if (shipRandom.Next(0, 100) <= 4)
		{
			yield return (object)new WaitForSeconds((float)shipRandom.Next(7, 35));
			if (inShipPhase)
			{
				RoundManager.PlayRandomClip(shipAmbianceAudio, shipCreakSFX, randomize: false, (float)shipRandom.Next(0, 10) / 10f);
			}
		}
	}

	private IEnumerator ResetDissonanceCommsComponent()
	{
		((Behaviour)voiceChatModule).enabled = false;
		yield return (object)new WaitForSeconds(3f);
		((Behaviour)voiceChatModule).enabled = true;
		voiceChatModule.ResetMicrophoneCapture();
	}

	[ServerRpc(RequireOwnership = false)]
	public void PlayerHasRevivedServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3083945322u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3083945322u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				playersRevived++;
			}
		}
	}

	private IEnumerator waitingForOtherPlayersToRevive()
	{
		yield return (object)new WaitForSeconds(2f);
		if (!inShipPhase)
		{
			((Behaviour)HUDManager.Instance.loadingText).enabled = true;
			((TMP_Text)HUDManager.Instance.loadingText).text = "Waiting for crew...";
		}
	}

	public void ReviveDeadPlayers()
	{
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		allPlayersDead = false;
		for (int i = 0; i < allPlayerScripts.Length; i++)
		{
			Debug.Log((object)"Reviving players A");
			allPlayerScripts[i].ResetPlayerBloodObjects(allPlayerScripts[i].isPlayerDead);
			if (!allPlayerScripts[i].isPlayerDead && !allPlayerScripts[i].isPlayerControlled)
			{
				continue;
			}
			allPlayerScripts[i].isClimbingLadder = false;
			if (!allPlayerScripts[i].inSpecialInteractAnimation || (Object)(object)allPlayerScripts[i].currentTriggerInAnimationWith == (Object)null || !Object.op_Implicit((Object)(object)((Component)allPlayerScripts[i].currentTriggerInAnimationWith).GetComponentInChildren<MoveToExitSpecialAnimation>()))
			{
				allPlayerScripts[i].clampLooking = false;
				((Component)allPlayerScripts[i].gameplayCamera).transform.localEulerAngles = new Vector3(((Component)allPlayerScripts[i].gameplayCamera).transform.localEulerAngles.x, 0f, ((Component)allPlayerScripts[i].gameplayCamera).transform.localEulerAngles.z);
				allPlayerScripts[i].inVehicleAnimation = false;
			}
			allPlayerScripts[i].disableMoveInput = false;
			allPlayerScripts[i].ResetZAndXRotation();
			((Collider)allPlayerScripts[i].thisController).enabled = true;
			allPlayerScripts[i].health = 100;
			allPlayerScripts[i].hasBeenCriticallyInjured = false;
			allPlayerScripts[i].disableLookInput = false;
			allPlayerScripts[i].disableInteract = false;
			((Behaviour)allPlayerScripts[i].nightVisionRadar).enabled = false;
			Debug.Log((object)"Reviving players B");
			if (allPlayerScripts[i].isPlayerDead)
			{
				allPlayerScripts[i].isPlayerDead = false;
				allPlayerScripts[i].isPlayerControlled = true;
				allPlayerScripts[i].isInElevator = true;
				allPlayerScripts[i].isInHangarShipRoom = true;
				allPlayerScripts[i].isInsideFactory = false;
				allPlayerScripts[i].parentedToElevatorLastFrame = false;
				allPlayerScripts[i].overrideGameOverSpectatePivot = null;
				SetPlayerObjectExtrapolate(enable: false);
				allPlayerScripts[i].TeleportPlayer(GetPlayerSpawnPosition(i));
				allPlayerScripts[i].setPositionOfDeadPlayer = false;
				allPlayerScripts[i].DisablePlayerModel(allPlayerObjects[i], enable: true, disableLocalArms: true);
				((Behaviour)allPlayerScripts[i].helmetLight).enabled = false;
				Debug.Log((object)"Reviving players C");
				allPlayerScripts[i].Crouch(crouch: false);
				allPlayerScripts[i].criticallyInjured = false;
				if ((Object)(object)allPlayerScripts[i].playerBodyAnimator != (Object)null)
				{
					allPlayerScripts[i].playerBodyAnimator.SetBool("Limp", false);
				}
				allPlayerScripts[i].bleedingHeavily = false;
				allPlayerScripts[i].activatingItem = false;
				allPlayerScripts[i].twoHanded = false;
				allPlayerScripts[i].inShockingMinigame = false;
				allPlayerScripts[i].inSpecialInteractAnimation = false;
				allPlayerScripts[i].freeRotationInInteractAnimation = false;
				allPlayerScripts[i].disableSyncInAnimation = false;
				allPlayerScripts[i].inAnimationWithEnemy = null;
				allPlayerScripts[i].holdingWalkieTalkie = false;
				allPlayerScripts[i].speakingToWalkieTalkie = false;
				Debug.Log((object)"Reviving players D");
				allPlayerScripts[i].isSinking = false;
				allPlayerScripts[i].isUnderwater = false;
				allPlayerScripts[i].sinkingValue = 0f;
				allPlayerScripts[i].statusEffectAudio.Stop();
				allPlayerScripts[i].DisableJetpackControlsLocally();
				allPlayerScripts[i].health = 100;
				Debug.Log((object)"Reviving players E");
				allPlayerScripts[i].mapRadarDotAnimator.SetBool("dead", false);
				allPlayerScripts[i].externalForceAutoFade = Vector3.zero;
				if (((NetworkBehaviour)allPlayerScripts[i]).IsOwner)
				{
					HUDManager.Instance.gasHelmetAnimator.SetBool("gasEmitting", false);
					allPlayerScripts[i].hasBegunSpectating = false;
					HUDManager.Instance.RemoveSpectateUI();
					HUDManager.Instance.gameOverAnimator.SetTrigger("revive");
					allPlayerScripts[i].hinderedMultiplier = 1f;
					allPlayerScripts[i].isMovementHindered = 0;
					allPlayerScripts[i].sourcesCausingSinking = 0;
					Debug.Log((object)"Reviving players E2");
					allPlayerScripts[i].reverbPreset = shipReverb;
				}
			}
			Debug.Log((object)"Reviving players F");
			SoundManager.Instance.earsRingingTimer = 0f;
			allPlayerScripts[i].voiceMuffledByEnemy = false;
			SoundManager.Instance.playerVoicePitchTargets[i] = 1f;
			SoundManager.Instance.SetPlayerPitch(1f, i);
			if ((Object)(object)allPlayerScripts[i].currentVoiceChatIngameSettings == (Object)null)
			{
				RefreshPlayerVoicePlaybackObjects();
			}
			if ((Object)(object)allPlayerScripts[i].currentVoiceChatIngameSettings != (Object)null)
			{
				if ((Object)(object)allPlayerScripts[i].currentVoiceChatIngameSettings.voiceAudio == (Object)null)
				{
					allPlayerScripts[i].currentVoiceChatIngameSettings.InitializeComponents();
				}
				if ((Object)(object)allPlayerScripts[i].currentVoiceChatIngameSettings.voiceAudio == (Object)null)
				{
					return;
				}
				((Component)allPlayerScripts[i].currentVoiceChatIngameSettings.voiceAudio).GetComponent<OccludeAudio>().overridingLowPass = false;
			}
			Debug.Log((object)"Reviving players G");
		}
		PlayerControllerB playerControllerB = GameNetworkManager.Instance.localPlayerController;
		playerControllerB.bleedingHeavily = false;
		playerControllerB.criticallyInjured = false;
		playerControllerB.playerBodyAnimator.SetBool("Limp", false);
		playerControllerB.health = 100;
		HUDManager.Instance.UpdateHealthUI(100, hurtPlayer: false);
		playerControllerB.spectatedPlayerScript = null;
		((Behaviour)HUDManager.Instance.audioListenerLowPass).enabled = false;
		Debug.Log((object)"Reviving players H");
		SetSpectateCameraToGameOverMode(enableGameOver: false, playerControllerB);
		RagdollGrabbableObject[] array = Object.FindObjectsOfType<RagdollGrabbableObject>();
		for (int j = 0; j < array.Length; j++)
		{
			if (!array[j].isHeld)
			{
				if (((NetworkBehaviour)this).IsServer)
				{
					if (((NetworkBehaviour)array[j]).NetworkObject.IsSpawned)
					{
						((NetworkBehaviour)array[j]).NetworkObject.Despawn(true);
					}
					else
					{
						Object.Destroy((Object)(object)((Component)array[j]).gameObject);
					}
				}
			}
			else if (array[j].isHeld && (Object)(object)array[j].playerHeldBy != (Object)null)
			{
				array[j].playerHeldBy.DropAllHeldItems();
			}
		}
		DeadBodyInfo[] array2 = Object.FindObjectsOfType<DeadBodyInfo>(true);
		for (int k = 0; k < array2.Length; k++)
		{
			Object.Destroy((Object)(object)((Component)array2[k]).gameObject);
		}
		livingPlayers = connectedPlayersAmount + 1;
		allPlayersDead = false;
		UpdatePlayerVoiceEffects();
		ResetMiscValues();
	}

	private void ResetMiscValues()
	{
		shipAnimator.ResetTrigger("ShipLeave");
	}

	public void RefreshPlayerVoicePlaybackObjects()
	{
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		PlayerVoiceIngameSettings[] array = Object.FindObjectsOfType<PlayerVoiceIngameSettings>(true);
		Debug.Log((object)$"Refreshing voice playback objects. Number of voice objects found: {array.Length}");
		for (int i = 0; i < allPlayerScripts.Length; i++)
		{
			PlayerControllerB playerControllerB = allPlayerScripts[i];
			if (!playerControllerB.isPlayerControlled && !playerControllerB.isPlayerDead)
			{
				Debug.Log((object)$"Skipping player #{i} as they are not controlled or dead");
				continue;
			}
			for (int j = 0; j < array.Length; j++)
			{
				if (array[j]._playerState == null)
				{
					array[j].FindPlayerIfNull();
					if (array[j]._playerState == null)
					{
						Debug.LogError((object)$"Unable to connect player to voice B #{i}; {((Behaviour)array[j]).isActiveAndEnabled}; {array[j]._playerState == null}");
					}
				}
				else if (!((Behaviour)array[j]).isActiveAndEnabled)
				{
					Debug.LogError((object)$"Unable to connect player to voice A #{i}; {((Behaviour)array[j]).isActiveAndEnabled}; {array[j]._playerState == null}");
				}
				else if (array[j]._playerState.Name == ((Component)playerControllerB).gameObject.GetComponentInChildren<NfgoPlayer>().PlayerId)
				{
					Debug.Log((object)$"Found a match for voice object #{j} and player object #{i}");
					playerControllerB.voicePlayerState = array[j]._playerState;
					playerControllerB.currentVoiceChatAudioSource = array[j].voiceAudio;
					playerControllerB.currentVoiceChatIngameSettings = array[j];
					playerControllerB.currentVoiceChatAudioSource.outputAudioMixerGroup = SoundManager.Instance.playerVoiceMixers[playerControllerB.playerClientId];
					Debug.Log((object)$"player voice chat audiosource: {playerControllerB.currentVoiceChatAudioSource}; set audiomixer to {SoundManager.Instance.playerVoiceMixers[playerControllerB.playerClientId]} ; {playerControllerB.currentVoiceChatAudioSource.outputAudioMixerGroup} ; {playerControllerB.playerClientId}");
				}
			}
		}
	}

	public void UpdatePlayerVoiceEffects()
	{
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		updatePlayerVoiceInterval = 2f;
		PlayerControllerB playerControllerB = ((!GameNetworkManager.Instance.localPlayerController.isPlayerDead || !((Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript != (Object)null)) ? GameNetworkManager.Instance.localPlayerController : GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript);
		for (int i = 0; i < allPlayerScripts.Length; i++)
		{
			PlayerControllerB playerControllerB2 = allPlayerScripts[i];
			if ((!playerControllerB2.isPlayerControlled && !playerControllerB2.isPlayerDead) || (Object)(object)playerControllerB2 == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				continue;
			}
			if (playerControllerB2.voicePlayerState == null || playerControllerB2.currentVoiceChatIngameSettings._playerState == null || (Object)(object)playerControllerB2.currentVoiceChatAudioSource == (Object)null)
			{
				RefreshPlayerVoicePlaybackObjects();
				if (playerControllerB2.voicePlayerState == null || (Object)(object)playerControllerB2.currentVoiceChatAudioSource == (Object)null)
				{
					Debug.Log((object)$"Was not able to access voice chat object for player #{i}; {playerControllerB2.voicePlayerState == null}; {(Object)(object)playerControllerB2.currentVoiceChatAudioSource == (Object)null}");
					continue;
				}
			}
			AudioSource currentVoiceChatAudioSource = allPlayerScripts[i].currentVoiceChatAudioSource;
			bool flag = playerControllerB2.speakingToWalkieTalkie && playerControllerB.holdingWalkieTalkie && (Object)(object)playerControllerB2 != (Object)(object)playerControllerB;
			if (playerControllerB2.isPlayerDead)
			{
				((Behaviour)((Component)currentVoiceChatAudioSource).GetComponent<AudioLowPassFilter>()).enabled = false;
				((Behaviour)((Component)currentVoiceChatAudioSource).GetComponent<AudioHighPassFilter>()).enabled = false;
				currentVoiceChatAudioSource.panStereo = 0f;
				SoundManager.Instance.playerVoicePitchTargets[playerControllerB2.playerClientId] = 1f;
				SoundManager.Instance.SetPlayerPitch(1f, (int)playerControllerB2.playerClientId);
				if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
				{
					currentVoiceChatAudioSource.spatialBlend = 0f;
					playerControllerB2.currentVoiceChatIngameSettings.set2D = true;
					playerControllerB2.voicePlayerState.Volume = 1f;
				}
				else
				{
					currentVoiceChatAudioSource.spatialBlend = 1f;
					playerControllerB2.currentVoiceChatIngameSettings.set2D = false;
					playerControllerB2.voicePlayerState.Volume = 0f;
				}
				continue;
			}
			AudioLowPassFilter component = ((Component)currentVoiceChatAudioSource).GetComponent<AudioLowPassFilter>();
			OccludeAudio component2 = ((Component)currentVoiceChatAudioSource).GetComponent<OccludeAudio>();
			((Behaviour)component).enabled = true;
			component2.overridingLowPass = flag || allPlayerScripts[i].voiceMuffledByEnemy;
			((Behaviour)((Component)currentVoiceChatAudioSource).GetComponent<AudioHighPassFilter>()).enabled = flag;
			if (!flag)
			{
				currentVoiceChatAudioSource.spatialBlend = 1f;
				playerControllerB2.currentVoiceChatIngameSettings.set2D = false;
				currentVoiceChatAudioSource.bypassListenerEffects = false;
				currentVoiceChatAudioSource.bypassEffects = false;
				currentVoiceChatAudioSource.outputAudioMixerGroup = SoundManager.Instance.playerVoiceMixers[playerControllerB2.playerClientId];
				component.lowpassResonanceQ = 1f;
			}
			else
			{
				currentVoiceChatAudioSource.spatialBlend = 0f;
				playerControllerB2.currentVoiceChatIngameSettings.set2D = true;
				if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
				{
					currentVoiceChatAudioSource.panStereo = 0f;
					currentVoiceChatAudioSource.outputAudioMixerGroup = SoundManager.Instance.playerVoiceMixers[playerControllerB2.playerClientId];
					currentVoiceChatAudioSource.bypassListenerEffects = false;
					currentVoiceChatAudioSource.bypassEffects = false;
				}
				else
				{
					currentVoiceChatAudioSource.panStereo = 0.4f;
					currentVoiceChatAudioSource.bypassListenerEffects = false;
					currentVoiceChatAudioSource.bypassEffects = false;
					currentVoiceChatAudioSource.outputAudioMixerGroup = SoundManager.Instance.playerVoiceMixers[playerControllerB2.playerClientId];
				}
				component2.lowPassOverride = 4000f;
				component.lowpassResonanceQ = 3f;
			}
			if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
			{
				playerControllerB2.voicePlayerState.Volume = 0.8f;
			}
			else
			{
				playerControllerB2.voicePlayerState.Volume = 1f;
			}
		}
	}

	[ServerRpc]
	public void SetShipDoorsOverheatServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2578118202u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2578118202u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetShipDoorsOverheatClientRpc();
		}
	}

	[ClientRpc]
	public void SetShipDoorsOverheatClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1864501499u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1864501499u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				SetShipDoorsOverheatLocalClient();
			}
		}
	}

	public void SetShipDoorsOverheatLocalClient()
	{
		HangarShipDoor hangarShipDoor = Object.FindObjectOfType<HangarShipDoor>();
		hangarShipDoor.PlayDoorAnimation(closed: false);
		hangarShipDoor.overheated = true;
		hangarShipDoor.triggerScript.interactable = false;
	}

	public void SetShipDoorsClosed(bool closed)
	{
		hangarDoorsClosed = closed;
		SetPlayerSafeInShip();
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetDoorsClosedServerRpc(bool closed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(430165634u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref closed, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 430165634u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetDoorsClosedClientRpc(closed);
			}
		}
	}

	[ClientRpc]
	public void SetDoorsClosedClientRpc(bool closed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2810194347u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref closed, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2810194347u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SetShipDoorsClosed(closed);
			}
		}
	}

	public void SetPlayerSafeInShip()
	{
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		PlayerControllerB playerControllerB = GameNetworkManager.Instance.localPlayerController;
		if (playerControllerB.isPlayerDead && (Object)(object)playerControllerB.spectatedPlayerScript != (Object)null)
		{
			playerControllerB = playerControllerB.spectatedPlayerScript;
		}
		EnemyAI[] array = Object.FindObjectsOfType<EnemyAI>();
		if (hangarDoorsClosed && GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom)
		{
			for (int i = 0; i < array.Length; i++)
			{
				array[i].EnableEnemyMesh(array[i].isInsidePlayerShip);
			}
		}
		else
		{
			for (int j = 0; j < array.Length; j++)
			{
				array[j].EnableEnemyMesh(enable: true);
			}
		}
	}

	public bool CanChangeLevels()
	{
		if (!travellingToNewLevel)
		{
			return inShipPhase;
		}
		return false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void ChangeLevelServerRpc(int levelID, int newGroupCreditsAmount)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1134466287u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, levelID);
			BytePacker.WriteValueBitPacked(val2, newGroupCreditsAmount);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1134466287u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			Debug.Log((object)$"Changing level server rpc {levelID}");
			if (!travellingToNewLevel && inShipPhase && newGroupCreditsAmount <= Object.FindObjectOfType<Terminal>().groupCredits && !isChallengeFile)
			{
				Object.FindObjectOfType<Terminal>().groupCredits = newGroupCreditsAmount;
				travellingToNewLevel = true;
				ChangeLevelClientRpc(levelID, newGroupCreditsAmount);
			}
			else
			{
				CancelChangeLevelClientRpc(Object.FindObjectOfType<Terminal>().groupCredits);
			}
		}
	}

	[ClientRpc]
	public void CancelChangeLevelClientRpc(int groupCreditsAmount)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3896714546u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, groupCreditsAmount);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3896714546u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				Object.FindObjectOfType<Terminal>().groupCredits = groupCreditsAmount;
				Object.FindObjectOfType<Terminal>().useCreditsCooldown = false;
			}
		}
	}

	[ClientRpc]
	public void ChangeLevelClientRpc(int levelID, int newGroupCreditsAmount)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(167566585u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, levelID);
			BytePacker.WriteValueBitPacked(val2, newGroupCreditsAmount);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 167566585u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			Object.FindObjectOfType<Terminal>().useCreditsCooldown = false;
			ChangeLevel(levelID);
			travellingToNewLevel = true;
			if (shipTravelCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(shipTravelCoroutine);
			}
			shipTravelCoroutine = ((MonoBehaviour)this).StartCoroutine(TravelToLevelEffects());
			if (!((NetworkBehaviour)this).IsServer)
			{
				Object.FindObjectOfType<Terminal>().groupCredits = newGroupCreditsAmount;
			}
		}
	}

	public void ChangeLevel(int levelID)
	{
		Debug.Log((object)$"level id: {levelID}");
		Debug.Log((object)"Changing level");
		currentLevel = levels[levelID];
		currentLevelID = levelID;
		TimeOfDay.Instance.currentLevel = currentLevel;
		RoundManager.Instance.currentLevel = levels[levelID];
		SoundManager.Instance.ResetSoundType();
	}

	private IEnumerator TravelToLevelEffects()
	{
		StartMatchLever lever = Object.FindObjectOfType<StartMatchLever>();
		lever.triggerScript.interactable = false;
		shipAmbianceAudio.PlayOneShot(shipDepartSFX);
		currentPlanetAnimator.SetTrigger("FlyAway");
		((Component)shipAnimatorObject).gameObject.GetComponent<Animator>().SetBool("FlyingToNewPlanet", true);
		HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
		yield return (object)new WaitForSeconds(2f);
		if ((Object)(object)currentPlanetPrefab != (Object)null)
		{
			Object.Destroy((Object)(object)currentPlanetPrefab);
		}
		yield return (object)new WaitForSeconds(currentLevel.timeToArrive);
		ArriveAtLevel();
		if (((NetworkBehaviour)this).IsServer || GameNetworkManager.Instance.gameHasStarted)
		{
			lever.triggerScript.interactable = true;
		}
		for (int i = 0; i < 20; i++)
		{
			AudioSource obj = shipAmbianceAudio;
			obj.volume -= 0.05f;
			yield return null;
		}
		yield return (object)new WaitForSeconds(0.02f);
		shipAmbianceAudio.Stop();
		shipAmbianceAudio.volume = 1f;
		shipAmbianceAudio.PlayOneShot(shipArriveSFX);
	}

	public void ArriveAtLevel()
	{
		Debug.Log((object)$"Level id: {currentLevel.levelID}");
		TimeOfDay timeOfDay = Object.FindObjectOfType<TimeOfDay>();
		outerSpaceSunAnimator.SetFloat("currentTime", timeOfDay.CalculatePlanetTime(currentLevel) / timeOfDay.totalTime + 1f);
		timeOfDay.currentLevel = currentLevel;
		travellingToNewLevel = false;
		ChangePlanet();
		currentPlanetAnimator.SetTrigger("FlyTo");
		((Component)shipAnimatorObject).gameObject.GetComponent<Animator>().SetBool("FlyingToNewPlanet", false);
		SetMapScreenInfoToCurrentLevel();
		Object.FindObjectOfType<StartMatchLever>().hasDisplayedTimeWarning = false;
		Debug.Log((object)$"Current level null?: {(Object)(object)currentLevel == (Object)null}");
		Debug.Log((object)("Current level planet name: " + currentLevel.PlanetName));
		if (!GameNetworkManager.Instance.disableSteam)
		{
			SteamFriends.SetRichPresence("moonname", currentLevel.PlanetName);
			GameNetworkManager.Instance.SetSteamFriendGrouping(GameNetworkManager.Instance.steamLobbyName, connectedPlayersAmount + 1, "#Status_Orbiting");
		}
		SetDiscordStatusDetails();
	}

	public void ChangePlanet()
	{
		if ((Object)(object)currentPlanetPrefab != (Object)null)
		{
			Object.Destroy((Object)(object)currentPlanetPrefab);
		}
		currentPlanetPrefab = Object.Instantiate<GameObject>(currentLevel.planetPrefab, planetContainer, false);
		currentPlanetAnimator = currentPlanetPrefab.GetComponentInChildren<Animator>();
		Object.FindObjectOfType<TimeOfDay>().currentLevel = currentLevel;
		SetMapScreenInfoToCurrentLevel();
	}

	public void SetMapScreenInfoToCurrentLevel()
	{
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		((Behaviour)screenLevelVideoReel).enabled = false;
		((Component)screenLevelVideoReel).gameObject.SetActive(false);
		screenLevelVideoReel.clip = currentLevel.videoReel;
		TimeOfDay timeOfDay = Object.FindObjectOfType<TimeOfDay>();
		if (timeOfDay.totalTime == 0f)
		{
			timeOfDay.totalTime = (float)timeOfDay.numberOfHours * timeOfDay.lengthOfHours;
		}
		string text = ((currentLevel.currentWeather == LevelWeatherType.None) ? "" : ("Weather: " + currentLevel.currentWeather));
		string levelDescription = currentLevel.LevelDescription;
		if (isChallengeFile)
		{
			((TMP_Text)screenLevelDescription).text = "Orbiting: " + GameNetworkManager.Instance.GetNameForWeekNumber() + "\n" + levelDescription + "\n" + text;
		}
		else
		{
			((TMP_Text)screenLevelDescription).text = "Orbiting: " + currentLevel.PlanetName + "\n" + levelDescription + "\n" + text;
		}
		mapScreen.overrideCameraForOtherUse = true;
		((Component)mapScreen.cam).transform.position = new Vector3(0f, 100f, 0f);
		((Behaviour)screenLevelDescription).enabled = true;
		mapScreen.mapCamera.nearClipPlane = -0.96f;
		mapScreen.mapCamera.farClipPlane = 7.52f;
		radarCanvas.planeDistance = -0.93f;
		if ((Object)(object)currentLevel.videoReel != (Object)null && !isChallengeFile)
		{
			((Behaviour)screenLevelVideoReel).enabled = true;
			((Component)screenLevelVideoReel).gameObject.SetActive(true);
			screenLevelVideoReel.Play();
		}
	}

	public void SwitchMapMonitorPurpose(bool displayInfo = false)
	{
		if (displayInfo)
		{
			((Behaviour)screenLevelVideoReel).enabled = true;
			((Component)screenLevelVideoReel).gameObject.SetActive(true);
			((Behaviour)screenLevelDescription).enabled = true;
			((Behaviour)mapScreenPlayerName).enabled = false;
			((Behaviour)mapScreen.localPlayerPlaceholder).enabled = false;
			((Behaviour)mapScreenPlayerNameBG).enabled = false;
			mapScreen.overrideCameraForOtherUse = true;
			mapScreen.SwitchScreenOn();
			((Behaviour)mapScreen.cam).enabled = true;
			((Behaviour)mapScreen.compassRose).enabled = false;
			Terminal terminal = Object.FindObjectOfType<Terminal>();
			terminal.displayingPersistentImage = null;
			((Behaviour)terminal.terminalImage).enabled = false;
		}
		else
		{
			((Behaviour)screenLevelVideoReel).enabled = false;
			((Component)screenLevelVideoReel).gameObject.SetActive(false);
			((Behaviour)screenLevelDescription).enabled = false;
			((Behaviour)mapScreenPlayerName).enabled = true;
			((Behaviour)mapScreenPlayerNameBG).enabled = true;
			mapScreen.overrideCameraForOtherUse = false;
			((Behaviour)mapScreen.compassRose).enabled = true;
		}
	}

	public void PowerSurgeShip()
	{
		mapScreen.SwitchScreenOn(on: false);
		if (((NetworkBehaviour)this).IsServer)
		{
			if (Object.op_Implicit((Object)(object)Object.FindObjectOfType<TVScript>()))
			{
				Object.FindObjectOfType<TVScript>().TurnOffTVServerRpc();
			}
			shipRoomLights.SetShipLightsServerRpc(setLightsOn: false);
			SurgePowerServerRpc();
		}
	}

	[ServerRpc]
	public void SurgePowerServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1165604590u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1165604590u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SurgePowerClientRpc();
		}
	}

	[ClientRpc]
	public void SurgePowerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(670705935u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 670705935u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				((UnityEvent)ShipPowerSurgedEvent).Invoke();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncCompanyBuyingRateServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2249588995u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2249588995u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SyncCompanyBuyingRateClientRpc(companyBuyingRate);
			}
		}
	}

	[ClientRpc]
	public void SyncCompanyBuyingRateClientRpc(float buyingRate)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3519313816u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref buyingRate, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3519313816u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				companyBuyingRate = buyingRate;
			}
		}
	}

	private void TeleportPlayerInShipIfOutOfRoomBounds()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)testRoom != (Object)null))
		{
			Bounds bounds = shipInnerRoomBounds.bounds;
			if (!((Bounds)(ref bounds)).Contains(((Component)GameNetworkManager.Instance.localPlayerController).transform.position))
			{
				GameNetworkManager.Instance.localPlayerController.TeleportPlayer(GetPlayerSpawnPosition((int)GameNetworkManager.Instance.localPlayerController.playerClientId, simpleTeleport: true));
			}
		}
	}

	public void LateUpdate()
	{
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		if (updatePlayerVoiceInterval > 5f)
		{
			updatePlayerVoiceInterval = 0f;
			UpdatePlayerVoiceEffects();
		}
		else
		{
			updatePlayerVoiceInterval += Time.deltaTime;
		}
		if (!inShipPhase && shipDoorsEnabled && !suckingPlayersOutOfShip)
		{
			if (((Component)GameNetworkManager.Instance.localPlayerController).transform.position.y < -600f)
			{
				GameNetworkManager.Instance.localPlayerController.KillPlayer(Vector3.zero, spawnBody: false, CauseOfDeath.Gravity);
			}
			else
			{
				Bounds bounds;
				if (GameNetworkManager.Instance.localPlayerController.isInElevator)
				{
					bounds = shipBounds.bounds;
					if (!((Bounds)(ref bounds)).Contains(((Component)GameNetworkManager.Instance.localPlayerController).transform.position) && GameNetworkManager.Instance.localPlayerController.thisController.isGrounded)
					{
						GameNetworkManager.Instance.localPlayerController.SetAllItemsInElevator(inShipRoom: false, inElevator: false);
						GameNetworkManager.Instance.localPlayerController.isInElevator = false;
						GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom = false;
						goto IL_0219;
					}
				}
				if (!GameNetworkManager.Instance.localPlayerController.isInElevator)
				{
					bounds = shipBounds.bounds;
					if (((Bounds)(ref bounds)).Contains(((Component)GameNetworkManager.Instance.localPlayerController).transform.position) && GameNetworkManager.Instance.localPlayerController.thisController.isGrounded)
					{
						GameNetworkManager.Instance.localPlayerController.isInElevator = true;
						bounds = shipInnerRoomBounds.bounds;
						if (((Bounds)(ref bounds)).Contains(((Component)GameNetworkManager.Instance.localPlayerController).transform.position) && GameNetworkManager.Instance.localPlayerController.thisController.isGrounded)
						{
							GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom = true;
						}
						else
						{
							GameNetworkManager.Instance.localPlayerController.SetAllItemsInElevator(inShipRoom: false, inElevator: true);
						}
					}
				}
			}
		}
		else if (!suckingPlayersOutOfShip)
		{
			TeleportPlayerInShipIfOutOfRoomBounds();
		}
		goto IL_0219;
		IL_0219:
		if (suckingPlayersOutOfShip)
		{
			starSphereObject.transform.position = ((Component)GameNetworkManager.Instance.localPlayerController).transform.position;
			currentPlanetPrefab.transform.position = ((Component)GameNetworkManager.Instance.localPlayerController).transform.position + new Vector3(-101f, -65f, 160f);
		}
		if (fearLevelIncreasing)
		{
			fearLevelIncreasing = false;
		}
		else if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			fearLevel -= Time.deltaTime * 0.5f;
		}
		else
		{
			fearLevel -= Time.deltaTime * 0.055f;
		}
	}

	public override void OnDestroy()
	{
		((NetworkBehaviour)this).OnDestroy();
	}

	[ServerRpc]
	public void Debug_EnableTestRoomServerRpc(bool enable)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3050994254u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enable, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3050994254u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost) || !Application.isEditor)
		{
			return;
		}
		if (enable)
		{
			testRoom = Object.Instantiate<GameObject>(testRoomPrefab, testRoomSpawnPosition.position, testRoomSpawnPosition.rotation, testRoomSpawnPosition);
			testRoom.GetComponent<NetworkObject>().Spawn(false);
		}
		else if ((Object)(object)Instance.testRoom != (Object)null)
		{
			if (!testRoom.GetComponent<NetworkObject>().IsSpawned)
			{
				Object.Destroy((Object)(object)testRoom);
			}
			else
			{
				testRoom.GetComponent<NetworkObject>().Despawn(true);
			}
		}
		if (enable)
		{
			Debug_EnableTestRoomClientRpc(enable, NetworkObjectReference.op_Implicit(testRoom.GetComponent<NetworkObject>()));
		}
		else
		{
			Debug_EnableTestRoomClientRpc(enable);
		}
	}

	public bool IsClientFriendsWithHost()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (!GameNetworkManager.Instance.disableSteam && !NetworkManager.Singleton.IsServer)
		{
			SteamFriends.GetFriends().ToList();
			Friend val = default(Friend);
			((Friend)(ref val))._002Ector(SteamId.op_Implicit(allPlayerScripts[0].playerSteamId));
			Debug.Log((object)$"Host steam friend id: {allPlayerScripts[0].playerSteamId}, user: {((Friend)(ref val)).Name}; is friend?: {((Friend)(ref val)).IsFriend}");
			if (!((Friend)(ref val)).IsFriend)
			{
				return false;
			}
		}
		return true;
	}

	[ClientRpc]
	public void Debug_EnableTestRoomClientRpc(bool enable, NetworkObjectReference objectRef = default(NetworkObjectReference))
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(375322246u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enable, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 375322246u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && IsClientFriendsWithHost())
		{
			QuickMenuManager quickMenuManager = Object.FindObjectOfType<QuickMenuManager>();
			for (int i = 0; i < quickMenuManager.doorGameObjects.Length; i++)
			{
				quickMenuManager.doorGameObjects[i].SetActive(!enable);
			}
			quickMenuManager.outOfBoundsCollider.enabled = !enable;
			if (enable)
			{
				((MonoBehaviour)this).StartCoroutine(SetTestRoomDebug(objectRef));
			}
			else if ((Object)(object)testRoom != (Object)null)
			{
				Object.Destroy((Object)(object)testRoom);
			}
		}
	}

	private IEnumerator SetTestRoomDebug(NetworkObjectReference objectRef)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		NetworkObject testRoomNetObject = null;
		yield return (object)new WaitUntil((Func<bool>)(() => ((NetworkObjectReference)(ref objectRef)).TryGet(ref testRoomNetObject, (NetworkManager)null)));
		if (!((Object)(object)testRoomNetObject == (Object)null))
		{
			Instance.testRoom = ((Component)testRoomNetObject).gameObject;
		}
	}

	[ServerRpc]
	public void Debug_ToggleAllowDeathServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3186641109u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3186641109u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && Application.isEditor)
		{
			allowLocalPlayerDeath = !allowLocalPlayerDeath;
			Debug_ToggleAllowDeathClientRpc(allowLocalPlayerDeath);
		}
	}

	[ClientRpc]
	public void Debug_ToggleAllowDeathClientRpc(bool allowDeath)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(348115853u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref allowDeath, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 348115853u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && IsClientFriendsWithHost() && !((NetworkBehaviour)this).IsServer)
			{
				allowLocalPlayerDeath = allowDeath;
			}
		}
	}

	[ServerRpc]
	public void Debug_ReviveAllPlayersServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2339227601u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2339227601u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && Application.isEditor)
		{
			Debug_ReviveAllPlayersClientRpc();
		}
	}

	[ClientRpc]
	public void Debug_ReviveAllPlayersClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1279156295u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1279156295u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && IsClientFriendsWithHost() && !((NetworkBehaviour)this).IsServer)
			{
				ReviveDeadPlayers();
				HUDManager.Instance.HideHUD(hide: false);
			}
		}
	}

	public void SetDiscordStatusDetails()
	{
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)DiscordController.Instance == (Object)null || GameNetworkManager.Instance.disableSteam)
		{
			return;
		}
		DiscordController.Instance.status_largeText = "";
		if ((Object)(object)currentLevel != (Object)null)
		{
			if (firingPlayersCutsceneRunning)
			{
				DiscordController.Instance.status_Details = "Getting fired";
				DiscordController.Instance.status_largeImage = "mapfired";
			}
			else if (!GameNetworkManager.Instance.gameHasStarted)
			{
				DiscordController.Instance.status_Details = "In orbit (Waiting for crew)";
				DiscordController.Instance.status_largeImage = "mapshipicon";
			}
			else if (inShipPhase)
			{
				DiscordController.Instance.status_Details = "Orbiting " + currentLevel.PlanetName;
				DiscordController.Instance.status_largeImage = "mapshipicon";
			}
			else
			{
				DiscordController.Instance.status_Details = HUDManager.Instance.SetClock(TimeOfDay.Instance.normalizedTimeOfDay, TimeOfDay.Instance.numberOfHours, createNewLine: false);
				DiscordController.Instance.status_largeText = "On " + currentLevel.PlanetName;
				if (currentLevel.levelIconString != "")
				{
					DiscordController.Instance.status_largeImage = currentLevel.levelIconString;
				}
			}
			if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
			{
				if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
				{
					DiscordController.Instance.status_smallText = "Deceased";
					DiscordController.Instance.status_smallImage = "faceiconwhitev1big";
				}
				else
				{
					DiscordController.Instance.status_smallText = "";
					DiscordController.Instance.status_smallImage = "faceiconorangev1big";
				}
			}
		}
		else
		{
			DiscordController.Instance.status_Details = "In orbit";
			DiscordController.Instance.status_smallText = "";
			DiscordController.Instance.status_smallImage = "faceiconorangev1big";
		}
		DiscordController.Instance.currentPartySize = connectedPlayersAmount + 1;
		DiscordController.Instance.maxPartySize = GameNetworkManager.Instance.maxAllowedPlayers;
		if ((Object)(object)RoundManager.Instance != (Object)null && inShipPhase)
		{
			float num = (float)GetValueOfAllScrap() / (float)TimeOfDay.Instance.profitQuota * 100f;
			DiscordController.Instance.status_State = $"{(int)num}% of quota | {TimeOfDay.Instance.daysUntilDeadline} days left";
		}
		DiscordController.Instance.timeElapsed = (int)(Time.realtimeSinceStartup - timeAtStartOfRun) / 60;
		if (GameNetworkManager.Instance.currentLobby.HasValue)
		{
			DiscordController instance = DiscordController.Instance;
			Lobby value = GameNetworkManager.Instance.currentLobby.Value;
			instance.status_partyId = Convert.ToString(SteamId.op_Implicit(((Lobby)(ref value)).Owner.Id));
		}
		DiscordController.Instance.UpdateStatus(clear: false);
	}

	public int GetValueOfAllScrap(bool onlyScrapCollected = true, bool onlyNewScrap = false)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		GrabbableObject[] array = Object.FindObjectsOfType<GrabbableObject>();
		int num = 0;
		for (int i = 0; i < array.Length; i++)
		{
			Bounds bounds = shipInnerRoomBounds.bounds;
			if (((Bounds)(ref bounds)).Contains(((Component)array[i]).transform.position))
			{
				array[i].isInShipRoom = true;
			}
		}
		for (int j = 0; j < array.Length; j++)
		{
			if ((!onlyNewScrap || !array[j].scrapPersistedThroughRounds) && array[j].itemProperties.isScrap && !array[j].deactivated && !array[j].itemUsedUp && (array[j].isInShipRoom || !onlyScrapCollected))
			{
				num += array[j].scrapValue;
			}
		}
		return num;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_StartOfRound()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Expected O, but got Unknown
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Expected O, but got Unknown
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Expected O, but got Unknown
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Expected O, but got Unknown
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Expected O, but got Unknown
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Expected O, but got Unknown
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Expected O, but got Unknown
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Expected O, but got Unknown
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Expected O, but got Unknown
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Expected O, but got Unknown
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Expected O, but got Unknown
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Expected O, but got Unknown
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Expected O, but got Unknown
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Expected O, but got Unknown
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Expected O, but got Unknown
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Expected O, but got Unknown
		//IL_0413: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Expected O, but got Unknown
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Expected O, but got Unknown
		//IL_0449: Unknown result type (might be due to invalid IL or missing references)
		//IL_0453: Expected O, but got Unknown
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Expected O, but got Unknown
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Expected O, but got Unknown
		//IL_049a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a4: Expected O, but got Unknown
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bf: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3212216718u, new RpcReceiveHandler(__rpc_handler_3212216718));
		NetworkManager.__rpc_func_table.Add(2773812843u, new RpcReceiveHandler(__rpc_handler_2773812843));
		NetworkManager.__rpc_func_table.Add(4249638645u, new RpcReceiveHandler(__rpc_handler_4249638645));
		NetworkManager.__rpc_func_table.Add(462348217u, new RpcReceiveHandler(__rpc_handler_462348217));
		NetworkManager.__rpc_func_table.Add(161788012u, new RpcReceiveHandler(__rpc_handler_161788012));
		NetworkManager.__rpc_func_table.Add(3953483456u, new RpcReceiveHandler(__rpc_handler_3953483456));
		NetworkManager.__rpc_func_table.Add(418581783u, new RpcReceiveHandler(__rpc_handler_418581783));
		NetworkManager.__rpc_func_table.Add(3380566632u, new RpcReceiveHandler(__rpc_handler_3380566632));
		NetworkManager.__rpc_func_table.Add(1076853239u, new RpcReceiveHandler(__rpc_handler_1076853239));
		NetworkManager.__rpc_func_table.Add(1846610026u, new RpcReceiveHandler(__rpc_handler_1846610026));
		NetworkManager.__rpc_func_table.Add(2369901769u, new RpcReceiveHandler(__rpc_handler_2369901769));
		NetworkManager.__rpc_func_table.Add(475465488u, new RpcReceiveHandler(__rpc_handler_475465488));
		NetworkManager.__rpc_func_table.Add(886676601u, new RpcReceiveHandler(__rpc_handler_886676601));
		NetworkManager.__rpc_func_table.Add(682230258u, new RpcReceiveHandler(__rpc_handler_682230258));
		NetworkManager.__rpc_func_table.Add(1613265729u, new RpcReceiveHandler(__rpc_handler_1613265729));
		NetworkManager.__rpc_func_table.Add(744998938u, new RpcReceiveHandler(__rpc_handler_744998938));
		NetworkManager.__rpc_func_table.Add(765506029u, new RpcReceiveHandler(__rpc_handler_765506029));
		NetworkManager.__rpc_func_table.Add(1089447320u, new RpcReceiveHandler(__rpc_handler_1089447320));
		NetworkManager.__rpc_func_table.Add(2028434619u, new RpcReceiveHandler(__rpc_handler_2028434619));
		NetworkManager.__rpc_func_table.Add(794862467u, new RpcReceiveHandler(__rpc_handler_794862467));
		NetworkManager.__rpc_func_table.Add(2659636069u, new RpcReceiveHandler(__rpc_handler_2659636069));
		NetworkManager.__rpc_func_table.Add(1043433721u, new RpcReceiveHandler(__rpc_handler_1043433721));
		NetworkManager.__rpc_func_table.Add(1482204640u, new RpcReceiveHandler(__rpc_handler_1482204640));
		NetworkManager.__rpc_func_table.Add(2721053021u, new RpcReceiveHandler(__rpc_handler_2721053021));
		NetworkManager.__rpc_func_table.Add(1068504982u, new RpcReceiveHandler(__rpc_handler_1068504982));
		NetworkManager.__rpc_func_table.Add(2441193238u, new RpcReceiveHandler(__rpc_handler_2441193238));
		NetworkManager.__rpc_func_table.Add(907290724u, new RpcReceiveHandler(__rpc_handler_907290724));
		NetworkManager.__rpc_func_table.Add(3083945322u, new RpcReceiveHandler(__rpc_handler_3083945322));
		NetworkManager.__rpc_func_table.Add(2578118202u, new RpcReceiveHandler(__rpc_handler_2578118202));
		NetworkManager.__rpc_func_table.Add(1864501499u, new RpcReceiveHandler(__rpc_handler_1864501499));
		NetworkManager.__rpc_func_table.Add(430165634u, new RpcReceiveHandler(__rpc_handler_430165634));
		NetworkManager.__rpc_func_table.Add(2810194347u, new RpcReceiveHandler(__rpc_handler_2810194347));
		NetworkManager.__rpc_func_table.Add(1134466287u, new RpcReceiveHandler(__rpc_handler_1134466287));
		NetworkManager.__rpc_func_table.Add(3896714546u, new RpcReceiveHandler(__rpc_handler_3896714546));
		NetworkManager.__rpc_func_table.Add(167566585u, new RpcReceiveHandler(__rpc_handler_167566585));
		NetworkManager.__rpc_func_table.Add(1165604590u, new RpcReceiveHandler(__rpc_handler_1165604590));
		NetworkManager.__rpc_func_table.Add(670705935u, new RpcReceiveHandler(__rpc_handler_670705935));
		NetworkManager.__rpc_func_table.Add(2249588995u, new RpcReceiveHandler(__rpc_handler_2249588995));
		NetworkManager.__rpc_func_table.Add(3519313816u, new RpcReceiveHandler(__rpc_handler_3519313816));
		NetworkManager.__rpc_func_table.Add(3050994254u, new RpcReceiveHandler(__rpc_handler_3050994254));
		NetworkManager.__rpc_func_table.Add(375322246u, new RpcReceiveHandler(__rpc_handler_375322246));
		NetworkManager.__rpc_func_table.Add(3186641109u, new RpcReceiveHandler(__rpc_handler_3186641109));
		NetworkManager.__rpc_func_table.Add(348115853u, new RpcReceiveHandler(__rpc_handler_348115853));
		NetworkManager.__rpc_func_table.Add(2339227601u, new RpcReceiveHandler(__rpc_handler_2339227601));
		NetworkManager.__rpc_func_table.Add(1279156295u, new RpcReceiveHandler(__rpc_handler_1279156295));
	}

	private static void __rpc_handler_3212216718(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool magnetOnServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref magnetOnServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).SetMagnetOnServerRpc(magnetOnServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2773812843(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool magnetOnClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref magnetOnClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).SetMagnetOnClientRpc(magnetOnClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4249638645(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong clientId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).PlayerLoadedServerRpc(clientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_462348217(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong clientId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).PlayerLoadedClientRpc(clientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_161788012(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool landingShip = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref landingShip, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).ResetPlayersLoadedValueClientRpc(landingShip);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3953483456(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int unlockableID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref unlockableID);
			int newGroupCreditsAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newGroupCreditsAmount);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).BuyShipUnlockableServerRpc(unlockableID, newGroupCreditsAmount);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_418581783(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int newGroupCreditsAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newGroupCreditsAmount);
			int unlockableID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref unlockableID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).BuyShipUnlockableClientRpc(newGroupCreditsAmount, unlockableID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3380566632(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int unlockableID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref unlockableID);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).ReturnUnlockableFromStorageServerRpc(unlockableID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1076853239(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int unlockableID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref unlockableID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).ReturnUnlockableFromStorageClientRpc(unlockableID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1846610026(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).SyncSuitsServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2369901769(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).SyncSuitsClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_475465488(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectNumber = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectNumber);
			ulong clientId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientId);
			ClientRpcParams client = rpcParams.Client;
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).OnClientDisconnectClientRpc(playerObjectNumber, clientId, client);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_886676601(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong clientId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientId);
			int connectedPlayers = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref connectedPlayers);
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			ulong[] connectedPlayerIdsOrdered = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<ulong>(ref connectedPlayerIdsOrdered, default(ForPrimitives));
			}
			int assignedPlayerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref assignedPlayerObjectId);
			int serverMoneyAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref serverMoneyAmount);
			int levelID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref levelID);
			int profitQuota = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref profitQuota);
			int timeUntilDeadline = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref timeUntilDeadline);
			int quotaFulfilled = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref quotaFulfilled);
			int randomSeed = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref randomSeed);
			bool isChallenge = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isChallenge, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).OnPlayerConnectedClientRpc(clientId, connectedPlayers, connectedPlayerIdsOrdered, assignedPlayerObjectId, serverMoneyAmount, levelID, profitQuota, timeUntilDeadline, quotaFulfilled, randomSeed, isChallenge);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_682230258(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int joiningClientId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref joiningClientId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).SyncAlreadyHeldObjectsServerRpc(joiningClientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1613265729(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			NetworkObjectReference[] gObjects = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref gObjects, default(ForNetworkSerializable));
			}
			bool flag2 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag2, default(ForPrimitives));
			int[] playersHeldBy = null;
			if (flag2)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref playersHeldBy, default(ForPrimitives));
			}
			bool flag3 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag3, default(ForPrimitives));
			int[] itemSlotNumbers = null;
			if (flag3)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref itemSlotNumbers, default(ForPrimitives));
			}
			bool flag4 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag4, default(ForPrimitives));
			int[] isObjectPocketed = null;
			if (flag4)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref isObjectPocketed, default(ForPrimitives));
			}
			int syncWithClient = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref syncWithClient);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).SyncAlreadyHeldObjectsClientRpc(gObjects, playersHeldBy, itemSlotNumbers, isObjectPocketed, syncWithClient);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_744998938(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).SyncShipUnlockablesServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_765506029(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			int[] playerSuitIDs = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref playerSuitIDs, default(ForPrimitives));
			}
			bool shipLightsOn = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref shipLightsOn, default(ForPrimitives));
			bool flag2 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag2, default(ForPrimitives));
			Vector3[] placeableObjectPositions = null;
			if (flag2)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref placeableObjectPositions);
			}
			bool flag3 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag3, default(ForPrimitives));
			Vector3[] placeableObjectRotations = null;
			if (flag3)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref placeableObjectRotations);
			}
			bool flag4 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag4, default(ForPrimitives));
			bool[] unlockedObjects = null;
			if (flag4)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref unlockedObjects, default(ForPrimitives));
			}
			bool flag5 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag5, default(ForPrimitives));
			int[] storedItems = null;
			if (flag5)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref storedItems, default(ForPrimitives));
			}
			bool flag6 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag6, default(ForPrimitives));
			int[] scrapValues = null;
			if (flag6)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref scrapValues, default(ForPrimitives));
			}
			bool flag7 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag7, default(ForPrimitives));
			int[] itemSaveData = null;
			if (flag7)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref itemSaveData, default(ForPrimitives));
			}
			int vehicleID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref vehicleID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).SyncShipUnlockablesClientRpc(playerSuitIDs, shipLightsOn, placeableObjectPositions, placeableObjectRotations, unlockedObjects, storedItems, scrapValues, itemSaveData, vehicleID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1089447320(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).StartGameServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2028434619(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerClientId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerClientId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).EndGameServerRpc(playerClientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_794862467(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerClientId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerClientId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).EndGameClientRpc(playerClientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2659636069(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int bodiesInsured = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref bodiesInsured);
			int daysPlayersSurvived = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref daysPlayersSurvived);
			int connectedPlayersOnServer = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref connectedPlayersOnServer);
			int scrapCollectedOnServer = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref scrapCollectedOnServer);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).EndOfGameClientRpc(bodiesInsured, daysPlayersSurvived, connectedPlayersOnServer, scrapCollectedOnServer);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1043433721(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).AllPlayersHaveRevivedClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1482204640(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).ManuallyEjectPlayersServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2721053021(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			int[] endGameStats = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref endGameStats, default(ForPrimitives));
			}
			bool abridgedVersion = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref abridgedVersion, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).FirePlayersAfterDeadlineClientRpc(endGameStats, abridgedVersion);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1068504982(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).EndPlayersFiredSequenceClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2441193238(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).StopShipSpeakerServerRpc(playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_907290724(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).StopShipSpeakerClientRpc(playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3083945322(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).PlayerHasRevivedServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2578118202(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).SetShipDoorsOverheatServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1864501499(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).SetShipDoorsOverheatClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_430165634(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool doorsClosedServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref doorsClosedServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).SetDoorsClosedServerRpc(doorsClosedServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2810194347(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool doorsClosedClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref doorsClosedClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).SetDoorsClosedClientRpc(doorsClosedClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1134466287(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int levelID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref levelID);
			int newGroupCreditsAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newGroupCreditsAmount);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).ChangeLevelServerRpc(levelID, newGroupCreditsAmount);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3896714546(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int groupCreditsAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref groupCreditsAmount);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).CancelChangeLevelClientRpc(groupCreditsAmount);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_167566585(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int levelID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref levelID);
			int newGroupCreditsAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newGroupCreditsAmount);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).ChangeLevelClientRpc(levelID, newGroupCreditsAmount);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1165604590(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).SurgePowerServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_670705935(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).SurgePowerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2249588995(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).SyncCompanyBuyingRateServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3519313816(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float buyingRate = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref buyingRate, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).SyncCompanyBuyingRateClientRpc(buyingRate);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3050994254(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool enable = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enable, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).Debug_EnableTestRoomServerRpc(enable);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_375322246(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enable = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enable, default(ForPrimitives));
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).Debug_EnableTestRoomClientRpc(enable, objectRef);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3186641109(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).Debug_ToggleAllowDeathServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_348115853(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool allowDeath = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref allowDeath, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).Debug_ToggleAllowDeathClientRpc(allowDeath);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2339227601(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartOfRound)(object)target).Debug_ReviveAllPlayersServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1279156295(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartOfRound)(object)target).Debug_ReviveAllPlayersClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "StartOfRound";
	}
}
