using System;

[Serializable]
public enum EnemySize
{
	Tiny,
	Giant,
	Medium
}
