using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class WalkieTalkie : GrabbableObject
{
	public PlayerControllerB playerListeningTo;

	public AudioSource thisAudio;

	private PlayerControllerB previousPlayerHeldBy;

	public bool isHoldingButton;

	public bool speakingIntoWalkieTalkie;

	public bool clientIsHoldingAndSpeakingIntoThis;

	public bool otherClientIsTransmittingAudios;

	private Coroutine speakIntoWalkieTalkieCoroutine;

	public AudioClip[] stopTransmissionSFX;

	public AudioClip[] startTransmissionSFX;

	public AudioClip switchWalkieTalkiePowerOff;

	public AudioClip switchWalkieTalkiePowerOn;

	public AudioClip talkingOnWalkieTalkieNotHeldSFX;

	public AudioClip playerDieOnWalkieTalkieSFX;

	public static List<WalkieTalkie> allWalkieTalkies = new List<WalkieTalkie>();

	public bool playingGarbledVoice;

	public Material onMaterial;

	public Material offMaterial;

	public Light walkieTalkieLight;

	public AudioSource target;

	[SerializeField]
	private float recordingRange = 6f;

	[SerializeField]
	private float maxVolume = 0.6f;

	private List<AudioSource> audioSourcesToReplay = new List<AudioSource>();

	private Dictionary<AudioSource, AudioSource> audioSourcesReceiving = new Dictionary<AudioSource, AudioSource>();

	public Collider listenCollider;

	private int audioSourcesToReplayLastFrameCount;

	public Collider[] collidersInRange = (Collider[])(object)new Collider[30];

	public List<WalkieTalkie> talkiesSendingToThis = new List<WalkieTalkie>();

	private float cleanUpInterval;

	private float updateInterval;

	public AudioSource wallAudio;

	public AudioClip[] wallAudios;

	private float wallAudioCheckInterval;

	private void OnDisable()
	{
		((NetworkBehaviour)this).OnDestroy();
		if (allWalkieTalkies.Contains(this))
		{
			allWalkieTalkies.Remove(this);
			if (allWalkieTalkies.Count <= 0)
			{
				allWalkieTalkies.TrimExcess();
			}
		}
	}

	private void OnEnable()
	{
		if (!allWalkieTalkies.Contains(this))
		{
			allWalkieTalkies.Add(this);
		}
	}

	public void SetLocalClientSpeaking(bool speaking)
	{
		if (previousPlayerHeldBy.speakingToWalkieTalkie != speaking)
		{
			previousPlayerHeldBy.speakingToWalkieTalkie = speaking;
			Debug.Log((object)$"Set local client speaking on walkie talkie: {speaking}");
			if (speaking)
			{
				SetPlayerSpeakingOnWalkieTalkieServerRpc((int)previousPlayerHeldBy.playerClientId);
			}
			else
			{
				UnsetPlayerSpeakingOnWalkieTalkieServerRpc((int)previousPlayerHeldBy.playerClientId);
			}
		}
	}

	[ServerRpc]
	public void SetPlayerSpeakingOnWalkieTalkieServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(64994802u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 64994802u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetPlayerSpeakingOnWalkieTalkieClientRpc(playerId);
		}
	}

	[ClientRpc]
	public void SetPlayerSpeakingOnWalkieTalkieClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2961867446u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2961867446u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				StartOfRound.Instance.allPlayerScripts[playerId].speakingToWalkieTalkie = true;
				clientIsHoldingAndSpeakingIntoThis = true;
				SendWalkieTalkieStartTransmissionSFX(playerId);
				StartOfRound.Instance.UpdatePlayerVoiceEffects();
			}
		}
	}

	[ServerRpc]
	public void UnsetPlayerSpeakingOnWalkieTalkieServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2502573704u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2502573704u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			UnsetPlayerSpeakingOnWalkieTalkieClientRpc(playerId);
		}
	}

	[ClientRpc]
	public void UnsetPlayerSpeakingOnWalkieTalkieClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3968582452u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3968582452u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				StartOfRound.Instance.allPlayerScripts[playerId].speakingToWalkieTalkie = false;
				clientIsHoldingAndSpeakingIntoThis = false;
				SendWalkieTalkieEndTransmissionSFX(playerId);
				updateInterval = 0.2f;
				StartOfRound.Instance.UpdatePlayerVoiceEffects();
			}
		}
	}

	private void SendWalkieTalkieEndTransmissionSFX(int playerId)
	{
		for (int i = 0; i < allWalkieTalkies.Count; i++)
		{
			if (!((Object)(object)StartOfRound.Instance.allPlayerScripts[playerId] == (Object)(object)allWalkieTalkies[i].playerHeldBy) && !PlayerIsHoldingAnotherWalkieTalkie(allWalkieTalkies[i]) && allWalkieTalkies[i].isBeingUsed)
			{
				RoundManager.PlayRandomClip(allWalkieTalkies[i].thisAudio, allWalkieTalkies[i].stopTransmissionSFX);
			}
		}
	}

	private void SendWalkieTalkieStartTransmissionSFX(int playerId)
	{
		Debug.Log((object)"Walkie talkie A");
		Random.Range(0f, talkingOnWalkieTalkieNotHeldSFX.length - 0.1f);
		for (int i = 0; i < allWalkieTalkies.Count; i++)
		{
			Debug.Log((object)$"Walkie talkie #{i} {((Object)((Component)allWalkieTalkies[i]).gameObject).name} B");
			Debug.Log((object)$"is walkie being used: {allWalkieTalkies[i].isBeingUsed}");
			if (!PlayerIsHoldingAnotherWalkieTalkie(allWalkieTalkies[i]) && allWalkieTalkies[i].isBeingUsed)
			{
				RoundManager.PlayRandomClip(allWalkieTalkies[i].thisAudio, allWalkieTalkies[i].startTransmissionSFX);
				Debug.Log((object)$"Walkie talkie #{i}  {((Object)((Component)allWalkieTalkies[i]).gameObject).name} C");
			}
		}
	}

	private void BroadcastSFXFromWalkieTalkie(AudioClip sfx, int fromPlayerId)
	{
		for (int i = 0; i < allWalkieTalkies.Count; i++)
		{
			if (!((Object)(object)StartOfRound.Instance.allPlayerScripts[fromPlayerId] == (Object)(object)allWalkieTalkies[i].playerHeldBy))
			{
				if (PlayerIsHoldingAnotherWalkieTalkie(allWalkieTalkies[i]))
				{
					break;
				}
				allWalkieTalkies[i].thisAudio.PlayOneShot(sfx);
			}
		}
	}

	private bool PlayerIsHoldingAnotherWalkieTalkie(WalkieTalkie walkieTalkie)
	{
		if ((Object)(object)walkieTalkie.playerHeldBy == (Object)null)
		{
			Debug.Log((object)"False A");
			return false;
		}
		if ((Object)(object)walkieTalkie.playerHeldBy.currentlyHeldObjectServer == (Object)null)
		{
			Debug.Log((object)"False B");
			return false;
		}
		if ((Object)(object)((Component)walkieTalkie.playerHeldBy.currentlyHeldObjectServer).GetComponent<WalkieTalkie>() == (Object)null)
		{
			Debug.Log((object)"False C");
			return false;
		}
		Debug.Log((object)$"{walkieTalkie.isPocketed}");
		if ((Object)(object)walkieTalkie.playerHeldBy != (Object)null && (Object)(object)walkieTalkie.playerHeldBy.currentlyHeldObjectServer != (Object)null && (Object)(object)((Component)walkieTalkie.playerHeldBy.currentlyHeldObjectServer).GetComponent<WalkieTalkie>() != (Object)null)
		{
			return walkieTalkie.isPocketed;
		}
		return false;
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		isHoldingButton = buttonDown;
		if (isBeingUsed && !speakingIntoWalkieTalkie && buttonDown)
		{
			previousPlayerHeldBy = playerHeldBy;
			if (speakIntoWalkieTalkieCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(speakIntoWalkieTalkieCoroutine);
			}
			speakIntoWalkieTalkieCoroutine = ((MonoBehaviour)this).StartCoroutine(speakingIntoWalkieTalkieMode());
		}
	}

	private IEnumerator speakingIntoWalkieTalkieMode()
	{
		PlayerHoldingWalkieTalkieButton(speaking: true);
		SetLocalClientSpeaking(speaking: true);
		yield return (object)new WaitForSeconds(0.2f);
		yield return (object)new WaitUntil((Func<bool>)(() => !isHoldingButton || !isHeld || !isBeingUsed));
		SetLocalClientSpeaking(speaking: false);
		PlayerHoldingWalkieTalkieButton(speaking: false);
	}

	private void PlayerHoldingWalkieTalkieButton(bool speaking)
	{
		speakingIntoWalkieTalkie = speaking;
		previousPlayerHeldBy.activatingItem = speaking;
		previousPlayerHeldBy.playerBodyAnimator.SetBool("walkieTalkie", speaking);
	}

	public void EnableWalkieTalkieListening(bool enable)
	{
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.holdingWalkieTalkie = enable;
		}
		if (IsPlayerSpectatedOrLocal())
		{
			thisAudio.Stop();
			StartOfRound.Instance.UpdatePlayerVoiceEffects();
		}
	}

	public override void UseUpBatteries()
	{
		base.UseUpBatteries();
		SwitchWalkieTalkieOn(on: false);
	}

	public override void PocketItem()
	{
		base.PocketItem();
		playerHeldBy.equippedUsableItemQE = false;
		((Behaviour)walkieTalkieLight).enabled = false;
	}

	public override void ItemInteractLeftRight(bool right)
	{
		base.ItemInteractLeftRight(right);
		if (!right)
		{
			SwitchWalkieTalkieOn(!isBeingUsed);
		}
	}

	public void SwitchWalkieTalkieOn(bool on)
	{
		isBeingUsed = on;
		EnableWalkieTalkieListening(on);
		if (on)
		{
			((Renderer)mainObjectRenderer).sharedMaterial = onMaterial;
			((Behaviour)walkieTalkieLight).enabled = true;
			thisAudio.PlayOneShot(switchWalkieTalkiePowerOn);
		}
		else
		{
			((Renderer)mainObjectRenderer).sharedMaterial = offMaterial;
			((Behaviour)walkieTalkieLight).enabled = false;
			thisAudio.PlayOneShot(switchWalkieTalkiePowerOff);
			wallAudio.Stop();
		}
	}

	public override void EquipItem()
	{
		base.EquipItem();
		if (isBeingUsed)
		{
			((Behaviour)walkieTalkieLight).enabled = true;
		}
		playerHeldBy.equippedUsableItemQE = true;
		if (isBeingUsed)
		{
			EnableWalkieTalkieListening(enable: true);
		}
	}

	public override void DiscardItem()
	{
		if (playerHeldBy.isPlayerDead && clientIsHoldingAndSpeakingIntoThis)
		{
			BroadcastSFXFromWalkieTalkie(playerDieOnWalkieTalkieSFX, (int)playerHeldBy.playerClientId);
		}
		EnableWalkieTalkieListening(enable: false);
		playerHeldBy.equippedUsableItemQE = false;
		base.DiscardItem();
	}

	private bool IsPlayerSpectatedOrLocal()
	{
		if (!((NetworkBehaviour)this).IsOwner)
		{
			if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
			{
				return (Object)(object)playerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript;
			}
			return false;
		}
		return true;
	}

	public override void Start()
	{
		base.Start();
		GetAllAudioSourcesToReplay();
		SetupAudiosourceClip();
	}

	public override void Update()
	{
		base.Update();
		if (isBeingUsed && ((NetworkBehaviour)this).IsOwner)
		{
			SetWallAudioVolume();
		}
		if (cleanUpInterval >= 0f)
		{
			cleanUpInterval -= Time.deltaTime;
		}
		else
		{
			cleanUpInterval = 15f;
			if (audioSourcesReceiving.Count > 10)
			{
				foreach (KeyValuePair<AudioSource, AudioSource> item in audioSourcesReceiving)
				{
					if ((Object)(object)item.Key == (Object)null)
					{
						audioSourcesReceiving.Remove(item.Key);
					}
				}
			}
		}
		if (updateInterval >= 0f)
		{
			updateInterval -= Time.deltaTime;
			return;
		}
		updateInterval = 0.3f;
		GetAllAudioSourcesToReplay();
		TimeAllAudioSources();
	}

	private void SetWallAudioVolume()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (StartOfRound.Instance.currentLevel.levelID == 3)
		{
			if (Time.realtimeSinceStartup - wallAudioCheckInterval > 40f)
			{
				wallAudioCheckInterval = Time.realtimeSinceStartup;
				if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, new Vector3(-28.8f, -7.72f, -10.56f)) < 18f && Random.Range(0, 100) < 3)
				{
					int num = Random.Range(0, wallAudios.Length);
					wallAudio.PlayOneShot(wallAudios[num]);
					PlayWallAudioServerRpc(num);
				}
			}
		}
		else
		{
			wallAudio.volume = 0f;
		}
	}

	[ServerRpc]
	public void PlayWallAudioServerRpc(int clipIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2677586182u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, clipIndex);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2677586182u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			PlayWallAudioClientRpc(clipIndex);
		}
	}

	[ClientRpc]
	public void PlayWallAudioClientRpc(int clipIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(518059100u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clipIndex);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 518059100u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && isBeingUsed && !((NetworkBehaviour)this).IsOwner)
			{
				wallAudio.PlayOneShot(wallAudios[clipIndex]);
			}
		}
	}

	private void TimeAllAudioSources()
	{
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < allWalkieTalkies.Count; i++)
		{
			if ((Object)(object)allWalkieTalkies[i] == (Object)(object)this)
			{
				continue;
			}
			AudioSource value;
			if ((Object)(object)allWalkieTalkies[i].playerHeldBy != (Object)null && allWalkieTalkies[i].clientIsHoldingAndSpeakingIntoThis && allWalkieTalkies[i].isBeingUsed && isBeingUsed)
			{
				if (!talkiesSendingToThis.Contains(allWalkieTalkies[i]))
				{
					talkiesSendingToThis.Add(allWalkieTalkies[i]);
				}
				for (int num = allWalkieTalkies[i].audioSourcesToReplay.Count - 1; num >= 0; num--)
				{
					AudioSource val = allWalkieTalkies[i].audioSourcesToReplay[num];
					if (!((Object)(object)val == (Object)null))
					{
						if (audioSourcesReceiving.TryAdd(val, null))
						{
							audioSourcesReceiving[val] = ((Component)target).gameObject.AddComponent<AudioSource>();
							audioSourcesReceiving[val].clip = val.clip;
							try
							{
								if (val.time >= val.clip.length)
								{
									if (val.time - 0.05f < val.clip.length)
									{
										audioSourcesReceiving[val].time = Mathf.Clamp(val.time - 0.05f, 0f, 1000f);
									}
									else
									{
										audioSourcesReceiving[val].time = val.time / 5f;
									}
								}
								else
								{
									audioSourcesReceiving[val].time = val.time;
								}
								audioSourcesReceiving[val].spatialBlend = 1f;
								audioSourcesReceiving[val].Play();
							}
							catch (Exception ex)
							{
								Debug.LogError((object)$"Error while playing audio clip in walkie talkie. Clip name: {((Object)val.clip).name} object: {((Object)((Component)val).gameObject).name}; time: {val.time}; {ex}");
							}
						}
						else
						{
							float num2 = Vector3.Distance(((Component)val).transform.position, ((Component)allWalkieTalkies[i]).transform.position);
							if (num2 > recordingRange + 7f)
							{
								audioSourcesReceiving.Remove(val, out value);
								Object.Destroy((Object)(object)value);
								allWalkieTalkies[i].audioSourcesToReplay.RemoveAt(num);
							}
							else
							{
								audioSourcesReceiving[val].volume = Mathf.Lerp(maxVolume, 0f, num2 / (recordingRange + 3f));
								if ((val.isPlaying && !audioSourcesReceiving[val].isPlaying) || (Object)(object)val.clip != (Object)(object)audioSourcesReceiving[val].clip)
								{
									audioSourcesReceiving[val].clip = val.clip;
									audioSourcesReceiving[val].Play();
								}
								else if (!val.isPlaying || !((Component)val).gameObject.activeInHierarchy)
								{
									audioSourcesReceiving[val].Stop();
								}
								audioSourcesReceiving[val].time = val.time;
							}
						}
					}
				}
			}
			else
			{
				if (!talkiesSendingToThis.Contains(allWalkieTalkies[i]))
				{
					continue;
				}
				talkiesSendingToThis.Remove(allWalkieTalkies[i]);
				foreach (AudioSource item in allWalkieTalkies[i].audioSourcesToReplay)
				{
					for (int j = 0; j < allWalkieTalkies.Count; j++)
					{
						if (allWalkieTalkies[j].audioSourcesReceiving.ContainsKey(item))
						{
							allWalkieTalkies[j].audioSourcesReceiving.Remove(item, out value);
							Object.Destroy((Object)(object)value);
						}
					}
				}
				allWalkieTalkies[i].audioSourcesToReplay.Clear();
			}
		}
	}

	public static void TransmitOneShotAudio(AudioSource audioSource, AudioClip clip, float vol = 1f)
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)clip == (Object)null || (Object)(object)audioSource == (Object)null)
		{
			return;
		}
		for (int i = 0; i < allWalkieTalkies.Count; i++)
		{
			if ((Object)(object)allWalkieTalkies[i].playerHeldBy == (Object)null || !allWalkieTalkies[i].clientIsHoldingAndSpeakingIntoThis || !allWalkieTalkies[i].isBeingUsed)
			{
				continue;
			}
			float num = Vector3.Distance(((Component)allWalkieTalkies[i]).transform.position, ((Component)audioSource).transform.position);
			if (!(num < allWalkieTalkies[i].recordingRange))
			{
				continue;
			}
			for (int j = 0; j < allWalkieTalkies.Count; j++)
			{
				if (j != i && allWalkieTalkies[j].isBeingUsed)
				{
					float num2 = Mathf.Lerp(allWalkieTalkies[i].maxVolume, 0f, num / (allWalkieTalkies[i].recordingRange + 3f));
					allWalkieTalkies[j].target.PlayOneShot(clip, num2 * vol);
				}
			}
		}
	}

	private void SetupAudiosourceClip()
	{
		target.Stop();
	}

	private void GetAllAudioSourcesToReplay()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)playerHeldBy == (Object)null || !playerHeldBy.speakingToWalkieTalkie || !isBeingUsed)
		{
			return;
		}
		int num = Physics.OverlapSphereNonAlloc(((Component)this).transform.position, recordingRange, collidersInRange, 11010632, (QueryTriggerInteraction)2);
		for (int i = 0; i < num; i++)
		{
			if (!Object.op_Implicit((Object)(object)((Component)collidersInRange[i]).gameObject.GetComponent<WalkieTalkie>()))
			{
				AudioSource component = ((Component)collidersInRange[i]).GetComponent<AudioSource>();
				if ((Object)(object)component != (Object)null && component.isPlaying && (Object)(object)component.clip != (Object)null && component.time > 0f && !audioSourcesToReplay.Contains(component) && ((Component)component).gameObject.activeInHierarchy)
				{
					audioSourcesToReplay.Add(component);
				}
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_WalkieTalkie()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(64994802u, new RpcReceiveHandler(__rpc_handler_64994802));
		NetworkManager.__rpc_func_table.Add(2961867446u, new RpcReceiveHandler(__rpc_handler_2961867446));
		NetworkManager.__rpc_func_table.Add(2502573704u, new RpcReceiveHandler(__rpc_handler_2502573704));
		NetworkManager.__rpc_func_table.Add(3968582452u, new RpcReceiveHandler(__rpc_handler_3968582452));
		NetworkManager.__rpc_func_table.Add(2677586182u, new RpcReceiveHandler(__rpc_handler_2677586182));
		NetworkManager.__rpc_func_table.Add(518059100u, new RpcReceiveHandler(__rpc_handler_518059100));
	}

	private static void __rpc_handler_64994802(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int playerSpeakingOnWalkieTalkieServerRpc = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerSpeakingOnWalkieTalkieServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((WalkieTalkie)(object)target).SetPlayerSpeakingOnWalkieTalkieServerRpc(playerSpeakingOnWalkieTalkieServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2961867446(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerSpeakingOnWalkieTalkieClientRpc = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerSpeakingOnWalkieTalkieClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((WalkieTalkie)(object)target).SetPlayerSpeakingOnWalkieTalkieClientRpc(playerSpeakingOnWalkieTalkieClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2502573704(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((WalkieTalkie)(object)target).UnsetPlayerSpeakingOnWalkieTalkieServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3968582452(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((WalkieTalkie)(object)target).UnsetPlayerSpeakingOnWalkieTalkieClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2677586182(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int clipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((WalkieTalkie)(object)target).PlayWallAudioServerRpc(clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_518059100(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((WalkieTalkie)(object)target).PlayWallAudioClientRpc(clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "WalkieTalkie";
	}
}
