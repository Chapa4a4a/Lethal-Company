using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class TestEnemy : EnemyAI
{
	public float detectionRadius = 12f;

	private Collider[] allPlayerColliders = (Collider[])(object)new Collider[4];

	private float closestPlayerDist;

	private Collider tempTargetCollider;

	public bool detectingPlayers;

	private bool tempDebug;

	public override void Start()
	{
		base.Start();
		movingTowardsTargetPlayer = true;
	}

	public override void DoAIInterval()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		int num = Physics.OverlapSphereNonAlloc(((Component)this).transform.position, detectionRadius, allPlayerColliders, StartOfRound.Instance.playersMask);
		if (num > 0)
		{
			detectingPlayers = true;
			closestPlayerDist = 255555f;
			for (int i = 0; i < num; i++)
			{
				float num2 = Vector3.Distance(((Component)this).transform.position, ((Component)allPlayerColliders[i]).transform.position);
				if (num2 < closestPlayerDist)
				{
					closestPlayerDist = num2;
					tempTargetCollider = allPlayerColliders[i];
				}
			}
			SetMovingTowardsTargetPlayer(((Component)tempTargetCollider).gameObject.GetComponent<PlayerControllerB>());
		}
		else
		{
			agent.speed = 5f;
			detectingPlayers = false;
		}
		base.DoAIInterval();
	}

	public override void Update()
	{
		if (((NetworkBehaviour)this).IsOwner && detectingPlayers)
		{
			agent.speed = Mathf.Clamp(agent.speed + Time.deltaTime / 3f, 0f, 12f);
		}
		base.Update();
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "TestEnemy";
	}
}
