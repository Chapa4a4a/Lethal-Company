using GameNetcodeStuff;
using UnityEngine;

public class OutOfBoundsTrigger : MonoBehaviour
{
	private StartOfRound playersManager;

	public bool disableWhenRoundStarts;

	private void Start()
	{
		playersManager = Object.FindObjectOfType<StartOfRound>();
	}

	private void OnTriggerEnter(Collider other)
	{
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		if (disableWhenRoundStarts && !playersManager.inShipPhase)
		{
			return;
		}
		if (((Component)other).tag.StartsWith("PlayerRagdoll"))
		{
			DeadBodyInfo componentInParent = ((Component)other).GetComponentInParent<DeadBodyInfo>();
			if ((Object)(object)componentInParent != (Object)null)
			{
				componentInParent.timesOutOfBounds++;
				if (componentInParent.timesOutOfBounds > 2)
				{
					componentInParent.SetBodyPartsKinematic();
				}
				else
				{
					componentInParent.ResetRagdollPosition();
				}
			}
		}
		else
		{
			if (!(((Component)other).tag == "Player"))
			{
				return;
			}
			PlayerControllerB component = ((Component)other).GetComponent<PlayerControllerB>();
			if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)(object)component)
			{
				return;
			}
			component.ResetFallGravity();
			if (!((Object)(object)component != (Object)null))
			{
				return;
			}
			if (!playersManager.shipDoorsEnabled)
			{
				playersManager.ForcePlayerIntoShip();
			}
			else if (component.isInsideFactory)
			{
				if (!StartOfRound.Instance.isChallengeFile)
				{
					component.KillPlayer(Vector3.zero, spawnBody: false);
				}
				else
				{
					component.TeleportPlayer(RoundManager.FindMainEntrancePosition(getTeleportPosition: true));
				}
			}
			else if (component.isInHangarShipRoom)
			{
				component.TeleportPlayer(playersManager.playerSpawnPositions[0].position);
			}
			else
			{
				component.TeleportPlayer(playersManager.outsideShipSpawnPosition.position);
			}
		}
	}
}
