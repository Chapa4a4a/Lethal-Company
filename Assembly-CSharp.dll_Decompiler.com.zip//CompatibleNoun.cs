using System;

[Serializable]
public class CompatibleNoun
{
	public TerminalKeyword noun;

	public TerminalNode result;
}
