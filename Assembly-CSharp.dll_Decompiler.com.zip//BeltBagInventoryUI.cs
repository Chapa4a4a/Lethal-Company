using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class BeltBagInventoryUI : MonoBehaviour
{
	public GameObject panel;

	public BeltBagItem currentBeltBag;

	public GameObject[] inventorySlots;

	public Image[] inventorySlotIcons;

	public int grabbingItemSlot = -1;

	public Image cursorGrabbingObjectImage;

	public bool setCursorImageV1;

	public bool displaying;

	public void ClickExitButton()
	{
		if (GameNetworkManager.Instance.localPlayerController.inSpecialMenu)
		{
			GameNetworkManager.Instance.localPlayerController.SetInSpecialMenu(setInMenu: false);
		}
		currentBeltBag = null;
		displaying = false;
	}

	public void FillSlots(BeltBagItem beltBag)
	{
		currentBeltBag = beltBag;
		displaying = true;
		for (int i = 0; i < inventorySlots.Length; i++)
		{
			if (beltBag.objectsInBag == null || beltBag.objectsInBag.Count <= i || (Object)(object)beltBag.objectsInBag[i] == (Object)null)
			{
				((Behaviour)inventorySlotIcons[i]).enabled = false;
				continue;
			}
			((Behaviour)inventorySlotIcons[i]).enabled = true;
			inventorySlotIcons[i].sprite = beltBag.objectsInBag[i].itemProperties.itemIcon;
		}
	}

	public void OnEnable()
	{
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("ActivateItem", false).canceled += OnClickRelease;
	}

	public void OnDisable()
	{
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("ActivateItem", false).canceled -= OnClickRelease;
		displaying = false;
	}

	public void Update()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (grabbingItemSlot != -1)
		{
			((Behaviour)cursorGrabbingObjectImage).enabled = true;
			Vector3 val = Vector2.op_Implicit(((InputControl<Vector2>)(object)((Pointer)Mouse.current).position).ReadValue());
			val.z = 2.1f;
			((Component)cursorGrabbingObjectImage).transform.position = HUDManager.Instance.UICamera.ScreenToWorldPoint(val);
		}
		else
		{
			((Behaviour)cursorGrabbingObjectImage).enabled = false;
		}
	}

	public void OnClickRelease(CallbackContext context)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Expected O, but got Unknown
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		if (grabbingItemSlot == -1)
		{
			return;
		}
		PointerEventData val = new PointerEventData(EventSystem.current);
		val.position = ((InputControl<Vector2>)(object)((Pointer)Mouse.current).position).ReadValue();
		List<RaycastResult> list = new List<RaycastResult>();
		EventSystem.current.RaycastAll(val, list);
		for (int i = 0; i < list.Count; i++)
		{
			RaycastResult val2 = list[i];
			if ((Object)(object)((RaycastResult)(ref val2)).gameObject == (Object)(object)panel)
			{
				((Behaviour)inventorySlotIcons[grabbingItemSlot]).enabled = true;
				HUDManager.Instance.SetMouseCursorSprite(HUDManager.Instance.handOpenCursorTex, new Vector2(16f, 16f));
				grabbingItemSlot = -1;
				return;
			}
		}
		RemoveItemFromUI(grabbingItemSlot);
	}

	public void RemoveItemFromUI(int slot)
	{
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)currentBeltBag != (Object)null && slot != -1)
		{
			if (currentBeltBag.objectsInBag.Count > slot && (Object)(object)currentBeltBag.objectsInBag[slot] != (Object)null && !currentBeltBag.tryingAddToBag)
			{
				((Behaviour)inventorySlotIcons[slot]).enabled = false;
				currentBeltBag.RemoveObjectFromBag(slot);
				FillSlots(currentBeltBag);
			}
			else
			{
				((Behaviour)inventorySlotIcons[slot]).enabled = true;
			}
			HUDManager.Instance.SetMouseCursorSprite(HUDManager.Instance.handOpenCursorTex);
			grabbingItemSlot = -1;
		}
	}

	public void ClickInventorySlotController(int slotNumber)
	{
		if (StartOfRound.Instance.localPlayerUsingController && !((Object)(object)currentBeltBag == (Object)null) && currentBeltBag.objectsInBag.Count > slotNumber && (Object)(object)currentBeltBag.objectsInBag[slotNumber] != (Object)null)
		{
			RemoveItemFromUI(slotNumber);
		}
	}

	public void ClickInventorySlot(int slotNumber)
	{
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		if (!StartOfRound.Instance.localPlayerUsingController && !((Object)(object)currentBeltBag == (Object)null) && currentBeltBag.objectsInBag.Count > slotNumber && (Object)(object)currentBeltBag.objectsInBag[slotNumber] != (Object)null)
		{
			grabbingItemSlot = slotNumber;
			currentBeltBag.GrabItemInBag();
			HUDManager.Instance.SetMouseCursorSprite(HUDManager.Instance.handClosedCursorTex, new Vector2(16f, 16f));
			cursorGrabbingObjectImage.sprite = inventorySlotIcons[slotNumber].sprite;
			((Behaviour)inventorySlotIcons[slotNumber]).enabled = false;
		}
	}
}
