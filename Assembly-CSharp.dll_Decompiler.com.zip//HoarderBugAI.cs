using System;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Animations.Rigging;

public class HoarderBugAI : EnemyAI
{
	public AISearchRoutine searchForItems;

	public AISearchRoutine searchForPlayer;

	[Header("Tracking/Memory")]
	[Space(3f)]
	public Vector3 nestPosition;

	private bool choseNestPosition;

	[Space(3f)]
	public static List<HoarderBugItem> HoarderBugItems = new List<HoarderBugItem>();

	public static List<GameObject> grabbableObjectsInMap = new List<GameObject>();

	public float angryTimer;

	public GrabbableObject targetItem;

	public HoarderBugItem heldItem;

	[Header("Animations")]
	[Space(5f)]
	private Vector3 agentLocalVelocity;

	private Vector3 previousPosition;

	private float velX;

	private float velZ;

	public Transform turnCompass;

	private float armsHoldLayerWeight;

	[Space(5f)]
	public Transform animationContainer;

	public Transform grabTarget;

	public MultiAimConstraint headLookRig;

	public Transform headLookTarget;

	[Header("Special behaviour states")]
	private float annoyanceMeter;

	public bool watchingPlayerNearPosition;

	public PlayerControllerB watchingPlayer;

	public Transform lookTarget;

	public bool lookingAtPositionOfInterest;

	private Vector3 positionOfInterest;

	private bool isAngry;

	[Header("Misc logic")]
	private bool sendingGrabOrDropRPC;

	private float waitingAtNestTimer;

	private bool waitingAtNest;

	private float timeSinceSeeingAPlayer;

	[Header("Chase logic")]
	private bool lostPlayerInChase;

	private float noticePlayerTimer;

	public PlayerControllerB angryAtPlayer;

	private bool inChase;

	[Header("Audios")]
	public AudioClip[] chitterSFX;

	[Header("Audios")]
	public AudioClip[] angryScreechSFX;

	public AudioClip angryVoiceSFX;

	public AudioClip bugFlySFX;

	public AudioClip hitPlayerSFX;

	private float timeSinceHittingPlayer;

	private float timeSinceLookingTowardsNoise;

	private float detectPlayersInterval;

	private bool inReturnToNestMode;

	public GameObject ghostCostume;

	public override void Start()
	{
		base.Start();
		heldItem = null;
		RefreshGrabbableObjectsInMapList();
		DateTime dateTime = new DateTime(DateTime.Now.Year, 10, 31);
		if (DateTime.Today == dateTime)
		{
			ghostCostume.SetActive(true);
		}
	}

	public static void RefreshGrabbableObjectsInMapList()
	{
		grabbableObjectsInMap.Clear();
		GrabbableObject[] array = Object.FindObjectsOfType<GrabbableObject>();
		Debug.Log((object)$"gobjectsin scnee!! : {array.Length}");
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].grabbableToEnemies && !array[i].deactivated)
			{
				grabbableObjectsInMap.Add(((Component)array[i]).gameObject);
			}
		}
	}

	private bool GrabTargetItemIfClose()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)targetItem != (Object)null && heldItem == null && Vector3.Distance(((Component)this).transform.position, ((Component)targetItem).transform.position) < 0.75f)
		{
			if (!SetDestinationToPosition(nestPosition, checkForPath: true))
			{
				nestPosition = ChooseClosestNodeToPosition(((Component)this).transform.position).position;
				SetDestinationToPosition(nestPosition);
			}
			NetworkObject component = ((Component)targetItem).GetComponent<NetworkObject>();
			SwitchToBehaviourStateOnLocalClient(1);
			GrabItem(component);
			sendingGrabOrDropRPC = true;
			GrabItemServerRpc(NetworkObjectReference.op_Implicit(component));
			return true;
		}
		return false;
	}

	private void ChooseNestPosition()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		HoarderBugAI[] array = Object.FindObjectsOfType<HoarderBugAI>();
		for (int i = 0; i < array.Length; i++)
		{
			if ((Object)(object)array[i] != (Object)(object)this && !PathIsIntersectedByLineOfSight(array[i].nestPosition, calculatePathDistance: false, avoidLineOfSight: false))
			{
				nestPosition = array[i].nestPosition;
				SyncNestPositionServerRpc(nestPosition);
				return;
			}
		}
		nestPosition = ChooseClosestNodeToPosition(((Component)this).transform.position).position;
		SyncNestPositionServerRpc(nestPosition);
	}

	[ServerRpc]
	private void SyncNestPositionServerRpc(Vector3 newNestPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3689917697u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newNestPosition);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3689917697u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncNestPositionClientRpc(newNestPosition);
		}
	}

	[ClientRpc]
	private void SyncNestPositionClientRpc(Vector3 newNestPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1841413947u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref newNestPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1841413947u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				nestPosition = newNestPosition;
			}
		}
	}

	public override void DoAIInterval()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0312: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0399: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		if (!choseNestPosition)
		{
			choseNestPosition = true;
			ChooseNestPosition();
			return;
		}
		if (CheckLineOfSightForPosition(nestPosition, 60f, 40, 0.5f))
		{
			for (int i = 0; i < HoarderBugItems.Count; i++)
			{
				if (HoarderBugItems[i].itemGrabbableObject.isHeld && HoarderBugItems[i].itemNestPosition == nestPosition)
				{
					HoarderBugItems[i].status = HoarderBugItemStatus.Stolen;
				}
			}
		}
		HoarderBugItem hoarderBugItem = CheckLineOfSightForItem(HoarderBugItemStatus.Stolen, 60f, 30, 3f);
		if (hoarderBugItem != null && !hoarderBugItem.itemGrabbableObject.isHeld)
		{
			hoarderBugItem.status = HoarderBugItemStatus.Returned;
			if (!grabbableObjectsInMap.Contains(((Component)hoarderBugItem.itemGrabbableObject).gameObject))
			{
				grabbableObjectsInMap.Add(((Component)hoarderBugItem.itemGrabbableObject).gameObject);
			}
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			inReturnToNestMode = false;
			ExitChaseMode();
			if (GrabTargetItemIfClose())
			{
				break;
			}
			if ((Object)(object)targetItem == (Object)null && !searchForItems.inProgress)
			{
				StartSearch(nestPosition, searchForItems);
				break;
			}
			if ((Object)(object)targetItem != (Object)null)
			{
				SetGoTowardsTargetObject(((Component)targetItem).gameObject);
				break;
			}
			GameObject val2 = CheckLineOfSight(grabbableObjectsInMap, 60f, 40, 5f);
			if (Object.op_Implicit((Object)(object)val2))
			{
				GrabbableObject component = val2.GetComponent<GrabbableObject>();
				if (Object.op_Implicit((Object)(object)component) && !component.deactivated && (!component.isHeld || (Random.Range(0, 100) < 4 && !component.isPocketed)))
				{
					SetGoTowardsTargetObject(val2);
				}
			}
			break;
		}
		case 1:
			ExitChaseMode();
			if (!inReturnToNestMode)
			{
				inReturnToNestMode = true;
				SetReturningToNest();
				Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Abandoned current search and returning to nest empty-handed"));
			}
			GrabTargetItemIfClose();
			if (waitingAtNest)
			{
				if (heldItem != null)
				{
					DropItemAndCallDropRPC(((Component)heldItem.itemGrabbableObject).GetComponent<NetworkObject>());
				}
				else
				{
					GameObject val = CheckLineOfSight(grabbableObjectsInMap, 60f, 40, 5f);
					if (Object.op_Implicit((Object)(object)val) && Vector3.Distance(eye.position, val.transform.position) < 6f)
					{
						targetItem = val.GetComponent<GrabbableObject>();
						if ((Object)(object)targetItem != (Object)null && !targetItem.isHeld && !targetItem.deactivated)
						{
							waitingAtNest = false;
							SwitchToBehaviourState(0);
							break;
						}
					}
				}
				if (waitingAtNestTimer <= 0f && !watchingPlayerNearPosition)
				{
					waitingAtNest = false;
					SwitchToBehaviourStateOnLocalClient(0);
				}
			}
			else if (Vector3.Distance(((Component)this).transform.position, nestPosition) < 0.75f)
			{
				waitingAtNest = true;
				waitingAtNestTimer = 15f;
			}
			break;
		case 2:
			inReturnToNestMode = false;
			if (heldItem != null)
			{
				DropItemAndCallDropRPC(((Component)heldItem.itemGrabbableObject).GetComponent<NetworkObject>(), droppedInNest: false);
			}
			if (lostPlayerInChase)
			{
				if (!searchForPlayer.inProgress)
				{
					searchForPlayer.searchWidth = 30f;
					StartSearch(((Component)targetPlayer).transform.position, searchForPlayer);
					Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Lost player in chase; beginning search where the player was last seen"));
				}
				break;
			}
			if ((Object)(object)targetPlayer == (Object)null)
			{
				Debug.LogError((object)"TargetPlayer is null even though bug is in chase; setting targetPlayer to watchingPlayer");
				if ((Object)(object)watchingPlayer != (Object)null)
				{
					targetPlayer = watchingPlayer;
				}
			}
			if (searchForPlayer.inProgress)
			{
				StopSearch(searchForPlayer);
				Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Found player during chase; stopping search coroutine and moving after target player"));
			}
			movingTowardsTargetPlayer = true;
			break;
		case 3:
			break;
		}
	}

	private void SetGoTowardsTargetObject(GameObject foundObject)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		if (SetDestinationToPosition(foundObject.transform.position, checkForPath: true) && grabbableObjectsInMap.Contains(foundObject))
		{
			Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Setting target object and going towards it."));
			targetItem = foundObject.GetComponent<GrabbableObject>();
			StopSearch(searchForItems, clear: false);
		}
		else
		{
			targetItem = null;
			Debug.Log((object)(((Object)((Component)this).gameObject).name + ": i found an object but cannot reach it (or it has been taken by another bug): " + ((Object)foundObject).name));
		}
	}

	private void ExitChaseMode()
	{
		if (inChase)
		{
			inChase = false;
			Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Exiting chase mode"));
			if (searchForPlayer.inProgress)
			{
				StopSearch(searchForPlayer);
			}
			movingTowardsTargetPlayer = false;
			creatureAnimator.SetBool("Chase", false);
			creatureSFX.Stop();
		}
	}

	private void SetReturningToNest()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		if (SetDestinationToPosition(nestPosition, checkForPath: true))
		{
			targetItem = null;
			StopSearch(searchForItems, clear: false);
		}
		else
		{
			Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Return to nest was called, but nest is not accessible! Abandoning and choosing a new nest position."));
			ChooseNestPosition();
		}
	}

	private void LateUpdate()
	{
		if (!inSpecialAnimation && !isEnemyDead && !StartOfRound.Instance.allPlayersDead)
		{
			if (detectPlayersInterval <= 0f)
			{
				detectPlayersInterval = 0.2f;
				DetectAndLookAtPlayers();
			}
			else
			{
				detectPlayersInterval -= Time.deltaTime;
			}
			AnimateLooking();
			CalculateAnimationDirection();
			SetArmLayerWeight();
		}
	}

	private void SetArmLayerWeight()
	{
		if (heldItem != null)
		{
			armsHoldLayerWeight = Mathf.Lerp(armsHoldLayerWeight, 0.85f, 8f * Time.deltaTime);
		}
		else
		{
			armsHoldLayerWeight = Mathf.Lerp(armsHoldLayerWeight, 0f, 8f * Time.deltaTime);
		}
		creatureAnimator.SetLayerWeight(1, armsHoldLayerWeight);
	}

	private void CalculateAnimationDirection(float maxSpeed = 1f)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		agentLocalVelocity = animationContainer.InverseTransformDirection(Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 2f));
		velX = Mathf.Lerp(velX, agentLocalVelocity.x, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityX", Mathf.Clamp(velX, 0f - maxSpeed, maxSpeed));
		velZ = Mathf.Lerp(velZ, agentLocalVelocity.z, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityZ", Mathf.Clamp(velZ, 0f - maxSpeed, maxSpeed));
		previousPosition = ((Component)this).transform.position;
	}

	private void AnimateLooking()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)watchingPlayer != (Object)null)
		{
			lookTarget.position = ((Component)watchingPlayer.gameplayCamera).transform.position;
		}
		else
		{
			if (!lookingAtPositionOfInterest)
			{
				agent.angularSpeed = 220f;
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 0f, 10f);
				return;
			}
			lookTarget.position = positionOfInterest;
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			agent.angularSpeed = 0f;
			turnCompass.LookAt(lookTarget);
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, turnCompass.rotation, 6f * Time.deltaTime);
			((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.localEulerAngles.y, 0f);
		}
		float num = Vector3.Angle(((Component)this).transform.forward, lookTarget.position - ((Component)this).transform.position);
		if (num > 22f)
		{
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 1f * (Mathf.Abs(num - 180f) / 180f), 7f);
		}
		else
		{
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 1f, 7f);
		}
		headLookTarget.position = Vector3.Lerp(headLookTarget.position, lookTarget.position, 8f * Time.deltaTime);
	}

	private void DetectAndLookAtPlayers()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((currentBehaviourStateIndex != 1) ? ((Component)this).transform.position : nestPosition);
		PlayerControllerB[] allPlayersInLineOfSight = GetAllPlayersInLineOfSight(70f, 30, eye, 1.2f);
		if (allPlayersInLineOfSight != null)
		{
			PlayerControllerB playerControllerB = watchingPlayer;
			timeSinceSeeingAPlayer = 0f;
			float num = 500f;
			bool flag = false;
			if ((Object)(object)stunnedByPlayer != (Object)null)
			{
				flag = true;
				angryAtPlayer = stunnedByPlayer;
			}
			for (int i = 0; i < allPlayersInLineOfSight.Length; i++)
			{
				if (!flag && (Object)(object)allPlayersInLineOfSight[i].currentlyHeldObjectServer != (Object)null)
				{
					for (int j = 0; j < HoarderBugItems.Count; j++)
					{
						if ((Object)(object)HoarderBugItems[j].itemGrabbableObject == (Object)(object)allPlayersInLineOfSight[i].currentlyHeldObjectServer)
						{
							HoarderBugItems[j].status = HoarderBugItemStatus.Stolen;
							angryAtPlayer = allPlayersInLineOfSight[i];
							flag = true;
						}
					}
				}
				if (IsHoarderBugAngry() && (Object)(object)allPlayersInLineOfSight[i] == (Object)(object)angryAtPlayer)
				{
					watchingPlayer = angryAtPlayer;
				}
				else
				{
					float num2 = Vector3.Distance(((Component)allPlayersInLineOfSight[i]).transform.position, val);
					if (num2 < num)
					{
						num = num2;
						watchingPlayer = allPlayersInLineOfSight[i];
					}
				}
				float num3 = Vector3.Distance(((Component)allPlayersInLineOfSight[i]).transform.position, nestPosition);
				if (HoarderBugItems.Count > 0)
				{
					if ((num3 < 4f || (inChase && num3 < 8f)) && angryTimer < 3.25f)
					{
						angryAtPlayer = allPlayersInLineOfSight[i];
						watchingPlayer = allPlayersInLineOfSight[i];
						angryTimer = 3.25f;
						break;
					}
					if (!isAngry && currentBehaviourStateIndex == 0 && num3 < 8f && ((Object)(object)targetItem == (Object)null || Vector3.Distance(((Component)targetItem).transform.position, ((Component)this).transform.position) > 7.5f) && ((NetworkBehaviour)this).IsOwner)
					{
						SwitchToBehaviourState(1);
					}
				}
				if (currentBehaviourStateIndex != 2 && Vector3.Distance(((Component)this).transform.position, ((Component)allPlayersInLineOfSight[i]).transform.position) < 2.5f)
				{
					annoyanceMeter += 0.2f;
					if (annoyanceMeter > 2.5f)
					{
						angryAtPlayer = allPlayersInLineOfSight[i];
						watchingPlayer = allPlayersInLineOfSight[i];
						angryTimer = 3.25f;
					}
				}
			}
			watchingPlayerNearPosition = num < 6f;
			if ((Object)(object)watchingPlayer != (Object)(object)playerControllerB)
			{
				RoundManager.PlayRandomClip(creatureVoice, chitterSFX);
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				return;
			}
			if (currentBehaviourStateIndex != 2)
			{
				if (IsHoarderBugAngry())
				{
					lostPlayerInChase = false;
					targetPlayer = watchingPlayer;
					SwitchToBehaviourState(2);
				}
			}
			else
			{
				targetPlayer = watchingPlayer;
				if (lostPlayerInChase)
				{
					lostPlayerInChase = false;
				}
			}
			return;
		}
		timeSinceSeeingAPlayer += 0.2f;
		watchingPlayerNearPosition = false;
		if (currentBehaviourStateIndex != 2)
		{
			if (timeSinceSeeingAPlayer > 1.5f)
			{
				watchingPlayer = null;
			}
			return;
		}
		if (timeSinceSeeingAPlayer > 1.25f)
		{
			watchingPlayer = null;
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (timeSinceSeeingAPlayer > 15f)
			{
				SwitchToBehaviourState(1);
			}
			else if (timeSinceSeeingAPlayer > 2.5f)
			{
				lostPlayerInChase = true;
			}
		}
	}

	private bool IsHoarderBugAngry()
	{
		if (stunNormalizedTimer > 0f)
		{
			angryTimer = 4f;
			if (Object.op_Implicit((Object)(object)stunnedByPlayer))
			{
				angryAtPlayer = stunnedByPlayer;
			}
			return true;
		}
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < HoarderBugItems.Count; i++)
		{
			if (HoarderBugItems[i].status == HoarderBugItemStatus.Stolen)
			{
				num2++;
			}
			else if (HoarderBugItems[i].status == HoarderBugItemStatus.Returned)
			{
				num++;
			}
		}
		if (!(angryTimer > 0f))
		{
			return num2 > 0;
		}
		return true;
	}

	public override void Update()
	{
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		timeSinceHittingPlayer += Time.deltaTime;
		timeSinceLookingTowardsNoise += Time.deltaTime;
		if (timeSinceLookingTowardsNoise > 0.6f)
		{
			lookingAtPositionOfInterest = false;
		}
		if (inSpecialAnimation || isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		if (angryTimer >= 0f)
		{
			angryTimer -= Time.deltaTime;
		}
		creatureAnimator.SetBool("stunned", stunNormalizedTimer > 0f);
		bool flag = IsHoarderBugAngry();
		if (!isAngry && flag)
		{
			isAngry = true;
			creatureVoice.clip = angryVoiceSFX;
			creatureVoice.Play();
		}
		else if (isAngry && !flag)
		{
			isAngry = false;
			angryAtPlayer = null;
			creatureVoice.Stop();
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			ExitChaseMode();
			addPlayerVelocityToDestination = 0f;
			if (stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
			}
			else
			{
				agent.speed = 6f;
			}
			waitingAtNest = false;
			break;
		case 1:
			ExitChaseMode();
			addPlayerVelocityToDestination = 0f;
			if (stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
			}
			else
			{
				agent.speed = 6f;
			}
			agent.acceleration = 30f;
			if (waitingAtNest && waitingAtNestTimer > 0f)
			{
				waitingAtNestTimer -= Time.deltaTime;
			}
			break;
		case 2:
			if (!inChase)
			{
				inChase = true;
				creatureSFX.clip = bugFlySFX;
				creatureSFX.Play();
				RoundManager.PlayRandomClip(creatureVoice, angryScreechSFX);
				creatureAnimator.SetBool("Chase", true);
				waitingAtNest = false;
				if (Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) < 10f)
				{
					GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.5f);
				}
			}
			addPlayerVelocityToDestination = 2f;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if (!IsHoarderBugAngry())
			{
				HoarderBugItem hoarderBugItem = CheckLineOfSightForItem(HoarderBugItemStatus.Returned, 60f, 12, 3f);
				if (hoarderBugItem != null && !hoarderBugItem.itemGrabbableObject.isHeld)
				{
					SwitchToBehaviourState(0);
					SetGoTowardsTargetObject(((Component)hoarderBugItem.itemGrabbableObject).gameObject);
				}
				else
				{
					SwitchToBehaviourState(1);
				}
				ExitChaseMode();
				break;
			}
			if (stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
			}
			else
			{
				agent.speed = 18f;
			}
			agent.acceleration = 16f;
			if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.75f, 60f, 15))
			{
				GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(0.4f);
			}
			break;
		}
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesPlayedInOneSpot, noiseID);
		if (timesPlayedInOneSpot <= 10 && !(timeSinceLookingTowardsNoise < 0.6f))
		{
			timeSinceLookingTowardsNoise = 0f;
			float num = Vector3.Distance(noisePosition, nestPosition);
			if (((NetworkBehaviour)this).IsOwner && HoarderBugItems.Count > 0 && !isAngry && currentBehaviourStateIndex == 0 && num < 15f && ((Object)(object)targetItem == (Object)null || Vector3.Distance(((Component)targetItem).transform.position, ((Component)this).transform.position) > 4.5f))
			{
				SwitchToBehaviourState(1);
			}
			positionOfInterest = noisePosition;
			lookingAtPositionOfInterest = true;
		}
	}

	private void DropItemAndCallDropRPC(NetworkObject dropItemNetworkObject, bool droppedInNest = true)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		Vector3 targetFloorPosition = RoundManager.Instance.RandomlyOffsetPosition(heldItem.itemGrabbableObject.GetItemFloorPosition(), 1.2f, 0.4f);
		DropItem(dropItemNetworkObject, targetFloorPosition);
		sendingGrabOrDropRPC = true;
		DropItemServerRpc(NetworkObjectReference.op_Implicit(dropItemNetworkObject), targetFloorPosition, droppedInNest);
	}

	[ServerRpc]
	public void DropItemServerRpc(NetworkObjectReference objectRef, Vector3 targetFloorPosition, bool droppedInNest)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Invalid comparison between Unknown and I4
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3510928244u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetFloorPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref droppedInNest, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3510928244u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DropItemClientRpc(objectRef, targetFloorPosition, droppedInNest);
		}
	}

	[ClientRpc]
	public void DropItemClientRpc(NetworkObjectReference objectRef, Vector3 targetFloorPosition, bool droppedInNest)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(847487221u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetFloorPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref droppedInNest, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 847487221u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			NetworkObject item = default(NetworkObject);
			if (((NetworkObjectReference)(ref objectRef)).TryGet(ref item, (NetworkManager)null))
			{
				DropItem(item, targetFloorPosition, droppedInNest);
			}
			else
			{
				Debug.LogError((object)(((Object)((Component)this).gameObject).name + ": Failed to get network object from network object reference (Drop item RPC)"));
			}
		}
	}

	[ServerRpc]
	public void GrabItemServerRpc(NetworkObjectReference objectRef)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2358561451u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2358561451u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			GrabItemClientRpc(objectRef);
		}
	}

	[ClientRpc]
	public void GrabItemClientRpc(NetworkObjectReference objectRef)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1536760829u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1536760829u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			SwitchToBehaviourStateOnLocalClient(1);
			NetworkObject item = default(NetworkObject);
			if (((NetworkObjectReference)(ref objectRef)).TryGet(ref item, (NetworkManager)null))
			{
				GrabItem(item);
			}
			else
			{
				Debug.LogError((object)(((Object)((Component)this).gameObject).name + ": Failed to get network object from network object reference (Grab item RPC)"));
			}
		}
	}

	private void DropItem(NetworkObject item, Vector3 targetFloorPosition, bool droppingInNest = true)
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		if (sendingGrabOrDropRPC)
		{
			sendingGrabOrDropRPC = false;
			return;
		}
		if (heldItem == null)
		{
			Debug.LogError((object)"Hoarder bug: my held item is null when attempting to drop it!!");
			return;
		}
		GrabbableObject itemGrabbableObject = heldItem.itemGrabbableObject;
		itemGrabbableObject.parentObject = null;
		((Component)itemGrabbableObject).transform.SetParent(StartOfRound.Instance.propsContainer, true);
		itemGrabbableObject.EnablePhysics(enable: true);
		itemGrabbableObject.fallTime = 0f;
		itemGrabbableObject.startFallingPosition = ((Component)itemGrabbableObject).transform.parent.InverseTransformPoint(((Component)itemGrabbableObject).transform.position);
		itemGrabbableObject.targetFloorPosition = ((Component)itemGrabbableObject).transform.parent.InverseTransformPoint(targetFloorPosition);
		itemGrabbableObject.floorYRot = -1;
		itemGrabbableObject.DiscardItemFromEnemy();
		heldItem = null;
		if (!droppingInNest)
		{
			grabbableObjectsInMap.Add(((Component)itemGrabbableObject).gameObject);
		}
	}

	private void GrabItem(NetworkObject item)
	{
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		if (sendingGrabOrDropRPC)
		{
			sendingGrabOrDropRPC = false;
			return;
		}
		if (heldItem != null)
		{
			Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Trying to grab another item (" + ((Object)((Component)item).gameObject).name + ") while hands are already full with item (" + ((Object)((Component)heldItem.itemGrabbableObject).gameObject).name + "). Dropping the currently held one."));
			DropItem(((Component)heldItem.itemGrabbableObject).GetComponent<NetworkObject>(), heldItem.itemGrabbableObject.GetItemFloorPosition());
		}
		targetItem = null;
		GrabbableObject component = ((Component)item).gameObject.GetComponent<GrabbableObject>();
		HoarderBugItems.Add(new HoarderBugItem(component, HoarderBugItemStatus.Owned, nestPosition));
		heldItem = HoarderBugItems[HoarderBugItems.Count - 1];
		component.parentObject = grabTarget;
		component.hasHitGround = false;
		component.GrabItemFromEnemy(this);
		component.EnablePhysics(enable: false);
		grabbableObjectsInMap.Remove(((Component)component).gameObject);
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (inChase && !(timeSinceHittingPlayer < 0.5f))
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				timeSinceHittingPlayer = 0f;
				playerControllerB.DamagePlayer(30, hasDamageSFX: true, callRPC: true, CauseOfDeath.Mauling);
				HitPlayerServerRpc();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void HitPlayerServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1884379629u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1884379629u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				HitPlayerClientRpc();
			}
		}
	}

	[ClientRpc]
	public void HitPlayerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1031891902u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1031891902u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !isEnemyDead)
			{
				creatureAnimator.SetTrigger("HitPlayer");
				creatureSFX.PlayOneShot(hitPlayerSFX);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, hitPlayerSFX);
			}
		}
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		Debug.Log((object)"HA");
		if (!isEnemyDead)
		{
			Debug.Log((object)"HB");
			creatureAnimator.SetTrigger("damage");
			angryAtPlayer = playerWhoHit;
			angryTimer += 18f;
			Debug.Log((object)"HC");
			enemyHP -= force;
			if (enemyHP <= 0 && ((NetworkBehaviour)this).IsOwner)
			{
				KillEnemyOnOwnerClient();
			}
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		base.KillEnemy();
		agent.speed = 0f;
		creatureVoice.Stop();
		creatureSFX.Stop();
		if (heldItem != null)
		{
			DropItemAndCallDropRPC(((Component)heldItem.itemGrabbableObject).GetComponent<NetworkObject>(), droppedInNest: false);
		}
	}

	public HoarderBugItem CheckLineOfSightForItem(HoarderBugItemStatus searchForItemsOfStatus = HoarderBugItemStatus.Any, float width = 45f, int range = 60, float proximityAwareness = -1f)
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < HoarderBugItems.Count; i++)
		{
			if (!HoarderBugItems[i].itemGrabbableObject.grabbableToEnemies || HoarderBugItems[i].itemGrabbableObject.isHeld || (searchForItemsOfStatus != HoarderBugItemStatus.Any && HoarderBugItems[i].status != searchForItemsOfStatus))
			{
				continue;
			}
			Vector3 position = ((Component)HoarderBugItems[i].itemGrabbableObject).transform.position;
			if (!Physics.Linecast(eye.position, position, StartOfRound.Instance.collidersAndRoomMaskAndDefault))
			{
				Vector3 val = position - eye.position;
				if (Vector3.Angle(eye.forward, val) < width || Vector3.Distance(((Component)this).transform.position, position) < proximityAwareness)
				{
					Debug.Log((object)"SEEING PLAYER");
					return HoarderBugItems[i];
				}
			}
		}
		return null;
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_HoarderBugAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3689917697u, new RpcReceiveHandler(__rpc_handler_3689917697));
		NetworkManager.__rpc_func_table.Add(1841413947u, new RpcReceiveHandler(__rpc_handler_1841413947));
		NetworkManager.__rpc_func_table.Add(3510928244u, new RpcReceiveHandler(__rpc_handler_3510928244));
		NetworkManager.__rpc_func_table.Add(847487221u, new RpcReceiveHandler(__rpc_handler_847487221));
		NetworkManager.__rpc_func_table.Add(2358561451u, new RpcReceiveHandler(__rpc_handler_2358561451));
		NetworkManager.__rpc_func_table.Add(1536760829u, new RpcReceiveHandler(__rpc_handler_1536760829));
		NetworkManager.__rpc_func_table.Add(1884379629u, new RpcReceiveHandler(__rpc_handler_1884379629));
		NetworkManager.__rpc_func_table.Add(1031891902u, new RpcReceiveHandler(__rpc_handler_1031891902));
	}

	private static void __rpc_handler_3689917697(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 newNestPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newNestPosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HoarderBugAI)(object)target).SyncNestPositionServerRpc(newNestPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1841413947(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newNestPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newNestPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HoarderBugAI)(object)target).SyncNestPositionClientRpc(newNestPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3510928244(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		NetworkObjectReference objectRef = default(NetworkObjectReference);
		((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
		Vector3 targetFloorPosition = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref targetFloorPosition);
		bool droppedInNest = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref droppedInNest, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((HoarderBugAI)(object)target).DropItemServerRpc(objectRef, targetFloorPosition, droppedInNest);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_847487221(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			Vector3 targetFloorPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetFloorPosition);
			bool droppedInNest = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref droppedInNest, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HoarderBugAI)(object)target).DropItemClientRpc(objectRef, targetFloorPosition, droppedInNest);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2358561451(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HoarderBugAI)(object)target).GrabItemServerRpc(objectRef);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1536760829(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HoarderBugAI)(object)target).GrabItemClientRpc(objectRef);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1884379629(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HoarderBugAI)(object)target).HitPlayerServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1031891902(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HoarderBugAI)(object)target).HitPlayerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "HoarderBugAI";
	}
}
