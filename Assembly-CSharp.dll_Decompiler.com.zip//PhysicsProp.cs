public class PhysicsProp : GrabbableObject
{
	public override void EquipItem()
	{
		base.EquipItem();
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "PhysicsProp";
	}
}
