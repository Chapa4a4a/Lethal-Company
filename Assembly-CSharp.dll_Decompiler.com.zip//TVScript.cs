using Unity.Netcode;
using UnityEngine;
using UnityEngine.Video;

public class TVScript : NetworkBehaviour
{
	public bool tvOn;

	private bool wasTvOnLastFrame;

	public MeshRenderer tvMesh;

	public VideoPlayer video;

	[Space(5f)]
	public VideoClip[] tvClips;

	public AudioClip[] tvAudioClips;

	[Space(5f)]
	private float currentClipTime;

	private int currentClip;

	public Material tvOnMaterial;

	public Material tvOffMaterial;

	public AudioClip switchTVOn;

	public AudioClip switchTVOff;

	public AudioSource tvSFX;

	private float timeSinceTurningOffTV;

	public Light tvLight;

	public void TurnTVOnOff(bool on)
	{
		tvOn = on;
		if (on)
		{
			tvSFX.clip = tvAudioClips[currentClip];
			tvSFX.time = currentClipTime;
			tvSFX.Play();
			tvSFX.PlayOneShot(switchTVOn);
			WalkieTalkie.TransmitOneShotAudio(tvSFX, switchTVOn);
		}
		else
		{
			tvSFX.Stop();
			tvSFX.PlayOneShot(switchTVOff);
			WalkieTalkie.TransmitOneShotAudio(tvSFX, switchTVOff);
		}
	}

	public void SwitchTVLocalClient()
	{
		if (tvOn)
		{
			TurnOffTVServerRpc();
		}
		else
		{
			TurnOnTVServerRpc();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void TurnOnTVServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4276612883u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4276612883u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			timeSinceTurningOffTV = 0f;
			if (timeSinceTurningOffTV > 7f)
			{
				TurnOnTVAndSyncClientRpc(currentClip, currentClipTime);
			}
			else
			{
				TurnOnTVClientRpc();
			}
		}
	}

	[ClientRpc]
	public void TurnOnTVClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3163094487u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3163094487u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				TurnTVOnOff(on: true);
			}
		}
	}

	[ClientRpc]
	public void TurnOnTVAndSyncClientRpc(int clipIndex, float clipTime)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(90711347u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clipIndex);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref clipTime, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 90711347u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				currentClip = clipIndex;
				currentClipTime = clipTime;
				TurnTVOnOff(on: true);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void TurnOffTVServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1273566447u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1273566447u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				TurnOffTVClientRpc();
			}
		}
	}

	[ClientRpc]
	public void TurnOffTVClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3106289039u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3106289039u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				TurnTVOnOff(on: false);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncTVServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3782954741u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3782954741u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SyncTVClientRpc(currentClip, currentClipTime, tvOn);
			}
		}
	}

	[ClientRpc]
	public void SyncTVClientRpc(int clipIndex, float clipTime, bool isOn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1554186895u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clipIndex);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref clipTime, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isOn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1554186895u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SyncTimeAndClipWithClients(clipIndex, clipTime, isOn);
			}
		}
	}

	private void SyncTimeAndClipWithClients(int clipIndex, float clipTime, bool isOn)
	{
		currentClip = clipIndex;
		currentClipTime = clipTime;
		tvOn = isOn;
	}

	private void OnEnable()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Expected O, but got Unknown
		video.loopPointReached += new EventHandler(TVFinishedClip);
	}

	private void OnDisable()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Expected O, but got Unknown
		video.loopPointReached -= new EventHandler(TVFinishedClip);
	}

	private void TVFinishedClip(VideoPlayer source)
	{
		if (tvOn && !GameNetworkManager.Instance.localPlayerController.isInsideFactory)
		{
			currentClip = (currentClip + 1) % tvClips.Length;
			video.clip = tvClips[currentClip];
			video.Play();
			tvSFX.clip = tvAudioClips[currentClip];
			tvSFX.time = 0f;
			tvSFX.Play();
		}
	}

	private void Update()
	{
		if (NetworkManager.Singleton.ShutdownInProgress || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		if (!tvOn || GameNetworkManager.Instance.localPlayerController.isInsideFactory)
		{
			if (wasTvOnLastFrame)
			{
				wasTvOnLastFrame = false;
				SetTVScreenMaterial(on: false);
				currentClipTime = (float)video.time;
				video.Stop();
			}
			if (((NetworkBehaviour)this).IsServer && !tvOn)
			{
				timeSinceTurningOffTV += Time.deltaTime;
			}
			currentClipTime += Time.deltaTime;
			if ((double)currentClipTime > tvClips[currentClip].length)
			{
				currentClip = (currentClip + 1) % tvClips.Length;
				currentClipTime = 0f;
				if (tvOn)
				{
					tvSFX.clip = tvAudioClips[currentClip];
					tvSFX.Play();
				}
			}
		}
		else
		{
			if (!wasTvOnLastFrame)
			{
				wasTvOnLastFrame = true;
				SetTVScreenMaterial(on: true);
				video.clip = tvClips[currentClip];
				video.time = currentClipTime;
				video.Play();
			}
			currentClipTime = (float)video.time;
		}
	}

	private void SetTVScreenMaterial(bool on)
	{
		Material[] sharedMaterials = ((Renderer)tvMesh).sharedMaterials;
		if (on)
		{
			sharedMaterials[1] = tvOnMaterial;
		}
		else
		{
			sharedMaterials[1] = tvOffMaterial;
		}
		((Renderer)tvMesh).sharedMaterials = sharedMaterials;
		((Behaviour)tvLight).enabled = on;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_TVScript()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(4276612883u, new RpcReceiveHandler(__rpc_handler_4276612883));
		NetworkManager.__rpc_func_table.Add(3163094487u, new RpcReceiveHandler(__rpc_handler_3163094487));
		NetworkManager.__rpc_func_table.Add(90711347u, new RpcReceiveHandler(__rpc_handler_90711347));
		NetworkManager.__rpc_func_table.Add(1273566447u, new RpcReceiveHandler(__rpc_handler_1273566447));
		NetworkManager.__rpc_func_table.Add(3106289039u, new RpcReceiveHandler(__rpc_handler_3106289039));
		NetworkManager.__rpc_func_table.Add(3782954741u, new RpcReceiveHandler(__rpc_handler_3782954741));
		NetworkManager.__rpc_func_table.Add(1554186895u, new RpcReceiveHandler(__rpc_handler_1554186895));
	}

	private static void __rpc_handler_4276612883(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((TVScript)(object)target).TurnOnTVServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3163094487(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TVScript)(object)target).TurnOnTVClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_90711347(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clipIndex);
			float clipTime = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref clipTime, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TVScript)(object)target).TurnOnTVAndSyncClientRpc(clipIndex, clipTime);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1273566447(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((TVScript)(object)target).TurnOffTVServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3106289039(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TVScript)(object)target).TurnOffTVClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3782954741(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((TVScript)(object)target).SyncTVServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1554186895(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clipIndex);
			float clipTime = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref clipTime, default(ForPrimitives));
			bool isOn = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isOn, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TVScript)(object)target).SyncTVClientRpc(clipIndex, clipTime, isOn);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "TVScript";
	}
}
