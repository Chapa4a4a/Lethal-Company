using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class PufferAI : EnemyAI
{
	private PlayerControllerB closestSeenPlayer;

	public AISearchRoutine roamMap;

	private float avoidPlayersTimer;

	private float fearTimer;

	private int previousBehaviourState = -1;

	public Transform lookAtPlayersCompass;

	private Coroutine shakeTailCoroutine;

	private bool inPuffingAnimation;

	private Vector3 agentLocalVelocity;

	private Vector3 previousPosition;

	public Transform animationContainer;

	private float velX;

	private float velZ;

	private float unclampedSpeed;

	private Vector3 lookAtNoise;

	private float timeSinceLookingAtNoise;

	private bool playerIsInLOS;

	private bool didStompAnimation;

	private bool inStompingAnimation;

	public AudioClip[] footstepsSFX;

	public AudioClip[] frightenSFX;

	public AudioClip stomp;

	public AudioClip angry;

	public AudioClip puff;

	public AudioClip nervousMumbling;

	public AudioClip rattleTail;

	public AudioClip bitePlayerSFX;

	[Space(5f)]
	public Transform tailPosition;

	public GameObject smokePrefab;

	private bool startedMovingAfterAlert;

	private float timeSinceAlert;

	private bool didPuffAnimation;

	private float timeSinceHittingPlayer;

	private bool gettingFarthestNodeFromPlayerAsync;

	private Transform farthestNodeFromTargetPlayer;

	public override void Start()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		lookAtNoise = Vector3.zero;
		base.Start();
	}

	public override void DoAIInterval()
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		if (StartOfRound.Instance.livingPlayers == 0)
		{
			base.DoAIInterval();
			return;
		}
		base.DoAIInterval();
		if (stunNormalizedTimer > 0f)
		{
			return;
		}
		PlayerControllerB playerControllerB = null;
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (((NetworkBehaviour)this).IsServer)
			{
				agent.angularSpeed = 300f;
				if (!roamMap.inProgress)
				{
					StartSearch(((Component)this).transform.position, roamMap);
				}
				playerControllerB = CheckLineOfSightForPlayer(45f, 20);
				playerIsInLOS = Object.op_Implicit((Object)(object)playerControllerB);
				if (playerIsInLOS)
				{
					ChangeOwnershipOfEnemy(playerControllerB.actualClientId);
					SwitchToBehaviourState(1);
				}
			}
			break;
		case 1:
			if (roamMap.inProgress)
			{
				StopSearch(roamMap);
			}
			playerControllerB = CheckLineOfSightForClosestPlayer(45f, 20, 2);
			playerIsInLOS = Object.op_Implicit((Object)(object)playerControllerB);
			if (!playerIsInLOS)
			{
				avoidPlayersTimer += AIIntervalTime;
				agent.angularSpeed = 300f;
			}
			else
			{
				avoidPlayersTimer = 0f;
				float num = Vector3.Distance(eye.position, ((Component)playerControllerB).transform.position);
				if (!inPuffingAnimation)
				{
					if (num < 5f)
					{
						if (didPuffAnimation)
						{
							SwitchToBehaviourState(2);
							break;
						}
						if (timeSinceAlert > 1.5f)
						{
							didPuffAnimation = true;
							inPuffingAnimation = true;
							ShakeTailServerRpc();
						}
					}
					else if (num < 7f && !didStompAnimation)
					{
						fearTimer += AIIntervalTime;
						if (fearTimer > 1f)
						{
							didStompAnimation = true;
							StompServerRpc();
						}
					}
				}
				if ((Object)(object)closestSeenPlayer == (Object)null || ((Object)(object)playerControllerB != (Object)(object)closestSeenPlayer && num < Vector3.Distance(eye.position, ((Component)closestSeenPlayer).transform.position)))
				{
					closestSeenPlayer = playerControllerB;
					avoidPlayersTimer = 0f;
					ChangeOwnershipOfEnemy(closestSeenPlayer.actualClientId);
				}
			}
			if (!inPuffingAnimation && (Object)(object)closestSeenPlayer != (Object)null)
			{
				AvoidClosestPlayer();
			}
			if (avoidPlayersTimer > 5f)
			{
				SwitchToBehaviourState(0);
				ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
			}
			break;
		case 2:
			if ((Object)(object)closestSeenPlayer == (Object)null)
			{
				closestSeenPlayer = CheckLineOfSightForClosestPlayer(45f, 20, 2);
				break;
			}
			playerIsInLOS = Object.op_Implicit((Object)(object)CheckLineOfSightForPlayer(70f, 20, 2));
			SetMovingTowardsTargetPlayer(closestSeenPlayer);
			break;
		}
	}

	private void LookAtPosition(Vector3 look, bool lookInstantly = false)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		agent.angularSpeed = 0f;
		lookAtPlayersCompass.LookAt(look);
		lookAtPlayersCompass.eulerAngles = new Vector3(0f, lookAtPlayersCompass.eulerAngles.y, 0f);
		if (lookInstantly)
		{
			((Component)this).transform.rotation = lookAtPlayersCompass.rotation;
		}
		else
		{
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, lookAtPlayersCompass.rotation, 10f * Time.deltaTime);
		}
	}

	private void CalculateAnimationDirection(float maxSpeed = 1.7f)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		agentLocalVelocity = animationContainer.InverseTransformDirection(Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 5f));
		velX = Mathf.Lerp(velX, 0f - agentLocalVelocity.x, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("moveX", Mathf.Clamp(velX, 0f - maxSpeed, maxSpeed));
		velZ = Mathf.Lerp(velZ, 0f - agentLocalVelocity.z, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("moveZ", Mathf.Clamp(velZ, 0f - maxSpeed, maxSpeed));
		previousPosition = ((Component)this).transform.position;
		creatureAnimator.SetFloat("movementSpeed", Mathf.Clamp(((Vector3)(ref agentLocalVelocity)).magnitude, 0f, maxSpeed));
	}

	public void AvoidClosestPlayer()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)farthestNodeFromTargetPlayer == (Object)null)
		{
			gettingFarthestNodeFromPlayerAsync = true;
			return;
		}
		Transform val = farthestNodeFromTargetPlayer;
		farthestNodeFromTargetPlayer = null;
		if ((Object)(object)val != (Object)null)
		{
			targetNode = val;
			SetDestinationToPosition(targetNode.position);
			return;
		}
		agent.speed = 0f;
		fearTimer += AIIntervalTime;
		if (timeSinceAlert < 0.75f)
		{
			return;
		}
		if (fearTimer > 1f && !didStompAnimation)
		{
			didStompAnimation = true;
			inStompingAnimation = true;
			StompServerRpc();
		}
		else if (fearTimer > 3f)
		{
			if (didPuffAnimation)
			{
				SwitchToBehaviourState(2);
				return;
			}
			didPuffAnimation = true;
			inPuffingAnimation = true;
			ShakeTailServerRpc();
		}
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesPlayedInOneSpot, noiseID);
		float num = Vector3.Distance(noisePosition, ((Component)this).transform.position);
		if (!(num > 15f))
		{
			if (Physics.Linecast(eye.position, noisePosition, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				noiseLoudness /= 2f;
			}
			if (!((double)(noiseLoudness / num) <= 0.045) && timeSinceLookingAtNoise > 5f)
			{
				timeSinceLookingAtNoise = 0f;
				lookAtNoise = noisePosition;
			}
		}
	}

	public override void Update()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0430: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead || inPuffingAnimation || inStompingAnimation)
		{
			return;
		}
		if (((NetworkBehaviour)this).IsOwner && gettingFarthestNodeFromPlayerAsync && (Object)(object)closestSeenPlayer != (Object)null)
		{
			Transform val = ChooseFarthestNodeFromPosition(maxAsyncIterations: (!(timeSinceAlert < 0.5f)) ? 10 : 30, pos: ((Component)closestSeenPlayer).transform.position, avoidLineOfSight: true, offset: 0, doAsync: true, capDistance: true);
			if (!gotFarthestNodeAsync)
			{
				return;
			}
			farthestNodeFromTargetPlayer = val;
			gettingFarthestNodeFromPlayerAsync = false;
		}
		timeSinceLookingAtNoise += Time.deltaTime;
		timeSinceHittingPlayer += Time.deltaTime;
		CalculateAnimationDirection(2f);
		if (stunNormalizedTimer > 0f)
		{
			creatureAnimator.SetLayerWeight(1, 1f);
		}
		else
		{
			creatureAnimator.SetLayerWeight(1, 0f);
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (previousBehaviourState != 0)
			{
				previousBehaviourState = 0;
				creatureAnimator.SetBool("alerted", false);
				agent.speed = 4f;
				playerIsInLOS = false;
				startedMovingAfterAlert = false;
				timeSinceAlert = 0f;
				creatureVoice.Stop();
				fearTimer = 0f;
				avoidPlayersTimer = 0f;
				didPuffAnimation = false;
				didStompAnimation = false;
				movingTowardsTargetPlayer = false;
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if (stunNormalizedTimer > 0f)
			{
				if ((Object)(object)stunnedByPlayer != (Object)null)
				{
					ChangeOwnershipOfEnemy(stunnedByPlayer.actualClientId);
					SwitchToBehaviourState(1);
				}
				agent.speed = 0f;
			}
			else
			{
				agent.speed = 4f;
			}
			fearTimer = Mathf.Clamp(fearTimer - Time.deltaTime, 0f, 100f);
			if (!playerIsInLOS && timeSinceLookingAtNoise < 2f)
			{
				LookAtPosition(lookAtNoise);
			}
			break;
		case 1:
			if (previousBehaviourState != 1)
			{
				if (previousBehaviourState != 2)
				{
					creatureAnimator.SetTrigger("alert");
					RoundManager.PlayRandomClip(creatureVoice, frightenSFX);
					creatureSFX.PlayOneShot(rattleTail);
					WalkieTalkie.TransmitOneShotAudio(creatureSFX, rattleTail);
					unclampedSpeed = -6f;
				}
				previousBehaviourState = 1;
				creatureAnimator.SetBool("alerted", true);
				playerIsInLOS = false;
				agent.speed = 0f;
				startedMovingAfterAlert = false;
				timeSinceAlert = 0f;
				fearTimer = 0f;
				didPuffAnimation = false;
				didStompAnimation = false;
				creatureAnimator.SetBool("attacking", false);
				movingTowardsTargetPlayer = false;
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			timeSinceAlert += Time.deltaTime;
			if (stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
				unclampedSpeed = 5f;
			}
			else
			{
				unclampedSpeed += Time.deltaTime * 4f;
				agent.speed = Mathf.Clamp(unclampedSpeed, 0f, 12f);
			}
			if (!startedMovingAfterAlert && agent.speed > 0.75f)
			{
				startedMovingAfterAlert = true;
				creatureVoice.clip = nervousMumbling;
				creatureVoice.Play();
			}
			if (!playerIsInLOS)
			{
				if (timeSinceLookingAtNoise < 1f)
				{
					LookAtPosition(lookAtNoise);
				}
				else if (avoidPlayersTimer < 1f && (Object)(object)closestSeenPlayer != (Object)null)
				{
					LookAtPosition(((Component)closestSeenPlayer).transform.position);
				}
			}
			else
			{
				LookAtPosition(((Component)closestSeenPlayer).transform.position);
			}
			break;
		case 2:
			if (previousBehaviourState != 2)
			{
				previousBehaviourState = 2;
				creatureAnimator.SetBool("attacking", true);
				playerIsInLOS = false;
				unclampedSpeed = 9f;
				startedMovingAfterAlert = false;
				timeSinceAlert = 0f;
				didPuffAnimation = false;
				didStompAnimation = false;
			}
			if (stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
				SwitchToBehaviourState(1);
			}
			else
			{
				unclampedSpeed = Mathf.Clamp(unclampedSpeed - Time.deltaTime * 5f, -1f, 100f);
				agent.speed = Mathf.Clamp(unclampedSpeed, 0f, 12f);
			}
			if (unclampedSpeed <= -0.75f)
			{
				SwitchToBehaviourState(1);
			}
			break;
		}
	}

	[ServerRpc]
	public void StompServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2829667697u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2829667697u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			StompClientRpc();
		}
	}

	[ClientRpc]
	public void StompClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3055061612u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3055061612u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (shakeTailCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(shakeTailCoroutine);
			}
			shakeTailCoroutine = ((MonoBehaviour)this).StartCoroutine(stompAnimation());
		}
	}

	[ServerRpc]
	public void ShakeTailServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3391967647u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3391967647u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			ShakeTailClientRpc();
		}
	}

	[ClientRpc]
	public void ShakeTailClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1543216111u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1543216111u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (shakeTailCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(shakeTailCoroutine);
			}
			shakeTailCoroutine = ((MonoBehaviour)this).StartCoroutine(shakeTailAnimation());
		}
	}

	private IEnumerator stompAnimation()
	{
		didStompAnimation = true;
		inPuffingAnimation = true;
		creatureAnimator.SetTrigger("stomp");
		agent.speed = 0f;
		yield return (object)new WaitForSeconds(0.15f);
		creatureSFX.PlayOneShot(stomp);
		WalkieTalkie.TransmitOneShotAudio(creatureSFX, stomp);
		RoundManager.Instance.PlayAudibleNoise(((Component)creatureSFX).transform.position, 8f, 0.8f);
		yield return (object)new WaitForSeconds(0.7f);
		timeSinceAlert = 0f;
		inStompingAnimation = false;
		inPuffingAnimation = false;
		unclampedSpeed = 0f;
	}

	private IEnumerator shakeTailAnimation()
	{
		didPuffAnimation = true;
		inPuffingAnimation = true;
		inStompingAnimation = false;
		creatureAnimator.SetTrigger("puff");
		creatureVoice.Stop();
		creatureVoice.PlayOneShot(angry);
		agent.speed = 0f;
		WalkieTalkie.TransmitOneShotAudio(creatureSFX, angry);
		yield return (object)new WaitForSeconds(0.5f);
		creatureSFX.PlayOneShot(puff);
		WalkieTalkie.TransmitOneShotAudio(creatureSFX, puff);
		Object.Instantiate<GameObject>(smokePrefab, tailPosition.position, Quaternion.identity, RoundManager.Instance.mapPropsContainer.transform);
		yield return (object)new WaitForSeconds(0.2f);
		timeSinceAlert = -2f;
		creatureVoice.clip = nervousMumbling;
		creatureVoice.Play();
		inPuffingAnimation = false;
		fearTimer = 0f;
		unclampedSpeed = 3f;
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
		if ((Object)(object)playerControllerB != (Object)null && timeSinceHittingPlayer > 1f)
		{
			timeSinceHittingPlayer = 0f;
			playerControllerB.DamagePlayer(20, hasDamageSFX: true, callRPC: true, CauseOfDeath.Mauling);
			BitePlayerServerRpc((int)playerControllerB.playerClientId);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void BitePlayerServerRpc(int playerBit)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3361827964u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerBit);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3361827964u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				BitePlayerClientRpc(playerBit);
			}
		}
	}

	[ClientRpc]
	public void BitePlayerClientRpc(int playerBit)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2332892213u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerBit);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2332892213u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (unclampedSpeed > 0.25f)
			{
				unclampedSpeed = 0.25f;
			}
			timeSinceHittingPlayer = 0f;
			creatureVoice.PlayOneShot(bitePlayerSFX);
			WalkieTalkie.TransmitOneShotAudio(creatureVoice, bitePlayerSFX);
			creatureAnimator.SetTrigger("Bite");
			LookAtPosition(((Component)StartOfRound.Instance.allPlayerScripts[playerBit]).transform.position, lookInstantly: true);
			if (((NetworkBehaviour)this).IsOwner && currentBehaviourStateIndex == 0)
			{
				SwitchToBehaviourState(1);
			}
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		base.KillEnemy(destroy);
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_PufferAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2829667697u, new RpcReceiveHandler(__rpc_handler_2829667697));
		NetworkManager.__rpc_func_table.Add(3055061612u, new RpcReceiveHandler(__rpc_handler_3055061612));
		NetworkManager.__rpc_func_table.Add(3391967647u, new RpcReceiveHandler(__rpc_handler_3391967647));
		NetworkManager.__rpc_func_table.Add(1543216111u, new RpcReceiveHandler(__rpc_handler_1543216111));
		NetworkManager.__rpc_func_table.Add(3361827964u, new RpcReceiveHandler(__rpc_handler_3361827964));
		NetworkManager.__rpc_func_table.Add(2332892213u, new RpcReceiveHandler(__rpc_handler_2332892213));
	}

	private static void __rpc_handler_2829667697(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PufferAI)(object)target).StompServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3055061612(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PufferAI)(object)target).StompClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3391967647(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PufferAI)(object)target).ShakeTailServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1543216111(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PufferAI)(object)target).ShakeTailClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3361827964(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerBit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerBit);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PufferAI)(object)target).BitePlayerServerRpc(playerBit);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2332892213(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerBit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerBit);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PufferAI)(object)target).BitePlayerClientRpc(playerBit);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "PufferAI";
	}
}
