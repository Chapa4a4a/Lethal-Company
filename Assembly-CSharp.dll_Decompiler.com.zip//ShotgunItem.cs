using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class ShotgunItem : GrabbableObject
{
	public int gunCompatibleAmmoID = 1410;

	public bool isReloading;

	public int shellsLoaded;

	public Animator gunAnimator;

	public AudioSource gunAudio;

	public AudioSource gunShootAudio;

	public AudioSource gunBulletsRicochetAudio;

	private Coroutine gunCoroutine;

	public AudioClip[] gunShootSFX;

	public AudioClip gunReloadSFX;

	public AudioClip gunReloadFinishSFX;

	public AudioClip noAmmoSFX;

	public AudioClip gunSafetySFX;

	public AudioClip switchSafetyOnSFX;

	public AudioClip switchSafetyOffSFX;

	public bool safetyOn;

	private float misfireTimer = 30f;

	private bool hasHitGroundWithSafetyOff = true;

	private int ammoSlotToUse = -1;

	private bool localClientSendingShootGunRPC;

	private PlayerControllerB previousPlayerHeldBy;

	public ParticleSystem gunShootParticle;

	public Transform shotgunRayPoint;

	public MeshRenderer shotgunShellLeft;

	public MeshRenderer shotgunShellRight;

	public MeshRenderer shotgunShellInHand;

	public Transform shotgunShellInHandTransform;

	private RaycastHit[] enemyColliders;

	private EnemyAI heldByEnemy;

	public override void Start()
	{
		base.Start();
		misfireTimer = 30f;
		hasHitGroundWithSafetyOff = true;
	}

	public override int GetItemDataToSave()
	{
		base.GetItemDataToSave();
		return shellsLoaded;
	}

	public override void LoadItemSaveData(int saveData)
	{
		base.LoadItemSaveData(saveData);
		safetyOn = true;
		shellsLoaded = saveData;
	}

	public override void Update()
	{
		base.Update();
		if (!((NetworkBehaviour)this).IsOwner || shellsLoaded <= 0 || isReloading || (Object)(object)heldByEnemy != (Object)null || isPocketed)
		{
			return;
		}
		if (hasHitGround && !safetyOn && !hasHitGroundWithSafetyOff && !isHeld)
		{
			if (Random.Range(0, 100) < 5)
			{
				ShootGunAndSync(heldByPlayer: false);
			}
			hasHitGroundWithSafetyOff = true;
		}
		else if (!safetyOn && misfireTimer <= 0f && !StartOfRound.Instance.inShipPhase)
		{
			if (Random.Range(0, 100) < 4)
			{
				ShootGunAndSync(isHeld);
			}
			if (Random.Range(0, 100) < 5)
			{
				misfireTimer = 2f;
			}
			else
			{
				misfireTimer = Random.Range(28f, 50f);
			}
		}
		else if (!safetyOn)
		{
			misfireTimer -= Time.deltaTime;
		}
	}

	public override void EquipItem()
	{
		base.EquipItem();
		previousPlayerHeldBy = playerHeldBy;
		previousPlayerHeldBy.equippedUsableItemQE = true;
		hasHitGroundWithSafetyOff = false;
	}

	public override void GrabItemFromEnemy(EnemyAI enemy)
	{
		base.GrabItemFromEnemy(enemy);
		heldByEnemy = enemy;
		hasHitGroundWithSafetyOff = false;
	}

	public override void DiscardItemFromEnemy()
	{
		base.DiscardItemFromEnemy();
		heldByEnemy = null;
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		if (!isReloading)
		{
			if (shellsLoaded == 0)
			{
				StartReloadGun();
			}
			else if (safetyOn)
			{
				gunAudio.PlayOneShot(gunSafetySFX);
			}
			else if (((NetworkBehaviour)this).IsOwner)
			{
				ShootGunAndSync(heldByPlayer: true);
			}
		}
	}

	public void ShootGunAndSync(bool heldByPlayer)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 shotgunPosition;
		Vector3 forward;
		if (!heldByPlayer)
		{
			shotgunPosition = shotgunRayPoint.position;
			forward = shotgunRayPoint.forward;
		}
		else
		{
			shotgunPosition = ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position - ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.up * 0.45f;
			forward = ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward;
		}
		Debug.Log((object)"Calling shoot gun....");
		ShootGun(shotgunPosition, forward);
		Debug.Log((object)"Calling shoot gun and sync");
		localClientSendingShootGunRPC = true;
		ShootGunServerRpc(shotgunPosition, forward);
	}

	[ServerRpc(RequireOwnership = false)]
	public void ShootGunServerRpc(Vector3 shotgunPosition, Vector3 shotgunForward)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1329927282u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref shotgunPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref shotgunForward);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1329927282u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ShootGunClientRpc(shotgunPosition, shotgunForward);
			}
		}
	}

	[ClientRpc]
	public void ShootGunClientRpc(Vector3 shotgunPosition, Vector3 shotgunForward)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4176294522u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref shotgunPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref shotgunForward);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4176294522u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			Debug.Log((object)"Shoot gun client rpc received");
			if (localClientSendingShootGunRPC)
			{
				localClientSendingShootGunRPC = false;
				Debug.Log((object)"localClientSendingShootGunRPC was true");
			}
			else
			{
				ShootGun(shotgunPosition, shotgunForward);
			}
		}
	}

	public void ShootGun(Vector3 shotgunPosition, Vector3 shotgunForward)
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_0325: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03de: Unknown result type (might be due to invalid IL or missing references)
		isReloading = false;
		bool flag = false;
		if (isHeld && (Object)(object)playerHeldBy != (Object)null && (Object)(object)playerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			playerHeldBy.playerBodyAnimator.SetTrigger("ShootShotgun");
			flag = true;
		}
		RoundManager.PlayRandomClip(gunShootAudio, gunShootSFX, randomize: true, 1f, 1840);
		WalkieTalkie.TransmitOneShotAudio(gunShootAudio, gunShootSFX[0]);
		gunShootParticle.Play(true);
		shellsLoaded = Mathf.Clamp(shellsLoaded - 1, 0, 2);
		PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
		if ((Object)(object)localPlayerController == (Object)null)
		{
			return;
		}
		float num = Vector3.Distance(((Component)localPlayerController).transform.position, ((Component)shotgunRayPoint).transform.position);
		bool flag2 = false;
		int damageNumber = 0;
		float num2 = 0f;
		Vector3 val = localPlayerController.playerCollider.ClosestPoint(shotgunPosition);
		if (!flag && !Physics.Linecast(shotgunPosition, val, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) && Vector3.Angle(shotgunForward, val - shotgunPosition) < 30f)
		{
			flag2 = true;
		}
		if (num < 5f)
		{
			num2 = 0.8f;
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			damageNumber = 100;
		}
		if (num < 15f)
		{
			num2 = 0.5f;
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			damageNumber = 100;
		}
		else if (num < 23f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
			damageNumber = 40;
		}
		else if (num < 30f)
		{
			damageNumber = 20;
		}
		if (num2 > 0f && SoundManager.Instance.timeSinceEarsStartedRinging > 16f)
		{
			((MonoBehaviour)this).StartCoroutine(delayedEarsRinging(num2));
		}
		Ray val2 = default(Ray);
		((Ray)(ref val2))._002Ector(shotgunPosition, shotgunForward);
		RaycastHit val3 = default(RaycastHit);
		if (Physics.Raycast(val2, ref val3, 30f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			((Component)gunBulletsRicochetAudio).transform.position = ((Ray)(ref val2)).GetPoint(((RaycastHit)(ref val3)).distance - 0.5f);
			gunBulletsRicochetAudio.Play();
		}
		if (flag2)
		{
			localPlayerController.DamagePlayer(damageNumber, hasDamageSFX: true, callRPC: true, CauseOfDeath.Gunshots, 0, fallDamage: false, shotgunRayPoint.forward * 30f);
		}
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (enemyColliders == null)
		{
			enemyColliders = (RaycastHit[])(object)new RaycastHit[10];
		}
		((Ray)(ref val2))._002Ector(shotgunPosition - shotgunForward * 10f, shotgunForward);
		int num3 = Physics.SphereCastNonAlloc(val2, 5f, enemyColliders, 15f, 524288, (QueryTriggerInteraction)2);
		List<EnemyAI> list = new List<EnemyAI>();
		IHittable hittable = default(IHittable);
		for (int i = 0; i < num3; i++)
		{
			if (!Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref enemyColliders[i])).transform).GetComponent<EnemyAICollisionDetect>()))
			{
				continue;
			}
			EnemyAI mainScript = ((Component)((RaycastHit)(ref enemyColliders[i])).transform).GetComponent<EnemyAICollisionDetect>().mainScript;
			if ((Object)(object)heldByEnemy != (Object)null && (Object)(object)heldByEnemy == (Object)(object)mainScript)
			{
				continue;
			}
			if (((RaycastHit)(ref enemyColliders[i])).distance == 0f)
			{
				Debug.Log((object)"Spherecast started inside enemy collider");
			}
			else if (!Physics.Linecast(shotgunPosition, ((RaycastHit)(ref enemyColliders[i])).point, ref val3, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) && ((Component)((RaycastHit)(ref enemyColliders[i])).transform).TryGetComponent<IHittable>(ref hittable))
			{
				float num4 = Vector3.Distance(shotgunPosition, ((RaycastHit)(ref enemyColliders[i])).point);
				int force = ((num4 < 3.7f) ? 5 : ((!(num4 < 6f)) ? 2 : 3));
				EnemyAICollisionDetect component = ((Component)((RaycastHit)(ref enemyColliders[i])).collider).GetComponent<EnemyAICollisionDetect>();
				if ((!((Object)(object)component != (Object)null) || (!((Object)(object)component.mainScript == (Object)null) && !list.Contains(component.mainScript))) && hittable.Hit(force, shotgunForward, playerHeldBy, playHitSFX: true) && (Object)(object)component != (Object)null)
				{
					list.Add(component.mainScript);
				}
			}
		}
	}

	private IEnumerator delayedEarsRinging(float effectSeverity)
	{
		yield return (object)new WaitForSeconds(0.6f);
		SoundManager.Instance.earsRingingTimer = effectSeverity;
	}

	public override void ItemInteractLeftRight(bool right)
	{
		base.ItemInteractLeftRight(right);
		if ((Object)(object)playerHeldBy == (Object)null)
		{
			return;
		}
		Debug.Log((object)$"r/l activate: {right}");
		if (!right)
		{
			if (safetyOn)
			{
				safetyOn = false;
				gunAudio.PlayOneShot(switchSafetyOffSFX);
				WalkieTalkie.TransmitOneShotAudio(gunAudio, switchSafetyOffSFX);
				SetSafetyControlTip();
			}
			else
			{
				safetyOn = true;
				gunAudio.PlayOneShot(switchSafetyOnSFX);
				WalkieTalkie.TransmitOneShotAudio(gunAudio, switchSafetyOnSFX);
				SetSafetyControlTip();
			}
			playerHeldBy.playerBodyAnimator.SetTrigger("SwitchGunSafety");
		}
		else if (!isReloading && shellsLoaded < 2)
		{
			StartReloadGun();
		}
	}

	public override void SetControlTipsForItem()
	{
		string[] toolTips = itemProperties.toolTips;
		if (toolTips.Length <= 2)
		{
			Debug.LogError((object)"Shotgun control tips array length is too short to set tips!");
			return;
		}
		if (safetyOn)
		{
			toolTips[2] = "Turn safety off: [Q]";
		}
		else
		{
			toolTips[2] = "Turn safety on: [Q]";
		}
		HUDManager.Instance.ChangeControlTipMultiple(toolTips, holdingItem: true, itemProperties);
	}

	private void SetSafetyControlTip()
	{
		string changeTo = ((!safetyOn) ? "Turn safety on: [Q]" : "Turn safety off: [Q]");
		if (((NetworkBehaviour)this).IsOwner)
		{
			HUDManager.Instance.ChangeControlTip(3, changeTo);
		}
	}

	private void StartReloadGun()
	{
		if (ReloadedGun())
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				if (gunCoroutine != null)
				{
					((MonoBehaviour)this).StopCoroutine(gunCoroutine);
				}
				gunCoroutine = ((MonoBehaviour)this).StartCoroutine(reloadGunAnimation());
			}
		}
		else
		{
			gunAudio.PlayOneShot(noAmmoSFX);
		}
	}

	[ServerRpc]
	public void ReloadGunEffectsServerRpc(bool start = true)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3349119596u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref start, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3349119596u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			ReloadGunEffectsClientRpc(start);
		}
	}

	[ClientRpc]
	public void ReloadGunEffectsClientRpc(bool start = true)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2673645315u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref start, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2673645315u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
		{
			if (start)
			{
				gunAudio.PlayOneShot(gunReloadSFX);
				WalkieTalkie.TransmitOneShotAudio(gunAudio, gunReloadSFX);
				gunAnimator.SetBool("Reloading", true);
				isReloading = true;
			}
			else
			{
				shellsLoaded = Mathf.Clamp(shellsLoaded + 1, 0, 2);
				gunAudio.PlayOneShot(gunReloadFinishSFX);
				gunAnimator.SetBool("Reloading", false);
				isReloading = false;
			}
		}
	}

	private IEnumerator reloadGunAnimation()
	{
		isReloading = true;
		if (shellsLoaded <= 0)
		{
			playerHeldBy.playerBodyAnimator.SetBool("ReloadShotgun", true);
			((Renderer)shotgunShellLeft).enabled = false;
			((Renderer)shotgunShellRight).enabled = false;
		}
		else
		{
			playerHeldBy.playerBodyAnimator.SetBool("ReloadShotgun2", true);
			((Renderer)shotgunShellRight).enabled = false;
		}
		yield return (object)new WaitForSeconds(0.3f);
		gunAudio.PlayOneShot(gunReloadSFX);
		gunAnimator.SetBool("Reloading", true);
		ReloadGunEffectsServerRpc();
		yield return (object)new WaitForSeconds(0.95f);
		((Renderer)shotgunShellInHand).enabled = true;
		shotgunShellInHandTransform.SetParent(playerHeldBy.leftHandItemTarget);
		shotgunShellInHandTransform.localPosition = new Vector3(-0.0555f, 0.1469f, -0.0655f);
		shotgunShellInHandTransform.localEulerAngles = new Vector3(-1.956f, 143.856f, -16.427f);
		yield return (object)new WaitForSeconds(0.95f);
		playerHeldBy.DestroyItemInSlotAndSync(ammoSlotToUse);
		ammoSlotToUse = -1;
		shellsLoaded = Mathf.Clamp(shellsLoaded + 1, 0, 2);
		((Renderer)shotgunShellLeft).enabled = true;
		if (shellsLoaded == 2)
		{
			((Renderer)shotgunShellRight).enabled = true;
		}
		((Renderer)shotgunShellInHand).enabled = false;
		shotgunShellInHandTransform.SetParent(((Component)this).transform);
		yield return (object)new WaitForSeconds(0.45f);
		gunAudio.PlayOneShot(gunReloadFinishSFX);
		gunAnimator.SetBool("Reloading", false);
		playerHeldBy.playerBodyAnimator.SetBool("ReloadShotgun", false);
		playerHeldBy.playerBodyAnimator.SetBool("ReloadShotgun2", false);
		isReloading = false;
		ReloadGunEffectsServerRpc(start: false);
	}

	private bool ReloadedGun()
	{
		int num = FindAmmoInInventory();
		if (num == -1)
		{
			Debug.Log((object)"not reloading");
			return false;
		}
		Debug.Log((object)"reloading!");
		ammoSlotToUse = num;
		return true;
	}

	private int FindAmmoInInventory()
	{
		for (int i = 0; i < playerHeldBy.ItemSlots.Length; i++)
		{
			if (!((Object)(object)playerHeldBy.ItemSlots[i] == (Object)null))
			{
				GunAmmo gunAmmo = playerHeldBy.ItemSlots[i] as GunAmmo;
				Debug.Log((object)$"Ammo null in slot #{i}?: {(Object)(object)gunAmmo == (Object)null}");
				if ((Object)(object)gunAmmo != (Object)null)
				{
					Debug.Log((object)$"Ammo in slot #{i} id: {gunAmmo.ammoType}");
				}
				if ((Object)(object)gunAmmo != (Object)null && gunAmmo.ammoType == gunCompatibleAmmoID)
				{
					return i;
				}
			}
		}
		return -1;
	}

	public override void PocketItem()
	{
		base.PocketItem();
		StopUsingGun();
	}

	public override void DiscardItem()
	{
		base.DiscardItem();
		StopUsingGun();
	}

	private void StopUsingGun()
	{
		previousPlayerHeldBy.equippedUsableItemQE = false;
		if (isReloading)
		{
			if (gunCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(gunCoroutine);
			}
			gunAnimator.SetBool("Reloading", false);
			gunAudio.Stop();
			if ((Object)(object)previousPlayerHeldBy != (Object)null)
			{
				previousPlayerHeldBy.playerBodyAnimator.SetBool("ReloadShotgun", false);
				previousPlayerHeldBy.playerBodyAnimator.SetBool("ReloadShotgun2", false);
			}
			((Renderer)shotgunShellInHand).enabled = false;
			shotgunShellInHandTransform.SetParent(((Component)this).transform);
			isReloading = false;
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ShotgunItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1329927282u, new RpcReceiveHandler(__rpc_handler_1329927282));
		NetworkManager.__rpc_func_table.Add(4176294522u, new RpcReceiveHandler(__rpc_handler_4176294522));
		NetworkManager.__rpc_func_table.Add(3349119596u, new RpcReceiveHandler(__rpc_handler_3349119596));
		NetworkManager.__rpc_func_table.Add(2673645315u, new RpcReceiveHandler(__rpc_handler_2673645315));
	}

	private static void __rpc_handler_1329927282(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 shotgunPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref shotgunPosition);
			Vector3 shotgunForward = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref shotgunForward);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShotgunItem)(object)target).ShootGunServerRpc(shotgunPosition, shotgunForward);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4176294522(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 shotgunPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref shotgunPosition);
			Vector3 shotgunForward = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref shotgunForward);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShotgunItem)(object)target).ShootGunClientRpc(shotgunPosition, shotgunForward);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3349119596(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool start = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref start, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShotgunItem)(object)target).ReloadGunEffectsServerRpc(start);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2673645315(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool start = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref start, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShotgunItem)(object)target).ReloadGunEffectsClientRpc(start);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ShotgunItem";
	}
}
