using UnityEngine;

public class SetLineRendererPoints : MonoBehaviour
{
	private LineRenderer lineRenderer;

	public Transform anchor;

	public Transform target;

	private void Start()
	{
		lineRenderer = ((Component)this).gameObject.GetComponent<LineRenderer>();
	}

	private void LateUpdate()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		lineRenderer.SetPosition(0, anchor.position);
		lineRenderer.SetPosition(1, target.position);
	}
}
