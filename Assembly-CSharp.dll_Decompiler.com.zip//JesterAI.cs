using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class JesterAI : EnemyAI
{
	public AudioSource farAudio;

	public AISearchRoutine roamMap;

	private Vector3 spawnPosition;

	public float popUpTimer;

	public float beginCrankingTimer;

	private int previousState;

	public AudioClip popGoesTheWeaselTheme;

	public AudioClip popUpSFX;

	public AudioClip screamingSFX;

	public AudioClip killPlayerSFX;

	private Vector3 previousPosition;

	public float maxAnimSpeed;

	private float noPlayersToChaseTimer;

	private bool targetingPlayer;

	public Transform headRigTarget;

	public Transform lookForwardTarget;

	public Collider mainCollider;

	private bool inKillAnimation;

	private Coroutine killPlayerAnimCoroutine;

	public Transform grabBodyPoint;

	public override void Start()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		spawnPosition = ((Component)this).transform.position;
		SetJesterInitialValues();
	}

	public override void DoAIInterval()
	{
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.livingPlayers == 0 || isEnemyDead)
		{
			return;
		}
		if (!((NetworkBehaviour)this).IsServer && ((NetworkBehaviour)this).IsOwner && currentBehaviourStateIndex != 2)
		{
			ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			if (stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
			}
			else
			{
				agent.speed = 5f;
			}
			agent.stoppingDistance = 4f;
			addPlayerVelocityToDestination = 0f;
			PlayerControllerB playerControllerB = targetPlayer;
			if (TargetClosestPlayer(3f, requireLineOfSight: true))
			{
				if (roamMap.inProgress)
				{
					StopSearch(roamMap);
				}
				SetMovingTowardsTargetPlayer(targetPlayer);
			}
			else
			{
				targetPlayer = playerControllerB;
			}
			if (!((Object)(object)targetPlayer != (Object)null) && (Object)(object)targetPlayer == (Object)null && !roamMap.inProgress)
			{
				StartSearch(spawnPosition, roamMap);
			}
			break;
		}
		case 1:
			agent.speed = 0f;
			break;
		case 2:
		{
			agent.stoppingDistance = 0f;
			PlayerControllerB playerControllerB = targetPlayer;
			bool flag = false;
			if ((Object)(object)targetPlayer == (Object)null)
			{
				flag = true;
			}
			else if (!PlayerIsTargetable(targetPlayer) || PathIsIntersectedByLineOfSight(RoundManager.Instance.GetNavMeshPosition(((Component)targetPlayer).transform.position, default(NavMeshHit), 5f, agent.areaMask)))
			{
				flag = true;
			}
			addPlayerVelocityToDestination = 1f;
			if (!TargetClosestPlayer(4f) && (Object)(object)playerControllerB != (Object)null && !flag)
			{
				targetPlayer = playerControllerB;
			}
			if ((Object)(object)targetPlayer != (Object)null)
			{
				if (roamMap.inProgress)
				{
					StopSearch(roamMap);
				}
				SetMovingTowardsTargetPlayer(targetPlayer);
				if ((Object)(object)targetPlayer != (Object)(object)playerControllerB)
				{
					ChangeOwnershipOfEnemy(targetPlayer.actualClientId);
				}
			}
			break;
		}
		}
	}

	private void CalculateAnimationSpeed(float maxSpeed = 1f)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, maxSpeed);
		float num = ((Vector3)(ref val)).magnitude / (Time.deltaTime * 3f);
		creatureAnimator.SetFloat("speedOfMovement", num);
		previousPosition = ((Component)this).transform.position;
		creatureAnimator.SetBool("walking", num > 0.05f);
	}

	private void SetJesterInitialValues()
	{
		targetPlayer = null;
		popUpTimer = Random.Range(35f, 40f);
		beginCrankingTimer = Random.Range(13f, 21f);
		if (StartOfRound.Instance.connectedPlayersAmount == 0)
		{
			beginCrankingTimer = Random.Range(25f, 42f);
		}
		creatureAnimator.SetBool("turningCrank", false);
		creatureAnimator.SetBool("poppedOut", false);
		creatureAnimator.SetFloat("CrankSpeedMultiplier", 1f);
		creatureAnimator.SetBool("stunned", false);
		mainCollider.isTrigger = false;
		noPlayersToChaseTimer = 0f;
		farAudio.Stop();
		creatureVoice.Stop();
		creatureSFX.Stop();
	}

	public override void Update()
	{
		//IL_030b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		if (isEnemyDead)
		{
			return;
		}
		CalculateAnimationSpeed(maxAnimSpeed);
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (previousState != 0)
			{
				previousState = 0;
				mainCollider.isTrigger = false;
				SetJesterInitialValues();
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if (stunNormalizedTimer > 0f)
			{
				beginCrankingTimer -= Time.deltaTime * 15f;
			}
			if ((Object)(object)targetPlayer != (Object)null)
			{
				beginCrankingTimer -= Time.deltaTime;
				if (beginCrankingTimer <= 0f)
				{
					SwitchToBehaviourState(1);
				}
			}
			break;
		case 1:
			if (previousState != 1)
			{
				previousState = 1;
				creatureAnimator.SetBool("turningCrank", true);
				farAudio.clip = popGoesTheWeaselTheme;
				farAudio.Play();
				agent.speed = 0f;
			}
			if (stunNormalizedTimer > 0f)
			{
				farAudio.Pause();
				creatureAnimator.SetFloat("CrankSpeedMultiplier", 0f);
			}
			else
			{
				if (!farAudio.isPlaying)
				{
					farAudio.UnPause();
				}
				creatureAnimator.SetFloat("CrankSpeedMultiplier", 1f);
				popUpTimer -= Time.deltaTime;
				if (popUpTimer <= 0f && ((NetworkBehaviour)this).IsOwner)
				{
					SwitchToBehaviourState(2);
				}
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
			}
			break;
		case 2:
			if (previousState != 2)
			{
				previousState = 2;
				farAudio.Stop();
				creatureAnimator.SetBool("poppedOut", true);
				creatureAnimator.SetFloat("CrankSpeedMultiplier", 1f);
				creatureSFX.PlayOneShot(popUpSFX);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, popUpSFX);
				creatureVoice.clip = screamingSFX;
				creatureVoice.Play();
				agent.speed = 0f;
				mainCollider.isTrigger = true;
				agent.stoppingDistance = 0f;
			}
			if (((NetworkBehaviour)this).IsOwner && (Object)(object)targetPlayer != (Object)null && CheckLineOfSightForPosition(((Component)targetPlayer.gameplayCamera).transform.position, 80f, 80))
			{
				headRigTarget.rotation = Quaternion.Lerp(headRigTarget.rotation, Quaternion.LookRotation(((Component)targetPlayer.gameplayCamera).transform.position - ((Component)headRigTarget).transform.position, Vector3.up), 5f * Time.deltaTime);
			}
			else
			{
				headRigTarget.rotation = Quaternion.Lerp(headRigTarget.rotation, Quaternion.LookRotation(lookForwardTarget.position - ((Component)headRigTarget).transform.position, Vector3.up), 5f * Time.deltaTime);
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if (inKillAnimation || stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
			}
			else
			{
				agent.speed = Mathf.Clamp(agent.speed + Time.deltaTime * 1.45f, 0f, 18f);
			}
			creatureAnimator.SetBool("stunned", stunNormalizedTimer > 0f);
			if (!targetingPlayer)
			{
				bool flag = false;
				for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
				{
					if (StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled && StartOfRound.Instance.allPlayerScripts[i].isInsideFactory)
					{
						flag = true;
					}
				}
				if (!flag)
				{
					noPlayersToChaseTimer -= Time.deltaTime;
					if (noPlayersToChaseTimer <= 0f)
					{
						SwitchToBehaviourState(0);
					}
				}
			}
			else
			{
				noPlayersToChaseTimer = 5f;
			}
			break;
		}
		base.Update();
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		if (!Object.op_Implicit((Object)(object)((Component)other).gameObject.GetComponent<PlayerControllerB>()))
		{
			return;
		}
		Debug.Log((object)("Jester collided with player: " + ((Object)((Component)other).gameObject).name));
		base.OnCollideWithPlayer(other);
		if (inKillAnimation)
		{
			return;
		}
		Debug.Log((object)"Jester collided A");
		if (isEnemyDead)
		{
			return;
		}
		Debug.Log((object)"Jester collided C");
		if (currentBehaviourStateIndex == 2)
		{
			Debug.Log((object)"Jester collided D");
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				inKillAnimation = true;
				KillPlayerServerRpc((int)playerControllerB.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KillPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3446243450u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3446243450u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (!inKillAnimation || ((NetworkBehaviour)StartOfRound.Instance.allPlayerScripts[playerId]).IsOwnedByServer)
			{
				inKillAnimation = true;
				KillPlayerClientRpc(playerId);
			}
			else
			{
				CancelKillPlayerClientRpc();
			}
		}
	}

	[ClientRpc]
	public void CancelKillPlayerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1851545498u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1851545498u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && killPlayerAnimCoroutine == null)
			{
				inKillAnimation = false;
			}
		}
	}

	[ClientRpc]
	public void KillPlayerClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(569892066u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 569892066u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (killPlayerAnimCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(killPlayerAnimCoroutine);
			}
			killPlayerAnimCoroutine = ((MonoBehaviour)this).StartCoroutine(killPlayerAnimation(playerId));
		}
	}

	private IEnumerator killPlayerAnimation(int playerId)
	{
		creatureSFX.PlayOneShot(killPlayerSFX);
		inKillAnimation = true;
		PlayerControllerB playerScript = StartOfRound.Instance.allPlayerScripts[playerId];
		playerScript.KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Mauling);
		creatureAnimator.SetTrigger("KillPlayer");
		float startTime = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)playerScript.deadBody != (Object)null || Time.realtimeSinceStartup - startTime > 2f));
		DeadBodyInfo body = playerScript.deadBody;
		if ((Object)(object)body != (Object)null && (Object)(object)body.attachedTo == (Object)null)
		{
			body.attachedLimb = body.bodyParts[5];
			body.attachedTo = grabBodyPoint;
			body.matchPositionExactly = true;
		}
		yield return (object)new WaitForSeconds(1.8f);
		if ((Object)(object)body != (Object)null && (Object)(object)body.attachedTo == (Object)(object)grabBodyPoint)
		{
			body.attachedLimb = null;
			body.attachedTo = null;
			body.matchPositionExactly = false;
		}
		yield return (object)new WaitForSeconds(0.4f);
		inKillAnimation = false;
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_JesterAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3446243450u, new RpcReceiveHandler(__rpc_handler_3446243450));
		NetworkManager.__rpc_func_table.Add(1851545498u, new RpcReceiveHandler(__rpc_handler_1851545498));
		NetworkManager.__rpc_func_table.Add(569892066u, new RpcReceiveHandler(__rpc_handler_569892066));
	}

	private static void __rpc_handler_3446243450(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((JesterAI)(object)target).KillPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1851545498(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((JesterAI)(object)target).CancelKillPlayerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_569892066(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((JesterAI)(object)target).KillPlayerClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "JesterAI";
	}
}
