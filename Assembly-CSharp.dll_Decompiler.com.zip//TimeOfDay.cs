using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using TMPro;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Rendering.HighDefinition;
using UnityEngine.UI;

public class TimeOfDay : NetworkBehaviour
{
	[Header("Time")]
	public SelectableLevel currentLevel;

	public float globalTimeSpeedMultiplier = 1f;

	public float currentDayTime;

	public int hour;

	private int previousHour;

	public float normalizedTimeOfDay;

	public bool timeHasStarted;

	[Space(5f)]
	public float globalTime;

	public float globalTimeAtEndOfDay;

	public bool movingGlobalTimeForward;

	[Space(10f)]
	private bool reachedQuota;

	public QuotaSettings quotaVariables;

	public int profitQuota;

	public int quotaFulfilled;

	public int timesFulfilledQuota;

	public float timeUntilDeadline;

	public int daysUntilDeadline;

	public int hoursUntilDeadline;

	[Space(5f)]
	public float lengthOfHours = 100f;

	public int numberOfHours = 7;

	public float totalTime;

	public const int startingGlobalTime = 100;

	[Space(3f)]
	public float shipLeaveAutomaticallyTime = 0.996f;

	[Space(5f)]
	public bool currentDayTimeStarted;

	private bool timeStartedThisFrame = true;

	public StartOfRound playersManager;

	public Animator sunAnimator;

	public Light sunIndirect;

	public Light sunDirect;

	public bool insideLighting = true;

	public DayMode dayMode;

	private DayMode dayModeLastTimePlayerWasOutside;

	public AudioClip[] timeOfDayCues;

	public AudioSource TimeOfDayMusic;

	private HDAdditionalLightData indirectLightData;

	[Header("Weather")]
	public WeatherEffect[] effects;

	public LevelWeatherType currentLevelWeather = LevelWeatherType.None;

	public float currentWeatherVariable;

	public float currentWeatherVariable2;

	[Space(2f)]
	public LocalVolumetricFog foggyWeather;

	[Space(4f)]
	public CompanyMood currentCompanyMood;

	public CompanyMood[] CommonCompanyMoods;

	[Space(4f)]
	private float changeHUDTimeInterval;

	private float nextTimeSync;

	public bool shipLeavingAlertCalled;

	public DialogueSegment[] shipLeavingSoonDialogue;

	public DialogueSegment[] shipLeavingEarlyDialogue;

	private bool shipLeavingOnMidnight;

	private bool shipFullCapacityAtMidnightMessage;

	private Coroutine playDelayedMusicCoroutine;

	public int votesForShipToLeaveEarly;

	public bool votedShipToLeaveEarlyThisRound;

	public UnityEvent onTimeSync = new UnityEvent();

	public UnityEvent onHourChanged = new UnityEvent();

	public float meteorShowerAtTime = -1f;

	public MeteorShowers MeteorWeather;

	public int overrideMeteorChance = -1;

	public List<int> furniturePlacedAtQuotaStart = new List<int>();

	public float luckValue;

	public bool hasShownAdThisQuota;

	public float normalizedTimeToShowAd = -1f;

	private float adWaitInterval = 10f;

	private int gotInfoFromClientsForAd;

	private bool checkingIfClientsAreReadyForAd;

	private bool doClientsMeetRequirementsForAd;

	private Coroutine adGetClientInfoCoroutine;

	private Collider[] playerColliders = (Collider[])(object)new Collider[4];

	public static TimeOfDay Instance { get; private set; }

	public void SetWeatherBasedOnVariables()
	{
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 101);
		if (currentLevelWeather == LevelWeatherType.Foggy)
		{
			foggyWeather.parameters.meanFreePath = random.Next((int)currentWeatherVariable, (int)currentWeatherVariable2);
		}
	}

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
			return;
		}
		Object.Destroy((Object)(object)((Component)Instance).gameObject);
		Instance = this;
	}

	private void Start()
	{
		playersManager = Object.FindObjectOfType<StartOfRound>();
		totalTime = lengthOfHours * (float)numberOfHours;
		SetCompanyMood();
		try
		{
			hasShownAdThisQuota = ES3.Load<bool>("ShownAdThisQuota", GameNetworkManager.Instance.currentSaveFileName, false);
		}
		catch (Exception ex)
		{
			Debug.LogException(ex);
		}
	}

	public void DecideRandomDayEvents()
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			Random random = new Random(StartOfRound.Instance.randomMapSeed + 28);
			int num = 7;
			if ((float)overrideMeteorChance != -1f)
			{
				num = overrideMeteorChance;
			}
			if (random.Next(0, 1000) < num)
			{
				meteorShowerAtTime = (float)random.Next(5, 80) / 100f;
			}
			else
			{
				meteorShowerAtTime = -1f;
			}
		}
	}

	private void Update()
	{
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		_ = movingGlobalTimeForward;
		if (currentDayTimeStarted)
		{
			if (timeStartedThisFrame)
			{
				timeStartedThisFrame = false;
				nextTimeSync = 0f;
				TimeOfDayMusic.volume = 0.7f;
				dayModeLastTimePlayerWasOutside = DayMode.None;
				shipLeavingOnMidnight = false;
				shipLeavingAlertCalled = false;
				votedShipToLeaveEarlyThisRound = false;
				shipLeaveAutomaticallyTime = 0.998f;
				votesForShipToLeaveEarly = 0;
				currentDayTime = CalculatePlanetTime(currentLevel);
				hour = (int)(currentDayTime / lengthOfHours);
				previousHour = hour;
				indirectLightData = null;
				globalTimeAtEndOfDay = globalTime + (totalTime - currentDayTime) / currentLevel.DaySpeedMultiplier;
				normalizedTimeOfDay = currentDayTime / totalTime;
				SetTimeForAdToPlay();
				RefreshClockUI();
				if (((NetworkBehaviour)this).IsServer)
				{
					DecideRandomDayEvents();
				}
				timeHasStarted = true;
			}
			else
			{
				MoveTimeOfDay();
				TimeOfDayEvents();
				SetWeatherEffects();
			}
		}
		else
		{
			timeStartedThisFrame = true;
			timeHasStarted = false;
			if (MeteorWeather.meteorsEnabled)
			{
				MeteorWeather.ResetMeteorWeather();
			}
		}
	}

	public void MoveGlobalTime()
	{
		float num = globalTime;
		globalTime = Mathf.Clamp(globalTime + Time.deltaTime * globalTimeSpeedMultiplier, 0f, globalTimeAtEndOfDay);
		num = globalTime - num;
		timeUntilDeadline -= num;
	}

	public float CalculatePlanetTime(SelectableLevel level)
	{
		return (globalTime + level.OffsetFromGlobalTime) * level.DaySpeedMultiplier % (totalTime + 1f);
	}

	public float CalculatePlanetTimeClampToEndOfDay(SelectableLevel level)
	{
		return (Mathf.Clamp(globalTime, 0f, globalTimeAtEndOfDay) + level.OffsetFromGlobalTime) * level.DaySpeedMultiplier % (totalTime + 1f);
	}

	private void MoveTimeOfDay()
	{
		try
		{
			MoveGlobalTime();
			SyncGlobalTimeOnNetwork();
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error updating time of day: {arg}");
		}
		currentDayTime = CalculatePlanetTime(currentLevel);
		hour = (int)(currentDayTime / lengthOfHours);
		if (hour != previousHour)
		{
			previousHour = hour;
			OnHourChanged();
			StartOfRound.Instance.SetDiscordStatusDetails();
		}
		if ((Object)(object)sunAnimator != (Object)null)
		{
			normalizedTimeOfDay = currentDayTime / totalTime;
			sunAnimator.SetFloat("timeOfDay", Mathf.Clamp(normalizedTimeOfDay, 0f, 0.99f));
			if (changeHUDTimeInterval > 3f)
			{
				changeHUDTimeInterval = 0f;
				HUDManager.Instance.SetClock(normalizedTimeOfDay, numberOfHours);
			}
			else
			{
				changeHUDTimeInterval += Time.deltaTime;
			}
			SetInsideLightingDimness();
		}
		if (((NetworkBehaviour)this).IsServer && meteorShowerAtTime > 0f && normalizedTimeOfDay >= meteorShowerAtTime)
		{
			meteorShowerAtTime = -1f;
			MeteorWeather.SetStartMeteorShower();
		}
	}

	public void SetInsideLightingDimness(bool doNotLerp = false, bool setValueTo = false)
	{
		if ((Object)(object)sunDirect == (Object)null || (Object)(object)sunIndirect == (Object)null)
		{
			return;
		}
		if ((Object)(object)indirectLightData == (Object)null)
		{
			indirectLightData = ((Component)sunIndirect).GetComponent<HDAdditionalLightData>();
		}
		HUDManager.Instance.SetClockVisible(!insideLighting);
		if ((Object)(object)GameNetworkManager.Instance != (Object)null)
		{
			if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
			{
				if ((Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript != (Object)null)
				{
					((Behaviour)sunDirect).enabled = !GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript.isInsideFactory;
				}
			}
			else
			{
				((Behaviour)sunDirect).enabled = !GameNetworkManager.Instance.localPlayerController.isInsideFactory;
			}
		}
		PlayerControllerB playerControllerB = GameNetworkManager.Instance.localPlayerController;
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead && (Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript != (Object)null)
		{
			playerControllerB = GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript;
		}
		if (playerControllerB.isInsideFactory)
		{
			((Behaviour)sunIndirect).enabled = false;
		}
		if (insideLighting)
		{
			indirectLightData.lightDimmer = Mathf.Lerp(indirectLightData.lightDimmer, 0f, 5f * Time.deltaTime);
			return;
		}
		((Behaviour)sunIndirect).enabled = true;
		indirectLightData.lightDimmer = Mathf.Lerp(indirectLightData.lightDimmer, 1f, 5f * Time.deltaTime);
	}

	private int RoundUpToNearestTen(float x)
	{
		return (int)(x / 10f) * 10;
	}

	private void SyncGlobalTimeOnNetwork()
	{
		if (((NetworkBehaviour)this).IsServer && (float)RoundUpToNearestTen(globalTime) >= nextTimeSync)
		{
			nextTimeSync = RoundUpToNearestTen(globalTime + 10f);
			SyncTimeClientRpc(globalTime, (int)timeUntilDeadline);
		}
	}

	[ClientRpc]
	public void SyncTimeClientRpc(float time, int deadline)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3168707752u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref time, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, deadline);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3168707752u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				globalTime = time;
				timeUntilDeadline = deadline;
				onTimeSync.Invoke();
			}
		}
	}

	public void SetTimeForAdToPlay()
	{
		if (((NetworkBehaviour)this).IsServer && !hasShownAdThisQuota && timesFulfilledQuota != 0)
		{
			float num = 33f;
			if (daysUntilDeadline <= 1)
			{
				num = 60f;
			}
			if ((float)Random.Range(0, 100) < num)
			{
				normalizedTimeToShowAd = Random.Range(0.04f, 0.7f);
			}
		}
	}

	private bool MeetsRequirementsToShowAd()
	{
		if (StartOfRound.Instance.timeSinceRoundStarted <= 15f)
		{
			return false;
		}
		if (timesFulfilledQuota == 0)
		{
			return false;
		}
		if (StartOfRound.Instance.livingPlayers <= 1)
		{
			return false;
		}
		return true;
	}

	private IEnumerator GetClientInfo()
	{
		float timeAtChecking = Time.realtimeSinceStartup;
		checkingIfClientsAreReadyForAd = true;
		doClientsMeetRequirementsForAd = true;
		Debug.Log((object)"Ad system: Setting gotinfo to 0");
		gotInfoFromClientsForAd = 0;
		SendHostInfoForShowingAdClientRpc();
		yield return (object)new WaitUntil((Func<bool>)(() => gotInfoFromClientsForAd >= StartOfRound.Instance.livingPlayers || Time.realtimeSinceStartup - timeAtChecking > 5f));
		if (doClientsMeetRequirementsForAd)
		{
			hasShownAdThisQuota = true;
			HUDManager.Instance.ChooseAdItem();
			normalizedTimeToShowAd = -1f;
		}
		else
		{
			checkingIfClientsAreReadyForAd = false;
			adWaitInterval = 15f;
		}
		adGetClientInfoCoroutine = null;
	}

	[ClientRpc]
	public void SendHostInfoForShowingAdClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(990741385u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 990741385u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		Debug.Log((object)"Received client rpc Ad");
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			return;
		}
		bool doesntMeetRequirements = false;
		float num = Mathf.Max(GameNetworkManager.Instance.localPlayerController.timeSinceTakingDamage, GameNetworkManager.Instance.localPlayerController.timeSinceFearLevelUp);
		if (num > 12f)
		{
			if (GameNetworkManager.Instance.localPlayerController.isInsideFactory && Physics.CheckSphere(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, 20f, 524288, (QueryTriggerInteraction)2))
			{
				doesntMeetRequirements = true;
				Debug.Log((object)"Can't show ad client; 1");
			}
		}
		else if (num < 1.7f && GameNetworkManager.Instance.localPlayerController.isInsideFactory && Physics.CheckSphere(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, 12f, 524288, (QueryTriggerInteraction)2))
		{
			doesntMeetRequirements = true;
			Debug.Log((object)"Can't show ad client; 2");
		}
		ReceiveInfoFromClientForShowingAdServerRpc(doesntMeetRequirements);
	}

	[ServerRpc(RequireOwnership = false)]
	public void ReceiveInfoFromClientForShowingAdServerRpc(bool doesntMeetRequirements)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3562921089u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref doesntMeetRequirements, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3562921089u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && checkingIfClientsAreReadyForAd)
		{
			Debug.Log((object)"Adding 1 to gotInfoFromClients");
			gotInfoFromClientsForAd++;
			if (doesntMeetRequirements)
			{
				doClientsMeetRequirementsForAd = false;
			}
		}
	}

	private void DisplayAdAtScheduledTime()
	{
		if (!((NetworkBehaviour)this).IsServer || hasShownAdThisQuota || normalizedTimeToShowAd == -1f || normalizedTimeOfDay >= 0.9f || checkingIfClientsAreReadyForAd || StartOfRound.Instance.livingPlayers <= 1)
		{
			return;
		}
		if (adWaitInterval <= 0f)
		{
			if (!(normalizedTimeOfDay > normalizedTimeToShowAd))
			{
				return;
			}
			if (MeetsRequirementsToShowAd())
			{
				if (!checkingIfClientsAreReadyForAd && adGetClientInfoCoroutine == null)
				{
					adGetClientInfoCoroutine = ((MonoBehaviour)this).StartCoroutine(GetClientInfo());
				}
			}
			else
			{
				adWaitInterval = 15f;
			}
		}
		else
		{
			adWaitInterval -= Time.deltaTime;
		}
	}

	public void TimeOfDayEvents()
	{
		dayMode = GetDayPhase(currentDayTime / totalTime);
		if (currentLevel.planetHasTime && !StartOfRound.Instance.shipIsLeaving)
		{
			if (!shipLeavingAlertCalled && currentDayTime / totalTime > 0.9f)
			{
				shipLeavingAlertCalled = true;
				HUDManager.Instance.ReadDialogue(shipLeavingSoonDialogue);
				((Behaviour)HUDManager.Instance.shipLeavingEarlyIcon).enabled = true;
			}
			DisplayAdAtScheduledTime();
			if (((NetworkBehaviour)this).IsServer && !shipLeavingOnMidnight && currentDayTime / totalTime >= shipLeaveAutomaticallyTime)
			{
				shipLeavingOnMidnight = true;
				SetShipToLeaveOnMidnightClientRpc();
			}
		}
		if (dayMode > dayModeLastTimePlayerWasOutside)
		{
			PlayerSeesNewTimeOfDay();
		}
	}

	public void CalculateLuckValue()
	{
		if (timesFulfilledQuota == 0)
		{
			AutoParentToShip[] array = Object.FindObjectsByType<AutoParentToShip>((FindObjectsSortMode)0);
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i].unlockableID != -1 && StartOfRound.Instance.unlockablesList.unlockables[array[i].unlockableID].spawnPrefab)
				{
					furniturePlacedAtQuotaStart.Add(array[i].unlockableID);
				}
			}
		}
		luckValue = 0f;
		for (int j = 0; j < furniturePlacedAtQuotaStart.Count; j++)
		{
			if (furniturePlacedAtQuotaStart[j] > StartOfRound.Instance.unlockablesList.unlockables.Count)
			{
				Debug.LogError((object)$"'Lucky' furniture with id {furniturePlacedAtQuotaStart[j]} exceeded the unlockables list size; skipping");
			}
			luckValue = Mathf.Clamp(luckValue + StartOfRound.Instance.unlockablesList.unlockables[furniturePlacedAtQuotaStart[j]].luckValue, -0.5f, 1f);
		}
		Debug.Log((object)$"Luck calculated: {luckValue}");
	}

	public void SetNewProfitQuota()
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		timesFulfilledQuota++;
		int num = quotaFulfilled - profitQuota;
		float num2 = Mathf.Clamp(1f + (float)timesFulfilledQuota * ((float)timesFulfilledQuota / quotaVariables.increaseSteepness), 0f, 10000f);
		CalculateLuckValue();
		float num3 = Random.Range(0f, 1f);
		Debug.Log((object)$"Randomizer amount before: {num3}");
		num3 *= Mathf.Abs(luckValue - 1f);
		Debug.Log((object)$"Randomizer amount after: {num3}");
		num2 = quotaVariables.baseIncrease * num2 * (quotaVariables.randomizerCurve.Evaluate(num3) * quotaVariables.randomizerMultiplier + 1f);
		Debug.Log((object)$"Amount to increase quota:{num2}");
		profitQuota = (int)Mathf.Clamp((float)profitQuota + num2, 0f, 1E+09f);
		quotaFulfilled = 0;
		timeUntilDeadline = totalTime * 4f;
		int overtimeBonus = num / 5 + 15 * daysUntilDeadline;
		furniturePlacedAtQuotaStart.Clear();
		AutoParentToShip[] array = Object.FindObjectsByType<AutoParentToShip>((FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].unlockableID != -1 && StartOfRound.Instance.unlockablesList.unlockables[array[i].unlockableID].spawnPrefab)
			{
				furniturePlacedAtQuotaStart.Add(array[i].unlockableID);
			}
		}
		hasShownAdThisQuota = false;
		SyncNewProfitQuotaClientRpc(profitQuota, overtimeBonus, timesFulfilledQuota);
	}

	[ClientRpc]
	public void SyncNewProfitQuotaClientRpc(int newProfitQuota, int overtimeBonus, int fulfilledQuota)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1041683203u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, newProfitQuota);
				BytePacker.WriteValueBitPacked(val2, overtimeBonus);
				BytePacker.WriteValueBitPacked(val2, fulfilledQuota);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1041683203u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				quotaFulfilled = 0;
				profitQuota = newProfitQuota;
				timeUntilDeadline = totalTime * (float)quotaVariables.deadlineDaysAmount;
				timesFulfilledQuota = fulfilledQuota;
				StartOfRound.Instance.companyBuyingRate = 0.3f;
				Terminal terminal = Object.FindObjectOfType<Terminal>();
				terminal.groupCredits = Mathf.Clamp(terminal.groupCredits + overtimeBonus, terminal.groupCredits, 100000000);
				terminal.RotateShipDecorSelection();
				HUDManager.Instance.DisplayNewDeadline(overtimeBonus);
			}
		}
	}

	public void UpdateProfitQuotaCurrentTime()
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		daysUntilDeadline = (int)Mathf.Floor(timeUntilDeadline / totalTime);
		hoursUntilDeadline = (int)(timeUntilDeadline / lengthOfHours) - daysUntilDeadline * numberOfHours;
		if (StartOfRound.Instance.isChallengeFile)
		{
			((Graphic)StartOfRound.Instance.deadlineMonitorBGImage).color = new Color(0.5294118f, 1f / 51f, 0.8f, 1f);
			((Graphic)StartOfRound.Instance.profitQuotaMonitorBGImage).color = new Color(0.5294118f, 1f / 51f, 0.8f, 1f);
			((TMP_Text)StartOfRound.Instance.deadlineMonitorText).text = "AS MUCH PROFIT AS POSSIBLE";
			((TMP_Text)StartOfRound.Instance.profitQuotaMonitorText).text = "Welcome to\n" + GameNetworkManager.Instance.GetNameForWeekNumber();
			((TMP_Text)StartOfRound.Instance.profitQuotaMonitorText).fontSize = 62f;
		}
		else
		{
			if (timeUntilDeadline <= 0f)
			{
				((TMP_Text)StartOfRound.Instance.deadlineMonitorText).text = "DEADLINE:\n NOW";
			}
			else
			{
				((TMP_Text)StartOfRound.Instance.deadlineMonitorText).text = $"DEADLINE:\n{daysUntilDeadline} Days";
			}
			((TMP_Text)StartOfRound.Instance.profitQuotaMonitorText).text = $"PROFIT QUOTA:\n${quotaFulfilled} / ${profitQuota}";
		}
	}

	[ClientRpc]
	public void SetShipToLeaveOnMidnightClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(749416460u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 749416460u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				StartOfRound.Instance.ShipLeaveAutomatically(leavingOnMidnight: true);
			}
		}
	}

	public void VoteShipToLeaveEarly()
	{
		if (!votedShipToLeaveEarlyThisRound)
		{
			votedShipToLeaveEarlyThisRound = true;
			SetShipLeaveEarlyServerRpc();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetShipLeaveEarlyServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(543987598u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 543987598u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			votesForShipToLeaveEarly++;
			int num = StartOfRound.Instance.connectedPlayersAmount + 1 - StartOfRound.Instance.livingPlayers;
			if (votesForShipToLeaveEarly >= num)
			{
				SetShipLeaveEarlyClientRpc(normalizedTimeOfDay + 0.1f, votesForShipToLeaveEarly);
			}
			else
			{
				AddVoteForShipToLeaveEarlyClientRpc();
			}
		}
	}

	[ClientRpc]
	public void AddVoteForShipToLeaveEarlyClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1359513530u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1359513530u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				votesForShipToLeaveEarly++;
				HUDManager.Instance.SetShipLeaveEarlyVotesText(votesForShipToLeaveEarly);
			}
		}
	}

	[ClientRpc]
	public void SetShipLeaveEarlyClientRpc(float timeToLeaveEarly, int votes)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3001101610u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToLeaveEarly, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, votes);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3001101610u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				votesForShipToLeaveEarly = votes;
				HUDManager.Instance.SetShipLeaveEarlyVotesText(votes);
				shipLeaveAutomaticallyTime = timeToLeaveEarly;
				shipLeavingAlertCalled = true;
				shipLeavingEarlyDialogue[0].bodyText = "WARNING! Please return by " + HUDManager.Instance.SetClock(timeToLeaveEarly, numberOfHours, createNewLine: false) + ". A vote has been cast, and the autopilot ship will leave early.";
				HUDManager.Instance.ReadDialogue(shipLeavingEarlyDialogue);
				((Behaviour)HUDManager.Instance.shipLeavingEarlyIcon).enabled = true;
			}
		}
	}

	[ClientRpc]
	public void ShipFullCapacityMidnightClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(711575688u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 711575688u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				shipLeavingEarlyDialogue[0].bodyText = "ALERT! The ship has reached full carrying capacity and cannot leave until items are removed!";
				HUDManager.Instance.ReadDialogue(shipLeavingEarlyDialogue);
			}
		}
	}

	public DayMode GetDayPhase(float time)
	{
		if (time >= 0.9f)
		{
			return DayMode.Midnight;
		}
		if (time >= 0.63f)
		{
			return DayMode.Sundown;
		}
		if (time >= 0.33f)
		{
			return DayMode.Noon;
		}
		return DayMode.Dawn;
	}

	private void PlayerSeesNewTimeOfDay()
	{
		if (!GameNetworkManager.Instance.localPlayerController.isInsideFactory && !GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom && playersManager.shipHasLanded)
		{
			dayModeLastTimePlayerWasOutside = dayMode;
			HUDManager.Instance.SetClockIcon(dayMode);
			if (currentLevel.planetHasTime)
			{
				PlayTimeMusicDelayed(timeOfDayCues[(int)dayMode], 0.5f, playRandomDaytimeMusic: true);
			}
		}
	}

	public void PlayTimeMusicDelayed(AudioClip clip, float delay, bool playRandomDaytimeMusic = false)
	{
		if (playDelayedMusicCoroutine != null)
		{
			Debug.Log((object)"Already playing music; cancelled starting new music");
		}
		else
		{
			playDelayedMusicCoroutine = ((MonoBehaviour)this).StartCoroutine(playSoundDelayed(clip, delay, playRandomDaytimeMusic));
		}
	}

	private IEnumerator playSoundDelayed(AudioClip clip, float delay, bool playRandomDaytimeMusic)
	{
		Debug.Log((object)"Play time of day sfx");
		yield return (object)new WaitForSeconds(delay);
		TimeOfDayMusic.PlayOneShot(clip, 1f);
		Debug.Log((object)$"Play music!; {TimeOfDayMusic.clip}; {TimeOfDayMusic.volume}");
		if (!playRandomDaytimeMusic || !currentLevel.planetHasTime)
		{
			yield break;
		}
		yield return (object)new WaitForSeconds(3f);
		yield return (object)new WaitForSeconds(Random.Range(2f, 8f));
		if (insideLighting || GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom || StartOfRound.Instance.fearLevel > 0.03f)
		{
			yield break;
		}
		if (Random.Range(0, 100) < 20 || ES3.Load<int>("TimesLanded", "LCGeneralSaveData", 0) <= 1)
		{
			if (ES3.Load<int>("TimesLanded", "LCGeneralSaveData", 0) <= 1)
			{
				ES3.Save<int>("TimesLanded", 2, "LCGeneralSaveData");
			}
			SoundManager.Instance.PlayRandomOutsideMusic(dayMode >= DayMode.Sundown);
		}
		playDelayedMusicCoroutine = null;
	}

	private IEnumerator fadeOutEffect(WeatherEffect effect, Vector3 moveFromPosition)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)effect.effectObject != (Object)null)
		{
			for (int i = 0; i < 270; i++)
			{
				effect.effectObject.transform.position = Vector3.Lerp(effect.effectObject.transform.position, moveFromPosition - Vector3.up * 50f, (float)i / 270f);
				yield return null;
				if ((Object)(object)effect.effectObject == (Object)null || !effect.transitioning)
				{
					yield break;
				}
			}
		}
		DisableWeatherEffect(effect);
	}

	private void SetWeatherEffects()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((!GameNetworkManager.Instance.localPlayerController.isPlayerDead) ? ((Component)StartOfRound.Instance.localPlayerController).transform.position : ((Component)StartOfRound.Instance.spectateCamera).transform.position);
		for (int i = 0; i < effects.Length; i++)
		{
			if (effects[i].effectEnabled)
			{
				if (!string.IsNullOrEmpty(effects[i].sunAnimatorBool) && (Object)(object)sunAnimator != (Object)null)
				{
					sunAnimator.SetBool(effects[i].sunAnimatorBool, true);
				}
				effects[i].transitioning = false;
				if ((Object)(object)effects[i].effectObject != (Object)null)
				{
					effects[i].effectObject.SetActive(true);
					if (effects[i].lerpPosition)
					{
						effects[i].effectObject.transform.position = Vector3.Lerp(effects[i].effectObject.transform.position, val, Time.deltaTime);
					}
					else
					{
						effects[i].effectObject.transform.position = val;
					}
				}
			}
			else if (!effects[i].transitioning)
			{
				effects[i].transitioning = true;
				if (effects[i].lerpPosition)
				{
					((MonoBehaviour)this).StartCoroutine(fadeOutEffect(effects[i], val));
				}
				else
				{
					DisableWeatherEffect(effects[i]);
				}
			}
		}
	}

	private void DisableWeatherEffect(WeatherEffect effect)
	{
		if (!((Object)(object)effect.effectObject == (Object)null))
		{
			effect.effectObject.SetActive(false);
		}
	}

	public void DisableAllWeather(bool deactivateObjects = false)
	{
		for (int i = 0; i < effects.Length; i++)
		{
			effects[i].effectEnabled = false;
		}
		if (!deactivateObjects)
		{
			return;
		}
		for (int j = 0; j < effects.Length; j++)
		{
			if ((Object)(object)effects[j].effectObject != (Object)null)
			{
				effects[j].effectObject.SetActive(false);
			}
		}
	}

	public void RefreshClockUI()
	{
		HUDManager.Instance.SetClockIcon(dayMode);
		HUDManager.Instance.SetClock(normalizedTimeOfDay, numberOfHours);
	}

	public void OnHourChanged(int amount = 1)
	{
		onHourChanged.Invoke();
	}

	public void OnDayChanged()
	{
		if (!StartOfRound.Instance.isChallengeFile)
		{
			StartOfRound.Instance.SetPlanetsWeather();
			SetBuyingRateForDay();
			SetCompanyMood();
		}
	}

	public void SetCompanyMood()
	{
		if (timesFulfilledQuota <= 0)
		{
			currentCompanyMood = CommonCompanyMoods[0];
			return;
		}
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 164);
		currentCompanyMood = CommonCompanyMoods[random.Next(0, CommonCompanyMoods.Length)];
	}

	public void SetBuyingRateForDay()
	{
		daysUntilDeadline = (int)Mathf.Floor(timeUntilDeadline / totalTime);
		if (daysUntilDeadline == 0)
		{
			StartOfRound.Instance.companyBuyingRate = 1f;
			return;
		}
		float num = 0.3f;
		float num2 = (1f - num) / (float)quotaVariables.deadlineDaysAmount;
		StartOfRound.Instance.companyBuyingRate = num2 * (float)(quotaVariables.deadlineDaysAmount - daysUntilDeadline) + num;
	}

	[ClientRpc]
	public void SetBeginMeteorShowerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1181254672u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1181254672u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				((Component)MeteorWeather).gameObject.SetActive(true);
				MeteorWeather.meteorsEnabled = true;
				HUDManager.Instance.MeteorShowerWarningHUD();
			}
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_TimeOfDay()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3168707752u, new RpcReceiveHandler(__rpc_handler_3168707752));
		NetworkManager.__rpc_func_table.Add(990741385u, new RpcReceiveHandler(__rpc_handler_990741385));
		NetworkManager.__rpc_func_table.Add(3562921089u, new RpcReceiveHandler(__rpc_handler_3562921089));
		NetworkManager.__rpc_func_table.Add(1041683203u, new RpcReceiveHandler(__rpc_handler_1041683203));
		NetworkManager.__rpc_func_table.Add(749416460u, new RpcReceiveHandler(__rpc_handler_749416460));
		NetworkManager.__rpc_func_table.Add(543987598u, new RpcReceiveHandler(__rpc_handler_543987598));
		NetworkManager.__rpc_func_table.Add(1359513530u, new RpcReceiveHandler(__rpc_handler_1359513530));
		NetworkManager.__rpc_func_table.Add(3001101610u, new RpcReceiveHandler(__rpc_handler_3001101610));
		NetworkManager.__rpc_func_table.Add(711575688u, new RpcReceiveHandler(__rpc_handler_711575688));
		NetworkManager.__rpc_func_table.Add(1181254672u, new RpcReceiveHandler(__rpc_handler_1181254672));
	}

	private static void __rpc_handler_3168707752(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float time = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref time, default(ForPrimitives));
			int deadline = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref deadline);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TimeOfDay)(object)target).SyncTimeClientRpc(time, deadline);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_990741385(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TimeOfDay)(object)target).SendHostInfoForShowingAdClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3562921089(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool doesntMeetRequirements = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref doesntMeetRequirements, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((TimeOfDay)(object)target).ReceiveInfoFromClientForShowingAdServerRpc(doesntMeetRequirements);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1041683203(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int newProfitQuota = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newProfitQuota);
			int overtimeBonus = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref overtimeBonus);
			int fulfilledQuota = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref fulfilledQuota);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TimeOfDay)(object)target).SyncNewProfitQuotaClientRpc(newProfitQuota, overtimeBonus, fulfilledQuota);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_749416460(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TimeOfDay)(object)target).SetShipToLeaveOnMidnightClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_543987598(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((TimeOfDay)(object)target).SetShipLeaveEarlyServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1359513530(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TimeOfDay)(object)target).AddVoteForShipToLeaveEarlyClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3001101610(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timeToLeaveEarly = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToLeaveEarly, default(ForPrimitives));
			int votes = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref votes);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TimeOfDay)(object)target).SetShipLeaveEarlyClientRpc(timeToLeaveEarly, votes);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_711575688(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TimeOfDay)(object)target).ShipFullCapacityMidnightClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1181254672(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TimeOfDay)(object)target).SetBeginMeteorShowerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "TimeOfDay";
	}
}
