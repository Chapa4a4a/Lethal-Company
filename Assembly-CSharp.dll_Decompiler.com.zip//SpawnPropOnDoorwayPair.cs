using DunGen;
using DunGen.Tags;
using UnityEngine;

public class SpawnPropOnDoorwayPair : MonoBehaviour
{
	public Tag CaveTag;

	private TileConnectionRule rule;

	public GameObject caveEntranceProp;

	private void OnEnable()
	{
		rule = new TileConnectionRule(CanTilesConnect);
		DoorwayPairFinder.CustomConnectionRules.Add(rule);
	}

	private void OnDisable()
	{
		DoorwayPairFinder.CustomConnectionRules.Remove(rule);
		rule = null;
	}

	private TileConnectionRule.ConnectionResult CanTilesConnect(Tile tileA, Tile tileB, Doorway doorwayA, Doorway doorwayB)
	{
		bool flag = tileA.Tags.HasTag(CaveTag);
		bool flag2 = tileB.Tags.HasTag(CaveTag);
		if (flag != flag2)
		{
			Doorway doorway = ((!flag) ? doorwayB : doorwayA);
			Object.Instantiate<GameObject>(caveEntranceProp, ((Component)doorway).transform, false);
			Debug.Log((object)$"got tile: {((Component)tileA).gameObject}", (Object)(object)((Component)tileA).gameObject);
			Debug.Log((object)$"got doorway! {doorwayA}; {((Object)doorwayA).name}; {((Component)doorwayA).gameObject}", (Object)(object)((Component)doorwayA).gameObject);
			Debug.Log((object)$"got doorway B! {doorwayB}; {((Object)doorwayB).name}; {((Component)doorwayB).gameObject}");
		}
		return TileConnectionRule.ConnectionResult.Passthrough;
	}
}
