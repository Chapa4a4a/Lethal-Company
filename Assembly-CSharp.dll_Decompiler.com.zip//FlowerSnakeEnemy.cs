using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;

public class FlowerSnakeEnemy : EnemyAI
{
	public AISearchRoutine snakeRoam;

	private float timeSinceSeeingTarget;

	private bool leaping;

	private Vector3 leapDirection;

	public AnimationCurve leapVerticalCurve;

	public Transform meshContainer;

	private Vector3 startLeapPosition;

	private float leapTime;

	public float leapTimeMultiplier = 5f;

	public float leapSpeedMultiplier = 1f;

	public float leapVerticalMultiplier = 4f;

	public PlayerControllerB clingingToPlayer;

	private bool waitingForHitPlayerRPC;

	public int clingPosition;

	private float collideWithPlayerInterval;

	private Vector3 previousPosition;

	public float spinePositionUpOffset;

	public float spinePositionRightOffset;

	private float timeOfLastCling;

	private bool choseFarawayNode;

	private float clingingPlayerFlapInterval;

	public static FlowerSnakeEnemy[] mainSnakes;

	private bool flapping;

	private float flapIntervalTimeOffset = 4f;

	private RaycastHit hit;

	private float leapVerticalPosition;

	private bool hitWallInLeap;

	private float fallFromLeapTimer = 1f;

	private bool fallingFromLeap;

	public Vector3 landingPoint;

	private Vector3 vel;

	public Material[] randomSkinColor;

	public int snakesOnPlayer;

	public bool activatedFlight;

	public float flightPower;

	private Vector3 forces;

	public float chuckleInterval;

	public AudioSource flappingAudio;

	public float clingToPlayerTimer;

	public float timeOfLastLeap;

	public override void Start()
	{
		base.Start();
		if (mainSnakes == null)
		{
			mainSnakes = new FlowerSnakeEnemy[StartOfRound.Instance.allPlayerScripts.Length];
		}
		Material val = null;
		int num = new Random(StartOfRound.Instance.randomMapSeed + (int)((NetworkBehaviour)this).NetworkObjectId).Next(0, 100);
		val = ((num < 33) ? randomSkinColor[0] : ((num <= 66) ? randomSkinColor[2] : randomSkinColor[1]));
		for (int i = 0; i < skinnedMeshRenderers.Length; i++)
		{
			((Renderer)skinnedMeshRenderers[i]).sharedMaterial = val;
		}
		flappingAudio.pitch = Random.Range(0.8f, 1.2f);
		flappingAudio.clip = enemyType.audioClips[9];
		flappingAudio.Play();
	}

	[ClientRpc]
	public void StartLeapClientRpc(Vector3 setLeapDir)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2859615571u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref setLeapDir);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2859615571u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				StartLeapOnLocalClient(setLeapDir);
			}
		}
	}

	public void StartLeapOnLocalClient(Vector3 leapDir)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		leaping = true;
		leapTime = 0f;
		hitWallInLeap = false;
		inSpecialAnimation = true;
		((Behaviour)agent).enabled = false;
		leapVerticalPosition = ((Component)this).transform.position.y;
		creatureAnimator.SetBool("Leaping", true);
		flappingAudio.Stop();
		leapDirection = leapDir;
		startLeapPosition = ((Component)this).transform.position;
		creatureVoice.Stop();
		int num = Random.Range(0, 100);
		if (num < 33)
		{
			creatureVoice.PlayOneShot(enemyType.audioClips[6]);
		}
		else if (num < 66)
		{
			creatureVoice.PlayOneShot(enemyType.audioClips[10]);
		}
		else
		{
			creatureVoice.PlayOneShot(enemyType.audioClips[7]);
		}
	}

	public void StopLeapOnLocalClient(bool landOnGround = false, Vector3 overrideLandingPosition = default(Vector3))
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		leaping = false;
		leapTime = 0f;
		creatureAnimator.SetBool("Leaping", false);
		if (!landOnGround)
		{
			return;
		}
		if (!isEnemyDead)
		{
			flappingAudio.clip = enemyType.audioClips[9];
			flappingAudio.Play();
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			landingPoint = overrideLandingPosition;
		}
		else
		{
			Vector3 val = RoundManager.Instance.GetNavMeshPosition(((Component)this).transform.position, default(NavMeshHit), 15f);
			if (!RoundManager.Instance.GotNavMeshPositionResult)
			{
				val = ((Component)ChooseClosestNodeToPosition(((Component)this).transform.position)).transform.position;
			}
			landingPoint = val;
		}
		SetEnemyOutside(landingPoint.y > -100f);
		serverPosition = landingPoint;
		fallingFromLeap = true;
		fallFromLeapTimer = 1f;
		timeOfLastLeap = Time.realtimeSinceStartup;
		if (((NetworkBehaviour)this).IsOwner && ((NetworkBehaviour)this).IsServer)
		{
			StopLeapClientRpc(landingPoint);
		}
	}

	public void StopClingingOnLocalClient(bool isMainSnake = false)
	{
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		inSpecialAnimation = false;
		clingPosition = 0;
		creatureAnimator.SetInteger("clingType", 0);
		SetFlappingLocalClient(setFlapping: false, isMainSnake);
		if (!isEnemyDead)
		{
			flappingAudio.clip = enemyType.audioClips[9];
			flappingAudio.Play();
		}
		flightPower = 0f;
		timeOfLastCling = Time.realtimeSinceStartup;
		Vector3 val = RoundManager.Instance.GetNavMeshPosition(((Component)this).transform.position, default(NavMeshHit), 15f);
		if (!RoundManager.Instance.GotNavMeshPositionResult)
		{
			val = ((Component)ChooseClosestNodeToPosition(((Component)this).transform.position)).transform.position;
		}
		SetEnemyOutside(landingPoint.y > -100f);
		((Component)this).transform.position = val;
		if (isMainSnake)
		{
			FlowerSnakeEnemy[] array = Object.FindObjectsByType<FlowerSnakeEnemy>((FindObjectsSortMode)0);
			for (int i = 0; i < array.Length; i++)
			{
				if (!((Object)(object)array[i] == (Object)(object)this) && (Object)(object)array[i].clingingToPlayer == (Object)(object)clingingToPlayer)
				{
					array[i].StopClingingOnLocalClient();
				}
			}
		}
		if ((Object)(object)clingingToPlayer != (Object)null)
		{
			Bounds bounds = StartOfRound.Instance.shipInnerRoomBounds.bounds;
			isInsidePlayerShip = ((Bounds)(ref bounds)).Contains(val);
			clingingToPlayer.carryWeight = Mathf.Max(clingingToPlayer.carryWeight - 0.03f, 1f);
			clingingToPlayer.enemiesOnPerson = Mathf.Max(clingingToPlayer.enemiesOnPerson - 1, 0);
			clingingToPlayer = null;
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			((Behaviour)agent).enabled = true;
			SwitchToBehaviourState(0);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StopClingingServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3381700831u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3381700831u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StopClingingOnLocalClient(isMainSnake: true);
				StopClingingClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void StopClingingClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3098650349u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3098650349u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer && playerId != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				StopClingingOnLocalClient(isMainSnake: true);
			}
		}
	}

	[ClientRpc]
	public void StopLeapClientRpc(Vector3 landingPoint)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2302911734u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref landingPoint);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2302911734u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer && leaping)
			{
				StopLeapOnLocalClient(landOnGround: true, landingPoint);
			}
		}
	}

	[ClientRpc]
	public void SetFlappingClientRpc(bool setFlapping)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1135936035u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setFlapping, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1135936035u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SetFlappingLocalClient(setFlapping, isMainSnake: true);
			}
		}
	}

	private void SetFlappingLocalClient(bool setFlapping, bool isMainSnake = false)
	{
		if (flapping != setFlapping)
		{
			flapping = setFlapping;
			creatureAnimator.SetBool("Flapping", setFlapping);
		}
		if (flapping)
		{
			if (Random.Range(0, 100) < 50)
			{
				flappingAudio.clip = enemyType.audioClips[5];
			}
			else
			{
				flappingAudio.clip = enemyType.audioClips[4];
			}
			flappingAudio.volume = 0.85f;
			flappingAudio.pitch = Random.Range(0.85f, 1.1f);
			flappingAudio.Play();
		}
		else
		{
			flappingAudio.Stop();
		}
		if (!isMainSnake)
		{
			return;
		}
		if (setFlapping && (Object)(object)clingingToPlayer != (Object)null && clingingToPlayer.enemiesOnPerson >= 2)
		{
			StartLiftingClungPlayer();
		}
		else
		{
			if ((Object)(object)clingingToPlayer != (Object)null && clingingToPlayer.jetpackControls)
			{
				clingingToPlayer.disablingJetpackControls = true;
			}
			activatedFlight = false;
		}
		FlowerSnakeEnemy[] array = Object.FindObjectsByType<FlowerSnakeEnemy>((FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if ((Object)(object)array[i].clingingToPlayer == (Object)(object)clingingToPlayer)
			{
				array[i].SetFlappingLocalClient(setFlapping);
			}
		}
	}

	public override void DoAIInterval()
	{
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_0388: Unknown result type (might be due to invalid IL or missing references)
		//IL_038d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0392: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (isEnemyDead)
		{
			return;
		}
		if (daytimeEnemyLeaving)
		{
			agent.speed = 0f;
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			movingTowardsTargetPlayer = false;
			if (Time.realtimeSinceStartup - timeOfLastCling < 10f)
			{
				if (snakeRoam.inProgress)
				{
					StopSearch(snakeRoam);
				}
				if (!choseFarawayNode)
				{
					if (SetDestinationToPosition(((Component)ChooseFarthestNodeFromPosition(((Component)this).transform.position)).transform.position, checkForPath: true))
					{
						choseFarawayNode = true;
					}
					else
					{
						((Component)this).transform.position = ChooseClosestNodeToPosition(((Component)this).transform.position).position;
					}
				}
				agent.speed = 7f;
				break;
			}
			if (!snakeRoam.inProgress)
			{
				StartSearch(((Component)this).transform.position, snakeRoam);
			}
			agent.speed = 4.5f;
			PlayerControllerB playerControllerB = null;
			PlayerControllerB[] allPlayersInLineOfSight = GetAllPlayersInLineOfSight(110f, 25, eye, 3f);
			if (allPlayersInLineOfSight == null)
			{
				break;
			}
			for (int j = 0; j < allPlayersInLineOfSight.Length; j++)
			{
				if (allPlayersInLineOfSight[j].enemiesOnPerson > 0)
				{
					playerControllerB = allPlayersInLineOfSight[j];
					break;
				}
				if (!Object.op_Implicit((Object)(object)allPlayersInLineOfSight[j].inAnimationWithEnemy))
				{
					playerControllerB = allPlayersInLineOfSight[j];
				}
			}
			if ((Object)(object)playerControllerB != (Object)null)
			{
				SetMovingTowardsTargetPlayer(playerControllerB);
				timeSinceSeeingTarget = 0f;
				SwitchToBehaviourState(1);
			}
			break;
		}
		case 1:
		{
			if ((Object)(object)targetPlayer == (Object)null)
			{
				SwitchToBehaviourState(0);
			}
			choseFarawayNode = false;
			if (snakeRoam.inProgress)
			{
				StopSearch(snakeRoam);
			}
			if (leaping || fallingFromLeap)
			{
				break;
			}
			if (targetPlayer.enemiesOnPerson == 0)
			{
				PlayerControllerB playerControllerB = null;
				PlayerControllerB[] allPlayersInLineOfSight = GetAllPlayersInLineOfSight(110f, 25, eye, 3f);
				if (allPlayersInLineOfSight != null)
				{
					for (int i = 0; i < allPlayersInLineOfSight.Length; i++)
					{
						if (allPlayersInLineOfSight[i].enemiesOnPerson > 0)
						{
							playerControllerB = allPlayersInLineOfSight[i];
							break;
						}
					}
					if ((Object)(object)playerControllerB != (Object)null)
					{
						SetMovingTowardsTargetPlayer(playerControllerB);
					}
				}
			}
			SetMovingTowardsTargetPlayer(targetPlayer);
			agent.speed = 6f;
			bool flag = CheckLineOfSightForPosition(((Component)targetPlayer.gameplayCamera).transform.position, 100f, 30, 5f);
			if (flag)
			{
				timeSinceSeeingTarget = 0f;
			}
			else
			{
				timeSinceSeeingTarget += AIIntervalTime;
			}
			float num = Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position);
			if (num > 35f || timeSinceSeeingTarget > 3f)
			{
				SwitchToBehaviourState(0);
			}
			else if (num < Random.Range(12f, 22f) && flag && Time.realtimeSinceStartup - timeOfLastLeap > Random.Range(0.25f, 1.1f))
			{
				Vector3 val = ((Component)targetPlayer).transform.position - ((Component)this).transform.position;
				val += Random.insideUnitSphere * Random.Range(0.05f, 0.15f);
				val.y = Mathf.Clamp(val.y, -16f, 16f);
				val = Vector3.Normalize(val * 1000f);
				StartLeapOnLocalClient(val);
				StartLeapClientRpc(val);
			}
			break;
		}
		}
	}

	public void OnEnable()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		((UnityEvent)StartOfRound.Instance.LocalPlayerDamagedEvent).AddListener(new UnityAction(LocalPlayerDamaged));
	}

	public void OnDisable()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		((UnityEvent)StartOfRound.Instance.LocalPlayerDamagedEvent).RemoveListener(new UnityAction(LocalPlayerDamaged));
		if ((Object)(object)clingingToPlayer != (Object)null)
		{
			StopClingingOnLocalClient(clingPosition == 4);
		}
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (((NetworkBehaviour)this).IsOwner && !daytimeEnemyLeaving)
		{
			KillEnemyOnOwnerClient();
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		base.KillEnemy(destroy);
		creatureSFX.Stop();
		flappingAudio.Stop();
		creatureVoice.Stop();
		if ((Object)(object)clingingToPlayer != (Object)null)
		{
			StopClingingOnLocalClient(clingPosition == 4);
		}
		if (leaping && ((NetworkBehaviour)this).IsServer)
		{
			StopLeapOnLocalClient(landOnGround: true);
		}
	}

	public override void DaytimeEnemyLeave()
	{
		base.DaytimeEnemyLeave();
		if (((NetworkBehaviour)this).IsServer && stunNormalizedTimer <= 0f && !isEnemyDead)
		{
			SetEnemyLeavingClientRpc();
			((MonoBehaviour)this).StartCoroutine(flyAwayThenDespawn());
		}
	}

	private IEnumerator flyAwayThenDespawn()
	{
		yield return (object)new WaitForSeconds(4f);
		if (((NetworkBehaviour)this).IsOwner)
		{
			KillEnemyOnOwnerClient(overrideDestroy: true);
		}
	}

	[ClientRpc]
	public void SetEnemyLeavingClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4240465152u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4240465152u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				creatureAnimator.SetBool("leaving", true);
			}
		}
	}

	private void LocalPlayerDamaged()
	{
		if ((Object)(object)clingingToPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController && clingPosition == 4)
		{
			StopClingingOnLocalClient(isMainSnake: true);
			StopClingingServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	[ServerRpc]
	public void StartFlyingServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1804766282u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1804766282u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			StartFlyingClientRpc();
		}
	}

	[ClientRpc]
	public void StartFlyingClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2596148101u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2596148101u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)clingingToPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController) && !((Object)(object)clingingToPlayer == (Object)null))
			{
				StartLiftingClungPlayer();
			}
		}
	}

	private void StartLiftingClungPlayer()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)clingingToPlayer == (Object)null))
		{
			clingingToPlayer.jetpackTurnCompass.rotation = ((Component)clingingToPlayer).transform.rotation;
			clingingToPlayer.disablingJetpackControls = false;
			clingingToPlayer.jetpackControls = true;
			activatedFlight = true;
			clingingToPlayer.syncFullRotation = ((Component)clingingToPlayer).transform.eulerAngles;
			clingingToPlayer.maxJetpackAngle = 60f;
			clingingToPlayer.jetpackRandomIntensity = 120f;
		}
	}

	[ClientRpc]
	public void MakeChuckleClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1473701276u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1473701276u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if ((Object)(object)clingingToPlayer != (Object)null)
			{
				isInsidePlayerShip = clingingToPlayer.isInHangarShipRoom;
			}
			RoundManager.PlayRandomClip(creatureVoice, enemyType.audioClips, randomize: true, 1f, 0, 5);
			bool noiseIsInsideClosedShip = (isInsidePlayerShip || ((Object)(object)clingingToPlayer != (Object)null && clingingToPlayer.isInHangarShipRoom)) && StartOfRound.Instance.hangarDoorsClosed;
			RoundManager.Instance.PlayAudibleNoise(((Component)creatureVoice).transform.position, 10f, 0.7f, 0, noiseIsInsideClosedShip);
		}
	}

	private void MainSnakeActAsConductor()
	{
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		clingToPlayerTimer -= Time.deltaTime;
		if ((Object)(object)clingingToPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			if ((clingingToPlayer.isInElevator && StartOfRound.Instance.shipIsLeaving) || (Object)(object)clingingToPlayer.inAnimationWithEnemy != (Object)null || clingToPlayerTimer <= 0f || daytimeEnemyLeaving)
			{
				StopClingingOnLocalClient(isMainSnake: true);
				StopClingingServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
				return;
			}
			if (activatedFlight)
			{
				flightPower = Mathf.Clamp(flightPower + Time.deltaTime * 1.7f, 12f, (float)clingingToPlayer.enemiesOnPerson * 4f);
			}
			else
			{
				flightPower = Mathf.Clamp(flightPower - Time.deltaTime * 50f, 0f, 1000f);
				if (clingingToPlayer.thisController.isGrounded)
				{
					flightPower = 0f;
				}
			}
			forces = Vector3.Lerp(forces, Vector3.ClampMagnitude(((Component)clingingToPlayer).transform.up * flightPower, 400f), Time.deltaTime);
			if (!clingingToPlayer.jetpackControls)
			{
				forces = Vector3.zero;
			}
			PlayerControllerB playerControllerB = clingingToPlayer;
			playerControllerB.externalForces += forces;
		}
		else if (((NetworkBehaviour)this).IsServer && !clingingToPlayer.isPlayerControlled && !clingingToPlayer.isPlayerDead)
		{
			clingPosition = 0;
			StopClingingServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (!flapping)
		{
			clingingPlayerFlapInterval = Mathf.Min(1f, clingingPlayerFlapInterval + Time.deltaTime / flapIntervalTimeOffset);
			if (clingingPlayerFlapInterval >= 1f)
			{
				if (clingingToPlayer.enemiesOnPerson <= 1)
				{
					flapIntervalTimeOffset = Random.Range(0.6f, 4f);
				}
				else if (Random.Range(0, 100) < 20)
				{
					flapIntervalTimeOffset = Random.Range(6f, 25f);
				}
				else
				{
					flapIntervalTimeOffset = Random.Range(6f, 15f);
				}
				SetFlappingLocalClient(setFlapping: true, isMainSnake: true);
				SetFlappingClientRpc(setFlapping: true);
			}
		}
		else
		{
			clingingPlayerFlapInterval = Mathf.Max(0f, clingingPlayerFlapInterval - Time.deltaTime / flapIntervalTimeOffset);
			if (clingingPlayerFlapInterval <= 0f)
			{
				flapIntervalTimeOffset = Random.Range(4f, 9f);
				SetFlappingLocalClient(setFlapping: false, isMainSnake: true);
				SetFlappingClientRpc(setFlapping: false);
			}
		}
	}

	private void DoChuckleOnInterval()
	{
		if (flapping)
		{
			chuckleInterval -= Time.deltaTime * 2f;
		}
		else
		{
			chuckleInterval -= Time.deltaTime;
		}
		if (chuckleInterval <= 0f)
		{
			MakeChuckleClientRpc();
			chuckleInterval = Random.Range(2f, 15f);
		}
	}

	private void DoLeapAndDropPhysics()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		if (fallingFromLeap)
		{
			fallFromLeapTimer -= Time.deltaTime;
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, landingPoint, 5f * Time.deltaTime);
			if (fallFromLeapTimer <= 0f || ((Component)this).transform.position == landingPoint)
			{
				if (((NetworkBehaviour)this).IsOwner)
				{
					((Behaviour)agent).enabled = true;
				}
				inSpecialAnimation = false;
				fallingFromLeap = false;
			}
		}
		if (!leaping || !((Object)(object)clingingToPlayer == (Object)null))
		{
			return;
		}
		if (hitWallInLeap)
		{
			leapTime += Time.deltaTime * 2f / leapTimeMultiplier;
		}
		else
		{
			leapTime += Time.deltaTime / leapTimeMultiplier;
		}
		if (leapTime > 1f)
		{
			StopLeapOnLocalClient(landOnGround: true);
			return;
		}
		bool flag = false;
		if (Physics.Raycast(((Component)this).transform.position, Vector3.down, ref hit, 50f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			flag = true;
			leapVerticalPosition = Mathf.Lerp(leapVerticalPosition, Mathf.Lerp(startLeapPosition.y + leapVerticalMultiplier, ((RaycastHit)(ref hit)).point.y + 0.1f, leapTime), Time.deltaTime * 12f);
		}
		else
		{
			leapVerticalPosition = Mathf.Lerp(leapVerticalPosition, startLeapPosition.y + leapVerticalCurve.Evaluate(leapTime) * leapVerticalMultiplier, 4f * Time.deltaTime);
		}
		Vector3 position = ((Component)this).transform.position;
		position.y = leapVerticalPosition;
		if (hitWallInLeap)
		{
			return;
		}
		position += leapDirection * leapSpeedMultiplier * Time.deltaTime;
		((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, Quaternion.LookRotation(leapDirection, Vector3.up), 5f * Time.deltaTime);
		if (!flag || Physics.Linecast(((Component)this).transform.position, position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			if (leapTime > 0.45f)
			{
				hitWallInLeap = true;
			}
		}
		else
		{
			((Component)this).transform.position = position;
		}
	}

	public override void Update()
	{
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (daytimeEnemyLeaving)
		{
			if (stunNormalizedTimer < 0f && !isEnemyDead)
			{
				creatureAnimator.SetBool("leaving", true);
			}
			if ((Object)(object)clingingToPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				StopClingingOnLocalClient(isMainSnake: true);
				StopClingingServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
		else if (isEnemyDead || StartOfRound.Instance.livingPlayers == 0)
		{
			if (fallingFromLeap)
			{
				fallFromLeapTimer -= Time.deltaTime;
				((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, landingPoint, 5f * Time.deltaTime);
				if (fallFromLeapTimer <= 0f || ((Component)this).transform.position == landingPoint)
				{
					inSpecialAnimation = false;
					fallingFromLeap = false;
				}
			}
		}
		else
		{
			if (((NetworkBehaviour)this).IsServer)
			{
				DoChuckleOnInterval();
			}
			if (Object.op_Implicit((Object)(object)clingingToPlayer) && clingPosition == 4)
			{
				MainSnakeActAsConductor();
			}
			DoLeapAndDropPhysics();
			CalculateAnimationSpeed();
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		base.OnCollideWithPlayer(other);
		if (!Object.op_Implicit((Object)(object)clingingToPlayer) && !isEnemyDead && !waitingForHitPlayerRPC && !(Time.realtimeSinceStartup - collideWithPlayerInterval < 1f) && !(Time.realtimeSinceStartup - timeOfLastCling < 4f) && !daytimeEnemyLeaving)
		{
			collideWithPlayerInterval = Time.realtimeSinceStartup;
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
			if ((Object)(object)playerControllerB != (Object)null && !Object.op_Implicit((Object)(object)playerControllerB.inAnimationWithEnemy) && (!playerControllerB.isInElevator || !StartOfRound.Instance.shipIsLeaving))
			{
				waitingForHitPlayerRPC = true;
				FSHitPlayerServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void FSHitPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(963676545u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 963676545u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[playerId];
		if (daytimeEnemyLeaving || (Object)(object)clingingToPlayer != (Object)null || Object.op_Implicit((Object)(object)playerControllerB.inAnimationWithEnemy) || (playerControllerB.isInElevator && StartOfRound.Instance.shipIsLeaving))
		{
			FSHitPlayerCancelClientRpc(playerId);
			return;
		}
		if (playerId == (int)GameNetworkManager.Instance.localPlayerController.playerClientId && waitingForHitPlayerRPC)
		{
			waitingForHitPlayerRPC = false;
		}
		int num = 4;
		FlowerSnakeEnemy[] array = Object.FindObjectsByType<FlowerSnakeEnemy>((FindObjectsSortMode)0);
		bool flag = false;
		for (int i = 1; i < 6; i++)
		{
			bool flag2 = false;
			for (int j = 0; j < array.Length; j++)
			{
				if ((Object)(object)array[j].clingingToPlayer == (Object)(object)playerControllerB && array[j].clingPosition == num)
				{
					flag2 = true;
				}
			}
			if (!flag2)
			{
				flag = true;
				break;
			}
			num = Mathf.Max((num + 1) % 6, 1);
		}
		if (!flag)
		{
			FSHitPlayerCancelClientRpc(playerId);
			return;
		}
		float clingTime = Random.Range(30f, 60f);
		SetClingToPlayer(playerControllerB, num, clingTime);
		ClingToPlayerClientRpc(playerId, num, clingTime);
	}

	[ClientRpc]
	public void FSHitPlayerCancelClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3147834348u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3147834348u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerId == (int)GameNetworkManager.Instance.localPlayerController.playerClientId && waitingForHitPlayerRPC)
			{
				waitingForHitPlayerRPC = false;
			}
		}
	}

	[ClientRpc]
	public void ClingToPlayerClientRpc(int playerId, int setClingPosition, float clingTime)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2927112307u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			BytePacker.WriteValueBitPacked(val2, setClingPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref clingTime, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2927112307u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
		{
			if (playerId == (int)GameNetworkManager.Instance.localPlayerController.playerClientId && waitingForHitPlayerRPC)
			{
				waitingForHitPlayerRPC = false;
			}
			StopLeapOnLocalClient();
			PlayerControllerB playerToCling = StartOfRound.Instance.allPlayerScripts[playerId];
			SetClingToPlayer(playerToCling, setClingPosition, clingTime);
		}
	}

	private void SetClingToPlayer(PlayerControllerB playerToCling, int setClingPosition, float clingTime)
	{
		clingPosition = setClingPosition;
		clingingToPlayer = playerToCling;
		inSpecialAnimation = true;
		playerToCling.enemiesOnPerson++;
		creatureAnimator.SetInteger("clingType", setClingPosition);
		playerToCling.carryWeight += 0.03f;
		if ((Object)(object)playerToCling == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			SoundManager.Instance.misc2DAudio.volume = 1f;
			SoundManager.Instance.misc2DAudio.pitch = Random.Range(0.9f, 1.1f);
			SoundManager.Instance.misc2DAudio.PlayOneShot(enemyType.audioClips[8]);
		}
		clingToPlayerTimer = clingTime;
	}

	public override void EnableEnemyMesh(bool enable, bool overrideDoNotSet = false)
	{
		if ((Object)(object)clingingToPlayer != (Object)null)
		{
			isInsidePlayerShip = clingingToPlayer.isInHangarShipRoom;
		}
		base.EnableEnemyMesh(!isInsidePlayerShip || GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom, overrideDoNotSet);
	}

	private void LateUpdate()
	{
		if (Object.op_Implicit((Object)(object)clingingToPlayer))
		{
			SetClingingAnimationPosition();
		}
	}

	private void CalculateAnimationSpeed(float maxSpeed = 1f)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 2f);
		float magnitude = ((Vector3)(ref val)).magnitude;
		creatureAnimator.SetFloat("Moving", Mathf.Clamp(magnitude, 0f, 1f));
		previousPosition = ((Component)this).transform.position;
		if (!flapping)
		{
			if (magnitude > 0.1f)
			{
				flappingAudio.volume = Mathf.Lerp(flappingAudio.volume, 1f, Time.deltaTime * 3f);
			}
			else
			{
				flappingAudio.volume = Mathf.Lerp(flappingAudio.volume, 0f, Time.deltaTime * 3f);
			}
		}
	}

	private void SetClingingAnimationPosition()
	{
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)clingingToPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			if (clingPosition >= 4)
			{
				((Component)this).transform.position = ((Component)clingingToPlayer.gameplayCamera).transform.position;
				Transform transform = ((Component)this).transform;
				transform.position += ((Component)this).transform.up * -0.172f;
				Transform transform2 = ((Component)this).transform;
				transform2.position += ((Component)this).transform.right * -0.013f;
				((Component)this).transform.rotation = ((Component)clingingToPlayer.gameplayCamera).transform.rotation;
			}
			else
			{
				((Component)this).transform.position = ((Component)clingingToPlayer.upperSpineLocalPoint).transform.position;
				Transform transform3 = ((Component)this).transform;
				transform3.position += ((Component)this).transform.up * spinePositionUpOffset;
				Transform transform4 = ((Component)this).transform;
				transform4.position += ((Component)this).transform.right * spinePositionRightOffset;
				((Component)this).transform.rotation = ((Component)clingingToPlayer.upperSpineLocalPoint).transform.rotation;
			}
		}
		else if (clingPosition >= 4)
		{
			bool flag = false;
			if (clingPosition == 4 && flapping && Vector3.Angle(clingingToPlayer.headCostumeContainer.up, Vector3.up) > 70f)
			{
				flag = true;
			}
			((Component)this).transform.position = clingingToPlayer.headCostumeContainer.position;
			if (!flag)
			{
				((Component)this).transform.rotation = clingingToPlayer.headCostumeContainer.rotation;
			}
		}
		else
		{
			((Component)this).transform.position = clingingToPlayer.upperSpine.position;
			((Component)this).transform.rotation = clingingToPlayer.upperSpine.rotation;
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_FlowerSnakeEnemy()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2859615571u, new RpcReceiveHandler(__rpc_handler_2859615571));
		NetworkManager.__rpc_func_table.Add(3381700831u, new RpcReceiveHandler(__rpc_handler_3381700831));
		NetworkManager.__rpc_func_table.Add(3098650349u, new RpcReceiveHandler(__rpc_handler_3098650349));
		NetworkManager.__rpc_func_table.Add(2302911734u, new RpcReceiveHandler(__rpc_handler_2302911734));
		NetworkManager.__rpc_func_table.Add(1135936035u, new RpcReceiveHandler(__rpc_handler_1135936035));
		NetworkManager.__rpc_func_table.Add(4240465152u, new RpcReceiveHandler(__rpc_handler_4240465152));
		NetworkManager.__rpc_func_table.Add(1804766282u, new RpcReceiveHandler(__rpc_handler_1804766282));
		NetworkManager.__rpc_func_table.Add(2596148101u, new RpcReceiveHandler(__rpc_handler_2596148101));
		NetworkManager.__rpc_func_table.Add(1473701276u, new RpcReceiveHandler(__rpc_handler_1473701276));
		NetworkManager.__rpc_func_table.Add(963676545u, new RpcReceiveHandler(__rpc_handler_963676545));
		NetworkManager.__rpc_func_table.Add(3147834348u, new RpcReceiveHandler(__rpc_handler_3147834348));
		NetworkManager.__rpc_func_table.Add(2927112307u, new RpcReceiveHandler(__rpc_handler_2927112307));
	}

	private static void __rpc_handler_2859615571(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 setLeapDir = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref setLeapDir);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).StartLeapClientRpc(setLeapDir);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3381700831(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((FlowerSnakeEnemy)(object)target).StopClingingServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3098650349(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).StopClingingClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2302911734(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 val = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref val);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).StopLeapClientRpc(val);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1135936035(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flappingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flappingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).SetFlappingClientRpc(flappingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4240465152(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).SetEnemyLeavingClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1804766282(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((FlowerSnakeEnemy)(object)target).StartFlyingServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2596148101(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).StartFlyingClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1473701276(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).MakeChuckleClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_963676545(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((FlowerSnakeEnemy)(object)target).FSHitPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3147834348(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).FSHitPlayerCancelClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2927112307(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int setClingPosition = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setClingPosition);
			float clingTime = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref clingTime, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowerSnakeEnemy)(object)target).ClingToPlayerClientRpc(playerId, setClingPosition, clingTime);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "FlowerSnakeEnemy";
	}
}
