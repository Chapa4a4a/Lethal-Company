using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class AnimatedObjectTrigger : NetworkBehaviour
{
	public Animator triggerAnimator;

	public Animator triggerAnimatorB;

	public bool isBool = true;

	public string animationString;

	public bool boolValue;

	public bool setInitialState;

	public bool initialBoolState;

	[Space(5f)]
	public AudioSource thisAudioSource;

	public AudioClip[] boolFalseAudios;

	public AudioClip[] boolTrueAudios;

	public AudioClip[] secondaryAudios;

	[Space(4f)]
	public AudioClip playWhileTrue;

	public bool resetAudioWhenFalse;

	public bool makeAudibleNoise;

	public float noiseLoudness = 0.7f;

	[Space(3f)]
	public ParticleSystem playParticle;

	public int playParticleOnTimesTriggered;

	[Space(4f)]
	private StartOfRound playersManager;

	private bool localPlayerTriggered;

	public BooleanEvent onTriggerBool;

	[Space(5f)]
	public bool playAudiosInSequence;

	private int timesTriggered;

	public bool triggerByChance;

	public float chancePercent = 5f;

	private bool hasInitializedRandomSeed;

	public Random triggerRandom;

	private float audioTime;

	public void Start()
	{
		if (setInitialState)
		{
			if (SceneManager.sceneCount > 1)
			{
				((MonoBehaviour)this).StartCoroutine(waitForNavMeshBake());
			}
			else
			{
				SetInitialState();
			}
		}
	}

	private IEnumerator waitForNavMeshBake()
	{
		yield return (object)new WaitForSeconds(7f);
		SetInitialState();
	}

	public void SetInitialState()
	{
		if (setInitialState)
		{
			boolValue = initialBoolState;
			triggerAnimator.SetBool(animationString, boolValue);
			if ((Object)(object)triggerAnimatorB != (Object)null)
			{
				triggerAnimatorB.SetBool("on", boolValue);
			}
		}
	}

	public void TriggerAnimation(PlayerControllerB playerWhoTriggered)
	{
		if (triggerByChance)
		{
			InitializeRandomSeed();
			if ((float)triggerRandom.Next(100) >= chancePercent)
			{
				return;
			}
		}
		if (isBool)
		{
			Debug.Log((object)$"Triggering animated object trigger bool: setting to {!boolValue}");
			boolValue = !boolValue;
			if ((Object)(object)triggerAnimator != (Object)null)
			{
				triggerAnimator.SetBool(animationString, boolValue);
			}
			if ((Object)(object)triggerAnimatorB != (Object)null)
			{
				triggerAnimatorB.SetBool("on", boolValue);
			}
		}
		else if ((Object)(object)triggerAnimator != (Object)null)
		{
			triggerAnimator.SetTrigger(animationString);
		}
		SetParticleBasedOnBoolean();
		PlayAudio(boolValue);
		localPlayerTriggered = true;
		if (isBool)
		{
			((UnityEvent<bool>)onTriggerBool).Invoke(boolValue);
			UpdateAnimServerRpc(boolValue, playSecondaryAudios: false, (int)playerWhoTriggered.playerClientId);
		}
		else
		{
			UpdateAnimTriggerServerRpc();
		}
	}

	public void TriggerAnimationNonPlayer(bool playSecondaryAudios = false, bool overrideBool = false, bool setBoolFalse = false)
	{
		if (overrideBool && setBoolFalse && !boolValue)
		{
			return;
		}
		if (triggerByChance)
		{
			InitializeRandomSeed();
			if ((float)triggerRandom.Next(100) >= chancePercent)
			{
				return;
			}
		}
		if (isBool)
		{
			boolValue = !boolValue;
			triggerAnimator.SetBool(animationString, boolValue);
		}
		else
		{
			triggerAnimator.SetTrigger(animationString);
		}
		SetParticleBasedOnBoolean();
		PlayAudio(boolValue, playSecondaryAudios);
		localPlayerTriggered = true;
		if (isBool)
		{
			UpdateAnimServerRpc(boolValue, playSecondaryAudios);
		}
		else
		{
			UpdateAnimTriggerServerRpc();
		}
	}

	public void InitializeRandomSeed()
	{
		if (!hasInitializedRandomSeed)
		{
			hasInitializedRandomSeed = true;
			triggerRandom = new Random(playersManager.randomMapSeed);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void UpdateAnimServerRpc(bool setBool, bool playSecondaryAudios = false, int playerWhoTriggered = -1)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1461767556u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setBool, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref playSecondaryAudios, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1461767556u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				UpdateAnimClientRpc(setBool, playSecondaryAudios, playerWhoTriggered);
			}
		}
	}

	[ClientRpc]
	private void UpdateAnimClientRpc(bool setBool, bool playSecondaryAudios = false, int playerWhoTriggered = -1)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(848048148u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setBool, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref playSecondaryAudios, default(ForPrimitives));
			BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 848048148u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null || (playerWhoTriggered != -1 && (int)GameNetworkManager.Instance.localPlayerController.playerClientId == playerWhoTriggered))
		{
			return;
		}
		if (isBool)
		{
			if ((Object)(object)triggerAnimatorB != (Object)null)
			{
				triggerAnimatorB.SetBool("on", setBool);
			}
			boolValue = setBool;
			if ((Object)(object)triggerAnimator != (Object)null)
			{
				triggerAnimator.SetBool(animationString, setBool);
			}
			((UnityEvent<bool>)onTriggerBool).Invoke(boolValue);
		}
		else
		{
			triggerAnimator.SetTrigger(animationString);
		}
		SetParticleBasedOnBoolean();
		PlayAudio(setBool, playSecondaryAudios);
	}

	public void SetBoolOnClientOnly(bool setTo)
	{
		if (isBool)
		{
			boolValue = setTo;
			if ((Object)(object)triggerAnimator != (Object)null)
			{
				triggerAnimator.SetBool(animationString, boolValue);
			}
			SetParticleBasedOnBoolean();
		}
		PlayAudio(boolValue);
	}

	public void SetBoolOnClientOnlyInverted(bool setTo)
	{
		if (isBool)
		{
			boolValue = !setTo;
			if ((Object)(object)triggerAnimator != (Object)null)
			{
				triggerAnimator.SetBool(animationString, boolValue);
			}
			SetParticleBasedOnBoolean();
		}
		PlayAudio(boolValue);
	}

	private void SetParticleBasedOnBoolean()
	{
		if (!((Object)(object)playParticle == (Object)null))
		{
			if (boolValue)
			{
				playParticle.Play(true);
			}
			else
			{
				playParticle.Stop(true, (ParticleSystemStopBehavior)1);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void UpdateAnimTriggerServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2219526317u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2219526317u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				UpdateAnimTriggerClientRpc();
			}
		}
	}

	[ClientRpc]
	private void UpdateAnimTriggerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1023577379u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1023577379u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		((UnityEvent<bool>)onTriggerBool).Invoke(false);
		if (localPlayerTriggered)
		{
			localPlayerTriggered = false;
			return;
		}
		if ((Object)(object)triggerAnimator != (Object)null)
		{
			triggerAnimator.SetTrigger(animationString);
		}
		PlayAudio(boolVal: false);
	}

	private void PlayAudio(bool boolVal, bool playSecondaryAudios = false)
	{
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null || (Object)(object)thisAudioSource == (Object)null)
		{
			return;
		}
		if ((Object)(object)playWhileTrue != (Object)null)
		{
			thisAudioSource.clip = playWhileTrue;
			if (boolVal)
			{
				thisAudioSource.Play();
				if (!resetAudioWhenFalse)
				{
					thisAudioSource.time = audioTime;
				}
			}
			else
			{
				audioTime = thisAudioSource.time;
				thisAudioSource.Stop();
			}
		}
		AudioClip val = null;
		if (playSecondaryAudios)
		{
			val = secondaryAudios[Random.Range(0, secondaryAudios.Length)];
		}
		else if (boolVal && boolTrueAudios.Length != 0)
		{
			val = boolTrueAudios[Random.Range(0, boolTrueAudios.Length)];
		}
		else if (boolFalseAudios.Length != 0)
		{
			if (playAudiosInSequence)
			{
				if (timesTriggered >= boolFalseAudios.Length)
				{
					return;
				}
				if (timesTriggered == playParticleOnTimesTriggered)
				{
					playParticle.Play(true);
					if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)playParticle).transform.position) < 14f)
					{
						HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
					}
				}
				val = boolFalseAudios[timesTriggered];
				timesTriggered++;
			}
			else
			{
				val = boolFalseAudios[Random.Range(0, boolFalseAudios.Length)];
			}
		}
		if (!((Object)(object)val == (Object)null))
		{
			thisAudioSource.PlayOneShot(val, 1f);
			WalkieTalkie.TransmitOneShotAudio(thisAudioSource, val);
			if (makeAudibleNoise)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)thisAudioSource).transform.position, 18f, noiseLoudness, 0, StartOfRound.Instance.hangarDoorsClosed, 400);
			}
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_AnimatedObjectTrigger()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1461767556u, new RpcReceiveHandler(__rpc_handler_1461767556));
		NetworkManager.__rpc_func_table.Add(848048148u, new RpcReceiveHandler(__rpc_handler_848048148));
		NetworkManager.__rpc_func_table.Add(2219526317u, new RpcReceiveHandler(__rpc_handler_2219526317));
		NetworkManager.__rpc_func_table.Add(1023577379u, new RpcReceiveHandler(__rpc_handler_1023577379));
	}

	private static void __rpc_handler_1461767556(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool setBool = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setBool, default(ForPrimitives));
			bool playSecondaryAudios = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref playSecondaryAudios, default(ForPrimitives));
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((AnimatedObjectTrigger)(object)target).UpdateAnimServerRpc(setBool, playSecondaryAudios, playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_848048148(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool setBool = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setBool, default(ForPrimitives));
			bool playSecondaryAudios = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref playSecondaryAudios, default(ForPrimitives));
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((AnimatedObjectTrigger)(object)target).UpdateAnimClientRpc(setBool, playSecondaryAudios, playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2219526317(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((AnimatedObjectTrigger)(object)target).UpdateAnimTriggerServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1023577379(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((AnimatedObjectTrigger)(object)target).UpdateAnimTriggerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "AnimatedObjectTrigger";
	}
}
