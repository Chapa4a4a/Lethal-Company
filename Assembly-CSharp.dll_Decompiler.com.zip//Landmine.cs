using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class Landmine : NetworkBehaviour, IHittable
{
	private bool mineActivated = true;

	public bool hasExploded;

	public ParticleSystem explosionParticle;

	public Animator mineAnimator;

	public AudioSource mineAudio;

	public AudioSource mineFarAudio;

	public AudioClip mineDetonate;

	public AudioClip mineTrigger;

	public AudioClip mineDetonateFar;

	public AudioClip mineDeactivate;

	public AudioClip minePress;

	private bool sendingExplosionRPC;

	private RaycastHit hit;

	private RoundManager roundManager;

	private float pressMineDebounceTimer;

	private bool localPlayerOnMine;

	private void Start()
	{
		((MonoBehaviour)this).StartCoroutine(StartIdleAnimation());
	}

	private void Update()
	{
		if (pressMineDebounceTimer > 0f)
		{
			pressMineDebounceTimer -= Time.deltaTime;
		}
		if (localPlayerOnMine && GameNetworkManager.Instance.localPlayerController.teleportedLastFrame)
		{
			localPlayerOnMine = false;
			TriggerMineOnLocalClientByExiting();
		}
	}

	public void ToggleMine(bool enabled)
	{
		if (mineActivated != enabled)
		{
			mineActivated = enabled;
			if (!enabled)
			{
				mineAudio.PlayOneShot(mineDeactivate);
				WalkieTalkie.TransmitOneShotAudio(mineAudio, mineDeactivate);
			}
			ToggleMineServerRpc(enabled);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ToggleMineServerRpc(bool enable)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2763604698u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enable, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2763604698u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ToggleMineClientRpc(enable);
			}
		}
	}

	[ClientRpc]
	public void ToggleMineClientRpc(bool enable)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3479956057u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enable, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3479956057u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				ToggleMineEnabledLocalClient(enable);
			}
		}
	}

	public void ToggleMineEnabledLocalClient(bool enabled)
	{
		if (mineActivated != enabled)
		{
			mineActivated = enabled;
			if (!enabled)
			{
				mineAudio.PlayOneShot(mineDeactivate);
				WalkieTalkie.TransmitOneShotAudio(mineAudio, mineDeactivate);
			}
		}
	}

	private IEnumerator StartIdleAnimation()
	{
		roundManager = Object.FindObjectOfType<RoundManager>();
		if (!((Object)(object)roundManager == (Object)null))
		{
			if (roundManager.BreakerBoxRandom != null)
			{
				yield return (object)new WaitForSeconds((float)roundManager.BreakerBoxRandom.NextDouble() + 0.5f);
			}
			mineAnimator.SetTrigger("startIdle");
			mineAudio.pitch = Random.Range(0.9f, 1.1f);
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (hasExploded || pressMineDebounceTimer > 0f)
		{
			return;
		}
		if (((Component)other).CompareTag("Player"))
		{
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if (!((Object)(object)component != (Object)(object)GameNetworkManager.Instance.localPlayerController) && (Object)(object)component != (Object)null && !component.isPlayerDead)
			{
				localPlayerOnMine = true;
				pressMineDebounceTimer = 0.5f;
				PressMineServerRpc();
			}
		}
		else
		{
			if (!((Component)other).CompareTag("PhysicsProp") && !((Component)other).tag.StartsWith("PlayerRagdoll"))
			{
				return;
			}
			if (Object.op_Implicit((Object)(object)((Component)other).GetComponent<DeadBodyInfo>()))
			{
				if ((Object)(object)((Component)other).GetComponent<DeadBodyInfo>().playerScript != (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					return;
				}
			}
			else if (Object.op_Implicit((Object)(object)((Component)other).GetComponent<GrabbableObject>()) && !((NetworkBehaviour)((Component)other).GetComponent<GrabbableObject>()).NetworkObject.IsOwner)
			{
				return;
			}
			pressMineDebounceTimer = 0.5f;
			PressMineServerRpc();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PressMineServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4224840819u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4224840819u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PressMineClientRpc();
			}
		}
	}

	[ClientRpc]
	public void PressMineClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2652432181u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2652432181u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				pressMineDebounceTimer = 0.5f;
				mineAudio.PlayOneShot(minePress);
				WalkieTalkie.TransmitOneShotAudio(mineAudio, minePress);
			}
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (hasExploded || !mineActivated)
		{
			return;
		}
		if (((Component)other).CompareTag("Player"))
		{
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)null && !component.isPlayerDead && !((Object)(object)component != (Object)(object)GameNetworkManager.Instance.localPlayerController))
			{
				localPlayerOnMine = false;
				TriggerMineOnLocalClientByExiting();
			}
		}
		else
		{
			if (!((Component)other).tag.StartsWith("PlayerRagdoll") && !((Component)other).CompareTag("PhysicsProp"))
			{
				return;
			}
			if (Object.op_Implicit((Object)(object)((Component)other).GetComponent<DeadBodyInfo>()))
			{
				if ((Object)(object)((Component)other).GetComponent<DeadBodyInfo>().playerScript != (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					return;
				}
			}
			else if (Object.op_Implicit((Object)(object)((Component)other).GetComponent<GrabbableObject>()) && !((NetworkBehaviour)((Component)other).GetComponent<GrabbableObject>()).NetworkObject.IsOwner)
			{
				return;
			}
			TriggerMineOnLocalClientByExiting();
		}
	}

	private void TriggerMineOnLocalClientByExiting()
	{
		if (!hasExploded)
		{
			SetOffMineAnimation();
			sendingExplosionRPC = true;
			ExplodeMineServerRpc();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ExplodeMineServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3032666565u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3032666565u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ExplodeMineClientRpc();
			}
		}
	}

	[ClientRpc]
	public void ExplodeMineClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(456724201u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 456724201u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (sendingExplosionRPC)
			{
				sendingExplosionRPC = false;
			}
			else
			{
				SetOffMineAnimation();
			}
		}
	}

	public void SetOffMineAnimation()
	{
		hasExploded = true;
		mineAnimator.SetTrigger("detonate");
		mineAudio.PlayOneShot(mineTrigger, 1f);
	}

	private IEnumerator TriggerOtherMineDelayed(Landmine mine)
	{
		if (!mine.hasExploded)
		{
			mine.mineAudio.pitch = Random.Range(0.75f, 1.07f);
			mine.hasExploded = true;
			yield return (object)new WaitForSeconds(0.2f);
			mine.SetOffMineAnimation();
		}
	}

	public void Detonate()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		mineAudio.pitch = Random.Range(0.93f, 1.07f);
		mineAudio.PlayOneShot(mineDetonate, 1f);
		SpawnExplosion(((Component)this).transform.position + Vector3.up, spawnExplosionEffect: false, 5.7f, 6f);
	}

	public static void SpawnExplosion(Vector3 explosionPosition, bool spawnExplosionEffect = false, float killRange = 1f, float damageRange = 1f, int nonLethalDamage = 50, float physicsForce = 0f, GameObject overridePrefab = null, bool goThroughCar = false)
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0333: Unknown result type (might be due to invalid IL or missing references)
		//IL_0338: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0364: Unknown result type (might be due to invalid IL or missing references)
		//IL_0382: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Unknown result type (might be due to invalid IL or missing references)
		//IL_039b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0455: Unknown result type (might be due to invalid IL or missing references)
		//IL_045a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_041a: Unknown result type (might be due to invalid IL or missing references)
		//IL_041f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0421: Unknown result type (might be due to invalid IL or missing references)
		//IL_0426: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0400: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0407: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		if (spawnExplosionEffect)
		{
			GameObject val = ((!((Object)(object)overridePrefab != (Object)null)) ? Object.Instantiate<GameObject>(StartOfRound.Instance.explosionPrefab, explosionPosition, Quaternion.Euler(-90f, 0f, 0f), RoundManager.Instance.mapPropsContainer.transform) : Object.Instantiate<GameObject>(overridePrefab, explosionPosition, Quaternion.identity, RoundManager.Instance.mapPropsContainer.transform));
			val.SetActive(true);
		}
		float num = Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, explosionPosition);
		if (num < 14f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
		}
		else if (num < 25f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
		}
		bool flag = false;
		Collider[] array = Physics.OverlapSphere(explosionPosition, damageRange, 2621448, (QueryTriggerInteraction)2);
		PlayerControllerB playerControllerB = null;
		RaycastHit val2 = default(RaycastHit);
		Vector3 val4;
		for (int i = 0; i < array.Length; i++)
		{
			float num2 = Vector3.Distance(explosionPosition, ((Component)array[i]).transform.position);
			if (Physics.Linecast(explosionPosition, ((Component)array[i]).transform.position + Vector3.up * 0.3f, ref val2, 1073742080, (QueryTriggerInteraction)1) && ((!goThroughCar && ((Component)((RaycastHit)(ref val2)).collider).gameObject.layer == 30) || num2 > 4f))
			{
				continue;
			}
			if (((Component)array[i]).gameObject.layer == 3 && !flag)
			{
				playerControllerB = ((Component)array[i]).gameObject.GetComponent<PlayerControllerB>();
				if ((Object)(object)playerControllerB != (Object)null && ((NetworkBehaviour)playerControllerB).IsOwner)
				{
					flag = true;
					if (num2 < killRange)
					{
						Vector3 val3 = Vector3.Normalize(((Component)playerControllerB.gameplayCamera).transform.position - explosionPosition) * 80f / Vector3.Distance(((Component)playerControllerB.gameplayCamera).transform.position, explosionPosition);
						PlayerControllerB playerControllerB2 = playerControllerB;
						Vector3 bodyVelocity = val3;
						val4 = default(Vector3);
						playerControllerB2.KillPlayer(bodyVelocity, spawnBody: true, CauseOfDeath.Blast, 0, val4);
					}
					else if (num2 < damageRange)
					{
						Vector3 val3 = Vector3.Normalize(((Component)playerControllerB.gameplayCamera).transform.position - explosionPosition) * 80f / Vector3.Distance(((Component)playerControllerB.gameplayCamera).transform.position, explosionPosition);
						playerControllerB.DamagePlayer(nonLethalDamage, hasDamageSFX: true, callRPC: true, CauseOfDeath.Blast, 0, fallDamage: false, val3);
					}
				}
			}
			else if (((Component)array[i]).gameObject.layer == 21)
			{
				Landmine componentInChildren = ((Component)array[i]).gameObject.GetComponentInChildren<Landmine>();
				if ((Object)(object)componentInChildren != (Object)null && !componentInChildren.hasExploded && num2 < 6f)
				{
					((MonoBehaviour)componentInChildren).StartCoroutine(componentInChildren.TriggerOtherMineDelayed(componentInChildren));
				}
			}
			else if (((Component)array[i]).gameObject.layer == 19)
			{
				EnemyAICollisionDetect componentInChildren2 = ((Component)array[i]).gameObject.GetComponentInChildren<EnemyAICollisionDetect>();
				if ((Object)(object)componentInChildren2 != (Object)null && ((NetworkBehaviour)componentInChildren2.mainScript).IsOwner && num2 < 4.5f)
				{
					EnemyAI mainScript = componentInChildren2.mainScript;
					val4 = default(Vector3);
					mainScript.HitEnemyOnLocalClient(6, val4);
					componentInChildren2.mainScript.HitFromExplosion(num2);
				}
			}
		}
		playerControllerB = GameNetworkManager.Instance.localPlayerController;
		if (physicsForce > 0f && Vector3.Distance(((Component)playerControllerB).transform.position, explosionPosition) < 35f && !Physics.Linecast(explosionPosition, ((Component)playerControllerB).transform.position + Vector3.up * 0.3f, ref val2, 256, (QueryTriggerInteraction)1))
		{
			float num3 = Vector3.Distance(((Component)playerControllerB).transform.position, explosionPosition);
			Vector3 val5 = Vector3.Normalize(((Component)playerControllerB).transform.position + Vector3.up * num3 - explosionPosition) / (num3 * 0.35f) * physicsForce;
			if (((Vector3)(ref val5)).magnitude > 2f)
			{
				if (((Vector3)(ref val5)).magnitude > 10f)
				{
					playerControllerB.CancelSpecialTriggerAnimations();
				}
				if (playerControllerB.inVehicleAnimation)
				{
					val4 = playerControllerB.externalForceAutoFade + val5;
					if (!(((Vector3)(ref val4)).magnitude > 50f))
					{
						goto IL_042b;
					}
				}
				PlayerControllerB playerControllerB3 = playerControllerB;
				playerControllerB3.externalForceAutoFade += val5;
			}
		}
		goto IL_042b;
		IL_042b:
		VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
		if ((Object)(object)vehicleController != (Object)null && !vehicleController.magnetedToShip && physicsForce > 0f && Vector3.Distance(((Component)vehicleController).transform.position, explosionPosition) < 35f)
		{
			vehicleController.mainRigidbody.AddExplosionForce(physicsForce * 50f, explosionPosition, 12f, 3f, (ForceMode)1);
		}
		int num4 = ~LayerMask.GetMask(new string[1] { "Room" });
		num4 = ~LayerMask.GetMask(new string[1] { "Colliders" });
		array = Physics.OverlapSphere(explosionPosition, 10f, num4);
		for (int j = 0; j < array.Length; j++)
		{
			Rigidbody component = ((Component)array[j]).GetComponent<Rigidbody>();
			if ((Object)(object)component != (Object)null)
			{
				component.AddExplosionForce(70f, explosionPosition, 10f);
			}
		}
	}

	public bool MineHasLineOfSight(Vector3 pos)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		return !Physics.Linecast(((Component)this).transform.position, pos, ref hit, 256);
	}

	bool IHittable.Hit(int force, Vector3 hitDirection, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		SetOffMineAnimation();
		sendingExplosionRPC = true;
		ExplodeMineServerRpc();
		return true;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_Landmine()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2763604698u, new RpcReceiveHandler(__rpc_handler_2763604698));
		NetworkManager.__rpc_func_table.Add(3479956057u, new RpcReceiveHandler(__rpc_handler_3479956057));
		NetworkManager.__rpc_func_table.Add(4224840819u, new RpcReceiveHandler(__rpc_handler_4224840819));
		NetworkManager.__rpc_func_table.Add(2652432181u, new RpcReceiveHandler(__rpc_handler_2652432181));
		NetworkManager.__rpc_func_table.Add(3032666565u, new RpcReceiveHandler(__rpc_handler_3032666565));
		NetworkManager.__rpc_func_table.Add(456724201u, new RpcReceiveHandler(__rpc_handler_456724201));
	}

	private static void __rpc_handler_2763604698(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enable = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enable, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((Landmine)(object)target).ToggleMineServerRpc(enable);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3479956057(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enable = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enable, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Landmine)(object)target).ToggleMineClientRpc(enable);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4224840819(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((Landmine)(object)target).PressMineServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2652432181(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Landmine)(object)target).PressMineClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3032666565(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((Landmine)(object)target).ExplodeMineServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_456724201(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((Landmine)(object)target).ExplodeMineClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "Landmine";
	}
}
