using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Dissonance;
using Steamworks;
using TMPro;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;
using UnityEngine.UI;

namespace GameNetcodeStuff;

public class PlayerControllerB : NetworkBehaviour, IHittable, IShockableWithGun, IVisibleThreat
{
	public bool isTestingPlayer;

	[Header("MODELS / ANIMATIONS")]
	public Transform[] bodyParts;

	public Transform thisPlayerBody;

	public SkinnedMeshRenderer thisPlayerModel;

	public SkinnedMeshRenderer thisPlayerModelLOD1;

	public SkinnedMeshRenderer thisPlayerModelLOD2;

	public SkinnedMeshRenderer thisPlayerModelArms;

	public Transform playerGlobalHead;

	public Transform playerModelArmsMetarig;

	public Transform localArmsRotationTarget;

	public Transform meshContainer;

	public Transform lowerSpine;

	public Transform upperSpine;

	public Transform upperSpineLocalPoint;

	public Transform lowerTorsoCostumeContainer;

	public Transform lowerTorsoCostumeContainerBeltBagOffset;

	public Transform headCostumeContainer;

	public Transform headCostumeContainerLocal;

	public Camera gameplayCamera;

	public Transform cameraContainerTransform;

	public Transform playerEye;

	public float targetFOV = 66f;

	public Camera visorCamera;

	public CharacterController thisController;

	public Animator playerBodyAnimator;

	public MeshFilter playerBadgeMesh;

	public MeshRenderer playerBetaBadgeMesh;

	public int playerLevelNumber;

	public Transform localVisor;

	public Transform localVisorTargetPoint;

	private bool isSidling;

	private bool wasMovingForward;

	public MultiRotationConstraint cameraLookRig1;

	public MultiRotationConstraint cameraLookRig2;

	public Transform playerHudUIContainer;

	public Transform playerHudBaseRotation;

	public ChainIKConstraint rightArmNormalRig;

	public ChainIKConstraint rightArmProceduralRig;

	public ChainIKConstraint rightArmRig;

	public ChainIKConstraint leftArmRig;

	public TwoBoneIKConstraint leftArmRigSecondary;

	public TwoBoneIKConstraint rightArmRigSecondary;

	public ChainIKConstraint leftArmRigSecondaryLocal;

	public ChainIKConstraint rightArmRigSecondaryLocal;

	public Transform rightArmProceduralTarget;

	private Vector3 rightArmProceduralTargetBasePosition;

	public Transform leftHandItemTarget;

	public Light nightVision;

	public Light nightVisionRadar;

	public int currentSuitID;

	public bool performingEmote;

	public float emoteLayerWeight;

	public float timeSinceStartingEmote;

	public ParticleSystem beamUpParticle;

	public ParticleSystem beamOutParticle;

	public ParticleSystem beamOutBuildupParticle;

	public bool localArmsMatchCamera;

	public Transform localArmsTransform;

	public Collider playerCollider;

	public Collider[] bodyPartSpraypaintColliders;

	[Header("AUDIOS")]
	public AudioSource movementAudio;

	public AudioSource itemAudio;

	public AudioSource statusEffectAudio;

	public AudioSource waterBubblesAudio;

	public int currentFootstepSurfaceIndex;

	private int previousFootstepClip;

	[HideInInspector]
	public Dictionary<AudioSource, AudioReverbTrigger> audioCoroutines = new Dictionary<AudioSource, AudioReverbTrigger>();

	[HideInInspector]
	public Dictionary<AudioSource, IEnumerator> audioCoroutines2 = new Dictionary<AudioSource, IEnumerator>();

	[HideInInspector]
	public AudioReverbTrigger currentAudioTrigger;

	public AudioReverbTrigger currentAudioTriggerB;

	public float targetDryLevel;

	public float targetRoom;

	public float targetHighFreq;

	public float targetLowFreq;

	public float targetDecayTime;

	public ReverbPreset reverbPreset;

	public AudioListener activeAudioListener;

	public AudioReverbFilter activeAudioReverbFilter;

	public ParticleSystem bloodParticle;

	public bool playingQuickSpecialAnimation;

	private Coroutine quickSpecialAnimationCoroutine;

	[Header("INPUT / MOVEMENT")]
	public float movementSpeed = 0.5f;

	public PlayerActions playerActions;

	private bool isWalking;

	private bool movingForward;

	public Vector2 moveInputVector;

	public Vector3 velocityLastFrame;

	private float sprintMultiplier = 1f;

	public bool isSprinting;

	public float sprintTime = 5f;

	public Image sprintMeterUI;

	[HideInInspector]
	public float sprintMeter;

	[HideInInspector]
	public bool isExhausted;

	private float exhaustionEffectLerp;

	public float jumpForce = 5f;

	private bool isJumping;

	private bool isFallingFromJump;

	private Coroutine jumpCoroutine;

	public float fallValue;

	public bool isGroundedOnServer;

	public bool isPlayerSliding;

	private float playerSlidingTimer;

	public Vector3 playerGroundNormal;

	public float maxSlideFriction;

	private float slideFriction;

	public float fallValueUncapped;

	public bool takingFallDamage;

	public float minVelocityToTakeDamage;

	public bool isCrouching;

	private float crouchMeter;

	private bool isFallingNoJump;

	public int isMovementHindered;

	private int movementHinderedPrev;

	public float hinderedMultiplier = 1f;

	public int sourcesCausingSinking;

	public bool isSinking;

	public bool isUnderwater;

	private float syncUnderwaterInterval;

	private bool isFaceUnderwaterOnServer;

	public Collider underwaterCollider;

	private bool wasUnderwaterLastFrame;

	public float sinkingValue;

	public float sinkingSpeedMultiplier;

	public int statusEffectAudioIndex;

	private float cameraUp;

	public float lookSensitivity = 0.4f;

	public bool disableLookInput;

	public bool disableMoveInput;

	private float oldLookRot;

	private float targetLookRot;

	private float previousYRot;

	private float targetYRot;

	public Vector3 syncFullRotation;

	public Vector3 syncFullCameraRotation;

	private Vector3 walkForce;

	public Vector3 externalForces;

	public Vector3 externalForceAutoFade;

	private Vector3 movementForcesLastFrame;

	public Rigidbody playerRigidbody;

	public float averageVelocity;

	public int velocityMovingAverageLength = 20;

	public int velocityAverageCount;

	public float getAverageVelocityInterval;

	public bool jetpackControls;

	public bool disablingJetpackControls;

	private bool disabledJetpackControlsThisFrame;

	public Transform jetpackTurnCompass;

	private bool startedJetpackControls;

	public float maxJetpackAngle = -1f;

	public float jetpackRandomIntensity;

	public float jetpackCounteractiveForce = -16f;

	private float previousFrameDeltaTime;

	private Collider[] nearByPlayers = (Collider[])(object)new Collider[4];

	private bool teleportingThisFrame;

	public bool teleportedLastFrame;

	[Header("LOCATION")]
	public bool isInElevator;

	public bool isInHangarShipRoom;

	public bool isInsideFactory;

	[Space(5f)]
	public bool parentedToElevatorLastFrame;

	public Vector3 previousElevatorPosition;

	[Header("CONTROL / NETWORKING")]
	public ulong playerClientId;

	public string playerUsername = "Player";

	public ulong playerSteamId;

	public ulong actualClientId;

	public bool isPlayerControlled;

	public bool justConnected = true;

	public bool disconnectedMidGame;

	[Space(5f)]
	private bool isCameraDisabled;

	public StartOfRound playersManager;

	public bool isHostPlayerObject;

	public Vector3 oldPlayerPosition;

	private int previousAnimationState;

	public Vector3 serverPlayerPosition;

	public Transform lastSyncedPhysicsParent;

	public Transform physicsParent;

	public Transform overridePhysicsParent;

	public bool snapToServerPosition;

	private float oldCameraUp;

	public float ladderCameraHorizontal;

	private float updatePlayerAnimationsInterval;

	private float updatePlayerLookInterval;

	private List<int> currentAnimationStateHash = new List<int>();

	private List<int> previousAnimationStateHash = new List<int>();

	private float currentAnimationSpeed;

	private float previousAnimationSpeed;

	private int previousAnimationServer;

	private int oldConnectedPlayersAmount;

	private int playerMask = 8;

	public RawImage playerScreen;

	public VoicePlayerState voicePlayerState;

	public AudioSource currentVoiceChatAudioSource;

	public PlayerVoiceIngameSettings currentVoiceChatIngameSettings;

	private float voiceChatUpdateInterval;

	public bool isTypingChat;

	public bool sentPlayerValues;

	[Header("DEATH")]
	private Vector3 positionOfDeath;

	public int health;

	public float healthRegenerateTimer;

	public bool criticallyInjured;

	public bool hasBeenCriticallyInjured;

	private float limpMultiplier = 0.2f;

	public float timeSinceTakingDamage;

	public float timeSinceFearLevelUp;

	public CauseOfDeath causeOfDeath;

	public bool isPlayerDead;

	[HideInInspector]
	public bool setPositionOfDeadPlayer;

	[HideInInspector]
	public Vector3 placeOfDeath;

	public Transform spectateCameraPivot;

	public Transform overrideGameOverSpectatePivot;

	public PlayerControllerB spectatedPlayerScript;

	public DeadBodyInfo deadBody;

	public GameObject[] bodyBloodDecals;

	private int currentBloodIndex;

	public List<GameObject> playerBloodPooledObjects = new List<GameObject>();

	public bool bleedingHeavily;

	private float bloodDropTimer;

	private bool alternatePlaceFootprints;

	public EnemyAI inAnimationWithEnemy;

	[Header("UI/MENU")]
	public bool inTerminalMenu;

	public QuickMenuManager quickMenuManager;

	public TextMeshProUGUI usernameBillboardText;

	public Transform usernameBillboard;

	public CanvasGroup usernameAlpha;

	public Canvas usernameCanvas;

	[Header("ITEM INTERACTION")]
	public float grabDistance = 5f;

	public float throwPower = 17f;

	public bool isHoldingObject;

	private bool hasThrownObject;

	public bool twoHanded;

	public bool twoHandedAnimation;

	public float carryWeight = 1f;

	public bool isGrabbingObjectAnimation;

	public bool activatingItem;

	private bool waitingToDropItem;

	public float grabObjectAnimationTime;

	public Transform localItemHolder;

	public Transform serverItemHolder;

	public Transform serverItemHolderNonTorsoRelative;

	public Transform propThrowPosition;

	public GrabbableObject currentlyHeldObject;

	private GrabbableObject currentlyGrabbingObject;

	public GrabbableObject currentlyHeldObjectServer;

	public GameObject heldObjectServerCopy;

	private Coroutine grabObjectCoroutine;

	private Ray interactRay;

	private int grabbableObjectsMask = 64;

	private int interactableObjectsMask = 1073742656;

	private int walkableSurfacesNoPlayersMask = 1342179585;

	private RaycastHit hit;

	private float upperBodyAnimationsWeight;

	public float doingUpperBodyEmote;

	private float handsOnWallWeight;

	public Light helmetLight;

	public Light[] allHelmetLights;

	private bool grabbedObjectValidated;

	private bool grabInvalidated;

	private bool throwingObject;

	[Space(5f)]
	public GrabbableObject[] ItemSlots;

	public int currentItemSlot;

	private MeshRenderer[] itemRenderers;

	private float timeSinceSwitchingSlots;

	[HideInInspector]
	public bool grabSetParentServer;

	[Header("TRIGGERS AND SPECIAL")]
	public Image cursorIcon;

	public TextMeshProUGUI cursorTip;

	public Sprite grabItemIcon;

	private bool hoveringOverItem;

	public InteractTrigger hoveringOverTrigger;

	public InteractTrigger previousHoveringOverTrigger;

	public InteractTrigger currentTriggerInAnimationWith;

	public bool isHoldingInteract;

	public bool inSpecialInteractAnimation;

	public bool disableInteract;

	public bool inVehicleAnimation;

	public bool freeRotationInInteractAnimation;

	public bool disableSyncInAnimation;

	public float specialAnimationWeight;

	public bool isClimbingLadder;

	public bool clampLooking;

	public float minVerticalClamp;

	public float maxVerticalClamp;

	public float horizontalClamp;

	public bool enteringSpecialAnimation;

	public float climbSpeed = 4f;

	public Vector3 clampCameraRotation;

	public Transform lineOfSightCube;

	public bool voiceMuffledByEnemy;

	[Header("SPECIAL ITEMS")]
	public bool inSpecialMenu;

	public int shipTeleporterId;

	public EnemyAI redirectToEnemy;

	public MeshRenderer mapRadarDirectionIndicator;

	public Animator mapRadarDotAnimator;

	public int enemiesOnPerson;

	public bool equippedUsableItemQE;

	public bool IsInspectingItem;

	public bool isFirstFrameLateUpdate = true;

	public GrabbableObject pocketedFlashlight;

	public bool isFreeCamera;

	public bool isSpeedCheating;

	public bool inShockingMinigame;

	public Transform shockingTarget;

	public Transform turnCompass;

	public Transform smoothLookTurnCompass;

	public float smoothLookMultiplier = 25f;

	private bool smoothLookEnabledLastFrame;

	public Camera turnCompassCamera;

	[HideInInspector]
	public Vector3 targetScreenPos;

	[HideInInspector]
	public float shockMinigamePullPosition;

	[Space(5f)]
	public bool speakingToWalkieTalkie;

	public bool holdingWalkieTalkie;

	public float isInGameOverAnimation;

	[HideInInspector]
	public bool hasBegunSpectating;

	private Coroutine timeSpecialAnimationCoroutine;

	private float spectatedPlayerDeadTimer;

	public float insanityLevel;

	public float maxInsanityLevel = 50f;

	public float insanitySpeedMultiplier = 1f;

	public bool isPlayerAlone;

	public float timeSincePlayerMoving;

	public Scrollbar terminalScrollVertical;

	private bool updatePositionForNewlyJoinedClient;

	private float timeSinceTakingGravityDamage;

	[Space(5f)]
	public float drunkness;

	public float drunknessInertia = 1f;

	public float drunknessSpeed;

	public bool increasingDrunknessThisFrame;

	public float timeSinceMakingLoudNoise;

	public float slopeIntensity = 2f;

	private float slopeModifier;

	public float slopeModifierSpeed = 1f;

	private Coroutine waitForPhysicsParentCoroutine;

	private Vector3 controllerCollisionPoint;

	ThreatType IVisibleThreat.type => ThreatType.Player;

	bool IVisibleThreat.IsThreatDead()
	{
		if (!isPlayerDead)
		{
			return !isPlayerControlled;
		}
		return true;
	}

	GrabbableObject IVisibleThreat.GetHeldObject()
	{
		return currentlyHeldObjectServer;
	}

	int IVisibleThreat.SendSpecialBehaviour(int id)
	{
		return 0;
	}

	float IVisibleThreat.GetVisibility()
	{
		if (isPlayerDead)
		{
			return 0f;
		}
		float num = 1f;
		if (isCrouching)
		{
			num -= 0.25f;
		}
		if (timeSincePlayerMoving > 0.5f)
		{
			num -= 0.16f;
		}
		return num;
	}

	int IVisibleThreat.GetThreatLevel(Vector3 seenByPosition)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		if (isHoldingObject && (Object)(object)currentlyHeldObjectServer != (Object)null && currentlyHeldObjectServer.itemProperties.isDefensiveWeapon)
		{
			num += 2;
		}
		if (timeSinceMakingLoudNoise < 0.8f)
		{
			num++;
		}
		float num2 = LineOfSightToPositionAngle(seenByPosition);
		if (num2 == -361f || num2 > 100f)
		{
			num--;
		}
		else if (num2 < 45f)
		{
			num++;
		}
		if (TimeOfDay.Instance.normalizedTimeOfDay < 0.2f)
		{
			num++;
		}
		else if (TimeOfDay.Instance.normalizedTimeOfDay > 0.8f)
		{
			num--;
		}
		if (isInHangarShipRoom)
		{
			num++;
		}
		else if (Vector3.Distance(((Component)this).transform.position, StartOfRound.Instance.elevatorTransform.position) > 30f)
		{
			num--;
		}
		int num3 = Physics.OverlapSphereNonAlloc(((Component)this).transform.position, 12f, nearByPlayers, StartOfRound.Instance.playersMask);
		for (int i = 0; i < num3; i++)
		{
			if (!(Vector3.Distance(((Component)this).transform.position, ((Component)nearByPlayers[i]).transform.position) > 6f) || !Physics.Linecast(((Component)gameplayCamera).transform.position, ((Component)nearByPlayers[i]).transform.position + Vector3.up * 0.6f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				num++;
			}
		}
		if (health >= 30)
		{
			num++;
		}
		else if (criticallyInjured)
		{
			num -= 2;
		}
		if (StartOfRound.Instance.connectedPlayersAmount <= 0)
		{
			num++;
		}
		return num;
	}

	Vector3 IVisibleThreat.GetThreatVelocity()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			return Vector3.Normalize(thisController.velocity * 100f);
		}
		if (timeSincePlayerMoving < 0.25f)
		{
			return Vector3.Normalize((serverPlayerPosition - oldPlayerPosition) * 100f);
		}
		return Vector3.zero;
	}

	int IVisibleThreat.GetInterestLevel()
	{
		int num = 0;
		if ((Object)(object)currentlyHeldObjectServer != (Object)null && currentlyHeldObjectServer.itemProperties.isScrap)
		{
			num++;
		}
		if (carryWeight > 1.22f)
		{
			num++;
		}
		if (carryWeight > 1.5f)
		{
			num++;
		}
		return num;
	}

	Transform IVisibleThreat.GetThreatLookTransform()
	{
		return ((Component)gameplayCamera).transform;
	}

	Transform IVisibleThreat.GetThreatTransform()
	{
		return ((Component)this).transform;
	}

	private void Awake()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		isHostPlayerObject = (Object)(object)((Component)this).gameObject == (Object)(object)playersManager.allPlayerObjects[0];
		playerActions = new PlayerActions();
		previousAnimationState = 0;
		serverPlayerPosition = ((Component)this).transform.position;
		((Behaviour)gameplayCamera).enabled = false;
		((Behaviour)visorCamera).enabled = false;
		((Renderer)thisPlayerModel).enabled = true;
		((Renderer)thisPlayerModel).shadowCastingMode = (ShadowCastingMode)1;
		((Renderer)thisPlayerModelArms).enabled = false;
		((Behaviour)gameplayCamera).enabled = false;
		previousAnimationStateHash = new List<int>(new int[playerBodyAnimator.layerCount]);
		currentAnimationStateHash = new List<int>(new int[playerBodyAnimator.layerCount]);
		if ((Object)(object)playerBodyAnimator.runtimeAnimatorController != (Object)(object)playersManager.otherClientsAnimatorController)
		{
			playerBodyAnimator.runtimeAnimatorController = playersManager.otherClientsAnimatorController;
		}
		isCameraDisabled = true;
		sprintMeter = 1f;
		ItemSlots = new GrabbableObject[4];
		rightArmProceduralTargetBasePosition = rightArmProceduralTarget.localPosition;
		playerUsername = $"Player #{playerClientId}";
		previousElevatorPosition = playersManager.elevatorTransform.position;
		if (Object.op_Implicit((Object)(object)((Component)this).gameObject.GetComponent<Rigidbody>()))
		{
			((Component)this).gameObject.GetComponent<Rigidbody>().interpolation = (RigidbodyInterpolation)0;
		}
		((Collider)((Component)this).gameObject.GetComponent<CharacterController>()).enabled = false;
		syncFullRotation = ((Component)this).transform.eulerAngles;
	}

	private void Start()
	{
		InstantiateBloodPooledObjects();
		((MonoBehaviour)this).StartCoroutine(PlayIntroTip());
		jetpackTurnCompass.SetParent((Transform)null);
		Scrollbar obj = terminalScrollVertical;
		obj.value += 500f;
	}

	private IEnumerator PlayIntroTip()
	{
		yield return (object)new WaitForSeconds(4f);
		QuickMenuManager quickMenu = Object.FindObjectOfType<QuickMenuManager>();
		yield return (object)new WaitUntil((Func<bool>)(() => !quickMenu.isMenuOpen));
		HUDManager.Instance.DisplayTip("Welcome!", "Right-click to scan objects in the ship for info.", isWarning: false, useSave: true, "LC_IntroTip1");
	}

	private void InstantiateBloodPooledObjects()
	{
		int num = 50;
		for (int i = 0; i < num; i++)
		{
			GameObject val = Object.Instantiate<GameObject>(playersManager.playerBloodPrefab, playersManager.bloodObjectsContainer);
			val.SetActive(false);
			playerBloodPooledObjects.Add(val);
		}
	}

	public void ResetPlayerBloodObjects(bool resetBodyBlood = true)
	{
		if (playerBloodPooledObjects != null)
		{
			for (int i = 0; i < playerBloodPooledObjects.Count; i++)
			{
				playerBloodPooledObjects[i].SetActive(false);
			}
		}
		if (resetBodyBlood)
		{
			for (int j = 0; j < bodyBloodDecals.Length; j++)
			{
				bodyBloodDecals[j].SetActive(false);
			}
		}
	}

	private void OnEnable()
	{
		InputActionAsset actions = IngamePlayerSettings.Instance.playerInput.actions;
		try
		{
			playerActions.Movement.Look.performed += Look_performed;
			actions.FindAction("Jump", false).performed += Jump_performed;
			actions.FindAction("Crouch", false).performed += Crouch_performed;
			actions.FindAction("Interact", false).performed += Interact_performed;
			actions.FindAction("ItemSecondaryUse", false).performed += ItemSecondaryUse_performed;
			actions.FindAction("ItemTertiaryUse", false).performed += ItemTertiaryUse_performed;
			actions.FindAction("ActivateItem", false).performed += ActivateItem_performed;
			actions.FindAction("ActivateItem", false).canceled += ActivateItem_canceled;
			actions.FindAction("Discard", false).performed += Discard_performed;
			actions.FindAction("SwitchItem", false).performed += ScrollMouse_performed;
			actions.FindAction("OpenMenu", false).performed += OpenMenu_performed;
			actions.FindAction("InspectItem", false).performed += InspectItem_performed;
			actions.FindAction("SpeedCheat", false).performed += SpeedCheat_performed;
			actions.FindAction("Emote1", false).performed += Emote1_performed;
			actions.FindAction("Emote2", false).performed += Emote2_performed;
			playerActions.Movement.Enable();
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while subscribing to input in PlayerController!: {arg}");
		}
		playerActions.Movement.Enable();
	}

	private void OnDisable()
	{
		InputActionAsset actions = IngamePlayerSettings.Instance.playerInput.actions;
		try
		{
			playerActions.Movement.Look.performed -= Look_performed;
			actions.FindAction("Jump", false).performed -= Jump_performed;
			actions.FindAction("Crouch", false).performed -= Crouch_performed;
			actions.FindAction("Interact", false).performed -= Interact_performed;
			actions.FindAction("ItemSecondaryUse", false).performed -= ItemSecondaryUse_performed;
			actions.FindAction("ItemTertiaryUse", false).performed -= ItemTertiaryUse_performed;
			actions.FindAction("ActivateItem", false).performed -= ActivateItem_performed;
			actions.FindAction("ActivateItem", false).canceled -= ActivateItem_canceled;
			actions.FindAction("Discard", false).performed -= Discard_performed;
			actions.FindAction("SwitchItem", false).performed -= ScrollMouse_performed;
			actions.FindAction("OpenMenu", false).performed -= OpenMenu_performed;
			actions.FindAction("InspectItem", false).performed -= InspectItem_performed;
			actions.FindAction("SpeedCheat", false).performed -= SpeedCheat_performed;
			actions.FindAction("Emote1", false).performed -= Emote1_performed;
			actions.FindAction("Emote2", false).performed -= Emote2_performed;
			playerActions.Movement.Enable();
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while unsubscribing from input in PlayerController!: {arg}");
		}
		playerActions.Movement.Disable();
	}

	public override void OnDestroy()
	{
		((NetworkBehaviour)this).OnDestroy();
	}

	private void SpeedCheat_performed(CallbackContext context)
	{
		if (((((NetworkBehaviour)this).IsOwner && (isPlayerControlled || isPlayerDead) && !inTerminalMenu && !isTypingChat && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer) && ((CallbackContext)(ref context)).performed && !((Object)(object)HUDManager.Instance == (Object)null) && IngamePlayerSettings.Instance.playerInput.actions.FindAction("Sprint", false).ReadValue<float>() > 0.5f)
		{
			HUDManager.Instance.ToggleErrorConsole();
		}
	}

	public bool AllowPlayerDeath()
	{
		if (!StartOfRound.Instance.allowLocalPlayerDeath)
		{
			return false;
		}
		if ((Object)(object)playersManager.testRoom == (Object)null)
		{
			if (StartOfRound.Instance.timeSinceRoundStarted < 2f)
			{
				return false;
			}
			if (!playersManager.shipDoorsEnabled)
			{
				return false;
			}
		}
		return true;
	}

	public void DamagePlayer(int damageNumber, bool hasDamageSFX = true, bool callRPC = true, CauseOfDeath causeOfDeath = CauseOfDeath.Unknown, int deathAnimation = 0, bool fallDamage = false, Vector3 force = default(Vector3))
	{
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner || isPlayerDead || !AllowPlayerDeath())
		{
			return;
		}
		if (health - damageNumber <= 0 && !criticallyInjured && damageNumber < 50)
		{
			health = 5;
		}
		else
		{
			health = Mathf.Clamp(health - damageNumber, 0, 100);
		}
		HUDManager.Instance.UpdateHealthUI(health);
		if (health <= 0)
		{
			bool spawnBody = deathAnimation != -1;
			KillPlayer(force, spawnBody, causeOfDeath, deathAnimation);
		}
		else
		{
			if (health < 10 && !criticallyInjured)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
				MakeCriticallyInjured(enable: true);
			}
			else
			{
				if (damageNumber >= 10)
				{
					sprintMeter = Mathf.Clamp(sprintMeter + (float)damageNumber / 125f, 0f, 1f);
				}
				if (callRPC)
				{
					if (((NetworkBehaviour)this).IsServer)
					{
						DamagePlayerClientRpc(damageNumber, health);
					}
					else
					{
						DamagePlayerServerRpc(damageNumber, health);
					}
				}
			}
			if (fallDamage)
			{
				HUDManager.Instance.UIAudio.PlayOneShot(StartOfRound.Instance.fallDamageSFX, 1f);
				WalkieTalkie.TransmitOneShotAudio(movementAudio, StartOfRound.Instance.fallDamageSFX);
				BreakLegsSFXClientRpc();
			}
			else if (hasDamageSFX)
			{
				HUDManager.Instance.UIAudio.PlayOneShot(StartOfRound.Instance.damageSFX, 1f);
			}
		}
		((UnityEvent)StartOfRound.Instance.LocalPlayerDamagedEvent).Invoke();
		takingFallDamage = false;
		if (!inSpecialInteractAnimation && !twoHandedAnimation)
		{
			playerBodyAnimator.SetTrigger("Damage");
		}
		specialAnimationWeight = 1f;
		PlayQuickSpecialAnimation(0.7f);
	}

	[ServerRpc]
	public void BreakLegsSFXServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(800455552u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 800455552u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			BreakLegsSFXClientRpc();
		}
	}

	[ClientRpc]
	public void BreakLegsSFXClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3591743514u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3591743514u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				movementAudio.PlayOneShot(StartOfRound.Instance.fallDamageSFX, 1f);
				WalkieTalkie.TransmitOneShotAudio(movementAudio, StartOfRound.Instance.fallDamageSFX);
			}
		}
	}

	public void MakeCriticallyInjured(bool enable)
	{
		if (enable)
		{
			criticallyInjured = true;
			playerBodyAnimator.SetBool("Limp", true);
			bleedingHeavily = true;
			if (((NetworkBehaviour)this).IsServer)
			{
				MakeCriticallyInjuredClientRpc();
			}
			else
			{
				MakeCriticallyInjuredServerRpc();
			}
		}
		else
		{
			criticallyInjured = false;
			playerBodyAnimator.SetBool("Limp", false);
			bleedingHeavily = false;
			if (((NetworkBehaviour)this).IsServer)
			{
				HealClientRpc();
			}
			else
			{
				HealServerRpc();
			}
		}
	}

	[ServerRpc]
	public void DamagePlayerServerRpc(int damageNumber, int newHealthAmount)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1084949295u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, damageNumber);
			BytePacker.WriteValueBitPacked(val2, newHealthAmount);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1084949295u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DamagePlayerClientRpc(damageNumber, newHealthAmount);
		}
	}

	[ClientRpc]
	public void DamagePlayerClientRpc(int damageNumber, int newHealthAmount)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1822320450u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, damageNumber);
				BytePacker.WriteValueBitPacked(val2, newHealthAmount);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1822320450u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				DamageOnOtherClients(damageNumber, newHealthAmount);
			}
		}
	}

	private void DamageOnOtherClients(int damageNumber, int newHealthAmount)
	{
		playersManager.gameStats.allPlayerStats[playerClientId].damageTaken += damageNumber;
		health = newHealthAmount;
		timeSinceTakingDamage = Time.realtimeSinceStartup;
		if (!((NetworkBehaviour)this).IsOwner)
		{
			PlayQuickSpecialAnimation(0.7f);
		}
	}

	public void PlayQuickSpecialAnimation(float animTime)
	{
		if (quickSpecialAnimationCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(quickSpecialAnimationCoroutine);
		}
		quickSpecialAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(playQuickSpecialAnimation(animTime));
	}

	private IEnumerator playQuickSpecialAnimation(float animTime)
	{
		playingQuickSpecialAnimation = true;
		yield return (object)new WaitForSeconds(animTime);
		playingQuickSpecialAnimation = false;
	}

	[ServerRpc]
	public void StartSinkingServerRpc(float sinkingSpeed, int audioClipIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3986869491u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref sinkingSpeed, default(ForPrimitives));
			BytePacker.WriteValueBitPacked(val2, audioClipIndex);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3986869491u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			StartSinkingClientRpc(sinkingSpeed, audioClipIndex);
		}
	}

	[ClientRpc]
	public void StartSinkingClientRpc(float sinkingSpeed, int audioClipIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1090586009u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref sinkingSpeed, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, audioClipIndex);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1090586009u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				sinkingSpeedMultiplier = sinkingSpeed;
				isSinking = true;
				statusEffectAudio.clip = StartOfRound.Instance.statusEffectClips[audioClipIndex];
				statusEffectAudio.Play();
			}
		}
	}

	[ServerRpc]
	public void StopSinkingServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(341877959u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 341877959u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			StopSinkingClientRpc();
		}
	}

	[ClientRpc]
	public void StopSinkingClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2005250174u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2005250174u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		statusEffectAudio.Stop();
		isSinking = false;
		voiceMuffledByEnemy = false;
		if (!((NetworkBehaviour)this).IsOwner)
		{
			if ((Object)(object)currentVoiceChatIngameSettings == (Object)null)
			{
				StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
			}
			if ((Object)(object)currentVoiceChatIngameSettings != (Object)null)
			{
				((Component)currentVoiceChatIngameSettings.voiceAudio).GetComponent<OccludeAudio>().overridingLowPass = false;
			}
		}
	}

	[ServerRpc]
	public void MakeCriticallyInjuredServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4195705835u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4195705835u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			MakeCriticallyInjuredClientRpc();
		}
	}

	[ClientRpc]
	public void MakeCriticallyInjuredClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3390857164u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3390857164u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				bleedingHeavily = true;
				criticallyInjured = true;
				hasBeenCriticallyInjured = true;
			}
		}
	}

	[ServerRpc]
	public void HealServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2585603452u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2585603452u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			HealClientRpc();
		}
	}

	[ClientRpc]
	public void HealClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2196003333u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2196003333u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				bleedingHeavily = false;
				criticallyInjured = false;
			}
		}
	}

	public void DropBlood(Vector3 direction = default(Vector3), bool leaveBlood = true, bool leaveFootprint = false)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		if (leaveBlood)
		{
			if (bloodDropTimer >= 0f && !isPlayerDead)
			{
				return;
			}
			bloodDropTimer = 0.4f;
			if (direction == Vector3.zero)
			{
				direction = Vector3.down;
			}
			Transform transform = playerBloodPooledObjects[currentBloodIndex].transform;
			transform.rotation = Quaternion.LookRotation(direction, Vector3.up);
			if (isInElevator)
			{
				transform.SetParent(playersManager.elevatorTransform);
			}
			else
			{
				transform.SetParent(playersManager.bloodObjectsContainer);
			}
			if (isPlayerDead)
			{
				if ((Object)(object)deadBody == (Object)null || !((Component)deadBody).gameObject.activeSelf)
				{
					return;
				}
				interactRay = new Ray(((Component)deadBody.bodyParts[3]).transform.position + Vector3.up * 0.5f, direction);
			}
			else
			{
				interactRay = new Ray(((Component)this).transform.position + ((Component)this).transform.up * 2f, direction);
			}
			if (Physics.Raycast(interactRay, ref hit, 6f, playersManager.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				flag = true;
				transform.position = ((RaycastHit)(ref hit)).point - ((Vector3)(ref direction)).normalized * 0.45f;
				RandomizeBloodRotationAndScale(transform);
				((Component)transform).gameObject.SetActive(true);
			}
			currentBloodIndex = (currentBloodIndex + 1) % playerBloodPooledObjects.Count;
		}
		if (!leaveFootprint || isPlayerDead || playersManager.snowFootprintsPooledObjects == null || playersManager.snowFootprintsPooledObjects.Count <= 0)
		{
			return;
		}
		alternatePlaceFootprints = !alternatePlaceFootprints;
		if (alternatePlaceFootprints)
		{
			return;
		}
		Transform transform2 = ((Component)playersManager.snowFootprintsPooledObjects[playersManager.currentFootprintIndex]).transform;
		transform2.rotation = Quaternion.LookRotation(direction, Vector3.up);
		if (!flag)
		{
			interactRay = new Ray(((Component)this).transform.position + ((Component)this).transform.up * 0.3f, direction);
			if (Physics.Raycast(interactRay, ref hit, 6f, playersManager.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				transform2.position = ((RaycastHit)(ref hit)).point - ((Vector3)(ref direction)).normalized * 0.45f;
			}
		}
		else
		{
			transform2.position = ((RaycastHit)(ref hit)).point - ((Vector3)(ref direction)).normalized * 0.45f;
		}
		((Component)transform2).transform.eulerAngles = new Vector3(((Component)transform2).transform.eulerAngles.x, ((Component)this).transform.eulerAngles.y, ((Component)transform2).transform.eulerAngles.z);
		((Behaviour)playersManager.snowFootprintsPooledObjects[playersManager.currentFootprintIndex]).enabled = true;
		playersManager.currentFootprintIndex = (playersManager.currentFootprintIndex + 1) % playersManager.snowFootprintsPooledObjects.Count;
	}

	private void RandomizeBloodRotationAndScale(Transform blood)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		Vector3 localEulerAngles = blood.localEulerAngles;
		localEulerAngles.z = Random.Range(-180f, 180f);
		blood.localEulerAngles = localEulerAngles;
		blood.localScale = new Vector3(Random.Range(0.15f, 0.7f), Random.Range(0.15f, 0.7f), 0.55f);
	}

	private void Emote1_performed(CallbackContext context)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		PerformEmote(context, 1);
	}

	private void Emote2_performed(CallbackContext context)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		PerformEmote(context, 2);
	}

	public void PerformEmote(CallbackContext context, int emoteID)
	{
		if (((CallbackContext)(ref context)).performed && ((((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer) && CheckConditionsForEmote() && !(timeSinceStartingEmote < 0.5f))
		{
			timeSinceStartingEmote = 0f;
			performingEmote = true;
			playerBodyAnimator.SetInteger("emoteNumber", emoteID);
			StartPerformingEmoteServerRpc();
		}
	}

	[ServerRpc]
	public void StartPerformingEmoteServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3803364611u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3803364611u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			StartPerformingEmoteClientRpc();
		}
	}

	[ClientRpc]
	public void StartPerformingEmoteClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1955832627u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1955832627u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				performingEmote = true;
			}
		}
	}

	[ServerRpc]
	public void StopPerformingEmoteServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(878005044u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 878005044u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			StopPerformingEmoteClientRpc();
		}
	}

	[ClientRpc]
	public void StopPerformingEmoteClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(655708081u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 655708081u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				performingEmote = false;
			}
		}
	}

	public bool CheckConditionsForSinkingInQuicksand()
	{
		if (!thisController.isGrounded)
		{
			return false;
		}
		if (inSpecialInteractAnimation || Object.op_Implicit((Object)(object)inAnimationWithEnemy) || isClimbingLadder)
		{
			return false;
		}
		if ((Object)(object)physicsParent != (Object)null)
		{
			return false;
		}
		if (isInHangarShipRoom)
		{
			return false;
		}
		if (isInElevator)
		{
			return false;
		}
		if (currentFootstepSurfaceIndex != 1 && currentFootstepSurfaceIndex != 4 && currentFootstepSurfaceIndex != 8 && currentFootstepSurfaceIndex != 7 && (!isInsideFactory || currentFootstepSurfaceIndex != 5))
		{
			return false;
		}
		return true;
	}

	private bool CheckConditionsForEmote()
	{
		if (inSpecialInteractAnimation)
		{
			return false;
		}
		if (isPlayerDead || isJumping || isWalking)
		{
			return false;
		}
		if (isCrouching || isClimbingLadder)
		{
			return false;
		}
		if (isGrabbingObjectAnimation || inTerminalMenu || isTypingChat)
		{
			return false;
		}
		return true;
	}

	private void ActivateItem_performed(CallbackContext context)
	{
		if (!((CallbackContext)(ref context)).performed || inSpecialMenu)
		{
			return;
		}
		if (((NetworkBehaviour)this).IsOwner && isPlayerDead && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject))
		{
			if (!StartOfRound.Instance.overrideSpectateCamera && (Object)(object)spectatedPlayerScript != (Object)null && !spectatedPlayerScript.isPlayerDead)
			{
				SpectateNextPlayer();
			}
		}
		else if (CanUseItem() && !(timeSinceSwitchingSlots < 0.075f))
		{
			ShipBuildModeManager.Instance.CancelBuildMode();
			((Component)currentlyHeldObjectServer).gameObject.GetComponent<GrabbableObject>().UseItemOnClient();
			timeSinceSwitchingSlots = 0f;
		}
	}

	private void ActivateItem_canceled(CallbackContext context)
	{
		if (CanUseItem() && currentlyHeldObjectServer.itemProperties.holdButtonUse)
		{
			ShipBuildModeManager.Instance.CancelBuildMode();
			((Component)currentlyHeldObjectServer).gameObject.GetComponent<GrabbableObject>().UseItemOnClient(buttonDown: false);
		}
	}

	private bool CanUseItem()
	{
		if ((!((NetworkBehaviour)this).IsOwner || !isPlayerControlled || (((NetworkBehaviour)this).IsServer && !isHostPlayerObject)) && !isTestingPlayer)
		{
			return false;
		}
		if (!isHoldingObject || (Object)(object)currentlyHeldObjectServer == (Object)null)
		{
			return false;
		}
		if (quickMenuManager.isMenuOpen)
		{
			return false;
		}
		if (isPlayerDead)
		{
			return false;
		}
		if (!currentlyHeldObjectServer.itemProperties.usableInSpecialAnimations && (isGrabbingObjectAnimation || inTerminalMenu || isTypingChat || (inSpecialInteractAnimation && !inShockingMinigame)))
		{
			return false;
		}
		return true;
	}

	private int FirstEmptyItemSlot()
	{
		int result = -1;
		if ((Object)(object)ItemSlots[currentItemSlot] == (Object)null)
		{
			result = currentItemSlot;
		}
		else
		{
			for (int i = 0; i < ItemSlots.Length; i++)
			{
				if ((Object)(object)ItemSlots[i] == (Object)null)
				{
					result = i;
					break;
				}
			}
		}
		return result;
	}

	private int NextItemSlot(bool forward)
	{
		if (forward)
		{
			return (currentItemSlot + 1) % ItemSlots.Length;
		}
		if (currentItemSlot == 0)
		{
			return ItemSlots.Length - 1;
		}
		return currentItemSlot - 1;
	}

	private void SwitchToItemSlot(int slot, GrabbableObject fillSlotWithItem = null)
	{
		currentItemSlot = slot;
		if (((NetworkBehaviour)this).IsOwner)
		{
			for (int i = 0; i < HUDManager.Instance.itemSlotIconFrames.Length; i++)
			{
				((Component)HUDManager.Instance.itemSlotIconFrames[i]).GetComponent<Animator>().SetBool("selectedSlot", false);
			}
			((Component)HUDManager.Instance.itemSlotIconFrames[slot]).GetComponent<Animator>().SetBool("selectedSlot", true);
		}
		if ((Object)(object)fillSlotWithItem != (Object)null)
		{
			ItemSlots[slot] = fillSlotWithItem;
			if (((NetworkBehaviour)this).IsOwner)
			{
				HUDManager.Instance.itemSlotIcons[slot].sprite = fillSlotWithItem.itemProperties.itemIcon;
				((Behaviour)HUDManager.Instance.itemSlotIcons[currentItemSlot]).enabled = true;
			}
		}
		if ((Object)(object)currentlyHeldObjectServer != (Object)null)
		{
			currentlyHeldObjectServer.playerHeldBy = this;
			if (((NetworkBehaviour)this).IsOwner)
			{
				SetSpecialGrabAnimationBool(setTrue: false, currentlyHeldObjectServer);
			}
			currentlyHeldObjectServer.PocketItem();
			if ((Object)(object)ItemSlots[slot] != (Object)null && !string.IsNullOrEmpty(ItemSlots[slot].itemProperties.pocketAnim))
			{
				playerBodyAnimator.SetTrigger(ItemSlots[slot].itemProperties.pocketAnim);
			}
		}
		if ((Object)(object)ItemSlots[slot] != (Object)null)
		{
			ItemSlots[slot].playerHeldBy = this;
			ItemSlots[slot].EquipItem();
			if (((NetworkBehaviour)this).IsOwner)
			{
				SetSpecialGrabAnimationBool(setTrue: true, ItemSlots[slot]);
			}
			if ((Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				if (ItemSlots[slot].itemProperties.twoHandedAnimation || currentlyHeldObjectServer.itemProperties.twoHandedAnimation)
				{
					playerBodyAnimator.ResetTrigger("SwitchHoldAnimationTwoHanded");
					playerBodyAnimator.SetTrigger("SwitchHoldAnimationTwoHanded");
				}
				playerBodyAnimator.ResetTrigger("SwitchHoldAnimation");
				playerBodyAnimator.SetTrigger("SwitchHoldAnimation");
			}
			twoHandedAnimation = ItemSlots[slot].itemProperties.twoHandedAnimation;
			twoHanded = ItemSlots[slot].itemProperties.twoHanded;
			playerBodyAnimator.SetBool("GrabValidated", true);
			playerBodyAnimator.SetBool("cancelHolding", false);
			isHoldingObject = true;
			currentlyHeldObjectServer = ItemSlots[slot];
		}
		else
		{
			if (!((NetworkBehaviour)this).IsOwner && (Object)(object)heldObjectServerCopy != (Object)null)
			{
				heldObjectServerCopy.SetActive(false);
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
				HUDManager.Instance.ClearControlTips();
			}
			currentlyHeldObjectServer = null;
			currentlyHeldObject = null;
			isHoldingObject = false;
			twoHanded = false;
			playerBodyAnimator.SetBool("cancelHolding", true);
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (twoHanded)
			{
				HUDManager.Instance.PingHUDElement(HUDManager.Instance.Inventory, 0.1f, 0.13f, 0.13f);
				((Behaviour)HUDManager.Instance.holdingTwoHandedItem).enabled = true;
			}
			else
			{
				HUDManager.Instance.PingHUDElement(HUDManager.Instance.Inventory, 1.5f, 1f, 0.13f);
				((Behaviour)HUDManager.Instance.holdingTwoHandedItem).enabled = false;
			}
		}
	}

	private void ScrollMouse_performed(CallbackContext context)
	{
		if (inTerminalMenu)
		{
			float num = ((CallbackContext)(ref context)).ReadValue<float>();
			Scrollbar obj = terminalScrollVertical;
			obj.value += num / 3f;
		}
		else if (((((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer) && !(timeSinceSwitchingSlots < 0.3f) && !isGrabbingObjectAnimation && !quickMenuManager.isMenuOpen && !inSpecialInteractAnimation && !throwingObject && !isTypingChat && !twoHanded && !activatingItem && !jetpackControls && !disablingJetpackControls)
		{
			ShipBuildModeManager.Instance.CancelBuildMode();
			playerBodyAnimator.SetBool("GrabValidated", false);
			if (((CallbackContext)(ref context)).ReadValue<float>() > 0f)
			{
				SwitchToItemSlot(NextItemSlot(forward: true));
				SwitchItemSlotsServerRpc(forward: true);
			}
			else
			{
				SwitchToItemSlot(NextItemSlot(forward: false));
				SwitchItemSlotsServerRpc(forward: false);
			}
			if ((Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				((Component)currentlyHeldObjectServer).gameObject.GetComponent<AudioSource>().PlayOneShot(currentlyHeldObjectServer.itemProperties.grabSFX, 0.6f);
			}
			timeSinceSwitchingSlots = 0f;
		}
	}

	[ServerRpc]
	private void SwitchItemSlotsServerRpc(bool forward)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(412259855u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref forward, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 412259855u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SwitchItemSlotsClientRpc(forward);
		}
	}

	[ClientRpc]
	private void SwitchItemSlotsClientRpc(bool forward)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(141629807u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref forward, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 141629807u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
		{
			SwitchToItemSlot(NextItemSlot(forward));
			if ((Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				((Component)currentlyHeldObjectServer).gameObject.GetComponent<AudioSource>().PlayOneShot(currentlyHeldObjectServer.itemProperties.grabSFX, 0.6f);
			}
		}
	}

	private bool InteractTriggerUseConditionsMet()
	{
		if (sinkingValue > 0.73f)
		{
			return false;
		}
		if (jetpackControls && (hoveringOverTrigger.specialCharacterAnimation || hoveringOverTrigger.isLadder))
		{
			return false;
		}
		if (isClimbingLadder)
		{
			if (hoveringOverTrigger.isLadder)
			{
				if (!hoveringOverTrigger.usingLadder)
				{
					return false;
				}
			}
			else if (hoveringOverTrigger.specialCharacterAnimation)
			{
				return false;
			}
		}
		else if (inSpecialInteractAnimation && !hoveringOverTrigger.allowUseWhileInAnimation)
		{
			return false;
		}
		if (disableInteract)
		{
			return false;
		}
		if (hoveringOverTrigger.isPlayingSpecialAnimation)
		{
			return false;
		}
		return true;
	}

	private void InspectItem_performed(CallbackContext context)
	{
		if (!ShipBuildModeManager.Instance.InBuildMode && ((CallbackContext)(ref context)).performed && ((((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer) && !isGrabbingObjectAnimation && !isTypingChat && !inSpecialInteractAnimation && !throwingObject && !activatingItem)
		{
			ShipBuildModeManager.Instance.CancelBuildMode();
			if ((Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				currentlyHeldObjectServer.InspectItem();
			}
		}
	}

	private void QEItemInteract_performed(CallbackContext context)
	{
		if (!equippedUsableItemQE || ((!((NetworkBehaviour)this).IsOwner || !isPlayerControlled || (((NetworkBehaviour)this).IsServer && !isHostPlayerObject)) && !isTestingPlayer) || !((CallbackContext)(ref context)).performed || isGrabbingObjectAnimation || isTypingChat || inTerminalMenu || inSpecialInteractAnimation || throwingObject || timeSinceSwitchingSlots < 0.2f)
		{
			return;
		}
		float num = ((CallbackContext)(ref context)).ReadValue<float>();
		if ((Object)(object)currentlyHeldObjectServer != (Object)null)
		{
			timeSinceSwitchingSlots = 0f;
			if (num < 0f)
			{
				currentlyHeldObjectServer.ItemInteractLeftRightOnClient(right: false);
			}
			else
			{
				currentlyHeldObjectServer.ItemInteractLeftRightOnClient(right: true);
			}
		}
	}

	private void ItemSecondaryUse_performed(CallbackContext context)
	{
		Debug.Log((object)"secondary use A");
		if (!equippedUsableItemQE)
		{
			return;
		}
		Debug.Log((object)"secondary use B");
		if ((!((NetworkBehaviour)this).IsOwner || !isPlayerControlled || (((NetworkBehaviour)this).IsServer && !isHostPlayerObject)) && !isTestingPlayer)
		{
			return;
		}
		Debug.Log((object)"secondary use C");
		if (!((CallbackContext)(ref context)).performed)
		{
			return;
		}
		Debug.Log((object)"secondary use D");
		if (isGrabbingObjectAnimation || isTypingChat || inTerminalMenu || inSpecialInteractAnimation || throwingObject)
		{
			return;
		}
		Debug.Log((object)"secondary use E");
		if (!(timeSinceSwitchingSlots < 0.2f))
		{
			Debug.Log((object)"secondary use F");
			if ((Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				Debug.Log((object)"secondary use G");
				timeSinceSwitchingSlots = 0f;
				currentlyHeldObjectServer.ItemInteractLeftRightOnClient(right: false);
			}
		}
	}

	private void ItemTertiaryUse_performed(CallbackContext context)
	{
		if (equippedUsableItemQE && ((((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer) && ((CallbackContext)(ref context)).performed && !isGrabbingObjectAnimation && !isTypingChat && !inTerminalMenu && !inSpecialInteractAnimation && !throwingObject && !(timeSinceSwitchingSlots < 0.2f) && (Object)(object)currentlyHeldObjectServer != (Object)null)
		{
			timeSinceSwitchingSlots = 0f;
			currentlyHeldObjectServer.ItemInteractLeftRightOnClient(right: true);
		}
	}

	private void Interact_performed(CallbackContext context)
	{
		if (((NetworkBehaviour)this).IsOwner && isPlayerDead && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject))
		{
			if (!StartOfRound.Instance.overrideSpectateCamera && (Object)(object)spectatedPlayerScript != (Object)null && !spectatedPlayerScript.isPlayerDead)
			{
				SpectateNextPlayer();
			}
		}
		else
		{
			if (((!((NetworkBehaviour)this).IsOwner || !isPlayerControlled || (((NetworkBehaviour)this).IsServer && !isHostPlayerObject)) && !isTestingPlayer) || !((CallbackContext)(ref context)).performed || timeSinceSwitchingSlots < 0.2f || inSpecialMenu)
			{
				return;
			}
			ShipBuildModeManager.Instance.CancelBuildMode();
			if (!isGrabbingObjectAnimation && !isTypingChat && !inTerminalMenu && !throwingObject && !IsInspectingItem && !((Object)(object)inAnimationWithEnemy != (Object)null) && !jetpackControls && !disablingJetpackControls && !StartOfRound.Instance.suckingPlayersOutOfShip)
			{
				if (!activatingItem && !waitingToDropItem)
				{
					BeginGrabObject();
				}
				if (!((Object)(object)hoveringOverTrigger == (Object)null) && !hoveringOverTrigger.holdInteraction && (!isHoldingObject || hoveringOverTrigger.oneHandedItemAllowed) && (!twoHanded || (hoveringOverTrigger.twoHandedItemAllowed && !hoveringOverTrigger.specialCharacterAnimation)) && InteractTriggerUseConditionsMet())
				{
					hoveringOverTrigger.Interact(thisPlayerBody);
				}
			}
		}
	}

	private void BeginGrabObject()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		interactRay = new Ray(((Component)gameplayCamera).transform.position, ((Component)gameplayCamera).transform.forward);
		if (!Physics.Raycast(interactRay, ref hit, grabDistance, interactableObjectsMask) || ((Component)((RaycastHit)(ref hit)).collider).gameObject.layer == 8 || !(((Component)((RaycastHit)(ref hit)).collider).tag == "PhysicsProp") || twoHanded || sinkingValue > 0.73f || Physics.Linecast(((Component)gameplayCamera).transform.position, ((Component)((RaycastHit)(ref hit)).collider).transform.position + ((Component)this).transform.up * 0.16f, 1073741824, (QueryTriggerInteraction)1))
		{
			return;
		}
		currentlyGrabbingObject = ((Component)((Component)((RaycastHit)(ref hit)).collider).transform).gameObject.GetComponent<GrabbableObject>();
		if (!GameNetworkManager.Instance.gameHasStarted && !currentlyGrabbingObject.itemProperties.canBeGrabbedBeforeGameStart && (Object)(object)StartOfRound.Instance.testRoom == (Object)null)
		{
			return;
		}
		grabInvalidated = false;
		if ((Object)(object)currentlyGrabbingObject == (Object)null || inSpecialInteractAnimation || currentlyGrabbingObject.isHeld || currentlyGrabbingObject.isPocketed)
		{
			return;
		}
		NetworkObject networkObject = ((NetworkBehaviour)currentlyGrabbingObject).NetworkObject;
		if ((Object)(object)networkObject == (Object)null || !networkObject.IsSpawned)
		{
			return;
		}
		currentlyGrabbingObject.InteractItem();
		if (currentlyGrabbingObject.grabbable && FirstEmptyItemSlot() != -1)
		{
			playerBodyAnimator.SetBool("GrabInvalidated", false);
			playerBodyAnimator.SetBool("GrabValidated", false);
			playerBodyAnimator.SetBool("cancelHolding", false);
			playerBodyAnimator.ResetTrigger("Throw");
			SetSpecialGrabAnimationBool(setTrue: true);
			isGrabbingObjectAnimation = true;
			((Behaviour)cursorIcon).enabled = false;
			((TMP_Text)cursorTip).text = "";
			twoHanded = currentlyGrabbingObject.itemProperties.twoHanded;
			carryWeight = Mathf.Clamp(carryWeight + (currentlyGrabbingObject.itemProperties.weight - 1f), 1f, 10f);
			if (currentlyGrabbingObject.itemProperties.grabAnimationTime > 0f)
			{
				grabObjectAnimationTime = currentlyGrabbingObject.itemProperties.grabAnimationTime;
			}
			else
			{
				grabObjectAnimationTime = 0.4f;
			}
			if (!isTestingPlayer)
			{
				GrabObjectServerRpc(NetworkObjectReference.op_Implicit(networkObject));
			}
			if (grabObjectCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(grabObjectCoroutine);
			}
			grabObjectCoroutine = ((MonoBehaviour)this).StartCoroutine(GrabObject());
		}
	}

	private IEnumerator GrabObject()
	{
		grabbedObjectValidated = false;
		yield return (object)new WaitForSeconds(0.1f);
		currentlyGrabbingObject.parentObject = localItemHolder;
		if ((Object)(object)currentlyGrabbingObject.itemProperties.grabSFX != (Object)null)
		{
			itemAudio.PlayOneShot(currentlyGrabbingObject.itemProperties.grabSFX, 1f);
		}
		while (((Object)(object)currentlyGrabbingObject != (Object)(object)currentlyHeldObjectServer || !currentlyHeldObjectServer.wasOwnerLastFrame) && !grabInvalidated)
		{
			Debug.Log((object)$"grabInvalidated: {grabInvalidated}");
			yield return null;
		}
		if (grabInvalidated)
		{
			grabInvalidated = false;
			Debug.Log((object)("Grab was invalidated on object: " + ((Object)currentlyGrabbingObject).name));
			if ((Object)(object)currentlyGrabbingObject.playerHeldBy != (Object)null)
			{
				Debug.Log((object)$"playerHeldBy on currentlyGrabbingObject 2: {currentlyGrabbingObject.playerHeldBy}");
			}
			if ((Object)(object)currentlyGrabbingObject.parentObject == (Object)(object)localItemHolder)
			{
				if ((Object)(object)currentlyGrabbingObject.playerHeldBy != (Object)null)
				{
					Debug.Log((object)$"Grab invalidated; giving grabbed object to the client who got it first; {currentlyGrabbingObject.playerHeldBy}");
					currentlyGrabbingObject.parentObject = currentlyGrabbingObject.playerHeldBy.serverItemHolder;
				}
				else
				{
					Debug.Log((object)"Grab invalidated; no other client has possession of it, so set its parent object to null.");
					currentlyGrabbingObject.parentObject = null;
				}
			}
			twoHanded = false;
			SetSpecialGrabAnimationBool(setTrue: false);
			if ((Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				playerBodyAnimator.SetBool("Grab", true);
			}
			playerBodyAnimator.SetBool("GrabInvalidated", true);
			carryWeight = Mathf.Clamp(carryWeight - (currentlyGrabbingObject.itemProperties.weight - 1f), 1f, 10f);
			isGrabbingObjectAnimation = false;
			currentlyGrabbingObject = null;
		}
		else
		{
			grabbedObjectValidated = true;
			currentlyHeldObjectServer.GrabItemOnClient();
			isHoldingObject = true;
			yield return (object)new WaitForSeconds(grabObjectAnimationTime - 0.2f);
			playerBodyAnimator.SetBool("GrabValidated", true);
			isGrabbingObjectAnimation = false;
		}
	}

	private void SetSpecialGrabAnimationBool(bool setTrue, GrabbableObject currentItem = null)
	{
		if ((Object)(object)currentItem == (Object)null)
		{
			currentItem = currentlyGrabbingObject;
		}
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		playerBodyAnimator.SetBool("Grab", setTrue);
		if (string.IsNullOrEmpty(currentItem.itemProperties.grabAnim))
		{
			return;
		}
		try
		{
			playerBodyAnimator.SetBool(currentItem.itemProperties.grabAnim, setTrue);
		}
		catch (Exception)
		{
			Debug.LogError((object)("An item tried to set an animator bool which does not exist: " + currentItem.itemProperties.grabAnim));
		}
	}

	[ServerRpc]
	private void GrabObjectServerRpc(NetworkObjectReference grabbedObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1554282707u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1554282707u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		bool flag = true;
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref grabbedObject)).TryGet(ref val3, (NetworkManager)null) && Object.op_Implicit((Object)(object)((Component)val3).GetComponentInChildren<GrabbableObject>()))
		{
			if (((Component)val3).GetComponentInChildren<GrabbableObject>().heldByPlayerOnServer)
			{
				flag = false;
				Debug.Log((object)("Invalidated grab on " + ((Object)((Component)this).gameObject).name + " on client; another player was already grabbing the same object"));
			}
		}
		else
		{
			flag = false;
		}
		if (flag)
		{
			((Component)val3).GetComponentInChildren<GrabbableObject>().heldByPlayerOnServer = true;
			val3.ChangeOwnership(actualClientId);
			GrabObjectClientRpc(grabValidated: true, NetworkObjectReference.op_Implicit(val3));
		}
		else
		{
			GrabObjectClientRpc(flag, grabbedObject);
		}
	}

	[ClientRpc]
	private void GrabObjectClientRpc(bool grabValidated, NetworkObjectReference grabbedObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2552479808u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref grabValidated, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2552479808u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		if (grabValidated)
		{
			NetworkObject val3 = default(NetworkObject);
			if (!((NetworkObjectReference)(ref grabbedObject)).TryGet(ref val3, (NetworkManager)null))
			{
				Debug.Log((object)$"Error! Networkobject grabbed was not found on client: {val3.NetworkObjectId}");
				return;
			}
			SwitchToItemSlot(FirstEmptyItemSlot(), ((Component)val3).gameObject.GetComponentInChildren<GrabbableObject>());
			currentlyHeldObjectServer.EnablePhysics(enable: false);
			currentlyHeldObjectServer.isHeld = true;
			currentlyHeldObjectServer.hasHitGround = false;
			currentlyHeldObjectServer.isInFactory = isInsideFactory;
			SetItemInElevator(isInHangarShipRoom, isInElevator, currentlyHeldObjectServer);
			if ((Object)(object)((Component)currentlyHeldObjectServer).transform.parent != (Object)(object)playersManager.propsContainer && (Object)(object)((Component)currentlyHeldObjectServer).transform.parent != (Object)(object)StartOfRound.Instance.elevatorTransform)
			{
				Debug.Log((object)("Picked up scrap " + currentlyHeldObjectServer.itemProperties.itemName + " was not in the normal places; reparenting it now"));
				if (currentlyHeldObjectServer.isInElevator)
				{
					Debug.Log((object)("Picked up scrap " + currentlyHeldObjectServer.itemProperties.itemName + " is in the elevator; parenting it to elevator"));
					((Component)currentlyHeldObjectServer).transform.SetParent(StartOfRound.Instance.elevatorTransform, true);
				}
				else
				{
					Debug.Log((object)("Picked up scrap " + currentlyHeldObjectServer.itemProperties.itemName + " is not in the elevator; parenting it to spawnedScrapContainer"));
					((Component)currentlyHeldObjectServer).transform.SetParent(playersManager.propsContainer, true);
				}
			}
			twoHanded = currentlyHeldObjectServer.itemProperties.twoHanded;
			twoHandedAnimation = currentlyHeldObjectServer.itemProperties.twoHandedAnimation;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				currentlyHeldObjectServer.parentObject = serverItemHolder;
				isHoldingObject = true;
				carryWeight = Mathf.Clamp(carryWeight + (currentlyHeldObjectServer.itemProperties.weight - 1f), 1f, 10f);
				if ((Object)(object)currentlyHeldObjectServer.itemProperties.grabSFX != (Object)null)
				{
					itemAudio.PlayOneShot(currentlyHeldObjectServer.itemProperties.grabSFX, 1f);
				}
				if ((Object)(object)currentlyHeldObjectServer.playerHeldBy != (Object)null)
				{
					Debug.Log((object)$"playerHeldBy on grabbed object: {currentlyHeldObjectServer.playerHeldBy}");
				}
				else
				{
					Debug.Log((object)"grabbed object playerHeldBy is null");
				}
			}
		}
		else
		{
			Debug.Log((object)$"Player #{playerClientId}: Was grabbing object {((NetworkObjectReference)(ref grabbedObject)).NetworkObjectId} validated by server? : {grabValidated}");
			if (((NetworkBehaviour)this).IsOwner)
			{
				Debug.Log((object)"Local client got grab invalidated");
				grabInvalidated = true;
			}
		}
	}

	private void Discard_performed(CallbackContext context)
	{
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner || !isPlayerControlled || (((NetworkBehaviour)this).IsServer && !isHostPlayerObject) || !((CallbackContext)(ref context)).performed)
		{
			return;
		}
		if (StartOfRound.Instance.localPlayerUsingController && ShipBuildModeManager.Instance.InBuildMode)
		{
			ShipBuildModeManager.Instance.StoreObjectLocalClient();
		}
		else
		{
			if (timeSinceSwitchingSlots < 0.2f || isGrabbingObjectAnimation || timeSinceSwitchingSlots < 0.2f || isTypingChat || inSpecialInteractAnimation || activatingItem)
			{
				return;
			}
			ShipBuildModeManager.Instance.CancelBuildMode();
			if (throwingObject || !isHoldingObject || !((Object)(object)currentlyHeldObjectServer != (Object)null))
			{
				return;
			}
			if ((Object)(object)Object.FindObjectOfType<DepositItemsDesk>() != (Object)null && (Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				DepositItemsDesk depositItemsDesk = Object.FindObjectOfType<DepositItemsDesk>();
				Bounds bounds = ((Collider)Object.FindObjectOfType<DepositItemsDesk>().triggerCollider).bounds;
				if (((Bounds)(ref bounds)).Contains(((Component)currentlyHeldObjectServer).transform.position))
				{
					depositItemsDesk.PlaceItemOnCounter(this);
					return;
				}
			}
			((MonoBehaviour)this).StartCoroutine(waitToEndOfFrameToDiscard());
		}
	}

	private IEnumerator waitToEndOfFrameToDiscard()
	{
		yield return (object)new WaitForEndOfFrame();
		DiscardHeldObject();
	}

	public void DespawnHeldObject()
	{
		if ((Object)(object)currentlyHeldObjectServer != (Object)null)
		{
			SetSpecialGrabAnimationBool(setTrue: false, currentlyHeldObjectServer);
			playerBodyAnimator.SetBool("cancelHolding", true);
			playerBodyAnimator.SetTrigger("Throw");
			if (((NetworkBehaviour)this).IsOwner)
			{
				((Behaviour)HUDManager.Instance.itemSlotIcons[currentItemSlot]).enabled = false;
				((Behaviour)HUDManager.Instance.holdingTwoHandedItem).enabled = false;
			}
			throwingObject = true;
			DespawnHeldObjectOnClient();
			DespawnHeldObjectServerRpc();
		}
	}

	private void DespawnHeldObjectOnClient()
	{
		ItemSlots[currentItemSlot] = null;
		twoHanded = false;
		twoHandedAnimation = false;
		carryWeight = Mathf.Clamp(carryWeight - (currentlyHeldObjectServer.itemProperties.weight - 1f), 1f, 10f);
		isHoldingObject = false;
		hasThrownObject = true;
	}

	[ServerRpc]
	private void DespawnHeldObjectServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1786952262u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1786952262u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if ((Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				((Component)currentlyHeldObjectServer).gameObject.GetComponent<NetworkObject>().Despawn(true);
			}
			DespawnHeldObjectClientRpc();
		}
	}

	[ClientRpc]
	private void DespawnHeldObjectClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2217326231u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2217326231u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (!((NetworkBehaviour)this).IsOwner)
			{
				DespawnHeldObjectOnClient();
			}
			else
			{
				throwingObject = false;
			}
		}
	}

	public void DiscardHeldObject(bool placeObject = false, NetworkObject parentObjectTo = null, Vector3 placePosition = default(Vector3), bool matchRotationOfParent = true)
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		SetSpecialGrabAnimationBool(setTrue: false, currentlyHeldObjectServer);
		playerBodyAnimator.SetBool("cancelHolding", true);
		playerBodyAnimator.SetTrigger("Throw");
		((Behaviour)HUDManager.Instance.itemSlotIcons[currentItemSlot]).enabled = false;
		((Behaviour)HUDManager.Instance.holdingTwoHandedItem).enabled = false;
		if (!placeObject)
		{
			Vector3 hitPoint;
			NetworkObject physicsRegionOfDroppedObject = currentlyHeldObjectServer.GetPhysicsRegionOfDroppedObject(this, out hitPoint);
			if ((Object)(object)physicsRegionOfDroppedObject != (Object)null)
			{
				placePosition = hitPoint;
				parentObjectTo = physicsRegionOfDroppedObject;
				placeObject = true;
				matchRotationOfParent = false;
			}
		}
		if (placeObject)
		{
			if ((Object)(object)parentObjectTo == (Object)null)
			{
				throwingObject = true;
				placePosition = ((!isInElevator) ? StartOfRound.Instance.propsContainer.InverseTransformPoint(placePosition) : StartOfRound.Instance.elevatorTransform.InverseTransformPoint(placePosition));
				int floorYRot = (int)((Component)this).transform.localEulerAngles.y;
				SetObjectAsNoLongerHeld(isInElevator, isInHangarShipRoom, placePosition, currentlyHeldObjectServer, floorYRot);
				currentlyHeldObjectServer.DiscardItemOnClient();
				ThrowObjectServerRpc(NetworkObjectReference.op_Implicit(((Component)currentlyHeldObjectServer).gameObject.GetComponent<NetworkObject>()), isInElevator, isInHangarShipRoom, placePosition, floorYRot);
			}
			else
			{
				PlaceGrabbableObject(((Component)parentObjectTo).transform, placePosition, matchRotationOfParent, currentlyHeldObjectServer);
				currentlyHeldObjectServer.DiscardItemOnClient();
				PlaceObjectServerRpc(NetworkObjectReference.op_Implicit(((Component)currentlyHeldObjectServer).gameObject.GetComponent<NetworkObject>()), NetworkObjectReference.op_Implicit(parentObjectTo), placePosition, matchRotationOfParent);
			}
			return;
		}
		throwingObject = true;
		bool droppedInElevator = isInElevator;
		Bounds bounds;
		Vector3 targetFloorPosition;
		if (!isInElevator)
		{
			Vector3 val = ((!currentlyHeldObjectServer.itemProperties.allowDroppingAheadOfPlayer) ? currentlyHeldObjectServer.GetItemFloorPosition() : DropItemAheadOfPlayer());
			bounds = playersManager.shipBounds.bounds;
			if (!((Bounds)(ref bounds)).Contains(val))
			{
				targetFloorPosition = playersManager.propsContainer.InverseTransformPoint(val);
			}
			else
			{
				droppedInElevator = true;
				targetFloorPosition = playersManager.elevatorTransform.InverseTransformPoint(val);
			}
		}
		else
		{
			Vector3 val = currentlyHeldObjectServer.GetItemFloorPosition();
			bounds = playersManager.shipBounds.bounds;
			if (!((Bounds)(ref bounds)).Contains(val))
			{
				droppedInElevator = false;
				targetFloorPosition = playersManager.propsContainer.InverseTransformPoint(val);
			}
			else
			{
				targetFloorPosition = playersManager.elevatorTransform.InverseTransformPoint(val);
			}
		}
		int floorYRot2 = (int)((Component)this).transform.localEulerAngles.y;
		SetObjectAsNoLongerHeld(droppedInElevator, isInHangarShipRoom, targetFloorPosition, currentlyHeldObjectServer, floorYRot2);
		currentlyHeldObjectServer.DiscardItemOnClient();
		ThrowObjectServerRpc(NetworkObjectReference.op_Implicit(((NetworkBehaviour)currentlyHeldObjectServer).NetworkObject), droppedInElevator, isInHangarShipRoom, targetFloorPosition, floorYRot2);
	}

	private Vector3 DropItemAheadOfPlayer()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		Vector3 zero = Vector3.zero;
		Ray val = default(Ray);
		((Ray)(ref val))._002Ector(((Component)this).transform.position + Vector3.up * 0.4f, ((Component)gameplayCamera).transform.forward);
		zero = ((!Physics.Raycast(val, ref hit, 1.7f, 268438273, (QueryTriggerInteraction)1)) ? ((Ray)(ref val)).GetPoint(1.7f) : ((Ray)(ref val)).GetPoint(Mathf.Clamp(((RaycastHit)(ref hit)).distance - 0.3f, 0.01f, 2f)));
		Vector3 itemFloorPosition = currentlyHeldObjectServer.GetItemFloorPosition(zero);
		if (itemFloorPosition == zero)
		{
			itemFloorPosition = currentlyHeldObjectServer.GetItemFloorPosition();
		}
		return itemFloorPosition;
	}

	[ServerRpc]
	private void ThrowObjectServerRpc(NetworkObjectReference grabbedObject, bool droppedInElevator, bool droppedInShipRoom, Vector3 targetFloorPosition, int floorYRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2376977494u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref droppedInElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref droppedInShipRoom, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetFloorPosition);
			BytePacker.WriteValueBitPacked(val2, floorYRot);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2376977494u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			NetworkObject val3 = default(NetworkObject);
			if (((NetworkObjectReference)(ref grabbedObject)).TryGet(ref val3, (NetworkManager)null))
			{
				ThrowObjectClientRpc(droppedInElevator, droppedInShipRoom, targetFloorPosition, grabbedObject, floorYRot);
			}
			else
			{
				Debug.LogError((object)"Object was not thrown because it does not exist on the server.");
			}
		}
	}

	[ClientRpc]
	private void ThrowObjectClientRpc(bool droppedInElevator, bool droppedInShipRoom, Vector3 targetFloorPosition, NetworkObjectReference grabbedObject, int floorYRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3943098567u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref droppedInElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref droppedInShipRoom, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetFloorPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, floorYRot);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3943098567u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref grabbedObject)).TryGet(ref val3, (NetworkManager)null))
		{
			GrabbableObject component = ((Component)val3).GetComponent<GrabbableObject>();
			if (!((NetworkBehaviour)this).IsOwner)
			{
				SetObjectAsNoLongerHeld(droppedInElevator, droppedInShipRoom, targetFloorPosition, component);
			}
			if (!component.itemProperties.syncDiscardFunction)
			{
				component.playerHeldBy = null;
			}
			if ((Object)(object)component == (Object)(object)currentlyHeldObjectServer)
			{
				currentlyHeldObjectServer = null;
			}
			else
			{
				string arg = "null";
				if ((Object)(object)currentlyHeldObjectServer != (Object)null)
				{
					arg = ((Object)((Component)currentlyHeldObjectServer).gameObject).name;
				}
				Debug.LogError((object)$"ThrowObjectClientRpc called for an object which is not the same as currentlyHeldObjectServer which is {arg}, on player #{playerClientId}.");
			}
		}
		else
		{
			Debug.LogError((object)"The server did not have a reference to the held object (when attempting to THROW on client.)");
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			throwingObject = false;
		}
	}

	public void SetObjectAsNoLongerHeld(bool droppedInElevator, bool droppedInShipRoom, Vector3 targetFloorPosition, GrabbableObject dropObject, int floorYRot = -1)
	{
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < ItemSlots.Length; i++)
		{
			if ((Object)(object)ItemSlots[i] == (Object)(object)dropObject)
			{
				ItemSlots[i] = null;
			}
		}
		dropObject.heldByPlayerOnServer = false;
		dropObject.parentObject = null;
		if (droppedInElevator)
		{
			((Component)dropObject).transform.SetParent(playersManager.elevatorTransform, true);
		}
		else
		{
			((Component)dropObject).transform.SetParent(playersManager.propsContainer, true);
		}
		SetItemInElevator(droppedInShipRoom, droppedInElevator, dropObject);
		dropObject.EnablePhysics(enable: true);
		dropObject.EnableItemMeshes(enable: true);
		((Component)dropObject).transform.localScale = dropObject.originalScale;
		dropObject.isHeld = false;
		dropObject.isPocketed = false;
		dropObject.fallTime = 0f;
		dropObject.startFallingPosition = ((Component)dropObject).transform.parent.InverseTransformPoint(((Component)dropObject).transform.position);
		dropObject.targetFloorPosition = targetFloorPosition;
		dropObject.floorYRot = floorYRot;
		twoHanded = false;
		twoHandedAnimation = false;
		carryWeight = Mathf.Clamp(carryWeight - (dropObject.itemProperties.weight - 1f), 1f, 10f);
		isHoldingObject = false;
		hasThrownObject = true;
	}

	public void SetAllItemsInElevator(bool inShipRoom, bool inElevator)
	{
		for (int i = 0; i < ItemSlots.Length; i++)
		{
			if ((Object)(object)ItemSlots[i] != (Object)null)
			{
				SetItemInElevator(inShipRoom, inElevator, ItemSlots[i]);
			}
		}
	}

	public void SetItemInElevator(bool droppedInShipRoom, bool droppedInElevator, GrabbableObject gObject)
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		gObject.isInElevator = droppedInElevator;
		if (gObject.isInShipRoom == droppedInShipRoom)
		{
			return;
		}
		gObject.isInShipRoom = droppedInShipRoom;
		if (!gObject.scrapPersistedThroughRounds)
		{
			if (droppedInShipRoom)
			{
				RoundManager.Instance.scrapCollectedInLevel += gObject.scrapValue;
				StartOfRound.Instance.gameStats.allPlayerStats[playerClientId].profitable += gObject.scrapValue;
				RoundManager.Instance.CollectNewScrapForThisRound(gObject);
				gObject.OnBroughtToShip();
				if (gObject.itemProperties.isScrap && Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)gObject).transform.position) < 12f)
				{
					HUDManager.Instance.DisplayTip("Got scrap!", "To sell, use the terminal to route the ship to the company building.", isWarning: false, useSave: true, "LCTip_SellScrap");
				}
			}
			else
			{
				if (gObject.scrapPersistedThroughRounds)
				{
					return;
				}
				RoundManager.Instance.scrapCollectedInLevel -= gObject.scrapValue;
				StartOfRound.Instance.gameStats.allPlayerStats[playerClientId].profitable -= gObject.scrapValue;
			}
			HUDManager.Instance.SetQuota(RoundManager.Instance.scrapCollectedInLevel);
		}
		if (droppedInShipRoom)
		{
			StartOfRound.Instance.currentShipItemCount++;
		}
		else
		{
			StartOfRound.Instance.currentShipItemCount--;
		}
	}

	[ServerRpc]
	private void PlaceObjectServerRpc(NetworkObjectReference grabbedObject, NetworkObjectReference parentObject, Vector3 placePositionOffset = default(Vector3), bool matchRotationOfParent = true)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3830452098u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref parentObject, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref placePositionOffset);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref matchRotationOfParent, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3830452098u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			NetworkObject val3 = default(NetworkObject);
			NetworkObject val4 = default(NetworkObject);
			NetworkObject val5 = default(NetworkObject);
			NetworkObject val6 = default(NetworkObject);
			if (((NetworkObjectReference)(ref grabbedObject)).TryGet(ref val3, (NetworkManager)null) && ((NetworkObjectReference)(ref parentObject)).TryGet(ref val4, (NetworkManager)null))
			{
				PlaceObjectClientRpc(parentObject, placePositionOffset, matchRotationOfParent, grabbedObject);
			}
			else if (!((NetworkObjectReference)(ref grabbedObject)).TryGet(ref val5, (NetworkManager)null))
			{
				Debug.LogError((object)$"Object placement not synced to clients, missing reference to a network object: placing object with id: {((NetworkObjectReference)(ref grabbedObject)).NetworkObjectId}; player #{playerClientId}");
			}
			else if (!((NetworkObjectReference)(ref parentObject)).TryGet(ref val6, (NetworkManager)null))
			{
				Debug.LogError((object)$"Object placement not synced to clients, missing reference to a network object: parent object with id: {((NetworkObjectReference)(ref grabbedObject)).NetworkObjectId}; player #{playerClientId}");
			}
		}
	}

	public void PlaceGrabbableObject(Transform parentObject, Vector3 positionOffset, bool matchRotationOfParent, GrabbableObject placeObject)
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		PlayerPhysicsRegion componentInChildren = ((Component)parentObject).GetComponentInChildren<PlayerPhysicsRegion>();
		if ((Object)(object)componentInChildren != (Object)null && componentInChildren.allowDroppingItems)
		{
			parentObject = componentInChildren.physicsTransform;
		}
		placeObject.EnablePhysics(enable: true);
		placeObject.EnableItemMeshes(enable: true);
		placeObject.isHeld = false;
		placeObject.isPocketed = false;
		placeObject.heldByPlayerOnServer = false;
		SetItemInElevator(isInHangarShipRoom, isInElevator, placeObject);
		placeObject.parentObject = null;
		((Component)placeObject).transform.SetParent(parentObject, true);
		placeObject.startFallingPosition = ((Component)placeObject).transform.localPosition;
		((Component)placeObject).transform.localScale = placeObject.originalScale;
		((Component)placeObject).transform.localPosition = positionOffset;
		placeObject.targetFloorPosition = positionOffset;
		if (!matchRotationOfParent)
		{
			placeObject.fallTime = 0f;
		}
		else
		{
			((Component)placeObject).transform.localEulerAngles = new Vector3(0f, 0f, 0f);
			placeObject.fallTime = 1.1f;
		}
		placeObject.OnPlaceObject();
		for (int i = 0; i < ItemSlots.Length; i++)
		{
			if ((Object)(object)ItemSlots[i] == (Object)(object)placeObject)
			{
				ItemSlots[i] = null;
			}
		}
		twoHanded = false;
		twoHandedAnimation = false;
		carryWeight = Mathf.Clamp(carryWeight - (placeObject.itemProperties.weight - 1f), 1f, 10f);
		isHoldingObject = false;
		hasThrownObject = true;
	}

	[ClientRpc]
	private void PlaceObjectClientRpc(NetworkObjectReference parentObjectReference, Vector3 placePositionOffset, bool matchRotationOfParent, NetworkObjectReference grabbedObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3771510012u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref parentObjectReference, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref placePositionOffset);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref matchRotationOfParent, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3771510012u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref grabbedObject)).TryGet(ref val3, (NetworkManager)null))
		{
			GrabbableObject component = ((Component)val3).GetComponent<GrabbableObject>();
			if (!((NetworkBehaviour)this).IsOwner)
			{
				NetworkObject val4 = default(NetworkObject);
				if (((NetworkObjectReference)(ref parentObjectReference)).TryGet(ref val4, (NetworkManager)null))
				{
					PlaceGrabbableObject(((Component)val4).transform, placePositionOffset, matchRotationOfParent, component);
				}
				else
				{
					PlaceGrabbableObject(null, placePositionOffset, matchRotationOfParent, component);
					Debug.LogError((object)$"Reference to parent object when placing was missing. object: {component} placed by {((Object)((Component)this).gameObject).name}");
				}
			}
			if (!component.itemProperties.syncDiscardFunction)
			{
				component.playerHeldBy = null;
			}
			if ((Object)(object)currentlyHeldObjectServer == (Object)(object)component)
			{
				currentlyHeldObjectServer = null;
			}
			else
			{
				string arg = "null";
				if ((Object)(object)currentlyHeldObjectServer != (Object)null)
				{
					arg = ((Object)((Component)currentlyHeldObjectServer).gameObject).name;
				}
				Debug.LogError((object)$"ThrowObjectClientRpc called for an object which is not the same as currentlyHeldObjectServer which is {arg}, on player #{playerClientId}.");
			}
		}
		else
		{
			Debug.LogError((object)"The server did not have a reference to the held object (when attempting to PLACE object on client.)");
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			throwingObject = false;
			((Behaviour)HUDManager.Instance.itemSlotIcons[currentItemSlot]).enabled = false;
		}
	}

	private void SetFreeCamera_performed(CallbackContext context)
	{
		if (((NetworkBehaviour)this).IsServer && ((NetworkBehaviour)this).IsOwner && ((CallbackContext)(ref context)).performed)
		{
			_ = isTypingChat;
		}
	}

	public void ChangeHelmetLight(int lightNumber, bool enable = true)
	{
		for (int i = 0; i < allHelmetLights.Length; i++)
		{
			((Behaviour)allHelmetLights[i]).enabled = false;
		}
		((Behaviour)allHelmetLights[lightNumber]).enabled = enable;
		helmetLight = allHelmetLights[lightNumber];
	}

	public void SetInSpecialMenu(bool setInMenu, SpecialHUDMenu menuType = SpecialHUDMenu.BeltBagInventory)
	{
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		inSpecialMenu = setInMenu;
		if (setInMenu)
		{
			Cursor.lockState = (CursorLockMode)0;
			((Behaviour)cursorIcon).enabled = false;
			((TMP_Text)cursorTip).text = "";
			if ((Object)(object)hoveringOverTrigger != (Object)null)
			{
				previousHoveringOverTrigger = hoveringOverTrigger;
			}
			hoveringOverTrigger = null;
			HUDManager.Instance.OpenSpecialMenu(menuType);
		}
		else
		{
			Cursor.lockState = (CursorLockMode)1;
			if (!StartOfRound.Instance.localPlayerUsingController)
			{
				Cursor.visible = false;
			}
			HUDManager.Instance.SetMouseCursorSprite(HUDManager.Instance.defaultCursorTex);
			HUDManager.Instance.CloseSpecialMenus();
		}
	}

	private void OpenMenu_performed(CallbackContext context)
	{
		if (!((CallbackContext)(ref context)).performed)
		{
			return;
		}
		if ((Object)(object)NetworkManager.Singleton == (Object)null)
		{
			if (!isTestingPlayer)
			{
				return;
			}
		}
		else if (!((NetworkBehaviour)this).IsOwner || (!isPlayerControlled && !isPlayerDead) || (((NetworkBehaviour)this).IsServer && !isHostPlayerObject))
		{
			return;
		}
		if (!inTerminalMenu && (!Object.op_Implicit((Object)(object)Object.FindObjectOfType<Terminal>()) || !(Object.FindObjectOfType<Terminal>().timeSinceTerminalInUse < 0.25f)) && !isTypingChat)
		{
			if (inSpecialMenu)
			{
				SetInSpecialMenu(setInMenu: false);
				Cursor.lockState = (CursorLockMode)1;
				Cursor.visible = false;
			}
			else if (!quickMenuManager.isMenuOpen)
			{
				quickMenuManager.OpenQuickMenu();
			}
			else if (IngamePlayerSettings.Instance.changesNotApplied)
			{
				IngamePlayerSettings.Instance.DisplayConfirmChangesScreen(visible: true);
			}
			else
			{
				quickMenuManager.CloseQuickMenu();
			}
		}
	}

	private void Jump_performed(CallbackContext context)
	{
		if (!quickMenuManager.isMenuOpen && ((((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer) && !inSpecialInteractAnimation && !isTypingChat && (isMovementHindered <= 0 || isUnderwater) && !isExhausted && (thisController.isGrounded || (!isJumping && IsPlayerNearGround())) && !isJumping && (!isPlayerSliding || playerSlidingTimer > 2.5f) && !isCrouching)
		{
			playerSlidingTimer = 0f;
			isJumping = true;
			sprintMeter = Mathf.Clamp(sprintMeter - 0.08f, 0f, 1f);
			((UnityEvent<PlayerControllerB>)StartOfRound.Instance.PlayerJumpEvent).Invoke(this);
			PlayJumpAudio();
			if (jumpCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(jumpCoroutine);
			}
			jumpCoroutine = ((MonoBehaviour)this).StartCoroutine(PlayerJump());
			if (StartOfRound.Instance.connectedPlayersAmount != 0)
			{
				PlayerJumpedServerRpc();
			}
		}
	}

	private IEnumerator PlayerJump()
	{
		playerBodyAnimator.SetBool("Jumping", true);
		yield return (object)new WaitForSeconds(0.15f);
		fallValue = jumpForce;
		fallValueUncapped = jumpForce;
		yield return (object)new WaitForSeconds(0.1f);
		isJumping = false;
		isFallingFromJump = true;
		yield return (object)new WaitUntil((Func<bool>)(() => thisController.isGrounded));
		playerBodyAnimator.SetBool("Jumping", false);
		isFallingFromJump = false;
		PlayerHitGroundEffects();
		jumpCoroutine = null;
	}

	[ServerRpc]
	public void PlayerJumpedServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(420292904u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 420292904u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			PlayerJumpedClientRpc();
		}
	}

	[ClientRpc]
	public void PlayerJumpedClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2770415134u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2770415134u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				((UnityEvent<PlayerControllerB>)StartOfRound.Instance.PlayerJumpEvent).Invoke(this);
				PlayJumpAudio();
			}
		}
	}

	private void PlayJumpAudio()
	{
		if ((Object)(object)StartOfRound.Instance.unlockablesList.unlockables[currentSuitID].jumpAudio != (Object)null)
		{
			movementAudio.PlayOneShot(StartOfRound.Instance.unlockablesList.unlockables[currentSuitID].jumpAudio);
		}
		else
		{
			movementAudio.PlayOneShot(StartOfRound.Instance.playerJumpSFX);
		}
	}

	public void ResetFallGravity()
	{
		takingFallDamage = false;
		fallValue = 0f;
		fallValueUncapped = 0f;
	}

	private void PlayerLookInput()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_033f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_0315: Unknown result type (might be due to invalid IL or missing references)
		//IL_0393: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		if (quickMenuManager.isMenuOpen || inSpecialMenu || StartOfRound.Instance.newGameIsLoading || disableLookInput)
		{
			return;
		}
		Vector2 val = playerActions.Movement.Look.ReadValue<Vector2>() * 0.008f * (float)IngamePlayerSettings.Instance.settings.lookSensitivity;
		if (IngamePlayerSettings.Instance.settings.invertYAxis)
		{
			val.y *= -1f;
		}
		if (isFreeCamera)
		{
			StartOfRound.Instance.freeCinematicCameraTurnCompass.Rotate(new Vector3(0f, val.x, 0f));
			cameraUp -= val.y;
			cameraUp = Mathf.Clamp(cameraUp, -80f, 80f);
			((Component)StartOfRound.Instance.freeCinematicCameraTurnCompass).transform.localEulerAngles = new Vector3(cameraUp, ((Component)StartOfRound.Instance.freeCinematicCameraTurnCompass).transform.localEulerAngles.y, 0f);
			return;
		}
		if (IsInspectingItem)
		{
			val *= 0.01f;
			Vector3 localPosition = rightArmProceduralTarget.localPosition;
			localPosition.x = Mathf.Clamp(localPosition.x + val.x, rightArmProceduralTargetBasePosition.x - 0.1f, rightArmProceduralTargetBasePosition.x + 0.1f);
			localPosition.y = Mathf.Clamp(localPosition.y + val.y, rightArmProceduralTargetBasePosition.y - 0.3f, rightArmProceduralTargetBasePosition.y + 0.3f);
			rightArmProceduralTarget.localPosition = new Vector3(localPosition.x, localPosition.y, rightArmProceduralTarget.localPosition.z);
			return;
		}
		if (((NetworkBehaviour)this).IsOwner && isPlayerDead && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject))
		{
			spectateCameraPivot.Rotate(new Vector3(0f, val.x, 0f));
			cameraUp -= val.y;
			cameraUp = Mathf.Clamp(cameraUp, -80f, 80f);
			((Component)spectateCameraPivot).transform.localEulerAngles = new Vector3(cameraUp, ((Component)spectateCameraPivot).transform.localEulerAngles.y, 0f);
		}
		if ((!((NetworkBehaviour)this).IsOwner || !isPlayerControlled || (((NetworkBehaviour)this).IsServer && !isHostPlayerObject)) && !isTestingPlayer)
		{
			return;
		}
		StartOfRound.Instance.playerLookMagnitudeThisFrame = ((Vector2)(ref val)).magnitude * Time.deltaTime;
		if (inSpecialInteractAnimation && (isClimbingLadder || clampLooking))
		{
			if (isClimbingLadder)
			{
				minVerticalClamp = 25f;
				maxVerticalClamp = -60f;
				horizontalClamp = 60f;
			}
			LookClamped(val);
			SyncFullRotWithClients(inVehicleAnimation);
			return;
		}
		if (smoothLookMultiplier != 25f)
		{
			CalculateSmoothLookingInput(val);
		}
		else
		{
			CalculateNormalLookingInput(val);
		}
		if (isTestingPlayer || (((NetworkBehaviour)this).IsServer && playersManager.connectedPlayersAmount < 1))
		{
			return;
		}
		if (jetpackControls || disablingJetpackControls)
		{
			SyncFullRotWithClients();
		}
		else if (updatePlayerLookInterval > 0.1f && Physics.OverlapSphere(((Component)this).transform.position, 35f, playerMask).Length != 0)
		{
			updatePlayerLookInterval = 0f;
			if (Mathf.Abs(oldCameraUp + previousYRot - (cameraUp + thisPlayerBody.eulerAngles.y)) > 3f && !playersManager.newGameIsLoading)
			{
				UpdatePlayerRotationServerRpc((short)cameraUp, (short)thisPlayerBody.localEulerAngles.y);
				oldCameraUp = cameraUp;
				previousYRot = thisPlayerBody.localEulerAngles.y;
			}
		}
	}

	private void SyncFullRotWithClients(bool syncLookDirection = false)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		if ((jetpackControls || disablingJetpackControls || isClimbingLadder || syncLookDirection) && updatePlayerLookInterval > 0.15f)
		{
			updatePlayerLookInterval = 0f;
			if (syncLookDirection)
			{
				UpdatePlayerRotationFullServerRpc(((Component)this).transform.eulerAngles, ((Component)gameplayCamera).transform.localEulerAngles, syncingCameraRotation: true);
			}
			else
			{
				UpdatePlayerRotationFullServerRpc(((Component)this).transform.eulerAngles, Vector3.zero, syncingCameraRotation: false);
			}
			syncFullRotation = ((Component)this).transform.eulerAngles;
		}
	}

	private void CalculateSmoothLookingInput(Vector2 inputVector)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		if (!smoothLookEnabledLastFrame)
		{
			smoothLookEnabledLastFrame = true;
			smoothLookTurnCompass.rotation = ((Component)gameplayCamera).transform.rotation;
			smoothLookTurnCompass.SetParent((Transform)null);
		}
		smoothLookTurnCompass.Rotate(new Vector3(0f, inputVector.x, 0f), (Space)1);
		cameraUp -= inputVector.y;
		cameraUp = Mathf.Clamp(cameraUp, -80f, 60f);
		smoothLookTurnCompass.localEulerAngles = new Vector3(cameraUp, smoothLookTurnCompass.localEulerAngles.y, smoothLookTurnCompass.localEulerAngles.z);
		smoothLookTurnCompass.eulerAngles = new Vector3(smoothLookTurnCompass.eulerAngles.x, smoothLookTurnCompass.eulerAngles.y, ((Component)thisPlayerBody).transform.eulerAngles.z);
		thisPlayerBody.eulerAngles = new Vector3(thisPlayerBody.eulerAngles.x, Mathf.LerpAngle(thisPlayerBody.eulerAngles.y, smoothLookTurnCompass.eulerAngles.y, smoothLookMultiplier * Time.deltaTime), thisPlayerBody.eulerAngles.z);
		((Component)gameplayCamera).transform.localEulerAngles = new Vector3(Mathf.LerpAngle(((Component)gameplayCamera).transform.localEulerAngles.x, cameraUp, smoothLookMultiplier * Time.deltaTime), ((Component)gameplayCamera).transform.localEulerAngles.y, ((Component)gameplayCamera).transform.localEulerAngles.z);
	}

	private void CalculateNormalLookingInput(Vector2 inputVector)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		if (smoothLookEnabledLastFrame)
		{
			smoothLookEnabledLastFrame = false;
		}
		if (inShockingMinigame)
		{
			inputVector.x = Mathf.Clamp(inputVector.x, -15f, 15f);
			inputVector.y = Mathf.Clamp(inputVector.y, -15f, 15f);
			turnCompass.Rotate(new Vector3(0f, inputVector.x, 0f));
		}
		else if (jetpackControls)
		{
			jetpackTurnCompass.Rotate(new Vector3(0f, inputVector.x, 0f), (Space)1);
		}
		else
		{
			thisPlayerBody.Rotate(new Vector3(0f, inputVector.x, 0f), (Space)1);
		}
		cameraUp -= inputVector.y;
		cameraUp = Mathf.Clamp(cameraUp, -80f, 80f);
		((Component)gameplayCamera).transform.localEulerAngles = new Vector3(cameraUp, ((Component)gameplayCamera).transform.localEulerAngles.y, ((Component)gameplayCamera).transform.localEulerAngles.z);
		playerHudUIContainer.Rotate(new Vector3(inputVector.y / 4f, (0f - inputVector.x) / 8f, 0f) * Mathf.Clamp(Time.deltaTime * 15f, 0.02f, 4f));
	}

	private void Look_performed(CallbackContext context)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		if (quickMenuManager.isMenuOpen || inSpecialMenu)
		{
			Vector2 val = ((CallbackContext)(ref context)).ReadValue<Vector2>();
			if (((Vector2)(ref val)).magnitude > 0.001f)
			{
				Cursor.visible = true;
			}
		}
		else if ((((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer)
		{
			StartOfRound.Instance.localPlayerUsingController = !InputControlPath.MatchesPrefix("<Mouse>", ((CallbackContext)(ref context)).control);
		}
	}

	bool IShockableWithGun.CanBeShocked()
	{
		return !isPlayerDead;
	}

	float IShockableWithGun.GetDifficultyMultiplier()
	{
		return 1.5f;
	}

	NetworkObject IShockableWithGun.GetNetworkObject()
	{
		return ((NetworkBehaviour)this).NetworkObject;
	}

	Transform IShockableWithGun.GetShockableTransform()
	{
		return ((Component)this).transform;
	}

	Vector3 IShockableWithGun.GetShockablePosition()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		return ((Component)gameplayCamera).transform.position;
	}

	void IShockableWithGun.ShockWithGun(PlayerControllerB shockedByPlayer)
	{
		isMovementHindered++;
		hinderedMultiplier *= 3.5f;
		if (inSpecialInteractAnimation && (Object)(object)currentTriggerInAnimationWith != (Object)null)
		{
			MoveToExitSpecialAnimation componentInChildren = ((Component)currentTriggerInAnimationWith).GetComponentInChildren<MoveToExitSpecialAnimation>();
			if (componentInChildren.electricChair)
			{
				componentInChildren.PowerSurgeChairServerRpc();
			}
		}
	}

	void IShockableWithGun.StopShockingWithGun()
	{
		isMovementHindered = Mathf.Clamp(isMovementHindered - 1, 0, 1000);
		hinderedMultiplier /= 3.5f;
	}

	public void ForceTurnTowardsTarget()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		if (inSpecialInteractAnimation && inShockingMinigame && (Object)(object)shockingTarget != (Object)null)
		{
			targetScreenPos = turnCompassCamera.WorldToViewportPoint(shockingTarget.position);
			shockMinigamePullPosition = targetScreenPos.x - 0.5f;
			float num = Mathf.Clamp(Time.deltaTime, 0f, 0.1f);
			if (targetScreenPos.x > 0.54f)
			{
				turnCompass.Rotate(Vector3.up * 2000f * num * Mathf.Abs(shockMinigamePullPosition));
				playerBodyAnimator.SetBool("PullingCameraRight", false);
				playerBodyAnimator.SetBool("PullingCameraLeft", true);
			}
			else if (targetScreenPos.x < 0.46f)
			{
				turnCompass.Rotate(Vector3.up * -2000f * num * Mathf.Abs(shockMinigamePullPosition));
				playerBodyAnimator.SetBool("PullingCameraLeft", false);
				playerBodyAnimator.SetBool("PullingCameraRight", true);
			}
			else
			{
				playerBodyAnimator.SetBool("PullingCameraLeft", false);
				playerBodyAnimator.SetBool("PullingCameraRight", false);
			}
			targetScreenPos = gameplayCamera.WorldToViewportPoint(shockingTarget.position + Vector3.up * 0.35f);
			if (targetScreenPos.y > 0.6f)
			{
				cameraUp = Mathf.Clamp(Mathf.Lerp(cameraUp, cameraUp - 25f, 25f * num * Mathf.Abs(targetScreenPos.y - 0.5f)), -89f, 89f);
			}
			else if (targetScreenPos.y < 0.35f)
			{
				cameraUp = Mathf.Clamp(Mathf.Lerp(cameraUp, cameraUp + 25f, 25f * num * Mathf.Abs(targetScreenPos.y - 0.5f)), -89f, 89f);
			}
			((Component)gameplayCamera).transform.localEulerAngles = new Vector3(cameraUp, ((Component)gameplayCamera).transform.localEulerAngles.y, ((Component)gameplayCamera).transform.localEulerAngles.z);
			Vector3 zero = Vector3.zero;
			zero.y = turnCompass.eulerAngles.y;
			thisPlayerBody.rotation = Quaternion.Lerp(thisPlayerBody.rotation, Quaternion.Euler(zero), Time.deltaTime * 20f * (1f - Mathf.Abs(shockMinigamePullPosition)));
		}
	}

	private void LookClamped(Vector2 lookInput)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		lookInput *= 2f;
		ladderCameraHorizontal += lookInput.x;
		ladderCameraHorizontal = Mathf.Clamp(ladderCameraHorizontal, 0f - horizontalClamp, horizontalClamp);
		cameraUp -= lookInput.y;
		cameraUp = Mathf.Clamp(cameraUp, maxVerticalClamp, minVerticalClamp);
		((Component)gameplayCamera).transform.localEulerAngles = new Vector3(cameraUp, ladderCameraHorizontal, ((Component)gameplayCamera).transform.localEulerAngles.z);
	}

	private void Crouch_performed(CallbackContext context)
	{
		if (((CallbackContext)(ref context)).performed && !quickMenuManager.isMenuOpen && ((((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer) && !inSpecialInteractAnimation && thisController.isGrounded && !isTypingChat && !isJumping && !isSprinting)
		{
			crouchMeter = Mathf.Min(crouchMeter + 0.3f, 1.3f);
			Crouch(!isCrouching);
		}
	}

	public void Crouch(bool crouch)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		if (crouch)
		{
			if (sourcesCausingSinking <= 0 || !(sinkingValue > 0.6f))
			{
				isCrouching = true;
				StartOfRound.Instance.timeAtMakingLastPersonalMovement = Time.realtimeSinceStartup;
				playerBodyAnimator.SetTrigger("startCrouching");
				playerBodyAnimator.SetBool("crouching", true);
			}
		}
		else if (!Physics.Raycast(((Component)gameplayCamera).transform.position, Vector3.up, ref hit, 1.1f, playersManager.collidersAndRoomMask, (QueryTriggerInteraction)1))
		{
			isCrouching = false;
			StartOfRound.Instance.timeAtMakingLastPersonalMovement = Time.realtimeSinceStartup;
			playerBodyAnimator.SetBool("crouching", false);
		}
	}

	[ServerRpc]
	private void UpdatePlayerRotationServerRpc(short newRot, short newYRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(588787670u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, newRot);
			BytePacker.WriteValueBitPacked(val2, newYRot);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 588787670u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			UpdatePlayerRotationClientRpc(newRot, newYRot);
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Client rpc parameters were likely not correct, so an RPC was skipped: {arg}");
		}
	}

	[ClientRpc]
	private void UpdatePlayerRotationClientRpc(short newRot, short newYRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2188611472u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, newRot);
			BytePacker.WriteValueBitPacked(val2, newYRot);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2188611472u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			playersManager.gameStats.allPlayerStats[playerClientId].turnAmount++;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				targetYRot = newYRot;
				targetLookRot = newRot;
			}
		}
	}

	[ServerRpc]
	private void UpdatePlayerRotationFullServerRpc(Vector3 playerEulers, Vector3 cameraRotation, bool syncingCameraRotation)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2609793477u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref playerEulers);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref cameraRotation);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref syncingCameraRotation, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2609793477u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			if (syncingCameraRotation)
			{
				UpdatePlayerRotationFullWithCameraClientRpc(playerEulers, cameraRotation);
			}
			else
			{
				UpdatePlayerRotationFullClientRpc(playerEulers);
			}
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Client rpc parameters were likely not correct, so an RPC was skipped: {arg}");
		}
	}

	[ClientRpc]
	private void UpdatePlayerRotationFullWithCameraClientRpc(Vector3 playerEulers, Vector3 cameraRotation)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2829807886u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref playerEulers);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref cameraRotation);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2829807886u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				syncFullRotation = playerEulers;
				syncFullCameraRotation = cameraRotation;
			}
		}
	}

	[ClientRpc]
	private void UpdatePlayerRotationFullClientRpc(Vector3 playerEulers)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2444895710u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref playerEulers);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2444895710u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				syncFullRotation = playerEulers;
			}
		}
	}

	private void UpdatePlayerAnimationsToOtherClients(Vector2 moveInputVector)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		updatePlayerAnimationsInterval += Time.deltaTime;
		if (!inSpecialInteractAnimation && !(updatePlayerAnimationsInterval > 0.14f))
		{
			return;
		}
		updatePlayerAnimationsInterval = 0f;
		currentAnimationSpeed = playerBodyAnimator.GetFloat("animationSpeed");
		for (int i = 0; i < playerBodyAnimator.layerCount; i++)
		{
			List<int> list = currentAnimationStateHash;
			int index = i;
			AnimatorStateInfo currentAnimatorStateInfo = playerBodyAnimator.GetCurrentAnimatorStateInfo(i);
			list[index] = ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).fullPathHash;
			if (previousAnimationStateHash[i] != currentAnimationStateHash[i])
			{
				previousAnimationStateHash[i] = currentAnimationStateHash[i];
				previousAnimationSpeed = currentAnimationSpeed;
				UpdatePlayerAnimationServerRpc(currentAnimationStateHash[i], currentAnimationSpeed);
				return;
			}
		}
		if (previousAnimationSpeed != currentAnimationSpeed)
		{
			previousAnimationSpeed = currentAnimationSpeed;
			UpdatePlayerAnimationServerRpc(0, currentAnimationSpeed);
		}
	}

	public void DisableInVehicleAnimationSync()
	{
		DisableInVehicleAnimationServerRpc();
	}

	[ServerRpc(RequireOwnership = false)]
	public void DisableInVehicleAnimationServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3483566845u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3483566845u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				Debug.Log((object)"Sending disable invehicleanimation serverrpc");
				DisableInVehicleAnimationClientRpc();
			}
		}
	}

	[ClientRpc]
	public void DisableInVehicleAnimationClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3511599861u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3511599861u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				Debug.Log((object)("Client got DisableInVehicleAnimationClientRpc for player " + ((Object)((Component)this).gameObject).name));
				inVehicleAnimation = false;
			}
		}
	}

	[ServerRpc]
	private void UpdatePlayerAnimationServerRpc(int animationState, float animationSpeed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3473255830u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, animationState);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref animationSpeed, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3473255830u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			UpdatePlayerAnimationClientRpc(animationState, animationSpeed);
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Client rpc parameters were likely not correct, so an RPC was skipped: {arg}");
		}
	}

	[ClientRpc]
	private void UpdatePlayerAnimationClientRpc(int animationState, float animationSpeed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3386813972u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, animationState);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref animationSpeed, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3386813972u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (playerBodyAnimator.GetFloat("animationSpeed") != animationSpeed)
		{
			playerBodyAnimator.SetFloat("animationSpeed", animationSpeed);
		}
		if (animationState == 0)
		{
			return;
		}
		AnimatorStateInfo currentAnimatorStateInfo = playerBodyAnimator.GetCurrentAnimatorStateInfo(0);
		if (((AnimatorStateInfo)(ref currentAnimatorStateInfo)).fullPathHash == animationState)
		{
			return;
		}
		for (int i = 0; i < playerBodyAnimator.layerCount; i++)
		{
			if (playerBodyAnimator.HasState(i, animationState))
			{
				playerBodyAnimator.CrossFadeInFixedTime(animationState, 0.1f);
				break;
			}
		}
	}

	public void UpdateSpecialAnimationValue(bool specialAnimation, short yVal = 0, float timed = 0f, bool climbingLadder = false)
	{
		IsInSpecialAnimationServerRpc(specialAnimation, timed, climbingLadder);
		ResetZAndXRotation();
		if (specialAnimation)
		{
			UpdatePlayerRotationServerRpc(0, yVal);
		}
	}

	public void ResetZAndXRotation()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 localEulerAngles = thisPlayerBody.localEulerAngles;
		localEulerAngles.x = 0f;
		localEulerAngles.z = 0f;
		thisPlayerBody.localEulerAngles = localEulerAngles;
	}

	[ServerRpc]
	private void IsInSpecialAnimationServerRpc(bool specialAnimation, float timed = 0f, bool climbingLadder = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2480354441u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref specialAnimation, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timed, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref climbingLadder, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2480354441u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			IsInSpecialAnimationClientRpc(specialAnimation, timed, climbingLadder);
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Client rpc parameters were likely not correct, so an RPC was skipped: {arg}");
		}
	}

	[ClientRpc]
	private void IsInSpecialAnimationClientRpc(bool specialAnimation, float timed = 0f, bool climbingLadder = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2281795056u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref specialAnimation, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timed, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref climbingLadder, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2281795056u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		Debug.Log((object)"Setting animation on client");
		inSpecialInteractAnimation = specialAnimation;
		isClimbingLadder = climbingLadder;
		if (!specialAnimation && !climbingLadder)
		{
			ResetZAndXRotation();
		}
		if (timed > 0f)
		{
			if (timeSpecialAnimationCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(timeSpecialAnimationCoroutine);
			}
			timeSpecialAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(timeSpecialAnimation(timed));
		}
	}

	private IEnumerator timeSpecialAnimation(float time)
	{
		yield return (object)new WaitForSeconds(time);
		inSpecialInteractAnimation = false;
		timeSpecialAnimationCoroutine = null;
	}

	public void GetCurrentMaterialStandingOn()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		interactRay = new Ray(thisPlayerBody.position + Vector3.up, -Vector3.up);
		if (!Physics.Raycast(interactRay, ref hit, 6f, StartOfRound.Instance.walkableSurfacesMask, (QueryTriggerInteraction)1) || ((Component)((RaycastHit)(ref hit)).collider).CompareTag(StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].surfaceTag))
		{
			return;
		}
		for (int i = 0; i < StartOfRound.Instance.footstepSurfaces.Length; i++)
		{
			if (((Component)((RaycastHit)(ref hit)).collider).CompareTag(StartOfRound.Instance.footstepSurfaces[i].surfaceTag))
			{
				currentFootstepSurfaceIndex = i;
				break;
			}
		}
	}

	public void PlayFootstepSound()
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		GetCurrentMaterialStandingOn();
		int num = Random.Range(0, StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].clips.Length);
		if (num == previousFootstepClip)
		{
			num = (num + 1) % StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].clips.Length;
		}
		movementAudio.pitch = Random.Range(0.93f, 1.07f);
		bool flag;
		if (((NetworkBehaviour)this).IsOwner)
		{
			flag = isSprinting;
		}
		else
		{
			AnimatorStateInfo currentAnimatorStateInfo = playerBodyAnimator.GetCurrentAnimatorStateInfo(0);
			flag = ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).IsTag("Sprinting");
		}
		float num2 = 0.9f;
		if (!flag)
		{
			num2 = 0.6f;
		}
		movementAudio.PlayOneShot(StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].clips[num], num2);
		previousFootstepClip = num;
		WalkieTalkie.TransmitOneShotAudio(movementAudio, StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].clips[num], num2);
	}

	public void PlayFootstepServer()
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		if (!isClimbingLadder && !inSpecialInteractAnimation && !((NetworkBehaviour)this).IsOwner && isPlayerControlled)
		{
			bool noiseIsInsideClosedShip = isInHangarShipRoom && playersManager.hangarDoorsClosed;
			if (isSprinting)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 22f, 0.6f, 0, noiseIsInsideClosedShip, 7);
			}
			else
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 17f, 0.4f, 0, noiseIsInsideClosedShip, 7);
			}
			PlayFootstepSound();
		}
	}

	public void PlayFootstepLocal()
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (!isClimbingLadder && !inSpecialInteractAnimation && (isTestingPlayer || (((NetworkBehaviour)this).IsOwner && isPlayerControlled)))
		{
			bool noiseIsInsideClosedShip = isInHangarShipRoom && playersManager.hangarDoorsClosed;
			if (isSprinting)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 22f, 0.6f, 0, noiseIsInsideClosedShip, 6);
			}
			else
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 17f, 0.4f, 0, noiseIsInsideClosedShip, 6);
			}
			PlayFootstepSound();
		}
	}

	[ServerRpc]
	private void UpdatePlayerPositionServerRpc(Vector3 newPos, bool inElevator, bool inShipRoom, bool exhausted, bool isPlayerGrounded)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2013428264u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPos);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inShipRoom, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref exhausted, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isPlayerGrounded, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2013428264u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			UpdatePlayerPositionClientRpc(newPos, inElevator, inShipRoom, exhausted, isPlayerGrounded);
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Caught an error when sending player position RPC; likely a player disconnected to cause this. Error: {arg}");
		}
	}

	[ClientRpc]
	private void UpdatePlayerPositionClientRpc(Vector3 newPos, bool inElevator, bool isInShip, bool exhausted, bool isPlayerGrounded)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_037c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1048810471u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPos);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isInShip, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref exhausted, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isPlayerGrounded, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1048810471u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		playersManager.gameStats.allPlayerStats[playerClientId].stepsTaken++;
		playersManager.gameStats.allStepsTaken++;
		bool flag = currentFootstepSurfaceIndex == 8 && ((((NetworkBehaviour)this).IsOwner && thisController.isGrounded) || isPlayerGrounded);
		if (bleedingHeavily || flag)
		{
			DropBlood(Vector3.down, bleedingHeavily, flag);
		}
		timeSincePlayerMoving = 0f;
		if (((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (!inElevator)
		{
			isInHangarShipRoom = false;
		}
		isExhausted = exhausted;
		isInElevator = inElevator;
		isInHangarShipRoom = isInShip;
		for (int i = 0; i < ItemSlots.Length; i++)
		{
			if ((Object)(object)ItemSlots[i] != (Object)null && ItemSlots[i].isHeld)
			{
				if (ItemSlots[i].isInShipRoom != isInShip)
				{
					SetItemInElevator(isInShip, isInElevator, ItemSlots[i]);
				}
				ItemSlots[i].isInElevator = inElevator;
			}
		}
		oldPlayerPosition = serverPlayerPosition;
		if (!disableSyncInAnimation && !inVehicleAnimation)
		{
			serverPlayerPosition = newPos;
		}
		if ((Object)(object)overridePhysicsParent != (Object)null)
		{
			if ((Object)(object)overridePhysicsParent != (Object)(object)lastSyncedPhysicsParent)
			{
				lastSyncedPhysicsParent = overridePhysicsParent;
				((Component)this).transform.SetParent(overridePhysicsParent);
			}
		}
		else if ((Object)(object)physicsParent != (Object)null)
		{
			if ((Object)(object)physicsParent != (Object)(object)lastSyncedPhysicsParent)
			{
				lastSyncedPhysicsParent = physicsParent;
				((Component)this).transform.SetParent(physicsParent);
			}
		}
		else if ((Object)(object)lastSyncedPhysicsParent != (Object)null)
		{
			lastSyncedPhysicsParent = null;
		}
		else if (isInElevator)
		{
			if (!parentedToElevatorLastFrame)
			{
				parentedToElevatorLastFrame = true;
				((Component)this).transform.SetParent(playersManager.elevatorTransform);
			}
		}
		else if (parentedToElevatorLastFrame)
		{
			parentedToElevatorLastFrame = false;
			((Component)this).transform.SetParent(playersManager.playersContainer);
			((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
		}
	}

	[ServerRpc]
	private void RemovePlayerPhysicsParentServerRpc(Vector3 newPos, bool removeOverride, bool removeBoth, bool inElevator, bool isInShip)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3843228541u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPos);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref removeOverride, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref removeBoth, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isInShip, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3843228541u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			RemovePlayerPhysicsParentClientRpc(newPos, removeOverride, removeBoth, inElevator, isInShip);
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Caught an error when sending RemovePhysicsParent RPC. Error: {arg}");
		}
	}

	[ClientRpc]
	private void RemovePlayerPhysicsParentClientRpc(Vector3 newPos, bool removeOverride, bool removeBoth, bool inElevator, bool isInShip)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_030d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2084785324u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPos);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref removeOverride, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref removeBoth, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isInShip, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2084785324u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (waitForPhysicsParentCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(waitForPhysicsParentCoroutine);
		}
		if (!inElevator)
		{
			isInHangarShipRoom = false;
		}
		isInElevator = inElevator;
		isInHangarShipRoom = isInShip;
		for (int i = 0; i < ItemSlots.Length; i++)
		{
			if ((Object)(object)ItemSlots[i] != (Object)null && ItemSlots[i].isHeld)
			{
				if (ItemSlots[i].isInShipRoom != isInShip)
				{
					SetItemInElevator(isInShip, isInElevator, ItemSlots[i]);
				}
				ItemSlots[i].isInElevator = inElevator;
			}
		}
		oldPlayerPosition = serverPlayerPosition;
		if (!disableSyncInAnimation && !inVehicleAnimation)
		{
			serverPlayerPosition = newPos;
		}
		if (removeBoth)
		{
			physicsParent = null;
			overridePhysicsParent = null;
		}
		else if (removeOverride)
		{
			overridePhysicsParent = null;
		}
		else
		{
			physicsParent = null;
		}
		if (isPlayerDead)
		{
			return;
		}
		if ((Object)(object)overridePhysicsParent != (Object)null)
		{
			if ((Object)(object)overridePhysicsParent != (Object)(object)lastSyncedPhysicsParent)
			{
				lastSyncedPhysicsParent = overridePhysicsParent;
				((Component)this).transform.SetParent(overridePhysicsParent);
			}
		}
		else if ((Object)(object)physicsParent != (Object)null)
		{
			if ((Object)(object)physicsParent != (Object)(object)lastSyncedPhysicsParent)
			{
				lastSyncedPhysicsParent = physicsParent;
				((Component)this).transform.SetParent(physicsParent);
			}
		}
		else if (isInElevator)
		{
			parentedToElevatorLastFrame = true;
			((Component)this).transform.SetParent(playersManager.elevatorTransform);
		}
		else
		{
			parentedToElevatorLastFrame = false;
			((Component)this).transform.SetParent(playersManager.playersContainer);
			((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
		}
	}

	[ServerRpc]
	private void UpdatePlayerPhysicsParentServerRpc(Vector3 newPos, NetworkObjectReference setPhysicsParent, bool isOverride, bool inElevator, bool isInShip)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1155355692u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPos);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref setPhysicsParent, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isOverride, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isInShip, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1155355692u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			UpdatePlayerPhysicsParentClientRpc(newPos, setPhysicsParent, isOverride, inElevator, isInShip);
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Caught an error when sending UpdatePhysicsParent RPC. Error: {arg}");
		}
	}

	[ClientRpc]
	private void UpdatePlayerPhysicsParentClientRpc(Vector3 newPos, NetworkObjectReference setPhysicsParent, bool isOverride, bool inElevator, bool isInShip)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3055429600u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPos);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref setPhysicsParent, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isOverride, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isInShip, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3055429600u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (!inElevator)
		{
			isInHangarShipRoom = false;
		}
		isInElevator = inElevator;
		isInHangarShipRoom = isInShip;
		for (int i = 0; i < ItemSlots.Length; i++)
		{
			if ((Object)(object)ItemSlots[i] != (Object)null && ItemSlots[i].isHeld)
			{
				if (ItemSlots[i].isInShipRoom != isInShip)
				{
					SetItemInElevator(isInShip, isInElevator, ItemSlots[i]);
				}
				ItemSlots[i].isInElevator = inElevator;
			}
		}
		oldPlayerPosition = serverPlayerPosition;
		if (!disableSyncInAnimation && !inVehicleAnimation)
		{
			serverPlayerPosition = newPos;
		}
		NetworkObject val3 = default(NetworkObject);
		if (!((NetworkObjectReference)(ref setPhysicsParent)).TryGet(ref val3, (NetworkManager)null))
		{
			if (waitForPhysicsParentCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(waitForPhysicsParentCoroutine);
			}
			waitForPhysicsParentCoroutine = ((MonoBehaviour)this).StartCoroutine(waitForPhysicsParentToSpawn(newPos, setPhysicsParent, isOverride, inElevator, isInShip));
		}
		else
		{
			UpdatePlayerPhysicsParentLocal(setPhysicsParent, isOverride);
		}
	}

	public void UpdatePlayerPhysicsParentLocal(NetworkObjectReference setPhysicsParent, bool isOverride)
	{
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		NetworkObject val = default(NetworkObject);
		if (((NetworkObjectReference)(ref setPhysicsParent)).TryGet(ref val, (NetworkManager)null))
		{
			if (isOverride)
			{
				overridePhysicsParent = ((Component)val).transform;
			}
			else
			{
				overridePhysicsParent = null;
				if ((Object)(object)((Component)val).GetComponentInChildren<PlayerPhysicsRegion>() != (Object)null)
				{
					physicsParent = ((Component)val).GetComponentInChildren<PlayerPhysicsRegion>().physicsTransform;
				}
			}
		}
		if (isPlayerDead)
		{
			return;
		}
		if ((Object)(object)overridePhysicsParent != (Object)null)
		{
			if ((Object)(object)overridePhysicsParent != (Object)(object)lastSyncedPhysicsParent)
			{
				lastSyncedPhysicsParent = overridePhysicsParent;
				((Component)this).transform.SetParent(overridePhysicsParent);
			}
			return;
		}
		if ((Object)(object)physicsParent != (Object)null)
		{
			if ((Object)(object)physicsParent != (Object)(object)lastSyncedPhysicsParent)
			{
				lastSyncedPhysicsParent = physicsParent;
				((Component)this).transform.SetParent(physicsParent);
			}
			return;
		}
		if ((Object)(object)lastSyncedPhysicsParent != (Object)null)
		{
			lastSyncedPhysicsParent = null;
		}
		if (isInElevator)
		{
			parentedToElevatorLastFrame = true;
			((Component)this).transform.SetParent(playersManager.elevatorTransform);
		}
		else
		{
			parentedToElevatorLastFrame = false;
			((Component)this).transform.SetParent(playersManager.playersContainer);
			((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
		}
	}

	private IEnumerator waitForPhysicsParentToSpawn(Vector3 newPos, NetworkObjectReference setPhysicsParent, bool isOverride, bool inElevator, bool isInShip)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		float time = Time.realtimeSinceStartup;
		NetworkObject val = default(NetworkObject);
		while (Time.realtimeSinceStartup - time < 5f)
		{
			yield return (object)new WaitForSeconds(0.5f);
			if (((NetworkObjectReference)(ref setPhysicsParent)).TryGet(ref val, (NetworkManager)null))
			{
				UpdatePlayerPhysicsParentLocal(setPhysicsParent, isOverride);
			}
		}
		waitForPhysicsParentCoroutine = null;
	}

	[ServerRpc]
	public void LandFromJumpServerRpc(bool fallHard)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3332990272u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref fallHard, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3332990272u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			LandFromJumpClientRpc(fallHard);
		}
	}

	[ClientRpc]
	public void LandFromJumpClientRpc(bool fallHard)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(983565270u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref fallHard, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 983565270u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
		{
			if (fallHard)
			{
				movementAudio.PlayOneShot(StartOfRound.Instance.playerHitGroundHard, 1f);
			}
			else
			{
				movementAudio.PlayOneShot(StartOfRound.Instance.playerHitGroundSoft, 0.7f);
			}
		}
	}

	public void LimpAnimationSpeed()
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			limpMultiplier = 1.1f;
		}
	}

	public void SpawnPlayerAnimation()
	{
		UpdateSpecialAnimationValue(specialAnimation: true, 0);
		inSpecialInteractAnimation = true;
		playerBodyAnimator.ResetTrigger("SpawnPlayer");
		playerBodyAnimator.SetTrigger("SpawnPlayer");
		((MonoBehaviour)this).StartCoroutine(spawnPlayerAnimTimer());
	}

	private IEnumerator spawnPlayerAnimTimer()
	{
		yield return (object)new WaitForSeconds(3f);
		inSpecialInteractAnimation = false;
		UpdateSpecialAnimationValue(specialAnimation: false, 0);
	}

	[ServerRpc(RequireOwnership = false)]
	private void SendNewPlayerValuesServerRpc(ulong newPlayerSteamId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2504133785u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, newPlayerSteamId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2504133785u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost) || sentPlayerValues)
		{
			return;
		}
		sentPlayerValues = true;
		if (!GameNetworkManager.Instance.disableSteam && GameNetworkManager.Instance.currentLobby.HasValue)
		{
			if (!GameNetworkManager.Instance.steamIdsInLobby.Contains(SteamId.op_Implicit(newPlayerSteamId)))
			{
				NetworkManager.Singleton.DisconnectClient(actualClientId);
				return;
			}
			if (StartOfRound.Instance.KickedClientIds.Contains(newPlayerSteamId))
			{
				NetworkManager.Singleton.DisconnectClient(actualClientId);
				return;
			}
		}
		List<ulong> list = new List<ulong>();
		for (int i = 0; i < 4; i++)
		{
			if (i == (int)playerClientId)
			{
				list.Add(newPlayerSteamId);
			}
			else
			{
				list.Add(playersManager.allPlayerScripts[i].playerSteamId);
			}
		}
		SendNewPlayerValuesClientRpc(list.ToArray());
	}

	[ClientRpc]
	private void SendNewPlayerValuesClientRpc(ulong[] playerSteamIds)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(956616685u, val, (RpcDelivery)0);
			bool flag = playerSteamIds != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<ulong>(playerSteamIds, default(ForPrimitives));
			}
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 956616685u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		Friend val3 = default(Friend);
		for (int i = 0; i < playerSteamIds.Length; i++)
		{
			if (playersManager.allPlayerScripts[i].isPlayerControlled || playersManager.allPlayerScripts[i].isPlayerDead)
			{
				((Friend)(ref val3))._002Ector(SteamId.op_Implicit(playerSteamIds[i]));
				string input = NoPunctuation(((Friend)(ref val3)).Name);
				input = Regex.Replace(input, "[^\\w\\._]", "");
				if (input == string.Empty || input.Length == 0)
				{
					input = "Nameless";
				}
				else if (input.Length <= 2)
				{
					input += "0";
				}
				playersManager.allPlayerScripts[i].playerSteamId = playerSteamIds[i];
				playersManager.allPlayerScripts[i].playerUsername = input;
				((TMP_Text)playersManager.allPlayerScripts[i].usernameBillboardText).text = input;
				string text = input;
				int numberOfDuplicateNamesInLobby = GetNumberOfDuplicateNamesInLobby();
				if (numberOfDuplicateNamesInLobby > 0)
				{
					text = $"{input}{numberOfDuplicateNamesInLobby}";
				}
				quickMenuManager.AddUserToPlayerList(playerSteamIds[i], text, i);
				StartOfRound.Instance.mapScreen.radarTargets[i].name = text;
			}
		}
		StartOfRound.Instance.StartTrackingAllPlayerVoices();
		if ((Object)(object)GameNetworkManager.Instance != (Object)null && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
		{
			GameNetworkManager.Instance.localPlayerController.updatePositionForNewlyJoinedClient = true;
		}
	}

	private int GetNumberOfDuplicateNamesInLobby()
	{
		int num = 0;
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if ((StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled || playersManager.allPlayerScripts[i].isPlayerDead) && !((Object)(object)StartOfRound.Instance.allPlayerScripts[i] == (Object)(object)this) && StartOfRound.Instance.allPlayerScripts[i].playerUsername == playerUsername)
			{
				num++;
			}
		}
		for (int j = 0; j < StartOfRound.Instance.allPlayerScripts.Length; j++)
		{
			if ((StartOfRound.Instance.allPlayerScripts[j].isPlayerControlled || playersManager.allPlayerScripts[j].isPlayerDead) && !((Object)(object)StartOfRound.Instance.allPlayerScripts[j] == (Object)(object)this) && StartOfRound.Instance.allPlayerScripts[j].playerUsername == $"{StartOfRound.Instance.allPlayerScripts[j].playerUsername}{num}")
			{
				num++;
			}
		}
		return num;
	}

	private string NoPunctuation(string input)
	{
		return new string(input.Where((char c) => char.IsLetter(c)).ToArray());
	}

	public void ConnectClientToPlayerObject()
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		if (!isTestingPlayer)
		{
			actualClientId = NetworkManager.Singleton.LocalClientId;
			playersManager.thisClientPlayerId = (int)playerClientId;
		}
		if ((Object)(object)GameNetworkManager.Instance != (Object)null)
		{
			GameNetworkManager.Instance.localPlayerController = this;
		}
		playersManager.localPlayerController = this;
		for (int i = 0; i < playersManager.allPlayerObjects.Length; i++)
		{
			PlayerControllerB component = playersManager.allPlayerObjects[i].GetComponent<PlayerControllerB>();
			if (!component.isPlayerControlled && !component.isTestingPlayer)
			{
				component.TeleportPlayer(playersManager.notSpawnedPosition.position);
			}
			if ((Object)(object)component != (Object)(object)playersManager.localPlayerController)
			{
				playersManager.OtherClients.Add(component);
			}
		}
		playersManager.localClientHasControl = true;
		if ((Object)(object)playerBodyAnimator.runtimeAnimatorController != (Object)(object)playersManager.localClientAnimatorController)
		{
			playerBodyAnimator.runtimeAnimatorController = playersManager.localClientAnimatorController;
		}
		if (!isTestingPlayer)
		{
			if (!GameNetworkManager.Instance.disableSteam)
			{
				playerUsername = GameNetworkManager.Instance.username;
				SendNewPlayerValuesServerRpc(SteamId.op_Implicit(SteamClient.SteamId));
			}
			else if (((NetworkBehaviour)this).IsServer)
			{
				Object.FindObjectOfType<QuickMenuManager>().AddUserToPlayerList(0uL, "Player #0", 0);
			}
			HUDManager.Instance.AddTextToChatOnServer(playerUsername + " joined the ship.");
			usernameAlpha.alpha = 0f;
			((Behaviour)usernameBillboardText).enabled = false;
		}
	}

	private void ChangeAudioListenerToObject(GameObject addToObject)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		((Component)activeAudioListener).transform.SetParent(addToObject.transform);
		((Component)activeAudioListener).transform.localEulerAngles = Vector3.zero;
		((Component)activeAudioListener).transform.localPosition = Vector3.zero;
		StartOfRound.Instance.audioListener = activeAudioListener;
	}

	private void PlayerHitGroundEffects()
	{
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		GetCurrentMaterialStandingOn();
		if (fallValue < -9f)
		{
			if (fallValue < -16f)
			{
				movementAudio.PlayOneShot(StartOfRound.Instance.playerHitGroundHard, 1f);
				WalkieTalkie.TransmitOneShotAudio(movementAudio, StartOfRound.Instance.playerHitGroundHard);
			}
			else if (fallValue < -2f)
			{
				movementAudio.PlayOneShot(StartOfRound.Instance.playerHitGroundSoft, 1f);
			}
			LandFromJumpServerRpc(fallValue < -16f);
		}
		float num = fallValueUncapped;
		if (disabledJetpackControlsThisFrame && Vector3.Angle(((Component)this).transform.up, Vector3.up) > 80f)
		{
			num -= 10f;
		}
		if (takingFallDamage && !isSpeedCheating)
		{
			if (fallValueUncapped < -48.5f)
			{
				DamagePlayer(100, hasDamageSFX: true, callRPC: true, CauseOfDeath.Gravity);
			}
			else if (fallValueUncapped < -45f)
			{
				DamagePlayer(80, hasDamageSFX: true, callRPC: true, CauseOfDeath.Gravity);
			}
			else if (fallValueUncapped < -40f)
			{
				DamagePlayer(50, hasDamageSFX: true, callRPC: true, CauseOfDeath.Gravity);
			}
			else if (fallValue < -38f)
			{
				DamagePlayer(30, hasDamageSFX: true, callRPC: true, CauseOfDeath.Gravity);
			}
		}
		if (fallValue < -16f)
		{
			RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 7f);
		}
	}

	public void OnControllerColliderHit(ControllerColliderHit hit)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			controllerCollisionPoint = hit.point;
		}
	}

	private void CalculateGroundNormal()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		Vector3[] array = (Vector3[])(object)new Vector3[5]
		{
			((Component)this).transform.position + Vector3.up * 1.5f,
			((Component)this).transform.position + Vector3.up * 1.5f + Vector3.right * thisController.radius,
			((Component)this).transform.position + Vector3.up * 1.5f + -Vector3.right * thisController.radius,
			((Component)this).transform.position + Vector3.up * 1.5f + Vector3.forward * thisController.radius,
			((Component)this).transform.position + Vector3.up * 1.5f + -Vector3.forward * thisController.radius
		};
		for (int i = 0; i < array.Length; i++)
		{
			if (Physics.Raycast(array[i], -Vector3.up, ref hit, 1.8f, 268438273, (QueryTriggerInteraction)1))
			{
				playerGroundNormal = ((RaycastHit)(ref hit)).normal;
				return;
			}
			Debug.DrawRay(array[i], -Vector3.up, Color.red);
			playerGroundNormal = Vector3.up;
		}
		if (controllerCollisionPoint != Vector3.zero)
		{
			if (Physics.Raycast(controllerCollisionPoint + Vector3.up * 0.3f, -Vector3.up, ref hit, 1f, 268438273, (QueryTriggerInteraction)1))
			{
				playerGroundNormal = ((RaycastHit)(ref hit)).normal;
			}
			else
			{
				playerGroundNormal = Vector3.up;
			}
			controllerCollisionPoint = Vector3.zero;
		}
	}

	private bool IsPlayerNearGround()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		interactRay = new Ray(((Component)this).transform.position, Vector3.down);
		return Physics.Raycast(interactRay, 0.15f, StartOfRound.Instance.allPlayersCollideWithMask, (QueryTriggerInteraction)1);
	}

	[ServerRpc]
	public void DisableJetpackModeServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3237016509u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3237016509u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DisableJetpackModeClientRpc();
		}
	}

	[ClientRpc]
	public void DisableJetpackModeClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1367193869u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1367193869u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				DisableJetpackControlsLocally();
			}
		}
	}

	public void DisableJetpackControlsLocally()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		jetpackControls = false;
		thisController.radius = 0.4f;
		jetpackTurnCompass.rotation = ((Component)this).transform.rotation;
		startedJetpackControls = false;
		disablingJetpackControls = false;
		maxJetpackAngle = -1f;
		jetpackRandomIntensity = 0f;
	}

	private void Update()
	{
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d64: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cbd: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ced: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d42: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c11: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c17: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c27: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c51: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c57: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c85: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c92: Unknown result type (might be due to invalid IL or missing references)
		//IL_218b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f01: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f21: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f37: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f57: Unknown result type (might be due to invalid IL or missing references)
		//IL_219c: Unknown result type (might be due to invalid IL or missing references)
		//IL_21a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_21ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_21b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_21bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_21c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_21c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_206d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2078: Unknown result type (might be due to invalid IL or missing references)
		//IL_2082: Unknown result type (might be due to invalid IL or missing references)
		//IL_2087: Unknown result type (might be due to invalid IL or missing references)
		//IL_209d: Unknown result type (might be due to invalid IL or missing references)
		//IL_20a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_20b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dd7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ddd: Unknown result type (might be due to invalid IL or missing references)
		//IL_1de2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1df2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e08: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_212c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2141: Unknown result type (might be due to invalid IL or missing references)
		//IL_214b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e3e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e64: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2200: Unknown result type (might be due to invalid IL or missing references)
		//IL_230e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2319: Unknown result type (might be due to invalid IL or missing references)
		//IL_231e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2328: Unknown result type (might be due to invalid IL or missing references)
		//IL_232d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2347: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e96: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ec2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ee9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0844: Unknown result type (might be due to invalid IL or missing references)
		//IL_084f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0864: Unknown result type (might be due to invalid IL or missing references)
		//IL_086e: Unknown result type (might be due to invalid IL or missing references)
		//IL_087e: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_07dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_075f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0769: Unknown result type (might be due to invalid IL or missing references)
		//IL_076f: Unknown result type (might be due to invalid IL or missing references)
		//IL_08eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_08fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0910: Unknown result type (might be due to invalid IL or missing references)
		//IL_0920: Unknown result type (might be due to invalid IL or missing references)
		//IL_0925: Unknown result type (might be due to invalid IL or missing references)
		//IL_092b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0930: Unknown result type (might be due to invalid IL or missing references)
		//IL_0943: Unknown result type (might be due to invalid IL or missing references)
		//IL_0948: Unknown result type (might be due to invalid IL or missing references)
		//IL_094f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0954: Unknown result type (might be due to invalid IL or missing references)
		//IL_097c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0990: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1879: Unknown result type (might be due to invalid IL or missing references)
		//IL_187e: Unknown result type (might be due to invalid IL or missing references)
		//IL_188b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1896: Unknown result type (might be due to invalid IL or missing references)
		//IL_18a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_18a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_18aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_18ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_18b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_18b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_18bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b69: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ed0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ed5: Unknown result type (might be due to invalid IL or missing references)
		//IL_19d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_19ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_1996: Unknown result type (might be due to invalid IL or missing references)
		//IL_199c: Unknown result type (might be due to invalid IL or missing references)
		//IL_19a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_19a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_18d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_18d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_18df: Unknown result type (might be due to invalid IL or missing references)
		//IL_18e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_18f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_18f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c78: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c83: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c93: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c23: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef6: Unknown result type (might be due to invalid IL or missing references)
		//IL_192f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1931: Unknown result type (might be due to invalid IL or missing references)
		//IL_1916: Unknown result type (might be due to invalid IL or missing references)
		//IL_191b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1920: Unknown result type (might be due to invalid IL or missing references)
		//IL_1928: Unknown result type (might be due to invalid IL or missing references)
		//IL_192d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c48: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1956: Unknown result type (might be due to invalid IL or missing references)
		//IL_1961: Unknown result type (might be due to invalid IL or missing references)
		//IL_197e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1983: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f24: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f46: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f55: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f5a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f5f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f73: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e20: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e26: Unknown result type (might be due to invalid IL or missing references)
		//IL_110f: Unknown result type (might be due to invalid IL or missing references)
		//IL_111a: Unknown result type (might be due to invalid IL or missing references)
		//IL_112a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1135: Unknown result type (might be due to invalid IL or missing references)
		//IL_1145: Unknown result type (might be due to invalid IL or missing references)
		//IL_114a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1157: Unknown result type (might be due to invalid IL or missing references)
		//IL_115c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1162: Unknown result type (might be due to invalid IL or missing references)
		//IL_1169: Unknown result type (might be due to invalid IL or missing references)
		//IL_1174: Unknown result type (might be due to invalid IL or missing references)
		//IL_1189: Unknown result type (might be due to invalid IL or missing references)
		//IL_118e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1193: Unknown result type (might be due to invalid IL or missing references)
		//IL_1195: Unknown result type (might be due to invalid IL or missing references)
		//IL_119a: Unknown result type (might be due to invalid IL or missing references)
		//IL_119c: Unknown result type (might be due to invalid IL or missing references)
		//IL_119f: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff5: Unknown result type (might be due to invalid IL or missing references)
		//IL_11bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_11d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1012: Unknown result type (might be due to invalid IL or missing references)
		//IL_101a: Unknown result type (might be due to invalid IL or missing references)
		//IL_102d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1032: Unknown result type (might be due to invalid IL or missing references)
		//IL_103c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1041: Unknown result type (might be due to invalid IL or missing references)
		//IL_1057: Unknown result type (might be due to invalid IL or missing references)
		//IL_105c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1061: Unknown result type (might be due to invalid IL or missing references)
		//IL_2b75: Unknown result type (might be due to invalid IL or missing references)
		//IL_2b80: Unknown result type (might be due to invalid IL or missing references)
		//IL_12d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_12d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_12e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_12eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_12f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_2bdf: Unknown result type (might be due to invalid IL or missing references)
		//IL_2bbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_1242: Unknown result type (might be due to invalid IL or missing references)
		//IL_1274: Unknown result type (might be due to invalid IL or missing references)
		//IL_127b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1522: Unknown result type (might be due to invalid IL or missing references)
		//IL_1527: Unknown result type (might be due to invalid IL or missing references)
		//IL_183e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1844: Unknown result type (might be due to invalid IL or missing references)
		//IL_15ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_15b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1800: Unknown result type (might be due to invalid IL or missing references)
		//IL_1805: Unknown result type (might be due to invalid IL or missing references)
		//IL_1694: Unknown result type (might be due to invalid IL or missing references)
		//IL_1699: Unknown result type (might be due to invalid IL or missing references)
		//IL_16b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1731: Unknown result type (might be due to invalid IL or missing references)
		//IL_173b: Unknown result type (might be due to invalid IL or missing references)
		//IL_16de: Unknown result type (might be due to invalid IL or missing references)
		//IL_1773: Unknown result type (might be due to invalid IL or missing references)
		//IL_177d: Unknown result type (might be due to invalid IL or missing references)
		//IL_17c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_17d0: Unknown result type (might be due to invalid IL or missing references)
		if ((((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject)) || isTestingPlayer)
		{
			if (isCameraDisabled)
			{
				isCameraDisabled = false;
				Debug.Log((object)("Taking control of player " + ((Object)((Component)this).gameObject).name + " and enabling camera!"));
				StartOfRound.Instance.SwitchCamera(gameplayCamera);
				((Renderer)thisPlayerModel).shadowCastingMode = (ShadowCastingMode)3;
				((Renderer)mapRadarDirectionIndicator).enabled = true;
				((Renderer)thisPlayerModelArms).enabled = true;
				((Behaviour)playerScreen).enabled = true;
				Cursor.lockState = (CursorLockMode)1;
				Cursor.visible = false;
				((Collider)((Component)this).gameObject.GetComponent<CharacterController>()).enabled = true;
				activeAudioReverbFilter = ((Component)activeAudioListener).GetComponent<AudioReverbFilter>();
				((Behaviour)activeAudioReverbFilter).enabled = true;
				ChangeAudioListenerToObject(((Component)gameplayCamera).gameObject);
				if ((Object)(object)playerBodyAnimator.runtimeAnimatorController != (Object)(object)playersManager.localClientAnimatorController)
				{
					playerBodyAnimator.runtimeAnimatorController = playersManager.localClientAnimatorController;
					AnimatorStateInfo currentAnimatorStateInfo = playerBodyAnimator.GetCurrentAnimatorStateInfo(5);
					if (!((AnimatorStateInfo)(ref currentAnimatorStateInfo)).IsTag("notInSpecialAnim"))
					{
						playerBodyAnimator.SetTrigger("SA_stopAnimation");
					}
				}
				if (justConnected)
				{
					justConnected = false;
					ConnectClientToPlayerObject();
				}
				SpawnPlayerAnimation();
				Debug.Log((object)("!!!! ENABLING CAMERA FOR PLAYER: " + ((Object)((Component)this).gameObject).name));
				Debug.Log((object)$"!!!! connectedPlayersAmount: {playersManager.connectedPlayersAmount}");
			}
			hasBegunSpectating = false;
			playerHudUIContainer.rotation = Quaternion.Lerp(playerHudUIContainer.rotation, playerHudBaseRotation.rotation, 24f * Time.deltaTime);
			SetNightVisionEnabled(isNotLocalClient: false);
			timeSinceFearLevelUp += Time.deltaTime;
			ForceTurnTowardsTarget();
			if (inTerminalMenu)
			{
				targetFOV = 60f;
			}
			else if (IsInspectingItem)
			{
				((RigConstraint<ChainIKConstraintJob, ChainIKConstraintData, ChainIKConstraintJobBinder<ChainIKConstraintData>>)(object)rightArmProceduralRig).weight = Mathf.Lerp(((RigConstraint<ChainIKConstraintJob, ChainIKConstraintData, ChainIKConstraintJobBinder<ChainIKConstraintData>>)(object)rightArmProceduralRig).weight, 1f, 25f * Time.deltaTime);
				targetFOV = 46f;
			}
			else
			{
				((RigConstraint<ChainIKConstraintJob, ChainIKConstraintData, ChainIKConstraintJobBinder<ChainIKConstraintData>>)(object)rightArmProceduralRig).weight = Mathf.Lerp(((RigConstraint<ChainIKConstraintJob, ChainIKConstraintData, ChainIKConstraintJobBinder<ChainIKConstraintData>>)(object)rightArmProceduralRig).weight, 0f, 25f * Time.deltaTime);
				if (isSprinting)
				{
					targetFOV = 68f;
				}
				else
				{
					targetFOV = 66f;
				}
			}
			gameplayCamera.fieldOfView = Mathf.Lerp(gameplayCamera.fieldOfView, targetFOV, 6f * Time.deltaTime);
			moveInputVector = IngamePlayerSettings.Instance.playerInput.actions.FindAction("Move", false).ReadValue<Vector2>();
			if (((Vector2)(ref moveInputVector)).magnitude > 0.2f)
			{
				((UnityEvent<PlayerControllerB>)StartOfRound.Instance.PlayerMoveInputEvent).Invoke(this);
			}
			float num = IngamePlayerSettings.Instance.playerInput.actions.FindAction("Sprint", false).ReadValue<float>();
			if (quickMenuManager.isMenuOpen || isTypingChat || disableMoveInput || (inSpecialInteractAnimation && !isClimbingLadder && !inShockingMinigame))
			{
				moveInputVector = Vector2.zero;
			}
			SetFaceUnderwaterFilters();
			if (isWalking)
			{
				if (isFreeCamera || ((Vector2)(ref moveInputVector)).sqrMagnitude <= 0.19f || (inSpecialInteractAnimation && !isClimbingLadder && !inShockingMinigame))
				{
					isWalking = false;
					isSprinting = false;
					playerBodyAnimator.SetBool("Walking", false);
					playerBodyAnimator.SetBool("Sprinting", false);
					playerBodyAnimator.SetBool("Sideways", false);
				}
				else if (num > 0.3f && movementHinderedPrev <= 0 && !criticallyInjured && sprintMeter > 0.1f)
				{
					if (!isSprinting && sprintMeter < 0.3f)
					{
						if (!isExhausted)
						{
							isExhausted = true;
						}
					}
					else
					{
						if (isCrouching)
						{
							Crouch(crouch: false);
						}
						isSprinting = true;
						playerBodyAnimator.SetBool("Sprinting", true);
					}
				}
				else
				{
					isSprinting = false;
					if (sprintMeter < 0.1f)
					{
						isExhausted = true;
					}
					playerBodyAnimator.SetBool("Sprinting", false);
				}
				if (isSprinting)
				{
					sprintMultiplier = Mathf.Lerp(sprintMultiplier, 2.25f, Time.deltaTime * 1f);
				}
				else
				{
					sprintMultiplier = Mathf.Lerp(sprintMultiplier, 1f, 10f * Time.deltaTime);
				}
				if (moveInputVector.y < 0.2f && moveInputVector.y > -0.2f && !inSpecialInteractAnimation)
				{
					playerBodyAnimator.SetBool("Sideways", true);
					isSidling = true;
				}
				else
				{
					playerBodyAnimator.SetBool("Sideways", false);
					isSidling = false;
				}
				if (!inVehicleAnimation)
				{
					if (enteringSpecialAnimation)
					{
						playerBodyAnimator.SetFloat("animationSpeed", 1f);
					}
					else if (moveInputVector.y < 0.5f && moveInputVector.x < 0.5f)
					{
						playerBodyAnimator.SetFloat("animationSpeed", -1f * Mathf.Clamp(slopeModifier + 1f, 0.7f, 1.4f));
						movingForward = false;
					}
					else
					{
						playerBodyAnimator.SetFloat("animationSpeed", 1f * Mathf.Clamp(slopeModifier + 1f, 0.7f, 1.4f));
						movingForward = true;
					}
				}
			}
			else
			{
				if (enteringSpecialAnimation)
				{
					playerBodyAnimator.SetFloat("animationSpeed", 1f);
				}
				else if (isClimbingLadder)
				{
					playerBodyAnimator.SetFloat("animationSpeed", 0f);
				}
				if (!isFreeCamera && ((Vector2)(ref moveInputVector)).sqrMagnitude >= 0.19f && (!inSpecialInteractAnimation || isClimbingLadder || inShockingMinigame))
				{
					isWalking = true;
					playerBodyAnimator.SetBool("Walking", true);
				}
			}
			if (performingEmote && !CheckConditionsForEmote())
			{
				performingEmote = false;
				StopPerformingEmoteServerRpc();
				timeSinceStartingEmote = 0f;
			}
			timeSinceStartingEmote += Time.deltaTime;
			playerBodyAnimator.SetBool("hinderedMovement", isMovementHindered > 0);
			Vector3 positionOffset;
			if (sourcesCausingSinking == 0)
			{
				if (isSinking)
				{
					isSinking = false;
					StopSinkingServerRpc();
				}
			}
			else
			{
				if (isSinking)
				{
					GetCurrentMaterialStandingOn();
					if (!CheckConditionsForSinkingInQuicksand())
					{
						isSinking = false;
						StopSinkingServerRpc();
					}
				}
				else if (!isSinking && CheckConditionsForSinkingInQuicksand())
				{
					isSinking = true;
					StartSinkingServerRpc(sinkingSpeedMultiplier, statusEffectAudioIndex);
				}
				if (sinkingValue >= 1f)
				{
					Vector3 zero = Vector3.zero;
					positionOffset = default(Vector3);
					KillPlayer(zero, spawnBody: false, CauseOfDeath.Suffocation, 0, positionOffset);
				}
				else if (sinkingValue > 0.5f)
				{
					Crouch(crouch: false);
				}
			}
			if (isCrouching)
			{
				thisController.center = Vector3.Lerp(thisController.center, new Vector3(thisController.center.x, 0.72f, thisController.center.z), 8f * Time.deltaTime);
				thisController.height = Mathf.Lerp(thisController.height, 1.5f, 8f * Time.deltaTime);
			}
			else
			{
				crouchMeter = Mathf.Max(crouchMeter - Time.deltaTime * 2f, 0f);
				thisController.center = Vector3.Lerp(thisController.center, new Vector3(thisController.center.x, 1.28f, thisController.center.z), 8f * Time.deltaTime);
				thisController.height = Mathf.Lerp(thisController.height, 2.5f, 8f * Time.deltaTime);
			}
			if (isFreeCamera)
			{
				float num2 = movementSpeed / 1.75f;
				if (num > 0.5f)
				{
					num2 *= 5f;
				}
				Vector3 val = (((Component)playersManager.freeCinematicCameraTurnCompass).transform.right * moveInputVector.x + ((Component)playersManager.freeCinematicCameraTurnCompass).transform.forward * moveInputVector.y) * num2;
				Transform transform = ((Component)playersManager.freeCinematicCameraTurnCompass).transform;
				transform.position += val * Time.deltaTime;
				((Component)StartOfRound.Instance.freeCinematicCamera).transform.position = Vector3.Lerp(((Component)StartOfRound.Instance.freeCinematicCamera).transform.position, ((Component)StartOfRound.Instance.freeCinematicCameraTurnCompass).transform.position, 3f * Time.deltaTime);
				((Component)StartOfRound.Instance.freeCinematicCamera).transform.rotation = Quaternion.Slerp(((Component)StartOfRound.Instance.freeCinematicCamera).transform.rotation, StartOfRound.Instance.freeCinematicCameraTurnCompass.rotation, 3f * Time.deltaTime);
			}
			if (disabledJetpackControlsThisFrame)
			{
				disabledJetpackControlsThisFrame = false;
			}
			if (jetpackControls)
			{
				if (disablingJetpackControls && thisController.isGrounded)
				{
					disabledJetpackControlsThisFrame = true;
					DisableJetpackControlsLocally();
					DisableJetpackModeServerRpc();
				}
				else if (!thisController.isGrounded)
				{
					if (!startedJetpackControls)
					{
						startedJetpackControls = true;
						jetpackTurnCompass.rotation = ((Component)this).transform.rotation;
					}
					thisController.radius = Mathf.Lerp(thisController.radius, 1.25f, 10f * Time.deltaTime);
					Quaternion rotation = jetpackTurnCompass.rotation;
					jetpackTurnCompass.Rotate(new Vector3(0f, 0f, 0f - moveInputVector.x) * (180f * Time.deltaTime), (Space)1);
					if (maxJetpackAngle != -1f && Vector3.Angle(jetpackTurnCompass.up, Vector3.up) > maxJetpackAngle)
					{
						jetpackTurnCompass.rotation = rotation;
					}
					rotation = jetpackTurnCompass.rotation;
					jetpackTurnCompass.Rotate(new Vector3(moveInputVector.y, 0f, 0f) * (180f * Time.deltaTime), (Space)1);
					if (maxJetpackAngle != -1f && Vector3.Angle(jetpackTurnCompass.up, Vector3.up) > maxJetpackAngle)
					{
						jetpackTurnCompass.rotation = rotation;
					}
					if (jetpackRandomIntensity != -1f)
					{
						rotation = jetpackTurnCompass.rotation;
						Vector3 val2 = default(Vector3);
						((Vector3)(ref val2))._002Ector(Mathf.Clamp(Random.Range(0f - jetpackRandomIntensity, jetpackRandomIntensity), 0f - maxJetpackAngle, maxJetpackAngle), Mathf.Clamp(Random.Range(0f - jetpackRandomIntensity, jetpackRandomIntensity), 0f - maxJetpackAngle, maxJetpackAngle), Mathf.Clamp(Random.Range(0f - jetpackRandomIntensity, jetpackRandomIntensity), 0f - maxJetpackAngle, maxJetpackAngle));
						jetpackTurnCompass.Rotate(val2 * Time.deltaTime, (Space)1);
						if (maxJetpackAngle != -1f && Vector3.Angle(jetpackTurnCompass.up, Vector3.up) > maxJetpackAngle)
						{
							jetpackTurnCompass.rotation = rotation;
						}
					}
					((Component)this).transform.rotation = Quaternion.Slerp(((Component)this).transform.rotation, jetpackTurnCompass.rotation, 8f * Time.deltaTime);
				}
			}
			else if (!isClimbingLadder)
			{
				Vector3 localEulerAngles = ((Component)this).transform.localEulerAngles;
				localEulerAngles.x = Mathf.LerpAngle(localEulerAngles.x, 0f, 15f * Time.deltaTime);
				localEulerAngles.z = Mathf.LerpAngle(localEulerAngles.z, 0f, 15f * Time.deltaTime);
				((Component)this).transform.localEulerAngles = localEulerAngles;
			}
			if (!inSpecialInteractAnimation || inShockingMinigame || StartOfRound.Instance.suckingPlayersOutOfShip)
			{
				if (isFreeCamera)
				{
					moveInputVector = Vector2.zero;
				}
				CalculateGroundNormal();
				float num3 = movementSpeed / carryWeight;
				if (sinkingValue > 0.73f)
				{
					num3 = 0f;
				}
				else
				{
					if (isCrouching)
					{
						num3 /= 1.5f;
					}
					else if (criticallyInjured && !isCrouching)
					{
						num3 *= limpMultiplier;
					}
					if (isSpeedCheating)
					{
						num3 *= 15f;
					}
					if (movementHinderedPrev > 0)
					{
						num3 /= 2f * hinderedMultiplier;
					}
					if (drunkness > 0f)
					{
						num3 *= StartOfRound.Instance.drunknessSpeedEffect.Evaluate(drunkness) / 5f + 1f;
					}
					if (!isCrouching && crouchMeter > 1.2f)
					{
						num3 *= 0.5f;
					}
					if (!isCrouching)
					{
						float num4 = Vector3.Dot(playerGroundNormal, walkForce);
						if (num4 > 0.05f)
						{
							slopeModifier = Mathf.MoveTowards(slopeModifier, num4, (slopeModifierSpeed + 0.45f) * Time.deltaTime);
						}
						else
						{
							slopeModifier = Mathf.MoveTowards(slopeModifier, num4, slopeModifierSpeed / 2f * Time.deltaTime);
						}
						num3 = Mathf.Max(num3 * 0.8f, num3 + slopeIntensity * slopeModifier);
					}
				}
				if (isTypingChat || (jetpackControls && !thisController.isGrounded) || StartOfRound.Instance.suckingPlayersOutOfShip)
				{
					moveInputVector = Vector2.zero;
				}
				Vector3 val3 = default(Vector3);
				((Vector3)(ref val3))._002Ector(0f, 0f, 0f);
				int num5 = Physics.OverlapSphereNonAlloc(((Component)this).transform.position, 0.65f, nearByPlayers, StartOfRound.Instance.playersMask);
				for (int i = 0; i < num5; i++)
				{
					val3 += Vector3.Normalize((((Component)this).transform.position - ((Component)nearByPlayers[i]).transform.position) * 100f) * 1.2f;
				}
				int num6 = Physics.OverlapSphereNonAlloc(((Component)this).transform.position, 1.25f, nearByPlayers, 524288);
				for (int j = 0; j < num6; j++)
				{
					EnemyAICollisionDetect component = ((Component)nearByPlayers[j]).gameObject.GetComponent<EnemyAICollisionDetect>();
					if ((Object)(object)component != (Object)null && (Object)(object)component.mainScript != (Object)null && !component.mainScript.isEnemyDead && Vector3.Distance(((Component)this).transform.position, ((Component)nearByPlayers[j]).transform.position) < component.mainScript.enemyType.pushPlayerDistance)
					{
						val3 += Vector3.Normalize((((Component)this).transform.position - ((Component)nearByPlayers[j]).transform.position) * 100f) * component.mainScript.enemyType.pushPlayerForce;
					}
				}
				float num7 = 1f;
				num7 = ((isFallingFromJump || isFallingNoJump) ? 1.33f : ((drunkness > 0.3f) ? Mathf.Clamp(Mathf.Abs(drunkness - 2.25f), 0.3f, 2.5f) : ((!isCrouching && crouchMeter > 1f) ? 15f : ((!isSprinting) ? (10f / carryWeight) : (5f / (carryWeight * 1.5f))))));
				walkForce = Vector3.MoveTowards(walkForce, ((Component)this).transform.right * moveInputVector.x + ((Component)this).transform.forward * moveInputVector.y, num7 * Time.deltaTime);
				Vector3 val4 = walkForce * num3 * sprintMultiplier + new Vector3(0f, fallValue, 0f) + val3;
				val4 += externalForces;
				if (((Vector3)(ref externalForceAutoFade)).magnitude > 0.05f)
				{
					val4 += externalForceAutoFade;
					externalForceAutoFade = Vector3.Lerp(externalForceAutoFade, Vector3.zero, 2f * Time.deltaTime);
				}
				if (isPlayerSliding && thisController.isGrounded)
				{
					playerSlidingTimer += Time.deltaTime;
					if (slideFriction > maxSlideFriction)
					{
						slideFriction -= 35f * Time.deltaTime;
					}
					((Vector3)(ref val4))._002Ector(val4.x + (1f - playerGroundNormal.y) * playerGroundNormal.x * (1f - slideFriction), val4.y, val4.z + (1f - playerGroundNormal.y) * playerGroundNormal.z * (1f - slideFriction));
				}
				else
				{
					playerSlidingTimer = 0f;
					slideFriction = 0f;
				}
				positionOffset = thisController.velocity;
				_ = ((Vector3)(ref positionOffset)).magnitude;
				thisController.Move(val4 * Time.deltaTime);
				if (!inSpecialInteractAnimation || inShockingMinigame)
				{
					if (!thisController.isGrounded)
					{
						if (jetpackControls && !disablingJetpackControls)
						{
							fallValue = Mathf.MoveTowards(fallValue, jetpackCounteractiveForce, 9f * Time.deltaTime);
							fallValueUncapped = -8f;
						}
						else
						{
							fallValue = Mathf.Clamp(fallValue - 38f * Time.deltaTime, -150f, jumpForce);
							if (Mathf.Abs(externalForceAutoFade.y) - Mathf.Abs(fallValue) < 5f)
							{
								if (disablingJetpackControls)
								{
									fallValueUncapped -= 26f * Time.deltaTime;
								}
								else
								{
									fallValueUncapped -= 38f * Time.deltaTime;
								}
							}
						}
						if (!isJumping && !isFallingFromJump)
						{
							if (!isFallingNoJump)
							{
								isFallingNoJump = true;
								fallValue = -7f;
								fallValueUncapped = -7f;
							}
							else if (fallValue < -20f)
							{
								isCrouching = false;
								playerBodyAnimator.SetBool("crouching", false);
								playerBodyAnimator.SetBool("FallNoJump", true);
							}
						}
						if (fallValueUncapped < -35f)
						{
							takingFallDamage = true;
						}
					}
					else
					{
						movementHinderedPrev = isMovementHindered;
						if (!isJumping)
						{
							if (isFallingNoJump)
							{
								isFallingNoJump = false;
								if (!isCrouching && fallValue < -9f)
								{
									playerBodyAnimator.SetTrigger("ShortFallLanding");
								}
								PlayerHitGroundEffects();
							}
							if (!isFallingFromJump)
							{
								fallValue = -7f - Mathf.Clamp(12f * slopeModifier, 0f, 100f);
								fallValueUncapped = -7f - Mathf.Clamp(12f * slopeModifier, 0f, 100f);
							}
						}
						playerBodyAnimator.SetBool("FallNoJump", false);
					}
				}
				externalForces = Vector3.zero;
				if (!teleportingThisFrame && teleportedLastFrame)
				{
					teleportedLastFrame = false;
				}
				if (jetpackControls || disablingJetpackControls)
				{
					if (!teleportingThisFrame && !inSpecialInteractAnimation && !enteringSpecialAnimation && !isClimbingLadder && (StartOfRound.Instance.timeSinceRoundStarted > 1f || (Object)(object)StartOfRound.Instance.testRoom != (Object)null))
					{
						positionOffset = thisController.velocity;
						float magnitude = ((Vector3)(ref positionOffset)).magnitude;
						if (getAverageVelocityInterval <= 0f)
						{
							getAverageVelocityInterval = 0.04f;
							velocityAverageCount++;
							if (velocityAverageCount > velocityMovingAverageLength)
							{
								averageVelocity += (magnitude - averageVelocity) / (float)(velocityMovingAverageLength + 1);
							}
							else
							{
								averageVelocity += magnitude;
								if (velocityAverageCount == velocityMovingAverageLength)
								{
									averageVelocity /= velocityAverageCount;
								}
							}
						}
						else
						{
							getAverageVelocityInterval -= Time.deltaTime;
						}
						Debug.Log((object)$"Average velocity: {averageVelocity}");
						if (timeSinceTakingGravityDamage > 0.6f && velocityAverageCount > 4)
						{
							float num8 = Vector3.Angle(((Component)this).transform.up, Vector3.up);
							if (Physics.CheckSphere(((Component)gameplayCamera).transform.position, 0.5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) || (num8 > 65f && Physics.CheckSphere(lowerSpine.position, 0.5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)))
							{
								if (averageVelocity > 17f)
								{
									Debug.Log((object)"Take damage a");
									timeSinceTakingGravityDamage = 0f;
									DamagePlayer(Mathf.Clamp(85, 20, 100), hasDamageSFX: true, callRPC: true, CauseOfDeath.Gravity, 0, fallDamage: true, Vector3.ClampMagnitude(velocityLastFrame, 50f));
								}
								else if (averageVelocity > 9f)
								{
									Debug.Log((object)"Take damage b");
									DamagePlayer(Mathf.Clamp(30, 20, 100), hasDamageSFX: true, callRPC: true, CauseOfDeath.Gravity, 0, fallDamage: true, Vector3.ClampMagnitude(velocityLastFrame, 50f));
									timeSinceTakingGravityDamage = 0.35f;
								}
								else if (num8 > 60f && averageVelocity > 6f)
								{
									Debug.Log((object)"Take damage c");
									DamagePlayer(Mathf.Clamp(30, 20, 100), hasDamageSFX: true, callRPC: true, CauseOfDeath.Gravity, 0, fallDamage: true, Vector3.ClampMagnitude(velocityLastFrame, 50f));
									timeSinceTakingGravityDamage = 0f;
								}
							}
						}
						else
						{
							timeSinceTakingGravityDamage += Time.deltaTime;
						}
						velocityLastFrame = thisController.velocity;
						previousFrameDeltaTime = Time.deltaTime;
					}
					else
					{
						teleportingThisFrame = false;
					}
				}
				else
				{
					averageVelocity = 0f;
					velocityAverageCount = 0;
					timeSinceTakingGravityDamage = 0f;
				}
				isPlayerSliding = Vector3.Angle(Vector3.up, playerGroundNormal) >= thisController.slopeLimit;
			}
			else if (isClimbingLadder)
			{
				Vector3 val5 = thisPlayerBody.up;
				Vector3 val6 = ((Component)gameplayCamera).transform.position + thisPlayerBody.up * 0.07f;
				positionOffset = externalForces + externalForceAutoFade;
				if (((Vector3)(ref positionOffset)).magnitude > 8f)
				{
					CancelSpecialTriggerAnimations();
				}
				externalForces = Vector3.zero;
				externalForceAutoFade = Vector3.Lerp(externalForceAutoFade, Vector3.zero, 5f * Time.deltaTime);
				if (moveInputVector.y < 0f)
				{
					val5 = -thisPlayerBody.up;
					val6 = ((Component)this).transform.position;
				}
				if (!Physics.Raycast(val6, val5, 0.15f, StartOfRound.Instance.allPlayersCollideWithMask, (QueryTriggerInteraction)1))
				{
					Transform transform2 = ((Component)thisPlayerBody).transform;
					transform2.position += thisPlayerBody.up * (moveInputVector.y * climbSpeed * Time.deltaTime);
				}
			}
			if (inVehicleAnimation)
			{
				positionOffset = externalForces + externalForceAutoFade;
				if (((Vector3)(ref positionOffset)).magnitude > 50f)
				{
					CancelSpecialTriggerAnimations();
				}
			}
			teleportingThisFrame = false;
			playerEye.position = ((Component)gameplayCamera).transform.position;
			playerEye.rotation = ((Component)gameplayCamera).transform.rotation;
			if (isHoldingObject && (Object)(object)currentlyHeldObjectServer == (Object)null)
			{
				DropAllHeldItems();
			}
			if (((Object)(object)NetworkManager.Singleton != (Object)null && !((NetworkBehaviour)this).IsServer) || (!isTestingPlayer && playersManager.connectedPlayersAmount > 0) || oldConnectedPlayersAmount >= 1)
			{
				updatePlayerLookInterval += Time.deltaTime;
				UpdatePlayerAnimationsToOtherClients(moveInputVector);
			}
			ClickHoldInteraction();
		}
		else
		{
			if (!isCameraDisabled)
			{
				isCameraDisabled = true;
				((Behaviour)gameplayCamera).enabled = false;
				((Behaviour)visorCamera).enabled = false;
				((Renderer)thisPlayerModel).shadowCastingMode = (ShadowCastingMode)1;
				((Renderer)thisPlayerModelArms).enabled = false;
				((Renderer)mapRadarDirectionIndicator).enabled = false;
				((Collider)((Component)this).gameObject.GetComponent<CharacterController>()).enabled = false;
				if ((Object)(object)playerBodyAnimator.runtimeAnimatorController != (Object)(object)playersManager.otherClientsAnimatorController)
				{
					playerBodyAnimator.runtimeAnimatorController = playersManager.otherClientsAnimatorController;
				}
				if (!isPlayerDead)
				{
					for (int k = 0; k < playersManager.allPlayerObjects.Length && !((Behaviour)playersManager.allPlayerObjects[k].GetComponent<PlayerControllerB>().gameplayCamera).enabled; k++)
					{
						if (k == 4)
						{
							Debug.LogWarning((object)"!!! No cameras are enabled !!!");
							((Behaviour)playerScreen).enabled = false;
						}
					}
				}
				if (Object.op_Implicit((Object)(object)((Component)this).gameObject.GetComponent<Rigidbody>()))
				{
					((Component)this).gameObject.GetComponent<Rigidbody>().interpolation = (RigidbodyInterpolation)0;
				}
				Debug.Log((object)("!!!! DISABLING CAMERA FOR PLAYER: " + ((Object)((Component)this).gameObject).name));
				Debug.Log((object)$"!!!! connectedPlayersAmount: {playersManager.connectedPlayersAmount}");
			}
			SetNightVisionEnabled(isNotLocalClient: true);
			if (!isTestingPlayer && !isPlayerDead && isPlayerControlled)
			{
				if (!disableSyncInAnimation && !inVehicleAnimation)
				{
					if (snapToServerPosition)
					{
						((Component)this).transform.localPosition = Vector3.Lerp(((Component)this).transform.localPosition, serverPlayerPosition, 16f * Time.deltaTime);
					}
					else
					{
						float num9 = 8f;
						if (jetpackControls)
						{
							num9 = 15f;
						}
						float num10 = Mathf.Clamp(num9 * Vector3.Distance(((Component)this).transform.localPosition, serverPlayerPosition), 0.9f, 300f);
						((Component)this).transform.localPosition = Vector3.MoveTowards(((Component)this).transform.localPosition, serverPlayerPosition, num10 * Time.deltaTime);
					}
				}
				if (inVehicleAnimation)
				{
					((Component)gameplayCamera).transform.localEulerAngles = new Vector3(Mathf.LerpAngle(((Component)gameplayCamera).transform.localEulerAngles.x, syncFullCameraRotation.x, 14f * Time.deltaTime), Mathf.LerpAngle(((Component)gameplayCamera).transform.localEulerAngles.y, syncFullCameraRotation.y, 14f * Time.deltaTime), Mathf.LerpAngle(((Component)gameplayCamera).transform.localEulerAngles.z, syncFullCameraRotation.z, 14f * Time.deltaTime));
				}
				else
				{
					((Component)gameplayCamera).transform.localEulerAngles = new Vector3(Mathf.LerpAngle(((Component)gameplayCamera).transform.localEulerAngles.x, targetLookRot, 14f * Time.deltaTime), 0f, 0f);
				}
				if (jetpackControls || disablingJetpackControls || isClimbingLadder)
				{
					if (!disableSyncInAnimation && !inVehicleAnimation)
					{
						((Component)this).transform.rotation = Quaternion.Lerp(Quaternion.Euler(((Component)this).transform.eulerAngles), Quaternion.Euler(syncFullRotation), 8f * Time.deltaTime);
					}
				}
				else
				{
					syncFullRotation = ((Component)this).transform.eulerAngles;
					if (!disableSyncInAnimation && !inVehicleAnimation)
					{
						((Component)this).transform.localEulerAngles = new Vector3(((Component)this).transform.localEulerAngles.x, Mathf.LerpAngle(((Component)this).transform.localEulerAngles.y, targetYRot, 14f * Time.deltaTime), ((Component)this).transform.localEulerAngles.z);
					}
					if (!inSpecialInteractAnimation && !disableSyncInAnimation && !inVehicleAnimation)
					{
						Vector3 localEulerAngles2 = ((Component)this).transform.localEulerAngles;
						localEulerAngles2.x = Mathf.LerpAngle(localEulerAngles2.x, 0f, 25f * Time.deltaTime);
						localEulerAngles2.z = Mathf.LerpAngle(localEulerAngles2.z, 0f, 25f * Time.deltaTime);
						((Component)this).transform.localEulerAngles = localEulerAngles2;
					}
				}
				playerEye.position = ((Component)gameplayCamera).transform.position;
				playerEye.localEulerAngles = new Vector3(targetLookRot, 0f, 0f);
				playerEye.eulerAngles = new Vector3(playerEye.eulerAngles.x, targetYRot, playerEye.eulerAngles.z);
			}
			else if ((isPlayerDead || !isPlayerControlled) && setPositionOfDeadPlayer)
			{
				((Component)this).transform.position = playersManager.notSpawnedPosition.position;
			}
			if (isInGameOverAnimation > 0f && (Object)(object)deadBody != (Object)null && ((Component)deadBody).gameObject.activeSelf)
			{
				isInGameOverAnimation -= Time.deltaTime;
			}
			else if (!hasBegunSpectating)
			{
				isInGameOverAnimation = 0f;
				hasBegunSpectating = true;
			}
		}
		timeSincePlayerMoving += Time.deltaTime;
		timeSinceMakingLoudNoise += Time.deltaTime;
		if (!inSpecialInteractAnimation)
		{
			if (playingQuickSpecialAnimation)
			{
				specialAnimationWeight = 1f;
			}
			else
			{
				specialAnimationWeight = Mathf.Lerp(specialAnimationWeight, 0f, Time.deltaTime * 12f);
			}
			if (!localArmsMatchCamera)
			{
				localArmsTransform.position = playerModelArmsMetarig.position + playerModelArmsMetarig.forward * -0.445f;
				playerModelArmsMetarig.rotation = Quaternion.Lerp(playerModelArmsMetarig.rotation, localArmsRotationTarget.rotation, 15f * Time.deltaTime);
			}
		}
		else
		{
			if (((!isClimbingLadder && !inShockingMinigame) || freeRotationInInteractAnimation) && !clampLooking && !inVehicleAnimation)
			{
				cameraUp = Mathf.Lerp(cameraUp, 0f, 5f * Time.deltaTime);
				((Component)gameplayCamera).transform.localEulerAngles = new Vector3(cameraUp, ((Component)gameplayCamera).transform.localEulerAngles.y, ((Component)gameplayCamera).transform.localEulerAngles.z);
			}
			specialAnimationWeight = Mathf.Lerp(specialAnimationWeight, 1f, Time.deltaTime * 20f);
			playerModelArmsMetarig.localEulerAngles = new Vector3(-90f, 0f, 0f);
		}
		interactRay = new Ray(((Component)this).transform.position + Vector3.up * 2.3f, ((Component)this).transform.forward);
		if (doingUpperBodyEmote > 0f || (!twoHanded && ((Object)(object)currentlyHeldObjectServer == (Object)null || !currentlyHeldObjectServer.itemProperties.disableHandsOnWall) && Physics.Raycast(interactRay, ref hit, 0.53f, walkableSurfacesNoPlayersMask, (QueryTriggerInteraction)1)))
		{
			doingUpperBodyEmote -= Time.deltaTime;
			handsOnWallWeight = Mathf.Lerp(handsOnWallWeight, 1f, 15f * Time.deltaTime);
		}
		else
		{
			handsOnWallWeight = Mathf.Lerp(handsOnWallWeight, 0f, 15f * Time.deltaTime);
		}
		playerBodyAnimator.SetLayerWeight(playerBodyAnimator.GetLayerIndex("UpperBodyEmotes"), handsOnWallWeight);
		if (performingEmote)
		{
			emoteLayerWeight = Mathf.Lerp(emoteLayerWeight, 1f, 10f * Time.deltaTime);
		}
		else
		{
			emoteLayerWeight = Mathf.Lerp(emoteLayerWeight, 0f, 10f * Time.deltaTime);
		}
		playerBodyAnimator.SetLayerWeight(playerBodyAnimator.GetLayerIndex("EmotesNoArms"), emoteLayerWeight);
		meshContainer.position = Vector3.Lerp(((Component)this).transform.position, ((Component)this).transform.position - Vector3.up * 2.8f, StartOfRound.Instance.playerSinkingCurve.Evaluate(sinkingValue));
		if (isSinking && !inSpecialInteractAnimation && (Object)(object)inAnimationWithEnemy == (Object)null)
		{
			sinkingValue = Mathf.Clamp(sinkingValue + Time.deltaTime * sinkingSpeedMultiplier, 0f, 1f);
		}
		else
		{
			sinkingValue = Mathf.Clamp(sinkingValue - Time.deltaTime * 0.75f, 0f, 1f);
		}
		if (sinkingValue > 0.73f || isUnderwater)
		{
			if (!wasUnderwaterLastFrame)
			{
				wasUnderwaterLastFrame = true;
				if (!((NetworkBehaviour)this).IsOwner)
				{
					waterBubblesAudio.Play();
				}
			}
			voiceMuffledByEnemy = true;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				statusEffectAudio.volume = Mathf.Lerp(statusEffectAudio.volume, 0f, 4f * Time.deltaTime);
				if ((Object)(object)currentVoiceChatIngameSettings != (Object)null)
				{
					OccludeAudio component2 = ((Component)currentVoiceChatIngameSettings.voiceAudio).GetComponent<OccludeAudio>();
					component2.overridingLowPass = true;
					component2.lowPassOverride = 600f;
					waterBubblesAudio.volume = Mathf.Clamp(currentVoiceChatIngameSettings._playerState.Amplitude * 120f, 0f, 1f);
				}
				else
				{
					StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
				}
			}
			else if (sinkingValue > 0.73f)
			{
				HUDManager.Instance.sinkingCoveredFace = true;
			}
		}
		else if (((NetworkBehaviour)this).IsOwner)
		{
			HUDManager.Instance.sinkingCoveredFace = false;
		}
		else if (wasUnderwaterLastFrame)
		{
			waterBubblesAudio.Stop();
			if ((Object)(object)currentVoiceChatIngameSettings != (Object)null)
			{
				wasUnderwaterLastFrame = false;
				((Component)currentVoiceChatIngameSettings.voiceAudio).GetComponent<OccludeAudio>().overridingLowPass = false;
				voiceMuffledByEnemy = false;
			}
			else
			{
				StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
				StartOfRound.Instance.UpdatePlayerVoiceEffects();
			}
		}
		else
		{
			statusEffectAudio.volume = Mathf.Lerp(statusEffectAudio.volume, 1f, 4f * Time.deltaTime);
		}
		if ((Object)(object)activeAudioReverbFilter == (Object)null)
		{
			activeAudioReverbFilter = ((Component)activeAudioListener).GetComponent<AudioReverbFilter>();
			((Behaviour)activeAudioReverbFilter).enabled = true;
		}
		if ((Object)(object)reverbPreset != (Object)null && (Object)(object)GameNetworkManager.Instance != (Object)null && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null && (((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)this && (!isPlayerDead || StartOfRound.Instance.overrideSpectateCamera)) || ((Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript == (Object)(object)this && !StartOfRound.Instance.overrideSpectateCamera)))
		{
			activeAudioReverbFilter.dryLevel = Mathf.Lerp(activeAudioReverbFilter.dryLevel, reverbPreset.dryLevel, 15f * Time.deltaTime);
			activeAudioReverbFilter.roomLF = Mathf.Lerp(activeAudioReverbFilter.roomLF, reverbPreset.lowFreq, 15f * Time.deltaTime);
			activeAudioReverbFilter.roomHF = Mathf.Lerp(activeAudioReverbFilter.roomHF, reverbPreset.highFreq, 15f * Time.deltaTime);
			activeAudioReverbFilter.decayTime = Mathf.Lerp(activeAudioReverbFilter.decayTime, reverbPreset.decayTime, 15f * Time.deltaTime);
			activeAudioReverbFilter.room = Mathf.Lerp(activeAudioReverbFilter.room, reverbPreset.room, 15f * Time.deltaTime);
			SoundManager.Instance.SetEchoFilter(reverbPreset.hasEcho);
		}
		if (isHoldingObject || isGrabbingObjectAnimation || inShockingMinigame)
		{
			upperBodyAnimationsWeight = Mathf.Lerp(upperBodyAnimationsWeight, 1f, 25f * Time.deltaTime);
			playerBodyAnimator.SetLayerWeight(playerBodyAnimator.GetLayerIndex("HoldingItemsRightHand"), upperBodyAnimationsWeight);
			if (twoHandedAnimation || inShockingMinigame)
			{
				playerBodyAnimator.SetLayerWeight(playerBodyAnimator.GetLayerIndex("HoldingItemsBothHands"), upperBodyAnimationsWeight);
			}
			else
			{
				playerBodyAnimator.SetLayerWeight(playerBodyAnimator.GetLayerIndex("HoldingItemsBothHands"), Mathf.Abs(upperBodyAnimationsWeight - 1f));
			}
		}
		else
		{
			upperBodyAnimationsWeight = Mathf.Lerp(upperBodyAnimationsWeight, 0f, 25f * Time.deltaTime);
			playerBodyAnimator.SetLayerWeight(playerBodyAnimator.GetLayerIndex("HoldingItemsRightHand"), upperBodyAnimationsWeight);
			playerBodyAnimator.SetLayerWeight(playerBodyAnimator.GetLayerIndex("HoldingItemsBothHands"), upperBodyAnimationsWeight);
		}
		playerBodyAnimator.SetLayerWeight(playerBodyAnimator.GetLayerIndex("SpecialAnimations"), specialAnimationWeight);
		if (inSpecialInteractAnimation && !inShockingMinigame)
		{
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)cameraLookRig1).weight = Mathf.Lerp(((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)cameraLookRig1).weight, 0f, Time.deltaTime * 25f);
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)cameraLookRig2).weight = Mathf.Lerp(((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)cameraLookRig1).weight, 0f, Time.deltaTime * 25f);
		}
		else
		{
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)cameraLookRig1).weight = 0.45f;
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)cameraLookRig2).weight = 1f;
		}
		if (inVehicleAnimation)
		{
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)cameraLookRig1).weight = 0.33f;
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)cameraLookRig2).weight = 1f;
			((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)leftArmRigSecondary).weight = 1f;
			((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)rightArmRigSecondary).weight = 1f;
			((RigConstraint<ChainIKConstraintJob, ChainIKConstraintData, ChainIKConstraintJobBinder<ChainIKConstraintData>>)(object)leftArmRig).weight = 0f;
			((RigConstraint<ChainIKConstraintJob, ChainIKConstraintData, ChainIKConstraintJobBinder<ChainIKConstraintData>>)(object)rightArmRig).weight = 0f;
		}
		else
		{
			((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)leftArmRigSecondary).weight = 0f;
			((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)rightArmRigSecondary).weight = 0f;
			((RigConstraint<ChainIKConstraintJob, ChainIKConstraintData, ChainIKConstraintJobBinder<ChainIKConstraintData>>)(object)leftArmRig).weight = 1f;
			((RigConstraint<ChainIKConstraintJob, ChainIKConstraintData, ChainIKConstraintJobBinder<ChainIKConstraintData>>)(object)rightArmRig).weight = 1f;
		}
		if (isExhausted)
		{
			exhaustionEffectLerp = Mathf.Lerp(exhaustionEffectLerp, 1f, 10f * Time.deltaTime);
		}
		else
		{
			exhaustionEffectLerp = Mathf.Lerp(exhaustionEffectLerp, 0f, 10f * Time.deltaTime);
		}
		playerBodyAnimator.SetFloat("tiredAmount", exhaustionEffectLerp);
		if (isPlayerDead)
		{
			drunkness = 0f;
			drunknessInertia = 0f;
		}
		else
		{
			drunkness = Mathf.Clamp(drunkness + Time.deltaTime / 12f * drunknessSpeed * drunknessInertia, 0f, 1f);
			if (!increasingDrunknessThisFrame)
			{
				if (drunkness > 0f)
				{
					drunknessInertia = Mathf.Clamp(drunknessInertia - Time.deltaTime / 3f * drunknessSpeed / Mathf.Clamp(Mathf.Abs(drunknessInertia), 0.2f, 1f), -2.5f, 2.5f);
				}
				else
				{
					drunknessInertia = 0f;
				}
			}
			else
			{
				increasingDrunknessThisFrame = false;
			}
			float num11 = StartOfRound.Instance.drunknessSideEffect.Evaluate(drunkness);
			if (num11 > 0.15f)
			{
				SoundManager.Instance.playerVoicePitchTargets[playerClientId] = 1f + num11;
			}
			else
			{
				SoundManager.Instance.playerVoicePitchTargets[playerClientId] = 1f;
			}
		}
		smoothLookMultiplier = 25f * Mathf.Clamp(Mathf.Abs(drunkness - 1.5f), 0.15f, 1f);
		if (bleedingHeavily && bloodDropTimer >= 0f)
		{
			bloodDropTimer -= Time.deltaTime;
		}
		if (Physics.Raycast(lineOfSightCube.position, lineOfSightCube.forward, ref hit, 10f, playersManager.collidersAndRoomMask, (QueryTriggerInteraction)1))
		{
			lineOfSightCube.localScale = new Vector3(1.5f, 1.5f, ((RaycastHit)(ref hit)).distance);
		}
		else
		{
			lineOfSightCube.localScale = new Vector3(1.5f, 1.5f, 10f);
		}
		SetPlayerSanityLevel();
	}

	private void SetFaceUnderwaterFilters()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		if (isPlayerDead)
		{
			return;
		}
		if (isUnderwater && (Object)(object)underwaterCollider != (Object)null)
		{
			Bounds bounds = underwaterCollider.bounds;
			if (((Bounds)(ref bounds)).Contains(((Component)gameplayCamera).transform.position))
			{
				HUDManager.Instance.setUnderwaterFilter = true;
				statusEffectAudio.volume = Mathf.Lerp(statusEffectAudio.volume, 0f, 4f * Time.deltaTime);
				StartOfRound.Instance.drowningTimer -= Time.deltaTime / 10f;
				if (StartOfRound.Instance.drowningTimer < 0f)
				{
					StartOfRound.Instance.drowningTimer = 1f;
					KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Drowning);
				}
				else if (StartOfRound.Instance.drowningTimer <= 0.3f)
				{
					if (!StartOfRound.Instance.playedDrowningSFX)
					{
						StartOfRound.Instance.playedDrowningSFX = true;
						HUDManager.Instance.UIAudio.PlayOneShot(StartOfRound.Instance.HUDSystemAlertSFX);
					}
					HUDManager.Instance.DisplayStatusEffect("Oxygen critically low!");
				}
				goto IL_019b;
			}
		}
		statusEffectAudio.volume = Mathf.Lerp(statusEffectAudio.volume, 1f, 4f * Time.deltaTime);
		StartOfRound.Instance.playedDrowningSFX = false;
		StartOfRound.Instance.drowningTimer = Mathf.Clamp(StartOfRound.Instance.drowningTimer + Time.deltaTime, 0.1f, 1f);
		HUDManager.Instance.setUnderwaterFilter = false;
		goto IL_019b;
		IL_019b:
		if (syncUnderwaterInterval <= 0f)
		{
			if (HUDManager.Instance.setUnderwaterFilter)
			{
				if (!isFaceUnderwaterOnServer)
				{
					isFaceUnderwaterOnServer = true;
					SetFaceUnderwaterServerRpc();
				}
			}
			else if (isFaceUnderwaterOnServer)
			{
				isFaceUnderwaterOnServer = false;
				SetFaceOutOfWaterServerRpc();
			}
		}
		else
		{
			syncUnderwaterInterval = 0.5f;
		}
	}

	[ServerRpc]
	private void SetFaceUnderwaterServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1048203095u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1048203095u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetFaceUnderwaterClientRpc();
		}
	}

	[ClientRpc]
	private void SetFaceUnderwaterClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1284827260u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1284827260u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				isUnderwater = true;
			}
		}
	}

	[ServerRpc]
	private void SetFaceOutOfWaterServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3262284737u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3262284737u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetFaceOutOfWaterClientRpc();
		}
	}

	[ClientRpc]
	private void SetFaceOutOfWaterClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4067397557u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4067397557u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				isUnderwater = false;
			}
		}
	}

	public void IncreaseFearLevelOverTime(float amountMultiplier = 1f, float cap = 1f)
	{
		playersManager.fearLevelIncreasing = true;
		if (!(playersManager.fearLevel > cap))
		{
			playersManager.fearLevel += Time.deltaTime * amountMultiplier;
			if (playersManager.fearLevel > 0.6f && timeSinceFearLevelUp > 8f)
			{
				timeSinceFearLevelUp = 0f;
			}
		}
	}

	public void JumpToFearLevel(float targetFearLevel, bool onlyGoUp = true)
	{
		if (!onlyGoUp || !(targetFearLevel - playersManager.fearLevel < 0.05f))
		{
			playersManager.fearLevel = targetFearLevel;
			playersManager.fearLevelIncreasing = true;
			if (timeSinceFearLevelUp > 8f)
			{
				timeSinceFearLevelUp = 0f;
			}
		}
	}

	private void SetPlayerSanityLevel()
	{
		if (StartOfRound.Instance.inShipPhase || !TimeOfDay.Instance.currentDayTimeStarted)
		{
			insanityLevel = 0f;
			return;
		}
		if (!NearOtherPlayers(this, 17f) && !PlayerIsHearingOthersThroughWalkieTalkie(this))
		{
			if (isInsideFactory)
			{
				insanitySpeedMultiplier = 0.8f;
			}
			else if (isInHangarShipRoom)
			{
				insanitySpeedMultiplier = 0.2f;
			}
			else if (StartOfRound.Instance.connectedPlayersAmount == 0)
			{
				insanitySpeedMultiplier = -2f;
			}
			else if (TimeOfDay.Instance.dayMode >= DayMode.Sundown)
			{
				insanitySpeedMultiplier = 0.5f;
			}
			else
			{
				insanitySpeedMultiplier = 0.3f;
			}
			isPlayerAlone = true;
		}
		else
		{
			insanitySpeedMultiplier = -3f;
			isPlayerAlone = false;
		}
		if (insanitySpeedMultiplier < 0f)
		{
			insanityLevel = Mathf.MoveTowards(insanityLevel, 0f, Time.deltaTime * (0f - insanitySpeedMultiplier));
			return;
		}
		if (insanityLevel > maxInsanityLevel)
		{
			insanityLevel = Mathf.MoveTowards(insanityLevel, maxInsanityLevel, Time.deltaTime * 2f);
			return;
		}
		if (StartOfRound.Instance.connectedPlayersAmount == 0)
		{
			insanitySpeedMultiplier /= 2f;
		}
		insanityLevel = Mathf.MoveTowards(insanityLevel, maxInsanityLevel, Time.deltaTime * insanitySpeedMultiplier * 0.6f);
	}

	private void SetNightVisionEnabled(bool isNotLocalClient)
	{
		((Behaviour)nightVision).enabled = false;
		if (!((Object)(object)GameNetworkManager.Instance == (Object)null) && !((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && (!isNotLocalClient || (Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript == (Object)(object)this) && isInsideFactory)
		{
			((Behaviour)nightVision).enabled = true;
		}
	}

	public void ClickHoldInteraction()
	{
		if (!(isHoldingInteract = IngamePlayerSettings.Instance.playerInput.actions.FindAction("Interact", false).IsPressed()))
		{
			StopHoldInteractionOnTrigger();
		}
		else if ((Object)(object)hoveringOverTrigger == (Object)null || !hoveringOverTrigger.interactable)
		{
			StopHoldInteractionOnTrigger();
		}
		else if ((Object)(object)hoveringOverTrigger == (Object)null || !((Component)hoveringOverTrigger).gameObject.activeInHierarchy || !hoveringOverTrigger.holdInteraction || hoveringOverTrigger.currentCooldownValue > 0f || (isHoldingObject && !hoveringOverTrigger.oneHandedItemAllowed) || (twoHanded && !hoveringOverTrigger.twoHandedItemAllowed))
		{
			StopHoldInteractionOnTrigger();
		}
		else if (isGrabbingObjectAnimation || isTypingChat || (inSpecialInteractAnimation && !hoveringOverTrigger.allowUseWhileInAnimation) || throwingObject)
		{
			StopHoldInteractionOnTrigger();
		}
		else if (!HUDManager.Instance.HoldInteractionFill(hoveringOverTrigger.timeToHold, hoveringOverTrigger.timeToHoldSpeedMultiplier))
		{
			hoveringOverTrigger.HoldInteractNotFilled();
		}
		else
		{
			hoveringOverTrigger.Interact(thisPlayerBody);
		}
	}

	private void StopHoldInteractionOnTrigger()
	{
		HUDManager.Instance.holdFillAmount = 0f;
		if ((Object)(object)previousHoveringOverTrigger != (Object)null)
		{
			previousHoveringOverTrigger.StopInteraction();
		}
		if ((Object)(object)hoveringOverTrigger != (Object)null)
		{
			hoveringOverTrigger.StopInteraction();
		}
	}

	public void CancelSpecialTriggerAnimations()
	{
		Terminal terminal = Object.FindObjectOfType<Terminal>();
		if (terminal.terminalInUse)
		{
			terminal.QuitTerminal();
		}
		else if ((Object)(object)currentTriggerInAnimationWith != (Object)null)
		{
			currentTriggerInAnimationWith.StopSpecialAnimation();
		}
	}

	public void TeleportPlayer(Vector3 pos, bool withRotation = false, float rot = 0f, bool allowInteractTrigger = false, bool enableController = true)
	{
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)("Called teleport function on " + ((Object)((Component)this).gameObject).name));
		if (((NetworkBehaviour)this).IsOwner && !allowInteractTrigger)
		{
			CancelSpecialTriggerAnimations();
		}
		else if (!allowInteractTrigger && (Object)(object)currentTriggerInAnimationWith != (Object)null)
		{
			((UnityEvent<PlayerControllerB>)currentTriggerInAnimationWith.onCancelAnimation).Invoke(this);
			currentTriggerInAnimationWith.SetInteractTriggerNotInAnimation();
		}
		if (Object.op_Implicit((Object)(object)inAnimationWithEnemy))
		{
			inAnimationWithEnemy.CancelSpecialAnimationWithPlayer();
		}
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).Invoke(this);
		if (withRotation)
		{
			targetYRot = rot;
			((Component)this).transform.localEulerAngles = new Vector3(0f, targetYRot, 0f);
		}
		serverPlayerPosition = pos;
		((Collider)thisController).enabled = false;
		((Component)this).transform.position = pos;
		if (enableController)
		{
			((Collider)thisController).enabled = true;
		}
		teleportingThisFrame = true;
		teleportedLastFrame = true;
		timeSinceTakingGravityDamage = 1f;
		averageVelocity = 0f;
		if (!isUnderwater && !isSinking)
		{
			return;
		}
		Debug.Log((object)"Player is sinking; disable all quicksand locally");
		QuicksandTrigger[] array = Object.FindObjectsByType<QuicksandTrigger>((FindObjectsInactive)0, (FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].sinkingLocalPlayer)
			{
				array[i].OnExit(((Component)this).gameObject.GetComponent<Collider>());
				break;
			}
		}
	}

	public void KillPlayer(Vector3 bodyVelocity, bool spawnBody = true, CauseOfDeath causeOfDeath = CauseOfDeath.Unknown, int deathAnimation = 0, Vector3 positionOffset = default(Vector3))
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner && !isPlayerDead && AllowPlayerDeath())
		{
			isPlayerDead = true;
			isPlayerControlled = false;
			((Renderer)thisPlayerModelArms).enabled = false;
			localVisor.position = playersManager.notSpawnedPosition.position;
			DisablePlayerModel(((Component)this).gameObject);
			isInsideFactory = false;
			IsInspectingItem = false;
			inTerminalMenu = false;
			twoHanded = false;
			carryWeight = 1f;
			fallValue = 0f;
			fallValueUncapped = 0f;
			takingFallDamage = false;
			isSinking = false;
			isUnderwater = false;
			StartOfRound.Instance.drowningTimer = 1f;
			HUDManager.Instance.setUnderwaterFilter = false;
			wasUnderwaterLastFrame = false;
			sourcesCausingSinking = 0;
			sinkingValue = 0f;
			hinderedMultiplier = 1f;
			isMovementHindered = 0;
			inAnimationWithEnemy = null;
			positionOfDeath = ((Component)this).transform.position;
			if (spawnBody)
			{
				Debug.DrawRay(((Component)this).transform.position, ((Component)this).transform.up * 3f, Color.red, 10f);
				SpawnDeadBody((int)playerClientId, bodyVelocity, (int)causeOfDeath, this, deathAnimation, null, positionOffset);
			}
			SetInSpecialMenu(setInMenu: false);
			physicsParent = null;
			overridePhysicsParent = null;
			lastSyncedPhysicsParent = null;
			StartOfRound.Instance.CurrentPlayerPhysicsRegions.Clear();
			((Component)this).transform.SetParent(playersManager.playersContainer);
			CancelSpecialTriggerAnimations();
			ChangeAudioListenerToObject(((Component)playersManager.spectateCamera).gameObject);
			SoundManager.Instance.SetDiageticMixerSnapshot();
			HUDManager.Instance.SetNearDepthOfFieldEnabled(enabled: true);
			HUDManager.Instance.HUDAnimator.SetBool("biohazardDamage", false);
			Debug.Log((object)("Running kill player function for LOCAL client, player object: " + ((Object)((Component)this).gameObject).name));
			HUDManager.Instance.gameOverAnimator.SetTrigger("gameOver");
			HUDManager.Instance.HideHUD(hide: true);
			StopHoldInteractionOnTrigger();
			KillPlayerServerRpc((int)playerClientId, spawnBody, bodyVelocity, (int)causeOfDeath, deathAnimation, positionOffset);
			StartOfRound.Instance.SwitchCamera(StartOfRound.Instance.spectateCamera);
			isInGameOverAnimation = 1.5f;
			((TMP_Text)cursorTip).text = "";
			((Behaviour)cursorIcon).enabled = false;
			DropAllHeldItems(spawnBody);
			DisableJetpackControlsLocally();
		}
	}

	[ServerRpc]
	private void KillPlayerServerRpc(int playerId, bool spawnBody, Vector3 bodyVelocity, int causeOfDeath, int deathAnimation, Vector3 positionOffset)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4121569671u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref spawnBody, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref bodyVelocity);
			BytePacker.WriteValueBitPacked(val2, causeOfDeath);
			BytePacker.WriteValueBitPacked(val2, deathAnimation);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref positionOffset);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4121569671u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		playersManager.livingPlayers--;
		if (playersManager.livingPlayers == 0)
		{
			playersManager.allPlayersDead = true;
			playersManager.ShipLeaveAutomatically();
		}
		((Component)this).transform.SetParent(playersManager.playersContainer);
		if (!spawnBody)
		{
			PlayerControllerB component = playersManager.allPlayerObjects[playerId].GetComponent<PlayerControllerB>();
			for (int i = 0; i < component.ItemSlots.Length; i++)
			{
				GrabbableObject grabbableObject = component.ItemSlots[i];
				if ((Object)(object)grabbableObject != (Object)null)
				{
					((Component)grabbableObject).gameObject.GetComponent<NetworkObject>().Despawn(true);
				}
			}
		}
		else if (deathAnimation != 9)
		{
			GameObject obj = Object.Instantiate<GameObject>(StartOfRound.Instance.ragdollGrabbableObjectPrefab, playersManager.propsContainer);
			obj.GetComponent<NetworkObject>().Spawn(false);
			obj.GetComponent<RagdollGrabbableObject>().bodyID.Value = playerId;
		}
		KillPlayerClientRpc(playerId, spawnBody, bodyVelocity, causeOfDeath, deathAnimation, positionOffset);
	}

	[ClientRpc]
	private void KillPlayerClientRpc(int playerId, bool spawnBody, Vector3 bodyVelocity, int causeOfDeath, int deathAnimation, Vector3 positionOffset)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1905939161u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref spawnBody, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref bodyVelocity);
			BytePacker.WriteValueBitPacked(val2, causeOfDeath);
			BytePacker.WriteValueBitPacked(val2, deathAnimation);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref positionOffset);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1905939161u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		StartOfRound.Instance.gameStats.deaths++;
		Debug.Log((object)("A player died. player object: " + ((Object)((Component)this).gameObject).name));
		if (!((NetworkBehaviour)this).IsServer)
		{
			Debug.Log((object)"Setting living players minus one.");
			playersManager.livingPlayers--;
			Debug.Log((object)playersManager.livingPlayers);
			if (playersManager.livingPlayers == 0)
			{
				playersManager.allPlayersDead = true;
				playersManager.ShipLeaveAutomatically();
			}
		}
		PlayerControllerB component = playersManager.allPlayerObjects[playerId].GetComponent<PlayerControllerB>();
		component.physicsParent = null;
		component.overridePhysicsParent = null;
		component.lastSyncedPhysicsParent = null;
		component.bleedingHeavily = false;
		statusEffectAudio.Stop();
		if (!((NetworkBehaviour)this).IsOwner && spawnBody)
		{
			SpawnDeadBody(playerId, bodyVelocity, causeOfDeath, component, deathAnimation, null, positionOffset);
			DropAllHeldItems(spawnBody);
		}
		placeOfDeath = ((Component)component).transform.position;
		DisablePlayerModel(playersManager.allPlayerObjects[playerId]);
		component.setPositionOfDeadPlayer = true;
		component.isPlayerDead = true;
		component.isPlayerControlled = false;
		component.snapToServerPosition = false;
		component.isUnderwater = false;
		component.isHoldingObject = false;
		component.currentlyHeldObjectServer = null;
		((Component)component).transform.SetParent(playersManager.playersContainer);
		SoundManager.Instance.playerVoicePitchTargets[playerId] = 1f;
		SoundManager.Instance.playerVoicePitchLerpSpeed[playerId] = 3f;
		component.causeOfDeath = (CauseOfDeath)causeOfDeath;
		if (!((NetworkBehaviour)this).IsOwner && GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			HUDManager.Instance.UpdateBoxesSpectateUI();
		}
		StartOfRound.Instance.UpdatePlayerVoiceEffects();
	}

	public void SpawnDeadBody(int playerId, Vector3 bodyVelocity, int causeOfDeath, PlayerControllerB deadPlayerController, int deathAnimation = 0, Transform overridePosition = null, Vector3 positionOffset = default(Vector3))
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		float num = 1.32f;
		if (positionOffset != Vector3.zero)
		{
			num = 0f;
		}
		Transform val = null;
		if (deathAnimation == 9)
		{
			if ((Object)(object)RoundManager.Instance.mapPropsContainer != (Object)null)
			{
				val = RoundManager.Instance.mapPropsContainer.transform;
			}
		}
		else if (isInElevator)
		{
			val = playersManager.elevatorTransform;
		}
		GameObject val2 = ((!((Object)(object)overridePosition != (Object)null)) ? Object.Instantiate<GameObject>(playersManager.playerRagdolls[deathAnimation], deadPlayerController.thisPlayerBody.position + Vector3.up * num + positionOffset, deadPlayerController.thisPlayerBody.rotation, val) : Object.Instantiate<GameObject>(playersManager.playerRagdolls[deathAnimation], overridePosition.position + Vector3.up * num + positionOffset, overridePosition.rotation, val));
		Debug.DrawRay(val2.transform.position, val2.transform.up * 2f, Color.green, 10f);
		DeadBodyInfo component = val2.GetComponent<DeadBodyInfo>();
		if ((Object)(object)component != (Object)null)
		{
			if (Object.op_Implicit((Object)(object)overridePosition))
			{
				component.overrideSpawnPosition = true;
			}
			if ((Object)(object)deadPlayerController.physicsParent != (Object)null)
			{
				component.SetPhysicsParent(deadPlayerController.physicsParent);
			}
			component.parentedToShip = isInElevator;
			component.playerObjectId = playerId;
			deadBody = component;
		}
		Rigidbody[] componentsInChildren = val2.GetComponentsInChildren<Rigidbody>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].velocity = bodyVelocity;
		}
		if ((Object)(object)deadBody != (Object)null)
		{
			for (int j = 0; j < bodyBloodDecals.Length; j++)
			{
				deadBody.bodyBloodDecals[j].SetActive(bodyBloodDecals[j].activeSelf);
			}
		}
		CauseOfDeath causeOfDeath2 = (CauseOfDeath)causeOfDeath;
		if ((Object)(object)component != (Object)null)
		{
			ScanNodeProperties componentInChildren = ((Component)component).gameObject.GetComponentInChildren<ScanNodeProperties>();
			componentInChildren.headerText = "Body of " + deadPlayerController.playerUsername;
			componentInChildren.subText = "Cause of death: " + causeOfDeath2;
		}
		if ((Object)(object)deadBody != (Object)null)
		{
			deadBody.causeOfDeath = causeOfDeath2;
			if (causeOfDeath2 == CauseOfDeath.Bludgeoning || causeOfDeath2 == CauseOfDeath.Mauling || causeOfDeath2 == CauseOfDeath.Gunshots)
			{
				deadBody.MakeCorpseBloody();
			}
			if (causeOfDeath2 == CauseOfDeath.Gravity)
			{
				deadBody.bodyAudio.PlayOneShot(StartOfRound.Instance.playerFallDeath);
				WalkieTalkie.TransmitOneShotAudio(deadBody.bodyAudio, StartOfRound.Instance.playerFallDeath);
			}
		}
	}

	public void DestroyItemInSlotAndSync(int itemSlot)
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (itemSlot >= ItemSlots.Length || (Object)(object)ItemSlots[itemSlot] == (Object)null)
			{
				Debug.LogError((object)$"Destroy item in slot called for a slot (slot {itemSlot}) which is empty or incorrect");
			}
			timeSinceSwitchingSlots = 0f;
			DestroyItemInSlot(itemSlot);
			DestroyItemInSlotServerRpc(itemSlot);
		}
	}

	[ServerRpc]
	public void DestroyItemInSlotServerRpc(int itemSlot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1388366573u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, itemSlot);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1388366573u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DestroyItemInSlotClientRpc(itemSlot);
		}
	}

	[ClientRpc]
	public void DestroyItemInSlotClientRpc(int itemSlot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(899109231u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, itemSlot);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 899109231u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				DestroyItemInSlot(itemSlot);
			}
		}
	}

	public void DestroyItemInSlot(int itemSlot)
	{
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null || (Object)(object)NetworkManager.Singleton == (Object)null || NetworkManager.Singleton.ShutdownInProgress)
		{
			return;
		}
		Debug.Log((object)$"Destroying item in slot {itemSlot}; {currentItemSlot}; is currentlyheldobjectserver null: {(Object)(object)currentlyHeldObjectServer == (Object)null}");
		if ((Object)(object)currentlyHeldObjectServer != (Object)null)
		{
			Debug.Log((object)("currentlyHeldObjectServer: " + currentlyHeldObjectServer.itemProperties.itemName));
		}
		GrabbableObject grabbableObject = ItemSlots[itemSlot];
		if (isHoldingObject)
		{
			if (currentItemSlot == itemSlot)
			{
				carryWeight = Mathf.Clamp(carryWeight - (currentlyHeldObjectServer.itemProperties.weight - 1f), 1f, 10f);
				isHoldingObject = false;
				twoHanded = false;
				if (((NetworkBehaviour)this).IsOwner)
				{
					playerBodyAnimator.SetBool("cancelHolding", true);
					playerBodyAnimator.SetTrigger("Throw");
					((Behaviour)HUDManager.Instance.holdingTwoHandedItem).enabled = false;
					HUDManager.Instance.ClearControlTips();
					activatingItem = false;
				}
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
				((Behaviour)HUDManager.Instance.itemSlotIcons[itemSlot]).enabled = false;
			}
			if ((Object)(object)currentlyHeldObjectServer != (Object)null && (Object)(object)currentlyHeldObjectServer == (Object)(object)ItemSlots[itemSlot])
			{
				if (((NetworkBehaviour)this).IsOwner)
				{
					SetSpecialGrabAnimationBool(setTrue: false, currentlyHeldObjectServer);
					currentlyHeldObjectServer.DiscardItemOnClient();
				}
				currentlyHeldObjectServer = null;
			}
		}
		ItemSlots[itemSlot] = null;
		if (((NetworkBehaviour)this).IsServer)
		{
			((NetworkBehaviour)grabbableObject).NetworkObject.Despawn(true);
		}
	}

	public void DropAllHeldItems(bool itemsFall = true, bool disconnecting = false)
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < ItemSlots.Length; i++)
		{
			GrabbableObject grabbableObject = ItemSlots[i];
			if (!((Object)(object)grabbableObject != (Object)null))
			{
				continue;
			}
			if (itemsFall)
			{
				grabbableObject.parentObject = null;
				grabbableObject.heldByPlayerOnServer = false;
				if (isInElevator)
				{
					((Component)grabbableObject).transform.SetParent(playersManager.elevatorTransform, true);
				}
				else
				{
					((Component)grabbableObject).transform.SetParent(playersManager.propsContainer, true);
				}
				SetItemInElevator(isInHangarShipRoom, isInElevator, grabbableObject);
				grabbableObject.EnablePhysics(enable: true);
				grabbableObject.EnableItemMeshes(enable: true);
				((Component)grabbableObject).transform.localScale = grabbableObject.originalScale;
				grabbableObject.isHeld = false;
				grabbableObject.isPocketed = false;
				Debug.Log((object)$"Drop all held items A {grabbableObject.startFallingPosition}; item parent: {((Component)grabbableObject).transform.parent}; {((Component)grabbableObject).transform.parent.InverseTransformPoint(((Component)grabbableObject).transform.position)}; {((Component)grabbableObject).transform.position}");
				Debug.DrawRay(((Component)grabbableObject).transform.position, Vector3.up, Color.red, 25f);
				grabbableObject.startFallingPosition = ((Component)grabbableObject).transform.parent.InverseTransformPoint(((Component)grabbableObject).transform.position);
				grabbableObject.FallToGround(randomizePosition: true);
				grabbableObject.fallTime = Random.Range(-0.3f, 0.05f);
				if (((NetworkBehaviour)this).IsOwner)
				{
					grabbableObject.DiscardItemOnClient();
				}
				else if (!grabbableObject.itemProperties.syncDiscardFunction)
				{
					grabbableObject.playerHeldBy = null;
				}
			}
			if (((NetworkBehaviour)this).IsOwner && !disconnecting)
			{
				((Behaviour)HUDManager.Instance.holdingTwoHandedItem).enabled = false;
				((Behaviour)HUDManager.Instance.itemSlotIcons[i]).enabled = false;
				HUDManager.Instance.ClearControlTips();
				activatingItem = false;
			}
			ItemSlots[i] = null;
		}
		if (isHoldingObject)
		{
			isHoldingObject = false;
			if ((Object)(object)currentlyHeldObjectServer != (Object)null)
			{
				SetSpecialGrabAnimationBool(setTrue: false, currentlyHeldObjectServer);
			}
			playerBodyAnimator.SetBool("cancelHolding", true);
			playerBodyAnimator.SetTrigger("Throw");
		}
		activatingItem = false;
		twoHanded = false;
		carryWeight = 1f;
		currentlyHeldObjectServer = null;
	}

	public void DropAllHeldItemsAndSync()
	{
		DropAllHeldItems();
		DropAllHeldItemsServerRpc();
	}

	[ServerRpc(RequireOwnership = false)]
	public void DropAllHeldItemsServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(760742013u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 760742013u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DropAllHeldItemsClientRpc();
			}
		}
	}

	[ClientRpc]
	public void DropAllHeldItemsClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2096889309u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2096889309u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				DropAllHeldItems();
			}
		}
	}

	private bool NearOtherPlayers(PlayerControllerB playerScript = null, float checkRadius = 10f)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)playerScript == (Object)null)
		{
			playerScript = this;
		}
		((Component)this).gameObject.layer = 0;
		bool result = Physics.CheckSphere(((Component)playerScript).transform.position, checkRadius, 8, (QueryTriggerInteraction)1);
		((Component)this).gameObject.layer = 3;
		return result;
	}

	private bool PlayerIsHearingOthersThroughWalkieTalkie(PlayerControllerB playerScript = null)
	{
		if ((Object)(object)playerScript == (Object)null)
		{
			playerScript = this;
		}
		if (!playerScript.holdingWalkieTalkie)
		{
			return false;
		}
		for (int i = 0; i < WalkieTalkie.allWalkieTalkies.Count; i++)
		{
			if (WalkieTalkie.allWalkieTalkies[i].clientIsHoldingAndSpeakingIntoThis && (Object)(object)WalkieTalkie.allWalkieTalkies[i] != (Object)(object)(playerScript.currentlyHeldObjectServer as WalkieTalkie))
			{
				return true;
			}
		}
		return false;
	}

	public void DisablePlayerModel(GameObject playerObject, bool enable = false, bool disableLocalArms = false)
	{
		SkinnedMeshRenderer[] componentsInChildren = playerObject.GetComponentsInChildren<SkinnedMeshRenderer>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			((Renderer)componentsInChildren[i]).enabled = enable;
		}
		if (disableLocalArms)
		{
			((Renderer)thisPlayerModelArms).enabled = false;
		}
	}

	public void SyncBodyPositionWithClients()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)deadBody != (Object)null)
		{
			SyncBodyPositionClientRpc(((Component)deadBody).transform.position);
		}
	}

	[ClientRpc]
	public void SyncBodyPositionClientRpc(Vector3 newBodyPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(301044013u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref newBodyPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 301044013u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !(Vector3.Distance(((Component)deadBody).transform.position, newBodyPosition) < 1.5f))
			{
				((MonoBehaviour)this).StartCoroutine(WaitUntilPlayerHasLeftBodyToTeleport(newBodyPosition));
			}
		}
	}

	private IEnumerator WaitUntilPlayerHasLeftBodyToTeleport(Vector3 newBodyPosition)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)deadBody == (Object)null || !Physics.CheckSphere(((Component)deadBody).transform.position, 8f, playersManager.playersMask)));
		if (!((Object)(object)deadBody == (Object)null))
		{
			deadBody.SetRagdollPositionSafely(newBodyPosition);
		}
	}

	private void LateUpdate()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_08fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_0508: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0529: Unknown result type (might be due to invalid IL or missing references)
		//IL_0548: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0421: Unknown result type (might be due to invalid IL or missing references)
		//IL_042c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0431: Unknown result type (might be due to invalid IL or missing references)
		//IL_0436: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a71: Unknown result type (might be due to invalid IL or missing references)
		//IL_0993: Unknown result type (might be due to invalid IL or missing references)
		//IL_0974: Unknown result type (might be due to invalid IL or missing references)
		//IL_0466: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_0499: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3b: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f2: Unknown result type (might be due to invalid IL or missing references)
		if (isFirstFrameLateUpdate)
		{
			isFirstFrameLateUpdate = false;
			previousElevatorPosition = playersManager.elevatorTransform.position;
		}
		else if (((NetworkBehaviour)this).IsOwner && isPlayerControlled && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject))
		{
			int num = 0;
			Transform val = null;
			NetworkObject val2 = null;
			for (int i = 0; i < StartOfRound.Instance.CurrentPlayerPhysicsRegions.Count; i++)
			{
				if (StartOfRound.Instance.CurrentPlayerPhysicsRegions[i].priority > num)
				{
					num = StartOfRound.Instance.CurrentPlayerPhysicsRegions[i].priority;
					val = StartOfRound.Instance.CurrentPlayerPhysicsRegions[i].physicsTransform;
					val2 = StartOfRound.Instance.CurrentPlayerPhysicsRegions[i].parentNetworkObject;
				}
			}
			if (isInElevator && num <= 0)
			{
				val = null;
			}
			physicsParent = val;
			if ((Object)(object)overridePhysicsParent != (Object)null)
			{
				if ((Object)(object)overridePhysicsParent != (Object)(object)lastSyncedPhysicsParent)
				{
					parentedToElevatorLastFrame = false;
					lastSyncedPhysicsParent = overridePhysicsParent;
					((Component)this).transform.SetParent(overridePhysicsParent);
					UpdatePlayerPhysicsParentServerRpc(thisPlayerBody.localPosition, NetworkObjectReference.op_Implicit(((Component)overridePhysicsParent).GetComponent<NetworkObject>()), isOverride: true, isInElevator, isInHangarShipRoom);
				}
			}
			else if ((Object)(object)physicsParent != (Object)null && (Object)(object)val2 != (Object)null)
			{
				if ((Object)(object)physicsParent != (Object)(object)lastSyncedPhysicsParent)
				{
					parentedToElevatorLastFrame = false;
					lastSyncedPhysicsParent = physicsParent;
					((Component)this).transform.SetParent(physicsParent);
					UpdatePlayerPhysicsParentServerRpc(thisPlayerBody.localPosition, NetworkObjectReference.op_Implicit(((Component)val2).GetComponent<NetworkObject>()), isOverride: false, isInElevator, isInHangarShipRoom);
				}
			}
			else
			{
				if ((Object)(object)lastSyncedPhysicsParent != (Object)null)
				{
					lastSyncedPhysicsParent = null;
					((Component)this).transform.SetParent(playersManager.playersContainer);
					RemovePlayerPhysicsParentServerRpc(thisPlayerBody.localPosition, removeOverride: false, removeBoth: true, isInElevator, isInHangarShipRoom);
				}
				if (isInElevator)
				{
					if (!parentedToElevatorLastFrame)
					{
						parentedToElevatorLastFrame = true;
						((Component)this).transform.SetParent(playersManager.elevatorTransform);
					}
				}
				else if (parentedToElevatorLastFrame)
				{
					parentedToElevatorLastFrame = false;
					((Component)this).transform.SetParent(playersManager.playersContainer);
				}
			}
		}
		previousElevatorPosition = playersManager.elevatorTransform.position;
		if (!isTestingPlayer)
		{
			if ((Object)(object)NetworkManager.Singleton == (Object)null)
			{
				return;
			}
			if (!((NetworkBehaviour)this).IsOwner && usernameAlpha.alpha >= 0f && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
			{
				CanvasGroup obj = usernameAlpha;
				obj.alpha -= Time.deltaTime;
				usernameBillboard.LookAt(GameNetworkManager.Instance.localPlayerController.localVisorTargetPoint);
			}
			else if (((Component)usernameCanvas).gameObject.activeSelf)
			{
				((Component)usernameCanvas).gameObject.SetActive(false);
			}
		}
		if (((NetworkBehaviour)this).IsOwner && (!((NetworkBehaviour)this).IsServer || isHostPlayerObject))
		{
			PlayerLookInput();
			if (((Component)RoundManager.Instance.indoorFog).gameObject.activeSelf)
			{
				((Component)RoundManager.Instance.indoorFog).transform.position = ((Component)StartOfRound.Instance.audioListener).transform.position;
				PlayerControllerB playerControllerB = this;
				if (isPlayerDead && (Object)(object)spectatedPlayerScript != (Object)null)
				{
					playerControllerB = spectatedPlayerScript;
				}
				((Behaviour)RoundManager.Instance.indoorFog).enabled = playerControllerB.isInsideFactory;
			}
			if (isPlayerControlled && !isPlayerDead)
			{
				if ((Object)(object)GameNetworkManager.Instance != (Object)null)
				{
					float num2 = 0.14f;
					num2 = (inSpecialInteractAnimation ? 0.06f : ((!NearOtherPlayers(this)) ? 0.24f : 0.1f));
					Vector3 val3 = oldPlayerPosition - ((Component)this).transform.localPosition;
					if (((Vector3)(ref val3)).sqrMagnitude > num2 || updatePositionForNewlyJoinedClient)
					{
						updatePositionForNewlyJoinedClient = false;
						if (!playersManager.newGameIsLoading)
						{
							UpdatePlayerPositionServerRpc(thisPlayerBody.localPosition, isInElevator, isInHangarShipRoom, isExhausted, thisController.isGrounded);
							oldPlayerPosition = ((Component)this).transform.localPosition;
						}
					}
					if ((Object)(object)currentlyHeldObjectServer != (Object)null && isHoldingObject && grabbedObjectValidated)
					{
						((Component)currentlyHeldObjectServer).transform.localPosition = currentlyHeldObjectServer.itemProperties.positionOffset;
						((Component)currentlyHeldObjectServer).transform.localEulerAngles = currentlyHeldObjectServer.itemProperties.rotationOffset;
					}
				}
				localVisor.position = localVisorTargetPoint.position;
				localVisor.rotation = Quaternion.Lerp(localVisor.rotation, localVisorTargetPoint.rotation, 53f * Mathf.Clamp(Time.deltaTime, 0.0167f, 20f));
				float num3 = 1f;
				if (drunkness > 0.02f)
				{
					num3 *= Mathf.Abs(StartOfRound.Instance.drunknessSpeedEffect.Evaluate(drunkness) - 1.25f);
				}
				if (isSprinting)
				{
					sprintMeter = Mathf.Clamp(sprintMeter - Time.deltaTime / sprintTime * carryWeight * num3, 0f, 1f);
				}
				else if (isMovementHindered > 0)
				{
					if (isWalking)
					{
						sprintMeter = Mathf.Clamp(sprintMeter - Time.deltaTime / sprintTime * num3 * 0.5f, 0f, 1f);
					}
				}
				else
				{
					if (!isWalking)
					{
						sprintMeter = Mathf.Clamp(sprintMeter + Time.deltaTime / (sprintTime + 4f) * num3, 0f, 1f);
					}
					else
					{
						sprintMeter = Mathf.Clamp(sprintMeter + Time.deltaTime / (sprintTime + 9f) * num3, 0f, 1f);
					}
					if (isExhausted && sprintMeter > 0.2f)
					{
						isExhausted = false;
					}
				}
				sprintMeterUI.fillAmount = sprintMeter;
				float num4;
				if (isHoldingObject && (Object)(object)currentlyHeldObjectServer != (Object)null && currentlyHeldObjectServer.itemProperties.requiresBattery)
				{
					HUDManager.Instance.batteryMeter.fillAmount = currentlyHeldObjectServer.insertedBattery.charge / 1.3f;
					((Component)HUDManager.Instance.batteryMeter).gameObject.SetActive(true);
					((Behaviour)HUDManager.Instance.batteryIcon).enabled = true;
					num4 = currentlyHeldObjectServer.insertedBattery.charge / 1.3f;
				}
				else if (((Behaviour)helmetLight).enabled)
				{
					HUDManager.Instance.batteryMeter.fillAmount = pocketedFlashlight.insertedBattery.charge / 1.3f;
					((Component)HUDManager.Instance.batteryMeter).gameObject.SetActive(true);
					((Behaviour)HUDManager.Instance.batteryIcon).enabled = true;
					num4 = pocketedFlashlight.insertedBattery.charge / 1.3f;
				}
				else
				{
					((Component)HUDManager.Instance.batteryMeter).gameObject.SetActive(false);
					((Behaviour)HUDManager.Instance.batteryIcon).enabled = false;
					num4 = 1f;
				}
				HUDManager.Instance.batteryBlinkUI.SetBool("blink", num4 < 0.2f && num4 > 0f);
				timeSinceSwitchingSlots += Time.deltaTime;
				if (limpMultiplier > 0f)
				{
					limpMultiplier -= Time.deltaTime / 1.8f;
				}
				if (health < 20)
				{
					if (healthRegenerateTimer <= 0f)
					{
						healthRegenerateTimer = 1f;
						health++;
						if (health >= 20)
						{
							MakeCriticallyInjured(enable: false);
						}
						HUDManager.Instance.UpdateHealthUI(health, hurtPlayer: false);
					}
					else
					{
						healthRegenerateTimer -= Time.deltaTime;
					}
				}
				SetHoverTipAndCurrentInteractTrigger();
			}
		}
		if (!inSpecialInteractAnimation && localArmsMatchCamera)
		{
			localArmsTransform.position = ((Component)cameraContainerTransform).transform.position + ((Component)gameplayCamera).transform.up * -0.5f;
			playerModelArmsMetarig.rotation = localArmsRotationTarget.rotation;
		}
		if (playersManager.overrideSpectateCamera || !((NetworkBehaviour)this).IsOwner || !isPlayerDead || (((NetworkBehaviour)this).IsServer && !isHostPlayerObject))
		{
			return;
		}
		if (isInGameOverAnimation > 0f && (Object)(object)deadBody != (Object)null)
		{
			if ((Object)(object)overrideGameOverSpectatePivot != (Object)null)
			{
				spectateCameraPivot.position = overrideGameOverSpectatePivot.position;
			}
			else
			{
				spectateCameraPivot.position = deadBody.bodyParts[0].position;
			}
			RaycastSpectateCameraAroundPivot();
		}
		else if ((Object)(object)spectatedPlayerScript != (Object)null)
		{
			if (spectatedPlayerScript.isPlayerDead)
			{
				if (StartOfRound.Instance.allPlayersDead)
				{
					StartOfRound.Instance.SetSpectateCameraToGameOverMode(enableGameOver: true);
				}
				if (!(spectatedPlayerDeadTimer >= 1.5f))
				{
					spectatedPlayerDeadTimer += Time.deltaTime;
					if ((Object)(object)spectatedPlayerScript.deadBody != (Object)null)
					{
						spectateCameraPivot.position = spectatedPlayerScript.deadBody.bodyParts[0].position;
						RaycastSpectateCameraAroundPivot();
					}
					return;
				}
				spectatedPlayerDeadTimer = 0f;
				SpectateNextPlayer(getClosest: true);
			}
			spectateCameraPivot.position = spectatedPlayerScript.lowerSpine.position + Vector3.up * 0.7f;
			RaycastSpectateCameraAroundPivot();
		}
		else if (StartOfRound.Instance.allPlayersDead)
		{
			StartOfRound.Instance.SetSpectateCameraToGameOverMode(enableGameOver: true);
			SetSpectatedPlayerEffects(allPlayersDead: true);
		}
		else
		{
			SpectateNextPlayer(getClosest: true);
		}
	}

	private void RaycastSpectateCameraAroundPivot()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		interactRay = new Ray(spectateCameraPivot.position, -spectateCameraPivot.forward);
		if (Physics.Raycast(interactRay, ref hit, 1.4f, walkableSurfacesNoPlayersMask, (QueryTriggerInteraction)1))
		{
			((Component)playersManager.spectateCamera).transform.position = ((Ray)(ref interactRay)).GetPoint(((RaycastHit)(ref hit)).distance - 0.25f);
		}
		else
		{
			((Component)playersManager.spectateCamera).transform.position = ((Ray)(ref interactRay)).GetPoint(1.3f);
		}
		((Component)playersManager.spectateCamera).transform.LookAt(spectateCameraPivot);
	}

	private void SetHoverTipAndCurrentInteractTrigger()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		if (!isGrabbingObjectAnimation && !inSpecialMenu && !quickMenuManager.isMenuOpen)
		{
			interactRay = new Ray(((Component)gameplayCamera).transform.position, ((Component)gameplayCamera).transform.forward);
			if (Physics.Raycast(interactRay, ref hit, grabDistance, interactableObjectsMask) && ((Component)((RaycastHit)(ref hit)).collider).gameObject.layer != 8 && ((Component)((RaycastHit)(ref hit)).collider).gameObject.layer != 30)
			{
				string tag = ((Component)((RaycastHit)(ref hit)).collider).tag;
				if (!(tag == "PhysicsProp"))
				{
					if (tag == "InteractTrigger")
					{
						InteractTrigger component = ((Component)((RaycastHit)(ref hit)).transform).gameObject.GetComponent<InteractTrigger>();
						if ((Object)(object)component != (Object)(object)previousHoveringOverTrigger && (Object)(object)previousHoveringOverTrigger != (Object)null)
						{
							previousHoveringOverTrigger.isBeingHeldByPlayer = false;
						}
						if (!((Object)(object)component == (Object)null))
						{
							hoveringOverTrigger = component;
							if (!component.interactable)
							{
								cursorIcon.sprite = component.disabledHoverIcon;
								((Behaviour)cursorIcon).enabled = (Object)(object)component.disabledHoverIcon != (Object)null;
								((TMP_Text)cursorTip).text = component.disabledHoverTip;
							}
							else if (component.isPlayingSpecialAnimation || (inSpecialInteractAnimation && component.specialCharacterAnimation))
							{
								((Behaviour)cursorIcon).enabled = false;
								((TMP_Text)cursorTip).text = "";
							}
							else if (isHoldingInteract)
							{
								if (twoHanded)
								{
									((TMP_Text)cursorTip).text = "[Hands full]";
								}
								else if (!string.IsNullOrEmpty(component.holdTip))
								{
									((TMP_Text)cursorTip).text = component.holdTip;
								}
							}
							else
							{
								((Behaviour)cursorIcon).enabled = true;
								cursorIcon.sprite = component.hoverIcon;
								((TMP_Text)cursorTip).text = component.hoverTip;
							}
						}
					}
				}
				else
				{
					if (FirstEmptyItemSlot() == -1)
					{
						((TMP_Text)cursorTip).text = "Inventory full!";
						goto IL_01d3;
					}
					GrabbableObject component2 = ((Component)((RaycastHit)(ref hit)).collider).gameObject.GetComponent<GrabbableObject>();
					if (Physics.Linecast(((Component)gameplayCamera).transform.position, ((Component)component2).transform.position, 1073741824, (QueryTriggerInteraction)1))
					{
						((Behaviour)cursorIcon).enabled = false;
						((TMP_Text)cursorTip).text = "";
					}
					else
					{
						if (GameNetworkManager.Instance.gameHasStarted || component2.itemProperties.canBeGrabbedBeforeGameStart || !((Object)(object)StartOfRound.Instance.testRoom == (Object)null))
						{
							if ((Object)(object)component2 != (Object)null && !string.IsNullOrEmpty(component2.customGrabTooltip))
							{
								((TMP_Text)cursorTip).text = component2.customGrabTooltip;
							}
							else
							{
								((TMP_Text)cursorTip).text = "Grab : [E]";
							}
							goto IL_01d3;
						}
						((TMP_Text)cursorTip).text = "(Cannot hold until ship has landed)";
					}
				}
			}
			else
			{
				((Behaviour)cursorIcon).enabled = false;
				((TMP_Text)cursorTip).text = "";
				if ((Object)(object)hoveringOverTrigger != (Object)null)
				{
					previousHoveringOverTrigger = hoveringOverTrigger;
				}
				hoveringOverTrigger = null;
			}
			goto IL_037a;
		}
		goto IL_03c5;
		IL_037a:
		if (!isFreeCamera && Physics.Raycast(interactRay, ref hit, 5f, playerMask))
		{
			PlayerControllerB component3 = ((Component)((RaycastHit)(ref hit)).collider).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)component3 != (Object)null)
			{
				component3.ShowNameBillboard();
			}
		}
		goto IL_03c5;
		IL_01d3:
		((Behaviour)cursorIcon).enabled = true;
		cursorIcon.sprite = grabItemIcon;
		goto IL_037a;
		IL_03c5:
		if (StartOfRound.Instance.localPlayerUsingController)
		{
			StringBuilder stringBuilder = new StringBuilder(((TMP_Text)cursorTip).text);
			stringBuilder.Replace("[E]", "[X]");
			stringBuilder.Replace("[LMB]", "[X]");
			stringBuilder.Replace("[RMB]", "[R-Trigger]");
			stringBuilder.Replace("[F]", "[R-Shoulder]");
			stringBuilder.Replace("[Z]", "[L-Shoulder]");
			((TMP_Text)cursorTip).text = stringBuilder.ToString();
		}
		else
		{
			((TMP_Text)cursorTip).text = ((TMP_Text)cursorTip).text.Replace("[LMB]", "[E]");
		}
	}

	public void ShowNameBillboard()
	{
		usernameAlpha.alpha = 1f;
		((Component)usernameCanvas).gameObject.SetActive(true);
	}

	public bool IsPlayerServer()
	{
		return ((NetworkBehaviour)this).IsServer;
	}

	private void SpectateNextPlayer(bool getClosest = false)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		if ((Object)(object)spectatedPlayerScript != (Object)null)
		{
			num = (int)spectatedPlayerScript.playerClientId;
		}
		bool flag = false;
		if (getClosest)
		{
			Vector3 position = positionOfDeath;
			if ((Object)(object)deadBody != (Object)null)
			{
				position = ((Component)deadBody.bodyParts[0]).transform.position;
			}
			float num2 = 10000f;
			float num3 = 10000f;
			for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
			{
				if (!playersManager.allPlayerScripts[num].isPlayerDead && playersManager.allPlayerScripts[num].isPlayerControlled && (Object)(object)playersManager.allPlayerScripts[num] != (Object)(object)this)
				{
					num3 = Vector3.Distance(position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position);
					if (num3 < num2)
					{
						num2 = num3;
						num = i;
						flag = true;
					}
				}
			}
		}
		if (!flag)
		{
			for (int j = 0; j < StartOfRound.Instance.allPlayerScripts.Length; j++)
			{
				num = (num + 1) % StartOfRound.Instance.allPlayerScripts.Length;
				if (!playersManager.allPlayerScripts[num].isPlayerDead && playersManager.allPlayerScripts[num].isPlayerControlled && (Object)(object)playersManager.allPlayerScripts[num] != (Object)(object)this)
				{
					spectatedPlayerScript = playersManager.allPlayerScripts[num];
					StartOfRound.Instance.SetPlayerSafeInShip();
					SetSpectatedPlayerEffects();
					return;
				}
			}
			if ((Object)(object)deadBody != (Object)null && ((Component)deadBody).gameObject.activeSelf)
			{
				spectateCameraPivot.position = deadBody.bodyParts[0].position;
				RaycastSpectateCameraAroundPivot();
			}
			StartOfRound.Instance.SetPlayerSafeInShip();
		}
		else
		{
			spectatedPlayerScript = playersManager.allPlayerScripts[num];
			StartOfRound.Instance.SetPlayerSafeInShip();
			SetSpectatedPlayerEffects();
		}
	}

	public void SetSpectatedPlayerEffects(bool allPlayersDead = false)
	{
		try
		{
			if ((Object)(object)spectatedPlayerScript != (Object)null)
			{
				HUDManager.Instance.SetSpectatingTextToPlayer(spectatedPlayerScript);
			}
			else
			{
				((TMP_Text)HUDManager.Instance.spectatingPlayerText).text = "";
			}
			TimeOfDay timeOfDay = Object.FindObjectOfType<TimeOfDay>();
			if (allPlayersDead)
			{
				for (int i = 0; i < timeOfDay.effects.Length; i++)
				{
					timeOfDay.effects[i].effectEnabled = false;
				}
				if ((Object)(object)timeOfDay.sunDirect != (Object)null)
				{
					((Behaviour)timeOfDay.sunDirect).enabled = true;
					((Component)timeOfDay.sunIndirect).GetComponent<HDAdditionalLightData>().lightDimmer = 1f;
				}
				AudioReverbPresets audioReverbPresets = Object.FindObjectOfType<AudioReverbPresets>();
				if ((Object)(object)audioReverbPresets != (Object)null && audioReverbPresets.audioPresets.Length > 3)
				{
					GameNetworkManager.Instance.localPlayerController.reverbPreset = audioReverbPresets.audioPresets[3].reverbPreset;
				}
				SoundManager.Instance.SetEchoFilter(setEcho: false);
				return;
			}
			AudioReverbTrigger audioReverbTrigger = spectatedPlayerScript.currentAudioTrigger;
			AudioReverbPresets audioReverbPresets2 = Object.FindObjectOfType<AudioReverbPresets>();
			if ((Object)(object)audioReverbPresets2 != (Object)null && audioReverbPresets2.audioPresets.Length >= 4 && !spectatedPlayerScript.isInsideFactory && !spectatedPlayerScript.isInElevator)
			{
				audioReverbPresets2.audioPresets[3].ChangeAudioReverbForPlayer(spectatedPlayerScript);
			}
			if ((Object)(object)audioReverbTrigger == (Object)null)
			{
				TimeOfDay.Instance.SetInsideLightingDimness(doNotLerp: true, spectatedPlayerScript.isInsideFactory || spectatedPlayerScript.isInHangarShipRoom);
				return;
			}
			if ((Object)(object)audioReverbTrigger.localFog != (Object)null)
			{
				if (audioReverbTrigger.toggleLocalFog)
				{
					audioReverbTrigger.localFog.parameters.meanFreePath = audioReverbTrigger.fogEnabledAmount;
				}
				else
				{
					audioReverbTrigger.localFog.parameters.meanFreePath = 200f;
				}
			}
			TimeOfDay.Instance.SetInsideLightingDimness(doNotLerp: true, audioReverbTrigger.setInsideAtmosphere && audioReverbTrigger.insideLighting);
			if (audioReverbTrigger.disableAllWeather || spectatedPlayerScript.isInsideFactory)
			{
				TimeOfDay.Instance.DisableAllWeather();
			}
			else
			{
				if (audioReverbTrigger.enableCurrentLevelWeather && TimeOfDay.Instance.currentLevelWeather != LevelWeatherType.None)
				{
					TimeOfDay.Instance.effects[(int)TimeOfDay.Instance.currentLevelWeather].effectEnabled = true;
				}
				if (audioReverbTrigger.weatherEffect != -1)
				{
					TimeOfDay.Instance.effects[audioReverbTrigger.weatherEffect].effectEnabled = audioReverbTrigger.effectEnabled;
				}
			}
			StartOfRound.Instance.UpdatePlayerVoiceEffects();
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error caught in SpectatedPlayerEffects: {arg}");
		}
	}

	public void AddBloodToBody()
	{
		for (int i = 0; i < bodyBloodDecals.Length; i++)
		{
			if (!bodyBloodDecals[i].activeSelf)
			{
				bodyBloodDecals[i].SetActive(true);
				break;
			}
		}
	}

	public void RemoveBloodFromBody()
	{
		for (int i = 0; i < bodyBloodDecals.Length; i++)
		{
			bodyBloodDecals[i].SetActive(false);
		}
	}

	bool IHittable.Hit(int force, Vector3 hitDirection, PlayerControllerB playerWhoHit, bool playHitSFX = false, int hitID = -1)
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if (!AllowPlayerDeath())
		{
			return false;
		}
		CentipedeAI[] array = Object.FindObjectsByType<CentipedeAI>((FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if ((Object)(object)array[i].clingingToPlayer == (Object)(object)this)
			{
				return false;
			}
		}
		if (Object.op_Implicit((Object)(object)inAnimationWithEnemy))
		{
			return false;
		}
		if (force <= 2)
		{
			DamagePlayerFromOtherClientServerRpc(20, hitDirection, (int)playerWhoHit.playerClientId);
		}
		else if (force <= 4)
		{
			DamagePlayerFromOtherClientServerRpc(30, hitDirection, (int)playerWhoHit.playerClientId);
		}
		else
		{
			DamagePlayerFromOtherClientServerRpc(100, hitDirection, (int)playerWhoHit.playerClientId);
		}
		return true;
	}

	[ServerRpc(RequireOwnership = false)]
	public void DamagePlayerFromOtherClientServerRpc(int damageAmount, Vector3 hitDirection, int playerWhoHit)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(638895557u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, damageAmount);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref hitDirection);
				BytePacker.WriteValueBitPacked(val2, playerWhoHit);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 638895557u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DamagePlayerFromOtherClientClientRpc(damageAmount, hitDirection, playerWhoHit, health - damageAmount);
			}
		}
	}

	[ClientRpc]
	public void DamagePlayerFromOtherClientClientRpc(int damageAmount, Vector3 hitDirection, int playerWhoHit, int newHealthAmount)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2557046125u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, damageAmount);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref hitDirection);
			BytePacker.WriteValueBitPacked(val2, playerWhoHit);
			BytePacker.WriteValueBitPacked(val2, newHealthAmount);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2557046125u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || !AllowPlayerDeath())
		{
			return;
		}
		if (((NetworkBehaviour)this).IsOwner && isPlayerControlled)
		{
			CentipedeAI[] array = Object.FindObjectsByType<CentipedeAI>((FindObjectsSortMode)0);
			for (int i = 0; i < array.Length; i++)
			{
				if ((Object)(object)array[i].clingingToPlayer == (Object)(object)this)
				{
					return;
				}
			}
			DamagePlayer(damageAmount, hasDamageSFX: true, callRPC: true, CauseOfDeath.Bludgeoning);
		}
		movementAudio.PlayOneShot(StartOfRound.Instance.hitPlayerSFX);
		if (health < 6)
		{
			DropBlood(hitDirection);
			bodyBloodDecals[0].SetActive(true);
			playersManager.allPlayerScripts[playerWhoHit].AddBloodToBody();
			playersManager.allPlayerScripts[playerWhoHit].movementAudio.PlayOneShot(StartOfRound.Instance.bloodGoreSFX);
			WalkieTalkie.TransmitOneShotAudio(playersManager.allPlayerScripts[playerWhoHit].movementAudio, StartOfRound.Instance.bloodGoreSFX);
		}
	}

	public bool HasLineOfSightToPosition(Vector3 pos, float width = 45f, int range = 60, float proximityAwareness = -1f)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(((Component)this).transform.position, pos);
		if (num < (float)range && (Vector3.Angle(((Component)playerEye).transform.forward, pos - ((Component)gameplayCamera).transform.position) < width || num < proximityAwareness) && !Physics.Linecast(((Component)playerEye).transform.position, pos, ref hit, StartOfRound.Instance.collidersRoomDefaultAndFoliage, (QueryTriggerInteraction)1))
		{
			return true;
		}
		return false;
	}

	public float LineOfSightToPositionAngle(Vector3 pos, int range = 60, float proximityAwareness = -1f)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(((Component)this).transform.position, pos) < (float)range && !Physics.Linecast(((Component)playerEye).transform.position, pos, StartOfRound.Instance.collidersRoomDefaultAndFoliage, (QueryTriggerInteraction)1))
		{
			return Vector3.Angle(((Component)playerEye).transform.forward, pos - ((Component)gameplayCamera).transform.position);
		}
		return -361f;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_PlayerControllerB()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Expected O, but got Unknown
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Expected O, but got Unknown
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Expected O, but got Unknown
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Expected O, but got Unknown
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Expected O, but got Unknown
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Expected O, but got Unknown
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Expected O, but got Unknown
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Expected O, but got Unknown
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Expected O, but got Unknown
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Expected O, but got Unknown
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Expected O, but got Unknown
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Expected O, but got Unknown
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Expected O, but got Unknown
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Expected O, but got Unknown
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Expected O, but got Unknown
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Expected O, but got Unknown
		//IL_0413: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Expected O, but got Unknown
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Expected O, but got Unknown
		//IL_0449: Unknown result type (might be due to invalid IL or missing references)
		//IL_0453: Expected O, but got Unknown
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Expected O, but got Unknown
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Expected O, but got Unknown
		//IL_049a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a4: Expected O, but got Unknown
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bf: Expected O, but got Unknown
		//IL_04d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Expected O, but got Unknown
		//IL_04eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f5: Expected O, but got Unknown
		//IL_0506: Unknown result type (might be due to invalid IL or missing references)
		//IL_0510: Expected O, but got Unknown
		//IL_0521: Unknown result type (might be due to invalid IL or missing references)
		//IL_052b: Expected O, but got Unknown
		//IL_053c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0546: Expected O, but got Unknown
		//IL_0557: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Expected O, but got Unknown
		//IL_0572: Unknown result type (might be due to invalid IL or missing references)
		//IL_057c: Expected O, but got Unknown
		//IL_058d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0597: Expected O, but got Unknown
		//IL_05a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b2: Expected O, but got Unknown
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cd: Expected O, but got Unknown
		//IL_05de: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e8: Expected O, but got Unknown
		//IL_05f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0603: Expected O, but got Unknown
		//IL_0614: Unknown result type (might be due to invalid IL or missing references)
		//IL_061e: Expected O, but got Unknown
		//IL_062f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0639: Expected O, but got Unknown
		//IL_064a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0654: Expected O, but got Unknown
		//IL_0665: Unknown result type (might be due to invalid IL or missing references)
		//IL_066f: Expected O, but got Unknown
		//IL_0680: Unknown result type (might be due to invalid IL or missing references)
		//IL_068a: Expected O, but got Unknown
		//IL_069b: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a5: Expected O, but got Unknown
		//IL_06b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c0: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(800455552u, new RpcReceiveHandler(__rpc_handler_800455552));
		NetworkManager.__rpc_func_table.Add(3591743514u, new RpcReceiveHandler(__rpc_handler_3591743514));
		NetworkManager.__rpc_func_table.Add(1084949295u, new RpcReceiveHandler(__rpc_handler_1084949295));
		NetworkManager.__rpc_func_table.Add(1822320450u, new RpcReceiveHandler(__rpc_handler_1822320450));
		NetworkManager.__rpc_func_table.Add(3986869491u, new RpcReceiveHandler(__rpc_handler_3986869491));
		NetworkManager.__rpc_func_table.Add(1090586009u, new RpcReceiveHandler(__rpc_handler_1090586009));
		NetworkManager.__rpc_func_table.Add(341877959u, new RpcReceiveHandler(__rpc_handler_341877959));
		NetworkManager.__rpc_func_table.Add(2005250174u, new RpcReceiveHandler(__rpc_handler_2005250174));
		NetworkManager.__rpc_func_table.Add(4195705835u, new RpcReceiveHandler(__rpc_handler_4195705835));
		NetworkManager.__rpc_func_table.Add(3390857164u, new RpcReceiveHandler(__rpc_handler_3390857164));
		NetworkManager.__rpc_func_table.Add(2585603452u, new RpcReceiveHandler(__rpc_handler_2585603452));
		NetworkManager.__rpc_func_table.Add(2196003333u, new RpcReceiveHandler(__rpc_handler_2196003333));
		NetworkManager.__rpc_func_table.Add(3803364611u, new RpcReceiveHandler(__rpc_handler_3803364611));
		NetworkManager.__rpc_func_table.Add(1955832627u, new RpcReceiveHandler(__rpc_handler_1955832627));
		NetworkManager.__rpc_func_table.Add(878005044u, new RpcReceiveHandler(__rpc_handler_878005044));
		NetworkManager.__rpc_func_table.Add(655708081u, new RpcReceiveHandler(__rpc_handler_655708081));
		NetworkManager.__rpc_func_table.Add(412259855u, new RpcReceiveHandler(__rpc_handler_412259855));
		NetworkManager.__rpc_func_table.Add(141629807u, new RpcReceiveHandler(__rpc_handler_141629807));
		NetworkManager.__rpc_func_table.Add(1554282707u, new RpcReceiveHandler(__rpc_handler_1554282707));
		NetworkManager.__rpc_func_table.Add(2552479808u, new RpcReceiveHandler(__rpc_handler_2552479808));
		NetworkManager.__rpc_func_table.Add(1786952262u, new RpcReceiveHandler(__rpc_handler_1786952262));
		NetworkManager.__rpc_func_table.Add(2217326231u, new RpcReceiveHandler(__rpc_handler_2217326231));
		NetworkManager.__rpc_func_table.Add(2376977494u, new RpcReceiveHandler(__rpc_handler_2376977494));
		NetworkManager.__rpc_func_table.Add(3943098567u, new RpcReceiveHandler(__rpc_handler_3943098567));
		NetworkManager.__rpc_func_table.Add(3830452098u, new RpcReceiveHandler(__rpc_handler_3830452098));
		NetworkManager.__rpc_func_table.Add(3771510012u, new RpcReceiveHandler(__rpc_handler_3771510012));
		NetworkManager.__rpc_func_table.Add(420292904u, new RpcReceiveHandler(__rpc_handler_420292904));
		NetworkManager.__rpc_func_table.Add(2770415134u, new RpcReceiveHandler(__rpc_handler_2770415134));
		NetworkManager.__rpc_func_table.Add(588787670u, new RpcReceiveHandler(__rpc_handler_588787670));
		NetworkManager.__rpc_func_table.Add(2188611472u, new RpcReceiveHandler(__rpc_handler_2188611472));
		NetworkManager.__rpc_func_table.Add(2609793477u, new RpcReceiveHandler(__rpc_handler_2609793477));
		NetworkManager.__rpc_func_table.Add(2829807886u, new RpcReceiveHandler(__rpc_handler_2829807886));
		NetworkManager.__rpc_func_table.Add(2444895710u, new RpcReceiveHandler(__rpc_handler_2444895710));
		NetworkManager.__rpc_func_table.Add(3483566845u, new RpcReceiveHandler(__rpc_handler_3483566845));
		NetworkManager.__rpc_func_table.Add(3511599861u, new RpcReceiveHandler(__rpc_handler_3511599861));
		NetworkManager.__rpc_func_table.Add(3473255830u, new RpcReceiveHandler(__rpc_handler_3473255830));
		NetworkManager.__rpc_func_table.Add(3386813972u, new RpcReceiveHandler(__rpc_handler_3386813972));
		NetworkManager.__rpc_func_table.Add(2480354441u, new RpcReceiveHandler(__rpc_handler_2480354441));
		NetworkManager.__rpc_func_table.Add(2281795056u, new RpcReceiveHandler(__rpc_handler_2281795056));
		NetworkManager.__rpc_func_table.Add(2013428264u, new RpcReceiveHandler(__rpc_handler_2013428264));
		NetworkManager.__rpc_func_table.Add(1048810471u, new RpcReceiveHandler(__rpc_handler_1048810471));
		NetworkManager.__rpc_func_table.Add(3843228541u, new RpcReceiveHandler(__rpc_handler_3843228541));
		NetworkManager.__rpc_func_table.Add(2084785324u, new RpcReceiveHandler(__rpc_handler_2084785324));
		NetworkManager.__rpc_func_table.Add(1155355692u, new RpcReceiveHandler(__rpc_handler_1155355692));
		NetworkManager.__rpc_func_table.Add(3055429600u, new RpcReceiveHandler(__rpc_handler_3055429600));
		NetworkManager.__rpc_func_table.Add(3332990272u, new RpcReceiveHandler(__rpc_handler_3332990272));
		NetworkManager.__rpc_func_table.Add(983565270u, new RpcReceiveHandler(__rpc_handler_983565270));
		NetworkManager.__rpc_func_table.Add(2504133785u, new RpcReceiveHandler(__rpc_handler_2504133785));
		NetworkManager.__rpc_func_table.Add(956616685u, new RpcReceiveHandler(__rpc_handler_956616685));
		NetworkManager.__rpc_func_table.Add(3237016509u, new RpcReceiveHandler(__rpc_handler_3237016509));
		NetworkManager.__rpc_func_table.Add(1367193869u, new RpcReceiveHandler(__rpc_handler_1367193869));
		NetworkManager.__rpc_func_table.Add(1048203095u, new RpcReceiveHandler(__rpc_handler_1048203095));
		NetworkManager.__rpc_func_table.Add(1284827260u, new RpcReceiveHandler(__rpc_handler_1284827260));
		NetworkManager.__rpc_func_table.Add(3262284737u, new RpcReceiveHandler(__rpc_handler_3262284737));
		NetworkManager.__rpc_func_table.Add(4067397557u, new RpcReceiveHandler(__rpc_handler_4067397557));
		NetworkManager.__rpc_func_table.Add(4121569671u, new RpcReceiveHandler(__rpc_handler_4121569671));
		NetworkManager.__rpc_func_table.Add(1905939161u, new RpcReceiveHandler(__rpc_handler_1905939161));
		NetworkManager.__rpc_func_table.Add(1388366573u, new RpcReceiveHandler(__rpc_handler_1388366573));
		NetworkManager.__rpc_func_table.Add(899109231u, new RpcReceiveHandler(__rpc_handler_899109231));
		NetworkManager.__rpc_func_table.Add(760742013u, new RpcReceiveHandler(__rpc_handler_760742013));
		NetworkManager.__rpc_func_table.Add(2096889309u, new RpcReceiveHandler(__rpc_handler_2096889309));
		NetworkManager.__rpc_func_table.Add(301044013u, new RpcReceiveHandler(__rpc_handler_301044013));
		NetworkManager.__rpc_func_table.Add(638895557u, new RpcReceiveHandler(__rpc_handler_638895557));
		NetworkManager.__rpc_func_table.Add(2557046125u, new RpcReceiveHandler(__rpc_handler_2557046125));
	}

	private static void __rpc_handler_800455552(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).BreakLegsSFXServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3591743514(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).BreakLegsSFXClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1084949295(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int damageNumber = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref damageNumber);
			int newHealthAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newHealthAmount);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).DamagePlayerServerRpc(damageNumber, newHealthAmount);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1822320450(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int damageNumber = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref damageNumber);
			int newHealthAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newHealthAmount);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).DamagePlayerClientRpc(damageNumber, newHealthAmount);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3986869491(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			float sinkingSpeed = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref sinkingSpeed, default(ForPrimitives));
			int audioClipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref audioClipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).StartSinkingServerRpc(sinkingSpeed, audioClipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1090586009(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float sinkingSpeed = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref sinkingSpeed, default(ForPrimitives));
			int audioClipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref audioClipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).StartSinkingClientRpc(sinkingSpeed, audioClipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_341877959(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).StopSinkingServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2005250174(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).StopSinkingClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4195705835(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).MakeCriticallyInjuredServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3390857164(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).MakeCriticallyInjuredClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2585603452(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).HealServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2196003333(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).HealClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3803364611(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).StartPerformingEmoteServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1955832627(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).StartPerformingEmoteClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_878005044(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).StopPerformingEmoteServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_655708081(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).StopPerformingEmoteClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_412259855(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool forward = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref forward, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).SwitchItemSlotsServerRpc(forward);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_141629807(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool forward = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref forward, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).SwitchItemSlotsClientRpc(forward);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1554282707(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			NetworkObjectReference grabbedObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).GrabObjectServerRpc(grabbedObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2552479808(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool grabValidated = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref grabValidated, default(ForPrimitives));
			NetworkObjectReference grabbedObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).GrabObjectClientRpc(grabValidated, grabbedObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1786952262(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).DespawnHeldObjectServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2217326231(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).DespawnHeldObjectClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2376977494(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		NetworkObjectReference grabbedObject = default(NetworkObjectReference);
		((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
		bool droppedInElevator = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref droppedInElevator, default(ForPrimitives));
		bool droppedInShipRoom = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref droppedInShipRoom, default(ForPrimitives));
		Vector3 targetFloorPosition = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref targetFloorPosition);
		int floorYRot = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref floorYRot);
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((PlayerControllerB)(object)target).ThrowObjectServerRpc(grabbedObject, droppedInElevator, droppedInShipRoom, targetFloorPosition, floorYRot);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_3943098567(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool droppedInElevator = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref droppedInElevator, default(ForPrimitives));
			bool droppedInShipRoom = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref droppedInShipRoom, default(ForPrimitives));
			Vector3 targetFloorPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetFloorPosition);
			NetworkObjectReference grabbedObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			int floorYRot = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref floorYRot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).ThrowObjectClientRpc(droppedInElevator, droppedInShipRoom, targetFloorPosition, grabbedObject, floorYRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3830452098(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		NetworkObjectReference grabbedObject = default(NetworkObjectReference);
		((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
		NetworkObjectReference parentObject = default(NetworkObjectReference);
		((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref parentObject, default(ForNetworkSerializable));
		Vector3 placePositionOffset = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref placePositionOffset);
		bool matchRotationOfParent = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref matchRotationOfParent, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((PlayerControllerB)(object)target).PlaceObjectServerRpc(grabbedObject, parentObject, placePositionOffset, matchRotationOfParent);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_3771510012(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference parentObjectReference = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref parentObjectReference, default(ForNetworkSerializable));
			Vector3 placePositionOffset = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref placePositionOffset);
			bool matchRotationOfParent = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref matchRotationOfParent, default(ForPrimitives));
			NetworkObjectReference grabbedObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref grabbedObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).PlaceObjectClientRpc(parentObjectReference, placePositionOffset, matchRotationOfParent, grabbedObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_420292904(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).PlayerJumpedServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2770415134(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).PlayerJumpedClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_588787670(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			short newRot = default(short);
			ByteUnpacker.ReadValueBitPacked(reader, ref newRot);
			short newYRot = default(short);
			ByteUnpacker.ReadValueBitPacked(reader, ref newYRot);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).UpdatePlayerRotationServerRpc(newRot, newYRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2188611472(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			short newRot = default(short);
			ByteUnpacker.ReadValueBitPacked(reader, ref newRot);
			short newYRot = default(short);
			ByteUnpacker.ReadValueBitPacked(reader, ref newYRot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).UpdatePlayerRotationClientRpc(newRot, newYRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2609793477(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 playerEulers = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref playerEulers);
		Vector3 cameraRotation = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref cameraRotation);
		bool syncingCameraRotation = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref syncingCameraRotation, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((PlayerControllerB)(object)target).UpdatePlayerRotationFullServerRpc(playerEulers, cameraRotation, syncingCameraRotation);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_2829807886(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 playerEulers = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref playerEulers);
			Vector3 cameraRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref cameraRotation);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).UpdatePlayerRotationFullWithCameraClientRpc(playerEulers, cameraRotation);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2444895710(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 playerEulers = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref playerEulers);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).UpdatePlayerRotationFullClientRpc(playerEulers);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3483566845(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).DisableInVehicleAnimationServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3511599861(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).DisableInVehicleAnimationClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3473255830(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int animationState = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref animationState);
			float animationSpeed = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref animationSpeed, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).UpdatePlayerAnimationServerRpc(animationState, animationSpeed);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3386813972(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int animationState = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref animationState);
			float animationSpeed = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref animationSpeed, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).UpdatePlayerAnimationClientRpc(animationState, animationSpeed);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2480354441(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		bool specialAnimation = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref specialAnimation, default(ForPrimitives));
		float timed = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timed, default(ForPrimitives));
		bool climbingLadder = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref climbingLadder, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((PlayerControllerB)(object)target).IsInSpecialAnimationServerRpc(specialAnimation, timed, climbingLadder);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_2281795056(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool specialAnimation = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref specialAnimation, default(ForPrimitives));
			float timed = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timed, default(ForPrimitives));
			bool climbingLadder = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref climbingLadder, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).IsInSpecialAnimationClientRpc(specialAnimation, timed, climbingLadder);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2013428264(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 newPos = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref newPos);
		bool inElevator = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inElevator, default(ForPrimitives));
		bool inShipRoom = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inShipRoom, default(ForPrimitives));
		bool exhausted = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref exhausted, default(ForPrimitives));
		bool isPlayerGrounded = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isPlayerGrounded, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((PlayerControllerB)(object)target).UpdatePlayerPositionServerRpc(newPos, inElevator, inShipRoom, exhausted, isPlayerGrounded);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_1048810471(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newPos);
			bool inElevator = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inElevator, default(ForPrimitives));
			bool isInShip = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isInShip, default(ForPrimitives));
			bool exhausted = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref exhausted, default(ForPrimitives));
			bool isPlayerGrounded = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isPlayerGrounded, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).UpdatePlayerPositionClientRpc(newPos, inElevator, isInShip, exhausted, isPlayerGrounded);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3843228541(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 newPos = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref newPos);
		bool removeOverride = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref removeOverride, default(ForPrimitives));
		bool removeBoth = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref removeBoth, default(ForPrimitives));
		bool inElevator = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inElevator, default(ForPrimitives));
		bool isInShip = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isInShip, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((PlayerControllerB)(object)target).RemovePlayerPhysicsParentServerRpc(newPos, removeOverride, removeBoth, inElevator, isInShip);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_2084785324(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newPos);
			bool removeOverride = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref removeOverride, default(ForPrimitives));
			bool removeBoth = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref removeBoth, default(ForPrimitives));
			bool inElevator = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inElevator, default(ForPrimitives));
			bool isInShip = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isInShip, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).RemovePlayerPhysicsParentClientRpc(newPos, removeOverride, removeBoth, inElevator, isInShip);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1155355692(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 newPos = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref newPos);
		NetworkObjectReference setPhysicsParent = default(NetworkObjectReference);
		((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref setPhysicsParent, default(ForNetworkSerializable));
		bool isOverride = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isOverride, default(ForPrimitives));
		bool inElevator = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inElevator, default(ForPrimitives));
		bool isInShip = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isInShip, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((PlayerControllerB)(object)target).UpdatePlayerPhysicsParentServerRpc(newPos, setPhysicsParent, isOverride, inElevator, isInShip);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_3055429600(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newPos);
			NetworkObjectReference setPhysicsParent = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref setPhysicsParent, default(ForNetworkSerializable));
			bool isOverride = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isOverride, default(ForPrimitives));
			bool inElevator = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inElevator, default(ForPrimitives));
			bool isInShip = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isInShip, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).UpdatePlayerPhysicsParentClientRpc(newPos, setPhysicsParent, isOverride, inElevator, isInShip);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3332990272(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool fallHard = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref fallHard, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).LandFromJumpServerRpc(fallHard);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_983565270(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool fallHard = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref fallHard, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).LandFromJumpClientRpc(fallHard);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2504133785(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong newPlayerSteamId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref newPlayerSteamId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).SendNewPlayerValuesServerRpc(newPlayerSteamId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_956616685(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			ulong[] playerSteamIds = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<ulong>(ref playerSteamIds, default(ForPrimitives));
			}
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).SendNewPlayerValuesClientRpc(playerSteamIds);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3237016509(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).DisableJetpackModeServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1367193869(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).DisableJetpackModeClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1048203095(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).SetFaceUnderwaterServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1284827260(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).SetFaceUnderwaterClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3262284737(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).SetFaceOutOfWaterServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4067397557(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).SetFaceOutOfWaterClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4121569671(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		int playerId = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
		bool spawnBody = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref spawnBody, default(ForPrimitives));
		Vector3 bodyVelocity = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref bodyVelocity);
		int num = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref num);
		int deathAnimation = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref deathAnimation);
		Vector3 positionOffset = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref positionOffset);
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((PlayerControllerB)(object)target).KillPlayerServerRpc(playerId, spawnBody, bodyVelocity, num, deathAnimation, positionOffset);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_1905939161(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			bool spawnBody = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref spawnBody, default(ForPrimitives));
			Vector3 bodyVelocity = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref bodyVelocity);
			int num = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref num);
			int deathAnimation = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref deathAnimation);
			Vector3 positionOffset = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref positionOffset);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).KillPlayerClientRpc(playerId, spawnBody, bodyVelocity, num, deathAnimation, positionOffset);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1388366573(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int itemSlot = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref itemSlot);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).DestroyItemInSlotServerRpc(itemSlot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_899109231(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int itemSlot = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref itemSlot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).DestroyItemInSlotClientRpc(itemSlot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_760742013(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).DropAllHeldItemsServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2096889309(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).DropAllHeldItemsClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_301044013(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newBodyPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newBodyPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).SyncBodyPositionClientRpc(newBodyPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_638895557(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int damageAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref damageAmount);
			Vector3 hitDirection = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref hitDirection);
			int playerWhoHit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoHit);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlayerControllerB)(object)target).DamagePlayerFromOtherClientServerRpc(damageAmount, hitDirection, playerWhoHit);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2557046125(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int damageAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref damageAmount);
			Vector3 hitDirection = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref hitDirection);
			int playerWhoHit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoHit);
			int newHealthAmount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newHealthAmount);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlayerControllerB)(object)target).DamagePlayerFromOtherClientClientRpc(damageAmount, hitDirection, playerWhoHit, newHealthAmount);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "PlayerControllerB";
	}
}
