public enum BabyState
{
	Roaming,
	Observing,
	RolledOver,
	Running
}
