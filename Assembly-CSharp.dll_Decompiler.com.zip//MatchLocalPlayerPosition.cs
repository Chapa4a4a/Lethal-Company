using UnityEngine;

public class MatchLocalPlayerPosition : MonoBehaviour
{
	private void LateUpdate()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)GameNetworkManager.Instance != (Object)null && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
		{
			((Component)this).transform.position = ((Component)GameNetworkManager.Instance.localPlayerController).transform.position;
		}
	}
}
