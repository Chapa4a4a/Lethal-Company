using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using GameNetcodeStuff;
using Netcode.Transports.Facepunch;
using Steamworks;
using Steamworks.Data;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameNetworkManager : MonoBehaviour
{
	public int gameVersionNum = 1;

	public int compatibleFileCutoffVersion;

	public bool AlwaysDisplayNews = true;

	public bool isDemo;

	[Space(5f)]
	public bool SendExceptionsToServer;

	[Space(5f)]
	public bool disableSteam;

	private FacepunchTransport transport;

	public List<SteamId> steamIdsInLobby = new List<SteamId>();

	public HostSettings lobbyHostSettings;

	public int connectedPlayers;

	public int maxAllowedPlayers = 4;

	private bool hasSubscribedToConnectionCallbacks;

	public bool gameHasStarted;

	public PlayerControllerB localPlayerController;

	public int disconnectReason;

	public string username;

	public bool isDisconnecting;

	public bool firstTimeInMenu = true;

	public bool isHostingGame;

	public bool waitingForLobbyDataRefresh;

	public int playersInRefreshedLobby;

	public string steamLobbyName;

	public const string LCchallengeFileName = "LCChallengeFile";

	public const string LCsaveFile1Name = "LCSaveFile1";

	public const string LCsaveFile2Name = "LCSaveFile2";

	public const string LCsaveFile3Name = "LCSaveFile3";

	public const string generalSaveDataName = "LCGeneralSaveData";

	public string currentSaveFileName = "LCSaveFile1";

	public int saveFileNum;

	public AudioClip buttonCancelSFX;

	public AudioClip buttonSelectSFX;

	public AudioClip buttonPressSFX;

	public AudioClip buttonTuneSFX;

	public bool disallowConnection;

	public string disconnectionReasonMessage;

	public bool localClientWaitingForApproval;

	public bool disapprovedClientThisFrame;

	private string previousLogErrorString;

	public static GameNetworkManager Instance { get; private set; }

	public Lobby? currentLobby { get; private set; }

	private void LogCallback(string condition, string stackTrace, LogType type)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Invalid comparison between Unknown and I4
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		if (((int)type != 4 && (int)type != 0) || (Object)(object)HUDManager.Instance == (Object)null || (Object)(object)localPlayerController == (Object)null)
		{
			return;
		}
		string text = condition + stackTrace.Substring(0, Mathf.Clamp(200, 0, stackTrace.Length));
		if (string.IsNullOrEmpty(previousLogErrorString) || !(text == previousLogErrorString))
		{
			previousLogErrorString = text;
			if (!SendExceptionsToServer)
			{
				HUDManager.Instance.AddToErrorLog(text, (int)localPlayerController.playerClientId);
				return;
			}
			HUDManager.Instance.SendErrorMessageServerRpc(text, (int)localPlayerController.playerClientId);
			HUDManager.Instance.AddToErrorLog(text, (int)localPlayerController.playerClientId);
		}
	}

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
			((MonoBehaviour)this).StartCoroutine(waitFrameBeforeFindingUsername());
			if (compatibleFileCutoffVersion > gameVersionNum)
			{
				Debug.LogError((object)"The compatible file cutoff version was higher than the game version number. This should not happen!!");
				compatibleFileCutoffVersion = gameVersionNum;
			}
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private IEnumerator waitFrameBeforeFindingUsername()
	{
		yield return null;
		yield return null;
		if (!disableSteam)
		{
			string text = SteamClient.Name.ToString();
			if (text.Length > 18)
			{
				text.Remove(15, text.Length - 15);
				text += "...";
			}
			username = text;
		}
		else
		{
			username = "PlayerName";
		}
	}

	public int GetWeekNumber()
	{
		DateTime dateTime = new DateTime(2023, 12, 11);
		DateTime dateTime2;
		try
		{
			dateTime2 = DateTime.UtcNow;
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Unable to get UTC time; defaulting to system date time; {arg}");
			dateTime2 = DateTime.Today;
		}
		Debug.Log((object)$"Returning week num: {(int)((dateTime2 - dateTime).TotalDays / 7.0)}");
		return (int)((dateTime2 - dateTime).TotalDays / 7.0);
	}

	public string GetNameForWeekNumber(int overrideWeekNum = -1)
	{
		StringBuilder stringBuilder = new StringBuilder();
		Random random = ((overrideWeekNum == -1) ? new Random(GetWeekNumber()) : new Random(overrideWeekNum));
		List<char> list = "BCDFGKLMNPSTVZHRW".ToCharArray().ToList();
		List<char> list2 = "AEIOU".ToCharArray().ToList();
		int num = 0;
		int num2 = 1;
		char c = 'a';
		int num3 = ((random.Next(0, 100) >= 40) ? random.Next(3, 8) : random.Next(3, 5));
		for (int i = 0; i < num3; i++)
		{
			int num4 = 5;
			if (list.Contains(c))
			{
				num4 -= 2;
			}
			if (c == 'O' || c == 'E')
			{
				num4--;
			}
			if (random.Next(0, num4) > num2)
			{
				if (random.Next(0, 100) < 40)
				{
					if (!list.Contains('Y'))
					{
						list.Add('Y');
						list.Add('J');
						list.Add('X');
						list.Add('Q');
					}
				}
				else if (list.Contains('Y'))
				{
					list.Remove('Y');
					list.Remove('J');
					list.Remove('X');
					list.Remove('Q');
				}
				bool flag = false;
				char c2 = char.ToUpper(c);
				int num5 = list.Count;
				while (num5 > 0)
				{
					char c3 = list[random.Next(0, list.Count)];
					if (list.Count == 1 || num > 1 || random.Next(0, 100) < 33 || c2 == 'Q' || c2 == 'K' || (c2 == 'Q' && c3 == 'B') || (c2 == 'H' && c3 == 'P') || (c2 == 'I' && c3 == 'W'))
					{
						list.Remove(c3);
						num5--;
						num = 0;
						flag = true;
						continue;
					}
					c = c3;
					break;
				}
				if (flag)
				{
					list = "BCDFGJKLMNPSTVZHRW".ToCharArray().ToList();
				}
				if (c == c2)
				{
					num++;
				}
				num2++;
			}
			else
			{
				bool flag2 = false;
				char c2 = char.ToUpper(c);
				int num6 = list2.Count;
				while (num6 > 0)
				{
					char c3 = list2[random.Next(0, list2.Count)];
					if ((list2.Count == 1 && c2 == 'U' && c3 == 'U') || (c2 == 'I' && c3 == 'I') || (c2 == 'I' && c3 == 'U' && i == 1))
					{
						list2.Remove(c3);
						num6--;
						flag2 = true;
						continue;
					}
					c = c3;
					break;
				}
				num2 = 1;
				if (flag2)
				{
					list2 = "AEIOU".ToCharArray().ToList();
				}
			}
			if (i != 0)
			{
				c = char.ToLower(c);
			}
			stringBuilder.Append(c);
		}
		return stringBuilder.ToString() + "-" + random.Next(1, 99);
	}

	private void Start()
	{
		((Component)this).GetComponent<NetworkManager>().NetworkConfig.ProtocolVersion = (ushort)gameVersionNum;
		if (Object.op_Implicit((Object)(object)((Component)this).GetComponent<FacepunchTransport>()))
		{
			transport = ((Component)this).GetComponent<FacepunchTransport>();
		}
		else
		{
			Debug.Log((object)"Facepunch transport is disabled.");
		}
		saveFileNum = ES3.Load<int>("SelectedFile", "LCGeneralSaveData", 0);
		switch (saveFileNum)
		{
		case -1:
			currentSaveFileName = "LCChallengeFile";
			break;
		case 0:
			currentSaveFileName = "LCSaveFile1";
			break;
		case 1:
			currentSaveFileName = "LCSaveFile2";
			break;
		case 2:
			currentSaveFileName = "LCSaveFile3";
			break;
		default:
			currentSaveFileName = "LCSaveFile1";
			break;
		}
	}

	private void OnEnable()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected O, but got Unknown
		Application.logMessageReceived += new LogCallback(LogCallback);
		if (!disableSteam)
		{
			Debug.Log((object)"subcribing to steam callbacks");
			SteamMatchmaking.OnLobbyCreated += SteamMatchmaking_OnLobbyCreated;
			SteamMatchmaking.OnLobbyMemberJoined += SteamMatchmaking_OnLobbyMemberJoined;
			SteamMatchmaking.OnLobbyMemberLeave += SteamMatchmaking_OnLobbyMemberLeave;
			SteamMatchmaking.OnLobbyInvite += SteamMatchmaking_OnLobbyInvite;
			SteamMatchmaking.OnLobbyGameCreated += SteamMatchmaking_OnLobbyGameCreated;
			SteamFriends.OnGameLobbyJoinRequested += SteamFriends_OnGameLobbyJoinRequested;
		}
	}

	private void OnDisable()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected O, but got Unknown
		Application.logMessageReceived -= new LogCallback(LogCallback);
		if (!disableSteam)
		{
			Debug.Log((object)"unsubscribing from steam callbacks");
			SteamMatchmaking.OnLobbyCreated -= SteamMatchmaking_OnLobbyCreated;
			SteamMatchmaking.OnLobbyMemberJoined -= SteamMatchmaking_OnLobbyMemberJoined;
			SteamMatchmaking.OnLobbyMemberLeave -= SteamMatchmaking_OnLobbyMemberLeave;
			SteamMatchmaking.OnLobbyInvite -= SteamMatchmaking_OnLobbyInvite;
			SteamMatchmaking.OnLobbyGameCreated -= SteamMatchmaking_OnLobbyGameCreated;
			SteamFriends.OnGameLobbyJoinRequested -= SteamFriends_OnGameLobbyJoinRequested;
		}
	}

	public void SetSteamFriendGrouping(string groupName, int groupSize, string steamDisplay)
	{
		if (!disableSteam)
		{
			SteamFriends.SetRichPresence("steam_player_group", groupName);
			SteamFriends.SetRichPresence("steam_player_group_size", groupSize.ToString());
			SteamFriends.SetRichPresence("steam_display", steamDisplay);
		}
	}

	private void ConnectionApproval(ConnectionApprovalRequest request, ConnectionApprovalResponse response)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)("Connection approval callback! Game version of client request: " + Encoding.ASCII.GetString(request.Payload).ToString()));
		Debug.Log((object)$"Joining client id: {request.ClientNetworkId}; Local/host client id: {NetworkManager.Singleton.LocalClientId}");
		if (request.ClientNetworkId == NetworkManager.Singleton.LocalClientId)
		{
			Debug.Log((object)"Stopped connection approval callback, as the client in question was the host!");
			return;
		}
		bool flag = !disallowConnection;
		if (flag)
		{
			string @string = Encoding.ASCII.GetString(request.Payload);
			string[] array = @string.Split(",");
			if (string.IsNullOrEmpty(@string))
			{
				response.Reason = "Unknown; please verify your game files.";
				flag = false;
			}
			else if (Instance.connectedPlayers >= 4)
			{
				response.Reason = "Lobby is full!";
				flag = false;
			}
			else if (Instance.gameHasStarted)
			{
				response.Reason = "Game has already started!";
				flag = false;
			}
			else if (Instance.gameVersionNum.ToString() != array[0])
			{
				response.Reason = $"Game version mismatch! Their version: {gameVersionNum}. Your version: {array[0]}";
				flag = false;
			}
			else if (!disableSteam && ((Object)(object)StartOfRound.Instance == (Object)null || array.Length < 2 || StartOfRound.Instance.KickedClientIds.Contains((ulong)Convert.ToInt64(array[1]))))
			{
				response.Reason = "You cannot rejoin after being kicked.";
				flag = false;
			}
		}
		else
		{
			response.Reason = "The host was not accepting connections.";
		}
		Debug.Log((object)$"Approved connection?: {flag}. Connected players #: {Instance.connectedPlayers}");
		Debug.Log((object)("Disapproval reason: " + response.Reason));
		response.CreatePlayerObject = false;
		response.Approved = flag;
		response.Pending = false;
	}

	private void Singleton_OnClientDisconnectCallback(ulong clientId)
	{
		Debug.Log((object)"Disconnect callback called");
		Debug.Log((object)$"Is server: {NetworkManager.Singleton.IsServer}; ishost: {NetworkManager.Singleton.IsHost}; isConnectedClient: {NetworkManager.Singleton.IsConnectedClient}");
		if ((Object)(object)NetworkManager.Singleton == (Object)null)
		{
			Debug.Log((object)"Network singleton is null!");
			return;
		}
		if (clientId == NetworkManager.Singleton.LocalClientId && localClientWaitingForApproval)
		{
			OnLocalClientConnectionDisapproved(clientId);
			return;
		}
		if (NetworkManager.Singleton.IsServer)
		{
			Debug.Log((object)$"Disconnect callback called in gamenetworkmanager; disconnecting clientId: {clientId}");
			if ((Object)(object)StartOfRound.Instance != (Object)null && !StartOfRound.Instance.ClientPlayerList.ContainsKey(clientId))
			{
				Debug.Log((object)"A Player disconnected but they were not in clientplayerlist");
				return;
			}
			if (clientId == NetworkManager.Singleton.LocalClientId)
			{
				Debug.Log((object)"Disconnect callback called for local client; ignoring.");
				return;
			}
			if (NetworkManager.Singleton.IsServer)
			{
				connectedPlayers--;
			}
		}
		if ((Object)(object)StartOfRound.Instance != (Object)null)
		{
			StartOfRound.Instance.OnClientDisconnect(clientId);
		}
		Debug.Log((object)"Disconnect callback from networkmanager in gamenetworkmanager");
	}

	private void OnLocalClientConnectionDisapproved(ulong clientId)
	{
		localClientWaitingForApproval = false;
		Debug.Log((object)$"Local client connection denied; clientId: {clientId}; reason: {disconnectionReasonMessage.ToString()}");
		if (!string.IsNullOrEmpty(NetworkManager.Singleton.DisconnectReason))
		{
			disconnectionReasonMessage = NetworkManager.Singleton.DisconnectReason;
		}
		Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)5);
		LeaveCurrentSteamLobby();
		SetInstanceValuesBackToDefault();
		if (NetworkManager.Singleton.IsConnectedClient)
		{
			Debug.Log((object)"Calling shutdown(true) on server in OnLocalClientDisapproved");
			NetworkManager.Singleton.Shutdown(true);
		}
	}

	private void Singleton_OnClientConnectedCallback(ulong clientId)
	{
		if (!((Object)(object)NetworkManager.Singleton == (Object)null))
		{
			Debug.Log((object)"Client connected callback in gamenetworkmanager");
			if (NetworkManager.Singleton.IsServer)
			{
				connectedPlayers++;
			}
			if ((Object)(object)StartOfRound.Instance != (Object)null)
			{
				StartOfRound.Instance.OnClientConnect(clientId);
			}
		}
	}

	public void SubscribeToConnectionCallbacks()
	{
		if (!hasSubscribedToConnectionCallbacks)
		{
			NetworkManager.Singleton.OnClientConnectedCallback += Instance.Singleton_OnClientConnectedCallback;
			NetworkManager.Singleton.OnClientDisconnectCallback += Instance.Singleton_OnClientDisconnectCallback;
			hasSubscribedToConnectionCallbacks = true;
		}
	}

	public void SteamFriends_OnGameLobbyJoinRequested(Lobby lobby, SteamId id)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)Object.FindObjectOfType<MenuManager>() == (Object)null)
		{
			return;
		}
		if (!Instance.currentLobby.HasValue)
		{
			Debug.Log((object)"JOIN REQUESTED through steam invite");
			Debug.Log((object)$"lobby id: {((Lobby)(ref lobby)).Id}");
			LobbySlot.JoinLobbyAfterVerifying(lobby, ((Lobby)(ref lobby)).Id);
			return;
		}
		Debug.Log((object)"Attempted to join by Steam invite request, but already in a lobby.");
		MenuManager menuManager = Object.FindObjectOfType<MenuManager>();
		if ((Object)(object)menuManager != (Object)null)
		{
			menuManager.DisplayMenuNotification("You are already in a lobby!", "Back");
		}
		Lobby value = Instance.currentLobby.Value;
		((Lobby)(ref value)).Leave();
		Instance.currentLobby = null;
	}

	public bool LobbyDataIsJoinable(Lobby lobby)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		string data = ((Lobby)(ref lobby)).GetData("vers");
		if (data != Instance.gameVersionNum.ToString())
		{
			Debug.Log((object)$"Lobby join denied! Attempted to join vers.{data} lobby id: {((Lobby)(ref lobby)).Id}");
			Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)2, $"The server host is playing on version {data} while you are on version {Instance.gameVersionNum}.");
			return false;
		}
		Friend[] array = SteamFriends.GetBlocked().ToArray();
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				Debug.Log((object)$"blocked users {i}: {((Friend)(ref array[i])).Name}; id: {array[i].Id}");
				if (((Lobby)(ref lobby)).IsOwnedBy(array[i].Id))
				{
					Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)2, "An error occured!");
					return false;
				}
			}
		}
		else
		{
			Debug.Log((object)"Blocked users list is null");
		}
		if (((Lobby)(ref lobby)).GetData("joinable") == "false")
		{
			Debug.Log((object)"Lobby join denied! Host lobby is not joinable");
			Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)2, "The server host has already landed their ship, or they are still loading in.");
			return false;
		}
		if (((Lobby)(ref lobby)).MemberCount >= 4 || ((Lobby)(ref lobby)).MemberCount < 1)
		{
			Debug.Log((object)$"Lobby join denied! Too many members in lobby! {((Lobby)(ref lobby)).Id}");
			Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)4, "The server is full!");
			return false;
		}
		Debug.Log((object)$"Lobby join accepted! Lobby id {((Lobby)(ref lobby)).Id} is OK");
		return true;
	}

	public IEnumerator TimeOutLobbyRefresh()
	{
		yield return (object)new WaitForSeconds(7f);
		waitingForLobbyDataRefresh = false;
		Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)5, "Error! Could not get the lobby data. Are you offline?");
		SteamMatchmaking.OnLobbyDataChanged -= LobbySlot.OnLobbyDataRefresh;
	}

	private void SteamMatchmaking_OnLobbyMemberJoined(Lobby lobby, Friend friend)
	{
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		if (Instance.currentLobby.HasValue)
		{
			Lobby value = Instance.currentLobby.Value;
			Friend[] array = ((Lobby)(ref value)).Members.ToArray();
			if (array != null)
			{
				for (int i = 0; i < array.Length; i++)
				{
					if (!steamIdsInLobby.Contains(array[i].Id))
					{
						steamIdsInLobby.Add(array[i].Id);
					}
				}
			}
		}
		Debug.Log((object)$"Player joined w steamId: {friend.Id}");
		if ((Object)(object)StartOfRound.Instance != (Object)null)
		{
			QuickMenuManager quickMenuManager = Object.FindObjectOfType<QuickMenuManager>();
			if ((Object)(object)quickMenuManager != (Object)null)
			{
				string input = NoPunctuation(((Friend)(ref friend)).Name);
				input = Regex.Replace(input, "[^\\w\\._]", "");
				quickMenuManager.AddUserToPlayerList(SteamId.op_Implicit(friend.Id), input, StartOfRound.Instance.connectedPlayersAmount);
			}
		}
	}

	private string NoPunctuation(string input)
	{
		return new string(input.Where((char c) => char.IsLetter(c)).ToArray());
	}

	private void SteamMatchmaking_OnLobbyMemberLeave(Lobby lobby, Friend friend)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if (!steamIdsInLobby.Contains(friend.Id))
		{
			steamIdsInLobby.Remove(friend.Id);
		}
	}

	private void SteamMatchmaking_OnLobbyGameCreated(Lobby lobby, uint arg2, ushort arg3, SteamId arg4)
	{
	}

	private void SteamMatchmaking_OnLobbyInvite(Friend friend, Lobby lobby)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"You got invited by {((Friend)(ref friend)).Name} to join {((Lobby)(ref lobby)).Id}");
	}

	private void SteamMatchmaking_OnLobbyCreated(Result result, Lobby lobby)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Invalid comparison between Unknown and I4
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		if ((int)result != 1)
		{
			Debug.LogError((object)$"Lobby could not be created! {result}", (Object)(object)this);
		}
		((Lobby)(ref lobby)).SetData("name", lobbyHostSettings.lobbyName.ToString());
		((Lobby)(ref lobby)).SetData("vers", Instance.gameVersionNum.ToString());
		if (!string.IsNullOrEmpty(lobbyHostSettings.serverTag))
		{
			((Lobby)(ref lobby)).SetData("tag", lobbyHostSettings.serverTag.ToLower());
		}
		else
		{
			((Lobby)(ref lobby)).SetData("tag", "none");
		}
		if (lobbyHostSettings.isLobbyPublic)
		{
			((Lobby)(ref lobby)).SetPublic();
		}
		else
		{
			((Lobby)(ref lobby)).SetPrivate();
			((Lobby)(ref lobby)).SetFriendsOnly();
		}
		((Lobby)(ref lobby)).SetJoinable(false);
		Instance.currentLobby = lobby;
		steamLobbyName = ((Lobby)(ref lobby)).GetData("name");
		Debug.Log((object)"Lobby has been created");
	}

	public void LeaveLobbyAtGameStart()
	{
		if (!Instance.currentLobby.HasValue)
		{
			Debug.Log((object)"Current lobby is null. (Attempted to close lobby at game start)");
		}
		else
		{
			LeaveCurrentSteamLobby();
		}
	}

	public void SetLobbyJoinable(bool joinable)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		if (!Instance.currentLobby.HasValue)
		{
			Debug.Log((object)$"Current lobby is null. (Attempted to set lobby joinable {joinable}.)");
			return;
		}
		Lobby value = Instance.currentLobby.Value;
		((Lobby)(ref value)).SetJoinable(joinable);
		if ((Object)(object)StartOfRound.Instance != (Object)null && currentSaveFileName == "LCChallengeFile")
		{
			value = Instance.currentLobby.Value;
			((Lobby)(ref value)).SetData("chal", "t");
		}
		else
		{
			value = Instance.currentLobby.Value;
			((Lobby)(ref value)).SetData("chal", "f");
		}
	}

	public void SetCurrentLobbyNull()
	{
		currentLobby = null;
	}

	private void OnApplicationQuit()
	{
		try
		{
			ES3.Save<int>("SelectedFile", saveFileNum, "LCGeneralSaveData");
			Disconnect();
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while disconnecting: {arg}");
		}
		if ((Object)(object)DiscordController.Instance != (Object)null)
		{
			DiscordController.Instance.UpdateStatus(clear: true);
		}
	}

	public void Disconnect()
	{
		if (!isDisconnecting && !((Object)(object)StartOfRound.Instance == (Object)null))
		{
			isDisconnecting = true;
			if (isHostingGame)
			{
				disallowConnection = true;
			}
			StartDisconnect();
			SaveGame();
			if ((Object)(object)NetworkManager.Singleton == (Object)null)
			{
				Debug.Log((object)"Server is not active; quitting to main menu");
				ResetGameValuesToDefault();
				SceneManager.LoadScene("MainMenu");
			}
			else
			{
				((MonoBehaviour)this).StartCoroutine(DisconnectProcess());
			}
		}
	}

	private IEnumerator DisconnectProcess()
	{
		Debug.Log((object)$"Shutting down and disconnecting from server. Is host?: {NetworkManager.Singleton.IsServer}");
		NetworkManager.Singleton.Shutdown(false);
		yield return (object)new WaitUntil((Func<bool>)(() => !NetworkManager.Singleton.ShutdownInProgress));
		ResetGameValuesToDefault();
		SceneManager.LoadScene("MainMenu");
	}

	private void StartDisconnect()
	{
		if (!disableSteam)
		{
			Debug.Log((object)"Leaving current lobby");
			LeaveCurrentSteamLobby();
			steamLobbyName = SteamClient.Name;
		}
		if ((Object)(object)DiscordController.Instance != (Object)null)
		{
			DiscordController.Instance.UpdateStatus(clear: true);
		}
		Debug.Log((object)"Disconnecting and setting networkobjects to destroy with owner");
		NetworkObject[] array = Object.FindObjectsOfType<NetworkObject>(true);
		for (int i = 0; i < array.Length; i++)
		{
			array[i].DontDestroyWithOwner = false;
		}
		Terminal terminal = Object.FindObjectOfType<Terminal>();
		if ((Object)(object)terminal != (Object)null && terminal.displayingSteamKeyboard)
		{
			SteamUtils.OnGamepadTextInputDismissed -= terminal.OnGamepadTextInputDismissed_t;
		}
	}

	public void SaveGame()
	{
		SaveLocalPlayerValues();
		SaveGameValues();
	}

	private void ResetGameValuesToDefault()
	{
		ResetUnlockablesListValues();
		ResetStaticVariables();
		if ((Object)(object)StartOfRound.Instance != (Object)null)
		{
			StartOfRound.Instance.OnLocalDisconnect();
		}
		SetInstanceValuesBackToDefault();
	}

	public void ResetStaticVariables()
	{
		SprayPaintItem.sprayPaintDecals.Clear();
		SprayPaintItem.sprayPaintDecalsIndex = 0;
		SprayPaintItem.previousSprayDecal = null;
		ShipTeleporter.hasBeenSpawnedThisSession = false;
		ShipTeleporter.hasBeenSpawnedThisSessionInverse = false;
		RadMechAI.PooledBlastMarks.Clear();
	}

	public void ResetUnlockablesListValues(bool onlyResetPrefabItems = false)
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)StartOfRound.Instance != (Object)null))
		{
			return;
		}
		Debug.Log((object)"Resetting unlockables list!");
		List<UnlockableItem> unlockables = StartOfRound.Instance.unlockablesList.unlockables;
		for (int i = 0; i < unlockables.Count; i++)
		{
			if (!onlyResetPrefabItems || unlockables[i].spawnPrefab)
			{
				unlockables[i].hasBeenUnlockedByPlayer = false;
				if (unlockables[i].unlockableType == 1)
				{
					unlockables[i].placedPosition = Vector3.zero;
					unlockables[i].placedRotation = Vector3.zero;
					unlockables[i].hasBeenMoved = false;
					unlockables[i].inStorage = false;
				}
			}
		}
	}

	private void SaveLocalPlayerValues()
	{
		try
		{
			if ((Object)(object)HUDManager.Instance != (Object)null)
			{
				if (HUDManager.Instance.setTutorialArrow)
				{
					ES3.Save<int>("FinishedShockMinigame", PatcherTool.finishedShockMinigame, "LCGeneralSaveData");
				}
				if (HUDManager.Instance.hasSetSavedValues)
				{
					ES3.Save<int>("PlayerLevel", HUDManager.Instance.localPlayerLevel, "LCGeneralSaveData");
					ES3.Save<int>("PlayerXPNum", HUDManager.Instance.localPlayerXP, "LCGeneralSaveData");
				}
			}
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"ERROR occured while saving local player values!: {arg}");
		}
	}

	public void ResetSavedGameValues()
	{
		if (!isHostingGame)
		{
			return;
		}
		TimeOfDay timeOfDay = Object.FindObjectOfType<TimeOfDay>();
		if ((Object)(object)timeOfDay != (Object)null)
		{
			ES3.Save<int>("GlobalTime", 100, currentSaveFileName);
			ES3.Save<int>("QuotaFulfilled", 0, currentSaveFileName);
			ES3.Save<int>("QuotasPassed", 0, currentSaveFileName);
			ES3.Save<int>("ProfitQuota", timeOfDay.quotaVariables.startingQuota, currentSaveFileName);
			ES3.Save<int>("DeadlineTime", (int)(timeOfDay.totalTime * (float)timeOfDay.quotaVariables.deadlineDaysAmount), currentSaveFileName);
			ES3.Save<int>("GroupCredits", timeOfDay.quotaVariables.startingCredits, currentSaveFileName);
		}
		ES3.Save<int>("CurrentPlanetID", 0, currentSaveFileName);
		StartOfRound startOfRound = Object.FindObjectOfType<StartOfRound>();
		if (!((Object)(object)startOfRound != (Object)null))
		{
			return;
		}
		ES3.DeleteKey("UnlockedShipObjects", Instance.currentSaveFileName);
		for (int i = 0; i < startOfRound.levels.Length; i++)
		{
			ES3.Save<int>($"Level{startOfRound.levels[i].levelID}Mold", 0, currentSaveFileName);
			ES3.Save<int>($"Level{startOfRound.levels[i].levelID}MoldOrigin", -1, currentSaveFileName);
			ES3.DeleteKey($"Level{startOfRound.levels[i].levelID}DestroyedMold", currentSaveFileName);
		}
		for (int j = 0; j < startOfRound.unlockablesList.unlockables.Count; j++)
		{
			if (startOfRound.unlockablesList.unlockables[j].unlockableType == 1)
			{
				ES3.DeleteKey("ShipUnlockMoved_" + startOfRound.unlockablesList.unlockables[j].unlockableName, currentSaveFileName);
				ES3.DeleteKey("ShipUnlockStored_" + startOfRound.unlockablesList.unlockables[j].unlockableName, currentSaveFileName);
				ES3.DeleteKey("ShipUnlockPos_" + startOfRound.unlockablesList.unlockables[j].unlockableName, currentSaveFileName);
				ES3.DeleteKey("ShipUnlockRot_" + startOfRound.unlockablesList.unlockables[j].unlockableName, currentSaveFileName);
			}
		}
		ResetUnlockablesListValues();
		ES3.Save<int>("RandomSeed", startOfRound.randomMapSeed + 1, currentSaveFileName);
		ES3.Save<int>("Stats_DaysSpent", 0, currentSaveFileName);
		ES3.Save<int>("Stats_Deaths", 0, currentSaveFileName);
		ES3.Save<int>("Stats_ValueCollected", 0, currentSaveFileName);
		ES3.Save<int>("Stats_StepsTaken", 0, currentSaveFileName);
	}

	private void SaveGameValues()
	{
		//IL_04d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0516: Unknown result type (might be due to invalid IL or missing references)
		if (StartOfRound.Instance.isChallengeFile && Instance.gameHasStarted)
		{
			ES3.Save<bool>("FinishedChallenge", true, "LCChallengeFile");
			if (!StartOfRound.Instance.displayedLevelResults)
			{
				ES3.Save<int>("ProfitEarned", 0, "LCChallengeFile");
			}
			else
			{
				Debug.Log((object)$"Saved challenge score as {StartOfRound.Instance.scrapCollectedLastRound}; total scrap in level: {RoundManager.Instance.totalScrapValueInLevel}");
				ES3.Save<int>("ProfitEarned", StartOfRound.Instance.scrapCollectedLastRound, "LCChallengeFile");
			}
		}
		if (!isHostingGame)
		{
			return;
		}
		if (!ES3.KeyExists("FileGameVers", currentSaveFileName))
		{
			ES3.Save<int>("FileGameVers", Instance.gameVersionNum, currentSaveFileName);
		}
		if (!StartOfRound.Instance.inShipPhase || StartOfRound.Instance.isChallengeFile)
		{
			return;
		}
		try
		{
			TimeOfDay timeOfDay = Object.FindObjectOfType<TimeOfDay>();
			if ((Object)(object)timeOfDay != (Object)null)
			{
				ES3.Save<int>("QuotaFulfilled", timeOfDay.quotaFulfilled, currentSaveFileName);
				ES3.Save<int>("QuotasPassed", timeOfDay.timesFulfilledQuota, currentSaveFileName);
				ES3.Save<int>("ProfitQuota", timeOfDay.profitQuota, currentSaveFileName);
				ES3.Save<bool>("ShownAdThisQuota", timeOfDay.hasShownAdThisQuota, currentSaveFileName);
			}
			ES3.Save<int>("CurrentPlanetID", StartOfRound.Instance.currentLevelID, currentSaveFileName);
			if (timeOfDay.furniturePlacedAtQuotaStart == null || timeOfDay.furniturePlacedAtQuotaStart.Count == 0)
			{
				if (ES3.KeyExists("LuckyFurniture", currentSaveFileName))
				{
					ES3.DeleteKey("LuckyFurniture", currentSaveFileName);
				}
			}
			else
			{
				ES3.Save<int[]>("LuckyFurniture", timeOfDay.furniturePlacedAtQuotaStart.ToArray(), currentSaveFileName);
			}
			Terminal terminal = Object.FindObjectOfType<Terminal>();
			if ((Object)(object)terminal != (Object)null)
			{
				ES3.Save<int>("GroupCredits", terminal.groupCredits, currentSaveFileName);
				if (terminal.unlockedStoryLogs.Count > 0)
				{
					ES3.Save<int[]>("StoryLogs", terminal.unlockedStoryLogs.ToArray(), currentSaveFileName);
				}
				if (terminal.scannedEnemyIDs.Count > 0)
				{
					ES3.Save<int[]>("EnemyScans", terminal.scannedEnemyIDs.ToArray(), currentSaveFileName);
				}
				ES3.Save<bool>("VehicleWarrantyTicket", terminal.hasWarrantyTicket, currentSaveFileName);
			}
			StartOfRound startOfRound = Object.FindObjectOfType<StartOfRound>();
			MoldSpreadManager moldSpreadManager = Object.FindObjectOfType<MoldSpreadManager>();
			if ((Object)(object)startOfRound != (Object)null)
			{
				for (int i = 0; i < startOfRound.levels.Length; i++)
				{
					ES3.Save<int>($"Level{startOfRound.levels[i].levelID}Mold", startOfRound.levels[i].moldSpreadIterations, currentSaveFileName);
					ES3.Save<int>($"Level{startOfRound.levels[i].levelID}MoldOrigin", startOfRound.levels[i].moldStartPosition, currentSaveFileName);
					if ((Object)(object)moldSpreadManager != (Object)null)
					{
						if (moldSpreadManager.planetMoldStates[i].destroyedMold.Count > 0)
						{
							ES3.Save<int[]>($"Level{startOfRound.levels[i].levelID}DestroyedMold", moldSpreadManager.planetMoldStates[i].destroyedMold.ToArray(), currentSaveFileName);
						}
						else
						{
							ES3.DeleteKey($"Level{startOfRound.levels[i].levelID}DestroyedMold", currentSaveFileName);
						}
					}
				}
				List<int> list = new List<int>();
				for (int j = 0; j < startOfRound.unlockablesList.unlockables.Count; j++)
				{
					if (startOfRound.unlockablesList.unlockables[j].hasBeenUnlockedByPlayer || startOfRound.unlockablesList.unlockables[j].hasBeenMoved || startOfRound.unlockablesList.unlockables[j].inStorage)
					{
						list.Add(j);
					}
					if (startOfRound.unlockablesList.unlockables[j].IsPlaceable)
					{
						if (startOfRound.unlockablesList.unlockables[j].canBeStored)
						{
							ES3.Save<bool>("ShipUnlockStored_" + startOfRound.unlockablesList.unlockables[j].unlockableName, startOfRound.unlockablesList.unlockables[j].inStorage, currentSaveFileName);
						}
						if (startOfRound.unlockablesList.unlockables[j].hasBeenMoved)
						{
							ES3.Save<bool>("ShipUnlockMoved_" + startOfRound.unlockablesList.unlockables[j].unlockableName, startOfRound.unlockablesList.unlockables[j].hasBeenMoved, currentSaveFileName);
							ES3.Save<Vector3>("ShipUnlockPos_" + startOfRound.unlockablesList.unlockables[j].unlockableName, startOfRound.unlockablesList.unlockables[j].placedPosition, currentSaveFileName);
							ES3.Save<Vector3>("ShipUnlockRot_" + startOfRound.unlockablesList.unlockables[j].unlockableName, startOfRound.unlockablesList.unlockables[j].placedRotation, currentSaveFileName);
						}
					}
				}
				if (list.Count > 0)
				{
					ES3.Save<int[]>("UnlockedShipObjects", list.ToArray(), currentSaveFileName);
				}
				int num = -1;
				if ((Object)(object)StartOfRound.Instance.attachedVehicle != (Object)null)
				{
					num = StartOfRound.Instance.attachedVehicle.vehicleID;
				}
				ES3.Save<int>("AttachedVehicleID", num, currentSaveFileName);
				Debug.Log((object)$"saved vehicle: {num}");
				ES3.Save<int>("DeadlineTime", (int)Mathf.Clamp(timeOfDay.timeUntilDeadline, 0f, 99999f), currentSaveFileName);
				ES3.Save<int>("RandomSeed", startOfRound.randomMapSeed, currentSaveFileName);
				ES3.Save<int>("Stats_DaysSpent", startOfRound.gameStats.daysSpent, currentSaveFileName);
				ES3.Save<int>("Stats_Deaths", startOfRound.gameStats.deaths, currentSaveFileName);
				ES3.Save<int>("Stats_ValueCollected", startOfRound.gameStats.scrapValueCollected, currentSaveFileName);
				ES3.Save<int>("Stats_StepsTaken", startOfRound.gameStats.allStepsTaken, currentSaveFileName);
			}
			SaveItemsInShip();
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while trying to save game values when disconnecting as host: {arg}");
		}
	}

	private void SaveItemsInShip()
	{
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		GrabbableObject[] array = Object.FindObjectsByType<GrabbableObject>((FindObjectsInactive)0, (FindObjectsSortMode)0);
		if (array == null || array.Length == 0)
		{
			ES3.DeleteKey("shipGrabbableItemIDs", currentSaveFileName);
			ES3.DeleteKey("shipGrabbableItemPos", currentSaveFileName);
			ES3.DeleteKey("shipScrapValues", currentSaveFileName);
			ES3.DeleteKey("shipItemSaveData", currentSaveFileName);
		}
		else
		{
			if (StartOfRound.Instance.isChallengeFile)
			{
				return;
			}
			List<int> list = new List<int>();
			List<Vector3> list2 = new List<Vector3>();
			List<int> list3 = new List<int>();
			List<int> list4 = new List<int>();
			int num = 0;
			for (int i = 0; i < array.Length && i <= StartOfRound.Instance.maxShipItemCapacity; i++)
			{
				if (!StartOfRound.Instance.allItemsList.itemsList.Contains(array[i].itemProperties) || array[i].deactivated)
				{
					continue;
				}
				if ((Object)(object)array[i].itemProperties.spawnPrefab == (Object)null)
				{
					Debug.LogError((object)("Item '" + array[i].itemProperties.itemName + "' has no spawn prefab set!"));
				}
				else
				{
					if (array[i].itemUsedUp)
					{
						continue;
					}
					for (int j = 0; j < StartOfRound.Instance.allItemsList.itemsList.Count; j++)
					{
						if ((Object)(object)StartOfRound.Instance.allItemsList.itemsList[j] == (Object)(object)array[i].itemProperties)
						{
							list.Add(j);
							list2.Add(((Component)array[i]).transform.position);
							break;
						}
					}
					if (array[i].itemProperties.isScrap)
					{
						list3.Add(array[i].scrapValue);
					}
					if (array[i].itemProperties.saveItemVariable)
					{
						try
						{
							num = array[i].GetItemDataToSave();
						}
						catch
						{
							Debug.LogError((object)$"An error occured while getting item data to save for item type: {array[i].itemProperties}; gameobject '{((Object)((Component)array[i]).gameObject).name}'");
						}
						list4.Add(num);
						Debug.Log((object)$"Saved data for item type: {array[i].itemProperties.itemName} - {num}");
					}
				}
			}
			if (list.Count <= 0)
			{
				Debug.Log((object)"Got no ship grabbable items to save.");
				return;
			}
			ES3.Save<Vector3[]>("shipGrabbableItemPos", list2.ToArray(), currentSaveFileName);
			ES3.Save<int[]>("shipGrabbableItemIDs", list.ToArray(), currentSaveFileName);
			if (list3.Count > 0)
			{
				ES3.Save<int[]>("shipScrapValues", list3.ToArray(), currentSaveFileName);
			}
			else
			{
				ES3.DeleteKey("shipScrapValues", currentSaveFileName);
			}
			if (list4.Count > 0)
			{
				ES3.Save<int[]>("shipItemSaveData", list4.ToArray(), currentSaveFileName);
			}
			else
			{
				ES3.DeleteKey("shipItemSaveData", currentSaveFileName);
			}
		}
	}

	private void ConvertUnsellableItemsToCredits()
	{
		if (!StartOfRound.Instance.inShipPhase)
		{
			Debug.Log((object)"Players disconnected, but they were not in ship phase so they can't be reimbursed for their items.");
			ES3.Save<int>("Reimburse", 0, currentSaveFileName);
			return;
		}
		int num = 0;
		GrabbableObject[] array = Object.FindObjectsOfType<GrabbableObject>();
		for (int i = 0; i < array.Length; i++)
		{
			if (!array[i].itemProperties.isScrap && !array[i].itemUsedUp)
			{
				num += array[i].itemProperties.creditsWorth;
			}
		}
		Terminal terminal = Object.FindObjectOfType<Terminal>();
		for (int j = 0; j < terminal.orderedItemsFromTerminal.Count; j++)
		{
			num += terminal.buyableItemsList[terminal.orderedItemsFromTerminal[j]].creditsWorth;
		}
		if (terminal.orderedVehicleFromTerminal != -1)
		{
			num += terminal.buyableVehicles[terminal.orderedVehicleFromTerminal].creditsWorth;
		}
		ES3.Save<int>("Reimburse", num, currentSaveFileName);
	}

	private void SetInstanceValuesBackToDefault()
	{
		isDisconnecting = false;
		disallowConnection = false;
		connectedPlayers = 0;
		localPlayerController = null;
		gameHasStarted = false;
		if ((Object)(object)SoundManager.Instance != (Object)null)
		{
			SoundManager.Instance.ResetValues();
		}
		if (hasSubscribedToConnectionCallbacks && (Object)(object)NetworkManager.Singleton != (Object)null)
		{
			NetworkManager.Singleton.OnClientConnectedCallback -= Singleton_OnClientConnectedCallback;
			NetworkManager.Singleton.OnClientDisconnectCallback -= Singleton_OnClientDisconnectCallback;
			hasSubscribedToConnectionCallbacks = false;
		}
	}

	public void InviteFriendsUI()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		Lobby value = Instance.currentLobby.Value;
		SteamFriends.OpenGameInviteOverlay(((Lobby)(ref value)).Id);
	}

	public async void StartHost()
	{
		if (!Object.op_Implicit((Object)(object)Object.FindObjectOfType<MenuManager>()))
		{
			Debug.Log((object)"Menu manager script is not present in scene; unable to start host");
			return;
		}
		if (Instance.currentLobby.HasValue)
		{
			Debug.Log((object)"Tried starting host but currentLobby is not null! This should not happen. Leaving currentLobby and setting null.");
			LeaveCurrentSteamLobby();
		}
		if (!disableSteam)
		{
			GameNetworkManager instance = Instance;
			instance.currentLobby = await SteamMatchmaking.CreateLobbyAsync(4);
		}
		NetworkManager.Singleton.ConnectionApprovalCallback = ConnectionApproval;
		Object.FindObjectOfType<MenuManager>().StartHosting();
		SubscribeToConnectionCallbacks();
		if (!disableSteam)
		{
			steamIdsInLobby.Add(SteamClient.SteamId);
		}
		isHostingGame = true;
		connectedPlayers = 1;
	}

	public async void JoinLobby(Lobby lobby, SteamId id)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"lobby.id: {((Lobby)(ref lobby)).Id}");
		Debug.Log((object)$"id: {id}");
		if ((Object)(object)Object.FindObjectOfType<MenuManager>() == (Object)null)
		{
			return;
		}
		if (!Instance.currentLobby.HasValue)
		{
			Instance.currentLobby = lobby;
			steamLobbyName = ((Lobby)(ref lobby)).GetData("name");
			if ((int)(await ((Lobby)(ref lobby)).Join()) == 1)
			{
				Debug.Log((object)"Successfully joined steam lobby.");
				Lobby value = Instance.currentLobby.Value;
				Debug.Log((object)$"AA {((Lobby)(ref value)).Id}");
				Debug.Log((object)$"BB {id}");
				Instance.StartClient(((Lobby)(ref lobby)).Owner.Id);
			}
			else
			{
				Debug.Log((object)"Failed to join steam lobby.");
				LeaveCurrentSteamLobby();
				steamLobbyName = SteamClient.Name;
				Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)5, "The host has not loaded or has already landed their ship.");
			}
		}
		else
		{
			Debug.Log((object)"Lobby error!: Attempted to join, but we are already in a Steam lobby. We should not be in a lobby while in the menu!");
			LeaveCurrentSteamLobby();
		}
	}

	public void LeaveCurrentSteamLobby()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			if (Instance.currentLobby.HasValue)
			{
				Lobby value = Instance.currentLobby.Value;
				((Lobby)(ref value)).Leave();
				Instance.currentLobby = null;
				steamIdsInLobby.Clear();
			}
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Error caught while attempting to leave current lobby!: {arg}");
		}
	}

	public void SetConnectionDataBeforeConnecting()
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		localClientWaitingForApproval = true;
		Debug.Log((object)("Game version: " + Instance.gameVersionNum));
		if (disableSteam)
		{
			NetworkManager.Singleton.NetworkConfig.ConnectionData = Encoding.ASCII.GetBytes(Instance.gameVersionNum.ToString());
		}
		else
		{
			NetworkManager.Singleton.NetworkConfig.ConnectionData = Encoding.ASCII.GetBytes(Instance.gameVersionNum + "," + SteamId.op_Implicit(SteamClient.SteamId));
		}
	}

	public void StartClient(SteamId id)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"CC {id}");
		transport.targetSteamId = SteamId.op_Implicit(id);
		SetConnectionDataBeforeConnecting();
		if (NetworkManager.Singleton.StartClient())
		{
			Debug.Log((object)"started client!");
			SubscribeToConnectionCallbacks();
			Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: true, (RoomEnter)5);
			return;
		}
		Debug.Log((object)"Joined steam lobby successfully, but connection failed");
		Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)5);
		if (Instance.currentLobby.HasValue)
		{
			Debug.Log((object)"Leaving steam lobby");
			Lobby value = Instance.currentLobby.Value;
			((Lobby)(ref value)).Leave();
			Instance.currentLobby = null;
			steamLobbyName = SteamClient.Name;
		}
		SetInstanceValuesBackToDefault();
	}

	private IEnumerator delayStartClient()
	{
		yield return (object)new WaitForSeconds(1f);
		if (NetworkManager.Singleton.StartClient())
		{
			Debug.Log((object)"started client!");
			Debug.Log((object)$"Are we connected client: {NetworkManager.Singleton.IsConnectedClient}");
			if ((Object)(object)NetworkManager.Singleton != (Object)null)
			{
				Debug.Log((object)"NetworkManager is not null");
			}
			Debug.Log((object)$"Are we connected client: {NetworkManager.Singleton.IsConnectedClient}");
			Debug.Log((object)$"Are we host: {NetworkManager.Singleton.IsHost}");
			yield return null;
			if ((Object)(object)NetworkManager.Singleton != (Object)null)
			{
				Debug.Log((object)"NetworkManager is not null");
			}
			Debug.Log((object)$"is networkmanager listening: {NetworkManager.Singleton.IsListening}");
			Debug.Log((object)("connected host name: " + NetworkManager.Singleton.ConnectedHostname));
		}
	}
}
