using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;

public class SandSpiderWebTrap : MonoBehaviour, IHittable
{
	public SandSpiderAI mainScript;

	private bool hinderingLocalPlayer;

	public PlayerControllerB currentTrappedPlayer;

	public Transform leftBone;

	public Transform rightBone;

	public Transform centerOfWeb;

	public int trapID;

	public float zScale = 1f;

	public AudioSource webAudio;

	private bool webHasBeenBroken;

	public bool Hit(int force, Vector3 hitDirection, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		if (!webHasBeenBroken)
		{
			webHasBeenBroken = true;
			mainScript.BreakWebServerRpc(trapID, (int)playerWhoHit.playerClientId);
		}
		return true;
	}

	private void OnEnable()
	{
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).AddListener((UnityAction<PlayerControllerB>)PlayerLeaveWeb);
	}

	private void OnDisable()
	{
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).RemoveListener((UnityAction<PlayerControllerB>)PlayerLeaveWeb);
		PlayerLeaveWeb(GameNetworkManager.Instance.localPlayerController);
	}

	private void OnDestroy()
	{
		PlayerLeaveWeb(GameNetworkManager.Instance.localPlayerController);
	}

	public void Update()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)currentTrappedPlayer != (Object)null)
		{
			CallPlayerLeaveWebOnDeath();
			Vector3 val = ((Component)currentTrappedPlayer).transform.position + Vector3.up * 0.6f;
			rightBone.LookAt(val);
			leftBone.LookAt(val);
		}
		else
		{
			rightBone.LookAt(centerOfWeb);
			leftBone.LookAt(centerOfWeb);
		}
		((Component)this).transform.localScale = Vector3.Lerp(((Component)this).transform.localScale, new Vector3(1f, 1f, zScale), 8f * Time.deltaTime);
	}

	private void Awake()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.localScale = new Vector3(0.7f, 0.7f, 0.02f);
	}

	private void CallPlayerLeaveWebOnDeath()
	{
		if ((Object)(object)NetworkManager.Singleton != (Object)null)
		{
			if (NetworkManager.Singleton.IsHost && !currentTrappedPlayer.isPlayerControlled && !currentTrappedPlayer.isPlayerDead)
			{
				currentTrappedPlayer = null;
				mainScript.PlayerLeaveWebServerRpc(trapID, (int)currentTrappedPlayer.playerClientId);
			}
			else if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)currentTrappedPlayer && GameNetworkManager.Instance.localPlayerController.isPlayerDead)
			{
				currentTrappedPlayer = null;
				currentTrappedPlayer.isMovementHindered--;
				currentTrappedPlayer.hinderedMultiplier = Mathf.Clamp(currentTrappedPlayer.hinderedMultiplier * 0.4f, 1f, 100f);
				hinderingLocalPlayer = false;
				mainScript.PlayerLeaveWebServerRpc(trapID, (int)currentTrappedPlayer.playerClientId);
			}
		}
	}

	private void OnTriggerStay(Collider other)
	{
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || hinderingLocalPlayer)
		{
			return;
		}
		PlayerControllerB component = ((Component)other).GetComponent<PlayerControllerB>();
		if ((Object)(object)component != (Object)null && (Object)(object)component == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			component.isMovementHindered++;
			component.hinderedMultiplier *= 2.5f;
			hinderingLocalPlayer = true;
			if ((Object)(object)currentTrappedPlayer == (Object)null)
			{
				currentTrappedPlayer = GameNetworkManager.Instance.localPlayerController;
			}
			if ((Object)(object)mainScript != (Object)null)
			{
				mainScript.PlayerTripWebServerRpc(trapID, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	private void PlayerLeaveWeb(PlayerControllerB playerScript)
	{
		Debug.Log((object)"Player leave web called");
		if (hinderingLocalPlayer)
		{
			hinderingLocalPlayer = false;
			playerScript.isMovementHindered--;
			playerScript.hinderedMultiplier *= 0.4f;
			if ((Object)(object)currentTrappedPlayer == (Object)(object)playerScript)
			{
				currentTrappedPlayer = null;
			}
			webAudio.Stop();
			if ((Object)(object)mainScript != (Object)null)
			{
				mainScript.PlayerLeaveWebServerRpc(trapID, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (hinderingLocalPlayer)
		{
			PlayerControllerB component = ((Component)other).GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)null && (Object)(object)component == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				PlayerLeaveWeb(component);
			}
		}
	}
}
