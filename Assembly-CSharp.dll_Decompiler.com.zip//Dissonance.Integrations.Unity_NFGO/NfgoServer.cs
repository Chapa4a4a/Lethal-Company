using System;
using Dissonance.Networking;
using Unity.Netcode;
using UnityEngine;

namespace Dissonance.Integrations.Unity_NFGO;

public class NfgoServer : BaseServer<NfgoServer, NfgoClient, NfgoConn>
{
	private readonly NfgoCommsNetwork _network;

	private byte[] _receiveBuffer = new byte[1024];

	private NetworkManager _networkManager;

	public NfgoServer(NfgoCommsNetwork network)
	{
		_network = network;
	}

	public override void Connect()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Expected O, but got Unknown
		_networkManager = NetworkManager.Singleton;
		_networkManager.OnClientDisconnectCallback += Disconnected;
		_networkManager.CustomMessagingManager.RegisterNamedMessageHandler("DissonanceToServer", new HandleNamedMessageDelegate(NamedMessageHandler));
		base.Connect();
	}

	public override void Disconnect()
	{
		if ((Object)(object)_networkManager != (Object)null)
		{
			_networkManager.OnClientDisconnectCallback -= Disconnected;
			CustomMessagingManager customMessagingManager = _networkManager.CustomMessagingManager;
			if (customMessagingManager != null)
			{
				customMessagingManager.UnregisterNamedMessageHandler("DissonanceToServer");
			}
			_networkManager = null;
		}
		base.Disconnect();
	}

	private void Disconnected(ulong client)
	{
		base.ClientDisconnected(new NfgoConn(client));
	}

	private void NamedMessageHandler(ulong sender, FastBufferReader stream)
	{
		int length = ((FastBufferReader)(ref stream)).Length;
		if (_receiveBuffer.Length < length)
		{
			Array.Resize(ref _receiveBuffer, length);
		}
		ArraySegment<byte> arraySegment = NfgoCommsNetwork.ReadPacket(ref stream, ref _receiveBuffer);
		base.NetworkReceivedPacket(new NfgoConn(sender), arraySegment);
	}

	protected override void ReadMessages()
	{
	}

	protected override void SendReliable(NfgoConn destination, ArraySegment<byte> packet)
	{
		if (!((Object)(object)_networkManager == (Object)null))
		{
			_network.SendToClient(packet, destination, reliable: true, _networkManager);
		}
	}

	protected override void SendUnreliable(NfgoConn destination, ArraySegment<byte> packet)
	{
		if (!((Object)(object)_networkManager == (Object)null))
		{
			_network.SendToClient(packet, destination, reliable: false, _networkManager);
		}
	}
}
