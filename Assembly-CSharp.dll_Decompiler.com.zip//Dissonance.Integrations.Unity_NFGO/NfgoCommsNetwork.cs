using System;
using System.Collections.Generic;
using Dissonance.Datastructures;
using Dissonance.Extensions;
using Dissonance.Networking;
using JetBrains.Annotations;
using Unity.Collections;
using Unity.Netcode;
using UnityEngine;

namespace Dissonance.Integrations.Unity_NFGO;

public class NfgoCommsNetwork : BaseCommsNetwork<NfgoServer, NfgoClient, NfgoConn, Unit, Unit>
{
	private readonly ConcurrentPool<byte[]> _loopbackBuffers = new ConcurrentPool<byte[]>(8, (Func<byte[]>)(() => new byte[1024]));

	private readonly List<ArraySegment<byte>> _loopbackQueueToServer = new List<ArraySegment<byte>>();

	private readonly List<ArraySegment<byte>> _loopbackQueueToClient = new List<ArraySegment<byte>>();

	protected override NfgoClient CreateClient(Unit connectionParameters)
	{
		return new NfgoClient(this);
	}

	protected override NfgoServer CreateServer(Unit connectionParameters)
	{
		return new NfgoServer(this);
	}

	protected override void Update()
	{
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		if (base.IsInitialized)
		{
			bool flag = NetworkManager.Singleton.IsClient && NetworkManager.Singleton.IsConnectedClient;
			bool isServer = NetworkManager.Singleton.IsServer;
			if (((Behaviour)NetworkManager.Singleton).isActiveAndEnabled && (flag || isServer))
			{
				bool isServer2 = NetworkManager.Singleton.IsServer;
				bool isClient = NetworkManager.Singleton.IsClient;
				if (NetworkModeExtensions.IsServerEnabled(base.Mode) != isServer2 || NetworkModeExtensions.IsClientEnabled(base.Mode) != isClient)
				{
					if (isServer2 && isClient)
					{
						base.RunAsHost(Unit.None, Unit.None);
					}
					else if (isServer2)
					{
						base.RunAsDedicatedServer(Unit.None);
					}
					else if (isClient)
					{
						base.RunAsClient(Unit.None);
					}
				}
			}
			else if ((int)base.Mode != 0)
			{
				base.Stop();
				_loopbackQueueToClient.Clear();
				_loopbackQueueToServer.Clear();
			}
			if (base.Client != null)
			{
				foreach (ArraySegment<byte> item in _loopbackQueueToClient)
				{
					if (item.Array != null)
					{
						((BaseClient<NfgoServer, NfgoClient, NfgoConn>)base.Client).NetworkReceivedPacket(item);
						_loopbackBuffers.Put(item.Array);
					}
				}
			}
			_loopbackQueueToClient.Clear();
			if (base.Server != null)
			{
				foreach (ArraySegment<byte> item2 in _loopbackQueueToServer)
				{
					if (item2.Array != null)
					{
						((BaseServer<NfgoServer, NfgoClient, NfgoConn>)base.Server).NetworkReceivedPacket(new NfgoConn(NetworkManager.Singleton.LocalClientId), item2);
						_loopbackBuffers.Put(item2.Array);
					}
				}
			}
			_loopbackQueueToServer.Clear();
		}
		base.Update();
	}

	internal void SendToServer(ArraySegment<byte> packet, bool reliable, [NotNull] NetworkManager netManager)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		if (packet.Array == null)
		{
			throw new ArgumentException("packet is null");
		}
		if (netManager.IsHost)
		{
			_loopbackQueueToServer.Add(ArraySegmentExtensions.CopyToSegment<byte>(packet, _loopbackBuffers.Get(), 0));
			return;
		}
		FastBufferWriter val = WritePacket(packet);
		try
		{
			netManager.CustomMessagingManager.SendNamedMessage("DissonanceToServer", 0uL, val, (NetworkDelivery)(reliable ? 3 : 0));
		}
		finally
		{
			((IDisposable)(FastBufferWriter)(ref val)).Dispose();
		}
	}

	internal void SendToClient(ArraySegment<byte> packet, NfgoConn client, bool reliable, [NotNull] NetworkManager netManager)
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (packet.Array == null)
		{
			throw new ArgumentException("packet is null");
		}
		if (netManager.LocalClientId == client.ClientId)
		{
			_loopbackQueueToClient.Add(ArraySegmentExtensions.CopyToSegment<byte>(packet, _loopbackBuffers.Get(), 0));
		}
		else if (reliable || netManager.ConnectedClients.ContainsKey(client.ClientId))
		{
			FastBufferWriter val = WritePacket(packet);
			try
			{
				netManager.CustomMessagingManager.SendNamedMessage("DissonanceToClient", client.ClientId, val, (NetworkDelivery)(reliable ? 3 : 0));
			}
			finally
			{
				((IDisposable)(FastBufferWriter)(ref val)).Dispose();
			}
		}
	}

	private static FastBufferWriter WritePacket(ArraySegment<byte> packet)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		FastBufferWriter result = default(FastBufferWriter);
		((FastBufferWriter)(ref result))._002Ector(packet.Count + 4, (Allocator)2, -1);
		uint count = (uint)packet.Count;
		((FastBufferWriter)(ref result)).WriteValueSafe<uint>(ref count, default(ForPrimitives));
		((FastBufferWriter)(ref result)).WriteBytesSafe(packet.Array, packet.Count, packet.Offset);
		return result;
	}

	internal static ArraySegment<byte> ReadPacket(ref FastBufferReader reader, [CanBeNull] ref byte[] buffer)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		uint num = default(uint);
		((FastBufferReader)(ref reader)).ReadValueSafe<uint>(ref num, default(ForPrimitives));
		if (buffer == null || buffer.Length < num)
		{
			buffer = new byte[Math.Max(1024u, num)];
		}
		byte b = default(byte);
		for (int i = 0; i < num; i++)
		{
			((FastBufferReader)(ref reader)).ReadByteSafe(ref b);
			buffer[i] = b;
		}
		return new ArraySegment<byte>(buffer, 0, (int)num);
	}
}
