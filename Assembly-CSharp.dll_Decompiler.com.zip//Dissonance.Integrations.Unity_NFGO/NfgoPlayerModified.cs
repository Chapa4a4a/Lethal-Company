using System;
using GameNetcodeStuff;
using JetBrains.Annotations;
using Unity.Collections;
using Unity.Netcode;
using UnityEngine;

namespace Dissonance.Integrations.Unity_NFGO;

[RequireComponent(typeof(NetworkObject))]
public class NfgoPlayerModified : NetworkBehaviour, IDissonancePlayer
{
	private static readonly Log Log = Logs.Create((LogCategory)2, "NfgoPlayer");

	private DissonanceComms _comms;

	private Transform _transform;

	private string _playerIdString;

	private readonly NetworkVariable<FixedString128Bytes> _playerId = new NetworkVariable<FixedString128Bytes>(new FixedString128Bytes(""), (NetworkVariableReadPermission)0, (NetworkVariableWritePermission)0);

	private bool hasStartedTracking;

	[NotNull]
	private Transform Transform
	{
		get
		{
			if ((Object)(object)_transform == (Object)null)
			{
				_transform = ((Component)this).transform;
			}
			return _transform;
		}
	}

	public Vector3 Position => Transform.position;

	public Quaternion Rotation => Transform.rotation;

	public bool IsTracking { get; private set; }

	public string PlayerId
	{
		get
		{
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Unknown result type (might be due to invalid IL or missing references)
			FixedString128Bytes value;
			if (_playerIdString != null)
			{
				value = _playerId.Value;
				if (((FixedString128Bytes)(ref value)).Equals(_playerIdString))
				{
					goto IL_0042;
				}
			}
			value = _playerId.Value;
			_playerIdString = ((object)(FixedString128Bytes)(ref value)).ToString();
			goto IL_0042;
			IL_0042:
			return _playerIdString;
		}
	}

	public NetworkPlayerType Type
	{
		get
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			if (!((Object)(object)_comms == (Object)null))
			{
				FixedString128Bytes value = _playerId.Value;
				if (!((FixedString128Bytes)(ref value)).IsEmpty)
				{
					value = _playerId.Value;
					if (((FixedString128Bytes)(ref value)).Equals(_comms.LocalPlayerName))
					{
						return (NetworkPlayerType)1;
					}
					return (NetworkPlayerType)2;
				}
			}
			return (NetworkPlayerType)0;
		}
	}

	public override void OnDestroy()
	{
		if ((Object)(object)_comms != (Object)null)
		{
			_comms.LocalPlayerNameChanged -= OnLocalPlayerIdChanged;
		}
		NetworkVariable<FixedString128Bytes> playerId = _playerId;
		playerId.OnValueChanged = (OnValueChangedDelegate<FixedString128Bytes>)(object)Delegate.Remove((Delegate?)(object)playerId.OnValueChanged, (Delegate?)(object)new OnValueChangedDelegate<FixedString128Bytes>(OnNetworkVariablePlayerIdChanged<FixedString128Bytes>));
	}

	public void VoiceChatTrackingStart()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		_comms = Object.FindObjectOfType<DissonanceComms>();
		if ((Object)(object)_comms == (Object)null)
		{
			throw Log.CreateUserErrorException("cannot find DissonanceComms component in scene", "not placing a DissonanceComms component on a game object in the scene", "https://placeholder-software.co.uk/dissonance/docs/Basics/Quick-Start-UNet-HLAPI.html", "A6A291D8-5B53-417E-95CD-EC670637C532");
		}
		if (!hasStartedTracking)
		{
			NetworkVariable<FixedString128Bytes> playerId = _playerId;
			playerId.OnValueChanged = (OnValueChangedDelegate<FixedString128Bytes>)(object)Delegate.Combine((Delegate?)(object)playerId.OnValueChanged, (Delegate?)(object)new OnValueChangedDelegate<FixedString128Bytes>(OnNetworkVariablePlayerIdChanged<FixedString128Bytes>));
		}
		if (((Component)this).gameObject.GetComponent<PlayerControllerB>().isPlayerControlled && ((NetworkBehaviour)this).IsOwner)
		{
			if (_comms.LocalPlayerName != null)
			{
				SetNameServerRpc(_comms.LocalPlayerName);
			}
			if (!hasStartedTracking)
			{
				_comms.LocalPlayerNameChanged += OnLocalPlayerIdChanged;
			}
		}
		else
		{
			FixedString128Bytes value = _playerId.Value;
			if (!((FixedString128Bytes)(ref value)).IsEmpty)
			{
				StartTracking();
			}
		}
		hasStartedTracking = true;
	}

	[ServerRpc]
	public void SetNameServerRpc(string playerName)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Invalid comparison between Unknown and I4
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2623869394u, val, (RpcDelivery)0);
			bool flag = playerName != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(playerName, false);
			}
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2623869394u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			_playerId.Value = FixedString128Bytes.op_Implicit(playerName);
		}
	}

	private void OnLocalPlayerIdChanged(string _)
	{
		if (IsTracking)
		{
			StopTracking();
		}
		if (((Component)this).gameObject.GetComponent<PlayerControllerB>().isPlayerControlled && ((NetworkBehaviour)this).IsOwner)
		{
			SetNameServerRpc(_comms.LocalPlayerName);
		}
		StartTracking();
	}

	private void OnNetworkVariablePlayerIdChanged<T>(T previousvalue, T newvalue)
	{
		if (IsTracking)
		{
			StopTracking();
		}
		StartTracking();
	}

	private void StartTracking()
	{
		if (IsTracking)
		{
			throw Log.CreatePossibleBugException("Attempting to start player tracking, but tracking is already started", "4C2E74AA-CA09-4F98-B820-F2518A4E87D2");
		}
		if ((Object)(object)_comms != (Object)null)
		{
			_comms.TrackPlayerPosition((IDissonancePlayer)(object)this);
			IsTracking = true;
		}
	}

	private void StopTracking()
	{
		if (!IsTracking)
		{
			throw Log.CreatePossibleBugException("Attempting to stop player tracking, but tracking is not started", "BF8542EB-C13E-46FA-A8A0-B162F188BBA3");
		}
		if ((Object)(object)_comms != (Object)null)
		{
			_comms.StopTracking((IDissonancePlayer)(object)this);
			IsTracking = false;
		}
	}

	protected override void __initializeVariables()
	{
		if (_playerId == null)
		{
			throw new Exception("NfgoPlayerModified._playerId cannot be null. All NetworkVariableBase instances must be initialized.");
		}
		((NetworkVariableBase)_playerId).Initialize((NetworkBehaviour)(object)this);
		((NetworkBehaviour)this).__nameNetworkVariable((NetworkVariableBase)(object)_playerId, "_playerId");
		base.NetworkVariableFields.Add((NetworkVariableBase)(object)_playerId);
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_NfgoPlayerModified()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2623869394u, new RpcReceiveHandler(__rpc_handler_2623869394));
	}

	private static void __rpc_handler_2623869394(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		bool flag = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
		string nameServerRpc = null;
		if (flag)
		{
			((FastBufferReader)(ref reader)).ReadValueSafe(ref nameServerRpc, false);
		}
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((NfgoPlayerModified)(object)target).SetNameServerRpc(nameServerRpc);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	protected internal override string __getTypeName()
	{
		return "NfgoPlayerModified";
	}
}
