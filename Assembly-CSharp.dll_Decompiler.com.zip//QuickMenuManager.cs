using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Dissonance;
using Steamworks;
using TMPro;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.UI;

public class QuickMenuManager : MonoBehaviour
{
	[Header("HUD")]
	public TextMeshProUGUI interactTipText;

	public TextMeshProUGUI leaveGameClarificationText;

	public Image cursorIcon;

	[Header("In-game Menu")]
	public GameObject menuContainer;

	public GameObject mainButtonsPanel;

	public GameObject leaveGameConfirmPanel;

	public GameObject settingsPanel;

	[Space(3f)]
	public GameObject ConfirmKickUserPanel;

	public TextMeshProUGUI ConfirmKickPlayerText;

	public GameObject KeybindsPanel;

	public bool isMenuOpen;

	private int currentMicrophoneDevice;

	public TextMeshProUGUI currentMicrophoneText;

	public DissonanceComms voiceChatModule;

	public TextMeshProUGUI changesNotAppliedText;

	public TextMeshProUGUI settingsBackButton;

	public GameObject PleaseConfirmChangesSettingsPanel;

	public Button PleaseConfirmChangesSettingsPanelBackButton;

	public CanvasGroup inviteFriendsTextAlpha;

	[Header("Player list")]
	public PlayerListSlot[] playerListSlots;

	public GameObject playerListPanel;

	private int playerObjToKick;

	[Header("Debug menu")]
	public GameObject[] doorGameObjects;

	public Collider outOfBoundsCollider;

	public GameObject debugMenuUI;

	public SelectableLevel testAllEnemiesLevel;

	[Space(3f)]
	private int enemyToSpawnId;

	[Space(3f)]
	private int enemyTypeId;

	[Space(3f)]
	private int itemToSpawnId;

	[Space(3f)]
	private int numberEnemyToSpawn = 1;

	public Transform[] debugEnemySpawnPositions;

	public TMP_Dropdown debugEnemyDropdown;

	public TMP_Dropdown allItemsDropdown;

	public GameObject truckPrefab;

	private void Start()
	{
		currentMicrophoneDevice = PlayerPrefs.GetInt("LethalCompany_currentMic", 0);
		if (!((Object)(object)NetworkManager.Singleton == (Object)null) && NetworkManager.Singleton.IsServer)
		{
			Debug_SetEnemyDropdownOptions();
			Debug_SetAllItemsDropdownOptions();
		}
	}

	public void Debug_SetAllItemsDropdownOptions()
	{
		allItemsDropdown.ClearOptions();
		List<string> list = new List<string>();
		for (int i = 0; i < StartOfRound.Instance.allItemsList.itemsList.Count; i++)
		{
			list.Add(StartOfRound.Instance.allItemsList.itemsList[i].itemName);
		}
		allItemsDropdown.AddOptions(list);
	}

	public void Debug_SpawnItem()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (Application.isEditor && NetworkManager.Singleton.IsConnectedClient && NetworkManager.Singleton.IsServer)
		{
			GameObject obj = Object.Instantiate<GameObject>(StartOfRound.Instance.allItemsList.itemsList[itemToSpawnId].spawnPrefab, debugEnemySpawnPositions[3].position, Quaternion.identity, StartOfRound.Instance.propsContainer);
			obj.GetComponent<GrabbableObject>().fallTime = 0f;
			obj.GetComponent<NetworkObject>().Spawn(false);
		}
	}

	public void Debug_SetItemToSpawn(int itemId)
	{
		itemToSpawnId = itemId;
	}

	public void Debug_KillLocalPlayer()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		if (Application.isEditor && NetworkManager.Singleton.IsConnectedClient && NetworkManager.Singleton.IsServer)
		{
			GameNetworkManager.Instance.localPlayerController.KillPlayer(Vector3.zero);
		}
	}

	public void Debug_SpawnTruck()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (Application.isEditor && NetworkManager.Singleton.IsConnectedClient && NetworkManager.Singleton.IsServer)
		{
			Object.Instantiate<GameObject>(truckPrefab, StartOfRound.Instance.groundOutsideShipSpawnPosition.position, Quaternion.identity, RoundManager.Instance.VehiclesContainer).gameObject.GetComponent<NetworkObject>().Spawn(false);
		}
	}

	public void Debug_ToggleTestRoom()
	{
		if (Application.isEditor)
		{
			StartOfRound.Instance.Debug_EnableTestRoomServerRpc((Object)(object)StartOfRound.Instance.testRoom == (Object)null);
		}
	}

	public void Debug_ToggleAllowDeath()
	{
		if (Application.isEditor)
		{
			StartOfRound.Instance.Debug_ToggleAllowDeathServerRpc();
		}
	}

	public void Debug_RevivePlayers()
	{
		if (CanEnableDebugMenu())
		{
			StartOfRound.Instance.Debug_EnableTestRoomServerRpc(enable: false);
			RoundManager.Instance.DespawnPropsAtEndOfRound();
			StartOfRound.Instance.ReviveDeadPlayers();
			HUDManager.Instance.HideHUD(hide: false);
			StartOfRound.Instance.Debug_ReviveAllPlayersServerRpc();
		}
	}

	public void Debug_SetEnemyType(int enemyType)
	{
		enemyTypeId = enemyType;
		Debug_SetEnemyDropdownOptions();
	}

	private void Debug_SetEnemyDropdownOptions()
	{
		debugEnemyDropdown.ClearOptions();
		List<string> list = new List<string>();
		switch (enemyTypeId)
		{
		case 0:
		{
			for (int j = 0; j < testAllEnemiesLevel.Enemies.Count; j++)
			{
				list.Add(testAllEnemiesLevel.Enemies[j].enemyType.enemyName);
			}
			break;
		}
		case 1:
		{
			for (int k = 0; k < testAllEnemiesLevel.OutsideEnemies.Count; k++)
			{
				list.Add(testAllEnemiesLevel.OutsideEnemies[k].enemyType.enemyName);
			}
			break;
		}
		case 2:
		{
			for (int i = 0; i < testAllEnemiesLevel.DaytimeEnemies.Count; i++)
			{
				list.Add(testAllEnemiesLevel.DaytimeEnemies[i].enemyType.enemyName);
			}
			break;
		}
		}
		debugEnemyDropdown.AddOptions(list);
		Debug_SetEnemyToSpawn(0);
	}

	public void Debug_SetEnemyToSpawn(int enemyId)
	{
		enemyToSpawnId = enemyId;
	}

	public void Debug_SetNumberToSpawn(string numString)
	{
		numString = Regex.Replace(numString, "[^.0-9]", "");
		int num = Convert.ToInt32(numString);
		if (num > 0)
		{
			numberEnemyToSpawn = num;
		}
	}

	public void Debug_SpawnEnemy()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		if (!NetworkManager.Singleton.IsConnectedClient || !NetworkManager.Singleton.IsServer || !Application.isEditor)
		{
			return;
		}
		EnemyType enemyType = null;
		Vector3 spawnPosition = Vector3.zero;
		switch (enemyTypeId)
		{
		case 0:
			enemyType = testAllEnemiesLevel.Enemies[enemyToSpawnId].enemyType;
			spawnPosition = ((!((Object)(object)StartOfRound.Instance.testRoom != (Object)null)) ? RoundManager.Instance.insideAINodes[Random.Range(0, RoundManager.Instance.insideAINodes.Length)].transform.position : debugEnemySpawnPositions[enemyTypeId].position);
			break;
		case 1:
			enemyType = testAllEnemiesLevel.OutsideEnemies[enemyToSpawnId].enemyType;
			spawnPosition = ((!((Object)(object)StartOfRound.Instance.testRoom != (Object)null)) ? RoundManager.Instance.outsideAINodes[Random.Range(0, RoundManager.Instance.outsideAINodes.Length)].transform.position : debugEnemySpawnPositions[enemyTypeId].position);
			break;
		case 2:
			enemyType = testAllEnemiesLevel.DaytimeEnemies[enemyToSpawnId].enemyType;
			spawnPosition = ((!((Object)(object)StartOfRound.Instance.testRoom != (Object)null)) ? RoundManager.Instance.outsideAINodes[Random.Range(0, RoundManager.Instance.outsideAINodes.Length)].transform.position : debugEnemySpawnPositions[enemyTypeId].position);
			break;
		}
		if (!((Object)(object)enemyType == (Object)null))
		{
			for (int i = 0; i < numberEnemyToSpawn && i <= 50; i++)
			{
				RoundManager.Instance.SpawnEnemyGameObject(spawnPosition, 0f, -1, enemyType);
			}
		}
	}

	private bool CanEnableDebugMenu()
	{
		if ((Object)(object)NetworkManager.Singleton != (Object)null && NetworkManager.Singleton.IsServer)
		{
			return Application.isEditor;
		}
		return false;
	}

	public void OpenQuickMenu()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		menuContainer.SetActive(true);
		Cursor.lockState = (CursorLockMode)0;
		Cursor.SetCursor(HUDManager.Instance.defaultCursorTex, new Vector2(0f, 0f), (CursorMode)0);
		if (!StartOfRound.Instance.localPlayerUsingController)
		{
			Cursor.visible = true;
		}
		isMenuOpen = true;
		playerListPanel.SetActive(NonHostPlayerSlotsEnabled());
		debugMenuUI.SetActive(CanEnableDebugMenu());
	}

	public void CloseQuickMenu()
	{
		if (settingsPanel.activeSelf)
		{
			IngamePlayerSettings.Instance.DiscardChangedSettings();
		}
		CloseQuickMenuPanels();
		menuContainer.SetActive(false);
		Cursor.lockState = (CursorLockMode)1;
		Cursor.visible = false;
		isMenuOpen = false;
	}

	public void CloseQuickMenuPanels()
	{
		leaveGameConfirmPanel.SetActive(false);
		settingsPanel.SetActive(false);
		mainButtonsPanel.SetActive(true);
		playerListPanel.SetActive(NonHostPlayerSlotsEnabled());
	}

	public void DisableInviteFriendsButton()
	{
		inviteFriendsTextAlpha.alpha = 0.2f;
	}

	public void InviteFriendsButton()
	{
		if (!GameNetworkManager.Instance.gameHasStarted)
		{
			GameNetworkManager.Instance.InviteFriendsUI();
		}
	}

	public void LeaveGame()
	{
		playerListPanel.SetActive(false);
		leaveGameConfirmPanel.SetActive(true);
		mainButtonsPanel.SetActive(false);
		((Behaviour)leaveGameClarificationText).enabled = (Object)(object)NetworkManager.Singleton != (Object)null && NetworkManager.Singleton.IsServer && !StartOfRound.Instance.inShipPhase;
	}

	public void LeaveGameConfirm()
	{
		if ((Object)(object)GameNetworkManager.Instance != (Object)null && !HUDManager.Instance.retrievingSteamLeaderboard)
		{
			GameNetworkManager.Instance.Disconnect();
		}
	}

	public void EnableUIPanel(GameObject enablePanel)
	{
		enablePanel.SetActive(true);
		playerListPanel.SetActive(false);
		debugMenuUI.SetActive(false);
	}

	public void DisableUIPanel(GameObject enablePanel)
	{
		enablePanel.SetActive(false);
		if ((Object)(object)enablePanel != (Object)(object)mainButtonsPanel)
		{
			playerListPanel.SetActive(NonHostPlayerSlotsEnabled());
			debugMenuUI.SetActive(CanEnableDebugMenu());
		}
	}

	private void Update()
	{
		for (int i = 0; i < playerListSlots.Length; i++)
		{
			if (playerListSlots[i].isConnected)
			{
				float num = playerListSlots[i].volumeSlider.value / playerListSlots[i].volumeSlider.maxValue;
				if (num == -1f)
				{
					SoundManager.Instance.playerVoiceVolumes[i] = -70f;
				}
				else
				{
					SoundManager.Instance.playerVoiceVolumes[i] = num;
				}
			}
		}
	}

	private bool NonHostPlayerSlotsEnabled()
	{
		for (int i = 1; i < playerListSlots.Length; i++)
		{
			if (playerListSlots[i].isConnected)
			{
				return true;
			}
		}
		return false;
	}

	public void AddUserToPlayerList(ulong steamId, string playerName, int playerObjectId)
	{
		if (playerObjectId >= 0 && playerObjectId <= 4)
		{
			playerListSlots[playerObjectId].KickUserButton.SetActive(((NetworkBehaviour)StartOfRound.Instance).IsServer);
			playerListSlots[playerObjectId].slotContainer.SetActive(true);
			playerListSlots[playerObjectId].isConnected = true;
			playerListSlots[playerObjectId].playerSteamId = steamId;
			((TMP_Text)playerListSlots[playerObjectId].usernameHeader).text = playerName;
			if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
			{
				playerListSlots[playerObjectId].volumeSliderContainer.SetActive(playerObjectId != (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	public void KickUserFromServer(int playerObjId)
	{
		((TMP_Text)ConfirmKickPlayerText).text = "Kick out " + StartOfRound.Instance.allPlayerScripts[playerObjId].playerUsername.Substring(0, Mathf.Min(6, StartOfRound.Instance.allPlayerScripts[playerObjId].playerUsername.Length - 1)) + "?";
		playerObjToKick = playerObjId;
		ConfirmKickUserPanel.SetActive(true);
	}

	public void CancelKickUserFromServer()
	{
		ConfirmKickUserPanel.SetActive(false);
	}

	public void ConfirmKickUserFromServer()
	{
		if (playerObjToKick > 0 && playerObjToKick <= 3)
		{
			StartOfRound.Instance.KickPlayer(playerObjToKick);
			ConfirmKickUserPanel.SetActive(false);
		}
	}

	public void RemoveUserFromPlayerList(int playerObjectId)
	{
		playerListSlots[playerObjectId].slotContainer.SetActive(false);
		playerListSlots[playerObjectId].isConnected = false;
	}

	public void OpenUserSteamProfile(int slotId)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		if (!GameNetworkManager.Instance.disableSteam && playerListSlots[slotId].isConnected && playerListSlots[slotId].playerSteamId != 0L)
		{
			SteamFriends.OpenUserOverlay(SteamId.op_Implicit(playerListSlots[slotId].playerSteamId), "steamid");
		}
	}
}
