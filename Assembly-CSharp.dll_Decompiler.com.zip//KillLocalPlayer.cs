using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class KillLocalPlayer : MonoBehaviour
{
	public bool dontSpawnBody;

	public CauseOfDeath causeOfDeath = CauseOfDeath.Gravity;

	public bool justDamage;

	public StartOfRound playersManager;

	public int deathAnimation;

	[Space(5f)]
	public RoundManager roundManager;

	public Transform spawnEnemyPosition;

	[Space(5f)]
	public int enemySpawnNumber;

	public int playAudioOnDeath = -1;

	public GameObject spawnPrefab;

	public bool disallowKillingInShip;

	public bool destroyEnemies;

	public void KillPlayer(PlayerControllerB playerWhoTriggered)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if (disallowKillingInShip && (playerWhoTriggered.isInsideFactory || playerWhoTriggered.isInHangarShipRoom))
		{
			return;
		}
		if (justDamage)
		{
			playerWhoTriggered.DamagePlayer(25);
			Debug.Log((object)"DD TRIGGER");
			return;
		}
		if (playAudioOnDeath != -1)
		{
			SoundManager.Instance.PlayAudio1AtPositionForAllClients(((Component)playerWhoTriggered).transform.position, playAudioOnDeath);
		}
		if ((Object)(object)spawnPrefab != (Object)null)
		{
			Object.Instantiate<GameObject>(spawnPrefab, ((Component)playerWhoTriggered.lowerSpine).transform.position, Quaternion.identity, RoundManager.Instance.mapPropsContainer.transform);
		}
		playerWhoTriggered.KillPlayer(Vector3.zero, !dontSpawnBody, causeOfDeath, deathAnimation);
	}

	public void OnTriggerEnter(Collider other)
	{
		if (destroyEnemies && ((NetworkBehaviour)RoundManager.Instance).IsServer && ((Component)other).CompareTag("Enemy"))
		{
			EnemyAICollisionDetect component = ((Component)other).gameObject.GetComponent<EnemyAICollisionDetect>();
			if ((Object)(object)component != (Object)null)
			{
				component.mainScript.KillEnemyOnOwnerClient(overrideDestroy: true);
			}
		}
	}

	public void SpawnEnemy()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (GameNetworkManager.Instance.localPlayerController.playerClientId == 0L)
		{
			roundManager.SpawnEnemyOnServer(spawnEnemyPosition.position, 0f, enemySpawnNumber);
		}
	}
}
