using UnityEngine;

public class GrabbableObjectPhysicsTrigger : MonoBehaviour
{
	public GrabbableObject itemScript;

	private void OnTriggerEnter(Collider other)
	{
		if (!itemScript.isHeld && (((Component)other).gameObject.CompareTag("Player") || ((Component)other).gameObject.CompareTag("Enemy")))
		{
			itemScript.ActivatePhysicsTrigger(other);
		}
	}
}
