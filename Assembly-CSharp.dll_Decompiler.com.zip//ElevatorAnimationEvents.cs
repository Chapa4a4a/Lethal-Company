using System.Collections;
using UnityEngine;

public class ElevatorAnimationEvents : MonoBehaviour
{
	public RoundManager roundManager;

	public AudioSource audioToPlay;

	public AudioSource audioToPlay2;

	private Coroutine fadeCoroutine;

	public void PlayAudio(AudioClip SFXclip)
	{
		if (roundManager.ElevatorLowering || roundManager.ElevatorRunning)
		{
			audioToPlay.clip = SFXclip;
			audioToPlay.Play();
		}
	}

	public void PlayAudio2(AudioClip SFXclip)
	{
		if (roundManager.ElevatorLowering || roundManager.ElevatorRunning)
		{
			audioToPlay2.clip = SFXclip;
			audioToPlay2.Play();
		}
	}

	public void PlayAudioOneshot(AudioClip SFXclip)
	{
		Debug.Log((object)$"elevator running? : {roundManager.ElevatorRunning}");
		if (roundManager.ElevatorLowering || roundManager.ElevatorRunning)
		{
			audioToPlay.PlayOneShot(SFXclip);
		}
	}

	public void PlayAudio2Oneshot(AudioClip SFXclip)
	{
		if (roundManager.ElevatorLowering || roundManager.ElevatorRunning)
		{
			audioToPlay2.PlayOneShot(SFXclip);
		}
	}

	public void StopAudio(AudioSource audio)
	{
		audio.Stop();
	}

	public void FadeAudioOut(AudioSource audio)
	{
		if (fadeCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(fadeCoroutine);
		}
		fadeCoroutine = ((MonoBehaviour)this).StartCoroutine(fadeAudioIn(fadeIn: false));
	}

	public void FadeAudioIn(AudioSource audio)
	{
		if (fadeCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(fadeCoroutine);
		}
		fadeCoroutine = ((MonoBehaviour)this).StartCoroutine(fadeAudioIn(fadeIn: true));
	}

	private IEnumerator fadeAudioIn(bool fadeIn)
	{
		if (fadeIn)
		{
			audioToPlay2.volume = 0f;
			for (int i = 0; i < 20; i++)
			{
				yield return null;
				AudioSource obj = audioToPlay2;
				obj.volume += 0.05f;
			}
		}
		else
		{
			for (int j = 0; j < 20; j++)
			{
				AudioSource obj2 = audioToPlay2;
				obj2.volume -= 0.05f;
			}
			audioToPlay2.Stop();
		}
	}

	public void LoadNewFloor()
	{
	}

	public void ElevatorFullyRunning()
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		roundManager.isSpawningEnemies = false;
		roundManager.DetectElevatorIsRunning();
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null && !GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			if (!GameNetworkManager.Instance.localPlayerController.isInElevator)
			{
				Debug.Log((object)$"Killing player obj #{GameNetworkManager.Instance.localPlayerController.playerClientId}, they were not in the ship when it left.");
				GameNetworkManager.Instance.localPlayerController.KillPlayer(Vector3.zero, spawnBody: false, CauseOfDeath.Abandoned);
				HUDManager.Instance.AddTextToChatOnServer(GameNetworkManager.Instance.localPlayerController.playerUsername + " was left behind.");
			}
			else
			{
				roundManager.playersManager.ForcePlayerIntoShip();
			}
		}
		roundManager.playersManager.ShipHasLeft();
		SetBodiesKinematic();
	}

	private void SetBodiesKinematic()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		DeadBodyInfo[] array = Object.FindObjectsOfType<DeadBodyInfo>();
		for (int i = 0; i < array.Length; i++)
		{
			Bounds bounds = StartOfRound.Instance.shipBounds.bounds;
			if (((Bounds)(ref bounds)).Contains(array[i].bodyParts[5].position))
			{
				array[i].isInShip = true;
			}
			if (array[i].isInShip && (Object)(object)array[i].grabBodyObject != (Object)null && !array[i].grabBodyObject.isHeld)
			{
				array[i].grabBodyObject.grabbable = false;
				array[i].grabBodyObject.grabbableToEnemies = false;
				array[i].SetBodyPartsKinematic();
			}
		}
	}

	public void ElevatorNoLongerRunning()
	{
		roundManager.ElevatorRunning = false;
	}
}
