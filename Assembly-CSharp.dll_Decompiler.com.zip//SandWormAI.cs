using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class SandWormAI : EnemyAI
{
	public AudioSource groundAudio;

	public ParticleSystem emergeFromGroundParticle1;

	public ParticleSystem emergeFromGroundParticle2;

	public ParticleSystem hitGroundParticle;

	public AudioClip[] groundRumbleSFX;

	public AudioClip[] ambientRumbleSFX;

	public AudioClip hitGroundSFX;

	public AudioClip emergeFromGroundSFX;

	public AudioClip[] roarSFX;

	public bool inEmergingState;

	public bool emerged;

	private int timesEmerging;

	public bool hitGroundInAnimation;

	public Transform endingPosition;

	public Transform[] airPathNodes;

	public Vector3 endOfFlightPathPosition;

	private Coroutine emergingFromGroundCoroutine;

	public AISearchRoutine roamMap;

	public float chaseTimer;

	private int stateLastFrame;

	private NavMeshHit navHit;

	private Random sandWormRandom;

	public override void Start()
	{
		base.Start();
		sandWormRandom = new Random(StartOfRound.Instance.randomMapSeed + 15 + thisEnemyIndex);
		roamMap.randomized = true;
	}

	public override void DoAIInterval()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.livingPlayers == 0 || isEnemyDead)
		{
			return;
		}
		PlayerControllerB playerControllerB = null;
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (!emerged && !inEmergingState)
			{
				if (!roamMap.inProgress)
				{
					StartSearch(((Component)this).transform.position, roamMap);
				}
				agent.speed = 4f;
				playerControllerB = GetClosestPlayer(requireLineOfSight: false, cannotBeInShip: true, cannotBeNearShip: true);
				if ((Object)(object)playerControllerB != (Object)null && mostOptimalDistance < 15f)
				{
					SetMovingTowardsTargetPlayer(playerControllerB);
					SwitchToBehaviourState(1);
					chaseTimer = 0f;
				}
			}
			break;
		case 1:
			if (roamMap.inProgress)
			{
				StopSearch(roamMap);
			}
			targetPlayer = GetClosestPlayer(requireLineOfSight: false, cannotBeInShip: true, cannotBeNearShip: true);
			if (mostOptimalDistance > 19f)
			{
				targetPlayer = null;
			}
			if ((Object)(object)targetPlayer == (Object)null)
			{
				SwitchToBehaviourState(0);
				break;
			}
			SetMovingTowardsTargetPlayer(targetPlayer);
			if (chaseTimer < 1.5f && Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position) < 4f && !(Vector3.Distance(StartOfRound.Instance.shipInnerRoomBounds.ClosestPoint(((Component)this).transform.position), ((Component)this).transform.position) < 9f) && Random.Range(0, 100) < 17)
			{
				StartEmergeAnimation();
			}
			break;
		}
	}

	public override void Update()
	{
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead)
		{
			return;
		}
		if (stateLastFrame != currentBehaviourStateIndex)
		{
			stateLastFrame = currentBehaviourStateIndex;
			chaseTimer = 0f;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (creatureSFX.isPlaying)
			{
				creatureSFX.Stop();
			}
			break;
		case 1:
			if (!creatureSFX.isPlaying && !inEmergingState && !emerged)
			{
				int num = Random.Range(0, ambientRumbleSFX.Length);
				creatureSFX.clip = ambientRumbleSFX[num];
				creatureSFX.Play();
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if ((Object)(object)targetPlayer == (Object)null)
			{
				SwitchToBehaviourState(0);
				break;
			}
			if (!PlayerIsTargetable(targetPlayer, cannotBeInShip: true) || Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position) > 22f)
			{
				chaseTimer += Time.deltaTime;
			}
			else
			{
				chaseTimer = 0f;
			}
			if (chaseTimer > 6f)
			{
				SwitchToBehaviourState(0);
			}
			break;
		}
	}

	public void StartEmergeAnimation()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		inEmergingState = true;
		float num = RoundManager.Instance.YRotationThatFacesTheFarthestFromPosition(((Component)this).transform.position + Vector3.up * 1.5f, 30f);
		num += Random.Range(-45f, 45f);
		((Behaviour)agent).enabled = false;
		inSpecialAnimation = true;
		((Component)this).transform.eulerAngles = new Vector3(0f, num, 0f);
		bool flag = false;
		RaycastHit val2 = default(RaycastHit);
		for (int i = 0; i < 6; i++)
		{
			for (int j = 0; j < airPathNodes.Length - 1; j++)
			{
				Vector3 val = airPathNodes[j + 1].position - airPathNodes[j].position;
				if (!Physics.SphereCast(airPathNodes[j].position, 5f, val, ref val2, ((Vector3)(ref val)).magnitude, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					continue;
				}
				flag = false;
				for (int k = 0; k < StartOfRound.Instance.naturalSurfaceTags.Length; k++)
				{
					if (((Component)((RaycastHit)(ref val2)).collider).CompareTag(StartOfRound.Instance.naturalSurfaceTags[k]) || (StartOfRound.Instance.currentLevel.levelID == 12 && ((Component)((RaycastHit)(ref val2)).collider).CompareTag("Rock")))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					break;
				}
			}
			if (!flag)
			{
				num += 60f;
				((Component)this).transform.eulerAngles = new Vector3(0f, num, 0f);
			}
			else if (Physics.Raycast(endingPosition.position + Vector3.up * 50f, Vector3.down, ref val2, 100f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				endOfFlightPathPosition = RoundManager.Instance.GetNavMeshPosition(((RaycastHit)(ref val2)).point, navHit, 8f, agent.areaMask);
				if (!RoundManager.Instance.GotNavMeshPositionResult)
				{
					endOfFlightPathPosition = RoundManager.Instance.GetClosestNode(((RaycastHit)(ref val2)).point).position;
				}
				break;
			}
		}
		if (!flag)
		{
			inSpecialAnimation = false;
			((Behaviour)agent).enabled = true;
			inEmergingState = false;
		}
		else
		{
			EmergeServerRpc((int)num);
		}
	}

	[ServerRpc]
	public void EmergeServerRpc(int yRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1498805140u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, yRot);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1498805140u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			EmergeClientRpc(yRot);
		}
	}

	[ClientRpc]
	public void EmergeClientRpc(int yRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1497638036u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, yRot);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1497638036u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			inSpecialAnimation = true;
			inEmergingState = true;
			hitGroundInAnimation = false;
			((Behaviour)agent).enabled = false;
			((Component)this).transform.position = serverPosition;
			((Component)this).transform.eulerAngles = new Vector3(0f, (float)yRot, 0f);
			timesEmerging++;
			creatureSFX.Stop();
			if (emergingFromGroundCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(emergingFromGroundCoroutine);
			}
			emergingFromGroundCoroutine = ((MonoBehaviour)this).StartCoroutine(EmergeFromGround(yRot));
		}
	}

	private IEnumerator EmergeFromGround(int rot)
	{
		RoundManager.PlayRandomClip(creatureSFX, groundRumbleSFX);
		emergeFromGroundParticle1.Play(true);
		yield return (object)new WaitForSeconds((float)sandWormRandom.Next(3, 7) / 3f);
		creatureAnimator.SetBool("emerge", true);
		inEmergingState = false;
		emerged = true;
		yield return (object)new WaitForSeconds(0.1f);
		creatureSFX.PlayOneShot(emergeFromGroundSFX);
		emergeFromGroundParticle2.Play();
		ShakePlayerCameraInProximity(((Component)this).transform.position);
		yield return (object)new WaitForSeconds((float)sandWormRandom.Next(2, 5) / 3f);
		creatureVoice.PlayOneShot(roarSFX[sandWormRandom.Next(0, roarSFX.Length)]);
		Debug.Log((object)"Playing sandworm roar!");
		yield return (object)new WaitUntil((Func<bool>)(() => hitGroundInAnimation));
		hitGroundParticle.Play(true);
		groundAudio.PlayOneShot(hitGroundSFX);
		ShakePlayerCameraInProximity(((Component)groundAudio).transform.position);
		yield return (object)new WaitForSeconds(10f);
		SetInGround();
	}

	private void ShakePlayerCameraInProximity(Vector3 pos)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (!GameNetworkManager.Instance.localPlayerController.isInsideFactory)
		{
			float num = Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, pos);
			if (num < 27f)
			{
				Debug.Log((object)"Shaking camera strong");
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
			else if (num < 50f)
			{
				Debug.Log((object)"Shaking camera strong");
				HUDManager.Instance.ShakeCamera(ScreenShakeType.VeryStrong);
			}
			else if (num < 90f)
			{
				Debug.Log((object)"Shaking camera long");
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
			}
			else if (num < 120f)
			{
				Debug.Log((object)"Shaking camera small");
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
			}
		}
	}

	public void HitGroundInAnimation()
	{
		hitGroundInAnimation = true;
	}

	public void SetInGround()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.position = endOfFlightPathPosition;
		inSpecialAnimation = false;
		emerged = false;
		inEmergingState = false;
		creatureAnimator.SetBool("emerge", false);
		if (((NetworkBehaviour)this).IsOwner)
		{
			((Behaviour)agent).enabled = true;
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		base.OnCollideWithPlayer(other);
		if (!isEnemyDead && emerged)
		{
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)null && (Object)(object)component.inAnimationWithEnemy == (Object)null && (Object)(object)component == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				EatPlayer(component);
			}
		}
	}

	public void EatPlayer(PlayerControllerB playerScript)
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (playerScript.inSpecialInteractAnimation && (Object)(object)playerScript.currentTriggerInAnimationWith != (Object)null)
		{
			playerScript.currentTriggerInAnimationWith.CancelAnimationExternally();
		}
		playerScript.inAnimationWithEnemy = null;
		playerScript.inSpecialInteractAnimation = false;
		Debug.Log((object)"KILL player called");
		playerScript.KillPlayer(Vector3.zero, spawnBody: false);
	}

	public override void OnCollideWithEnemy(Collider other, EnemyAI enemyScript = null)
	{
		base.OnCollideWithEnemy(other);
		if (((NetworkBehaviour)this).IsServer && emerged)
		{
			enemyScript.KillEnemyOnOwnerClient(overrideDestroy: true);
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_SandWormAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1498805140u, new RpcReceiveHandler(__rpc_handler_1498805140));
		NetworkManager.__rpc_func_table.Add(1497638036u, new RpcReceiveHandler(__rpc_handler_1497638036));
	}

	private static void __rpc_handler_1498805140(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int yRot = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref yRot);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandWormAI)(object)target).EmergeServerRpc(yRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1497638036(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int yRot = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref yRot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandWormAI)(object)target).EmergeClientRpc(yRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "SandWormAI";
	}
}
