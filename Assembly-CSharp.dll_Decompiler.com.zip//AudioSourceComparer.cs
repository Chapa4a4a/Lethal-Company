using System.Collections.Generic;
using UnityEngine;

internal class AudioSourceComparer : IEqualityComparer<AudioSource>
{
	public bool Equals(AudioSource x, AudioSource y)
	{
		return ((Object)x).GetInstanceID() == ((Object)y).GetInstanceID();
	}

	public int GetHashCode(AudioSource obj)
	{
		return ((Object)obj).GetInstanceID().GetHashCode();
	}
}
