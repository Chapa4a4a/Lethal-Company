namespace DunGen.Graph;

public enum NodeType
{
	Normal,
	Start,
	Goal
}
