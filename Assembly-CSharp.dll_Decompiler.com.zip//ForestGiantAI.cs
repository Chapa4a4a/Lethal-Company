using System.Collections;
using System.Linq;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.Rendering.HighDefinition;

public class ForestGiantAI : EnemyAI, IVisibleThreat
{
	private Coroutine eatPlayerCoroutine;

	private bool inEatingPlayerAnimation;

	public Transform holdPlayerPoint;

	public AISearchRoutine roamPlanet;

	public AISearchRoutine searchForPlayers;

	private float velX;

	private float velZ;

	private Vector3 previousPosition;

	private Vector3 agentLocalVelocity;

	public Transform animationContainer;

	public TwoBoneIKConstraint reachForPlayerRig;

	public Transform reachForPlayerTarget;

	private float stopAndLookInterval;

	private float stopAndLookTimer;

	private float targetYRot;

	public float scrutiny = 1f;

	public float[] playerStealthMeters = new float[4];

	public float timeSpentStaring;

	public bool investigating;

	private bool hasBegunInvestigating;

	public Vector3 investigatePosition;

	public PlayerControllerB chasingPlayer;

	private bool lostPlayerInChase;

	private float noticePlayerTimer;

	private bool lookingAtTarget;

	public Transform turnCompass;

	public Transform lookTarget;

	private bool chasingPlayerInLOS;

	private float timeSinceChangingTarget;

	private bool hasLostPlayerInChaseDebounce;

	private bool triggerChaseByTouchingDebounce;

	public AudioSource farWideSFX;

	public DecalProjector bloodOnFaceDecal;

	private Vector3 lastSeenPlayerPositionInChase;

	private float timeSinceDetectingVoice;

	public Transform centerPosition;

	public Transform handBone;

	public Transform deathFallPosition;

	public AudioClip giantFall;

	public AudioClip giantCry;

	public AudioSource giantBurningAudio;

	public GameObject burningParticlesContainer;

	private float timeAtStartOfBurning;

	ThreatType IVisibleThreat.type => ThreatType.ForestGiant;

	bool IVisibleThreat.IsThreatDead()
	{
		return isEnemyDead;
	}

	GrabbableObject IVisibleThreat.GetHeldObject()
	{
		return null;
	}

	int IVisibleThreat.SendSpecialBehaviour(int id)
	{
		return 0;
	}

	int IVisibleThreat.GetThreatLevel(Vector3 seenByPosition)
	{
		return 18;
	}

	int IVisibleThreat.GetInterestLevel()
	{
		return 0;
	}

	Transform IVisibleThreat.GetThreatLookTransform()
	{
		return eye;
	}

	Transform IVisibleThreat.GetThreatTransform()
	{
		return ((Component)this).transform;
	}

	Vector3 IVisibleThreat.GetThreatVelocity()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			return agent.velocity;
		}
		return Vector3.zero;
	}

	float IVisibleThreat.GetVisibility()
	{
		if (isEnemyDead)
		{
			return 0f;
		}
		if (((Vector3)(ref agentLocalVelocity)).sqrMagnitude > 0f)
		{
			return 1f;
		}
		return 0.75f;
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		enemyHP -= force;
		if ((float)enemyHP <= 0f && !isEnemyDead && ((NetworkBehaviour)this).IsOwner)
		{
			KillEnemyOnOwnerClient();
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		base.KillEnemy(destroy);
		agent.speed = 0f;
		if (eatPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(eatPlayerCoroutine);
		}
		DropPlayerBody();
		creatureVoice.PlayOneShot(giantCry);
		burningParticlesContainer.SetActive(false);
	}

	public override void AnimationEventA()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		base.AnimationEventA();
		RaycastHit[] array = Physics.SphereCastAll(deathFallPosition.position, 2.7f, deathFallPosition.forward, 3.9f, StartOfRound.Instance.playersMask, (QueryTriggerInteraction)1);
		for (int i = 0; i < array.Length; i++)
		{
			PlayerControllerB component = ((Component)((RaycastHit)(ref array[i])).transform).GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)null && (Object)(object)component == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				GameNetworkManager.Instance.localPlayerController.KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Gravity);
				break;
			}
		}
	}

	public override void HitFromExplosion(float distance)
	{
		base.HitFromExplosion(distance);
		if (!isEnemyDead && currentBehaviourStateIndex != 2)
		{
			timeAtStartOfBurning = Time.realtimeSinceStartup;
			if (((NetworkBehaviour)this).IsOwner)
			{
				SwitchToBehaviourState(2);
			}
		}
	}

	public override void Start()
	{
		base.Start();
		for (int i = 0; i < playerStealthMeters.Length; i++)
		{
			playerStealthMeters[i] = 0f;
		}
		lookTarget.SetParent((Transform)null);
	}

	public override void DoAIInterval()
	{
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.livingPlayers == 0 || isEnemyDead)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (searchForPlayers.inProgress)
			{
				StopSearch(searchForPlayers);
			}
			if (investigating)
			{
				if (!hasBegunInvestigating)
				{
					hasBegunInvestigating = true;
					StopSearch(roamPlanet, clear: false);
					SetDestinationToPosition(investigatePosition);
				}
				if (Vector3.Distance(((Component)this).transform.position, investigatePosition) < 5f)
				{
					investigating = false;
					hasBegunInvestigating = false;
				}
			}
			else if (!roamPlanet.inProgress)
			{
				Vector3 position = ((Component)this).transform.position;
				if (previousBehaviourStateIndex == 1 && Vector3.Distance(((Component)this).transform.position, StartOfRound.Instance.elevatorTransform.position) < 30f)
				{
					position = ChooseFarthestNodeFromPosition(StartOfRound.Instance.elevatorTransform.position).position;
				}
				StartSearch(position, roamPlanet);
			}
			break;
		case 1:
			investigating = false;
			hasBegunInvestigating = false;
			if (roamPlanet.inProgress)
			{
				StopSearch(roamPlanet, clear: false);
			}
			if (lostPlayerInChase)
			{
				if (!searchForPlayers.inProgress)
				{
					Debug.Log((object)"Forest giant starting search for players routine");
					searchForPlayers.searchWidth = 25f;
					StartSearch(lastSeenPlayerPositionInChase, searchForPlayers);
					Debug.Log((object)"Lost player in chase; beginning search where the player was last seen");
				}
			}
			else
			{
				if (searchForPlayers.inProgress)
				{
					StopSearch(searchForPlayers);
					Debug.Log((object)"Found player during chase; stopping search coroutine and moving after target player");
				}
				SetMovingTowardsTargetPlayer(chasingPlayer);
			}
			break;
		case 2:
			if (searchForPlayers.inProgress)
			{
				StopSearch(searchForPlayers);
			}
			if (!roamPlanet.inProgress)
			{
				roamPlanet.searchPrecision = 18f;
				StartSearch(ChooseFarthestNodeFromPosition(((Component)this).transform.position).position, roamPlanet);
			}
			break;
		}
	}

	public override void FinishedCurrentSearchRoutine()
	{
		if (((NetworkBehaviour)this).IsOwner && currentBehaviourStateIndex == 1 && lostPlayerInChase && !chasingPlayerInLOS)
		{
			Debug.Log((object)"Forest giant: Finished search; player not in line of sight, lost player, returning to roaming mode");
			SwitchToBehaviourState(0);
		}
	}

	public override void ReachedNodeInSearch()
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		base.ReachedNodeInSearch();
		if (((NetworkBehaviour)this).IsOwner && currentBehaviourStateIndex == 0 && stopAndLookInterval > 12f)
		{
			stopAndLookInterval = 0f;
			stopAndLookTimer = Random.Range(3f, 12f);
			targetYRot = RoundManager.Instance.YRotationThatFacesTheFarthestFromPosition(eye.position, 10f, 5);
		}
	}

	private void LateUpdate()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null)
		{
			((Component)inSpecialAnimationWithPlayer).transform.position = holdPlayerPoint.position;
			((Component)inSpecialAnimationWithPlayer).transform.rotation = holdPlayerPoint.rotation;
		}
		if (lookingAtTarget)
		{
			LookAtTarget();
		}
		creatureAnimator.SetBool("staring", lookingAtTarget);
		if (!((Object)(object)GameNetworkManager.Instance == (Object)null) && !((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null))
		{
			farWideSFX.volume = Mathf.Clamp(Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position) / (farWideSFX.maxDistance - 10f), 0f, 1f);
		}
	}

	private void GiantSeePlayerEffect()
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead || GameNetworkManager.Instance.localPlayerController.isInsideFactory)
		{
			return;
		}
		if (currentBehaviourStateIndex == 1 && (Object)(object)chasingPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController && !lostPlayerInChase)
		{
			GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(1.4f);
			return;
		}
		bool flag = false;
		if (!GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom && CheckLineOfSightForPosition(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position, 45f, 70))
		{
			if (Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) < 15f)
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.7f);
			}
			else
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.4f);
			}
		}
	}

	public override void Update()
	{
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0420: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0325: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b9: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		if (isEnemyDead)
		{
			AudioSource obj = giantBurningAudio;
			obj.volume -= Time.deltaTime * 0.5f;
		}
		if ((stunNormalizedTimer > 0f && inEatingPlayerAnimation) || isEnemyDead || currentBehaviourStateIndex == 2)
		{
			StopKillAnimation();
		}
		else
		{
			GiantSeePlayerEffect();
		}
		if (isEnemyDead)
		{
			return;
		}
		creatureAnimator.SetBool("stunned", stunNormalizedTimer > 0f);
		CalculateAnimationDirection();
		stopAndLookInterval += Time.deltaTime;
		timeSinceChangingTarget += Time.deltaTime;
		timeSinceDetectingVoice += Time.deltaTime;
		switch (currentBehaviourStateIndex)
		{
		case 0:
			((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)reachForPlayerRig).weight = Mathf.Lerp(((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)reachForPlayerRig).weight, 0f, Time.deltaTime * 15f);
			lostPlayerInChase = false;
			triggerChaseByTouchingDebounce = false;
			hasLostPlayerInChaseDebounce = false;
			lookingAtTarget = false;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if (stopAndLookTimer > 0f)
			{
				stopAndLookTimer -= Time.deltaTime;
				turnCompass.eulerAngles = new Vector3(((Component)this).transform.eulerAngles.x, targetYRot, ((Component)this).transform.eulerAngles.z);
				((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, turnCompass.rotation, 5f * Time.deltaTime);
				agent.speed = 0f;
			}
			else
			{
				if (stunNormalizedTimer > 0f && (Object)(object)stunnedByPlayer != (Object)null && (Object)(object)stunnedByPlayer != (Object)(object)chasingPlayer)
				{
					FindAndTargetNewPlayerOnLocalClient(stunnedByPlayer);
					BeginChasingNewPlayerClientRpc((int)stunnedByPlayer.playerClientId);
				}
				agent.speed = 5f;
			}
			LookForPlayers();
			break;
		case 1:
			ReachForPlayerIfClose();
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if (inEatingPlayerAnimation)
			{
				agent.speed = 0f;
				break;
			}
			LookForPlayers();
			if (lostPlayerInChase)
			{
				if (!hasLostPlayerInChaseDebounce)
				{
					lookingAtTarget = false;
					hasLostPlayerInChaseDebounce = true;
					HasLostPlayerInChaseClientRpc();
				}
				((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)reachForPlayerRig).weight = Mathf.Lerp(((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)reachForPlayerRig).weight, 0f, Time.deltaTime * 15f);
				if (stopAndLookTimer > 0f)
				{
					stopAndLookTimer -= Time.deltaTime;
					turnCompass.eulerAngles = new Vector3(((Component)this).transform.eulerAngles.x, targetYRot, ((Component)this).transform.eulerAngles.z);
					((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, turnCompass.rotation, 5f * Time.deltaTime);
					agent.speed = 0f;
				}
				else if (stunNormalizedTimer > 0f)
				{
					agent.speed = 0f;
				}
				else
				{
					agent.speed = Mathf.Min(Mathf.Max(agent.speed, 0.1f) * 1.3f, 7f);
					Debug.Log((object)$"agent speed: {agent.speed}");
				}
				if (chasingPlayerInLOS)
				{
					noticePlayerTimer = 0f;
					lostPlayerInChase = false;
					break;
				}
				noticePlayerTimer += Time.deltaTime;
				if (noticePlayerTimer > 9f)
				{
					SwitchToBehaviourState(0);
				}
				break;
			}
			lookTarget.position = ((Component)chasingPlayer).transform.position;
			lookingAtTarget = true;
			if (stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
			}
			else
			{
				agent.speed = Mathf.Min(Mathf.Max(agent.speed, 0.1f) * 1.3f, 7f);
			}
			if (hasLostPlayerInChaseDebounce)
			{
				hasLostPlayerInChaseDebounce = false;
				HasFoundPlayerInChaseClientRpc();
			}
			if (chasingPlayerInLOS)
			{
				noticePlayerTimer = 0f;
				lastSeenPlayerPositionInChase = ((Component)chasingPlayer).transform.position;
				break;
			}
			noticePlayerTimer += Time.deltaTime;
			if (noticePlayerTimer > 3f)
			{
				lostPlayerInChase = true;
			}
			break;
		case 2:
			lookingAtTarget = false;
			if (isEnemyDead)
			{
				break;
			}
			if (!burningParticlesContainer.activeSelf)
			{
				burningParticlesContainer.SetActive(true);
			}
			if (!giantBurningAudio.isPlaying)
			{
				giantBurningAudio.Play();
			}
			giantBurningAudio.volume = Mathf.Min(giantBurningAudio.volume + Time.deltaTime * 0.5f, 1f);
			if (((NetworkBehaviour)this).IsOwner)
			{
				agent.speed = Mathf.Min(Mathf.Max(agent.speed, 0.1f) * 1.3f, 8f);
				if (Time.realtimeSinceStartup - timeAtStartOfBurning > 10f)
				{
					KillEnemyOnOwnerClient();
				}
			}
			break;
		}
	}

	private void ReachForPlayerIfClose()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		if (stunNormalizedTimer <= 0f && !lostPlayerInChase && (Object)(object)inSpecialAnimationWithPlayer == (Object)null && !Physics.Linecast(eye.position, ((Component)chasingPlayer).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault) && Vector3.Distance(((Component)this).transform.position, ((Component)chasingPlayer).transform.position) < 8f)
		{
			((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)reachForPlayerRig).weight = Mathf.Lerp(((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)reachForPlayerRig).weight, 0.9f, Time.deltaTime * 6f);
			Vector3 val = ((Component)chasingPlayer).transform.position + Vector3.up * 0.5f;
			reachForPlayerTarget.position = new Vector3(val.x + Random.Range(-0.2f, 0.2f), val.y + Random.Range(-0.2f, 0.2f), val.z + Random.Range(-0.2f, 0.2f));
		}
		else
		{
			((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)reachForPlayerRig).weight = Mathf.Lerp(((RigConstraint<TwoBoneIKConstraintJob, TwoBoneIKConstraintData, TwoBoneIKConstraintJobBinder<TwoBoneIKConstraintData>>)(object)reachForPlayerRig).weight, 0f, Time.deltaTime * 15f);
		}
	}

	private void LookAtTarget()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		turnCompass.LookAt(lookTarget);
		((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, turnCompass.rotation, 15f * Time.deltaTime);
		((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.localEulerAngles.y, 0f);
	}

	private void LookForPlayers()
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB[] allPlayersInLineOfSight = GetAllPlayersInLineOfSight(50f, 70, eye, 3f, StartOfRound.Instance.collidersRoomDefaultAndFoliage);
		if (allPlayersInLineOfSight != null)
		{
			PlayerControllerB playerControllerB = allPlayersInLineOfSight[0];
			int num = 0;
			float num2 = 1000f;
			PlayerControllerB playerControllerB2 = allPlayersInLineOfSight[0];
			float num3 = 0f;
			float num4 = 1f;
			for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
			{
				if (allPlayersInLineOfSight.Contains(StartOfRound.Instance.allPlayerScripts[i]))
				{
					float num5 = Vector3.Distance(((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position, eye.position);
					if (!StartOfRound.Instance.allPlayerScripts[i].isCrouching)
					{
						num4 += 1f;
					}
					if (StartOfRound.Instance.allPlayerScripts[i].timeSincePlayerMoving < 0.1f)
					{
						num4 += 1f;
					}
					playerStealthMeters[i] += Mathf.Clamp(Time.deltaTime / (num5 * 0.21f) * scrutiny * num4, 0f, 1f);
					if (playerStealthMeters[i] > num3)
					{
						num3 = playerStealthMeters[i];
						playerControllerB2 = StartOfRound.Instance.allPlayerScripts[i];
					}
					if (num5 < num2)
					{
						playerControllerB = StartOfRound.Instance.allPlayerScripts[i];
						num2 = num5;
						num = i;
					}
				}
				else
				{
					playerStealthMeters[i] -= Time.deltaTime * 0.33f;
				}
			}
			if (currentBehaviourStateIndex == 1)
			{
				if (lostPlayerInChase)
				{
					chasingPlayerInLOS = num3 > 0.15f;
					return;
				}
				chasingPlayerInLOS = allPlayersInLineOfSight.Contains(chasingPlayer);
				if ((Object)(object)stunnedByPlayer != (Object)null)
				{
					playerControllerB = stunnedByPlayer;
				}
				if ((Object)(object)playerControllerB != (Object)(object)chasingPlayer && playerStealthMeters[num] > 0.3f && timeSinceChangingTarget > 2f)
				{
					FindAndTargetNewPlayerOnLocalClient(playerControllerB);
					if (((NetworkBehaviour)this).IsServer)
					{
						BeginChasingNewPlayerServerRpc((int)playerControllerB.playerClientId);
					}
				}
				return;
			}
			if ((Object)(object)stunnedByPlayer != (Object)null)
			{
				playerControllerB2 = stunnedByPlayer;
			}
			if (num3 > 1f || Object.op_Implicit((Object)(object)stunnedByPlayer))
			{
				BeginChasingNewPlayerClientRpc((int)playerControllerB2.playerClientId);
				chasingPlayerInLOS = true;
			}
			else if (num3 > 0.35f)
			{
				if (stopAndLookTimer < 2f)
				{
					stopAndLookTimer = 2f;
				}
				turnCompass.LookAt(((Component)playerControllerB2).transform);
				targetYRot = turnCompass.eulerAngles.y;
				timeSpentStaring += Time.deltaTime;
			}
			if (currentBehaviourStateIndex != 1 && timeSpentStaring > 3f && !investigating)
			{
				investigating = true;
				hasBegunInvestigating = false;
				investigatePosition = RoundManager.Instance.GetNavMeshPosition(((Component)playerControllerB2).transform.position);
			}
		}
		else
		{
			if (currentBehaviourStateIndex == 1)
			{
				chasingPlayerInLOS = false;
			}
			timeSpentStaring = 0f;
		}
	}

	public void FindAndTargetNewPlayerOnLocalClient(PlayerControllerB newPlayer)
	{
		chasingPlayer = newPlayer;
		timeSinceChangingTarget = 0f;
		stopAndLookTimer = 0f;
	}

	[ServerRpc]
	private void BeginChasingNewPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(344062384u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 344062384u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			BeginChasingNewPlayerClientRpc(playerId);
		}
	}

	[ClientRpc]
	private void BeginChasingNewPlayerClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1296181132u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1296181132u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			noticePlayerTimer = 0f;
			timeSinceChangingTarget = 0f;
			chasingPlayer = StartOfRound.Instance.allPlayerScripts[playerId];
			hasLostPlayerInChaseDebounce = false;
			lostPlayerInChase = false;
			if (timeSinceChangingTarget > 1f)
			{
				agent.speed = 0f;
			}
			SwitchToBehaviourStateOnLocalClient(1);
		}
	}

	[ClientRpc]
	private void HasLostPlayerInChaseClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3295708237u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3295708237u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				lostPlayerInChase = true;
				lookingAtTarget = false;
			}
		}
	}

	[ClientRpc]
	private void HasFoundPlayerInChaseClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2685047264u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2685047264u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				lostPlayerInChase = false;
				lookingAtTarget = true;
			}
		}
	}

	private void CalculateAnimationDirection(float maxSpeed = 1f)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		agentLocalVelocity = animationContainer.InverseTransformDirection(Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 4f));
		velX = Mathf.Lerp(velX, agentLocalVelocity.x, 5f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityX", Mathf.Clamp(velX, 0f - maxSpeed, maxSpeed));
		velZ = Mathf.Lerp(velZ, agentLocalVelocity.z, 5f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityY", Mathf.Clamp(velZ, 0f - maxSpeed, maxSpeed));
		previousPosition = ((Component)this).transform.position;
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null || inEatingPlayerAnimation || stunNormalizedTimer >= 0f || currentBehaviourStateIndex == 2)
		{
			return;
		}
		PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other, inEatingPlayerAnimation);
		if (!((Object)(object)playerControllerB != (Object)null) || !((Object)(object)playerControllerB == (Object)(object)GameNetworkManager.Instance.localPlayerController))
		{
			return;
		}
		VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
		if ((Object)(object)vehicleController != (Object)null && (Object)(object)playerControllerB.physicsParent != (Object)null && (Object)(object)playerControllerB.physicsParent == (Object)(object)((Component)vehicleController).transform && !vehicleController.backDoorOpen)
		{
			return;
		}
		Vector3 val = Vector3.Normalize((centerPosition.position - (((Component)GameNetworkManager.Instance.localPlayerController).transform.position + Vector3.up * 1.5f)) * 1000f);
		RaycastHit val2 = default(RaycastHit);
		if (!Physics.Linecast(centerPosition.position + val * 1.7f, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position + Vector3.up * 1.5f, ref val2, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) && ((!StartOfRound.Instance.shipIsLeaving && StartOfRound.Instance.shipHasLanded) || !GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom) && !((Object)(object)playerControllerB.inAnimationWithEnemy != (Object)null))
		{
			if (playerControllerB.inSpecialInteractAnimation && (Object)(object)playerControllerB.currentTriggerInAnimationWith != (Object)null)
			{
				playerControllerB.currentTriggerInAnimationWith.CancelAnimationExternally();
			}
			if (currentBehaviourStateIndex == 0 && !triggerChaseByTouchingDebounce)
			{
				triggerChaseByTouchingDebounce = true;
				BeginChasingNewPlayerServerRpc((int)playerControllerB.playerClientId);
			}
			else
			{
				GrabPlayerServerRpc((int)playerControllerB.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void GrabPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2965927486u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2965927486u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !((Object)(object)inSpecialAnimationWithPlayer != (Object)null))
		{
			Vector3 position = ((Component)this).transform.position;
			int enemyYRot = (int)((Component)this).transform.eulerAngles.y;
			RaycastHit val3 = default(RaycastHit);
			if (Physics.Raycast(centerPosition.position, centerPosition.forward, ref val3, 6f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				enemyYRot = (int)RoundManager.Instance.YRotationThatFacesTheFarthestFromPosition(position, 20f, 5);
			}
			GrabPlayerClientRpc(playerId, position, enemyYRot);
		}
	}

	[ClientRpc]
	public void GrabPlayerClientRpc(int playerId, Vector3 enemyPosition, int enemyYRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3924255731u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref enemyPosition);
				BytePacker.WriteValueBitPacked(val2, enemyYRot);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3924255731u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)inSpecialAnimationWithPlayer != (Object)null))
			{
				BeginEatPlayer(StartOfRound.Instance.allPlayerScripts[playerId], enemyPosition, enemyYRot);
			}
		}
	}

	private void BeginEatPlayer(PlayerControllerB playerBeingEaten, Vector3 enemyPosition, int enemyYRot)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		inSpecialAnimationWithPlayer = playerBeingEaten;
		inSpecialAnimationWithPlayer.inSpecialInteractAnimation = true;
		inSpecialAnimationWithPlayer.inAnimationWithEnemy = this;
		if (eatPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(eatPlayerCoroutine);
		}
		eatPlayerCoroutine = ((MonoBehaviour)this).StartCoroutine(EatPlayerAnimation(playerBeingEaten, enemyPosition, enemyYRot));
	}

	private IEnumerator EatPlayerAnimation(PlayerControllerB playerBeingEaten, Vector3 enemyPosition, int enemyYRot)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		lookingAtTarget = false;
		creatureAnimator.SetTrigger("EatPlayer");
		inEatingPlayerAnimation = true;
		inSpecialAnimation = true;
		playerBeingEaten.isInElevator = false;
		playerBeingEaten.isInHangarShipRoom = false;
		Vector3 startPosition = ((Component)this).transform.position;
		Quaternion startRotation = ((Component)this).transform.rotation;
		for (int i = 0; i < 10; i++)
		{
			((Component)this).transform.position = Vector3.Lerp(startPosition, enemyPosition, (float)i / 10f);
			((Component)this).transform.rotation = Quaternion.Lerp(startRotation, Quaternion.Euler(((Component)this).transform.eulerAngles.x, (float)enemyYRot, ((Component)this).transform.eulerAngles.z), (float)i / 10f);
			yield return (object)new WaitForSeconds(0.01f);
		}
		((Component)this).transform.position = enemyPosition;
		((Component)this).transform.rotation = Quaternion.Euler(((Component)this).transform.eulerAngles.x, (float)enemyYRot, ((Component)this).transform.eulerAngles.z);
		serverRotation = ((Component)this).transform.eulerAngles;
		yield return (object)new WaitForSeconds(0.2f);
		inSpecialAnimation = false;
		yield return (object)new WaitForSeconds(4.4f);
		if ((Object)(object)playerBeingEaten.inAnimationWithEnemy == (Object)(object)this && !playerBeingEaten.isPlayerDead)
		{
			inSpecialAnimationWithPlayer = null;
			playerBeingEaten.KillPlayer(Vector3.zero, spawnBody: false, CauseOfDeath.Crushing);
			playerBeingEaten.inSpecialInteractAnimation = false;
			playerBeingEaten.inAnimationWithEnemy = null;
			((Behaviour)bloodOnFaceDecal).enabled = true;
			yield return (object)new WaitForSeconds(3f);
		}
		else
		{
			creatureVoice.Stop();
		}
		inEatingPlayerAnimation = false;
		inSpecialAnimationWithPlayer = null;
		if (((NetworkBehaviour)this).IsOwner)
		{
			if ((Object)(object)CheckLineOfSightForPlayer(50f, 15) != (Object)null)
			{
				_ = chasingPlayer;
			}
			else
			{
				SwitchToBehaviourState(0);
			}
		}
	}

	private void DropPlayerBody()
	{
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null)
		{
			inSpecialAnimationWithPlayer.inSpecialInteractAnimation = false;
			inSpecialAnimationWithPlayer.inSpecialInteractAnimation = false;
			inSpecialAnimationWithPlayer.inAnimationWithEnemy = null;
			inSpecialAnimationWithPlayer = null;
		}
	}

	private void StopKillAnimation()
	{
		if (eatPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(eatPlayerCoroutine);
		}
		inEatingPlayerAnimation = false;
		inSpecialAnimation = false;
		DropPlayerBody();
		creatureVoice.Stop();
	}

	private void ReactToNoise(float distanceToNoise, Vector3 noisePosition)
	{
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		if (currentBehaviourStateIndex == 1)
		{
			if (chasingPlayerInLOS && distanceToNoise - Vector3.Distance(((Component)this).transform.position, ((Component)chasingPlayer).transform.position) < -3f)
			{
				stopAndLookTimer = 1f;
				turnCompass.LookAt(noisePosition);
				targetYRot = turnCompass.eulerAngles.y;
			}
			else if (distanceToNoise < 15f && noticePlayerTimer > 3f)
			{
				stopAndLookTimer = 2f;
				turnCompass.LookAt(noisePosition);
				targetYRot = turnCompass.eulerAngles.y;
			}
		}
		else
		{
			stopAndLookTimer = 1.5f;
			turnCompass.LookAt(noisePosition);
			targetYRot = turnCompass.eulerAngles.y;
			timeSpentStaring += 0.3f;
			if (timeSpentStaring > 3f)
			{
				investigating = true;
				hasBegunInvestigating = false;
				investigatePosition = RoundManager.Instance.GetNavMeshPosition(noisePosition);
			}
		}
	}

	[ServerRpc]
	public void DetectPlayerVoiceServerRpc(Vector3 noisePosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1714423781u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref noisePosition);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1714423781u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			float distanceToNoise = Vector3.Distance(noisePosition, ((Component)this).transform.position);
			ReactToNoise(distanceToNoise, noisePosition);
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ForestGiantAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(344062384u, new RpcReceiveHandler(__rpc_handler_344062384));
		NetworkManager.__rpc_func_table.Add(1296181132u, new RpcReceiveHandler(__rpc_handler_1296181132));
		NetworkManager.__rpc_func_table.Add(3295708237u, new RpcReceiveHandler(__rpc_handler_3295708237));
		NetworkManager.__rpc_func_table.Add(2685047264u, new RpcReceiveHandler(__rpc_handler_2685047264));
		NetworkManager.__rpc_func_table.Add(2965927486u, new RpcReceiveHandler(__rpc_handler_2965927486));
		NetworkManager.__rpc_func_table.Add(3924255731u, new RpcReceiveHandler(__rpc_handler_3924255731));
		NetworkManager.__rpc_func_table.Add(1714423781u, new RpcReceiveHandler(__rpc_handler_1714423781));
	}

	private static void __rpc_handler_344062384(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ForestGiantAI)(object)target).BeginChasingNewPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1296181132(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ForestGiantAI)(object)target).BeginChasingNewPlayerClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3295708237(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ForestGiantAI)(object)target).HasLostPlayerInChaseClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2685047264(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ForestGiantAI)(object)target).HasFoundPlayerInChaseClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2965927486(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ForestGiantAI)(object)target).GrabPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3924255731(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			Vector3 enemyPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref enemyPosition);
			int enemyYRot = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref enemyYRot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ForestGiantAI)(object)target).GrabPlayerClientRpc(playerId, enemyPosition, enemyYRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1714423781(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 noisePosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref noisePosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ForestGiantAI)(object)target).DetectPlayerVoiceServerRpc(noisePosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ForestGiantAI";
	}
}
