using GameNetcodeStuff;
using UnityEngine;

public class QuicksandTrigger : MonoBehaviour
{
	public bool isWater;

	public bool isInsideWater;

	public int audioClipIndex;

	[Space(5f)]
	public bool sinkingLocalPlayer;

	public float movementHinderance = 1.6f;

	public float sinkingSpeedMultiplier = 0.15f;

	private void OnTriggerStay(Collider other)
	{
		if (isWater)
		{
			if (!((Component)other).gameObject.CompareTag("Player"))
			{
				return;
			}
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)(object)GameNetworkManager.Instance.localPlayerController && (Object)(object)component != (Object)null && (Object)(object)component.underwaterCollider != (Object)(object)this)
			{
				component.underwaterCollider = ((Component)this).gameObject.GetComponent<Collider>();
				return;
			}
		}
		if (!isWater && !((Component)other).gameObject.CompareTag("Player"))
		{
			return;
		}
		PlayerControllerB component2 = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
		if ((Object)(object)component2 != (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			return;
		}
		if ((isWater && component2.isInsideFactory != isInsideWater) || component2.isInElevator)
		{
			if (sinkingLocalPlayer)
			{
				StopSinkingLocalPlayer(component2);
			}
			return;
		}
		if (isWater && !component2.isUnderwater)
		{
			component2.underwaterCollider = ((Component)this).gameObject.GetComponent<Collider>();
			component2.isUnderwater = true;
		}
		component2.statusEffectAudioIndex = audioClipIndex;
		if (component2.isSinking)
		{
			return;
		}
		if (sinkingLocalPlayer)
		{
			if (!component2.CheckConditionsForSinkingInQuicksand())
			{
				StopSinkingLocalPlayer(component2);
			}
		}
		else if (component2.CheckConditionsForSinkingInQuicksand())
		{
			Debug.Log((object)"Set local player to sinking!");
			sinkingLocalPlayer = true;
			component2.sourcesCausingSinking++;
			component2.isMovementHindered++;
			component2.hinderedMultiplier *= movementHinderance;
			if (isWater)
			{
				component2.sinkingSpeedMultiplier = 0f;
			}
			else
			{
				component2.sinkingSpeedMultiplier = sinkingSpeedMultiplier;
			}
		}
	}

	private void OnTriggerExit(Collider other)
	{
		OnExit(other);
	}

	public void OnExit(Collider other)
	{
		if (!sinkingLocalPlayer)
		{
			if (isWater)
			{
				if (!((Component)other).CompareTag("Player") || (Object)(object)((Component)other).gameObject.GetComponent<PlayerControllerB>() == (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					return;
				}
				((Component)other).gameObject.GetComponent<PlayerControllerB>().isUnderwater = false;
			}
			Debug.Log((object)"Quicksand is not sinking local player!");
			return;
		}
		Debug.Log((object)"Quicksand is sinking local player!");
		if (((Component)other).CompareTag("Player"))
		{
			Debug.Log((object)"Quicksand is sinking local player! B");
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if (!((Object)(object)component != (Object)(object)GameNetworkManager.Instance.localPlayerController))
			{
				Debug.Log((object)"Quicksand is sinking local player! C");
				StopSinkingLocalPlayer(component);
			}
		}
	}

	public void StopSinkingLocalPlayer(PlayerControllerB playerScript)
	{
		if (sinkingLocalPlayer)
		{
			sinkingLocalPlayer = false;
			playerScript.sourcesCausingSinking = Mathf.Clamp(playerScript.sourcesCausingSinking - 1, 0, 100);
			playerScript.isMovementHindered = Mathf.Clamp(playerScript.isMovementHindered - 1, 0, 100);
			playerScript.hinderedMultiplier = Mathf.Clamp(playerScript.hinderedMultiplier / movementHinderance, 1f, 100f);
			if (playerScript.isMovementHindered == 0 && isWater)
			{
				playerScript.isUnderwater = false;
			}
		}
	}
}
