using UnityEngine;

public class WhoopieCushionItem : GrabbableObject
{
	public AudioSource whoopieCushionAudio;

	public AudioClip[] fartAudios;

	private float fartDebounce;

	private Vector3 lastPositionAtFart;

	private int timesPlayingInOneSpot;

	public void Fart()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(lastPositionAtFart, ((Component)this).transform.position) > 2f)
		{
			timesPlayingInOneSpot = 0;
		}
		timesPlayingInOneSpot++;
		lastPositionAtFart = ((Component)this).transform.position;
		RoundManager.PlayRandomClip(whoopieCushionAudio, fartAudios, randomize: true, 1f, -1);
		RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 8f, 0.8f, timesPlayingInOneSpot, isInShipRoom && StartOfRound.Instance.hangarDoorsClosed, 101158);
	}

	public override void ActivatePhysicsTrigger(Collider other)
	{
		if (Time.realtimeSinceStartup - fartDebounce > 0.2f)
		{
			fartDebounce = Time.realtimeSinceStartup;
			Fart();
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "WhoopieCushionItem";
	}
}
