using Unity.Netcode;
using UnityEngine;

public class ClipboardItem : GrabbableObject
{
	public bool truckManual;

	private bool parentedToTruck;

	public int currentPage = 1;

	public Animator clipboardAnimator;

	public AudioClip[] turnPageSFX;

	public AudioSource thisAudio;

	public override void Update()
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (parentedToTruck)
		{
			return;
		}
		if (StartOfRound.Instance.inShipPhase)
		{
			parentedToTruck = true;
			return;
		}
		VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
		if ((Object)(object)vehicleController != (Object)null)
		{
			parentedToTruck = true;
			parentObject = null;
			((Component)this).transform.SetParent(((Component)vehicleController).transform, true);
			fallTime = 0f;
			((Component)this).transform.localScale = originalScale;
			Vector3 localPosition = vehicleController.clipboardPosition.localPosition;
			targetFloorPosition = localPosition;
		}
	}

	public override void PocketItem()
	{
		if (((NetworkBehaviour)this).IsOwner && (Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.equippedUsableItemQE = false;
			isBeingUsed = false;
		}
		base.PocketItem();
	}

	public override void ItemInteractLeftRight(bool right)
	{
		int num = currentPage;
		RequireCooldown();
		if (right)
		{
			currentPage = Mathf.Clamp(currentPage + 1, 1, 4);
		}
		else
		{
			currentPage = Mathf.Clamp(currentPage - 1, 1, 4);
		}
		if (currentPage != num)
		{
			RoundManager.PlayRandomClip(thisAudio, turnPageSFX);
		}
		clipboardAnimator.SetInteger("page", currentPage);
	}

	public override void DiscardItem()
	{
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.equippedUsableItemQE = false;
		}
		isBeingUsed = false;
		base.DiscardItem();
	}

	public override void EquipItem()
	{
		base.EquipItem();
		playerHeldBy.equippedUsableItemQE = true;
		if (((NetworkBehaviour)this).IsOwner)
		{
			HUDManager.Instance.DisplayTip("To read the manual:", "Press Z to inspect closely. Press Q and E to flip the pages.", isWarning: false, useSave: true, "LCTip_UseManual");
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "ClipboardItem";
	}
}
