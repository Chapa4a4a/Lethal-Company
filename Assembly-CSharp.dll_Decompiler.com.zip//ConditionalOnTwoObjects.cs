using UnityEngine;

public class ConditionalOnTwoObjects : MonoBehaviour
{
	public GameObject conditionA;

	public GameObject conditionB;

	private void Start()
	{
		if ((Object)(object)conditionA == (Object)null && (Object)(object)conditionB == (Object)null)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
		else
		{
			Object.Destroy((Object)(object)this);
		}
	}
}
