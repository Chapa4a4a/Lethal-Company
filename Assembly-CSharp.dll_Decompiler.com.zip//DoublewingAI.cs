using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class DoublewingAI : EnemyAI
{
	public Animator bodyAnimator;

	private int behaviourStateLastFrame = -1;

	public AudioSource flappingAudio;

	public AudioClip[] birdScreechSFX;

	public AudioClip birdHitGroundSFX;

	public AISearchRoutine roamGlide;

	private bool alertingBird;

	private float glideTime = 10f;

	private float currentGlideTime;

	private RaycastHit hit;

	private bool flyingToOtherBirdLanding;

	private float avoidingPlayer;

	public Transform Body;

	private Vector3 previousPosition;

	private float flyLayerWeight;

	[Space(5f)]
	public float maxSpeed;

	[Space(5f)]
	public float speedElevationMultiplier;

	private float randomYRot;

	private int velocityAverageCount;

	private float averageVelocity;

	private float lerpedElevation;

	private float timeSinceEnteringFlight;

	private float randomHeightOffset;

	private bool birdStunned;

	private bool oddInterval;

	private int birdNoisiness = 5;

	private float timeSinceSquawking;

	private float velocityInterval;

	public Rigidbody birdRigidbody;

	private int timesSyncingPosition;

	public override void Start()
	{
		base.Start();
		creatureAnimator.SetInteger("idleType", Random.Range(0, 2));
		creatureAnimator.SetFloat("speedMultiplier", Random.Range(0.73f, 1.3f));
		bodyAnimator.SetFloat("speedMultiplier", Random.Range(0.8f, 1.2f));
		randomHeightOffset = (float)new Random(StartOfRound.Instance.randomMapSeed / (int)(((NetworkBehaviour)this).NetworkObjectId + 1)).NextDouble();
	}

	public override void DaytimeEnemyLeave()
	{
		base.DaytimeEnemyLeave();
		if (stunNormalizedTimer < 0f && !isEnemyDead)
		{
			bodyAnimator.SetBool("flying", true);
			creatureAnimator.SetBool("gliding", true);
			bodyAnimator.SetTrigger("Leave");
			bodyAnimator.SetBool("Leaving", true);
		}
		((MonoBehaviour)this).StartCoroutine(flyAwayThenDespawn());
	}

	private IEnumerator flyAwayThenDespawn()
	{
		yield return (object)new WaitForSeconds(7f);
		if (((NetworkBehaviour)this).IsOwner)
		{
			KillEnemyOnOwnerClient(overrideDestroy: true);
		}
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesPlayedInOneSpot, noiseID);
		if (noiseID != 911 && !isEnemyDead && !(stunNormalizedTimer > 0f))
		{
			float num = Vector3.Distance(noisePosition, ((Component)this).transform.position + Vector3.up * 0.5f);
			if (Physics.Linecast(((Component)this).transform.position, noisePosition, 256))
			{
				noiseLoudness /= 2f;
			}
			float num2 = 0.01f;
			if (!(noiseLoudness / num <= num2) && currentBehaviourStateIndex == 0 && !alertingBird)
			{
				alertingBird = true;
				AlertBirdServerRpc();
			}
		}
	}

	public void StunBird()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (birdStunned)
		{
			return;
		}
		birdStunned = true;
		agent.speed = 0f;
		DoublewingAI[] array = Object.FindObjectsByType<DoublewingAI>((FindObjectsInactive)0, (FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if (!((Object)(object)array[i] == (Object)(object)this) && Vector3.Distance(((Component)array[i]).transform.position, ((Component)this).transform.position) < 8f)
			{
				array[i].AlertBirdByOther();
			}
		}
		flappingAudio.Stop();
		creatureAnimator.SetBool("stunned", true);
		bodyAnimator.SetBool("stunned", true);
	}

	public void UnstunBird()
	{
		if (birdStunned)
		{
			birdStunned = false;
			creatureAnimator.SetBool("stunned", false);
			bodyAnimator.SetBool("stunned", false);
			if (currentBehaviourStateIndex == 0)
			{
				SwitchToBehaviourStateOnLocalClient(1);
			}
		}
	}

	public override void DoAIInterval()
	{
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0321: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (daytimeEnemyLeaving || isEnemyDead || StartOfRound.Instance.allPlayersDead || stunNormalizedTimer > 0f)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			oddInterval = !oddInterval;
			if (oddInterval && !alertingBird && Object.op_Implicit((Object)(object)CheckLineOfSightForPlayer(80f, 8, 4)))
			{
				alertingBird = true;
				AlertBirdServerRpc();
			}
			break;
		case 1:
		{
			behaviourStateLastFrame = 1;
			creatureAnimator.SetBool("gliding", true);
			bodyAnimator.SetBool("flying", true);
			agent.speed = Mathf.Clamp(agent.speed + AIIntervalTime * 4f, 5f, 19f);
			if (!flyingToOtherBirdLanding && avoidingPlayer <= 0f && !roamGlide.inProgress)
			{
				StartSearch(((Component)this).transform.position, roamGlide);
			}
			if (avoidingPlayer > 0f)
			{
				avoidingPlayer -= AIIntervalTime;
				if (Vector3.Distance(((Component)this).transform.position, destination) < 3f)
				{
					avoidingPlayer = 0f;
				}
				break;
			}
			PlayerControllerB playerControllerB = CheckLineOfSightForPlayer(80f, 10, 8);
			if (oddInterval && Object.op_Implicit((Object)(object)playerControllerB))
			{
				Transform val = ChooseFarthestNodeFromPosition(((Component)playerControllerB).transform.position, avoidLineOfSight: false, Random.Range(0, allAINodes.Length / 2));
				if (SetDestinationToPosition(val.position))
				{
					avoidingPlayer = Random.Range(10, 20);
					StopSearch(roamGlide);
				}
			}
			currentGlideTime += AIIntervalTime;
			if (!(currentGlideTime > glideTime))
			{
				break;
			}
			currentGlideTime = 0f;
			if (flyingToOtherBirdLanding)
			{
				if (!SetDestinationToPosition(destination, checkForPath: true))
				{
					flyingToOtherBirdLanding = false;
					glideTime = 5f;
					break;
				}
				if (Vector3.Distance(((Component)this).transform.position, destination) < 3f)
				{
					if (!TryLanding())
					{
						flyingToOtherBirdLanding = false;
						glideTime = 5f;
					}
					else
					{
						SwitchToBehaviourState(0);
					}
					break;
				}
			}
			for (int i = 0; i < RoundManager.Instance.SpawnedEnemies.Count; i++)
			{
				if ((Object)(object)RoundManager.Instance.SpawnedEnemies[i].enemyType == (Object)(object)enemyType && RoundManager.Instance.SpawnedEnemies[i].currentBehaviourStateIndex == 0 && Vector3.Distance(((Component)this).transform.position, ((Component)RoundManager.Instance.SpawnedEnemies[i]).transform.position) < 100f)
				{
					Vector3 randomNavMeshPositionInRadius = RoundManager.Instance.GetRandomNavMeshPositionInRadius(((Component)RoundManager.Instance.SpawnedEnemies[i]).transform.position);
					if (SetDestinationToPosition(randomNavMeshPositionInRadius, checkForPath: true))
					{
						StopSearch(roamGlide);
						flyingToOtherBirdLanding = true;
						glideTime = 2f;
					}
					break;
				}
			}
			if (!flyingToOtherBirdLanding)
			{
				if (TryLanding())
				{
					SwitchToBehaviourState(0);
				}
				else
				{
					glideTime = 10f;
				}
			}
			break;
		}
		}
	}

	public bool TryLanding()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		if (Physics.Raycast(new Vector3(((Component)this).transform.position.x, eye.position.y, ((Component)this).transform.position.z), Vector3.down, ref hit, 60f, StartOfRound.Instance.collidersAndRoomMaskAndDefault))
		{
			if (Physics.CheckSphere(((RaycastHit)(ref hit)).point, 16f, StartOfRound.Instance.playersMask, (QueryTriggerInteraction)1))
			{
				return false;
			}
			if (Vector3.Distance(((RaycastHit)(ref hit)).point, ((Component)this).transform.position) > 1f)
			{
				if (SetDestinationToPosition(((RaycastHit)(ref hit)).point, checkForPath: true))
				{
					agent.Warp(destination);
					return true;
				}
				return false;
			}
			return true;
		}
		return false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void AlertBirdServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(838150599u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 838150599u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				AlertBirdClientRpc();
			}
		}
	}

	[ClientRpc]
	public void AlertBirdClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3264241129u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3264241129u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				AlertBird();
			}
		}
	}

	public void AlertBird()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		DoublewingAI[] array = Object.FindObjectsByType<DoublewingAI>((FindObjectsInactive)0, (FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if (!((Object)(object)array[i] == (Object)(object)this) && Vector3.Distance(((Component)array[i]).transform.position, ((Component)this).transform.position) < 8f)
			{
				array[i].AlertBirdByOther();
			}
		}
		SwitchToBehaviourStateOnLocalClient(1);
		alertingBird = false;
	}

	public void AlertBirdByOther()
	{
		if (!daytimeEnemyLeaving)
		{
			if (((NetworkBehaviour)this).IsServer)
			{
				SwitchToBehaviourState(1);
			}
			else
			{
				SwitchToBehaviourStateOnLocalClient(1);
			}
		}
	}

	public override void Update()
	{
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		SetFlyDirection();
		if (daytimeEnemyLeaving)
		{
			return;
		}
		timeSinceSquawking += Time.deltaTime;
		if (stunNormalizedTimer > 0f)
		{
			StunBird();
		}
		else
		{
			UnstunBird();
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (behaviourStateLastFrame != 0)
			{
				behaviourStateLastFrame = 0;
				randomYRot = Random.Range(0f, 360f);
				agent.speed = 0f;
				creatureAnimator.SetBool("gliding", false);
				bodyAnimator.SetBool("flying", false);
				flyingToOtherBirdLanding = false;
				timeSinceEnteringFlight = 0f;
			}
			flyLayerWeight = Mathf.Max(0f, flyLayerWeight - Time.deltaTime * 0.28f);
			timeSinceEnteringFlight += Time.deltaTime;
			break;
		case 1:
			if (behaviourStateLastFrame != 1)
			{
				behaviourStateLastFrame = 1;
				timeSinceEnteringFlight = 0f;
				creatureAnimator.SetBool("gliding", true);
				bodyAnimator.SetBool("flying", true);
				int num = RoundManager.PlayRandomClip(creatureSFX, enemyType.audioClips);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[num], 0.7f);
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 12f, 0.6f, 0, noiseIsInsideClosedShip: false, 911);
				glideTime = Random.Range(8f, 20f);
			}
			timeSinceEnteringFlight += Time.deltaTime;
			flyLayerWeight = Mathf.Min(1f, flyLayerWeight + Time.deltaTime * 0.33f);
			break;
		}
	}

	private void BirdScreech()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		RoundManager.PlayRandomClip(creatureVoice, birdScreechSFX);
		WalkieTalkie.TransmitOneShotAudio(creatureVoice, birdScreechSFX[Random.Range(0, birdScreechSFX.Length)]);
		RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 12f, 0.6f, 0, noiseIsInsideClosedShip: false, 911);
	}

	public void SetFlyDirection()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_036b: Unknown result type (might be due to invalid IL or missing references)
		if (birdStunned || isEnemyDead)
		{
			Vector3 localEulerAngles = Body.localEulerAngles;
			localEulerAngles.x = 0f;
			localEulerAngles.z = 0f;
			Body.localEulerAngles = localEulerAngles;
			return;
		}
		bool flag = false;
		flag = averageVelocity * speedElevationMultiplier < 12f;
		Vector3 val = Body.position - previousPosition;
		float num = ((Vector3)(ref val)).magnitude / Time.deltaTime;
		if (daytimeEnemyLeaving)
		{
			val = Body.position - previousPosition;
			if (((Vector3)(ref val)).sqrMagnitude >= 0f)
			{
				Body.rotation = Quaternion.Lerp(Body.rotation, Quaternion.LookRotation(Body.position - previousPosition, Vector3.up), 5f * Time.deltaTime);
			}
		}
		else if (currentBehaviourStateIndex == 0 || timeSinceEnteringFlight < 1f)
		{
			flag = false;
			Body.rotation = Quaternion.Lerp(Body.rotation, Quaternion.Euler(new Vector3(0f, randomYRot, 0f)), 10f * Time.deltaTime);
		}
		else if (averageVelocity * speedElevationMultiplier > 0f && Body.position - previousPosition != Vector3.zero)
		{
			Body.rotation = Quaternion.Lerp(Body.rotation, Quaternion.LookRotation(Body.position - previousPosition, Vector3.up), 5f * Time.deltaTime);
		}
		if (velocityInterval <= 0f)
		{
			velocityInterval = 0.1f;
			velocityAverageCount++;
			if (velocityAverageCount > 5)
			{
				averageVelocity += (num - averageVelocity) / 6f;
			}
			else
			{
				averageVelocity += num;
				if (velocityAverageCount == 5)
				{
					averageVelocity /= velocityAverageCount;
				}
			}
		}
		else
		{
			velocityInterval -= Time.deltaTime;
		}
		creatureAnimator.SetBool("flapping", flag);
		if (flag)
		{
			if (flappingAudio.volume <= 0.99f)
			{
				flappingAudio.volume = Mathf.Min(flappingAudio.volume + Time.deltaTime, 1f);
			}
			if (!flappingAudio.isPlaying)
			{
				flappingAudio.Play();
			}
		}
		else if (flappingAudio.volume >= 0.05f)
		{
			flappingAudio.volume = Mathf.Max(flappingAudio.volume - Time.deltaTime, 0f);
		}
		else
		{
			flappingAudio.Stop();
		}
		lerpedElevation = Mathf.Lerp(lerpedElevation, averageVelocity * speedElevationMultiplier / maxSpeed, Time.deltaTime * 0.5f);
		bodyAnimator.SetFloat("elevation", Mathf.Clamp(lerpedElevation * randomHeightOffset, 0.02f, 0.98f));
		previousPosition = Body.position;
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (((NetworkBehaviour)this).IsOwner)
		{
			KillEnemyOnOwnerClient();
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		base.KillEnemy(destroy);
		bodyAnimator.SetBool("stunned", true);
		creatureAnimator.SetBool("dead", true);
	}

	public override void AnimationEventA()
	{
		base.AnimationEventA();
		if (((NetworkBehaviour)this).IsServer && timeSinceSquawking > 0.7f && Random.Range(0, 100) < birdNoisiness)
		{
			timeSinceSquawking = 0f;
			BirdScreechClientRpc();
		}
	}

	[ClientRpc(/*Could not decode attribute arguments.*/)]
	public void BirdScreechClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2325720037u, val, (RpcDelivery)1);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2325720037u, val, (RpcDelivery)1);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				BirdScreech();
			}
		}
	}

	public override void AnimationEventB()
	{
		base.AnimationEventB();
		creatureSFX.PlayOneShot(birdHitGroundSFX);
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_DoublewingAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(838150599u, new RpcReceiveHandler(__rpc_handler_838150599));
		NetworkManager.__rpc_func_table.Add(3264241129u, new RpcReceiveHandler(__rpc_handler_3264241129));
		NetworkManager.__rpc_func_table.Add(2325720037u, new RpcReceiveHandler(__rpc_handler_2325720037));
	}

	private static void __rpc_handler_838150599(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((DoublewingAI)(object)target).AlertBirdServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3264241129(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DoublewingAI)(object)target).AlertBirdClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2325720037(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DoublewingAI)(object)target).BirdScreechClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "DoublewingAI";
	}
}
