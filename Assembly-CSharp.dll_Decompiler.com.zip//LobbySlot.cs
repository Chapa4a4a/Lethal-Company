using Steamworks;
using Steamworks.Data;
using TMPro;
using UnityEngine;

public class LobbySlot : MonoBehaviour
{
	public MenuManager menuScript;

	public TextMeshProUGUI LobbyName;

	public TextMeshProUGUI playerCount;

	public SteamId lobbyId;

	public Lobby thisLobby;

	private static Coroutine timeOutLobbyRefreshCoroutine;

	private void Awake()
	{
		menuScript = Object.FindObjectOfType<MenuManager>();
	}

	public void JoinButton()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		if (!GameNetworkManager.Instance.waitingForLobbyDataRefresh)
		{
			JoinLobbyAfterVerifying(thisLobby, lobbyId);
		}
	}

	public static void JoinLobbyAfterVerifying(Lobby lobby, SteamId lobbyId)
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (GameNetworkManager.Instance.waitingForLobbyDataRefresh)
		{
			return;
		}
		MenuManager menuManager = Object.FindObjectOfType<MenuManager>();
		if (!((Object)(object)menuManager == (Object)null))
		{
			menuManager.serverListUIContainer.SetActive(false);
			menuManager.menuButtons.SetActive(true);
			Debug.Log((object)$"Lobby id joining: {lobbyId}");
			SteamMatchmaking.OnLobbyDataChanged += OnLobbyDataRefresh;
			GameNetworkManager.Instance.waitingForLobbyDataRefresh = true;
			Debug.Log((object)"refreshing lobby...");
			if (((Lobby)(ref lobby)).Refresh())
			{
				timeOutLobbyRefreshCoroutine = ((MonoBehaviour)GameNetworkManager.Instance).StartCoroutine(GameNetworkManager.Instance.TimeOutLobbyRefresh());
				Debug.Log((object)"Waiting for lobby data refresh");
				Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: true, (RoomEnter)5);
			}
			else
			{
				Debug.Log((object)"Could not refresh lobby");
				SteamMatchmaking.OnLobbyDataChanged -= OnLobbyDataRefresh;
				Object.FindObjectOfType<MenuManager>().SetLoadingScreen(isLoading: false, (RoomEnter)5, "Error! Could not get the lobby data. Are you offline?");
			}
		}
	}

	public static void OnLobbyDataRefresh(Lobby lobby)
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		if (timeOutLobbyRefreshCoroutine != null)
		{
			((MonoBehaviour)GameNetworkManager.Instance).StopCoroutine(timeOutLobbyRefreshCoroutine);
			timeOutLobbyRefreshCoroutine = null;
		}
		if (!GameNetworkManager.Instance.waitingForLobbyDataRefresh)
		{
			Debug.Log((object)"Not waiting for lobby data refresh; returned");
			return;
		}
		GameNetworkManager.Instance.waitingForLobbyDataRefresh = false;
		SteamMatchmaking.OnLobbyDataChanged -= OnLobbyDataRefresh;
		Debug.Log((object)$"Got lobby data refresh!; {((Lobby)(ref lobby)).Id}");
		Debug.Log((object)$"Members in lobby: {((Lobby)(ref lobby)).MemberCount}");
		if (GameNetworkManager.Instance.LobbyDataIsJoinable(lobby))
		{
			GameNetworkManager.Instance.JoinLobby(lobby, ((Lobby)(ref lobby)).Id);
		}
	}

	private void Update()
	{
	}
}
