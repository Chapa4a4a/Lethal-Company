using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Animations.Rigging;

public class MouthDogAI : EnemyAI, INoiseListener, IVisibleThreat
{
	public float noiseApproximation = 14f;

	public int suspicionLevel;

	private Vector3 previousPosition;

	public DampedTransform neckDampedTransform;

	private RoundManager roundManager;

	private float AITimer;

	private List<GameObject> allAINodesWithinRange = new List<GameObject>();

	private bool hasEnteredChaseModeFully;

	private bool startedChaseModeCoroutine;

	public AudioClip screamSFX;

	public AudioClip breathingSFX;

	public AudioClip killPlayerSFX;

	private float hearNoiseCooldown;

	private bool inLunge;

	private float lungeCooldown;

	private bool inKillAnimation;

	public Transform mouthGrip;

	public bool endingLunge;

	private Ray ray;

	private RaycastHit rayHit;

	private Vector3 lastHeardNoisePosition;

	private Vector3 noisePositionGuess;

	private float lastHeardNoiseDistanceWhenHeard;

	private bool heardOtherHowl;

	private DeadBodyInfo carryingBody;

	private Random enemyRandom;

	private Coroutine killPlayerCoroutine;

	private const int suspicionThreshold = 5;

	private const int alertThreshold = 9;

	private const int maxSuspicionLevel = 11;

	public AISearchRoutine roamPlanet;

	private Collider debugCollider;

	private float timeSinceHittingOtherEnemy;

	private float coweringMeter;

	private bool coweringOnFloor;

	private bool coweringOnFloorDebounce;

	ThreatType IVisibleThreat.type => ThreatType.EyelessDog;

	bool IVisibleThreat.IsThreatDead()
	{
		return isEnemyDead;
	}

	GrabbableObject IVisibleThreat.GetHeldObject()
	{
		return null;
	}

	int IVisibleThreat.SendSpecialBehaviour(int id)
	{
		return 0;
	}

	int IVisibleThreat.GetThreatLevel(Vector3 seenByPosition)
	{
		int num = 0;
		num = ((enemyHP >= 2) ? 5 : 3);
		if (creatureAnimator.GetBool("StartedChase"))
		{
			num += 3;
		}
		return num;
	}

	int IVisibleThreat.GetInterestLevel()
	{
		return 0;
	}

	Transform IVisibleThreat.GetThreatLookTransform()
	{
		return eye;
	}

	Transform IVisibleThreat.GetThreatTransform()
	{
		return ((Component)this).transform;
	}

	Vector3 IVisibleThreat.GetThreatVelocity()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			return agent.velocity;
		}
		return Vector3.zero;
	}

	float IVisibleThreat.GetVisibility()
	{
		if (isEnemyDead)
		{
			return 0f;
		}
		if (creatureAnimator.GetBool("StartedChase"))
		{
			return 1f;
		}
		return 0.75f;
	}

	public override void DoAIInterval()
	{
		base.DoAIInterval();
		_ = StartOfRound.Instance.livingPlayers;
	}

	public override void Start()
	{
		base.Start();
		roundManager = Object.FindObjectOfType<RoundManager>();
		useSecondaryAudiosOnAnimatedObjects = true;
		if (Random.Range(0, 10) < 2)
		{
			creatureVoice.pitch = Random.Range(0.6f, 1.3f);
		}
		else
		{
			creatureVoice.pitch = Random.Range(0.9f, 1.1f);
		}
		enemyRandom = new Random(StartOfRound.Instance.randomMapSeed + thisEnemyIndex);
	}

	public override void Update()
	{
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_04eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b9: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead)
		{
			creatureAnimator.SetLayerWeight(1, 0f);
		}
		else
		{
			if (!ventAnimationFinished)
			{
				return;
			}
			if (stunNormalizedTimer > 0f && !isEnemyDead)
			{
				if ((Object)(object)stunnedByPlayer != (Object)null && currentBehaviourStateIndex != 2 && ((NetworkBehaviour)this).IsOwner)
				{
					EnrageDogOnLocalClient(((Component)stunnedByPlayer).transform.position, Vector3.Distance(((Component)this).transform.position, ((Component)stunnedByPlayer).transform.position));
				}
				creatureAnimator.SetLayerWeight(1, 1f);
			}
			else
			{
				creatureAnimator.SetLayerWeight(1, 0f);
			}
			hitsPhysicsObjects = currentBehaviourStateIndex >= 2;
			if (!coweringOnFloor)
			{
				if (!coweringOnFloorDebounce)
				{
					coweringOnFloorDebounce = true;
					creatureAnimator.SetBool("Cower", false);
				}
				if (coweringMeter >= 0f)
				{
					coweringMeter -= Time.deltaTime;
				}
			}
			else
			{
				if (coweringOnFloorDebounce)
				{
					coweringOnFloorDebounce = false;
					creatureAnimator.SetBool("Cower", true);
					creatureAnimator.SetTrigger("StartCowering");
				}
				if (coweringMeter < 0.7f)
				{
					coweringMeter += Time.deltaTime;
				}
			}
			hearNoiseCooldown -= Time.deltaTime;
			timeSinceHittingOtherEnemy += Time.deltaTime;
			Animator obj = creatureAnimator;
			Vector3 val = Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f);
			obj.SetFloat("speedMultiplier", ((Vector3)(ref val)).sqrMagnitude / (Time.deltaTime / 4f));
			previousPosition = ((Component)this).transform.position;
			if (currentBehaviourStateIndex == 2 || currentBehaviourStateIndex == 3)
			{
				if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position, 50f, 25, 10f))
				{
					GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(0.4f, 0.5f);
				}
			}
			else if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position, 50f, 30, 5f))
			{
				GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(0.25f, 0.3f);
			}
			switch (currentBehaviourStateIndex)
			{
			case 0:
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)neckDampedTransform).weight = 1f;
				creatureAnimator.SetInteger("BehaviourState", 0);
				if (((NetworkBehaviour)this).IsOwner)
				{
					agent.speed = 3.5f;
					if (stunNormalizedTimer > 0f || coweringOnFloor)
					{
						agent.speed = 0f;
					}
					if (((NetworkBehaviour)this).IsOwner && !roamPlanet.inProgress)
					{
						StartSearch(((Component)this).transform.position, roamPlanet);
					}
				}
				break;
			case 1:
				if (hasEnteredChaseModeFully)
				{
					hasEnteredChaseModeFully = false;
					creatureVoice.Stop();
					startedChaseModeCoroutine = false;
					creatureAnimator.SetBool("StartedChase", false);
				}
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)neckDampedTransform).weight = Mathf.Lerp(((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)neckDampedTransform).weight, 1f, 8f * Time.deltaTime);
				creatureAnimator.SetInteger("BehaviourState", 1);
				if (!((NetworkBehaviour)this).IsOwner)
				{
					break;
				}
				if (((NetworkBehaviour)this).IsOwner && roamPlanet.inProgress)
				{
					StopSearch(roamPlanet);
				}
				agent.speed = 4.5f;
				if (stunNormalizedTimer > 0f || coweringOnFloor)
				{
					agent.speed = 0f;
				}
				AITimer -= Time.deltaTime;
				if (AITimer <= 0f)
				{
					AITimer = 4f;
					suspicionLevel--;
					if (suspicionLevel <= 1)
					{
						SwitchToBehaviourState(0);
					}
				}
				break;
			case 2:
				if (!hasEnteredChaseModeFully)
				{
					if (!startedChaseModeCoroutine)
					{
						startedChaseModeCoroutine = true;
						((MonoBehaviour)this).StartCoroutine(enterChaseMode());
					}
					break;
				}
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)neckDampedTransform).weight = Mathf.Lerp(((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)neckDampedTransform).weight, 0.2f, 8f * Time.deltaTime);
				creatureAnimator.SetInteger("BehaviourState", 2);
				if (!((NetworkBehaviour)this).IsOwner)
				{
					break;
				}
				if (((NetworkBehaviour)this).IsOwner && roamPlanet.inProgress)
				{
					StopSearch(roamPlanet);
				}
				if (!inLunge)
				{
					lungeCooldown -= Time.deltaTime;
					if (Vector3.Distance(((Component)this).transform.position, noisePositionGuess) < 4f && lungeCooldown <= 0f)
					{
						inLunge = true;
						EnterLunge();
						break;
					}
				}
				agent.speed = Mathf.Clamp(agent.speed + Time.deltaTime, 13f, 18f);
				if (stunNormalizedTimer > 0f || coweringOnFloor)
				{
					agent.speed = 0f;
				}
				AITimer -= Time.deltaTime;
				if (AITimer <= 0f)
				{
					AITimer = 3f;
					suspicionLevel--;
					if (Vector3.Distance(((Component)this).transform.position, agent.destination) < 3f)
					{
						SearchForPreviouslyHeardSound();
					}
					if (suspicionLevel <= 8)
					{
						SwitchToBehaviourState(1);
					}
				}
				break;
			case 3:
				if (((NetworkBehaviour)this).IsOwner)
				{
					NavMeshAgent obj2 = agent;
					obj2.speed -= Time.deltaTime * 5f;
					if (!endingLunge && agent.speed < 1.5f && !inKillAnimation)
					{
						endingLunge = true;
						lungeCooldown = 0.25f;
						EndLungeServerRpc();
					}
				}
				break;
			}
		}
	}

	private void SearchForPreviouslyHeardSound()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		Vector3 val = ((Component)this).transform.position;
		while (num < 5 && Vector3.Distance(val, ((Component)this).transform.position) < 4f)
		{
			num++;
			val = roundManager.GetRandomNavMeshPositionInRadius(lastHeardNoisePosition, lastHeardNoiseDistanceWhenHeard / noiseApproximation);
		}
		SetDestinationToPosition(val);
		noisePositionGuess = val;
	}

	private IEnumerator enterChaseMode()
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			agent.speed = 0.05f;
		}
		DropCarriedBody();
		creatureVoice.PlayOneShot(screamSFX);
		if (!isEnemyDead)
		{
			creatureAnimator.SetTrigger("ChaseHowl");
		}
		if (Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) < 16f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
			GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.5f);
		}
		yield return (object)new WaitForSeconds(0.5f);
		if (!heardOtherHowl)
		{
			CallAllDogsWithHowl();
		}
		heardOtherHowl = false;
		yield return (object)new WaitForSeconds(0.2f);
		if (!isEnemyDead)
		{
			creatureVoice.clip = breathingSFX;
			creatureVoice.Play();
			creatureAnimator.SetBool("StartedChase", true);
			hasEnteredChaseModeFully = true;
			creatureVoice.PlayOneShot(breathingSFX);
		}
	}

	private void CallAllDogsWithHowl()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		MouthDogAI[] array = Object.FindObjectsOfType<MouthDogAI>();
		for (int i = 0; i < array.Length; i++)
		{
			if (!((Object)(object)array[i] == (Object)(object)this))
			{
				array[i].ReactToOtherDogHowl(((Component)this).transform.position);
			}
		}
	}

	public void ReactToOtherDogHowl(Vector3 howlPosition)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		heardOtherHowl = true;
		lastHeardNoiseDistanceWhenHeard = Vector3.Distance(((Component)this).transform.position, howlPosition);
		noisePositionGuess = roundManager.GetRandomNavMeshPositionInRadius(howlPosition, lastHeardNoiseDistanceWhenHeard / noiseApproximation);
		SetDestinationToPosition(noisePositionGuess);
		if (currentBehaviourStateIndex < 2)
		{
			SwitchToBehaviourStateOnLocalClient(2);
		}
		suspicionLevel = 8;
		lastHeardNoisePosition = howlPosition;
		Debug.Log((object)$"Setting lastHeardNoisePosition to {howlPosition}");
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesNoisePlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesNoisePlayedInOneSpot, noiseID);
		if (stunNormalizedTimer > 0f || noiseID == 675189 || noiseID == 7 || noiseID == 546 || inKillAnimation || hearNoiseCooldown >= 0f || timesNoisePlayedInOneSpot > 15)
		{
			return;
		}
		hearNoiseCooldown = 0.03f;
		float num = Vector3.Distance(((Component)this).transform.position, noisePosition);
		Debug.Log((object)$"dog '{((Object)((Component)this).gameObject).name}': Heard noise! Distance: {num} meters");
		float num2 = 18f * noiseLoudness;
		if (Physics.Linecast(((Component)this).transform.position, noisePosition, 256))
		{
			noiseLoudness /= 2f;
			num2 /= 2f;
		}
		if (noiseLoudness < 0.25f)
		{
			return;
		}
		if (currentBehaviourStateIndex < 2 && num < num2)
		{
			suspicionLevel = 9;
		}
		else
		{
			suspicionLevel++;
		}
		bool fullyEnrage = false;
		if (suspicionLevel >= 9)
		{
			if (currentBehaviourStateIndex < 2)
			{
				fullyEnrage = true;
			}
		}
		else if (suspicionLevel >= 5 && currentBehaviourStateIndex == 0)
		{
			fullyEnrage = false;
		}
		AITimer = 3f;
		EnrageDogOnLocalClient(noisePosition, num, approximatePosition: true, fullyEnrage);
	}

	private void EnrageDogOnLocalClient(Vector3 targetPosition, float distanceToNoise, bool approximatePosition = true, bool fullyEnrage = false)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"Mouth dog targetPos 1: {targetPosition}; distanceToNoise: {distanceToNoise}");
		if (approximatePosition)
		{
			targetPosition = roundManager.GetRandomNavMeshPositionInRadius(targetPosition, distanceToNoise / noiseApproximation);
		}
		noisePositionGuess = targetPosition;
		Debug.Log((object)$"Mouth dog targetPos 2: {targetPosition}");
		if (fullyEnrage)
		{
			if (currentBehaviourStateIndex < 2)
			{
				SwitchToBehaviourState(2);
				hearNoiseCooldown = 1f;
				suspicionLevel = 12;
			}
			suspicionLevel = Mathf.Clamp(suspicionLevel, 0, 11);
		}
		else if (currentBehaviourStateIndex == 0)
		{
			SwitchToBehaviourState(1);
		}
		if (!((NetworkBehaviour)this).IsOwner)
		{
			ChangeOwnershipOfEnemy(NetworkManager.Singleton.LocalClientId);
		}
		if (!inLunge)
		{
			SetDestinationToPosition(noisePositionGuess);
		}
		lastHeardNoiseDistanceWhenHeard = distanceToNoise;
		lastHeardNoisePosition = targetPosition;
		Debug.Log((object)$"Dog lastheardnoisePosition: {lastHeardNoisePosition}");
	}

	private void EnterLunge()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner)
		{
			ChangeOwnershipOfEnemy(NetworkManager.Singleton.LocalClientId);
		}
		SwitchToBehaviourState(3);
		endingLunge = false;
		ray = new Ray(((Component)this).transform.position + Vector3.up, ((Component)this).transform.forward);
		Vector3 pos = ((!Physics.Raycast(ray, ref rayHit, 17f, StartOfRound.Instance.collidersAndRoomMask)) ? ((Ray)(ref ray)).GetPoint(17f) : ((RaycastHit)(ref rayHit)).point);
		pos = roundManager.GetNavMeshPosition(pos);
		SetDestinationToPosition(pos);
		agent.speed = 13f;
	}

	[ServerRpc(RequireOwnership = false)]
	public void EndLungeServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(43708451u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 43708451u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				EndLungeClientRpc();
			}
		}
	}

	[ClientRpc]
	public void EndLungeClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4130373844u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4130373844u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			SwitchToBehaviourStateOnLocalClient(2);
			if (!isEnemyDead)
			{
				creatureAnimator.SetTrigger("EndLungeNoKill");
			}
			inLunge = false;
			Debug.Log((object)"Ending lunge");
		}
	}

	private void ChaseLocalPlayer()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		SwitchToBehaviourState(2);
		ChangeOwnershipOfEnemy(NetworkManager.Singleton.LocalClientId);
		SetDestinationToPosition(((Component)GameNetworkManager.Instance.localPlayerController).transform.position);
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		enemyHP -= force;
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (enemyHP <= 0)
			{
				KillEnemyOnOwnerClient();
				return;
			}
			if (inKillAnimation)
			{
				StopKillAnimationServerRpc();
			}
		}
		if ((Object)(object)playerWhoHit != (Object)null && currentBehaviourStateIndex != 2 && ((NetworkBehaviour)this).IsOwner)
		{
			EnrageDogOnLocalClient(((Component)playerWhoHit).transform.position, Vector3.Distance(((Component)this).transform.position, ((Component)playerWhoHit).transform.position));
		}
	}

	public override void OnCollideWithEnemy(Collider other, EnemyAI collidedEnemy = null)
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithEnemy(other, collidedEnemy);
		if (!((Object)(object)collidedEnemy.enemyType == (Object)(object)enemyType) && !(timeSinceHittingOtherEnemy < 1f))
		{
			if (currentBehaviourStateIndex == 2 && !inLunge)
			{
				((Component)this).transform.LookAt(((Component)other).transform.position);
				((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
				inLunge = true;
				EnterLunge();
			}
			timeSinceHittingOtherEnemy = 0f;
			collidedEnemy.HitEnemy(2, null, playHitSFX: true);
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other, inKillAnimation);
		if (!((Object)(object)playerControllerB != (Object)null))
		{
			return;
		}
		VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
		bool num = (Object)(object)vehicleController != (Object)null && (Object)(object)playerControllerB.physicsParent != (Object)null && (Object)(object)playerControllerB.physicsParent == (Object)(object)((Component)vehicleController).transform && !vehicleController.backDoorOpen;
		bool flag = StartOfRound.Instance.hangarDoorsClosed && isInsidePlayerShip != playerControllerB.isInHangarShipRoom;
		if (num || flag)
		{
			return;
		}
		Vector3 val = Vector3.Normalize((((Component)this).transform.position + Vector3.up - ((Component)playerControllerB.gameplayCamera).transform.position) * 100f);
		RaycastHit val2 = default(RaycastHit);
		if (Physics.Linecast(((Component)this).transform.position + Vector3.up + val * 0.5f, ((Component)playerControllerB.gameplayCamera).transform.position, ref val2, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
		{
			if (!((Object)(object)((RaycastHit)(ref val2)).collider == (Object)(object)debugCollider))
			{
				debugCollider = ((RaycastHit)(ref val2)).collider;
			}
		}
		else if (!playerControllerB.inVehicleAnimation || !(Vector3.Distance(((Component)this).transform.position, ((Component)playerControllerB).transform.position) > 3f))
		{
			if (currentBehaviourStateIndex == 3)
			{
				playerControllerB.inAnimationWithEnemy = this;
				KillPlayerServerRpc((int)playerControllerB.playerClientId);
			}
			else if (currentBehaviourStateIndex == 0 || currentBehaviourStateIndex == 1)
			{
				ChaseLocalPlayer();
			}
			else if (currentBehaviourStateIndex == 2 && !inLunge)
			{
				((Component)this).transform.LookAt(((Component)other).transform.position);
				((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
				inLunge = true;
				EnterLunge();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KillPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(998670557u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 998670557u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (!inKillAnimation)
			{
				inKillAnimation = true;
				KillPlayerClientRpc(playerId);
			}
			else
			{
				CancelKillAnimationWithPlayerClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void CancelKillAnimationWithPlayerClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2798326268u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2798326268u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				StartOfRound.Instance.allPlayerScripts[playerObjectId].inAnimationWithEnemy = null;
			}
		}
	}

	[ClientRpc]
	public void KillPlayerClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2252497379u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2252497379u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			Debug.Log((object)"Kill player rpc");
			if (killPlayerCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(killPlayerCoroutine);
			}
			killPlayerCoroutine = ((MonoBehaviour)this).StartCoroutine(KillPlayer(playerId));
		}
	}

	private IEnumerator KillPlayer(int playerId)
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			agent.speed = Mathf.Clamp(agent.speed, 2f, 0f);
		}
		Debug.Log((object)"killing player A");
		creatureVoice.pitch = Random.Range(0.96f, 1.04f);
		creatureVoice.PlayOneShot(killPlayerSFX, 1f);
		PlayerControllerB killPlayer = StartOfRound.Instance.allPlayerScripts[playerId];
		inKillAnimation = true;
		if (!isEnemyDead)
		{
			creatureAnimator.SetTrigger("EndLungeKill");
		}
		Debug.Log((object)"killing player B");
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)killPlayer)
		{
			killPlayer.KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Mauling);
		}
		float startTime = Time.timeSinceLevelLoad;
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)killPlayer.deadBody != (Object)null || Time.timeSinceLevelLoad - startTime > 2f));
		if ((Object)(object)killPlayer.deadBody == (Object)null)
		{
			Debug.Log((object)"Giant dog: Player body was not spawned or found within 2 seconds.");
			killPlayer.inAnimationWithEnemy = null;
			inKillAnimation = false;
			yield break;
		}
		TakeBodyInMouth(killPlayer.deadBody);
		startTime = Time.timeSinceLevelLoad;
		Quaternion rotateTo = Quaternion.Euler(new Vector3(0f, RoundManager.Instance.YRotationThatFacesTheFarthestFromPosition(((Component)this).transform.position + Vector3.up * 0.6f), 0f));
		Quaternion rotateFrom = ((Component)this).transform.rotation;
		while (Time.timeSinceLevelLoad - startTime < 2f)
		{
			yield return null;
			if (((NetworkBehaviour)this).IsOwner)
			{
				((Component)this).transform.rotation = Quaternion.RotateTowards(rotateFrom, rotateTo, 60f * Time.deltaTime);
			}
		}
		yield return (object)new WaitForSeconds(3.01f);
		DropCarriedBody();
		suspicionLevel = 2;
		SwitchToBehaviourStateOnLocalClient(2);
		endingLunge = true;
		inKillAnimation = false;
	}

	private void StopKillAnimation()
	{
		if (killPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(killPlayerCoroutine);
		}
		creatureVoice.Stop();
		DropCarriedBody();
		suspicionLevel = 2;
		SwitchToBehaviourStateOnLocalClient(2);
		endingLunge = true;
		inKillAnimation = false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void StopKillAnimationServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(19183128u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 19183128u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StopKillAnimationClientRpc();
			}
		}
	}

	[ClientRpc]
	public void StopKillAnimationClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4189041149u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4189041149u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				StopKillAnimation();
			}
		}
	}

	private void TakeBodyInMouth(DeadBodyInfo body)
	{
		carryingBody = body;
		carryingBody.attachedTo = mouthGrip;
		carryingBody.attachedLimb = body.bodyParts[5];
		carryingBody.matchPositionExactly = true;
	}

	private void DropCarriedBody()
	{
		if (!((Object)(object)carryingBody == (Object)null))
		{
			carryingBody.speedMultiplier = 12f;
			carryingBody.attachedTo = null;
			carryingBody.attachedLimb = null;
			carryingBody.matchPositionExactly = false;
			carryingBody = null;
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		StopKillAnimation();
		creatureVoice.Stop();
		creatureSFX.Stop();
		base.KillEnemy(destroy);
	}

	public override void ReceiveLoudNoiseBlast(Vector3 position, float angle)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		base.ReceiveLoudNoiseBlast(position, angle);
		if (angle < 30f)
		{
			coweringOnFloor = true;
		}
	}

	public override void EnableEnemyMesh(bool enable, bool overrideDoNotSet = false)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		base.EnableEnemyMesh(enable);
		ParticleSystem[] componentsInChildren = ((Component)this).gameObject.GetComponentsInChildren<ParticleSystem>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			MainModule main = componentsInChildren[i].main;
			((MainModule)(ref main)).playOnAwake = ((Behaviour)this).enabled;
		}
	}

	public override void OnDrawGizmos()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		base.OnDrawGizmos();
		if (debugEnemyAI)
		{
			Gizmos.DrawCube(noisePositionGuess, Vector3.one);
			Gizmos.DrawLine(noisePositionGuess, ((Component)this).transform.position + Vector3.up);
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_MouthDogAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(43708451u, new RpcReceiveHandler(__rpc_handler_43708451));
		NetworkManager.__rpc_func_table.Add(4130373844u, new RpcReceiveHandler(__rpc_handler_4130373844));
		NetworkManager.__rpc_func_table.Add(998670557u, new RpcReceiveHandler(__rpc_handler_998670557));
		NetworkManager.__rpc_func_table.Add(2798326268u, new RpcReceiveHandler(__rpc_handler_2798326268));
		NetworkManager.__rpc_func_table.Add(2252497379u, new RpcReceiveHandler(__rpc_handler_2252497379));
		NetworkManager.__rpc_func_table.Add(19183128u, new RpcReceiveHandler(__rpc_handler_19183128));
		NetworkManager.__rpc_func_table.Add(4189041149u, new RpcReceiveHandler(__rpc_handler_4189041149));
	}

	private static void __rpc_handler_43708451(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MouthDogAI)(object)target).EndLungeServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4130373844(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MouthDogAI)(object)target).EndLungeClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_998670557(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MouthDogAI)(object)target).KillPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2798326268(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MouthDogAI)(object)target).CancelKillAnimationWithPlayerClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2252497379(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MouthDogAI)(object)target).KillPlayerClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_19183128(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MouthDogAI)(object)target).StopKillAnimationServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4189041149(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MouthDogAI)(object)target).StopKillAnimationClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "MouthDogAI";
	}
}
