using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class CrawlerAI : EnemyAI
{
	public AISearchRoutine searchForPlayers;

	private float checkLineOfSightInterval;

	public float maxSearchAndRoamRadius = 100f;

	[Space(5f)]
	public float noticePlayerTimer;

	private bool hasEnteredChaseMode;

	private bool lostPlayerInChase;

	private bool beginningChasingThisClient;

	private Collider[] nearPlayerColliders;

	public AudioClip shortRoar;

	public AudioClip[] hitWallSFX;

	public AudioClip bitePlayerSFX;

	private Vector3 previousPosition;

	private float previousVelocity;

	private float averageVelocity;

	private float velocityInterval;

	private float velocityAverageCount;

	private float wallCollisionSFXDebounce;

	private float timeSinceHittingPlayer;

	private bool ateTargetPlayerBody;

	private Coroutine eatPlayerBodyCoroutine;

	public Transform mouthTarget;

	public AudioClip eatPlayerSFX;

	public AudioClip[] hitCrawlerSFX;

	public AudioClip[] longRoarSFX;

	public DeadBodyInfo currentlyHeldBody;

	private bool pullingSecondLimb;

	private float agentSpeedWithNegative;

	private Vector3 lastPositionOfSeenPlayer;

	[Space(5f)]
	public float BaseAcceleration = 55f;

	public float SpeedAccelerationEffect = 2f;

	public float SpeedIncreaseRate = 5f;

	private float lastTimeHit;

	public override void Start()
	{
		base.Start();
		nearPlayerColliders = (Collider[])(object)new Collider[4];
	}

	public override void DoAIInterval()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.livingPlayers == 0 || isEnemyDead)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (!searchForPlayers.inProgress)
			{
				StartSearch(((Component)this).transform.position, searchForPlayers);
				Debug.Log((object)$"Crawler: Started new search; is searching?: {searchForPlayers.inProgress}");
			}
			break;
		case 1:
			CheckForVeryClosePlayer();
			if (lostPlayerInChase)
			{
				movingTowardsTargetPlayer = false;
				if (!searchForPlayers.inProgress)
				{
					searchForPlayers.searchWidth = 30f;
					StartSearch(lastPositionOfSeenPlayer, searchForPlayers);
					Debug.Log((object)"Crawler: Lost player in chase; beginning search where the player was last seen");
				}
			}
			else if (searchForPlayers.inProgress)
			{
				StopSearch(searchForPlayers);
				movingTowardsTargetPlayer = true;
				Debug.Log((object)"Crawler: Found player during chase; stopping search coroutine and moving after target player");
			}
			break;
		}
	}

	public override void FinishedCurrentSearchRoutine()
	{
		base.FinishedCurrentSearchRoutine();
		searchForPlayers.searchWidth = Mathf.Clamp(searchForPlayers.searchWidth + 10f, 1f, maxSearchAndRoamRadius);
	}

	public override void Update()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0469: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_034d: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead)
		{
			return;
		}
		if (!((NetworkBehaviour)this).IsOwner)
		{
			inSpecialAnimation = false;
		}
		CalculateAgentSpeed();
		timeSinceHittingPlayer += Time.deltaTime;
		if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.25f, 80f, 25, 5f))
		{
			if (currentBehaviourStateIndex == 1)
			{
				GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(0.8f);
			}
			else
			{
				GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(0.8f, 0.5f);
			}
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			if (hasEnteredChaseMode)
			{
				hasEnteredChaseMode = false;
				searchForPlayers.searchWidth = 25f;
				beginningChasingThisClient = false;
				noticePlayerTimer = 0f;
				useSecondaryAudiosOnAnimatedObjects = false;
				openDoorSpeedMultiplier = 0.6f;
				agent.stoppingDistance = 0f;
				agent.speed = 7f;
			}
			if (checkLineOfSightInterval <= 0.05f)
			{
				checkLineOfSightInterval += Time.deltaTime;
				break;
			}
			checkLineOfSightInterval = 0f;
			PlayerControllerB playerControllerB3;
			if ((Object)(object)stunnedByPlayer != (Object)null)
			{
				playerControllerB3 = stunnedByPlayer;
				noticePlayerTimer = 1f;
			}
			else
			{
				playerControllerB3 = CheckLineOfSightForPlayer(55f);
			}
			if ((Object)(object)playerControllerB3 == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				noticePlayerTimer = Mathf.Clamp(noticePlayerTimer + 0.05f, 0f, 10f);
				if (noticePlayerTimer > 0.2f && !beginningChasingThisClient)
				{
					beginningChasingThisClient = true;
					BeginChasingPlayerServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
					ChangeOwnershipOfEnemy(playerControllerB3.actualClientId);
					Debug.Log((object)"Begin chasing on local client");
				}
			}
			else
			{
				noticePlayerTimer -= Time.deltaTime;
			}
			break;
		}
		case 1:
		{
			if (!hasEnteredChaseMode)
			{
				hasEnteredChaseMode = true;
				lostPlayerInChase = false;
				checkLineOfSightInterval = 0f;
				noticePlayerTimer = 0f;
				beginningChasingThisClient = false;
				useSecondaryAudiosOnAnimatedObjects = true;
				openDoorSpeedMultiplier = 1.5f;
				agent.stoppingDistance = 0.5f;
				agent.speed = 0f;
			}
			if (!((NetworkBehaviour)this).IsOwner || stunNormalizedTimer > 0f)
			{
				break;
			}
			if (checkLineOfSightInterval <= 0.075f)
			{
				checkLineOfSightInterval += Time.deltaTime;
				break;
			}
			checkLineOfSightInterval = 0f;
			if (!ateTargetPlayerBody && (Object)(object)targetPlayer != (Object)null && (Object)(object)targetPlayer.deadBody != (Object)null && (Object)(object)targetPlayer.deadBody.grabBodyObject != (Object)null && targetPlayer.deadBody.grabBodyObject.grabbableToEnemies && eatPlayerBodyCoroutine == null && Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer.deadBody.bodyParts[0]).transform.position) < 3.3f)
			{
				Debug.Log((object)"Crawler: Eat player body start");
				ateTargetPlayerBody = true;
				inSpecialAnimation = true;
				eatPlayerBodyCoroutine = ((MonoBehaviour)this).StartCoroutine(EatPlayerBodyAnimation((int)targetPlayer.playerClientId));
				EatPlayerBodyServerRpc((int)targetPlayer.playerClientId);
			}
			if (inSpecialAnimation)
			{
				break;
			}
			if (lostPlayerInChase)
			{
				PlayerControllerB playerControllerB = CheckLineOfSightForPlayer(55f);
				if (Object.op_Implicit((Object)(object)playerControllerB))
				{
					noticePlayerTimer = 0f;
					lostPlayerInChase = false;
					MakeScreechNoiseServerRpc();
					if ((Object)(object)playerControllerB != (Object)(object)targetPlayer)
					{
						SetMovingTowardsTargetPlayer(playerControllerB);
						ateTargetPlayerBody = false;
						ChangeOwnershipOfEnemy(playerControllerB.actualClientId);
					}
				}
				else
				{
					noticePlayerTimer -= 0.075f;
					if (noticePlayerTimer < -15f)
					{
						SwitchToBehaviourState(0);
					}
				}
				break;
			}
			PlayerControllerB playerControllerB2 = CheckLineOfSightForPlayer(65f, 80);
			if ((Object)(object)playerControllerB2 != (Object)null)
			{
				noticePlayerTimer = 0f;
				lastPositionOfSeenPlayer = ((Component)playerControllerB2).transform.position;
				if ((Object)(object)playerControllerB2 != (Object)(object)targetPlayer)
				{
					targetPlayer = playerControllerB2;
					ateTargetPlayerBody = false;
					ChangeOwnershipOfEnemy(targetPlayer.actualClientId);
				}
			}
			else
			{
				noticePlayerTimer += 0.075f;
				if (noticePlayerTimer > 1.8f)
				{
					lostPlayerInChase = true;
				}
			}
			break;
		}
		}
	}

	private void CalculateAgentSpeed()
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		if (stunNormalizedTimer >= 0f)
		{
			agent.speed = 0.1f;
			agent.acceleration = 200f;
			creatureAnimator.SetBool("stunned", true);
			return;
		}
		creatureAnimator.SetBool("stunned", false);
		creatureAnimator.SetFloat("speedMultiplier", Mathf.Clamp(averageVelocity / 12f * 2.5f, 0.1f, 6f));
		Vector3 val = ((Component)this).transform.position - previousPosition;
		float num = ((Vector3)(ref val)).magnitude / (Time.deltaTime / 1.4f);
		if (velocityInterval <= 0f)
		{
			previousVelocity = averageVelocity;
			velocityInterval = 0.05f;
			velocityAverageCount += 1f;
			if (velocityAverageCount > 5f)
			{
				averageVelocity += (num - averageVelocity) / 3f;
			}
			else
			{
				averageVelocity += num;
				if (velocityAverageCount == 2f)
				{
					averageVelocity /= velocityAverageCount;
				}
			}
		}
		else
		{
			velocityInterval -= Time.deltaTime;
		}
		if (((NetworkBehaviour)this).IsOwner && averageVelocity - num > Mathf.Clamp(num * 0.17f, 2f, 100f) && num > 3f && currentBehaviourStateIndex == 1)
		{
			if (wallCollisionSFXDebounce > 0.5f)
			{
				if (((NetworkBehaviour)this).IsServer)
				{
					CollideWithWallServerRpc();
				}
				else
				{
					CollideWithWallClientRpc();
				}
			}
			agentSpeedWithNegative *= 0.2f;
			wallCollisionSFXDebounce = 0f;
		}
		wallCollisionSFXDebounce += Time.deltaTime;
		previousPosition = ((Component)this).transform.position;
		if (currentBehaviourStateIndex == 0)
		{
			agent.speed = 8f;
			agent.acceleration = 26f;
		}
		else if (currentBehaviourStateIndex == 1)
		{
			float num2 = SpeedIncreaseRate;
			if (Time.realtimeSinceStartup - lastTimeHit < 1f)
			{
				num2 += 4.25f;
			}
			agentSpeedWithNegative += Time.deltaTime * num2;
			agent.speed = Mathf.Clamp(agentSpeedWithNegative, -3f, 16f);
			agent.acceleration = Mathf.Clamp(BaseAcceleration - averageVelocity * SpeedAccelerationEffect, 4f, 40f);
			if (agent.acceleration > 22f)
			{
				agent.angularSpeed = 800f;
				NavMeshAgent obj = agent;
				obj.acceleration += 20f;
			}
			else
			{
				agent.angularSpeed = 230f;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void CollideWithWallServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3661877694u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3661877694u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				CollideWithWallClientRpc();
			}
		}
	}

	[ClientRpc]
	public void CollideWithWallClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(461029090u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 461029090u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			RoundManager.PlayRandomClip(creatureSFX, hitWallSFX);
			RoundManager.Instance.PlayAudibleNoise(((Component)creatureSFX).transform.position, 8f, 0.75f);
			float num = Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position);
			if (num < 15f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
			else if (num < 24f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
			}
		}
	}

	private void CheckForVeryClosePlayer()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		if (Physics.OverlapSphereNonAlloc(((Component)this).transform.position, 1.5f, nearPlayerColliders, 8, (QueryTriggerInteraction)1) > 0)
		{
			PlayerControllerB component = ((Component)((Component)nearPlayerColliders[0]).transform).GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)null && (Object)(object)component != (Object)(object)targetPlayer && !Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.3f, ((Component)component).transform.position, StartOfRound.Instance.collidersAndRoomMask))
			{
				targetPlayer = component;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void BeginChasingPlayerServerRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(869452445u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 869452445u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				BeginChasingPlayerClientRpc(playerObjectId);
			}
		}
	}

	[ClientRpc]
	public void BeginChasingPlayerClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1964892800u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1964892800u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				MakeScreech();
				SwitchToBehaviourStateOnLocalClient(1);
				SetMovingTowardsTargetPlayer(StartOfRound.Instance.allPlayerScripts[playerObjectId]);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void MakeScreechNoiseServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2716706397u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2716706397u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				MakeScreechNoiseClientRpc();
			}
		}
	}

	[ClientRpc]
	public void MakeScreechNoiseClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3572529702u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3572529702u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				MakeScreech();
			}
		}
	}

	private void MakeScreech()
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		int num = Random.Range(0, longRoarSFX.Length);
		creatureVoice.PlayOneShot(longRoarSFX[num]);
		WalkieTalkie.TransmitOneShotAudio(creatureVoice, longRoarSFX[num]);
		if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position) < 15f)
		{
			GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.75f);
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (!(timeSinceHittingPlayer < 0.65f))
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				timeSinceHittingPlayer = 0f;
				playerControllerB.DamagePlayer(40, hasDamageSFX: true, callRPC: true, CauseOfDeath.Mauling);
				agent.speed = 0f;
				HitPlayerServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(1f);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void HitPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3352518565u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3352518565u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				HitPlayerClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void HitPlayerClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(880045462u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 880045462u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (!inSpecialAnimation)
			{
				creatureAnimator.SetTrigger("HitPlayer");
			}
			creatureVoice.PlayOneShot(bitePlayerSFX);
			agentSpeedWithNegative = Random.Range(-2f, 0.25f);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void EatPlayerBodyServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3781293737u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3781293737u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				EatPlayerBodyClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void EatPlayerBodyClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2460625110u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2460625110u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner && eatPlayerBodyCoroutine == null)
			{
				((MonoBehaviour)this).StartCoroutine(EatPlayerBodyAnimation(playerId));
			}
		}
	}

	private IEnumerator EatPlayerBodyAnimation(int playerId)
	{
		PlayerControllerB playerScript = StartOfRound.Instance.allPlayerScripts[playerId];
		float startTime = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => ((Object)(object)playerScript.deadBody != (Object)null && (Object)(object)playerScript.deadBody.grabBodyObject != (Object)null) || Time.realtimeSinceStartup - startTime > 2f));
		DeadBodyInfo deadBody = null;
		if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerId].deadBody != (Object)null)
		{
			if (debugEnemyAI)
			{
				Debug.Log((object)"Thumper: Body is not null!");
			}
			deadBody = StartOfRound.Instance.allPlayerScripts[playerId].deadBody;
		}
		yield return null;
		if (debugEnemyAI)
		{
			Debug.Log((object)$"{(Object)(object)deadBody != (Object)null}; {(Object)(object)deadBody.grabBodyObject != (Object)null}; {!deadBody.isInShip}; {!deadBody.grabBodyObject.isHeld}; {Vector3.Distance(((Component)this).transform.position, ((Component)deadBody.bodyParts[0]).transform.position)}");
		}
		if ((Object)(object)deadBody != (Object)null && (Object)(object)deadBody.grabBodyObject != (Object)null && !deadBody.isInShip && !deadBody.grabBodyObject.isHeld && !isEnemyDead && Vector3.Distance(((Component)this).transform.position, ((Component)deadBody.bodyParts[0]).transform.position) < 6.7f)
		{
			creatureAnimator.SetTrigger("EatPlayer");
			creatureVoice.pitch = Random.Range(0.85f, 1.1f);
			creatureVoice.PlayOneShot(eatPlayerSFX);
			deadBody.canBeGrabbedBackByPlayers = false;
			currentlyHeldBody = deadBody;
			pullingSecondLimb = (Object)(object)deadBody.attachedTo != (Object)null;
			if (pullingSecondLimb)
			{
				deadBody.secondaryAttachedLimb = deadBody.bodyParts[3];
				deadBody.secondaryAttachedTo = mouthTarget;
			}
			else
			{
				deadBody.attachedLimb = deadBody.bodyParts[0];
				deadBody.attachedTo = mouthTarget;
			}
			yield return (object)new WaitForSeconds(2.75f);
		}
		Debug.Log((object)"Crawler: leaving special animation");
		inSpecialAnimation = false;
		DropPlayerBody();
		eatPlayerBodyCoroutine = null;
	}

	private void DropPlayerBody()
	{
		if ((Object)(object)currentlyHeldBody != (Object)null)
		{
			if (pullingSecondLimb)
			{
				currentlyHeldBody.secondaryAttachedLimb = null;
				currentlyHeldBody.secondaryAttachedTo = null;
			}
			else
			{
				currentlyHeldBody.attachedLimb = null;
				currentlyHeldBody.attachedTo = null;
			}
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		base.KillEnemy();
		if (eatPlayerBodyCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(eatPlayerBodyCoroutine);
		}
		DropPlayerBody();
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (!isEnemyDead)
		{
			agent.speed = 2f;
			if (!inSpecialAnimation)
			{
				creatureAnimator.SetTrigger("HurtEnemy");
			}
			enemyHP -= force;
			agentSpeedWithNegative = Random.Range(-2.8f, -2f);
			lastTimeHit = Time.realtimeSinceStartup;
			averageVelocity = 0f;
			RoundManager.PlayRandomClip(creatureVoice, hitCrawlerSFX);
			if (enemyHP <= 0 && ((NetworkBehaviour)this).IsOwner)
			{
				KillEnemyOnOwnerClient();
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_CrawlerAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3661877694u, new RpcReceiveHandler(__rpc_handler_3661877694));
		NetworkManager.__rpc_func_table.Add(461029090u, new RpcReceiveHandler(__rpc_handler_461029090));
		NetworkManager.__rpc_func_table.Add(869452445u, new RpcReceiveHandler(__rpc_handler_869452445));
		NetworkManager.__rpc_func_table.Add(1964892800u, new RpcReceiveHandler(__rpc_handler_1964892800));
		NetworkManager.__rpc_func_table.Add(2716706397u, new RpcReceiveHandler(__rpc_handler_2716706397));
		NetworkManager.__rpc_func_table.Add(3572529702u, new RpcReceiveHandler(__rpc_handler_3572529702));
		NetworkManager.__rpc_func_table.Add(3352518565u, new RpcReceiveHandler(__rpc_handler_3352518565));
		NetworkManager.__rpc_func_table.Add(880045462u, new RpcReceiveHandler(__rpc_handler_880045462));
		NetworkManager.__rpc_func_table.Add(3781293737u, new RpcReceiveHandler(__rpc_handler_3781293737));
		NetworkManager.__rpc_func_table.Add(2460625110u, new RpcReceiveHandler(__rpc_handler_2460625110));
	}

	private static void __rpc_handler_3661877694(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CrawlerAI)(object)target).CollideWithWallServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_461029090(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CrawlerAI)(object)target).CollideWithWallClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_869452445(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CrawlerAI)(object)target).BeginChasingPlayerServerRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1964892800(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CrawlerAI)(object)target).BeginChasingPlayerClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2716706397(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CrawlerAI)(object)target).MakeScreechNoiseServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3572529702(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CrawlerAI)(object)target).MakeScreechNoiseClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3352518565(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CrawlerAI)(object)target).HitPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_880045462(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CrawlerAI)(object)target).HitPlayerClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3781293737(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CrawlerAI)(object)target).EatPlayerBodyServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2460625110(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CrawlerAI)(object)target).EatPlayerBodyClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "CrawlerAI";
	}
}
