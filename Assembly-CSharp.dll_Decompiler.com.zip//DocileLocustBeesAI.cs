using System.Collections;
using UnityEngine;
using UnityEngine.VFX;

public class DocileLocustBeesAI : EnemyAI
{
	private int previousBehaviour;

	public AISearchRoutine bugsRoam;

	public VisualEffect bugsEffect;

	private float timeSinceReturning;

	public ScanNodeProperties scanNode;

	public override void DoAIInterval()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.allPlayersDead || daytimeEnemyLeaving)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (!bugsRoam.inProgress)
			{
				StartSearch(((Component)this).transform.position, bugsRoam);
			}
			if (Physics.CheckSphere(((Component)this).transform.position, 8f, 520, (QueryTriggerInteraction)2))
			{
				SwitchToBehaviourState(1);
			}
			break;
		case 1:
			if (!Physics.CheckSphere(((Component)this).transform.position, 14f, 520, (QueryTriggerInteraction)2))
			{
				SwitchToBehaviourState(0);
			}
			break;
		}
	}

	public override void Update()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		bugsEffect.SetBool("Alive", Vector3.Distance(((Component)StartOfRound.Instance.activeCamera).transform.position, ((Component)this).transform.position) < 62f);
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (previousBehaviour != 0)
			{
				previousBehaviour = 0;
				bugsEffect.SetFloat("MoveToTargetForce", 6f);
				creatureVoice.Play();
			}
			scanNode.maxRange = 18;
			timeSinceReturning += Time.deltaTime;
			creatureVoice.volume = Mathf.Min(creatureVoice.volume + Time.deltaTime * 0.25f, 1f);
			break;
		case 1:
			if (previousBehaviour != 1)
			{
				previousBehaviour = 1;
				bugsEffect.SetFloat("MoveToTargetForce", -35f);
				if (timeSinceReturning > 2f)
				{
					creatureSFX.PlayOneShot(enemyType.audioClips[0]);
					WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[0], 0.8f);
					RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 8f, 0.35f, 0, noiseIsInsideClosedShip: false, 14152);
				}
				timeSinceReturning = 0f;
			}
			scanNode.maxRange = 1;
			if (creatureVoice.volume > 0f)
			{
				creatureVoice.volume = Mathf.Max(creatureVoice.volume - Time.deltaTime * 1.75f, 0f);
			}
			else
			{
				creatureVoice.Stop();
			}
			break;
		}
	}

	public override void DaytimeEnemyLeave()
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		base.DaytimeEnemyLeave();
		bugsEffect.SetFloat("MoveToTargetForce", -15f);
		creatureSFX.PlayOneShot(enemyType.audioClips[0], 0.5f);
		WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[0], 0.4f);
		RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 6f, 0.2f, 0, noiseIsInsideClosedShip: false, 14152);
		((MonoBehaviour)this).StartCoroutine(bugsLeave());
	}

	private IEnumerator bugsLeave()
	{
		yield return (object)new WaitForSeconds(6f);
		KillEnemyOnOwnerClient(overrideDestroy: true);
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "DocileLocustBeesAI";
	}
}
