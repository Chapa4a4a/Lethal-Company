using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class MeteorShowers : NetworkBehaviour
{
	public List<Meteor> meteors = new List<Meteor>();

	public Random meteorRandom;

	public AnimationCurve numberOfMeteorsCurve;

	public AnimationCurve meteorSizeVarianceCurve;

	public AnimationCurve landingTimeCurve;

	public float baseMeteorSize;

	public float skyAngularTilt = 0.5f;

	public float baseWarningTime = 0.15f;

	public float heightInSky = 800f;

	public float landingSpeed = 1.5f;

	public GameObject meteorPrefab;

	public GameObject distantSpritePrefab;

	public GameObject meteorLandingExplosion;

	private Ray skyRay;

	private Vector3 dest;

	public bool meteorsEnabled;

	public AudioClip insideFactoryMeteorClip;

	public void SetStartMeteorShower()
	{
		Debug.Log((object)$"Enable meteor!; {((NetworkBehaviour)this).IsServer}");
		if (((NetworkBehaviour)this).IsServer)
		{
			if (TimeOfDay.Instance.normalizedTimeOfDay > 0.8f)
			{
				((Component)this).gameObject.SetActive(false);
				Debug.Log((object)$"failed start meteor shower; Normalized time of day: {TimeOfDay.Instance.normalizedTimeOfDay}");
			}
			else
			{
				BeginDay(TimeOfDay.Instance.normalizedTimeOfDay);
			}
		}
	}

	public void ResetMeteorWeather()
	{
		meteorsEnabled = false;
		for (int i = 0; i < meteors.Count; i++)
		{
			if ((Object)(object)meteors[i].meteorObject != (Object)null)
			{
				Object.Destroy((Object)(object)meteors[i].meteorObject);
			}
		}
		meteors.Clear();
	}

	[ServerRpc]
	public void CreateMeteorServerRpc(float landingTime, Vector3 landingPosition, Vector3 skyDirection, float size)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Invalid comparison between Unknown and I4
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(505987061u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref landingTime, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref landingPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref skyDirection);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref size, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 505987061u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			CreateMeteorClientRpc(landingTime, landingPosition, skyDirection, size);
		}
	}

	[ClientRpc]
	public void CreateMeteorClientRpc(float landingTime, Vector3 landingPosition, Vector3 skyDirection, float size)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(663969610u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref landingTime, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref landingPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref skyDirection);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref size, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 663969610u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer && TimeOfDay.Instance.timeHasStarted)
			{
				Meteor meteor = new Meteor();
				meteor.normalizedLandingTime = landingTime;
				meteor.scale = size;
				meteor.skyDirection = skyDirection;
				meteor.landingPosition = landingPosition;
				meteors.Add(meteor);
			}
		}
	}

	public void BeginDay(float timeOfDay)
	{
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0282: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		meteorRandom = new Random(StartOfRound.Instance.randomMapSeed + 12);
		meteors.Clear();
		float num = (float)meteorRandom.Next(0, 100) / 100f;
		int num2 = Mathf.RoundToInt(Mathf.Clamp(numberOfMeteorsCurve.Evaluate(num) * 200f, 160f, 250f) / Mathf.Clamp(timeOfDay * 2.5f, 1f, 10f));
		Debug.Log((object)$"Meteors number: {num2}; {Mathf.Clamp(numberOfMeteorsCurve.Evaluate(num) * 200f, 180f, 250f)}");
		float num3 = Mathf.Clamp(baseMeteorSize / ((float)num2 * 0.1f), 12f, baseMeteorSize);
		int num4 = 0;
		if (num3 < 18f)
		{
			num4 = meteorRandom.Next(1, 5);
		}
		Vector3 val = RoundManager.FindMainEntrancePosition(getTeleportPosition: true, getOutsideEntrance: true);
		List<GameObject> list = new List<GameObject>();
		for (int i = 0; i < RoundManager.Instance.outsideAINodes.Length; i++)
		{
			if (!(Vector3.Distance(RoundManager.Instance.outsideAINodes[i].transform.position, StartOfRound.Instance.shipLandingPosition.position) < num3 * 2f) && !(Vector3.Distance(RoundManager.Instance.outsideAINodes[i].transform.position, val) < num3 + 24f))
			{
				list.Add(RoundManager.Instance.outsideAINodes[i]);
			}
		}
		int minValue = 0;
		for (int j = 0; j < 50; j++)
		{
			if (landingTimeCurve.Evaluate((float)j / 50f) > timeOfDay + 0.07f)
			{
				minValue = j * 2;
				break;
			}
		}
		RaycastHit val2 = default(RaycastHit);
		for (int k = 0; k < num2; k++)
		{
			Meteor meteor = new Meteor();
			num = meteorSizeVarianceCurve.Evaluate((float)meteorRandom.Next(0, 100) / 100f);
			meteor.scale = Mathf.Clamp(num3 * num, num3 * 0.25f, num3 * 1.8f);
			meteor.landingPosition = RoundManager.Instance.GetRandomNavMeshPositionInBoxPredictable(list[meteorRandom.Next(0, list.Count)].transform.position, 15f, default(NavMeshHit), meteorRandom, -273);
			if (Physics.Raycast(meteor.landingPosition + Vector3.up * 100f, -Vector3.up, ref val2, 150f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				meteor.landingPosition = ((RaycastHit)(ref val2)).point;
			}
			meteor.skyDirection = Vector3.up * 10f + new Vector3((float)meteorRandom.Next(-10, 10) * skyAngularTilt, 0f, (float)meteorRandom.Next(-10, 10) * skyAngularTilt);
			float num5 = (float)meteorRandom.Next(minValue, 100) / 100f;
			meteor.normalizedLandingTime = Mathf.Clamp(landingTimeCurve.Evaluate(num5), 0.06f, 0.93f);
			meteors.Add(meteor);
		}
		for (int l = 0; l < num4; l++)
		{
			Meteor meteor2 = meteors[meteorRandom.Next(0, meteors.Count)];
			meteor2.scale = Mathf.Clamp(meteor2.scale + (float)meteorRandom.Next(8, 40), 25f, baseMeteorSize);
		}
		HUDManager.Instance.MeteorShowerWarningHUD();
		TimeOfDay.Instance.SetBeginMeteorShowerClientRpc();
		meteorsEnabled = true;
	}

	private void Update()
	{
		if (TimeOfDay.Instance.timeHasStarted && StartOfRound.Instance.shipDoorsEnabled && meteorsEnabled)
		{
			for (int i = 0; i < meteors.Count; i++)
			{
				MeteorUpdate(meteors[i]);
			}
		}
	}

	public void MeteorUpdate(Meteor meteor)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0603: Unknown result type (might be due to invalid IL or missing references)
		//IL_0623: Unknown result type (might be due to invalid IL or missing references)
		//IL_0638: Unknown result type (might be due to invalid IL or missing references)
		//IL_064d: Unknown result type (might be due to invalid IL or missing references)
		//IL_065d: Unknown result type (might be due to invalid IL or missing references)
		//IL_067d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0693: Unknown result type (might be due to invalid IL or missing references)
		//IL_0699: Unknown result type (might be due to invalid IL or missing references)
		//IL_06aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_06df: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0708: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0410: Unknown result type (might be due to invalid IL or missing references)
		//IL_041b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_042a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0435: Unknown result type (might be due to invalid IL or missing references)
		//IL_043b: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_0282: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_046b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0480: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c5: Unknown result type (might be due to invalid IL or missing references)
		float num = meteor.normalizedLandingTime - TimeOfDay.Instance.normalizedTimeOfDay;
		switch (meteor.phase)
		{
		case 0:
			if (num < baseWarningTime)
			{
				meteor.phase = 1;
				skyRay = new Ray(meteor.landingPosition, meteor.skyDirection);
				ParticleSystem[] componentsInChildren3 = (meteor.meteorObject = Object.Instantiate<GameObject>(meteorPrefab, ((Ray)(ref skyRay)).GetPoint(800f), Quaternion.LookRotation(meteor.landingPosition - ((Ray)(ref skyRay)).GetPoint(800f)), RoundManager.Instance.mapPropsContainer.transform)).GetComponentsInChildren<ParticleSystem>();
				meteor.fireParticle = componentsInChildren3[0];
				meteor.fireParticle2 = componentsInChildren3[1];
				meteor.distantSprite = Object.Instantiate<GameObject>(distantSpritePrefab, meteor.meteorObject.transform.position, Quaternion.identity, RoundManager.Instance.mapPropsContainer.transform);
				if (((NetworkBehaviour)this).IsServer)
				{
					CreateMeteorClientRpc(meteor.normalizedLandingTime, meteor.landingPosition, meteor.skyDirection, meteor.scale);
				}
			}
			break;
		case 1:
		{
			if (meteor.previousPhase != 1)
			{
				AudioSource[] componentsInChildren4 = meteor.meteorObject.GetComponentsInChildren<AudioSource>();
				for (int l = 0; l < componentsInChildren4.Length; l++)
				{
					if (!((Component)componentsInChildren4[l]).CompareTag("Aluminum"))
					{
						componentsInChildren4[l].Play();
					}
				}
				meteor.previousPhase = 1;
			}
			skyRay = new Ray(meteor.landingPosition, meteor.skyDirection);
			float num2 = (baseWarningTime - num) / baseWarningTime;
			dest = Vector3.Lerp(((Ray)(ref skyRay)).GetPoint(heightInSky), ((Ray)(ref skyRay)).GetPoint(150f), num2);
			meteor.meteorObject.transform.position = Vector3.Lerp(meteor.meteorObject.transform.position, dest, 5f * Time.deltaTime);
			if ((Object)(object)meteor.distantSprite != (Object)null)
			{
				meteor.distantSprite.transform.LookAt(((Component)StartOfRound.Instance.audioListener).transform.position, Vector3.up);
				meteor.distantSprite.transform.localScale = Vector3.Lerp(Vector3.one * 0.3f, Vector3.one * meteor.scale, num2 * 2f);
				Ray val = default(Ray);
				((Ray)(ref val))._002Ector(((Component)StartOfRound.Instance.audioListener).transform.position, meteor.meteorObject.transform.position - ((Component)StartOfRound.Instance.audioListener).transform.position);
				meteor.distantSprite.transform.position = ((Ray)(ref val)).GetPoint(380f);
				meteor.meteorObject.transform.localScale = Vector3.one * meteor.scale * 0.25f;
				if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, meteor.meteorObject.transform.position) < Vector3.Distance(meteor.distantSprite.transform.position, ((Component)StartOfRound.Instance.audioListener).transform.position) && num2 > 0.75f)
				{
					Object.Destroy((Object)(object)meteor.distantSprite.gameObject);
					AudioSource[] componentsInChildren5 = meteor.meteorObject.GetComponentsInChildren<AudioSource>();
					for (int m = 0; m < componentsInChildren5.Length; m++)
					{
						componentsInChildren5[m].Play();
					}
					if (meteor.scale > 25f)
					{
						componentsInChildren5 = meteor.meteorObject.GetComponentsInChildren<AudioSource>();
						for (int n = 0; n < componentsInChildren5.Length; n++)
						{
							AudioSource obj3 = componentsInChildren5[n];
							obj3.pitch *= 0.5f;
							AudioSource obj4 = componentsInChildren5[n];
							obj4.maxDistance += 120f;
						}
					}
				}
			}
			else
			{
				meteor.meteorObject.transform.localScale = Vector3.Lerp(meteor.meteorObject.transform.localScale, Vector3.Lerp(Vector3.one * meteor.scale * 0.25f, Vector3.one * meteor.scale, num2), 5f * Time.deltaTime);
			}
			((Component)meteor.fireParticle).transform.localScale = new Vector3(meteor.meteorObject.transform.localScale.x, meteor.meteorObject.transform.localScale.y, meteor.meteorObject.transform.localScale.z * 0.72f);
			((Component)meteor.fireParticle2).transform.localScale = ((Component)meteor.fireParticle).transform.localScale;
			if (num <= 0f)
			{
				meteor.phase = 2;
			}
			break;
		}
		case 2:
		case 3:
			if (meteor.previousPhase != meteor.phase)
			{
				meteor.previousPhase = meteor.phase;
				AudioSource[] componentsInChildren = meteor.meteorObject.GetComponentsInChildren<AudioSource>();
				if (!componentsInChildren[0].isPlaying)
				{
					for (int i = 0; i < componentsInChildren.Length; i++)
					{
						componentsInChildren[i].Play();
					}
					if (meteor.scale > 25f)
					{
						componentsInChildren = meteor.meteorObject.GetComponentsInChildren<AudioSource>();
						for (int j = 0; j < componentsInChildren.Length; j++)
						{
							AudioSource obj = componentsInChildren[j];
							obj.pitch *= 0.5f;
							AudioSource obj2 = componentsInChildren[j];
							obj2.maxDistance += 120f;
						}
					}
				}
				if ((Object)(object)meteor.distantSprite != (Object)null)
				{
					Object.Destroy((Object)(object)meteor.distantSprite.gameObject);
				}
				if (meteor.phase == 2)
				{
					meteor.positionAtStartOfLandingPhase = meteor.meteorObject.transform.position;
				}
			}
			meteor.landingTimer = Mathf.Min(meteor.landingTimer + Time.deltaTime * landingSpeed, 1.3f);
			meteor.meteorObject.transform.localScale = Vector3.one * meteor.scale;
			((Component)meteor.fireParticle).transform.localScale = new Vector3(meteor.meteorObject.transform.localScale.x, meteor.meteorObject.transform.localScale.y, meteor.meteorObject.transform.localScale.z * 0.72f);
			((Component)meteor.fireParticle2).transform.localScale = ((Component)meteor.fireParticle).transform.localScale;
			meteor.meteorObject.transform.position = Vector3.LerpUnclamped(meteor.positionAtStartOfLandingPhase, meteor.landingPosition, meteor.landingTimer / 1f);
			meteor.meteorObject.transform.position = new Vector3(meteor.meteorObject.transform.position.x, Mathf.Max(meteor.meteorObject.transform.position.y, -80f), meteor.meteorObject.transform.position.z);
			if (meteor.landingTimer >= 0.4f && meteor.phase != 3)
			{
				meteor.phase = 3;
				if (!GameNetworkManager.Instance.localPlayerController.isInsideFactory)
				{
					AudioSource[] componentsInChildren2 = meteor.meteorObject.GetComponentsInChildren<AudioSource>();
					for (int k = 0; k < componentsInChildren2.Length; k++)
					{
						if (((Component)componentsInChildren2[k]).CompareTag("Aluminum"))
						{
							componentsInChildren2[k].pitch = Random.Range(0.84f, 1.16f);
							componentsInChildren2[k].Play();
							break;
						}
					}
				}
			}
			if (meteor.landingTimer >= 1f && !meteor.landed)
			{
				LandMeteor(meteor);
			}
			break;
		}
	}

	public void LandMeteor(Meteor meteor)
	{
		if (!meteor.landed)
		{
			meteor.landed = true;
			((MonoBehaviour)this).StartCoroutine(meteorLandingAnimation(meteor));
		}
	}

	private IEnumerator meteorLandingAnimation(Meteor meteor)
	{
		yield return (object)new WaitForSeconds(0.05f);
		GameObject val = Object.Instantiate<GameObject>(meteorLandingExplosion, meteor.landingPosition, Quaternion.Euler(-90f, 0f, 0f), RoundManager.Instance.mapPropsContainer.transform);
		val.transform.localScale = Vector3.one * meteor.scale;
		AudioSource[] componentsInChildren = val.GetComponentsInChildren<AudioSource>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if (GameNetworkManager.Instance.localPlayerController.isInsideFactory)
			{
				componentsInChildren[i].spatialBlend = 0f;
				componentsInChildren[i].clip = insideFactoryMeteorClip;
				componentsInChildren[i].pitch = Random.Range(0.9f, 1.1f);
				componentsInChildren[i].volume = Random.Range(0.2f, 0.8f);
				componentsInChildren[i].Play();
				break;
			}
			componentsInChildren[i].pitch = Random.Range(0.9f, 1.1f);
			componentsInChildren[i].Play();
			WalkieTalkie.TransmitOneShotAudio(componentsInChildren[i], componentsInChildren[i].clip);
		}
		ParticleSystem[] componentsInChildren2 = val.GetComponentsInChildren<ParticleSystem>();
		for (int j = 0; j < componentsInChildren2.Length; j++)
		{
			((Component)componentsInChildren2[j]).transform.localScale = val.transform.localScale * 0.12f;
		}
		bool flag = meteor.scale > baseMeteorSize / 3f;
		float num = Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, meteor.landingPosition);
		Landmine.SpawnExplosion(meteor.landingPosition, spawnExplosionEffect: false, meteor.scale, Mathf.Min(meteor.scale + meteor.scale * 0.4f, meteor.scale + 12f), 40, 50f);
		RoundManager.Instance.DestroyTreeAtPosition(meteor.landingPosition, meteor.scale);
		if (num < Mathf.Max(meteor.scale * 1.5f, 35f) || (flag && num < Mathf.Max(meteor.scale * 2f, 90f)))
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.VeryStrong);
			PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
			localPlayerController.externalForceAutoFade += Vector3.Normalize(((Component)GameNetworkManager.Instance.localPlayerController).transform.position - (meteor.landingPosition - Vector3.up * 25f)) * 110f / num;
		}
		else if (num < Mathf.Max(meteor.scale * 2f, 60f) || (flag && num < Mathf.Max(meteor.scale * 2.5f, 150f)))
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
			PlayerControllerB localPlayerController2 = GameNetworkManager.Instance.localPlayerController;
			localPlayerController2.externalForceAutoFade += Vector3.Normalize(((Component)GameNetworkManager.Instance.localPlayerController).transform.position - (meteor.landingPosition - Vector3.up * 20f)) * 85f / num;
		}
		yield return (object)new WaitForSeconds(0.6f);
		if (meteor != null && (Object)(object)meteor.meteorObject != (Object)null)
		{
			Object.Destroy((Object)(object)meteor.meteorObject);
		}
		meteors.Remove(meteor);
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_MeteorShowers()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(505987061u, new RpcReceiveHandler(__rpc_handler_505987061));
		NetworkManager.__rpc_func_table.Add(663969610u, new RpcReceiveHandler(__rpc_handler_663969610));
	}

	private static void __rpc_handler_505987061(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		float landingTime = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref landingTime, default(ForPrimitives));
		Vector3 landingPosition = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref landingPosition);
		Vector3 skyDirection = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref skyDirection);
		float size = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref size, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((MeteorShowers)(object)target).CreateMeteorServerRpc(landingTime, landingPosition, skyDirection, size);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_663969610(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float landingTime = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref landingTime, default(ForPrimitives));
			Vector3 landingPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref landingPosition);
			Vector3 skyDirection = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref skyDirection);
			float size = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref size, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MeteorShowers)(object)target).CreateMeteorClientRpc(landingTime, landingPosition, skyDirection, size);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "MeteorShowers";
	}
}
