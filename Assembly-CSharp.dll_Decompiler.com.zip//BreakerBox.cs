using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class BreakerBox : NetworkBehaviour, IShockableWithGun
{
	public int leversSwitchedOff = 2;

	public bool isPowerOn;

	public RoundManager roundManager;

	public Animator[] breakerSwitches;

	public AudioSource thisAudioSource;

	public AudioSource breakerBoxHum;

	public AudioClip switchPowerSFX;

	private void Start()
	{
		roundManager = Object.FindObjectOfType<RoundManager>();
	}

	public void SetSwitchesOff()
	{
		roundManager = Object.FindObjectOfType<RoundManager>();
		if ((Object)(object)roundManager == (Object)null)
		{
			Debug.LogError((object)"Could not find round manager from breaker box script!");
			return;
		}
		leversSwitchedOff = 0;
		int num = roundManager.BreakerBoxRandom.Next(2, breakerSwitches.Length - 1);
		for (int i = 0; i < num; i++)
		{
			int num2 = roundManager.BreakerBoxRandom.Next(0, breakerSwitches.Length);
			AnimatedObjectTrigger component = ((Component)breakerSwitches[num2]).gameObject.GetComponent<AnimatedObjectTrigger>();
			if (!component.boolValue)
			{
				Debug.Log((object)"switch was already turned off");
				continue;
			}
			breakerSwitches[num2].SetBool("turnedLeft", false);
			component.boolValue = false;
			component.setInitialState = false;
			leversSwitchedOff++;
		}
	}

	public void SwitchBreaker(bool on)
	{
		if ((Object)(object)roundManager == (Object)null)
		{
			return;
		}
		if (on)
		{
			leversSwitchedOff--;
		}
		else
		{
			leversSwitchedOff++;
		}
		if (((NetworkBehaviour)this).IsServer)
		{
			if (leversSwitchedOff <= 0 && !isPowerOn)
			{
				isPowerOn = true;
				roundManager.SwitchPower(on: true);
			}
			else if (leversSwitchedOff > 0 && isPowerOn)
			{
				isPowerOn = false;
				roundManager.SwitchPower(on: false);
			}
		}
		if (leversSwitchedOff <= 0)
		{
			breakerBoxHum.Play();
		}
		else if (leversSwitchedOff == 1)
		{
			breakerBoxHum.Stop();
		}
	}

	void IShockableWithGun.ShockWithGun(PlayerControllerB shockedByPlayer)
	{
		SetSwitchesOff();
		RoundManager.Instance.FlickerLights();
	}

	void IShockableWithGun.StopShockingWithGun()
	{
		RoundManager.Instance.FlickerLights();
	}

	bool IShockableWithGun.CanBeShocked()
	{
		return true;
	}

	float IShockableWithGun.GetDifficultyMultiplier()
	{
		return 0.3f;
	}

	Vector3 IShockableWithGun.GetShockablePosition()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return ((Component)this).transform.position;
	}

	Transform IShockableWithGun.GetShockableTransform()
	{
		return ((Component)this).transform;
	}

	NetworkObject IShockableWithGun.GetNetworkObject()
	{
		return ((NetworkBehaviour)this).NetworkObject;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "BreakerBox";
	}
}
