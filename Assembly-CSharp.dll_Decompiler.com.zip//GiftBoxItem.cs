using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class GiftBoxItem : GrabbableObject
{
	private GameObject objectInPresent;

	public ParticleSystem PoofParticle;

	public AudioSource presentAudio;

	public AudioClip openGiftAudio;

	private PlayerControllerB previousPlayerHeldBy;

	private bool hasUsedGift;

	private int objectInPresentValue;

	private Item objectInPresentItem;

	private bool loadedItemFromSave;

	public override void LoadItemSaveData(int saveData)
	{
		base.LoadItemSaveData(saveData);
		objectInPresentItem = StartOfRound.Instance.allItemsList.itemsList[saveData];
		objectInPresent = objectInPresentItem.spawnPrefab;
		Random random = new Random((int)targetFloorPosition.x + (int)targetFloorPosition.y);
		objectInPresentValue = (int)((float)random.Next(objectInPresentItem.minValue + 25, objectInPresentItem.maxValue + 35) * RoundManager.Instance.scrapValueMultiplier);
		loadedItemFromSave = true;
	}

	public override int GetItemDataToSave()
	{
		base.GetItemDataToSave();
		for (int i = 0; i < StartOfRound.Instance.allItemsList.itemsList.Count; i++)
		{
			if ((Object)(object)StartOfRound.Instance.allItemsList.itemsList[i] == (Object)(object)objectInPresentItem)
			{
				return i;
			}
		}
		return 0;
	}

	public override void InitializeAfterPositioning()
	{
		base.InitializeAfterPositioning();
		if (loadedItemFromSave)
		{
			return;
		}
		Random randomSeed = new Random((int)targetFloorPosition.x + (int)targetFloorPosition.y);
		Random random = new Random((int)targetFloorPosition.x + (int)targetFloorPosition.y);
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		List<int> list = new List<int>(RoundManager.Instance.currentLevel.spawnableScrap.Count);
		for (int i = 0; i < RoundManager.Instance.currentLevel.spawnableScrap.Count; i++)
		{
			if (RoundManager.Instance.currentLevel.spawnableScrap[i].spawnableItem.itemId == 152767)
			{
				list.Add(0);
			}
			else
			{
				list.Add(RoundManager.Instance.currentLevel.spawnableScrap[i].rarity);
			}
		}
		int randomWeightedIndexList = RoundManager.Instance.GetRandomWeightedIndexList(list, randomSeed);
		objectInPresentItem = RoundManager.Instance.currentLevel.spawnableScrap[randomWeightedIndexList].spawnableItem;
		objectInPresent = objectInPresentItem.spawnPrefab;
		objectInPresentValue = (int)((float)random.Next(objectInPresentItem.minValue + 25, objectInPresentItem.maxValue + 35) * RoundManager.Instance.scrapValueMultiplier);
	}

	public override void EquipItem()
	{
		base.EquipItem();
		previousPlayerHeldBy = playerHeldBy;
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		if (!((Object)(object)playerHeldBy == (Object)null) && !hasUsedGift)
		{
			hasUsedGift = true;
			playerHeldBy.activatingItem = true;
			OpenGiftBoxServerRpc();
		}
	}

	public override void PocketItem()
	{
		base.PocketItem();
		playerHeldBy.activatingItem = false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void OpenGiftBoxServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2878544999u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2878544999u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		GameObject val3 = null;
		int presentValue = 0;
		Vector3 val4 = Vector3.zero;
		if ((Object)(object)objectInPresent == (Object)null)
		{
			Debug.LogError((object)"Error: There is no object in gift box!");
		}
		else
		{
			Transform parentOfGiftObject = GetParentOfGiftObject();
			val4 = ((Component)this).transform.position + Vector3.up * 0.25f;
			val3 = Object.Instantiate<GameObject>(objectInPresent, val4, Quaternion.identity, parentOfGiftObject);
			GrabbableObject component = val3.GetComponent<GrabbableObject>();
			component.startFallingPosition = val4;
			((MonoBehaviour)this).StartCoroutine(SetObjectToHitGroundSFX(component));
			component.targetFloorPosition = component.GetItemFloorPosition(((Component)this).transform.position);
			if ((Object)(object)previousPlayerHeldBy != (Object)null && previousPlayerHeldBy.isInHangarShipRoom)
			{
				previousPlayerHeldBy.SetItemInElevator(droppedInShipRoom: true, droppedInElevator: true, component);
			}
			presentValue = objectInPresentValue;
			component.SetScrapValue(presentValue);
			((NetworkBehaviour)component).NetworkObject.Spawn(false);
		}
		if ((Object)(object)val3 != (Object)null)
		{
			OpenGiftBoxClientRpc(NetworkObjectReference.op_Implicit(val3.GetComponent<NetworkObject>()), presentValue, val4);
		}
		OpenGiftBoxNoPresentClientRpc();
	}

	private IEnumerator SetObjectToHitGroundSFX(GrabbableObject gObject)
	{
		yield return (object)new WaitForEndOfFrame();
		Debug.Log((object)("Setting " + gObject.itemProperties.itemName + " hit ground to false"));
		gObject.reachedFloorTarget = false;
		gObject.hasHitGround = false;
		gObject.fallTime = 0f;
	}

	[ClientRpc]
	public void OpenGiftBoxNoPresentClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3328558740u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3328558740u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			PoofParticle.Play();
			presentAudio.PlayOneShot(openGiftAudio);
			WalkieTalkie.TransmitOneShotAudio(presentAudio, openGiftAudio);
			RoundManager.Instance.PlayAudibleNoise(((Component)presentAudio).transform.position, 8f, 0.5f, 0, isInShipRoom && StartOfRound.Instance.hangarDoorsClosed);
			if ((Object)(object)playerHeldBy != (Object)null)
			{
				playerHeldBy.activatingItem = false;
				DestroyObjectInHand(playerHeldBy);
			}
		}
	}

	[ClientRpc]
	public void OpenGiftBoxClientRpc(NetworkObjectReference netObjectRef, int presentValue, Vector3 startFallingPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1252354594u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, presentValue);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref startFallingPos);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1252354594u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			PoofParticle.Play();
			presentAudio.PlayOneShot(openGiftAudio);
			WalkieTalkie.TransmitOneShotAudio(presentAudio, openGiftAudio);
			RoundManager.Instance.PlayAudibleNoise(((Component)presentAudio).transform.position, 8f, 0.5f, 0, isInShipRoom && StartOfRound.Instance.hangarDoorsClosed);
			if ((Object)(object)playerHeldBy != (Object)null)
			{
				playerHeldBy.activatingItem = false;
				DestroyObjectInHand(playerHeldBy);
			}
			if (!((NetworkBehaviour)this).IsServer)
			{
				((MonoBehaviour)this).StartCoroutine(waitForGiftPresentToSpawnOnClient(netObjectRef, presentValue, startFallingPos));
			}
		}
	}

	private IEnumerator waitForGiftPresentToSpawnOnClient(NetworkObjectReference netObjectRef, int presentValue, Vector3 startFallingPos)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		NetworkObject netObject = null;
		float startTime = Time.realtimeSinceStartup;
		while (Time.realtimeSinceStartup - startTime < 8f && !((NetworkObjectReference)(ref netObjectRef)).TryGet(ref netObject, (NetworkManager)null))
		{
			yield return (object)new WaitForSeconds(0.03f);
		}
		if ((Object)(object)netObject == (Object)null)
		{
			Debug.Log((object)"Gift box: No network object found");
			yield break;
		}
		yield return (object)new WaitForEndOfFrame();
		GrabbableObject component = ((Component)netObject).GetComponent<GrabbableObject>();
		RoundManager.Instance.totalScrapValueInLevel -= scrapValue;
		RoundManager.Instance.totalScrapValueInLevel += component.scrapValue;
		component.SetScrapValue(presentValue);
		Transform parentOfGiftObject = GetParentOfGiftObject();
		((Component)component).transform.SetParent(parentOfGiftObject, true);
		component.targetFloorPosition = ((Component)component).transform.parent.InverseTransformPoint(component.GetItemFloorPosition(startFallingPos));
		if ((Object)(object)((Component)component).transform.parent != (Object)null)
		{
			startFallingPos = ((Component)component).transform.parent.InverseTransformPoint(startFallingPos);
		}
		component.startFallingPosition = startFallingPos;
		component.fallTime = 0f;
		component.hasHitGround = false;
		component.reachedFloorTarget = false;
		if ((Object)(object)previousPlayerHeldBy != (Object)null && previousPlayerHeldBy.isInHangarShipRoom)
		{
			previousPlayerHeldBy.SetItemInElevator(droppedInShipRoom: true, droppedInElevator: true, component);
		}
	}

	private Transform GetParentOfGiftObject()
	{
		if (((Object)(object)previousPlayerHeldBy != (Object)null && previousPlayerHeldBy.isInElevator) || StartOfRound.Instance.inShipPhase)
		{
			return StartOfRound.Instance.elevatorTransform;
		}
		return null;
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_GiftBoxItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2878544999u, new RpcReceiveHandler(__rpc_handler_2878544999));
		NetworkManager.__rpc_func_table.Add(3328558740u, new RpcReceiveHandler(__rpc_handler_3328558740));
		NetworkManager.__rpc_func_table.Add(1252354594u, new RpcReceiveHandler(__rpc_handler_1252354594));
	}

	private static void __rpc_handler_2878544999(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiftBoxItem)(object)target).OpenGiftBoxServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3328558740(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiftBoxItem)(object)target).OpenGiftBoxNoPresentClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1252354594(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference netObjectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
			int presentValue = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref presentValue);
			Vector3 startFallingPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref startFallingPos);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiftBoxItem)(object)target).OpenGiftBoxClientRpc(netObjectRef, presentValue, startFallingPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "GiftBoxItem";
	}
}
