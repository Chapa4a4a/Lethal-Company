using System;
using System.Collections;
using System.Linq;
using DigitalRuby.ThunderAndLightning;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;

public class PatcherTool : GrabbableObject
{
	[Space(15f)]
	public float gunAnomalyDamage = 1f;

	public bool isShocking;

	public IShockableWithGun shockedTargetScript;

	[Space(15f)]
	public Light flashlightBulb;

	public Light flashlightBulbGlow;

	public AudioSource mainAudio;

	public AudioSource shockAudio;

	public AudioSource gunAudio;

	public AudioClip[] activateClips;

	public AudioClip[] beginShockClips;

	public AudioClip[] overheatClips;

	public AudioClip[] finishShockClips;

	public AudioClip outOfBatteriesClip;

	public AudioClip detectAnomaly;

	public AudioClip scanAnomaly;

	public Material bulbLight;

	public Material bulbDark;

	public Animator effectAnimator;

	public Animator gunAnimator;

	public ParticleSystem overheatParticle;

	private Coroutine scanGunCoroutine;

	private Coroutine beginShockCoroutine;

	public Transform aimDirection;

	private int anomalyMask = 524296;

	private int roomMask = 256;

	private RaycastHit hit;

	private Ray ray;

	public GameObject lightningObject;

	public Transform lightningDest;

	public Transform lightningBend1;

	public Transform lightningBend2;

	private Vector3 shockVectorMidpoint;

	[Header("Shock difficulty variables")]
	public float bendStrengthCap = 3f;

	public float endStrengthCap = 4.25f;

	private float currentEndStrengthCap;

	public float bendChangeSpeedMultiplier = 10f;

	public float endChangeSpeedMultiplier = 17f;

	private float currentEndChangeSpeedMultiplier;

	public float pullStrength;

	public float endPullStrength = 4.25f;

	private float currentEndPullStrength;

	public float maxChangePerFrame = 0.15f;

	public float endChangePerFrame = 2.5f;

	private float currentEndChangePerFrame;

	[HideInInspector]
	public float bendMultiplier;

	[HideInInspector]
	private float bendRandomizerShift;

	[HideInInspector]
	private Vector3 bendVector;

	public float gunOverheat;

	[HideInInspector]
	private bool sentStopShockingRPC;

	[HideInInspector]
	private bool wasShockingPreviousFrame;

	private LightningSplineScript lightningScript;

	private Random gunRandom;

	private int timesUsed;

	private bool lightningVisible;

	private float minigameChecksInterval;

	private float timeSpentShocking;

	private float makeAudibleNoiseTimer;

	public static int finishedShockMinigame;

	private RaycastHit[] raycastEnemies;

	private bool isScanning;

	private float currentDifficultyMultiplier;

	private PlayerControllerB previousPlayerHeldBy;

	public override void Start()
	{
		base.Start();
		raycastEnemies = (RaycastHit[])(object)new RaycastHit[12];
	}

	public override void OnDestroy()
	{
		((NetworkBehaviour)this).OnDestroy();
		if ((Object)(object)lightningDest != (Object)null && (Object)(object)((Component)lightningDest).gameObject != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)lightningDest).gameObject);
		}
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		gunOverheat = 0f;
		if ((Object)(object)playerHeldBy == (Object)null)
		{
			return;
		}
		if (scanGunCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(scanGunCoroutine);
			scanGunCoroutine = null;
		}
		if (beginShockCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(beginShockCoroutine);
			beginShockCoroutine = null;
		}
		if (isShocking)
		{
			Debug.Log((object)"Stop shocking gun");
			StopShockingAnomalyOnClient(failed: true);
		}
		else if (isScanning)
		{
			SwitchFlashlight(on: false);
			gunAudio.Stop();
			currentUseCooldown = 0.5f;
			if (scanGunCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(scanGunCoroutine);
				scanGunCoroutine = null;
			}
			isScanning = false;
		}
		else
		{
			Debug.Log((object)"Start scanning gun");
			isScanning = true;
			sentStopShockingRPC = false;
			scanGunCoroutine = ((MonoBehaviour)this).StartCoroutine(ScanGun());
			currentUseCooldown = 0.5f;
			Debug.Log((object)"Use patcher tool");
			PlayRandomAudio(mainAudio, activateClips);
			SwitchFlashlight(on: true);
		}
	}

	private void PlayRandomAudio(AudioSource audioSource, AudioClip[] audioClips)
	{
		if (audioClips.Length != 0)
		{
			audioSource.PlayOneShot(audioClips[Random.Range(0, audioClips.Length)]);
		}
	}

	private bool GunMeetsConditionsToShock(PlayerControllerB playerUsingGun, Vector3 targetPosition, float maxAngle = 80f)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"Target position: {targetPosition}");
		Vector3 position = ((Component)playerUsingGun.gameplayCamera).transform.position;
		Vector3 val = position;
		val.y = targetPosition.y;
		if (Vector3.Angle(((Component)playerUsingGun).transform.forward, targetPosition - position) > maxAngle)
		{
			return false;
		}
		if (gunOverheat > 2f || Vector3.Distance(position, targetPosition) < 0.7f || Vector3.Distance(position, targetPosition) > 13f || Physics.Linecast(position, targetPosition, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
		{
			RaycastHit val2 = default(RaycastHit);
			if (Physics.Linecast(position, targetPosition, ref val2, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
			{
				Debug.Log((object)((Object)((RaycastHit)(ref val2)).transform).name);
				Debug.Log((object)((Object)((Component)((RaycastHit)(ref val2)).transform).gameObject).name);
				Debug.DrawLine(position, targetPosition, Color.green, 25f);
			}
			Debug.Log((object)$"Gun not meeting conditions to zap; {gunOverheat > 2f}; {Vector3.Distance(position, targetPosition) < 0.7f}; {Physics.Linecast(position, targetPosition, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1)}");
			return false;
		}
		return true;
	}

	public override void LateUpdate()
	{
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0549: Unknown result type (might be due to invalid IL or missing references)
		base.LateUpdate();
		if (!lightningVisible)
		{
			return;
		}
		if (isShocking && shockedTargetScript != null && (Object)(object)playerHeldBy != (Object)null && !playerHeldBy.isPlayerDead && !Object.op_Implicit((Object)(object)playerHeldBy.inAnimationWithEnemy) && !insertedBattery.empty)
		{
			timeSpentShocking += Time.deltaTime / 8f;
			if (makeAudibleNoiseTimer <= 0f)
			{
				makeAudibleNoiseTimer = 0.8f;
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 20f, 0.92f, 0, isInShipRoom && StartOfRound.Instance.hangarDoorsClosed, 11);
			}
			else
			{
				makeAudibleNoiseTimer -= Time.deltaTime;
			}
			Vector3 shockablePosition = shockedTargetScript.GetShockablePosition();
			lightningDest.position = shockablePosition + new Vector3(Random.Range(-0.3f, 0.3f), Random.Range(-0.3f, 0.3f), Random.Range(-0.3f, 0.3f));
			shockVectorMidpoint = Vector3.Normalize(shockedTargetScript.GetShockableTransform().position - aimDirection.position);
			bendVector = ((Component)playerHeldBy).transform.right * bendMultiplier;
			lightningBend1.position = aimDirection.position + 0.3f * shockVectorMidpoint + bendVector;
			lightningBend2.position = aimDirection.position + 0.6f * shockVectorMidpoint + bendVector;
			if (bendRandomizerShift < 0f)
			{
				float num = Mathf.Clamp(RandomFloatInRange(gunRandom, -1f + Mathf.Round(bendRandomizerShift), 1f) * (bendChangeSpeedMultiplier * Time.deltaTime), 0f - maxChangePerFrame, maxChangePerFrame);
				bendMultiplier = Mathf.Clamp(bendMultiplier + num, 0f - bendStrengthCap, bendStrengthCap);
			}
			else
			{
				float num2 = Mathf.Clamp(RandomFloatInRange(gunRandom, -1f, 1f + Mathf.Round(bendRandomizerShift)) * (bendChangeSpeedMultiplier * Time.deltaTime), 0f - maxChangePerFrame, maxChangePerFrame);
				bendMultiplier = Mathf.Clamp(bendMultiplier + num2, 0f - bendStrengthCap, bendStrengthCap);
			}
			ShiftBendRandomizer();
			AdjustDifficultyValues();
			if (!((NetworkBehaviour)this).IsOwner)
			{
				return;
			}
			wasShockingPreviousFrame = true;
			float num3 = Mathf.Abs(Mathf.Clamp(bendMultiplier * 0.5f, -0.5f, 0.5f) - playerHeldBy.shockMinigamePullPosition * 2f);
			playerHeldBy.turnCompass.Rotate(Vector3.up * 100f * bendMultiplier * pullStrength * Time.deltaTime);
			RoundManager.Instance.tempTransform.eulerAngles = new Vector3(0f, ((Component)playerHeldBy.gameplayCamera).transform.eulerAngles.y, ((Component)playerHeldBy.gameplayCamera).transform.eulerAngles.z);
			if (Vector3.Angle(RoundManager.Instance.tempTransform.forward, new Vector3(lightningDest.position.x, ((Component)playerHeldBy.gameplayCamera).transform.position.y, lightningDest.position.z) - ((Component)playerHeldBy.gameplayCamera).transform.position) > 90f)
			{
				gunOverheat += Time.deltaTime * 10f;
			}
			if (bendMultiplier < -0.3f)
			{
				if (playerHeldBy.shockMinigamePullPosition < 0f)
				{
					gunOverheat = Mathf.Clamp(gunOverheat - Time.deltaTime * 3f, 0f, 10f);
				}
				else
				{
					gunOverheat += Time.deltaTime * (num3 * 2f);
				}
				HUDManager.Instance.SetTutorialArrow(2);
			}
			else if (bendMultiplier > 0.3f)
			{
				if (playerHeldBy.shockMinigamePullPosition > 0f)
				{
					gunOverheat = Mathf.Clamp(gunOverheat - Time.deltaTime * 3f, 0f, 10f);
				}
				else
				{
					gunOverheat += Time.deltaTime * (num3 * 2f);
				}
				HUDManager.Instance.SetTutorialArrow(1);
			}
			else
			{
				HUDManager.Instance.SetTutorialArrow(0);
			}
			minigameChecksInterval -= Time.deltaTime;
			if (minigameChecksInterval <= 0f)
			{
				minigameChecksInterval = 0.15f;
				if (shockedTargetScript == null || !GunMeetsConditionsToShock(playerHeldBy, shockablePosition))
				{
					StopShockingAnomalyOnClient(failed: true);
					return;
				}
			}
			if (gunOverheat > 0.75f)
			{
				gunAudio.volume = Mathf.Lerp(gunAudio.volume, 1f, 13f * Time.deltaTime);
				gunAnimator.SetBool("Overheating", true);
			}
			else
			{
				gunAudio.volume = Mathf.Lerp(gunAudio.volume, 0f, 7f * Time.deltaTime);
				gunAnimator.SetBool("Overheating", false);
			}
		}
		else if (wasShockingPreviousFrame)
		{
			wasShockingPreviousFrame = false;
			timeSpentShocking = 0f;
			if (((NetworkBehaviour)this).IsOwner)
			{
				StopShockingAnomalyOnClient();
			}
		}
	}

	private void AdjustDifficultyValues()
	{
		bendStrengthCap = Mathf.Lerp(0.4f, currentEndStrengthCap, timeSpentShocking * currentDifficultyMultiplier);
		bendChangeSpeedMultiplier = Mathf.Lerp(3.5f, currentEndChangeSpeedMultiplier, timeSpentShocking * currentDifficultyMultiplier);
		pullStrength = Mathf.Lerp(0.4f, currentEndPullStrength, timeSpentShocking * currentDifficultyMultiplier);
		maxChangePerFrame = Mathf.Lerp(0.13f, currentEndChangePerFrame, timeSpentShocking * currentDifficultyMultiplier);
		lightningScript.Forkedness = Mathf.Lerp(0.11f, 0.45f, timeSpentShocking * currentDifficultyMultiplier);
		lightningScript.ForkLengthMultiplier = Mathf.Lerp(0.11f, 1.1f, timeSpentShocking * currentDifficultyMultiplier);
		lightningScript.ForkLengthVariance = Mathf.Lerp(0.08f, 4f, timeSpentShocking * currentDifficultyMultiplier);
		shockAudio.volume = Mathf.Lerp(0.1f, 1f, timeSpentShocking * currentDifficultyMultiplier);
	}

	private void InitialDifficultyValues()
	{
		currentEndStrengthCap = SetCurrentDifficultyValue(endStrengthCap, 1.4f);
		currentEndChangeSpeedMultiplier = SetCurrentDifficultyValue(endChangeSpeedMultiplier, 7f);
		currentEndPullStrength = SetCurrentDifficultyValue(endPullStrength, 0.4f);
		currentEndChangePerFrame = SetCurrentDifficultyValue(endChangePerFrame, 0.12f);
	}

	private float SetCurrentDifficultyValue(float max, float min)
	{
		return shockedTargetScript.GetDifficultyMultiplier() * (max - min) + min;
	}

	public void ShiftBendRandomizer()
	{
		if (bendMultiplier < 0f)
		{
			if (bendMultiplier < -0.5f)
			{
				bendRandomizerShift += 1f * Time.deltaTime;
			}
			else
			{
				bendRandomizerShift -= 1f * Time.deltaTime;
			}
		}
		else if (bendMultiplier > 0.5f)
		{
			bendRandomizerShift -= 1f * Time.deltaTime;
		}
		else
		{
			bendRandomizerShift += 1f * Time.deltaTime;
		}
	}

	private void OnEnable()
	{
		((MonoBehaviour)this).StartCoroutine(waitForStartOfRoundInstance());
	}

	private IEnumerator waitForStartOfRoundInstance()
	{
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)StartOfRound.Instance != (Object)null && StartOfRound.Instance.CameraSwitchEvent != null && (Object)(object)StartOfRound.Instance.activeCamera != (Object)null));
		((UnityEvent)StartOfRound.Instance.CameraSwitchEvent).AddListener(new UnityAction(OnSwitchCamera));
		if ((Object)(object)StartOfRound.Instance != (Object)null && (Object)(object)StartOfRound.Instance.activeCamera != (Object)null)
		{
			lightningScript = lightningObject.GetComponent<LightningSplineScript>();
			lightningScript.Camera = StartOfRound.Instance.activeCamera;
		}
	}

	private void OnDisable()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		((UnityEvent)StartOfRound.Instance.CameraSwitchEvent).RemoveListener(new UnityAction(OnSwitchCamera));
	}

	private void OnSwitchCamera()
	{
		lightningObject.GetComponent<LightningSplineScript>().Camera = StartOfRound.Instance.activeCamera;
	}

	private IEnumerator ScanGun()
	{
		effectAnimator.SetTrigger("Scan");
		gunAudio.PlayOneShot(scanAnomaly);
		lightningScript = lightningObject.GetComponent<LightningSplineScript>();
		lightningDest.SetParent((Transform)null);
		lightningBend1.SetParent((Transform)null);
		lightningBend2.SetParent((Transform)null);
		Debug.Log((object)"Scan A");
		IShockableWithGun shockableWithGun = default(IShockableWithGun);
		for (int i = 0; i < 12; i++)
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				Debug.Log((object)"Scan B");
				if (isPocketed)
				{
					yield break;
				}
				ray = new Ray(((Component)playerHeldBy.gameplayCamera).transform.position - ((Component)playerHeldBy.gameplayCamera).transform.forward * 3f, ((Component)playerHeldBy.gameplayCamera).transform.forward);
				Debug.DrawRay(((Component)playerHeldBy.gameplayCamera).transform.position - ((Component)playerHeldBy.gameplayCamera).transform.forward * 3f, ((Component)playerHeldBy.gameplayCamera).transform.forward * 6f, Color.red, 5f);
				int num = Physics.SphereCastNonAlloc(ray, 5f, raycastEnemies, 5f, anomalyMask, (QueryTriggerInteraction)2);
				raycastEnemies = raycastEnemies.OrderBy((RaycastHit x) => ((RaycastHit)(ref x)).distance).ToArray();
				for (int j = 0; j < num; j++)
				{
					if (j >= raycastEnemies.Length)
					{
						continue;
					}
					hit = raycastEnemies[j];
					if (!((Object)(object)((RaycastHit)(ref hit)).transform == (Object)null) && ((Component)((RaycastHit)(ref hit)).transform).gameObject.TryGetComponent<IShockableWithGun>(ref shockableWithGun) && shockableWithGun.CanBeShocked())
					{
						Vector3 shockablePosition = shockableWithGun.GetShockablePosition();
						Debug.Log((object)("Got shockable transform name : " + ((Object)((Component)shockableWithGun.GetShockableTransform()).gameObject).name));
						if (GunMeetsConditionsToShock(playerHeldBy, shockablePosition, 60f))
						{
							gunAudio.Stop();
							BeginShockingAnomalyOnClient(shockableWithGun);
							yield break;
						}
					}
				}
			}
			yield return (object)new WaitForSeconds(0.125f);
		}
		Debug.Log((object)"Zap gun light off!!!");
		SwitchFlashlight(on: false);
		isScanning = false;
	}

	public void BeginShockingAnomalyOnClient(IShockableWithGun shockableScript)
	{
		timesUsed++;
		sentStopShockingRPC = false;
		gunRandom = new Random(playerHeldBy.playersManager.randomMapSeed + timesUsed);
		gunOverheat = 0f;
		shockedTargetScript = shockableScript;
		currentDifficultyMultiplier = shockableScript.GetDifficultyMultiplier();
		InitialDifficultyValues();
		bendMultiplier = 0f;
		bendRandomizerShift = 0f;
		if (beginShockCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(beginShockCoroutine);
		}
		beginShockCoroutine = ((MonoBehaviour)this).StartCoroutine(beginShockGame(shockableScript));
	}

	private IEnumerator beginShockGame(IShockableWithGun shockableScript)
	{
		if (shockableScript == null || (Object)(object)shockableScript.GetNetworkObject() == (Object)null)
		{
			Debug.LogError((object)$"Zap gun: The shockable script was null when starting the minigame! ; {shockableScript == null}; {(Object)(object)shockableScript.GetNetworkObject() == (Object)null}");
			isScanning = false;
			yield break;
		}
		effectAnimator.SetTrigger("Shock");
		gunAudio.PlayOneShot(detectAnomaly);
		isShocking = true;
		isScanning = false;
		playerHeldBy.inShockingMinigame = true;
		Transform shockableTransform = shockableScript.GetShockableTransform();
		playerHeldBy.shockingTarget = shockableTransform;
		playerHeldBy.isCrouching = false;
		playerHeldBy.playerBodyAnimator.SetBool("crouching", false);
		playerHeldBy.turnCompass.LookAt(shockableTransform);
		Vector3 zero = Vector3.zero;
		zero.y = playerHeldBy.turnCompass.localEulerAngles.y;
		playerHeldBy.turnCompass.localEulerAngles = zero;
		yield return (object)new WaitForSeconds(0.55f);
		StartShockAudios();
		isBeingUsed = true;
		shockedTargetScript.ShockWithGun(playerHeldBy);
		playerHeldBy.inSpecialInteractAnimation = true;
		playerHeldBy.playerBodyAnimator.SetBool("HoldPatcherTool", true);
		SwitchFlashlight(on: false);
		gunAnimator.SetTrigger("Shock");
		lightningObject.SetActive(true);
		lightningVisible = true;
		ShockPatcherToolServerRpc(NetworkObjectReference.op_Implicit(shockableScript.GetNetworkObject()));
	}

	private void StartShockAudios()
	{
		PlayRandomAudio(mainAudio, beginShockClips);
		gunAudio.Play();
		mainAudio.Play();
		mainAudio.volume = 1f;
		shockAudio.Play();
		shockAudio.volume = 0f;
	}

	public void StopShockingAnomalyOnClient(bool failed = false)
	{
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		if (scanGunCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(scanGunCoroutine);
			scanGunCoroutine = null;
		}
		timeSpentShocking = 0f;
		wasShockingPreviousFrame = false;
		lightningVisible = false;
		lightningObject.SetActive(false);
		isBeingUsed = false;
		SwitchFlashlight(on: false);
		gunAnimator.SetBool("Overheating", false);
		gunAnimator.SetBool("Shock", false);
		if (shockedTargetScript != null)
		{
			shockedTargetScript.StopShockingWithGun();
		}
		gunOverheat = 0f;
		gunAudio.Stop();
		gunAudio.volume = 1f;
		mainAudio.Stop();
		shockAudio.Stop();
		if (((NetworkBehaviour)this).IsOwner && (Object)(object)playerHeldBy != (Object)null && !sentStopShockingRPC)
		{
			HUDManager.Instance.SetTutorialArrow(0);
			sentStopShockingRPC = true;
			StopShockingServerRpc();
			playerHeldBy.playerBodyAnimator.SetTrigger("Overheat");
			Vector3 localEulerAngles = playerHeldBy.thisPlayerBody.localEulerAngles;
			localEulerAngles.x = 0f;
			localEulerAngles.z = 0f;
			playerHeldBy.thisPlayerBody.localEulerAngles = localEulerAngles;
		}
		if (failed)
		{
			PlayRandomAudio(gunAudio, overheatClips);
			overheatParticle.Play();
			currentUseCooldown = 5f;
			effectAnimator.SetTrigger("FailGame");
			if (timeSpentShocking > 0.75f)
			{
				SetFinishedShockMinigameTutorial();
			}
		}
		else
		{
			currentUseCooldown = 0.25f;
			effectAnimator.SetTrigger("FinishGame");
			if (((NetworkBehaviour)this).IsOwner)
			{
				playerHeldBy.playerBodyAnimator.SetTrigger("Overheat");
			}
			SetFinishedShockMinigameTutorial();
		}
		playerHeldBy.PlayQuickSpecialAnimation(3f);
		PlayRandomAudio(mainAudio, finishShockClips);
		if (((NetworkBehaviour)this).IsOwner)
		{
			if ((Object)(object)playerHeldBy != (Object)null)
			{
				playerHeldBy.playerBodyAnimator.SetBool("HoldPatcherTool", false);
				((MonoBehaviour)this).StartCoroutine(stopShocking(playerHeldBy));
			}
			else
			{
				Debug.LogError((object)"Error: playerHeldBy is null for owner of zap gun when stopping shock, in client rpc");
			}
			return;
		}
		isShocking = false;
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.inSpecialInteractAnimation = false;
			playerHeldBy.inShockingMinigame = false;
		}
	}

	private void SetFinishedShockMinigameTutorial()
	{
		if (HUDManager.Instance.setTutorialArrow)
		{
			finishedShockMinigame++;
			if (finishedShockMinigame >= 2)
			{
				HUDManager.Instance.setTutorialArrow = false;
			}
		}
	}

	private IEnumerator stopShocking(PlayerControllerB playerController)
	{
		yield return (object)new WaitForSeconds(0.4f);
		isShocking = false;
		playerController.inSpecialInteractAnimation = false;
		playerController.inShockingMinigame = false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void ShockPatcherToolServerRpc(NetworkObjectReference netObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2303694898u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObject, default(ForNetworkSerializable));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2303694898u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ShockPatcherToolClientRpc(netObject);
				Debug.Log((object)"Patcher tool server rpc received");
			}
		}
	}

	[ClientRpc]
	public void ShockPatcherToolClientRpc(NetworkObjectReference netObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4275427213u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObject, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4275427213u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		Debug.Log((object)"Shock patcher tool client rpc received");
		if (((NetworkBehaviour)this).IsOwner || (Object)(object)previousPlayerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			return;
		}
		Debug.Log((object)"Running shock patcher tool function");
		timesUsed++;
		gunRandom = new Random(playerHeldBy.playersManager.randomMapSeed + timesUsed);
		if (scanGunCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(scanGunCoroutine);
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref netObject)).TryGet(ref val3, (NetworkManager)null))
		{
			isShocking = true;
			isScanning = false;
			shockedTargetScript = ((Component)val3).gameObject.GetComponentInChildren<IShockableWithGun>();
			if (shockedTargetScript != null)
			{
				shockedTargetScript.ShockWithGun(playerHeldBy);
				StartShockAudios();
				lightningObject.SetActive(true);
				SwitchFlashlight(on: false);
				gunAnimator.SetTrigger("UseGun");
				effectAnimator.SetTrigger("Shock");
				lightningVisible = true;
				playerHeldBy.inShockingMinigame = true;
				playerHeldBy.inSpecialInteractAnimation = true;
			}
			else
			{
				Debug.LogError((object)"Zap gun: Unable to get IShockableWithGun interface from networkobject on client rpc!");
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StopShockingServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3351579778u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3351579778u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StopShockingClientRpc();
			}
		}
	}

	[ClientRpc]
	public void StopShockingClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(75402723u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 75402723u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			Debug.Log((object)"Running client rpc stopping shock");
			if (!((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && !((Object)(object)NetworkManager.Singleton == (Object)null) && !((NetworkBehaviour)this).IsOwner && !((Object)(object)previousPlayerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController))
			{
				Debug.Log((object)$"{((NetworkBehaviour)this).IsOwner} ; {previousPlayerHeldBy}");
				StopShockingAnomalyOnClient();
			}
		}
	}

	public override void UseUpBatteries()
	{
		base.UseUpBatteries();
		SwitchFlashlight(on: false);
		gunAudio.PlayOneShot(outOfBatteriesClip, 1f);
	}

	public override void PocketItem()
	{
		isBeingUsed = false;
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			DisablePatcherGun();
		}
		else
		{
			Debug.Log((object)"Could not find what player was holding this item");
		}
		base.PocketItem();
	}

	public override void DiscardItem()
	{
		DisablePatcherGun();
		base.DiscardItem();
	}

	private void DisablePatcherGun()
	{
		SwitchFlashlight(on: false);
		if (scanGunCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(scanGunCoroutine);
			scanGunCoroutine = null;
		}
		if (beginShockCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(beginShockCoroutine);
			beginShockCoroutine = null;
		}
		if ((Object)(object)playerHeldBy != (Object)null && isShocking)
		{
			StopShockingAnomalyOnClient(failed: true);
		}
		isBeingUsed = false;
		wasShockingPreviousFrame = false;
	}

	public override void EquipItem()
	{
		base.EquipItem();
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			previousPlayerHeldBy = playerHeldBy;
		}
	}

	public void SwitchFlashlight(bool on)
	{
		((Behaviour)flashlightBulb).enabled = on;
		((Behaviour)flashlightBulbGlow).enabled = on;
	}

	private float RandomFloatInRange(Random rand, float min, float max)
	{
		return (float)(rand.NextDouble() * (double)(max - min) + (double)min);
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_PatcherTool()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2303694898u, new RpcReceiveHandler(__rpc_handler_2303694898));
		NetworkManager.__rpc_func_table.Add(4275427213u, new RpcReceiveHandler(__rpc_handler_4275427213));
		NetworkManager.__rpc_func_table.Add(3351579778u, new RpcReceiveHandler(__rpc_handler_3351579778));
		NetworkManager.__rpc_func_table.Add(75402723u, new RpcReceiveHandler(__rpc_handler_75402723));
	}

	private static void __rpc_handler_2303694898(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference netObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref netObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PatcherTool)(object)target).ShockPatcherToolServerRpc(netObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4275427213(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference netObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref netObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PatcherTool)(object)target).ShockPatcherToolClientRpc(netObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3351579778(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PatcherTool)(object)target).StopShockingServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_75402723(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PatcherTool)(object)target).StopShockingClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "PatcherTool";
	}
}
