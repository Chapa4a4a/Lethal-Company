using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dissonance;
using GameNetcodeStuff;
using Steamworks;
using Steamworks.Data;
using TMPro;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;
using UnityEngine.UI;

public class HUDManager : NetworkBehaviour
{
	public Camera UICamera;

	public HUDElement Inventory;

	public HUDElement Chat;

	public HUDElement PlayerInfo;

	public HUDElement Tooltips;

	public HUDElement InstabilityCounter;

	public HUDElement Clock;

	public HUDElement Compass;

	private HUDElement[] HUDElements;

	public GameObject HUDContainer;

	public Animator playerScreenShakeAnimator;

	public RawImage playerScreenTexture;

	public Volume playerGraphicsVolume;

	public TextMeshProUGUI weightCounter;

	public Animator weightCounterAnimator;

	[Header("Item UI")]
	public Image[] itemSlotIcons;

	public Image[] itemSlotIconFrames;

	[Header("Tooltips")]
	public TextMeshProUGUI[] controlTipLines;

	[Header("Object Scanner")]
	private RaycastHit[] scanNodesHit;

	public RectTransform[] scanElements;

	private bool scanElementsHidden;

	private float playerPingingScan;

	private float updateScanInterval;

	private Dictionary<RectTransform, ScanNodeProperties> scanNodes = new Dictionary<RectTransform, ScanNodeProperties>();

	private List<ScanNodeProperties> nodesOnScreen = new List<ScanNodeProperties>();

	private TextMeshProUGUI[] scanElementText = (TextMeshProUGUI[])(object)new TextMeshProUGUI[2];

	public Animator scanEffectAnimator;

	public AudioClip scanSFX;

	public AudioClip addToScrapTotalSFX;

	public AudioClip finishAddingToTotalSFX;

	private float addToDisplayTotalInterval;

	private bool addingToDisplayTotal;

	[Space(3f)]
	public TextMeshProUGUI totalValueText;

	public Animator scanInfoAnimator;

	public int totalScrapScanned;

	private int totalScrapScannedDisplayNum;

	private int scannedScrapNum;

	private bool addedToScrapCounterThisFrame;

	[Header("Batteries")]
	public Image batteryIcon;

	public TextMeshProUGUI batteryInventoryNumber;

	public Image batteryMeter;

	[Header("Audio")]
	public AudioSource UIAudio;

	public AudioClip criticalInjury;

	public AudioLowPassFilter audioListenerLowPass;

	public AudioClip globalNotificationSFX;

	[Header("Misc UI elements")]
	public RawImage compassImage;

	public float compassOffset;

	public TextMeshProUGUI debugText;

	public GameObject errorLogPanel;

	public TextMeshProUGUI errorLogText;

	private string previousErrorReceived;

	public Image PTTIcon;

	public Animator batteryBlinkUI;

	public TextMeshProUGUI holdingTwoHandedItem;

	public CanvasGroup selfRedCanvasGroup;

	public Image holdInteractionFillAmount;

	public CanvasGroup holdInteractionCanvasGroup;

	public float holdFillAmount;

	public EndOfGameStatUIElements statsUIElements;

	public Animator gameOverAnimator;

	public Animator quotaAnimator;

	public TextMeshProUGUI HUDQuotaNumerator;

	public TextMeshProUGUI HUDQuotaDenominator;

	public Animator planetIntroAnimator;

	public Animator endgameStatsAnimator;

	public TextMeshProUGUI loadingText;

	public Image loadingDarkenScreen;

	public TextMeshProUGUI planetInfoSummaryText;

	public TextMeshProUGUI planetInfoHeaderText;

	public TextMeshProUGUI planetRiskLevelText;

	[Header("Text chat")]
	public TextMeshProUGUI chatText;

	public TextMeshProUGUI typingIndicator;

	public TMP_InputField chatTextField;

	public string lastChatMessage = "";

	public List<string> ChatMessageHistory = new List<string>();

	public Animator playerCouldRecieveTextChatAnimator;

	public StartOfRound playersManager;

	public PlayerActions playerActions;

	public PlayerControllerB localPlayer;

	private bool playerIsCriticallyInjured;

	public TextMeshProUGUI instabilityCounterNumber;

	public TextMeshProUGUI instabilityCounterText;

	private int previousInstability;

	private Terminal terminalScript;

	[Header("Special Graphics")]
	public bool retrievingSteamLeaderboard;

	public Animator signalTranslatorAnimator;

	public TextMeshProUGUI signalTranslatorText;

	public Animator alarmHornEffect;

	public AudioClip shipAlarmHornSFX;

	public Animator deviceChangeAnimator;

	public TextMeshProUGUI deviceChangeText;

	public Animator saveDataIconAnimatorB;

	public Animator HUDAnimator;

	public Animator radiationGraphicAnimator;

	public AudioClip radiationWarningAudio;

	public Animator meteorShowerGraphicAnimator;

	public AudioClip meteorShowerWarningAudio;

	public Image shipLeavingEarlyIcon;

	private float timeSinceDisplayingStatusEffect;

	public Animator statusEffectAnimator;

	public TextMeshProUGUI statusEffectText;

	[Space(3f)]
	public bool increaseHelmetCondensation;

	public Material helmetCondensationMaterial;

	[Space(3f)]
	public Animator moneyRewardsAnimator;

	public TextMeshProUGUI moneyRewardsTotalText;

	public TextMeshProUGUI moneyRewardsListText;

	private Coroutine scrollRewardTextCoroutine;

	public Scrollbar rewardsScrollbar;

	[Space(3f)]
	public CanvasGroup shockTutorialLeftAlpha;

	[Space(3f)]
	public CanvasGroup shockTutorialRightAlpha;

	public int tutorialArrowState;

	public bool setTutorialArrow;

	[Space(3f)]
	public Animator tipsPanelAnimator;

	public TextMeshProUGUI tipsPanelBody;

	public TextMeshProUGUI tipsPanelHeader;

	public AudioClip[] tipsSFX;

	public AudioClip[] warningSFX;

	private Coroutine tipsPanelCoroutine;

	private bool isDisplayingWarning;

	public Animator globalNotificationAnimator;

	public TextMeshProUGUI globalNotificationText;

	public bool sinkingCoveredFace;

	public Animator sinkingUnderAnimator;

	[Header("Dialogue Box")]
	private Coroutine readDialogueCoroutine;

	public TextMeshProUGUI dialogeBoxHeaderText;

	public TextMeshProUGUI dialogeBoxText;

	public Animator dialogueBoxAnimator;

	public AudioSource dialogueBoxSFX;

	public AudioClip[] dialogueBleeps;

	private Coroutine forceChangeTextCoroutine;

	private bool hudHidden;

	[Header("Advertisement UI")]
	public Transform advertItemParent;

	public AudioClip advertMusic;

	public AudioClip advertMusic2;

	public Animator advertAnimator;

	public TextMeshProUGUI advertTopText;

	public TextMeshProUGUI advertBottomText;

	public GameObject emptySuitPrefab;

	public GameObject advertItem;

	private Coroutine displayAdCoroutine;

	[Space(3f)]
	private bool hasLoadedSpectateUI;

	private bool hasGottenPlayerSteamProfilePictures;

	[Header("Spectate UI")]
	public GameObject spectatingPlayerBoxPrefab;

	public Transform SpectateBoxesContainer;

	private Dictionary<Animator, PlayerControllerB> spectatingPlayerBoxes = new Dictionary<Animator, PlayerControllerB>();

	private float updateSpectateBoxesInterval;

	private float yOffsetAmount;

	private int boxesAdded;

	public TextMeshProUGUI spectatingPlayerText;

	private bool displayedSpectatorAFKTip;

	public TextMeshProUGUI spectatorTipText;

	public TextMeshProUGUI holdButtonToEndGameEarlyText;

	public TextMeshProUGUI holdButtonToEndGameEarlyVotesText;

	public Image holdButtonToEndGameEarlyMeter;

	private float holdButtonToEndGameEarlyHoldTime;

	[Header("Time of day UI")]
	public TextMeshProUGUI clockNumber;

	public Image clockIcon;

	public Sprite[] clockIcons;

	private string amPM;

	private string newLine;

	[Space(5f)]
	public Animator gasHelmetAnimator;

	public Volume drunknessFilter;

	public CanvasGroup gasImageAlpha;

	public Volume insanityScreenFilter;

	public Volume flashbangScreenFilter;

	public float flashFilter;

	public Volume underwaterScreenFilter;

	public bool setUnderwaterFilter;

	public AudioSource breathingUnderwaterAudio;

	[Header("Player levelling")]
	public PlayerLevel[] playerLevels;

	public int localPlayerLevel;

	public int localPlayerXP;

	public TextMeshProUGUI playerLevelText;

	public TextMeshProUGUI playerLevelXPCounter;

	public Image playerLevelMeter;

	public AudioClip levelIncreaseSFX;

	public AudioClip levelDecreaseSFX;

	public AudioClip decreaseXPSFX;

	public AudioClip increaseXPSFX;

	public Animator playerLevelBoxAnimator;

	public AudioSource LevellingAudio;

	[Header("Profit quota/deadline")]
	public Animator reachedProfitQuotaAnimator;

	public TextMeshProUGUI newProfitQuotaText;

	public TextMeshProUGUI reachedProfitQuotaBonusText;

	public TextMeshProUGUI profitQuotaDaysLeftText;

	public TextMeshProUGUI profitQuotaDaysLeftText2;

	public AudioClip newProfitQuotaSFX;

	public AudioClip reachedQuotaSFX;

	public AudioClip OneDayToMeetQuotaSFX;

	public AudioClip profitQuotaDaysLeftCalmSFX;

	[Space(3f)]
	public Animator playersFiredAnimator;

	public TextMeshProUGUI EndOfRunStatsText;

	public bool displayingNewQuota;

	[Header("Displaying collected scrap")]
	public List<GrabbableObject> itemsToBeDisplayed = new List<GrabbableObject>();

	public ScrapItemHUDDisplay[] ScrapItemBoxes;

	private int boxesDisplaying;

	public Coroutine displayingItemCoroutine;

	private int bottomBoxIndex;

	public int bottomBoxYPosition;

	public Material hologramMaterial;

	public AudioClip displayCollectedScrapSFX;

	public AudioClip displayCollectedScrapSFXSmall;

	private int nextBoxIndex;

	[Space(5f)]
	public TextMeshProUGUI buildModeControlTip;

	public bool hasSetSavedValues;

	private float noLivingPlayersAtKeyboardTimer;

	public SpecialHUDMenuObject[] specialHUDMenus;

	public SpecialHUDMenu currentSpecialMenu;

	public Texture2D defaultCursorTex;

	public Texture2D handOpenCursorTex;

	public Texture2D handClosedCursorTex;

	public static HUDManager Instance { get; private set; }

	public void SetMouseCursorSprite(Texture2D cursorSprite, Vector2 hotspot = default(Vector2))
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)cursorSprite == (Object)null)
		{
			Cursor.SetCursor(defaultCursorTex, new Vector2(0f, 0f), (CursorMode)0);
		}
		else
		{
			Cursor.SetCursor(cursorSprite, hotspot, (CursorMode)0);
		}
	}

	public void OpenSpecialMenu(SpecialHUDMenu menu)
	{
		ShipBuildModeManager.Instance.CancelBuildMode();
		CloseSpecialMenus();
		currentSpecialMenu = menu;
		specialHUDMenus[(int)(menu - 1)].rootObject.SetActive(true);
		specialHUDMenus[(int)(menu - 1)].SpecialHUDAnimator.SetBool("Opened", true);
		if (StartOfRound.Instance.localPlayerUsingController)
		{
			EventSystem.current.SetSelectedGameObject(specialHUDMenus[(int)(menu - 1)].defaultSelectedGameObject);
		}
	}

	public void CloseSpecialMenus()
	{
		currentSpecialMenu = SpecialHUDMenu.None;
		for (int i = 0; i < specialHUDMenus.Length; i++)
		{
			specialHUDMenus[i].SpecialHUDAnimator.SetBool("Opened", false);
			specialHUDMenus[i].rootObject.SetActive(false);
		}
		EventSystem.current.SetSelectedGameObject((GameObject)null);
	}

	private void OnEnable()
	{
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("EnableChat", false).performed += EnableChat_performed;
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("OpenMenu", false).performed += OpenMenu_performed;
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("SubmitChat", false).performed += SubmitChat_performed;
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("PingScan", false).performed += PingScan_performed;
		InputSystem.onDeviceChange += OnDeviceChange;
		playerActions.Movement.Enable();
	}

	private void OnDisable()
	{
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("EnableChat", false).performed -= EnableChat_performed;
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("OpenMenu", false).performed -= OpenMenu_performed;
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("SubmitChat", false).performed -= SubmitChat_performed;
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("PingScan", false).performed -= PingScan_performed;
		InputSystem.onDeviceChange -= OnDeviceChange;
		playerActions.Movement.Disable();
	}

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
			playerActions = new PlayerActions();
			playersManager = Object.FindObjectOfType<StartOfRound>();
			HUDElements = new HUDElement[7] { Inventory, Chat, PlayerInfo, Tooltips, InstabilityCounter, Clock, Compass };
			scanNodesHit = (RaycastHit[])(object)new RaycastHit[13];
			((MonoBehaviour)this).StartCoroutine(waitUntilLocalPlayerControllerInitialized());
		}
		else
		{
			if ((Object)(object)((Component)Instance).gameObject != (Object)null)
			{
				Object.Destroy((Object)(object)((Component)Instance).gameObject);
			}
			else
			{
				Object.Destroy((Object)(object)Instance);
			}
			Instance = this;
		}
	}

	private void Start()
	{
		terminalScript = Object.FindObjectOfType<Terminal>();
	}

	private void OnDeviceChange(InputDevice device, InputDeviceChange deviceChange)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Invalid comparison between Unknown and I4
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Invalid comparison between Unknown and I4
		bool flag = false;
		if ((int)deviceChange != 2)
		{
			if ((int)deviceChange == 3)
			{
				flag = true;
				((TMP_Text)deviceChangeText).text = "Controller connected";
			}
		}
		else
		{
			flag = true;
			((TMP_Text)deviceChangeText).text = "Controller disconnected";
		}
		if (flag)
		{
			deviceChangeAnimator.SetTrigger("display");
		}
	}

	public void SetSavedValues(int playerObjectId = -1)
	{
		if (playerObjectId == -1)
		{
			playerObjectId = (int)GameNetworkManager.Instance.localPlayerController.playerClientId;
		}
		if (!hasSetSavedValues)
		{
			hasSetSavedValues = true;
			localPlayerLevel = ES3.Load<int>("PlayerLevel", "LCGeneralSaveData", 0);
			localPlayerXP = ES3.Load<int>("PlayerXPNum", "LCGeneralSaveData", 0);
			bool enabled = ES3.Load<bool>("playedDuringBeta", "LCGeneralSaveData", true);
			((Renderer)StartOfRound.Instance.allPlayerScripts[playerObjectId].playerBetaBadgeMesh).enabled = enabled;
			Debug.Log((object)"Has beta?: {hasBeta}");
			Debug.Log((object)string.Format("Has beta save data: {0}", ES3.Load<bool>("playedDuringBeta", "LCGeneralSaveData", true)));
			if (ES3.Load<int>("FinishedShockMinigame", "LCGeneralSaveData", 0) < 2)
			{
				setTutorialArrow = true;
			}
		}
	}

	private IEnumerator waitUntilLocalPlayerControllerInitialized()
	{
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null));
		SetSavedValues();
	}

	public void SetNearDepthOfFieldEnabled(bool enabled)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Expected O, but got Unknown
		float num = ((!enabled) ? 0.2f : 0.5f);
		DepthOfField val = default(DepthOfField);
		if (playerGraphicsVolume.sharedProfile.TryGet<DepthOfField>(ref val))
		{
			((VolumeParameter)val.nearFocusEnd).SetValue((VolumeParameter)new MinFloatParameter(num, 0f, true));
		}
	}

	private void SetAdvertisementItemToCorrectPosition()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)advertItem != (Object)null)
		{
			advertItem.transform.localPosition = Vector3.zero;
		}
	}

	public void ChooseAdItem()
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		for (int num = ((Component)advertItemParent).transform.childCount - 1; num >= 0; num--)
		{
			Object.Destroy((Object)(object)((Component)((Component)advertItemParent).transform.GetChild(num)).gameObject);
		}
		advertItem = null;
		bool flag = false;
		int num2 = 100;
		int num3 = -1;
		Terminal terminal = Object.FindObjectOfType<Terminal>();
		for (int i = 0; i < terminal.itemSalesPercentages.Length && i < terminal.buyableItemsList.Length; i++)
		{
			Item item = terminal.buyableItemsList[i];
			if (terminal.itemSalesPercentages[i] < num2 && item.itemId != 6 && item.itemId != 7 && item.itemId != 1 && item.itemId != 19)
			{
				num2 = terminal.itemSalesPercentages[i];
				num3 = i;
			}
		}
		Debug.Log((object)$"Steepest sale found : {num2}; index: {num3}");
		string itemName = "";
		string saleText = ChooseSaleText();
		if (num2 <= 70)
		{
			Debug.Log((object)"Putting a tool in the ad");
			Item item = terminal.buyableItemsList[num3];
			CreateToolAdModelAndDisplayAdClientRpc(num2, num3);
			CreateToolAdModel(num2, item);
			saleText = $"{100 - num2}% OFF!";
			itemName = item.itemName;
			flag = true;
		}
		else
		{
			Debug.Log((object)"Putting furniture in the ad");
			List<TerminalNode> list = new List<TerminalNode>();
			for (int j = 0; j < terminal.ShipDecorSelection.Count; j++)
			{
				if (!StartOfRound.Instance.unlockablesList.unlockables[terminal.ShipDecorSelection[j].shipUnlockableID].hasBeenUnlockedByPlayer)
				{
					list.Add(terminal.ShipDecorSelection[j]);
				}
			}
			if (list.Count > 0)
			{
				int num4 = Random.Range(0, list.Count);
				int num5 = -1;
				for (int k = 0; k < terminal.ShipDecorSelection.Count; k++)
				{
					if (terminal.ShipDecorSelection[k].shipUnlockableID == list[num4].shipUnlockableID)
					{
						num5 = k;
						Debug.Log((object)$"Randomly chose item index : {num5} / {num4}");
						break;
					}
				}
				CreateFurnitureAdModelAndDisplayAdClientRpc(num5);
				CreateFurnitureAdModel(StartOfRound.Instance.unlockablesList.unlockables[list[num4].shipUnlockableID]);
				itemName = StartOfRound.Instance.unlockablesList.unlockables[list[num4].shipUnlockableID].unlockableName;
				flag = true;
			}
			else
			{
				Debug.Log((object)"All furniture already purchased. Not displaying ad");
			}
		}
		if (flag)
		{
			BeginDisplayAd(itemName, saleText);
		}
	}

	private string ChooseSaleText()
	{
		string result = "AVAILABLE NOW!";
		int num = new Random(StartOfRound.Instance.randomMapSeed).Next(0, 100);
		if (num < 3)
		{
			result = "CURES CANCER!";
		}
		else if (num < 6)
		{
			result = "NO WAY!";
		}
		else if (num < 30)
		{
			result = "LIMITED TIME ONLY!";
		}
		else if (num < 60)
		{
			result = "GET YOURS TODAY!";
		}
		return result;
	}

	[ClientRpc]
	public void CreateFurnitureAdModelAndDisplayAdClientRpc(int indexInShipDecorList)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1647277829u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, indexInShipDecorList);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1647277829u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
		{
			for (int num = ((Component)advertItemParent).transform.childCount - 1; num >= 0; num--)
			{
				Object.Destroy((Object)(object)((Component)((Component)advertItemParent).transform.GetChild(num)).gameObject);
			}
			advertItem = null;
			if (!GameNetworkManager.Instance.localPlayerController.isPlayerDead)
			{
				UnlockableItem unlockable = StartOfRound.Instance.unlockablesList.unlockables[terminalScript.ShipDecorSelection[indexInShipDecorList].shipUnlockableID];
				CreateFurnitureAdModel(unlockable);
			}
			BeginDisplayAd(StartOfRound.Instance.unlockablesList.unlockables[terminalScript.ShipDecorSelection[indexInShipDecorList].shipUnlockableID].unlockableName, ChooseSaleText());
		}
	}

	[ClientRpc]
	public void CreateToolAdModelAndDisplayAdClientRpc(int steepestSale, int itemIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(229674455u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, steepestSale);
			BytePacker.WriteValueBitPacked(val2, itemIndex);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 229674455u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
		{
			for (int num = ((Component)advertItemParent).transform.childCount - 1; num >= 0; num--)
			{
				Object.Destroy((Object)(object)((Component)((Component)advertItemParent).transform.GetChild(num)).gameObject);
			}
			advertItem = null;
			Item item = terminalScript.buyableItemsList[itemIndex];
			if (!GameNetworkManager.Instance.localPlayerController.isPlayerDead)
			{
				CreateToolAdModel(steepestSale, item);
			}
			BeginDisplayAd(item.itemName, $"{steepestSale}% OFF!");
		}
	}

	public void CreateFurnitureAdModel(UnlockableItem unlockable)
	{
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Expected O, but got Unknown
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)("Unlockable name: " + unlockable.unlockableName));
		if (unlockable.unlockableType == 0)
		{
			advertItem = Object.Instantiate<GameObject>(emptySuitPrefab, advertItemParent, false);
			((Renderer)advertItem.GetComponentInChildren<SkinnedMeshRenderer>()).sharedMaterial = unlockable.suitMaterial;
			advertItem.transform.localPosition = Vector3.zero;
			advertItem.transform.localScale = advertItem.transform.localScale * 58f;
			foreach (Transform item in advertItem.transform)
			{
				Transform val = item;
				if (((Component)val).CompareTag("Gravel"))
				{
					GameObject obj = Object.Instantiate<GameObject>(unlockable.headCostumeObject, ((Component)val).transform.position, ((Component)val).transform.rotation);
					obj.transform.parent = val;
					obj.transform.localScale = Vector3.one;
					((Component)obj.GetComponentInChildren<Renderer>()).gameObject.layer = 5;
				}
				else if (((Component)val).CompareTag("Puddle"))
				{
					GameObject obj2 = Object.Instantiate<GameObject>(unlockable.lowerTorsoCostumeObject, ((Component)val).transform.position, ((Component)val).transform.rotation);
					obj2.transform.parent = val;
					obj2.transform.localScale = Vector3.one;
					((Component)obj2.GetComponentInChildren<Renderer>()).gameObject.layer = 5;
				}
			}
		}
		else
		{
			advertItem = Object.Instantiate<GameObject>(unlockable.prefabObject, advertItemParent, false);
			advertItem.transform.localPosition = Vector3.zero;
			advertItem.transform.localScale = advertItem.transform.localScale * 58f;
			Object.Destroy((Object)(object)advertItem.GetComponent<AutoParentToShip>());
			Object.Destroy((Object)(object)advertItem.GetComponent<NetworkObject>());
			Object.Destroy((Object)(object)advertItem.GetComponentInChildren<PlaceableShipObject>());
			Renderer[] componentsInChildren = advertItem.GetComponentsInChildren<Renderer>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				if (((Component)componentsInChildren[i]).gameObject.layer == 9 || ((Component)componentsInChildren[i]).gameObject.layer == 26)
				{
					Object.Destroy((Object)(object)((Component)componentsInChildren[i]).gameObject);
				}
				else
				{
					((Component)componentsInChildren[i]).gameObject.layer = 5;
				}
			}
		}
		advertItem.SetActive(true);
	}

	public void CreateToolAdModel(int salePercentage, Item item)
	{
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		advertItem = Object.Instantiate<GameObject>(item.spawnPrefab, advertItemParent);
		Object.Destroy((Object)(object)advertItem.GetComponent<NetworkObject>());
		Object.Destroy((Object)(object)advertItem.GetComponent<GrabbableObject>());
		Object.Destroy((Object)(object)advertItem.GetComponent<Collider>());
		Collider[] componentsInChildren = advertItem.GetComponentsInChildren<Collider>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].enabled = false;
		}
		advertItem.transform.localPosition = Vector3.zero;
		advertItem.transform.localScale = advertItem.transform.localScale * 155f;
		advertItem.transform.rotation = Quaternion.Euler(item.restingRotation);
		Renderer[] componentsInChildren2 = advertItem.GetComponentsInChildren<Renderer>();
		for (int j = 0; j < componentsInChildren2.Length; j++)
		{
			if (((Component)componentsInChildren2[j]).gameObject.layer == 22)
			{
				Object.Destroy((Object)(object)((Component)componentsInChildren2[j]).gameObject);
			}
			else if (((Component)componentsInChildren2[j]).gameObject.layer == 14)
			{
				Object.Destroy((Object)(object)((Component)componentsInChildren2[j]).gameObject);
			}
			else
			{
				((Component)componentsInChildren2[j]).gameObject.layer = 5;
			}
		}
		advertItem.SetActive(true);
	}

	public void BeginDisplayAd(string itemName, string saleText)
	{
		((TMP_Text)advertTopText).text = itemName;
		((TMP_Text)advertBottomText).text = saleText;
		if (displayAdCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(displayAdCoroutine);
		}
		displayAdCoroutine = ((MonoBehaviour)this).StartCoroutine(displayAd());
	}

	private IEnumerator displayAd()
	{
		if (!GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			advertAnimator.SetTrigger("PopUpAd");
		}
		if (new Random(StartOfRound.Instance.randomMapSeed).Next(0, 10) < 7)
		{
			UIAudio.PlayOneShot(advertMusic, 0.6f);
		}
		else
		{
			UIAudio.PlayOneShot(advertMusic2, 0.6f);
		}
		yield return (object)new WaitForSeconds(14f);
		for (int num = ((Component)advertItemParent).transform.childCount - 1; num >= 0; num--)
		{
			Object.Destroy((Object)(object)((Component)((Component)advertItemParent).transform.GetChild(num)).gameObject);
		}
	}

	public void UpdateHealthUI(int health, bool hurtPlayer = true)
	{
		if (health < 100)
		{
			selfRedCanvasGroup.alpha = (float)(100 - health) / 100f;
			if (health >= 20 && playerIsCriticallyInjured)
			{
				playerIsCriticallyInjured = false;
				HUDAnimator.SetTrigger("HealFromCritical");
			}
		}
		else
		{
			selfRedCanvasGroup.alpha = 0f;
		}
		if (hurtPlayer && health > 0)
		{
			if (health < 20)
			{
				playerIsCriticallyInjured = true;
				HUDAnimator.SetTrigger("CriticalHit");
				UIAudio.PlayOneShot(criticalInjury, 1f);
			}
			else
			{
				HUDAnimator.SetTrigger("SmallHit");
			}
		}
	}

	private void AddChatMessage(string chatMessage, string nameOfUserWhoTyped = "", int playerWhoSent = -1, bool dontRepeat = false)
	{
		if ((!dontRepeat || !(lastChatMessage == chatMessage)) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerWhoSent)
		{
			lastChatMessage = chatMessage;
			PingHUDElement(Chat, 4f);
			if (ChatMessageHistory.Count >= 4)
			{
				((TMP_Text)chatText).text.Remove(0, ChatMessageHistory[0].Length);
				ChatMessageHistory.Remove(ChatMessageHistory[0]);
			}
			StringBuilder stringBuilder = new StringBuilder(chatMessage);
			stringBuilder.Replace("[playerNum0]", StartOfRound.Instance.allPlayerScripts[0].playerUsername);
			stringBuilder.Replace("[playerNum1]", StartOfRound.Instance.allPlayerScripts[1].playerUsername);
			stringBuilder.Replace("[playerNum2]", StartOfRound.Instance.allPlayerScripts[2].playerUsername);
			stringBuilder.Replace("[playerNum3]", StartOfRound.Instance.allPlayerScripts[3].playerUsername);
			chatMessage = stringBuilder.ToString();
			string item = ((!string.IsNullOrEmpty(nameOfUserWhoTyped)) ? ("<color=#FF0000>" + nameOfUserWhoTyped + "</color>: <color=#FFFF00>'" + chatMessage + "'</color>") : ("<color=#7069ff>" + chatMessage + "</color>"));
			ChatMessageHistory.Add(item);
			((TMP_Text)chatText).text = "";
			for (int i = 0; i < ChatMessageHistory.Count; i++)
			{
				TextMeshProUGUI obj = chatText;
				((TMP_Text)obj).text = ((TMP_Text)obj).text + "\n" + ChatMessageHistory[i];
			}
		}
	}

	public void AddTextToChatOnServer(string chatMessage, int playerId = -1)
	{
		if (playerId != -1)
		{
			AddChatMessage(chatMessage, playersManager.allPlayerScripts[playerId].playerUsername);
			AddPlayerChatMessageServerRpc(chatMessage, playerId);
		}
		else
		{
			AddTextMessageServerRpc(chatMessage);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void AddPlayerChatMessageServerRpc(string chatMessage, int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2930587515u, val, (RpcDelivery)0);
			bool flag = chatMessage != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(chatMessage, false);
			}
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2930587515u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && chatMessage.Length <= 50)
		{
			AddPlayerChatMessageClientRpc(chatMessage, playerId);
		}
	}

	[ClientRpc]
	private void AddPlayerChatMessageClientRpc(string chatMessage, int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(168728662u, val, (RpcDelivery)0);
			bool flag = chatMessage != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(chatMessage, false);
			}
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 168728662u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playersManager.allPlayerScripts[playerId].isPlayerDead == GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			bool flag2 = GameNetworkManager.Instance.localPlayerController.holdingWalkieTalkie && StartOfRound.Instance.allPlayerScripts[playerId].holdingWalkieTalkie;
			if (!(Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)playersManager.allPlayerScripts[playerId]).transform.position) > 25f) || flag2)
			{
				AddChatMessage(chatMessage, playersManager.allPlayerScripts[playerId].playerUsername, playerId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void AddTextMessageServerRpc(string chatMessage)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2787681914u, val, (RpcDelivery)0);
			bool flag = chatMessage != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(chatMessage, false);
			}
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2787681914u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			AddTextMessageClientRpc(chatMessage);
		}
	}

	[ClientRpc]
	private void AddTextMessageClientRpc(string chatMessage)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1568596901u, val, (RpcDelivery)0);
			bool flag = chatMessage != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(chatMessage, false);
			}
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1568596901u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			AddChatMessage(chatMessage, "", -1, dontRepeat: true);
		}
	}

	private void SubmitChat_performed(CallbackContext context)
	{
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		localPlayer = GameNetworkManager.Instance.localPlayerController;
		if (!((CallbackContext)(ref context)).performed || (Object)(object)localPlayer == (Object)null || !localPlayer.isTypingChat || ((!((NetworkBehaviour)localPlayer).IsOwner || (((NetworkBehaviour)this).IsServer && !localPlayer.isHostPlayerObject)) && !localPlayer.isTestingPlayer) || localPlayer.isPlayerDead)
		{
			return;
		}
		if (!string.IsNullOrEmpty(chatTextField.text) && chatTextField.text.Length < 50)
		{
			AddTextToChatOnServer(chatTextField.text, (int)localPlayer.playerClientId);
		}
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled && Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position) > 24.4f && (!GameNetworkManager.Instance.localPlayerController.holdingWalkieTalkie || !StartOfRound.Instance.allPlayerScripts[i].holdingWalkieTalkie))
			{
				playerCouldRecieveTextChatAnimator.SetTrigger("ping");
				break;
			}
		}
		localPlayer.isTypingChat = false;
		chatTextField.text = "";
		EventSystem.current.SetSelectedGameObject((GameObject)null);
		PingHUDElement(Chat);
		((Behaviour)typingIndicator).enabled = false;
	}

	private void EnableChat_performed(CallbackContext context)
	{
		localPlayer = GameNetworkManager.Instance.localPlayerController;
		if (((CallbackContext)(ref context)).performed && !((Object)(object)localPlayer == (Object)null) && ((((NetworkBehaviour)localPlayer).IsOwner && (!((NetworkBehaviour)this).IsServer || localPlayer.isHostPlayerObject)) || localPlayer.isTestingPlayer) && !localPlayer.isPlayerDead && !localPlayer.inTerminalMenu)
		{
			ShipBuildModeManager.Instance.CancelBuildMode();
			localPlayer.isTypingChat = true;
			((Selectable)chatTextField).Select();
			PingHUDElement(Chat, 0.1f, 1f, 1f);
			((Behaviour)typingIndicator).enabled = true;
		}
	}

	private void OpenMenu_performed(CallbackContext context)
	{
		localPlayer = GameNetworkManager.Instance.localPlayerController;
		if (!((Object)(object)localPlayer == (Object)null) && localPlayer.isTypingChat && ((CallbackContext)(ref context)).performed && ((((NetworkBehaviour)localPlayer).IsOwner && (!((NetworkBehaviour)this).IsServer || localPlayer.isHostPlayerObject)) || localPlayer.isTestingPlayer))
		{
			localPlayer.isTypingChat = false;
			EventSystem.current.SetSelectedGameObject((GameObject)null);
			chatTextField.text = "";
			PingHUDElement(Chat, 1f);
			((Behaviour)typingIndicator).enabled = false;
		}
	}

	private void PingScan_performed(CallbackContext context)
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && ((CallbackContext)(ref context)).performed && CanPlayerScan() && playerPingingScan <= -1f)
		{
			playerPingingScan = 0.3f;
			((Component)scanEffectAnimator).transform.position = ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position;
			scanEffectAnimator.SetTrigger("scan");
			PingHUDElement(Compass, 1f, 0.8f, 0.12f);
			UIAudio.PlayOneShot(scanSFX);
		}
	}

	private bool CanPlayerScan()
	{
		if (!GameNetworkManager.Instance.localPlayerController.inSpecialInteractAnimation)
		{
			return !GameNetworkManager.Instance.localPlayerController.isPlayerDead;
		}
		return false;
	}

	public void UpdateBoxesSpectateUI()
	{
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB playerScript;
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			playerScript = StartOfRound.Instance.allPlayerScripts[i];
			if (!playerScript.isPlayerDead)
			{
				if (playerScript.isPlayerControlled || !spectatingPlayerBoxes.Values.Contains(playerScript))
				{
					continue;
				}
				Debug.Log((object)"Removing player spectate box since they disconnected");
				Animator key = spectatingPlayerBoxes.FirstOrDefault((KeyValuePair<Animator, PlayerControllerB> x) => (Object)(object)x.Value == (Object)(object)playerScript).Key;
				if (((Component)key).gameObject.activeSelf)
				{
					for (int j = 0; j < spectatingPlayerBoxes.Count; j++)
					{
						RectTransform component = ((Component)spectatingPlayerBoxes.ElementAt(j).Key).gameObject.GetComponent<RectTransform>();
						if (component.anchoredPosition.y <= -70f * (float)boxesAdded + 1f)
						{
							component.anchoredPosition = new Vector2(component.anchoredPosition.x, component.anchoredPosition.y + 70f);
						}
					}
					yOffsetAmount += 70f;
				}
				spectatingPlayerBoxes.Remove(key);
				Object.Destroy((Object)(object)((Component)key).gameObject);
			}
			else if (spectatingPlayerBoxes.Values.Contains(playerScript))
			{
				GameObject gameObject = ((Component)spectatingPlayerBoxes.FirstOrDefault((KeyValuePair<Animator, PlayerControllerB> x) => (Object)(object)x.Value == (Object)(object)playerScript).Key).gameObject;
				if (!gameObject.activeSelf)
				{
					RectTransform component2 = gameObject.GetComponent<RectTransform>();
					component2.anchoredPosition = new Vector2(component2.anchoredPosition.x, yOffsetAmount);
					boxesAdded++;
					gameObject.SetActive(true);
					yOffsetAmount -= 70f;
				}
			}
			else
			{
				GameObject gameObject = Object.Instantiate<GameObject>(spectatingPlayerBoxPrefab, SpectateBoxesContainer, false);
				gameObject.SetActive(true);
				RectTransform component3 = gameObject.GetComponent<RectTransform>();
				component3.anchoredPosition = new Vector2(component3.anchoredPosition.x, yOffsetAmount);
				yOffsetAmount -= 70f;
				boxesAdded++;
				spectatingPlayerBoxes.Add(gameObject.GetComponent<Animator>(), playerScript);
				((TMP_Text)gameObject.GetComponentInChildren<TextMeshProUGUI>()).text = playerScript.playerUsername;
				if (!GameNetworkManager.Instance.disableSteam)
				{
					FillImageWithSteamProfile(gameObject.GetComponent<RawImage>(), SteamId.op_Implicit(playerScript.playerSteamId));
				}
			}
		}
	}

	public static async void FillImageWithSteamProfile(RawImage image, SteamId steamId, bool large = true)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if (SteamClient.IsValid)
		{
			if (large)
			{
				image.texture = (Texture)(object)GetTextureFromImage(await SteamFriends.GetLargeAvatarAsync(steamId));
			}
			else
			{
				image.texture = (Texture)(object)GetTextureFromImage(await SteamFriends.GetSmallAvatarAsync(steamId));
			}
		}
	}

	public static Texture2D GetTextureFromImage(Image? image)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected O, but got Unknown
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		Texture2D val = new Texture2D((int)image.Value.Width, (int)image.Value.Height);
		Debug.Log((object)"Slot K");
		for (int i = 0; i < image.Value.Width; i++)
		{
			for (int j = 0; j < image.Value.Height; j++)
			{
				Image value = image.Value;
				Color pixel = ((Image)(ref value)).GetPixel(i, j);
				val.SetPixel(i, (int)image.Value.Height - j, new Color((float)(int)pixel.r / 255f, (float)(int)pixel.g / 255f, (float)(int)pixel.b / 255f, (float)(int)pixel.a / 255f));
			}
		}
		Debug.Log((object)"Slot L");
		val.Apply();
		return val;
	}

	public void RemoveSpectateUI()
	{
		for (int i = 0; i < spectatingPlayerBoxes.Count; i++)
		{
			((Component)spectatingPlayerBoxes.ElementAt(i).Key).gameObject.SetActive(false);
			boxesAdded--;
		}
		yOffsetAmount = 0f;
		hasGottenPlayerSteamProfilePictures = false;
		hasLoadedSpectateUI = false;
	}

	private void UpdateSpectateBoxSpeakerIcons()
	{
		if ((Object)(object)StartOfRound.Instance.voiceChatModule == (Object)null)
		{
			return;
		}
		bool flag = false;
		for (int i = 0; i < spectatingPlayerBoxes.Count; i++)
		{
			PlayerControllerB value = spectatingPlayerBoxes.ElementAt(i).Value;
			if (!value.isPlayerControlled && !value.isPlayerDead)
			{
				continue;
			}
			if ((Object)(object)value == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				if (!string.IsNullOrEmpty(StartOfRound.Instance.voiceChatModule.LocalPlayerName))
				{
					VoicePlayerState val = StartOfRound.Instance.voiceChatModule.FindPlayer(StartOfRound.Instance.voiceChatModule.LocalPlayerName);
					if (val != null)
					{
						spectatingPlayerBoxes.ElementAt(i).Key.SetBool("speaking", val.IsSpeaking && val.Amplitude > 0.005f);
					}
				}
			}
			else if (value.voicePlayerState == null)
			{
				if (!flag)
				{
					flag = true;
					StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
				}
			}
			else
			{
				VoicePlayerState val = value.voicePlayerState;
				spectatingPlayerBoxes.ElementAt(i).Key.SetBool("speaking", val.IsSpeaking && val.Amplitude > 0.005f && !val.IsLocallyMuted);
			}
		}
	}

	public void SetSpectatingTextToPlayer(PlayerControllerB playerScript)
	{
		if ((Object)(object)playerScript == (Object)null)
		{
			((TMP_Text)spectatingPlayerText).text = "";
		}
		else
		{
			((TMP_Text)spectatingPlayerText).text = "(Spectating: " + playerScript.playerUsername + ")";
		}
	}

	private void DisplayScrapItemsOnHud()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		if (boxesDisplaying < ScrapItemBoxes.Length && itemsToBeDisplayed.Count > 0)
		{
			DisplayNewScrapFound();
		}
		if (boxesDisplaying <= 0 || !(ScrapItemBoxes[bottomBoxIndex].UIContainer.anchoredPosition.y < (float)bottomBoxYPosition))
		{
			return;
		}
		for (int i = 0; i < ScrapItemBoxes.Length; i++)
		{
			RectTransform uIContainer = ScrapItemBoxes[i].UIContainer;
			uIContainer.anchoredPosition += Vector2.up * (Time.deltaTime * 325f);
		}
		if (ScrapItemBoxes[bottomBoxIndex].UIContainer.anchoredPosition.y > (float)bottomBoxYPosition)
		{
			float num = ScrapItemBoxes[bottomBoxIndex].UIContainer.anchoredPosition.y - (float)bottomBoxYPosition;
			num -= 0.01f;
			for (int j = 0; j < ScrapItemBoxes.Length; j++)
			{
				RectTransform uIContainer2 = ScrapItemBoxes[j].UIContainer;
				uIContainer2.anchoredPosition -= Vector2.up * num;
			}
		}
	}

	private void SetScreenFilters()
	{
		UnderwaterScreenFilters();
		drunknessFilter.weight = Mathf.Lerp(drunknessFilter.weight, StartOfRound.Instance.drunknessSideEffect.Evaluate(GameNetworkManager.Instance.localPlayerController.drunkness), 5f * Time.deltaTime);
		gasImageAlpha.alpha = drunknessFilter.weight * 1.5f;
		if (StartOfRound.Instance.fearLevel > 0.4f)
		{
			insanityScreenFilter.weight = Mathf.Lerp(insanityScreenFilter.weight, StartOfRound.Instance.fearLevel, 5f * Time.deltaTime);
		}
		else
		{
			insanityScreenFilter.weight = Mathf.Lerp(insanityScreenFilter.weight, 0f, 2f * Time.deltaTime);
		}
		sinkingUnderAnimator.SetBool("cover", sinkingCoveredFace);
		if (flashFilter > 0f)
		{
			flashFilter -= Time.deltaTime * 0.16f;
		}
		flashbangScreenFilter.weight = Mathf.Min(1f, flashFilter);
		HelmetCondensationDrops();
	}

	private void HelmetCondensationDrops()
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		if (!increaseHelmetCondensation)
		{
			if (helmetCondensationMaterial.color.a > 0f)
			{
				Color color = helmetCondensationMaterial.color;
				color.a = Mathf.Clamp(color.a - Time.deltaTime / 2f, 0f, 0.27f);
				helmetCondensationMaterial.color = color;
			}
		}
		else
		{
			if (helmetCondensationMaterial.color.a < 1f)
			{
				Color color2 = helmetCondensationMaterial.color;
				color2.a = Mathf.Clamp(color2.a + Time.deltaTime / 2f, 0f, 0.27f);
				helmetCondensationMaterial.color = color2;
			}
			increaseHelmetCondensation = false;
		}
		if ((TimeOfDay.Instance.effects[1].effectEnabled || TimeOfDay.Instance.effects[2].effectEnabled) && !TimeOfDay.Instance.insideLighting && Vector3.Angle(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward, Vector3.up) < 45f)
		{
			increaseHelmetCondensation = true;
		}
	}

	private void UnderwaterScreenFilters()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead && (Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript != (Object)null)
		{
			PlayerControllerB spectatedPlayerScript = GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript;
			if ((Object)(object)spectatedPlayerScript.underwaterCollider != (Object)null)
			{
				Bounds bounds = spectatedPlayerScript.underwaterCollider.bounds;
				if (((Bounds)(ref bounds)).Contains(((Component)StartOfRound.Instance.spectateCamera).transform.position))
				{
					flag = true;
				}
			}
		}
		if (setUnderwaterFilter || flag)
		{
			((Behaviour)audioListenerLowPass).enabled = true;
			audioListenerLowPass.cutoffFrequency = Mathf.Lerp(audioListenerLowPass.cutoffFrequency, 700f, 10f * Time.deltaTime);
			underwaterScreenFilter.weight = 1f;
			breathingUnderwaterAudio.volume = Mathf.Lerp(breathingUnderwaterAudio.volume, 1f, 10f * Time.deltaTime);
			if (!flag && !breathingUnderwaterAudio.isPlaying)
			{
				breathingUnderwaterAudio.Play();
			}
			return;
		}
		if (audioListenerLowPass.cutoffFrequency >= 19000f)
		{
			((Behaviour)audioListenerLowPass).enabled = false;
		}
		else
		{
			audioListenerLowPass.cutoffFrequency = Mathf.Lerp(audioListenerLowPass.cutoffFrequency, 20000f, 10f * Time.deltaTime);
		}
		if (underwaterScreenFilter.weight < 0.05f)
		{
			underwaterScreenFilter.weight = 0f;
			breathingUnderwaterAudio.Stop();
		}
		else
		{
			breathingUnderwaterAudio.volume = Mathf.Lerp(breathingUnderwaterAudio.volume, 0f, 10f * Time.deltaTime);
			underwaterScreenFilter.weight = Mathf.Lerp(underwaterScreenFilter.weight, 0f, 10f * Time.deltaTime);
		}
	}

	private void Update()
	{
		//IL_04b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d6: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		SetAdvertisementItemToCorrectPosition();
		DisplayScrapItemsOnHud();
		SetScreenFilters();
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			if (!hasLoadedSpectateUI)
			{
				hasLoadedSpectateUI = true;
				Debug.Log((object)"Adding boxes");
				UpdateBoxesSpectateUI();
			}
			if (StartOfRound.Instance.shipIsLeaving || !StartOfRound.Instance.currentLevel.planetHasTime)
			{
				holdButtonToEndGameEarlyHoldTime = 0f;
				((Component)holdButtonToEndGameEarlyMeter).gameObject.SetActive(false);
				((TMP_Text)holdButtonToEndGameEarlyText).text = "";
				((TMP_Text)holdButtonToEndGameEarlyVotesText).text = "";
			}
			else if (!TimeOfDay.Instance.shipLeavingAlertCalled)
			{
				((Behaviour)holdButtonToEndGameEarlyText).enabled = true;
				if (!TimeOfDay.Instance.votedShipToLeaveEarlyThisRound)
				{
					DisplaySpectatorVoteTip();
					if (StartOfRound.Instance.localPlayerUsingController)
					{
						((TMP_Text)holdButtonToEndGameEarlyText).text = "Tell autopilot ship to leave early : [R-trigger] (Hold)";
					}
					else
					{
						((TMP_Text)holdButtonToEndGameEarlyText).text = "Tell autopilot ship to leave early : [RMB] (Hold)";
					}
					if (playerActions.Movement.PingScan.IsPressed())
					{
						holdButtonToEndGameEarlyHoldTime += Time.deltaTime;
						((Component)holdButtonToEndGameEarlyMeter).gameObject.SetActive(true);
						if (holdButtonToEndGameEarlyHoldTime > 3f)
						{
							TimeOfDay.Instance.VoteShipToLeaveEarly();
							((TMP_Text)holdButtonToEndGameEarlyText).text = "Voted for ship to leave early";
						}
					}
					else
					{
						holdButtonToEndGameEarlyHoldTime = 0f;
						((Component)holdButtonToEndGameEarlyMeter).gameObject.SetActive(false);
					}
					holdButtonToEndGameEarlyMeter.fillAmount = holdButtonToEndGameEarlyHoldTime / 3f;
				}
				else
				{
					((TMP_Text)holdButtonToEndGameEarlyText).text = "Voted for ship to leave early";
					((Component)holdButtonToEndGameEarlyMeter).gameObject.SetActive(false);
				}
				int num = StartOfRound.Instance.connectedPlayersAmount + 1 - StartOfRound.Instance.livingPlayers;
				((Behaviour)holdButtonToEndGameEarlyText).enabled = true;
				((TMP_Text)holdButtonToEndGameEarlyVotesText).text = $"({TimeOfDay.Instance.votesForShipToLeaveEarly}/{num} Votes)";
			}
			else
			{
				((TMP_Text)holdButtonToEndGameEarlyText).text = "Ship leaving in one hour";
				if (TimeOfDay.Instance.votesForShipToLeaveEarly <= 0)
				{
					((TMP_Text)holdButtonToEndGameEarlyVotesText).text = "";
				}
				((Component)holdButtonToEndGameEarlyMeter).gameObject.SetActive(false);
			}
			if (updateSpectateBoxesInterval >= 0.35f)
			{
				updateSpectateBoxesInterval = 0f;
				UpdateSpectateBoxSpeakerIcons();
			}
			else
			{
				updateSpectateBoxesInterval += Time.deltaTime;
			}
		}
		else
		{
			float num2 = Mathf.RoundToInt(Mathf.Clamp(GameNetworkManager.Instance.localPlayerController.carryWeight - 1f, 0f, 100f) * 105f);
			((TMP_Text)weightCounter).text = $"{num2} lb";
			weightCounterAnimator.SetFloat("weight", num2 / 130f);
		}
		if (CanPlayerScan())
		{
			UpdateScanNodes(GameNetworkManager.Instance.localPlayerController);
			scanElementsHidden = false;
			if (scannedScrapNum >= 2 && totalScrapScannedDisplayNum < totalScrapScanned)
			{
				addingToDisplayTotal = true;
				if (addToDisplayTotalInterval <= 0.03f)
				{
					addToDisplayTotalInterval += Time.deltaTime;
				}
				else
				{
					addToDisplayTotalInterval = 0f;
					totalScrapScannedDisplayNum = (int)Mathf.Clamp(Mathf.MoveTowards((float)totalScrapScannedDisplayNum, (float)totalScrapScanned, 1500f * Time.deltaTime), 20f, 10000f);
					((TMP_Text)totalValueText).text = $"${totalScrapScannedDisplayNum}";
					UIAudio.PlayOneShot(addToScrapTotalSFX);
				}
			}
			else if (addingToDisplayTotal)
			{
				addingToDisplayTotal = false;
				UIAudio.PlayOneShot(finishAddingToTotalSFX);
			}
		}
		else if (!scanElementsHidden)
		{
			scanElementsHidden = true;
			DisableAllScanElements();
		}
		if (playerPingingScan >= -1f)
		{
			playerPingingScan -= Time.deltaTime;
		}
		for (int i = 0; i < HUDElements.Length; i++)
		{
			HUDElements[i].canvasGroup.alpha = Mathf.Lerp(HUDElements[i].canvasGroup.alpha, HUDElements[i].targetAlpha, 10f * Time.deltaTime);
		}
		compassImage.uvRect = new Rect(((Component)GameNetworkManager.Instance.localPlayerController).transform.eulerAngles.y / 360f + compassOffset, 0f, 1f, 1f);
		if (holdFillAmount > 0f)
		{
			holdInteractionCanvasGroup.alpha = Mathf.Lerp(holdInteractionCanvasGroup.alpha, 1f, 20f * Time.deltaTime);
		}
		else
		{
			holdInteractionCanvasGroup.alpha = Mathf.Lerp(holdInteractionCanvasGroup.alpha, 0f, 20f * Time.deltaTime);
		}
		if (tutorialArrowState == 0 || !setTutorialArrow)
		{
			shockTutorialLeftAlpha.alpha = Mathf.Lerp(shockTutorialLeftAlpha.alpha, 0f, 17f * Time.deltaTime);
			shockTutorialRightAlpha.alpha = Mathf.Lerp(shockTutorialRightAlpha.alpha, 0f, 17f * Time.deltaTime);
		}
		else if (tutorialArrowState == 1)
		{
			shockTutorialLeftAlpha.alpha = Mathf.Lerp(shockTutorialLeftAlpha.alpha, 1f, 17f * Time.deltaTime);
			shockTutorialRightAlpha.alpha = Mathf.Lerp(shockTutorialRightAlpha.alpha, 0f, 17f * Time.deltaTime);
		}
		else
		{
			shockTutorialRightAlpha.alpha = Mathf.Lerp(shockTutorialRightAlpha.alpha, 1f, 17f * Time.deltaTime);
			shockTutorialLeftAlpha.alpha = Mathf.Lerp(shockTutorialLeftAlpha.alpha, 0f, 17f * Time.deltaTime);
		}
	}

	public void SetShipLeaveEarlyVotesText(int votes)
	{
		int num = StartOfRound.Instance.connectedPlayersAmount + 1 - StartOfRound.Instance.livingPlayers;
		((TMP_Text)holdButtonToEndGameEarlyVotesText).text = $"({votes}/{num} Votes)";
	}

	private void UpdateScanNodes(PlayerControllerB playerScript)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		Vector3 zero = Vector3.zero;
		if (updateScanInterval <= 0f)
		{
			updateScanInterval = 0.25f;
			AssignNewNodes(playerScript);
		}
		updateScanInterval -= Time.deltaTime;
		bool flag = false;
		for (int i = 0; i < scanElements.Length; i++)
		{
			if (scanNodes.Count > 0 && scanNodes.TryGetValue(scanElements[i], out var value) && (Object)(object)value != (Object)null)
			{
				try
				{
					if (NodeIsNotVisible(value, i))
					{
						continue;
					}
					if (!((Component)scanElements[i]).gameObject.activeSelf)
					{
						((Component)scanElements[i]).gameObject.SetActive(true);
						((Component)scanElements[i]).GetComponent<Animator>().SetInteger("colorNumber", value.nodeType);
						if (value.creatureScanID != -1)
						{
							AttemptScanNewCreature(value.creatureScanID);
						}
					}
					goto IL_00f7;
				}
				catch (Exception arg)
				{
					Debug.LogError((object)$"Error in updatescanNodes A: {arg}");
					goto IL_00f7;
				}
			}
			scanNodes.Remove(scanElements[i]);
			((Component)scanElements[i]).gameObject.SetActive(false);
			continue;
			IL_00f7:
			try
			{
				scanElementText = ((Component)scanElements[i]).gameObject.GetComponentsInChildren<TextMeshProUGUI>();
				if (scanElementText.Length > 1)
				{
					((TMP_Text)scanElementText[0]).text = value.headerText;
					((TMP_Text)scanElementText[1]).text = value.subText;
				}
				if (value.nodeType == 2)
				{
					flag = true;
				}
				zero = playerScript.gameplayCamera.WorldToScreenPoint(((Component)value).transform.position);
				scanElements[i].anchoredPosition = new Vector2(zero.x - 439.48f, zero.y - 244.8f);
			}
			catch (Exception arg2)
			{
				Debug.LogError((object)$"Error in updatescannodes B: {arg2}");
			}
		}
		try
		{
			if (!flag)
			{
				totalScrapScanned = 0;
				totalScrapScannedDisplayNum = 0;
				addToDisplayTotalInterval = 0.35f;
			}
			scanInfoAnimator.SetBool("display", scannedScrapNum >= 2 && flag);
		}
		catch (Exception arg3)
		{
			Debug.LogError((object)$"Error in updatescannodes C: {arg3}");
		}
	}

	private void AssignNewNodes(PlayerControllerB playerScript)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		int num = Physics.SphereCastNonAlloc(new Ray(((Component)playerScript.gameplayCamera).transform.position + ((Component)playerScript.gameplayCamera).transform.forward * 20f, ((Component)playerScript.gameplayCamera).transform.forward), 20f, scanNodesHit, 80f, 4194304);
		if (num > scanElements.Length)
		{
			num = scanElements.Length;
		}
		nodesOnScreen.Clear();
		scannedScrapNum = 0;
		if (num > scanElements.Length)
		{
			for (int i = 0; i < num; i++)
			{
				ScanNodeProperties component = ((Component)((RaycastHit)(ref scanNodesHit[i])).transform).gameObject.GetComponent<ScanNodeProperties>();
				if (component.nodeType == 1 || component.nodeType == 2)
				{
					AttemptScanNode(component, i, playerScript);
				}
			}
		}
		if (nodesOnScreen.Count < scanElements.Length)
		{
			for (int j = 0; j < num; j++)
			{
				ScanNodeProperties component = ((Component)((RaycastHit)(ref scanNodesHit[j])).transform).gameObject.GetComponent<ScanNodeProperties>();
				AttemptScanNode(component, j, playerScript);
			}
		}
	}

	private void AttemptScanNode(ScanNodeProperties node, int i, PlayerControllerB playerScript)
	{
		if (MeetsScanNodeRequirements(node, playerScript))
		{
			if (node.nodeType == 2)
			{
				scannedScrapNum++;
			}
			if (!nodesOnScreen.Contains(node))
			{
				nodesOnScreen.Add(node);
			}
			if (playerPingingScan >= 0f)
			{
				AssignNodeToUIElement(node);
			}
		}
	}

	private bool MeetsScanNodeRequirements(ScanNodeProperties node, PlayerControllerB playerScript)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)node == (Object)null)
		{
			return false;
		}
		float num = Vector3.Distance(((Component)playerScript).transform.position, ((Component)node).transform.position);
		if (num < (float)node.maxRange && num > (float)node.minRange)
		{
			if (node.requiresLineOfSight)
			{
				return !Physics.Linecast(((Component)playerScript.gameplayCamera).transform.position, ((Component)node).transform.position, 134217984, (QueryTriggerInteraction)1);
			}
			return true;
		}
		return false;
	}

	private bool NodeIsNotVisible(ScanNodeProperties node, int elementIndex)
	{
		if (!nodesOnScreen.Contains(node))
		{
			if (scanNodes[scanElements[elementIndex]].nodeType == 2)
			{
				totalScrapScanned = Mathf.Clamp(totalScrapScanned - scanNodes[scanElements[elementIndex]].scrapValue, 0, 100000);
			}
			((Component)scanElements[elementIndex]).gameObject.SetActive(false);
			scanNodes.Remove(scanElements[elementIndex]);
			return true;
		}
		return false;
	}

	private void AssignNodeToUIElement(ScanNodeProperties node)
	{
		if (scanNodes.ContainsValue(node))
		{
			return;
		}
		for (int i = 0; i < scanElements.Length; i++)
		{
			if (scanNodes.TryAdd(scanElements[i], node))
			{
				if (node.nodeType == 2)
				{
					totalScrapScanned += node.scrapValue;
					addedToScrapCounterThisFrame = true;
				}
				break;
			}
		}
	}

	private void DisableAllScanElements()
	{
		for (int i = 0; i < scanElements.Length; i++)
		{
			((Component)scanElements[i]).gameObject.SetActive(false);
			totalScrapScanned = 0;
			totalScrapScannedDisplayNum = 0;
		}
	}

	private void AttemptScanNewCreature(int enemyID)
	{
		if (!terminalScript.scannedEnemyIDs.Contains(enemyID))
		{
			ScanNewCreatureServerRpc(enemyID);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ScanNewCreatureServerRpc(int enemyID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1944155956u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, enemyID);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1944155956u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !terminalScript.scannedEnemyIDs.Contains(enemyID))
			{
				terminalScript.scannedEnemyIDs.Add(enemyID);
				terminalScript.newlyScannedEnemyIDs.Add(enemyID);
				DisplayGlobalNotification("New creature data sent to terminal!");
				ScanNewCreatureClientRpc(enemyID);
			}
		}
	}

	[ClientRpc]
	public void ScanNewCreatureClientRpc(int enemyID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3039261141u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, enemyID);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3039261141u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !terminalScript.scannedEnemyIDs.Contains(enemyID))
			{
				terminalScript.scannedEnemyIDs.Add(enemyID);
				terminalScript.newlyScannedEnemyIDs.Add(enemyID);
				DisplayGlobalNotification("New creature data sent to terminal!");
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void GetNewStoryLogServerRpc(int logID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3153465849u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, logID);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3153465849u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !terminalScript.unlockedStoryLogs.Contains(logID))
			{
				terminalScript.unlockedStoryLogs.Add(logID);
				terminalScript.newlyUnlockedStoryLogs.Add(logID);
				DisplayGlobalNotification("Found journal entry: '" + terminalScript.logEntryFiles[logID].creatureName);
				GetNewStoryLogClientRpc(logID);
			}
		}
	}

	[ClientRpc]
	public void GetNewStoryLogClientRpc(int logID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2416035003u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, logID);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2416035003u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !terminalScript.unlockedStoryLogs.Contains(logID))
			{
				terminalScript.unlockedStoryLogs.Add(logID);
				terminalScript.newlyUnlockedStoryLogs.Add(logID);
				DisplayGlobalNotification("Found journal entry: '" + terminalScript.logEntryFiles[logID].creatureName + "'");
			}
		}
	}

	private void DisplayGlobalNotification(string displayText)
	{
		globalNotificationAnimator.SetTrigger("TriggerNotif");
		((TMP_Text)globalNotificationText).text = displayText;
		UIAudio.PlayOneShot(globalNotificationSFX);
	}

	public void PingHUDElement(HUDElement element, float delay = 2f, float startAlpha = 1f, float endAlpha = 0.2f)
	{
		if (delay == 0f && startAlpha == endAlpha)
		{
			element.targetAlpha = endAlpha;
			return;
		}
		element.targetAlpha = startAlpha;
		if (element.fadeCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(element.fadeCoroutine);
		}
		element.fadeCoroutine = ((MonoBehaviour)this).StartCoroutine(FadeUIElement(element, delay, endAlpha));
	}

	private IEnumerator FadeUIElement(HUDElement element, float delay, float endAlpha)
	{
		yield return (object)new WaitForSeconds(delay);
		element.targetAlpha = endAlpha;
	}

	public void HideHUD(bool hide)
	{
		if (hudHidden != hide)
		{
			hudHidden = hide;
			if (hide)
			{
				HUDAnimator.SetTrigger("hideHud");
				scanInfoAnimator.SetBool("display", false);
			}
			else
			{
				HUDAnimator.SetTrigger("revealHud");
			}
		}
	}

	public void ReadDialogue(DialogueSegment[] dialogueArray)
	{
		if (readDialogueCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(readDialogueCoroutine);
		}
		readDialogueCoroutine = ((MonoBehaviour)this).StartCoroutine(ReadOutDialogue(dialogueArray));
	}

	private IEnumerator ReadOutDialogue(DialogueSegment[] dialogueArray)
	{
		dialogueBoxAnimator.SetBool("Open", true);
		for (int i = 0; i < dialogueArray.Length; i++)
		{
			((TMP_Text)dialogeBoxHeaderText).text = dialogueArray[i].speakerText;
			((TMP_Text)dialogeBoxText).text = dialogueArray[i].bodyText;
			dialogueBoxSFX.PlayOneShot(dialogueBleeps[Random.Range(0, dialogueBleeps.Length)]);
			yield return (object)new WaitForSeconds(dialogueArray[i].waitTime);
		}
		dialogueBoxAnimator.SetBool("Open", false);
	}

	public void DisplayCreditsEarning(int creditsEarned, GrabbableObject[] objectsSold, int newGroupCredits)
	{
		Debug.Log((object)$"Earned {creditsEarned}; sold {objectsSold.Length} items; new credits amount: {newGroupCredits}");
		List<Item> list = new List<Item>();
		for (int i = 0; i < objectsSold.Length; i++)
		{
			list.Add(objectsSold[i].itemProperties);
		}
		Item[] array = list.Distinct().ToArray();
		string text = "";
		int num = 0;
		int num2 = 0;
		for (int j = 0; j < array.Length; j++)
		{
			num = 0;
			num2 = 0;
			for (int k = 0; k < objectsSold.Length; k++)
			{
				if ((Object)(object)objectsSold[k].itemProperties == (Object)(object)array[j])
				{
					num += objectsSold[k].scrapValue;
					num2++;
				}
			}
			text += $"{array[j].itemName} (x{num2}) : {num} \n";
		}
		((TMP_Text)moneyRewardsListText).text = text;
		((TMP_Text)moneyRewardsTotalText).text = $"TOTAL: ${creditsEarned}";
		moneyRewardsAnimator.SetTrigger("showRewards");
		rewardsScrollbar.value = 1f;
		if (list.Count > 8)
		{
			if (scrollRewardTextCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(scrollRewardTextCoroutine);
			}
			scrollRewardTextCoroutine = ((MonoBehaviour)this).StartCoroutine(scrollRewardsListText());
		}
	}

	private IEnumerator scrollRewardsListText()
	{
		yield return (object)new WaitForSeconds(0.3f);
		float num = 3f;
		while (num >= 0f)
		{
			num -= Time.deltaTime;
			Scrollbar obj = rewardsScrollbar;
			obj.value -= Time.deltaTime / num;
		}
	}

	public void DisplayNewDeadline(int overtimeBonus)
	{
		reachedProfitQuotaAnimator.SetBool("display", true);
		((TMP_Text)newProfitQuotaText).text = "$0";
		UIAudio.PlayOneShot(reachedQuotaSFX);
		displayingNewQuota = true;
		if (overtimeBonus < 0)
		{
			((TMP_Text)reachedProfitQuotaBonusText).text = "";
		}
		else
		{
			((TMP_Text)reachedProfitQuotaBonusText).text = $"Overtime bonus: ${overtimeBonus}";
		}
		((MonoBehaviour)this).StartCoroutine(rackUpNewQuotaText());
	}

	private IEnumerator rackUpNewQuotaText()
	{
		yield return (object)new WaitForSeconds(3.5f);
		int quotaTextAmount = 0;
		while (quotaTextAmount < TimeOfDay.Instance.profitQuota)
		{
			quotaTextAmount = (int)Mathf.Clamp((float)quotaTextAmount + Time.deltaTime * 250f, (float)(quotaTextAmount + 3), (float)(TimeOfDay.Instance.profitQuota + 10));
			((TMP_Text)newProfitQuotaText).text = "$" + quotaTextAmount;
			yield return null;
		}
		((TMP_Text)newProfitQuotaText).text = "$" + TimeOfDay.Instance.profitQuota;
		TimeOfDay.Instance.UpdateProfitQuotaCurrentTime();
		UIAudio.PlayOneShot(newProfitQuotaSFX);
		yield return (object)new WaitForSeconds(1.25f);
		displayingNewQuota = false;
		reachedProfitQuotaAnimator.SetBool("display", false);
	}

	public void DisplayDaysLeft(int daysLeft)
	{
		if (daysLeft >= 0)
		{
			string text = ((daysLeft != 1) ? $"{daysLeft} Days Left" : $"{daysLeft} Day Left");
			((TMP_Text)profitQuotaDaysLeftText).text = text;
			((TMP_Text)profitQuotaDaysLeftText2).text = text;
			if (daysLeft <= 1)
			{
				reachedProfitQuotaAnimator.SetTrigger("displayDaysLeft");
				UIAudio.PlayOneShot(OneDayToMeetQuotaSFX);
			}
			else
			{
				reachedProfitQuotaAnimator.SetTrigger("displayDaysLeftCalm");
				UIAudio.PlayOneShot(profitQuotaDaysLeftCalmSFX);
			}
		}
	}

	public void ShowPlayersFiredScreen(bool show)
	{
		playersFiredAnimator.SetBool("gameOver", show);
	}

	public void ShakeCamera(ScreenShakeType shakeType)
	{
		switch (shakeType)
		{
		case ScreenShakeType.Big:
			playerScreenShakeAnimator.SetTrigger("bigShake");
			break;
		case ScreenShakeType.Small:
			playerScreenShakeAnimator.SetTrigger("smallShake");
			break;
		case ScreenShakeType.Long:
			playerScreenShakeAnimator.SetTrigger("longShake");
			break;
		case ScreenShakeType.VeryStrong:
			playerScreenShakeAnimator.SetTrigger("veryStrongShake");
			break;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void UseSignalTranslatorServerRpc(string signalMessage)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2436660286u, val, (RpcDelivery)0);
			bool flag = signalMessage != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(signalMessage, false);
			}
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2436660286u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && Object.op_Implicit((Object)(object)Object.FindObjectOfType<SignalTranslator>()) && !string.IsNullOrEmpty(signalMessage) && signalMessage.Length <= 12)
		{
			SignalTranslator signalTranslator = Object.FindObjectOfType<SignalTranslator>();
			if (!(Time.realtimeSinceStartup - signalTranslator.timeLastUsingSignalTranslator < 8f))
			{
				signalTranslator.timeLastUsingSignalTranslator = Time.realtimeSinceStartup;
				signalTranslator.timesSendingMessage++;
				UseSignalTranslatorClientRpc(signalMessage, signalTranslator.timesSendingMessage);
			}
		}
	}

	[ClientRpc]
	public void UseSignalTranslatorClientRpc(string signalMessage, int timesSendingMessage)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1255866175u, val, (RpcDelivery)0);
			bool flag = signalMessage != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(signalMessage, false);
			}
			BytePacker.WriteValueBitPacked(val2, timesSendingMessage);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1255866175u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !string.IsNullOrEmpty(signalMessage) && Object.op_Implicit((Object)(object)Object.FindObjectOfType<SignalTranslator>()))
		{
			SignalTranslator signalTranslator = Object.FindObjectOfType<SignalTranslator>();
			signalTranslator.timeLastUsingSignalTranslator = Time.realtimeSinceStartup;
			if (signalTranslator.signalTranslatorCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(signalTranslator.signalTranslatorCoroutine);
			}
			string signalMessage2 = signalMessage.Substring(0, Mathf.Min(signalMessage.Length, 10));
			signalTranslator.timesSendingMessage = timesSendingMessage;
			signalTranslator.signalTranslatorCoroutine = ((MonoBehaviour)this).StartCoroutine(DisplaySignalTranslatorMessage(signalMessage2, timesSendingMessage, signalTranslator));
		}
	}

	private IEnumerator DisplaySignalTranslatorMessage(string signalMessage, int seed, SignalTranslator signalTranslator)
	{
		Random signalMessageRandom = new Random(seed + StartOfRound.Instance.randomMapSeed);
		signalTranslatorAnimator.SetBool("transmitting", true);
		signalTranslator.localAudio.Play();
		UIAudio.PlayOneShot(signalTranslator.startTransmissionSFX, 1f);
		((TMP_Text)signalTranslatorText).text = "";
		yield return (object)new WaitForSeconds(1.21f);
		for (int i = 0; i < signalMessage.Length; i++)
		{
			if ((Object)(object)signalTranslator == (Object)null)
			{
				break;
			}
			if (!((Component)signalTranslator).gameObject.activeSelf)
			{
				break;
			}
			UIAudio.PlayOneShot(signalTranslator.typeTextClips[Random.Range(0, signalTranslator.typeTextClips.Length)]);
			((TMP_Text)signalTranslatorText).text = ((TMP_Text)signalTranslatorText).text + signalMessage[i];
			float num = Mathf.Min((float)signalMessageRandom.Next(-1, 4) * 0.5f, 0f);
			yield return (object)new WaitForSeconds(0.7f + num);
		}
		if ((Object)(object)signalTranslator != (Object)null)
		{
			UIAudio.PlayOneShot(signalTranslator.finishTypingSFX);
			signalTranslator.localAudio.Stop();
		}
		yield return (object)new WaitForSeconds(0.5f);
		signalTranslatorAnimator.SetBool("transmitting", false);
	}

	public void ToggleHUD(bool enable)
	{
		HUDContainer.SetActive(enable);
	}

	public void FillChallengeResultsStats(int scrapCollected)
	{
		((TMP_Text)statsUIElements.challengeCollectedText).text = $"${scrapCollected} Collected";
		if (GameNetworkManager.Instance.disableSteam)
		{
			((TMP_Text)statsUIElements.challengeRankText).text = "---";
			return;
		}
		Debug.Log((object)$"Scrap collected B: {scrapCollected}");
		GetRankAndSubmitScore(scrapCollected);
	}

	public async void GetRankAndSubmitScore(int scrapCollected)
	{
		Debug.Log((object)"GetRankAndSubmitScore called");
		if (!StartOfRound.Instance.isChallengeFile)
		{
			return;
		}
		Debug.Log((object)"GetRankAndSubmitScore called A");
		try
		{
			retrievingSteamLeaderboard = true;
			int weekNum = GameNetworkManager.Instance.GetWeekNumber();
			Leaderboard? val = await SteamUserStats.FindOrCreateLeaderboardAsync($"challenge{weekNum}", (LeaderboardSort)2, (LeaderboardDisplay)1);
			Debug.Log((object)$"Found or created leaderboard 'challenge{weekNum}'");
			Debug.Log((object)"Did not submit score yet...");
			Leaderboard value;
			LeaderboardUpdate? val2;
			if (StartOfRound.Instance.allPlayersDead)
			{
				Debug.Log((object)"All players dead");
				value = val.Value;
				val2 = await ((Leaderboard)(ref value)).ReplaceScore(0, new int[1] { 3 });
				Debug.Log((object)"Replaced score! A");
			}
			else
			{
				value = val.Value;
				val2 = await ((Leaderboard)(ref value)).ReplaceScore(scrapCollected, (int[])null);
				Debug.Log((object)$"Replaced score! B: scrapCollected: {scrapCollected}");
			}
			ES3.Save<bool>("SubmittedScore", true, "LCChallengeFile");
			if (val2.HasValue && val2.HasValue)
			{
				ES3.Save<bool>("SubmittedScore", true, "LCChallengeFile");
				((TMP_Text)statsUIElements.challengeRankText).text = $"#{val2.Value.NewGlobalRank}";
			}
			else
			{
				Debug.Log((object)$"Updated leaderboard returned null, unable to replace score?; {!val2.HasValue}");
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while submitting leaderboard score: {arg}");
		}
		retrievingSteamLeaderboard = false;
	}

	public void FillEndGameStats(EndOfGameStats stats, int scrapCollected = 0)
	{
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < playersManager.allPlayerScripts.Length; i++)
		{
			PlayerControllerB playerControllerB = playersManager.allPlayerScripts[i];
			((TMP_Text)statsUIElements.playerNamesText[i]).text = "";
			((Behaviour)statsUIElements.playerStates[i]).enabled = false;
			((TMP_Text)statsUIElements.playerNotesText[i]).text = "Notes: \n";
			if (playerControllerB.disconnectedMidGame || playerControllerB.isPlayerDead || playerControllerB.isPlayerControlled)
			{
				if (playerControllerB.isPlayerDead)
				{
					num++;
				}
				else if (playerControllerB.isPlayerControlled)
				{
					num2++;
				}
				((TMP_Text)statsUIElements.playerNamesText[i]).text = playersManager.allPlayerScripts[i].playerUsername;
				((Behaviour)statsUIElements.playerStates[i]).enabled = true;
				if (playersManager.allPlayerScripts[i].isPlayerDead)
				{
					if (playersManager.allPlayerScripts[i].causeOfDeath == CauseOfDeath.Abandoned)
					{
						statsUIElements.playerStates[i].sprite = statsUIElements.missingIcon;
					}
					else
					{
						statsUIElements.playerStates[i].sprite = statsUIElements.deceasedIcon;
					}
				}
				else
				{
					statsUIElements.playerStates[i].sprite = statsUIElements.aliveIcon;
				}
				for (int j = 0; j < 3 && j < stats.allPlayerStats[i].playerNotes.Count; j++)
				{
					TextMeshProUGUI obj = statsUIElements.playerNotesText[i];
					((TMP_Text)obj).text = ((TMP_Text)obj).text + "* " + stats.allPlayerStats[i].playerNotes[j] + "\n";
				}
			}
			else
			{
				((TMP_Text)statsUIElements.playerNotesText[i]).text = "";
			}
		}
		((TMP_Text)statsUIElements.quotaNumerator).text = scrapCollected.ToString();
		((TMP_Text)statsUIElements.quotaDenominator).text = RoundManager.Instance.totalScrapValueInLevel.ToString();
		if (StartOfRound.Instance.allPlayersDead)
		{
			((Behaviour)statsUIElements.allPlayersDeadOverlay).enabled = true;
			((TMP_Text)statsUIElements.gradeLetter).text = "F";
			return;
		}
		((Behaviour)statsUIElements.allPlayersDeadOverlay).enabled = false;
		int num3 = 0;
		float num4 = (float)RoundManager.Instance.scrapCollectedInLevel / RoundManager.Instance.totalScrapValueInLevel;
		if (num2 == StartOfRound.Instance.connectedPlayersAmount + 1)
		{
			num3++;
		}
		else if (num > 1)
		{
			num3--;
		}
		if (num4 >= 0.99f)
		{
			num3 += 2;
		}
		else if (num4 >= 0.6f)
		{
			num3++;
		}
		else if (num4 <= 0.25f)
		{
			num3--;
		}
		switch (num3)
		{
		case -1:
			((TMP_Text)statsUIElements.gradeLetter).text = "D";
			break;
		case 0:
			((TMP_Text)statsUIElements.gradeLetter).text = "C";
			break;
		case 1:
			((TMP_Text)statsUIElements.gradeLetter).text = "B";
			break;
		case 2:
			((TMP_Text)statsUIElements.gradeLetter).text = "A";
			break;
		case 3:
			((TMP_Text)statsUIElements.gradeLetter).text = "S";
			break;
		}
	}

	[ServerRpc]
	public void SyncAllPlayerLevelsServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2352591293u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2352591293u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		int[] array = new int[4];
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (!StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled)
			{
				array[i] = -1;
			}
			else
			{
				array[i] = StartOfRound.Instance.allPlayerScripts[i].playerLevelNumber;
			}
		}
		bool[] array2 = new bool[4];
		for (int j = 0; j < StartOfRound.Instance.allPlayerScripts.Length; j++)
		{
			if (!StartOfRound.Instance.allPlayerScripts[j].isPlayerControlled)
			{
				array2[j] = false;
			}
			else
			{
				array2[j] = ((Renderer)StartOfRound.Instance.allPlayerScripts[j].playerBetaBadgeMesh).enabled;
			}
		}
		SyncAllPlayerLevelsClientRpc(array, array2);
	}

	[ClientRpc]
	public void SyncAllPlayerLevelsClientRpc(int[] playerLevelNumbers, bool[] playersHaveBeta)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1570713893u, val, (RpcDelivery)0);
			bool flag = playerLevelNumbers != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(playerLevelNumbers, default(ForPrimitives));
			}
			bool flag2 = playersHaveBeta != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag2, default(ForPrimitives));
			if (flag2)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(playersHaveBeta, default(ForPrimitives));
			}
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1570713893u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
			{
				SetLevelOfPlayer(StartOfRound.Instance.allPlayerScripts[i], playerLevelNumbers[i], playersHaveBeta[i]);
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while syncing player level from server: {arg}");
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncPlayerLevelServerRpc(int playerId, int playerLevelIndex, bool hasBeta = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1389701054u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				BytePacker.WriteValueBitPacked(val2, playerLevelIndex);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref hasBeta, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1389701054u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SyncPlayerLevelClientRpc(playerId, playerLevelIndex, hasBeta);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncAllPlayerLevelsServerRpc(int newPlayerLevel, int playerClientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4217433937u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, newPlayerLevel);
			BytePacker.WriteValueBitPacked(val2, playerClientId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4217433937u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		List<int> list = new List<int>();
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled || StartOfRound.Instance.allPlayerScripts[i].isPlayerDead)
			{
				if (i == playerClientId)
				{
					list.Add(newPlayerLevel);
				}
				else
				{
					list.Add(StartOfRound.Instance.allPlayerScripts[i].playerLevelNumber);
				}
			}
		}
		SyncAllPlayerLevelsClientRpc(list.ToArray(), StartOfRound.Instance.connectedPlayersAmount);
	}

	[ClientRpc]
	public void SyncAllPlayerLevelsClientRpc(int[] allPlayerLevels, int connectedPlayers)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2220027482u, val, (RpcDelivery)0);
			bool flag = allPlayerLevels != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(allPlayerLevels, default(ForPrimitives));
			}
			BytePacker.WriteValueBitPacked(val2, connectedPlayers);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2220027482u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || StartOfRound.Instance.connectedPlayersAmount != connectedPlayers)
		{
			return;
		}
		int num = 0;
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled || StartOfRound.Instance.allPlayerScripts[i].isPlayerDead)
			{
				if ((Object)(object)StartOfRound.Instance.allPlayerScripts[i] == (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					num++;
					continue;
				}
				SetLevelOfPlayer(StartOfRound.Instance.allPlayerScripts[i], allPlayerLevels[num], hasBeta: true);
				num++;
			}
		}
	}

	[ClientRpc]
	public void SyncPlayerLevelClientRpc(int playerId, int playerLevelIndex, bool hasBeta)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1676259161u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			BytePacker.WriteValueBitPacked(val2, playerLevelIndex);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref hasBeta, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1676259161u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			if (!((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerId)
			{
				if (playerLevelIndex >= playerLevels.Length)
				{
					Debug.LogError((object)"Error: Player level synced in client RPC was above the max player level!");
				}
				else
				{
					SetLevelOfPlayer(StartOfRound.Instance.allPlayerScripts[playerId], playerLevelIndex, hasBeta);
				}
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error while syncing player level from client #{playerId}: {arg}");
		}
	}

	public void SetLevelOfPlayer(PlayerControllerB playerScript, int playerLevelIndex, bool hasBeta)
	{
		playerScript.playerLevelNumber = playerLevelIndex;
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null && (Object)(object)playerScript == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			((Renderer)playerScript.playerBetaBadgeMesh).enabled = false;
			((Renderer)((Component)playerScript.playerBadgeMesh).gameObject.GetComponent<MeshRenderer>()).enabled = false;
		}
		else
		{
			((Renderer)playerScript.playerBetaBadgeMesh).enabled = hasBeta;
			playerScript.playerBadgeMesh.mesh = playerLevels[playerLevelIndex].badgeMesh;
		}
	}

	public void DisableLocalBadgeMesh()
	{
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
		{
			((Renderer)GameNetworkManager.Instance.localPlayerController.playerBetaBadgeMesh).enabled = false;
			((Renderer)((Component)GameNetworkManager.Instance.localPlayerController.playerBadgeMesh).gameObject.GetComponent<MeshRenderer>()).enabled = false;
		}
	}

	public void SetPlayerLevel(bool isDead, bool mostProfitable, bool allPlayersDead)
	{
		int num = 0;
		num = ((!isDead) ? (num + 10) : (num - 3));
		if (mostProfitable)
		{
			num += 15;
		}
		if (allPlayersDead)
		{
			num -= 5;
		}
		if (num > 0)
		{
			Debug.Log((object)$"XP gain before scaling to scrap returned: {num}");
			Debug.Log((object)((float)RoundManager.Instance.scrapCollectedInLevel / RoundManager.Instance.totalScrapValueInLevel));
			float num2 = (float)RoundManager.Instance.scrapCollectedInLevel / RoundManager.Instance.totalScrapValueInLevel;
			Debug.Log((object)num2);
			num = (int)((float)num * num2);
		}
		if (num == 0)
		{
			Debug.Log((object)"Gained no XP");
			playerLevelMeter.fillAmount = localPlayerXP / playerLevels[localPlayerLevel].XPMax;
			((TMP_Text)playerLevelXPCounter).text = localPlayerXP.ToString();
			((TMP_Text)playerLevelText).text = playerLevels[localPlayerLevel].levelName;
		}
		else
		{
			((MonoBehaviour)this).StartCoroutine(SetPlayerLevelSmoothly(num));
		}
	}

	private IEnumerator SetPlayerLevelSmoothly(int XPGain)
	{
		float changingPlayerXP = localPlayerXP;
		int changingPlayerLevel = localPlayerLevel;
		int targetXPLevel = Mathf.Max(localPlayerXP + XPGain, 0);
		bool conditionMet = false;
		if (XPGain < 0)
		{
			LevellingAudio.clip = decreaseXPSFX;
		}
		else
		{
			LevellingAudio.clip = increaseXPSFX;
		}
		LevellingAudio.Play();
		float timeAtStart = Time.realtimeSinceStartup;
		while (!conditionMet && Time.realtimeSinceStartup - timeAtStart < 5f)
		{
			Debug.Log((object)$"Level up timer: {Time.realtimeSinceStartup - timeAtStart}");
			if (XPGain < 0)
			{
				changingPlayerXP -= Time.deltaTime * 15f;
				if (changingPlayerXP < 0f)
				{
					changingPlayerXP = 0f;
				}
				if (changingPlayerXP <= (float)targetXPLevel)
				{
					conditionMet = true;
				}
				if (changingPlayerLevel - 1 >= 0 && changingPlayerXP < (float)playerLevels[changingPlayerLevel].XPMin)
				{
					changingPlayerLevel--;
					UIAudio.PlayOneShot(levelDecreaseSFX);
					playerLevelBoxAnimator.SetTrigger("Shake");
					yield return (object)new WaitForSeconds(0.4f);
				}
			}
			else
			{
				changingPlayerXP += Time.deltaTime * 15f;
				if (changingPlayerXP >= (float)targetXPLevel)
				{
					conditionMet = true;
				}
				if (changingPlayerLevel + 1 < playerLevels.Length && changingPlayerXP >= (float)playerLevels[changingPlayerLevel].XPMax)
				{
					changingPlayerLevel++;
					UIAudio.PlayOneShot(levelIncreaseSFX);
					playerLevelBoxAnimator.SetTrigger("Shake");
					yield return (object)new WaitForSeconds(0.4f);
				}
			}
			playerLevelMeter.fillAmount = (changingPlayerXP - (float)playerLevels[changingPlayerLevel].XPMin) / (float)playerLevels[changingPlayerLevel].XPMax;
			((TMP_Text)playerLevelText).text = playerLevels[changingPlayerLevel].levelName;
			((TMP_Text)playerLevelXPCounter).text = $"{Mathf.RoundToInt(changingPlayerXP)} EXP";
			yield return null;
		}
		LevellingAudio.Stop();
		int num = 0;
		for (int i = 0; i < playerLevels.Length; i++)
		{
			if (targetXPLevel >= playerLevels[i].XPMin && targetXPLevel < playerLevels[i].XPMax)
			{
				num = i;
				break;
			}
			if (i == playerLevels.Length - 1)
			{
				num = i;
			}
		}
		localPlayerXP = targetXPLevel;
		localPlayerLevel = num;
		((TMP_Text)playerLevelText).text = playerLevels[localPlayerLevel].levelName;
		((TMP_Text)playerLevelXPCounter).text = $"{Mathf.RoundToInt((float)localPlayerXP)} EXP";
		bool hasBeta = ES3.Load<bool>("playedDuringBeta", "LCGeneralSaveData", true);
		SyncPlayerLevelServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId, localPlayerLevel, hasBeta);
	}

	public void ApplyPenalty(int playersDead, int bodiesInsured)
	{
		float num = 0.2f;
		Terminal terminal = Object.FindObjectOfType<Terminal>();
		int groupCredits = terminal.groupCredits;
		bodiesInsured = Mathf.Max(bodiesInsured, 0);
		for (int i = 0; i < playersDead - bodiesInsured; i++)
		{
			terminal.groupCredits -= (int)((float)groupCredits * num);
		}
		for (int j = 0; j < bodiesInsured; j++)
		{
			terminal.groupCredits -= (int)((float)groupCredits * (num / 2.5f));
		}
		if (terminal.groupCredits < 0)
		{
			terminal.groupCredits = 0;
		}
		((TMP_Text)statsUIElements.penaltyAddition).text = $"{playersDead} casualties: -{num * 100f * (float)(playersDead - bodiesInsured)}%\n({bodiesInsured} bodies recovered)";
		((TMP_Text)statsUIElements.penaltyTotal).text = $"DUE: ${groupCredits - terminal.groupCredits}";
		Debug.Log((object)$"New group credits after penalty: {terminal.groupCredits}");
	}

	public void SetQuota(int numerator, int denominator = -1)
	{
		((TMP_Text)HUDQuotaNumerator).text = numerator.ToString();
		if (denominator != -1)
		{
			((TMP_Text)HUDQuotaDenominator).text = denominator.ToString();
		}
	}

	public void AddNewScrapFoundToDisplay(GrabbableObject GObject)
	{
		if (itemsToBeDisplayed.Count <= 16)
		{
			itemsToBeDisplayed.Add(GObject);
		}
	}

	public void DisplayNewScrapFound()
	{
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0312: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		if (itemsToBeDisplayed.Count <= 0)
		{
			return;
		}
		if ((Object)(object)itemsToBeDisplayed[0] == (Object)null || (Object)(object)itemsToBeDisplayed[0].itemProperties.spawnPrefab == (Object)null)
		{
			itemsToBeDisplayed.Clear();
			return;
		}
		if (itemsToBeDisplayed[0].scrapValue < 80)
		{
			UIAudio.PlayOneShot(displayCollectedScrapSFXSmall);
		}
		else
		{
			UIAudio.PlayOneShot(displayCollectedScrapSFX);
		}
		GameObject val = Object.Instantiate<GameObject>(itemsToBeDisplayed[0].itemProperties.spawnPrefab, ScrapItemBoxes[nextBoxIndex].itemObjectContainer);
		Object.Destroy((Object)(object)val.GetComponent<NetworkObject>());
		Object.Destroy((Object)(object)val.GetComponent<GrabbableObject>());
		Object.Destroy((Object)(object)val.GetComponent<Collider>());
		val.transform.localPosition = Vector3.zero;
		val.transform.localScale = val.transform.localScale * 4f;
		val.transform.rotation = Quaternion.Euler(itemsToBeDisplayed[0].itemProperties.restingRotation);
		Renderer[] componentsInChildren = val.GetComponentsInChildren<Renderer>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if (((Component)componentsInChildren[i]).gameObject.layer != 22)
			{
				Material[] sharedMaterials = componentsInChildren[i].sharedMaterials;
				componentsInChildren[i].rendererPriority = 70;
				for (int j = 0; j < sharedMaterials.Length; j++)
				{
					sharedMaterials[j] = hologramMaterial;
				}
				componentsInChildren[i].sharedMaterials = sharedMaterials;
				((Component)componentsInChildren[i]).gameObject.layer = 5;
			}
		}
		ScrapItemBoxes[nextBoxIndex].itemDisplayAnimator.SetTrigger("collect");
		if (itemsToBeDisplayed[0] is RagdollGrabbableObject)
		{
			RagdollGrabbableObject ragdollGrabbableObject = itemsToBeDisplayed[0] as RagdollGrabbableObject;
			if ((Object)(object)ragdollGrabbableObject != (Object)null && (Object)(object)ragdollGrabbableObject.ragdoll != (Object)null && (Object)(object)ragdollGrabbableObject.ragdoll.playerScript != (Object)null)
			{
				((TMP_Text)ScrapItemBoxes[nextBoxIndex].headerText).text = ragdollGrabbableObject.ragdoll.playerScript.playerUsername + " collected!";
			}
			else
			{
				((TMP_Text)ScrapItemBoxes[nextBoxIndex].headerText).text = "Body collected!";
			}
		}
		else
		{
			((TMP_Text)ScrapItemBoxes[nextBoxIndex].headerText).text = itemsToBeDisplayed[0].itemProperties.itemName + " collected!";
		}
		((TMP_Text)ScrapItemBoxes[nextBoxIndex].valueText).text = $"Value: ${itemsToBeDisplayed[0].scrapValue}";
		if (boxesDisplaying > 0)
		{
			ScrapItemBoxes[nextBoxIndex].UIContainer.anchoredPosition = new Vector2(ScrapItemBoxes[nextBoxIndex].UIContainer.anchoredPosition.x, ScrapItemBoxes[bottomBoxIndex].UIContainer.anchoredPosition.y - 124f);
		}
		else
		{
			ScrapItemBoxes[nextBoxIndex].UIContainer.anchoredPosition = new Vector2(ScrapItemBoxes[nextBoxIndex].UIContainer.anchoredPosition.x, (float)bottomBoxYPosition);
		}
		bottomBoxIndex = nextBoxIndex;
		((MonoBehaviour)this).StartCoroutine(displayScrapTimer(val));
		playScrapDisplaySFX();
		boxesDisplaying++;
		nextBoxIndex = (nextBoxIndex + 1) % 3;
		itemsToBeDisplayed.RemoveAt(0);
	}

	private IEnumerator playScrapDisplaySFX()
	{
		yield return (object)new WaitForSeconds(0.05f * (float)boxesDisplaying);
	}

	private IEnumerator displayScrapTimer(GameObject displayingObject)
	{
		yield return (object)new WaitForSeconds(3.5f);
		boxesDisplaying--;
		Object.Destroy((Object)(object)displayingObject);
	}

	public void ChangeControlTip(int toolTipNumber, string changeTo, bool clearAllOther = false)
	{
		if (StartOfRound.Instance.localPlayerUsingController)
		{
			StringBuilder stringBuilder = new StringBuilder(changeTo);
			stringBuilder.Replace("[E]", "[D-pad up]");
			stringBuilder.Replace("[Q]", "[D-pad down]");
			stringBuilder.Replace("[LMB]", "[Y]");
			stringBuilder.Replace("[RMB]", "[R-Trigger]");
			stringBuilder.Replace("[G]", "[B]");
			changeTo = stringBuilder.ToString();
		}
		else
		{
			changeTo = changeTo.Replace("[RMB]", "[LMB]");
		}
		((TMP_Text)controlTipLines[toolTipNumber]).text = changeTo;
		if (clearAllOther)
		{
			for (int i = 0; i < controlTipLines.Length; i++)
			{
				if (i != toolTipNumber)
				{
					((TMP_Text)controlTipLines[i]).text = "";
				}
			}
		}
		if (forceChangeTextCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(forceChangeTextCoroutine);
		}
		forceChangeTextCoroutine = ((MonoBehaviour)this).StartCoroutine(ForceChangeText(controlTipLines[toolTipNumber], changeTo));
	}

	private IEnumerator ForceChangeText(TextMeshProUGUI textToChange, string changeTextTo)
	{
		for (int i = 0; i < 5; i++)
		{
			yield return null;
			((TMP_Text)textToChange).text = changeTextTo;
		}
	}

	public void ClearControlTips()
	{
		for (int i = 0; i < controlTipLines.Length; i++)
		{
			((TMP_Text)controlTipLines[i]).text = "";
		}
	}

	public void ChangeControlTipMultiple(string[] allLines, bool holdingItem = false, Item itemProperties = null)
	{
		if (holdingItem)
		{
			((TMP_Text)controlTipLines[0]).text = "Drop " + itemProperties.itemName + " : [G]";
		}
		if (allLines == null)
		{
			return;
		}
		int num = 0;
		if (holdingItem)
		{
			num = 1;
		}
		for (int i = 0; i < allLines.Length && i + num < controlTipLines.Length; i++)
		{
			string text = allLines[i];
			if (StartOfRound.Instance.localPlayerUsingController)
			{
				StringBuilder stringBuilder = new StringBuilder(text);
				stringBuilder.Replace("[E]", "[D-pad up]");
				stringBuilder.Replace("[Q]", "[D-pad down]");
				stringBuilder.Replace("[LMB]", "[Y]");
				stringBuilder.Replace("[RMB]", "[R-Trigger]");
				stringBuilder.Replace("[G]", "[B]");
				text = stringBuilder.ToString();
			}
			else
			{
				text = text.Replace("[RMB]", "[LMB]");
			}
			((TMP_Text)controlTipLines[i + num]).text = text;
		}
	}

	public void SetDebugText(string setText)
	{
		((TMP_Text)debugText).text = setText;
		((Behaviour)debugText).enabled = true;
	}

	public void DisplayStatusEffect(string statusEffect)
	{
		statusEffectAnimator.SetTrigger("IndicateStatus");
		((TMP_Text)statusEffectText).text = statusEffect;
	}

	public void DisplayTip(string headerText, string bodyText, bool isWarning = false, bool useSave = false, string prefsKey = "LC_Tip1")
	{
		if (!CanTipDisplay(isWarning, useSave, prefsKey))
		{
			return;
		}
		if (useSave)
		{
			if (tipsPanelCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(tipsPanelCoroutine);
			}
			tipsPanelCoroutine = ((MonoBehaviour)this).StartCoroutine(TipsPanelTimer(prefsKey));
		}
		((TMP_Text)tipsPanelHeader).text = headerText;
		((TMP_Text)tipsPanelBody).text = bodyText;
		if (isWarning)
		{
			tipsPanelAnimator.SetTrigger("TriggerWarning");
			RoundManager.PlayRandomClip(UIAudio, warningSFX, randomize: false);
		}
		else
		{
			tipsPanelAnimator.SetTrigger("TriggerHint");
			RoundManager.PlayRandomClip(UIAudio, tipsSFX, randomize: false);
		}
	}

	private void DisplaySpectatorVoteTip()
	{
		if (displayedSpectatorAFKTip)
		{
			return;
		}
		bool flag = false;
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (!StartOfRound.Instance.allPlayerScripts[i].isPlayerDead && StartOfRound.Instance.allPlayerScripts[i].timeSincePlayerMoving < 10f)
			{
				flag = true;
			}
		}
		if (!flag)
		{
			noLivingPlayersAtKeyboardTimer += Time.deltaTime;
			if (noLivingPlayersAtKeyboardTimer > 12f)
			{
				if (StartOfRound.Instance.localPlayerUsingController)
				{
					DisplaySpectatorTip("TIP!: Hold [R-Trigger] to vote for the autopilot ship to leave early.");
				}
				else
				{
					DisplaySpectatorTip("TIP!: Hold [RMB] to vote for the autopilot ship to leave early.");
				}
			}
		}
		else
		{
			noLivingPlayersAtKeyboardTimer = 0f;
		}
	}

	private void DisplaySpectatorTip(string tipText)
	{
		displayedSpectatorAFKTip = true;
		((TMP_Text)spectatorTipText).text = tipText;
		if (!((Behaviour)spectatorTipText).enabled)
		{
			((MonoBehaviour)this).StartCoroutine(displayTipTextTimer());
		}
	}

	private IEnumerator displayTipTextTimer()
	{
		UIAudio.PlayOneShot(tipsSFX[0], 1f);
		((Behaviour)spectatorTipText).enabled = true;
		yield return (object)new WaitForSeconds(7f);
		((Behaviour)spectatorTipText).enabled = false;
	}

	private bool CanTipDisplay(bool isWarning, bool useSave, string prefsKey)
	{
		if (useSave)
		{
			return !ES3.Load<bool>(prefsKey, "LCGeneralSaveData", false);
		}
		if (tipsPanelCoroutine != null)
		{
			if (isWarning && !isDisplayingWarning)
			{
				return true;
			}
			return false;
		}
		return true;
	}

	private IEnumerator TipsPanelTimer(string prefsKey)
	{
		yield return (object)new WaitForSeconds(5f);
		ES3.Save<bool>(prefsKey, true, "LCGeneralSaveData");
	}

	public string SetClock(float timeNormalized, float numberOfHours, bool createNewLine = true)
	{
		int num = (int)(timeNormalized * (60f * numberOfHours)) + 360;
		int num2 = (int)Mathf.Floor((float)(num / 60));
		if (!createNewLine)
		{
			newLine = " ";
		}
		else
		{
			newLine = "\n";
		}
		amPM = newLine + "AM";
		if (num2 >= 24)
		{
			((TMP_Text)clockNumber).text = "12:00 " + newLine + " AM";
			return "12:00\nAM";
		}
		if (num2 < 12)
		{
			amPM = newLine + "AM";
		}
		else
		{
			amPM = newLine + "PM";
		}
		if (num2 > 12)
		{
			num2 %= 12;
		}
		int num3 = num % 60;
		string text = $"{num2:00}:{num3:00}".TrimStart('0') + amPM;
		((TMP_Text)clockNumber).text = text;
		return text;
	}

	public void SetClockIcon(DayMode dayMode)
	{
		clockIcon.sprite = clockIcons[(int)dayMode];
	}

	public void SetClockVisible(bool visible)
	{
		if (visible)
		{
			Clock.targetAlpha = 1f;
		}
		else
		{
			Clock.targetAlpha = 0f;
		}
	}

	public void TriggerAlarmHornEffect()
	{
		if (!((Object)(object)Object.FindObjectOfType<AlarmButton>() == (Object)null))
		{
			AlarmHornServerRpc();
		}
	}

	[ServerRpc]
	public void AlarmHornServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1616150480u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1616150480u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			AlarmButton alarmButton = Object.FindObjectOfType<AlarmButton>();
			if (!((Object)(object)alarmButton == (Object)null) && !(alarmButton.timeSincePushing < 1f))
			{
				alarmButton.timeSincePushing = 0f;
				AlarmHornClientRpc();
			}
		}
	}

	[ClientRpc]
	public void AlarmHornClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(840104050u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 840104050u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			AlarmButton alarmButton = Object.FindObjectOfType<AlarmButton>();
			if (!((Object)(object)alarmButton == (Object)null))
			{
				alarmButton.timeSincePushing = 0f;
				alarmHornEffect.SetTrigger("triggerAlarm");
				UIAudio.PlayOneShot(shipAlarmHornSFX, 1f);
			}
		}
	}

	public void RadiationWarningHUD()
	{
		radiationGraphicAnimator.SetTrigger("RadiationWarning");
		UIAudio.PlayOneShot(radiationWarningAudio, 1f);
	}

	public void MeteorShowerWarningHUD()
	{
		meteorShowerGraphicAnimator.SetTrigger("MeteorShowerWarning");
		UIAudio.PlayOneShot(meteorShowerWarningAudio, 1f);
		((MonoBehaviour)this).StartCoroutine(weatherPSASoundDeafening());
	}

	private IEnumerator weatherPSASoundDeafening()
	{
		float timer = 0f;
		while ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null && !GameNetworkManager.Instance.localPlayerController.isPlayerDead && timer < 10.4f)
		{
			timer += Time.deltaTime;
			SoundManager.Instance.SetDiageticMasterVolume(-13f);
			yield return null;
		}
	}

	public void UpdateInstabilityPercentage(int percentage)
	{
		if (previousInstability != percentage)
		{
			UpdateInstabilityClientRpc(percentage);
		}
	}

	[ClientRpc]
	public void UpdateInstabilityClientRpc(int percentage)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(551948140u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, percentage);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 551948140u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				((TMP_Text)instabilityCounterNumber).text = $"{percentage}%";
				PingHUDElement(InstabilityCounter, 2f, 1f, 0.7f);
			}
		}
	}

	public void SetTutorialArrow(int state)
	{
		tutorialArrowState = state;
	}

	public bool HoldInteractionFill(float timeToHold, float speedMultiplier = 1f)
	{
		if (timeToHold == -1f)
		{
			return false;
		}
		holdFillAmount += Time.deltaTime * speedMultiplier;
		holdInteractionFillAmount.fillAmount = holdFillAmount / timeToHold;
		if (holdFillAmount > timeToHold)
		{
			holdFillAmount = 0f;
			return true;
		}
		return false;
	}

	public void ToggleErrorConsole()
	{
		errorLogPanel.SetActive(!Instance.errorLogPanel.activeSelf);
	}

	[ServerRpc(RequireOwnership = false)]
	public void SendErrorMessageServerRpc(string errorMessage, int sentByPlayerNum)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1043384750u, val, (RpcDelivery)0);
			bool flag = errorMessage != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(errorMessage, false);
			}
			BytePacker.WriteValueBitPacked(val2, sentByPlayerNum);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1043384750u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && GameNetworkManager.Instance.SendExceptionsToServer && !((Object)(object)Instance == (Object)null))
		{
			AddToErrorLog(errorMessage, sentByPlayerNum);
		}
	}

	public void AddToErrorLog(string errorMessage, int sentByPlayerNum)
	{
		if (!(errorMessage == previousErrorReceived))
		{
			previousErrorReceived = errorMessage;
			string playerUsername = StartOfRound.Instance.allPlayerScripts[sentByPlayerNum].playerUsername;
			playerUsername = playerUsername.Substring(0, Mathf.Clamp(5, 1, playerUsername.Length));
			((TMP_Text)Instance.errorLogText).text = (((TMP_Text)Instance.errorLogText).text + "\n\n" + playerUsername + ": " + errorMessage).Substring(Mathf.Max(0, ((TMP_Text)Instance.errorLogText).text.Length - 1000));
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_HUDManager()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1647277829u, new RpcReceiveHandler(__rpc_handler_1647277829));
		NetworkManager.__rpc_func_table.Add(229674455u, new RpcReceiveHandler(__rpc_handler_229674455));
		NetworkManager.__rpc_func_table.Add(2930587515u, new RpcReceiveHandler(__rpc_handler_2930587515));
		NetworkManager.__rpc_func_table.Add(168728662u, new RpcReceiveHandler(__rpc_handler_168728662));
		NetworkManager.__rpc_func_table.Add(2787681914u, new RpcReceiveHandler(__rpc_handler_2787681914));
		NetworkManager.__rpc_func_table.Add(1568596901u, new RpcReceiveHandler(__rpc_handler_1568596901));
		NetworkManager.__rpc_func_table.Add(1944155956u, new RpcReceiveHandler(__rpc_handler_1944155956));
		NetworkManager.__rpc_func_table.Add(3039261141u, new RpcReceiveHandler(__rpc_handler_3039261141));
		NetworkManager.__rpc_func_table.Add(3153465849u, new RpcReceiveHandler(__rpc_handler_3153465849));
		NetworkManager.__rpc_func_table.Add(2416035003u, new RpcReceiveHandler(__rpc_handler_2416035003));
		NetworkManager.__rpc_func_table.Add(2436660286u, new RpcReceiveHandler(__rpc_handler_2436660286));
		NetworkManager.__rpc_func_table.Add(1255866175u, new RpcReceiveHandler(__rpc_handler_1255866175));
		NetworkManager.__rpc_func_table.Add(2352591293u, new RpcReceiveHandler(__rpc_handler_2352591293));
		NetworkManager.__rpc_func_table.Add(1570713893u, new RpcReceiveHandler(__rpc_handler_1570713893));
		NetworkManager.__rpc_func_table.Add(1389701054u, new RpcReceiveHandler(__rpc_handler_1389701054));
		NetworkManager.__rpc_func_table.Add(4217433937u, new RpcReceiveHandler(__rpc_handler_4217433937));
		NetworkManager.__rpc_func_table.Add(2220027482u, new RpcReceiveHandler(__rpc_handler_2220027482));
		NetworkManager.__rpc_func_table.Add(1676259161u, new RpcReceiveHandler(__rpc_handler_1676259161));
		NetworkManager.__rpc_func_table.Add(1616150480u, new RpcReceiveHandler(__rpc_handler_1616150480));
		NetworkManager.__rpc_func_table.Add(840104050u, new RpcReceiveHandler(__rpc_handler_840104050));
		NetworkManager.__rpc_func_table.Add(551948140u, new RpcReceiveHandler(__rpc_handler_551948140));
		NetworkManager.__rpc_func_table.Add(1043384750u, new RpcReceiveHandler(__rpc_handler_1043384750));
	}

	private static void __rpc_handler_1647277829(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int indexInShipDecorList = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref indexInShipDecorList);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).CreateFurnitureAdModelAndDisplayAdClientRpc(indexInShipDecorList);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_229674455(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int steepestSale = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref steepestSale);
			int itemIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref itemIndex);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).CreateToolAdModelAndDisplayAdClientRpc(steepestSale, itemIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2930587515(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			string chatMessage = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref chatMessage, false);
			}
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).AddPlayerChatMessageServerRpc(chatMessage, playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_168728662(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			string chatMessage = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref chatMessage, false);
			}
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).AddPlayerChatMessageClientRpc(chatMessage, playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2787681914(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			string chatMessage = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref chatMessage, false);
			}
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).AddTextMessageServerRpc(chatMessage);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1568596901(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			string chatMessage = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref chatMessage, false);
			}
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).AddTextMessageClientRpc(chatMessage);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1944155956(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int enemyID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref enemyID);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).ScanNewCreatureServerRpc(enemyID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3039261141(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int enemyID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref enemyID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).ScanNewCreatureClientRpc(enemyID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3153465849(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int logID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref logID);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).GetNewStoryLogServerRpc(logID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2416035003(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int logID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref logID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).GetNewStoryLogClientRpc(logID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2436660286(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			string signalMessage = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref signalMessage, false);
			}
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).UseSignalTranslatorServerRpc(signalMessage);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1255866175(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			string signalMessage = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref signalMessage, false);
			}
			int timesSendingMessage = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref timesSendingMessage);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).UseSignalTranslatorClientRpc(signalMessage, timesSendingMessage);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2352591293(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).SyncAllPlayerLevelsServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1570713893(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			int[] playerLevelNumbers = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref playerLevelNumbers, default(ForPrimitives));
			}
			bool flag2 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag2, default(ForPrimitives));
			bool[] playersHaveBeta = null;
			if (flag2)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref playersHaveBeta, default(ForPrimitives));
			}
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).SyncAllPlayerLevelsClientRpc(playerLevelNumbers, playersHaveBeta);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1389701054(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int playerLevelIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerLevelIndex);
			bool hasBeta = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref hasBeta, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).SyncPlayerLevelServerRpc(playerId, playerLevelIndex, hasBeta);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4217433937(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int newPlayerLevel = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newPlayerLevel);
			int playerClientId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerClientId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).SyncAllPlayerLevelsServerRpc(newPlayerLevel, playerClientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2220027482(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			int[] allPlayerLevels = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref allPlayerLevels, default(ForPrimitives));
			}
			int connectedPlayers = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref connectedPlayers);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).SyncAllPlayerLevelsClientRpc(allPlayerLevels, connectedPlayers);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1676259161(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int playerLevelIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerLevelIndex);
			bool hasBeta = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref hasBeta, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).SyncPlayerLevelClientRpc(playerId, playerLevelIndex, hasBeta);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1616150480(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).AlarmHornServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_840104050(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).AlarmHornClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_551948140(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int percentage = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref percentage);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HUDManager)(object)target).UpdateInstabilityClientRpc(percentage);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1043384750(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			string errorMessage = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref errorMessage, false);
			}
			int sentByPlayerNum = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref sentByPlayerNum);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HUDManager)(object)target).SendErrorMessageServerRpc(errorMessage, sentByPlayerNum);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "HUDManager";
	}
}
