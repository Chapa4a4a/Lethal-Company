using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class FlashlightItem : GrabbableObject
{
	[Space(15f)]
	public bool usingPlayerHelmetLight;

	public int flashlightInterferenceLevel;

	public static int globalFlashlightInterferenceLevel;

	public Light flashlightBulb;

	public Light flashlightBulbGlow;

	public AudioSource flashlightAudio;

	public AudioClip[] flashlightClips;

	public AudioClip outOfBatteriesClip;

	public AudioClip flashlightFlicker;

	public Material bulbLight;

	public Material bulbDark;

	public MeshRenderer flashlightMesh;

	public int flashlightTypeID;

	public bool changeMaterial = true;

	private float initialIntensity;

	private PlayerControllerB previousPlayerHeldBy;

	public override void Start()
	{
		base.Start();
		initialIntensity = flashlightBulb.intensity;
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		if (flashlightInterferenceLevel < 2)
		{
			SwitchFlashlight(used);
		}
		flashlightAudio.PlayOneShot(flashlightClips[Random.Range(0, flashlightClips.Length)]);
		RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 7f, 0.4f, 0, isInElevator && StartOfRound.Instance.hangarDoorsClosed);
	}

	public override void UseUpBatteries()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		base.UseUpBatteries();
		SwitchFlashlight(on: false);
		flashlightAudio.PlayOneShot(outOfBatteriesClip, 1f);
		RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 13f, 0.65f, 0, isInElevator && StartOfRound.Instance.hangarDoorsClosed);
	}

	public override void PocketItem()
	{
		if (!((NetworkBehaviour)this).IsOwner)
		{
			base.PocketItem();
			return;
		}
		if ((Object)(object)previousPlayerHeldBy != (Object)null)
		{
			((Behaviour)flashlightBulb).enabled = false;
			((Behaviour)flashlightBulbGlow).enabled = false;
			if (isBeingUsed && ((Object)(object)previousPlayerHeldBy.ItemSlots[previousPlayerHeldBy.currentItemSlot] == (Object)null || previousPlayerHeldBy.ItemSlots[previousPlayerHeldBy.currentItemSlot].itemProperties.itemId != 1 || previousPlayerHeldBy.ItemSlots[previousPlayerHeldBy.currentItemSlot].itemProperties.itemId != 6))
			{
				((Behaviour)previousPlayerHeldBy.helmetLight).enabled = true;
				previousPlayerHeldBy.pocketedFlashlight = this;
				usingPlayerHelmetLight = true;
				PocketFlashlightServerRpc(stillUsingFlashlight: true);
			}
			else
			{
				isBeingUsed = false;
				usingPlayerHelmetLight = false;
				((Behaviour)flashlightBulbGlow).enabled = false;
				SwitchFlashlight(on: false);
				PocketFlashlightServerRpc();
			}
		}
		else
		{
			Debug.Log((object)"Could not find what player was holding this flashlight item");
		}
		base.PocketItem();
	}

	[ServerRpc]
	public void PocketFlashlightServerRpc(bool stillUsingFlashlight = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(461510128u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref stillUsingFlashlight, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 461510128u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			PocketFlashlightClientRpc(stillUsingFlashlight);
		}
	}

	[ClientRpc]
	public void PocketFlashlightClientRpc(bool stillUsingFlashlight)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4121415408u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref stillUsingFlashlight, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4121415408u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		((Behaviour)flashlightBulb).enabled = false;
		((Behaviour)flashlightBulbGlow).enabled = false;
		if (stillUsingFlashlight)
		{
			if (!((Object)(object)previousPlayerHeldBy == (Object)null))
			{
				((Behaviour)previousPlayerHeldBy.helmetLight).enabled = true;
				previousPlayerHeldBy.pocketedFlashlight = this;
				usingPlayerHelmetLight = true;
			}
		}
		else
		{
			isBeingUsed = false;
			usingPlayerHelmetLight = false;
			((Behaviour)flashlightBulbGlow).enabled = false;
			SwitchFlashlight(on: false);
		}
	}

	public override void DiscardItem()
	{
		if ((Object)(object)previousPlayerHeldBy != (Object)null)
		{
			((Behaviour)previousPlayerHeldBy.helmetLight).enabled = false;
			((Behaviour)flashlightBulb).enabled = isBeingUsed;
			((Behaviour)flashlightBulbGlow).enabled = isBeingUsed;
		}
		base.DiscardItem();
	}

	public override void EquipItem()
	{
		previousPlayerHeldBy = playerHeldBy;
		playerHeldBy.ChangeHelmetLight(flashlightTypeID);
		((Behaviour)playerHeldBy.helmetLight).enabled = false;
		usingPlayerHelmetLight = false;
		if (isBeingUsed)
		{
			SwitchFlashlight(on: true);
		}
		base.EquipItem();
	}

	public void SwitchFlashlight(bool on)
	{
		isBeingUsed = on;
		if (!((NetworkBehaviour)this).IsOwner)
		{
			Debug.Log((object)$"Flashlight click. playerheldby null?: {(Object)(object)playerHeldBy != (Object)null}");
			Debug.Log((object)$"Flashlight being disabled or enabled: {on}");
			if ((Object)(object)playerHeldBy != (Object)null)
			{
				playerHeldBy.ChangeHelmetLight(flashlightTypeID, on);
			}
			((Behaviour)flashlightBulb).enabled = false;
			((Behaviour)flashlightBulbGlow).enabled = false;
		}
		else
		{
			((Behaviour)flashlightBulb).enabled = on;
			((Behaviour)flashlightBulbGlow).enabled = on;
		}
		if (usingPlayerHelmetLight && (Object)(object)playerHeldBy != (Object)null)
		{
			((Behaviour)playerHeldBy.helmetLight).enabled = on;
		}
		if (changeMaterial)
		{
			Material[] sharedMaterials = ((Renderer)flashlightMesh).sharedMaterials;
			if (on)
			{
				sharedMaterials[1] = bulbLight;
			}
			else
			{
				sharedMaterials[1] = bulbDark;
			}
			((Renderer)flashlightMesh).sharedMaterials = sharedMaterials;
		}
	}

	public override void Update()
	{
		base.Update();
		int num = ((flashlightInterferenceLevel <= globalFlashlightInterferenceLevel) ? globalFlashlightInterferenceLevel : flashlightInterferenceLevel);
		if (num >= 2)
		{
			flashlightBulb.intensity = 0f;
		}
		else if (num == 1)
		{
			flashlightBulb.intensity = Random.Range(0f, 200f);
		}
		else
		{
			flashlightBulb.intensity = initialIntensity;
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_FlashlightItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(461510128u, new RpcReceiveHandler(__rpc_handler_461510128));
		NetworkManager.__rpc_func_table.Add(4121415408u, new RpcReceiveHandler(__rpc_handler_4121415408));
	}

	private static void __rpc_handler_461510128(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool stillUsingFlashlight = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref stillUsingFlashlight, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((FlashlightItem)(object)target).PocketFlashlightServerRpc(stillUsingFlashlight);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4121415408(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool stillUsingFlashlight = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref stillUsingFlashlight, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlashlightItem)(object)target).PocketFlashlightClientRpc(stillUsingFlashlight);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "FlashlightItem";
	}
}
