using System.Collections;
using Unity.Netcode;
using UnityEngine;

public class AutoParentToShip : NetworkBehaviour
{
	public bool disableObject;

	public Vector3 positionOffset;

	public Vector3 rotationOffset;

	[HideInInspector]
	public Vector3 startingPosition;

	[HideInInspector]
	public Vector3 startingRotation;

	public bool overrideOffset;

	public int unlockableID = -1;

	private void Awake()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		if (!overrideOffset)
		{
			positionOffset = StartOfRound.Instance.elevatorTransform.InverseTransformPoint(((Component)this).transform.position);
			rotationOffset = StartOfRound.Instance.elevatorTransform.InverseTransformDirection(((Component)this).transform.eulerAngles);
		}
		MoveToOffset();
		PlaceableShipObject component = ((Component)this).gameObject.GetComponent<PlaceableShipObject>();
		if ((Object)(object)component != (Object)null && (Object)(object)component.parentObjectSecondary != (Object)null)
		{
			startingPosition = component.parentObjectSecondary.position;
			startingRotation = component.parentObjectSecondary.eulerAngles;
		}
		else
		{
			startingPosition = positionOffset;
			startingRotation = rotationOffset;
		}
		Debug.Log((object)$"item awake: {((Object)((Component)this).gameObject).name}; id: {unlockableID}");
		if (unlockableID != -1)
		{
			Debug.Log((object)$"placedPosition: {StartOfRound.Instance.unlockablesList.unlockables[unlockableID].placedPosition}");
		}
		if (unlockableID != -1 && StartOfRound.Instance.unlockablesList.unlockables[unlockableID].placedPosition != Vector3.zero)
		{
			Debug.Log((object)$"awake for {((Object)((Component)this).gameObject).name}; IsServer? :{((NetworkBehaviour)this).IsServer}");
			Debug.Log((object)$"ShipBuildModeManager?: {(Object)(object)ShipBuildModeManager.Instance != (Object)null}");
			Debug.Log((object)$"unlockableID: {unlockableID}");
			Debug.Log((object)$"Unlockables list count: {StartOfRound.Instance.unlockablesList.unlockables.Count}");
			if (!((NetworkBehaviour)this).IsServer && (Object)(object)ShipBuildModeManager.Instance != (Object)null)
			{
				ShipBuildModeManager.Instance.PlaceShipObject(StartOfRound.Instance.unlockablesList.unlockables[unlockableID].placedPosition, StartOfRound.Instance.unlockablesList.unlockables[unlockableID].placedRotation, ((Component)this).gameObject.GetComponentInChildren<PlaceableShipObject>(), placementSFX: false);
			}
		}
	}

	private void LateUpdate()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (!StartOfRound.Instance.suckingFurnitureOutOfShip)
		{
			if (disableObject)
			{
				((Component)this).transform.position = new Vector3(800f, -100f, 0f);
			}
			else
			{
				MoveToOffset();
			}
		}
	}

	public void StartSuckingOutOfShip()
	{
		((MonoBehaviour)this).StartCoroutine(SuckObjectOutOfShip());
	}

	private IEnumerator SuckObjectOutOfShip()
	{
		Vector3 dir = Vector3.Normalize((StartOfRound.Instance.middleOfSpaceNode.position - ((Component)this).transform.position) * 10000f);
		Debug.Log((object)dir);
		Quaternion randomRotation = Random.rotation;
		while (StartOfRound.Instance.suckingFurnitureOutOfShip)
		{
			yield return null;
			((Component)this).transform.position = ((Component)this).transform.position + dir * (Time.deltaTime * Mathf.Clamp(StartOfRound.Instance.suckingPower, 1.1f, 100f) * 17f);
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, ((Component)this).transform.rotation * randomRotation, Time.deltaTime * StartOfRound.Instance.suckingPower);
			Debug.DrawRay(((Component)this).transform.position + Vector3.up * 0.2f, StartOfRound.Instance.middleOfSpaceNode.position - ((Component)this).transform.position, Color.blue);
			Debug.DrawRay(((Component)this).transform.position, dir, Color.green);
		}
	}

	public void MoveToOffset()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.rotation = StartOfRound.Instance.elevatorTransform.rotation;
		((Component)this).transform.Rotate(rotationOffset);
		((Component)this).transform.position = StartOfRound.Instance.elevatorTransform.position;
		Vector3 val = positionOffset;
		val = StartOfRound.Instance.elevatorTransform.rotation * val;
		Transform transform = ((Component)this).transform;
		transform.position += val;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "AutoParentToShip";
	}
}
