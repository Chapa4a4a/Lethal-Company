public enum LevelWeatherType
{
	None = -1,
	DustClouds,
	Rainy,
	Stormy,
	Foggy,
	Flooded,
	Eclipsed
}
