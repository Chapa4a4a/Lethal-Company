public enum CarObstacleType
{
	Player,
	Enemy,
	Object
}
