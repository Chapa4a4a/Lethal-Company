using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using Unity.Netcode.Components;
using Unity.Netcode.Samples;
using UnityEngine;

public abstract class GrabbableObject : NetworkBehaviour
{
	public bool grabbable;

	public bool isHeld;

	public bool isHeldByEnemy;

	public bool deactivated;

	[Space(3f)]
	public Transform parentObject;

	public Vector3 targetFloorPosition;

	public Vector3 startFallingPosition;

	public int floorYRot;

	public float fallTime;

	public bool hasHitGround;

	[Space(5f)]
	public int scrapValue;

	public bool itemUsedUp;

	public PlayerControllerB playerHeldBy;

	public bool isPocketed;

	public bool isBeingUsed;

	public bool isInElevator;

	public bool isInShipRoom;

	public bool isInFactory = true;

	[Space(10f)]
	public float useCooldown;

	public float currentUseCooldown;

	[Space(10f)]
	public Item itemProperties;

	public Battery insertedBattery;

	public string customGrabTooltip;

	[HideInInspector]
	public Rigidbody propBody;

	[HideInInspector]
	public Collider[] propColliders;

	[HideInInspector]
	public Vector3 originalScale;

	public bool wasOwnerLastFrame;

	public MeshRenderer mainObjectRenderer;

	public int isSendingItemRPC;

	public bool scrapPersistedThroughRounds;

	public bool heldByPlayerOnServer;

	[HideInInspector]
	public Transform radarIcon;

	public bool reachedFloorTarget;

	[Space(3f)]
	public bool grabbableToEnemies = true;

	public bool hasBeenHeld;

	public bool rotateObject;

	public virtual int GetItemDataToSave()
	{
		if (!itemProperties.saveItemVariable)
		{
			Debug.LogError((object)("GetItemDataToSave is being called on " + itemProperties.itemName + ", which does not have saveItemVariable set true."));
		}
		return 0;
	}

	public virtual void LoadItemSaveData(int saveData)
	{
		if (!itemProperties.saveItemVariable)
		{
			Debug.LogError((object)("LoadItemSaveData is being called on " + itemProperties.itemName + ", which does not have saveItemVariable set true."));
		}
	}

	public virtual void InitializeAfterPositioning()
	{
	}

	public virtual void Start()
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		propColliders = ((Component)this).gameObject.GetComponentsInChildren<Collider>();
		for (int i = 0; i < propColliders.Length; i++)
		{
			if (!((Component)propColliders[i]).CompareTag("InteractTrigger"))
			{
				propColliders[i].excludeLayers = LayerMask.op_Implicit(-2621449);
			}
		}
		originalScale = ((Component)this).transform.localScale;
		if (itemProperties.itemSpawnsOnGround)
		{
			RandomScrapSpawn[] array = Object.FindObjectsOfType<RandomScrapSpawn>();
			for (int j = 0; j < array.Length; j++)
			{
				if ((Object)(object)array[j].spawnWithParent != (Object)null && ((Component)array[j].spawnWithParent).transform.position == ((Component)this).transform.position)
				{
					((Component)this).transform.SetParent(array[j].spawnWithParent, true);
					break;
				}
			}
			Debug.DrawRay(((Component)this).transform.position, Vector3.up * 10f, Color.cyan, 10f);
			startFallingPosition = ((Component)this).transform.position;
			if ((Object)(object)((Component)this).transform.parent != (Object)null)
			{
				startFallingPosition = ((Component)this).transform.parent.InverseTransformPoint(startFallingPosition);
			}
			Debug.DrawRay(((Component)this).transform.position, Vector3.up * 10f, Color.cyan, 10f);
			if ((Object)(object)((Component)this).transform.parent != (Object)null)
			{
				Debug.Log((object)$"Item spawning: {itemProperties.itemName} ; item parent : {((Component)this).transform.parent}");
			}
			else
			{
				Debug.Log((object)("Item spawning: " + itemProperties.itemName + " ; item parent : null "));
			}
			FallToGround(randomizePosition: false, justSpawned: true, startFallingPosition);
		}
		else
		{
			fallTime = 1f;
			hasHitGround = true;
			reachedFloorTarget = true;
			targetFloorPosition = ((Component)this).transform.localPosition;
		}
		if (itemProperties.isScrap)
		{
			fallTime = 1f;
			hasHitGround = true;
		}
		if (itemProperties.isScrap && (Object)(object)RoundManager.Instance.mapPropsContainer != (Object)null)
		{
			radarIcon = Object.Instantiate<GameObject>(StartOfRound.Instance.itemRadarIconPrefab, RoundManager.Instance.mapPropsContainer.transform).transform;
		}
		else if (itemProperties.itemId == 14 && (Object)(object)RoundManager.Instance.mapPropsContainer != (Object)null)
		{
			radarIcon = Object.Instantiate<GameObject>(StartOfRound.Instance.keyRadarIconPrefab, RoundManager.Instance.mapPropsContainer.transform).transform;
		}
		if (!itemProperties.isScrap)
		{
			HoarderBugAI.grabbableObjectsInMap.Add(((Component)this).gameObject);
		}
		MeshRenderer[] componentsInChildren = ((Component)this).gameObject.GetComponentsInChildren<MeshRenderer>();
		for (int k = 0; k < componentsInChildren.Length; k++)
		{
			((Renderer)componentsInChildren[k]).renderingLayerMask = 1u;
		}
		SkinnedMeshRenderer[] componentsInChildren2 = ((Component)this).gameObject.GetComponentsInChildren<SkinnedMeshRenderer>();
		for (int l = 0; l < componentsInChildren2.Length; l++)
		{
			((Renderer)componentsInChildren2[l]).renderingLayerMask = 1u;
		}
	}

	private IEnumerator fallToGroundOnFrameDelay(Vector3 startPosition)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		yield return null;
		if (!(startFallingPosition != startPosition))
		{
			FallToGround(randomizePosition: false, justSpawned: false, startPosition);
		}
	}

	public void FallToGround(bool randomizePosition = false, bool justSpawned = false, Vector3 overrideStartPos = default(Vector3))
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		Vector3 startPosition = ((Component)this).transform.position;
		if (overrideStartPos != Vector3.zero)
		{
			startPosition = overrideStartPos;
		}
		if (justSpawned)
		{
			Debug.Log((object)$"Start falling position: {startFallingPosition}");
			Debug.DrawRay(startFallingPosition, Vector3.up * 0.5f, Color.yellow, 20f);
			((MonoBehaviour)this).StartCoroutine(fallToGroundOnFrameDelay(startPosition));
			return;
		}
		fallTime = 0f;
		((Component)this).transform.localPosition = startFallingPosition;
		startPosition = ((Component)this).transform.position;
		Debug.Log((object)$"global startposition falltoground for object {((Object)((Component)this).gameObject).name}: {startPosition}");
		Debug.DrawRay(startPosition, Vector3.up * 1.5f, Color.blue, 25f);
		RaycastHit val = default(RaycastHit);
		if (Physics.Raycast(startPosition, Vector3.down, ref val, 80f, 268437760, (QueryTriggerInteraction)1))
		{
			Debug.DrawRay(startPosition, Vector3.down * ((RaycastHit)(ref val)).distance, Color.red, 20f, true);
			Debug.Log((object)("Item " + itemProperties.itemName + " landed on : " + ((Object)((RaycastHit)(ref val)).collider).name + " / " + ((Object)((Component)((RaycastHit)(ref val)).transform).gameObject).name));
			targetFloorPosition = ((RaycastHit)(ref val)).point + itemProperties.verticalOffset * Vector3.up;
			if ((Object)(object)((Component)this).transform.parent != (Object)null)
			{
				targetFloorPosition = ((Component)this).transform.parent.InverseTransformPoint(targetFloorPosition);
			}
		}
		else
		{
			Debug.Log((object)("dropping item did not get raycast : " + ((Object)((Component)this).gameObject).name));
			targetFloorPosition = ((Component)this).transform.localPosition;
		}
		if (randomizePosition)
		{
			targetFloorPosition += new Vector3(Random.Range(-0.5f, 0.5f), 0f, Random.Range(-0.5f, 0.5f));
		}
		InitializeAfterPositioning();
	}

	public void EnablePhysics(bool enable)
	{
		for (int i = 0; i < propColliders.Length; i++)
		{
			if (!((Object)(object)propColliders[i] == (Object)null) && !((Component)propColliders[i]).gameObject.CompareTag("InteractTrigger") && !((Component)propColliders[i]).gameObject.CompareTag("DoNotSet") && !((Component)propColliders[i]).gameObject.CompareTag("Enemy"))
			{
				propColliders[i].enabled = enable;
			}
		}
	}

	public virtual void InspectItem()
	{
		if (((NetworkBehaviour)this).IsOwner && (Object)(object)playerHeldBy != (Object)null && itemProperties.canBeInspected)
		{
			playerHeldBy.IsInspectingItem = !playerHeldBy.IsInspectingItem;
			HUDManager.Instance.SetNearDepthOfFieldEnabled(!playerHeldBy.IsInspectingItem);
		}
	}

	public virtual void InteractItem()
	{
	}

	public void GrabItemOnClient()
	{
		if (!((NetworkBehaviour)this).IsOwner)
		{
			Debug.LogError((object)"GrabItemOnClient was called but player was not the owner.");
			return;
		}
		SetControlTipsForItem();
		GrabItem();
		if (itemProperties.syncGrabFunction)
		{
			isSendingItemRPC++;
			GrabServerRpc();
		}
	}

	public virtual void SetControlTipsForItem()
	{
		HUDManager.Instance.ChangeControlTipMultiple(itemProperties.toolTips, holdingItem: true, itemProperties);
	}

	public virtual void GrabItem()
	{
	}

	public void UseItemOnClient(bool buttonDown = true)
	{
		if (!((NetworkBehaviour)this).IsOwner)
		{
			Debug.Log((object)"Can't use item; not owner");
		}
		else if (!RequireCooldown() && UseItemBatteries(!itemProperties.holdButtonUse, buttonDown))
		{
			if (itemProperties.syncUseFunction)
			{
				isSendingItemRPC++;
				ActivateItemServerRpc(isBeingUsed, buttonDown);
			}
			ItemActivate(isBeingUsed, buttonDown);
		}
	}

	public bool UseItemBatteries(bool isToggle, bool buttonDown = true)
	{
		if (itemProperties.requiresBattery && (insertedBattery == null || insertedBattery.empty))
		{
			return false;
		}
		if (itemProperties.itemIsTrigger)
		{
			insertedBattery.charge = Mathf.Clamp(insertedBattery.charge - itemProperties.batteryUsage, 0f, 1f);
			if (insertedBattery.charge <= 0f)
			{
				insertedBattery.empty = true;
			}
			isBeingUsed = false;
		}
		else if (itemProperties.automaticallySetUsingPower)
		{
			if (isToggle)
			{
				isBeingUsed = !isBeingUsed;
			}
			else
			{
				isBeingUsed = buttonDown;
			}
		}
		return true;
	}

	public virtual void ItemActivate(bool used, bool buttonDown = true)
	{
	}

	public void ItemInteractLeftRightOnClient(bool right)
	{
		if (!((NetworkBehaviour)this).IsOwner)
		{
			Debug.Log((object)"InteractLeftRight was called but player was not the owner.");
		}
		else if (!RequireCooldown() && UseItemBatteries(isToggle: true))
		{
			ItemInteractLeftRight(right);
			if (itemProperties.syncInteractLRFunction)
			{
				isSendingItemRPC++;
				InteractLeftRightServerRpc(right);
			}
		}
	}

	public virtual void ItemInteractLeftRight(bool right)
	{
	}

	public virtual void ActivatePhysicsTrigger(Collider other)
	{
	}

	public virtual void UseUpBatteries()
	{
		Debug.Log((object)"Use up batteries on local client");
		isBeingUsed = false;
	}

	public virtual void GrabItemFromEnemy(EnemyAI enemy)
	{
	}

	public virtual void DiscardItemFromEnemy()
	{
	}

	public virtual void ChargeBatteries()
	{
	}

	public virtual void DestroyObjectInHand(PlayerControllerB playerHolding)
	{
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		grabbable = false;
		grabbableToEnemies = false;
		deactivated = true;
		if ((Object)(object)playerHolding != (Object)null)
		{
			playerHolding.activatingItem = false;
		}
		if ((Object)(object)radarIcon != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)radarIcon).gameObject);
		}
		MeshRenderer[] componentsInChildren = ((Component)this).gameObject.GetComponentsInChildren<MeshRenderer>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			Object.Destroy((Object)(object)componentsInChildren[i]);
		}
		Collider[] componentsInChildren2 = ((Component)this).gameObject.GetComponentsInChildren<Collider>();
		for (int j = 0; j < componentsInChildren2.Length; j++)
		{
			Object.Destroy((Object)(object)componentsInChildren2[j]);
		}
		if (((NetworkBehaviour)this).IsOwner && isHeld && !isPocketed && (Object)(object)playerHolding != (Object)null && (Object)(object)playerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			playerHeldBy.DiscardHeldObject();
		}
	}

	public virtual void EquipItem()
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			HUDManager.Instance.ClearControlTips();
			SetControlTipsForItem();
		}
		rotateObject = false;
		EnableItemMeshes(enable: true);
		isPocketed = false;
		if (!hasBeenHeld)
		{
			hasBeenHeld = true;
			if (!isInShipRoom && !StartOfRound.Instance.inShipPhase && StartOfRound.Instance.currentLevel.spawnEnemiesAndScrap)
			{
				RoundManager.Instance.valueOfFoundScrapItems += scrapValue;
			}
		}
	}

	public virtual void PocketItem()
	{
		if (((NetworkBehaviour)this).IsOwner && (Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.IsInspectingItem = false;
		}
		isPocketed = true;
		EnableItemMeshes(enable: false);
		((Component)this).gameObject.GetComponent<AudioSource>().PlayOneShot(itemProperties.pocketSFX, 1f);
	}

	public void DiscardItemOnClient()
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			DiscardItem();
			HUDManager.Instance.ClearControlTips();
			SyncBatteryServerRpc((int)(insertedBattery.charge * 100f));
			if (itemProperties.syncDiscardFunction)
			{
				isSendingItemRPC++;
				DiscardItemServerRpc();
			}
		}
	}

	[ServerRpc]
	public void SyncBatteryServerRpc(int charge)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3484508350u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, charge);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3484508350u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncBatteryClientRpc(charge);
		}
	}

	[ClientRpc]
	public void SyncBatteryClientRpc(int charge)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2670202430u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, charge);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2670202430u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				float num = (float)charge / 100f;
				insertedBattery = new Battery(num <= 0f, num);
				ChargeBatteries();
			}
		}
	}

	public virtual void DiscardItem()
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			HUDManager.Instance.ClearControlTips();
			if ((Object)(object)playerHeldBy != (Object)null)
			{
				playerHeldBy.IsInspectingItem = false;
				playerHeldBy.activatingItem = false;
			}
		}
		playerHeldBy = null;
	}

	public virtual void LateUpdate()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)parentObject != (Object)null)
		{
			((Component)this).transform.rotation = parentObject.rotation;
			((Component)this).transform.Rotate(itemProperties.rotationOffset);
			((Component)this).transform.position = parentObject.position;
			Vector3 positionOffset = itemProperties.positionOffset;
			positionOffset = parentObject.rotation * positionOffset;
			Transform transform = ((Component)this).transform;
			transform.position += positionOffset;
		}
		if (rotateObject)
		{
			((Component)this).transform.Rotate(new Vector3(0f, Time.deltaTime * 60f, 0f), (Space)0);
		}
		if ((Object)(object)radarIcon != (Object)null)
		{
			radarIcon.position = ((Component)this).transform.position;
		}
	}

	public virtual void FallWithCurve()
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		float num = startFallingPosition.y - targetFloorPosition.y;
		if (floorYRot == -1)
		{
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, Quaternion.Euler(itemProperties.restingRotation.x, ((Component)this).transform.eulerAngles.y, itemProperties.restingRotation.z), Mathf.Clamp(14f * Time.deltaTime / num, 0f, 1f));
		}
		else
		{
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, Quaternion.Euler(itemProperties.restingRotation.x, (float)(floorYRot + itemProperties.floorYOffset) + 90f, itemProperties.restingRotation.z), Mathf.Clamp(14f * Time.deltaTime / num, 0f, 1f));
		}
		if (num > 5f)
		{
			((Component)this).transform.localPosition = Vector3.Lerp(startFallingPosition, targetFloorPosition, StartOfRound.Instance.objectFallToGroundCurveNoBounce.Evaluate(fallTime));
		}
		else
		{
			((Component)this).transform.localPosition = Vector3.Lerp(startFallingPosition, targetFloorPosition, StartOfRound.Instance.objectFallToGroundCurve.Evaluate(fallTime));
		}
		fallTime += Mathf.Abs(Time.deltaTime * 6f / num);
	}

	public virtual void OnPlaceObject()
	{
	}

	public virtual void OnBroughtToShip()
	{
		if ((Object)(object)radarIcon != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)radarIcon).gameObject);
		}
	}

	public virtual void Update()
	{
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		if (currentUseCooldown >= 0f)
		{
			currentUseCooldown -= Time.deltaTime;
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (isBeingUsed && itemProperties.requiresBattery)
			{
				if (insertedBattery.charge > 0f)
				{
					if (!itemProperties.itemIsTrigger)
					{
						insertedBattery.charge -= Time.deltaTime / itemProperties.batteryUsage;
					}
				}
				else if (!insertedBattery.empty)
				{
					insertedBattery.empty = true;
					if (isBeingUsed)
					{
						Debug.Log((object)"Use up batteries local");
						isBeingUsed = false;
						UseUpBatteries();
						isSendingItemRPC++;
						UseUpItemBatteriesServerRpc();
					}
				}
			}
			if (!wasOwnerLastFrame)
			{
				wasOwnerLastFrame = true;
			}
		}
		else if (wasOwnerLastFrame)
		{
			wasOwnerLastFrame = false;
		}
		if (!isHeld && (Object)(object)parentObject == (Object)null)
		{
			if (fallTime < 1f)
			{
				reachedFloorTarget = false;
				FallWithCurve();
				if (((Component)this).transform.localPosition.y - targetFloorPosition.y < 0.05f && !hasHitGround)
				{
					PlayDropSFX();
					OnHitGround();
				}
				return;
			}
			if (!reachedFloorTarget)
			{
				if (!hasHitGround)
				{
					PlayDropSFX();
					OnHitGround();
				}
				reachedFloorTarget = true;
				if (floorYRot == -1)
				{
					((Component)this).transform.rotation = Quaternion.Euler(itemProperties.restingRotation.x, ((Component)this).transform.eulerAngles.y, itemProperties.restingRotation.z);
				}
				else
				{
					((Component)this).transform.rotation = Quaternion.Euler(itemProperties.restingRotation.x, (float)(floorYRot + itemProperties.floorYOffset) + 90f, itemProperties.restingRotation.z);
				}
			}
			((Component)this).transform.localPosition = targetFloorPosition;
		}
		else if (isHeld || isHeldByEnemy)
		{
			reachedFloorTarget = false;
		}
	}

	public virtual void OnHitGround()
	{
	}

	public virtual void PlayDropSFX()
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)itemProperties.dropSFX != (Object)null)
		{
			AudioSource component = ((Component)this).gameObject.GetComponent<AudioSource>();
			component.PlayOneShot(itemProperties.dropSFX);
			WalkieTalkie.TransmitOneShotAudio(component, itemProperties.dropSFX);
			if (((NetworkBehaviour)this).IsOwner)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 8f, 0.5f, 0, isInElevator && StartOfRound.Instance.hangarDoorsClosed, 941);
			}
		}
		hasHitGround = true;
	}

	public void SetScrapValue(int setValueTo)
	{
		scrapValue = setValueTo;
		ScanNodeProperties componentInChildren = ((Component)this).gameObject.GetComponentInChildren<ScanNodeProperties>();
		if ((Object)(object)componentInChildren == (Object)null)
		{
			Debug.LogError((object)("Scan node is missing for item!: " + ((Object)((Component)this).gameObject).name));
			return;
		}
		componentInChildren.subText = $"Value: ${setValueTo}";
		componentInChildren.scrapValue = setValueTo;
	}

	public bool RequireCooldown()
	{
		if (useCooldown > 0f)
		{
			if (itemProperties.holdButtonUse && isBeingUsed)
			{
				return false;
			}
			if (currentUseCooldown <= 0f)
			{
				currentUseCooldown = useCooldown;
				return false;
			}
			return true;
		}
		return false;
	}

	[ServerRpc(RequireOwnership = false)]
	private void InteractLeftRightServerRpc(bool right)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1469591241u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref right, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1469591241u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				InteractLeftRightClientRpc(right);
			}
		}
	}

	[ClientRpc]
	private void InteractLeftRightClientRpc(bool right)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3081511085u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref right, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3081511085u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				ItemInteractLeftRight(right);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void GrabServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2618697776u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2618697776u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				GrabClientRpc();
			}
		}
	}

	[ClientRpc]
	private void GrabClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1334815929u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1334815929u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				GrabItem();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void ActivateItemServerRpc(bool onOff, bool buttonDown)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4280509730u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref onOff, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref buttonDown, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4280509730u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ActivateItemClientRpc(onOff, buttonDown);
			}
		}
	}

	[ClientRpc]
	private void ActivateItemClientRpc(bool onOff, bool buttonDown)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1761213193u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref onOff, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref buttonDown, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1761213193u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				Debug.Log((object)$"Is being used set to {onOff} by RPC");
				isBeingUsed = onOff;
				ItemActivate(onOff, buttonDown);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void DiscardItemServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1974688543u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1974688543u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DiscardItemClientRpc();
			}
		}
	}

	[ClientRpc]
	private void DiscardItemClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(335835173u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 335835173u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				DiscardItem();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void UseUpItemBatteriesServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2025123357u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2025123357u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				UseUpItemBatteriesClientRpc();
			}
		}
	}

	[ClientRpc]
	private void UseUpItemBatteriesClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(738171084u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 738171084u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				UseUpBatteries();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void EquipItemServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(947748389u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 947748389u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				EquipItemClientRpc();
			}
		}
	}

	[ClientRpc]
	private void EquipItemClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1898191537u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1898191537u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				EquipItem();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	private void PocketItemServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(101807903u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 101807903u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PocketItemClientRpc();
			}
		}
	}

	[ClientRpc]
	private void PocketItemClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3399384424u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3399384424u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				PocketItem();
			}
		}
	}

	public void ChangeOwnershipOfProp(ulong clientId)
	{
		ChangeOwnershipOfPropServerRpc(clientId);
	}

	[ServerRpc(RequireOwnership = false)]
	private void ChangeOwnershipOfPropServerRpc(ulong NewOwner)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1391130874u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, NewOwner);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1391130874u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		try
		{
			((Component)this).gameObject.GetComponent<NetworkRigidbodyModifiable>().kinematicOnOwner = true;
			((Component)this).transform.SetParent(playerHeldBy.localItemHolder, true);
			((NetworkTransform)((Component)this).gameObject.GetComponent<ClientNetworkTransform>()).InLocalSpace = true;
			((Component)this).transform.localPosition = Vector3.zero;
			((Component)this).transform.localEulerAngles = Vector3.zero;
			playerHeldBy.grabSetParentServer = false;
			((Component)this).gameObject.GetComponent<NetworkObject>().ChangeOwnership(NewOwner);
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Failed to transfer ownership of prop to client: {arg}");
		}
	}

	public virtual void EnableItemMeshes(bool enable)
	{
		MeshRenderer[] componentsInChildren = ((Component)this).gameObject.GetComponentsInChildren<MeshRenderer>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if (!((Component)componentsInChildren[i]).gameObject.CompareTag("DoNotSet") && !((Component)componentsInChildren[i]).gameObject.CompareTag("InteractTrigger"))
			{
				((Renderer)componentsInChildren[i]).enabled = enable;
			}
		}
		SkinnedMeshRenderer[] componentsInChildren2 = ((Component)this).gameObject.GetComponentsInChildren<SkinnedMeshRenderer>();
		for (int j = 0; j < componentsInChildren2.Length; j++)
		{
			((Renderer)componentsInChildren2[j]).enabled = enable;
			Debug.Log((object)("DISABLING/ENABLING SKINNEDMESH: " + ((Object)((Component)componentsInChildren2[j]).gameObject).name));
		}
	}

	public Vector3 GetItemFloorPosition(Vector3 startPosition = default(Vector3))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		if (startPosition == Vector3.zero)
		{
			startPosition = ((Component)this).transform.position + Vector3.up * 0.15f;
		}
		RaycastHit val = default(RaycastHit);
		if (Physics.Raycast(startPosition, -Vector3.up, ref val, 80f, 268437761, (QueryTriggerInteraction)1))
		{
			return ((RaycastHit)(ref val)).point + Vector3.up * 0.04f + itemProperties.verticalOffset * Vector3.up;
		}
		return startPosition;
	}

	public NetworkObject GetPhysicsRegionOfDroppedObject(PlayerControllerB playerDropping, out Vector3 hitPoint)
	{
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		Transform val = null;
		Ray val2 = default(Ray);
		RaycastHit val3 = default(RaycastHit);
		if ((Object)(object)playerDropping != (Object)null && itemProperties.allowDroppingAheadOfPlayer)
		{
			Debug.DrawRay(((Component)playerDropping).transform.position + Vector3.up * 0.4f, ((Component)playerDropping.gameplayCamera).transform.forward * 1.7f, Color.yellow, 1f);
			((Ray)(ref val2))._002Ector(((Component)playerDropping).transform.position + Vector3.up * 0.4f, ((Component)playerDropping.gameplayCamera).transform.forward);
			Vector3 val4 = ((!Physics.Raycast(val2, ref val3, 1.7f, 1342179585, (QueryTriggerInteraction)1)) ? ((Ray)(ref val2)).GetPoint(1.7f) : ((Ray)(ref val2)).GetPoint(Mathf.Clamp(((RaycastHit)(ref val3)).distance - 0.3f, 0.01f, 2f)));
			if (Physics.Raycast(val4, -Vector3.up, ref val3, 80f, 1342179585, (QueryTriggerInteraction)1))
			{
				Debug.DrawRay(val4, -Vector3.up * 80f, Color.yellow, 2f);
				val = ((Component)((RaycastHit)(ref val3)).collider).gameObject.transform;
			}
		}
		else
		{
			((Ray)(ref val2))._002Ector(((Component)this).transform.position, -Vector3.up);
			if (Physics.Raycast(val2, ref val3, 80f, 1342179585, (QueryTriggerInteraction)1))
			{
				Debug.DrawRay(((Component)this).transform.position, -Vector3.up * 80f, Color.blue, 2f);
				val = ((Component)((RaycastHit)(ref val3)).collider).gameObject.transform;
			}
		}
		if ((Object)(object)val != (Object)null)
		{
			PlayerPhysicsRegion componentInChildren = ((Component)val).GetComponentInChildren<PlayerPhysicsRegion>();
			if ((Object)(object)componentInChildren != (Object)null && componentInChildren.allowDroppingItems && componentInChildren.itemDropCollider.ClosestPoint(((RaycastHit)(ref val3)).point) == ((RaycastHit)(ref val3)).point)
			{
				NetworkObject parentNetworkObject = componentInChildren.parentNetworkObject;
				if ((Object)(object)parentNetworkObject != (Object)null)
				{
					Vector3 addPositionOffsetToItems = componentInChildren.addPositionOffsetToItems;
					hitPoint = componentInChildren.physicsTransform.InverseTransformPoint(((RaycastHit)(ref val3)).point + Vector3.up * 0.04f + itemProperties.verticalOffset * Vector3.up + addPositionOffsetToItems);
					return parentNetworkObject;
				}
				Debug.LogError((object)("Error: physics region transform does not have network object?: " + ((Object)((Component)val).gameObject).name));
			}
		}
		hitPoint = Vector3.zero;
		return null;
	}

	public virtual void ReactToSellingItemOnCounter()
	{
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_GrabbableObject()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3484508350u, new RpcReceiveHandler(__rpc_handler_3484508350));
		NetworkManager.__rpc_func_table.Add(2670202430u, new RpcReceiveHandler(__rpc_handler_2670202430));
		NetworkManager.__rpc_func_table.Add(1469591241u, new RpcReceiveHandler(__rpc_handler_1469591241));
		NetworkManager.__rpc_func_table.Add(3081511085u, new RpcReceiveHandler(__rpc_handler_3081511085));
		NetworkManager.__rpc_func_table.Add(2618697776u, new RpcReceiveHandler(__rpc_handler_2618697776));
		NetworkManager.__rpc_func_table.Add(1334815929u, new RpcReceiveHandler(__rpc_handler_1334815929));
		NetworkManager.__rpc_func_table.Add(4280509730u, new RpcReceiveHandler(__rpc_handler_4280509730));
		NetworkManager.__rpc_func_table.Add(1761213193u, new RpcReceiveHandler(__rpc_handler_1761213193));
		NetworkManager.__rpc_func_table.Add(1974688543u, new RpcReceiveHandler(__rpc_handler_1974688543));
		NetworkManager.__rpc_func_table.Add(335835173u, new RpcReceiveHandler(__rpc_handler_335835173));
		NetworkManager.__rpc_func_table.Add(2025123357u, new RpcReceiveHandler(__rpc_handler_2025123357));
		NetworkManager.__rpc_func_table.Add(738171084u, new RpcReceiveHandler(__rpc_handler_738171084));
		NetworkManager.__rpc_func_table.Add(947748389u, new RpcReceiveHandler(__rpc_handler_947748389));
		NetworkManager.__rpc_func_table.Add(1898191537u, new RpcReceiveHandler(__rpc_handler_1898191537));
		NetworkManager.__rpc_func_table.Add(101807903u, new RpcReceiveHandler(__rpc_handler_101807903));
		NetworkManager.__rpc_func_table.Add(3399384424u, new RpcReceiveHandler(__rpc_handler_3399384424));
		NetworkManager.__rpc_func_table.Add(1391130874u, new RpcReceiveHandler(__rpc_handler_1391130874));
	}

	private static void __rpc_handler_3484508350(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int charge = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref charge);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).SyncBatteryServerRpc(charge);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2670202430(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int charge = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref charge);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GrabbableObject)(object)target).SyncBatteryClientRpc(charge);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1469591241(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool right = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref right, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).InteractLeftRightServerRpc(right);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3081511085(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool right = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref right, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GrabbableObject)(object)target).InteractLeftRightClientRpc(right);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2618697776(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).GrabServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1334815929(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GrabbableObject)(object)target).GrabClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4280509730(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool onOff = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref onOff, default(ForPrimitives));
			bool buttonDown = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref buttonDown, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).ActivateItemServerRpc(onOff, buttonDown);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1761213193(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool onOff = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref onOff, default(ForPrimitives));
			bool buttonDown = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref buttonDown, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GrabbableObject)(object)target).ActivateItemClientRpc(onOff, buttonDown);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1974688543(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).DiscardItemServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_335835173(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GrabbableObject)(object)target).DiscardItemClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2025123357(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).UseUpItemBatteriesServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_738171084(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GrabbableObject)(object)target).UseUpItemBatteriesClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_947748389(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).EquipItemServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1898191537(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GrabbableObject)(object)target).EquipItemClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_101807903(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).PocketItemServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3399384424(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GrabbableObject)(object)target).PocketItemClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1391130874(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong newOwner = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref newOwner);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GrabbableObject)(object)target).ChangeOwnershipOfPropServerRpc(newOwner);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "GrabbableObject";
	}
}
