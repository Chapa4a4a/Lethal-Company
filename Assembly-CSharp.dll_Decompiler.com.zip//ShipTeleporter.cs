using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class ShipTeleporter : NetworkBehaviour
{
	public bool isInverseTeleporter;

	public Transform teleportOutPosition;

	[Space(5f)]
	public Transform teleporterPosition;

	public Animator teleporterAnimator;

	public Animator buttonAnimator;

	public AudioSource buttonAudio;

	public AudioSource shipTeleporterAudio;

	public AudioClip buttonPressSFX;

	public AudioClip teleporterSpinSFX;

	public AudioClip teleporterBeamUpSFX;

	public AudioClip beamUpPlayerBodySFX;

	private Coroutine beamUpPlayerCoroutine;

	public int teleporterId = 1;

	private int[] playersBeingTeleported;

	private float cooldownTime;

	public float cooldownAmount;

	public InteractTrigger buttonTrigger;

	public static bool hasBeenSpawnedThisSession;

	public static bool hasBeenSpawnedThisSessionInverse;

	private Random shipTeleporterSeed;

	public ReverbPreset caveReverb;

	public void SetRandomSeed()
	{
		if (isInverseTeleporter)
		{
			shipTeleporterSeed = new Random(StartOfRound.Instance.randomMapSeed + 17 + (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	private void Awake()
	{
		playersBeingTeleported = new int[4] { -1, -1, -1, -1 };
		if ((isInverseTeleporter && hasBeenSpawnedThisSessionInverse) || (!isInverseTeleporter && hasBeenSpawnedThisSession))
		{
			buttonTrigger.interactable = false;
			cooldownTime = cooldownAmount;
		}
		else if (isInverseTeleporter && !StartOfRound.Instance.inShipPhase)
		{
			SetRandomSeed();
		}
		if (isInverseTeleporter)
		{
			hasBeenSpawnedThisSessionInverse = true;
		}
		else
		{
			hasBeenSpawnedThisSession = true;
		}
	}

	private void Update()
	{
		if (!buttonTrigger.interactable)
		{
			if (cooldownTime <= 0f)
			{
				buttonTrigger.interactable = true;
				return;
			}
			buttonTrigger.disabledHoverTip = $"[Cooldown: {(int)cooldownTime} sec.]";
			cooldownTime -= Time.deltaTime;
		}
	}

	private void OnDisable()
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Expected O, but got Unknown
		for (int i = 0; i < playersBeingTeleported.Length; i++)
		{
			if (playersBeingTeleported[i] == teleporterId)
			{
				StartOfRound.Instance.allPlayerScripts[playersBeingTeleported[i]].shipTeleporterId = -1;
			}
		}
		((UnityEvent)StartOfRound.Instance.StartNewRoundEvent).RemoveListener(new UnityAction(SetRandomSeed));
	}

	private void OnEnable()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		((UnityEvent)StartOfRound.Instance.StartNewRoundEvent).AddListener(new UnityAction(SetRandomSeed));
	}

	public void PressTeleportButtonOnLocalClient()
	{
		if (!isInverseTeleporter || (!StartOfRound.Instance.inShipPhase && SceneManager.sceneCount > 1))
		{
			PressTeleportButtonServerRpc();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PressTeleportButtonServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(389447712u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 389447712u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PressTeleportButtonClientRpc();
			}
		}
	}

	[ClientRpc]
	public void PressTeleportButtonClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2773756087u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2773756087u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		PressButtonEffects();
		if (beamUpPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(beamUpPlayerCoroutine);
		}
		cooldownTime = cooldownAmount;
		buttonTrigger.interactable = false;
		if (isInverseTeleporter)
		{
			if (CanUseInverseTeleporter())
			{
				beamUpPlayerCoroutine = ((MonoBehaviour)this).StartCoroutine(beamOutPlayer());
			}
		}
		else
		{
			beamUpPlayerCoroutine = ((MonoBehaviour)this).StartCoroutine(beamUpPlayer());
		}
	}

	private void PressButtonEffects()
	{
		buttonAnimator.SetTrigger("press");
		buttonAnimator.SetBool("GlassOpen", false);
		((Component)buttonAnimator).GetComponentInChildren<AnimatedObjectTrigger>().boolValue = false;
		if (isInverseTeleporter)
		{
			if (CanUseInverseTeleporter())
			{
				teleporterAnimator.SetTrigger("useInverseTeleporter");
			}
			else
			{
				Debug.Log((object)$"Using inverse teleporter was not allowed; {StartOfRound.Instance.inShipPhase}; {StartOfRound.Instance.currentLevel.PlanetName}");
			}
		}
		else
		{
			teleporterAnimator.SetTrigger("useTeleporter");
		}
		buttonAudio.PlayOneShot(buttonPressSFX);
		WalkieTalkie.TransmitOneShotAudio(buttonAudio, buttonPressSFX);
	}

	private bool CanUseInverseTeleporter()
	{
		if (!StartOfRound.Instance.inShipPhase)
		{
			return StartOfRound.Instance.currentLevel.spawnEnemiesAndScrap;
		}
		return false;
	}

	private IEnumerator beamOutPlayer()
	{
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			yield break;
		}
		if (StartOfRound.Instance.inShipPhase)
		{
			Debug.Log((object)"Attempted using teleporter while in ship phase");
			yield break;
		}
		shipTeleporterAudio.PlayOneShot(teleporterSpinSFX);
		for (int b = 0; b < 5; b++)
		{
			for (int i = 0; i < StartOfRound.Instance.allPlayerObjects.Length; i++)
			{
				PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[i];
				Vector3 position = ((Component)playerControllerB).transform.position;
				if ((Object)(object)playerControllerB.deadBody != (Object)null)
				{
					position = ((Component)playerControllerB.deadBody.bodyParts[5]).transform.position;
				}
				if (Vector3.Distance(position, teleportOutPosition.position) > 2f)
				{
					if (playerControllerB.shipTeleporterId != 1)
					{
						if ((Object)(object)playerControllerB.deadBody != (Object)null)
						{
							playerControllerB.deadBody.beamOutParticle.Stop();
							playerControllerB.deadBody.bodyAudio.Stop();
						}
						else
						{
							playerControllerB.beamOutBuildupParticle.Stop();
							playerControllerB.movementAudio.Stop();
						}
					}
					continue;
				}
				if (playerControllerB.shipTeleporterId == 1)
				{
					Debug.Log((object)$"Cancelled teleporting #{playerControllerB.playerClientId} with inverse teleporter; {playerControllerB.shipTeleporterId}");
					continue;
				}
				SetPlayerTeleporterId(playerControllerB, 2);
				if ((Object)(object)playerControllerB.deadBody != (Object)null)
				{
					if ((Object)(object)playerControllerB.deadBody.beamUpParticle == (Object)null)
					{
						yield break;
					}
					if (!playerControllerB.deadBody.beamOutParticle.isPlaying)
					{
						playerControllerB.deadBody.beamOutParticle.Play();
						playerControllerB.deadBody.bodyAudio.PlayOneShot(beamUpPlayerBodySFX);
					}
				}
				else if (!playerControllerB.beamOutBuildupParticle.isPlaying)
				{
					playerControllerB.beamOutBuildupParticle.Play();
					playerControllerB.movementAudio.PlayOneShot(beamUpPlayerBodySFX);
				}
			}
			yield return (object)new WaitForSeconds(1f);
		}
		for (int j = 0; j < StartOfRound.Instance.allPlayerObjects.Length; j++)
		{
			PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[j];
			if (playerControllerB.shipTeleporterId == 1)
			{
				Debug.Log((object)$"Player #{playerControllerB.playerClientId} is in teleport 1, skipping");
				continue;
			}
			SetPlayerTeleporterId(playerControllerB, -1);
			if ((Object)(object)playerControllerB.deadBody != (Object)null)
			{
				playerControllerB.deadBody.beamOutParticle.Stop();
				playerControllerB.deadBody.bodyAudio.Stop();
			}
			else
			{
				playerControllerB.beamOutBuildupParticle.Stop();
				playerControllerB.movementAudio.Stop();
			}
			if ((Object)(object)playerControllerB != (Object)(object)GameNetworkManager.Instance.localPlayerController || StartOfRound.Instance.inShipPhase)
			{
				continue;
			}
			Vector3 position2 = ((Component)playerControllerB).transform.position;
			if ((Object)(object)playerControllerB.deadBody != (Object)null)
			{
				position2 = ((Component)playerControllerB.deadBody.bodyParts[5]).transform.position;
			}
			if (Vector3.Distance(position2, teleportOutPosition.position) < 2f)
			{
				if (RoundManager.Instance.insideAINodes.Length != 0)
				{
					Vector3 position3 = RoundManager.Instance.insideAINodes[shipTeleporterSeed.Next(0, RoundManager.Instance.insideAINodes.Length)].transform.position;
					Debug.DrawRay(position3, Vector3.up * 1f, Color.red);
					position3 = RoundManager.Instance.GetRandomNavMeshPositionInBoxPredictable(position3, 10f, default(NavMeshHit), shipTeleporterSeed);
					Debug.DrawRay(position3 + Vector3.right * 0.01f, Vector3.up * 3f, Color.green);
					SetPlayerTeleporterId(playerControllerB, 2);
					if ((Object)(object)playerControllerB.deadBody != (Object)null)
					{
						TeleportPlayerBodyOutServerRpc((int)playerControllerB.playerClientId, position3);
						continue;
					}
					TeleportPlayerOutWithInverseTeleporter((int)playerControllerB.playerClientId, position3);
					TeleportPlayerOutServerRpc((int)playerControllerB.playerClientId, position3);
				}
			}
			else
			{
				Debug.Log((object)$"Player #{playerControllerB.playerClientId} is not close enough to teleporter to beam out");
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void TeleportPlayerOutServerRpc(int playerObj, Vector3 teleportPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3033548568u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObj);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref teleportPos);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3033548568u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				TeleportPlayerOutClientRpc(playerObj, teleportPos);
			}
		}
	}

	[ClientRpc]
	public void TeleportPlayerOutClientRpc(int playerObj, Vector3 teleportPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3527914562u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObj);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref teleportPos);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3527914562u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !StartOfRound.Instance.inShipPhase && !((NetworkBehaviour)StartOfRound.Instance.allPlayerScripts[playerObj]).IsOwner)
			{
				TeleportPlayerOutWithInverseTeleporter(playerObj, teleportPos);
			}
		}
	}

	private void SpikeTrapsReactToInverseTeleport()
	{
		SpikeRoofTrap[] array = Object.FindObjectsByType<SpikeRoofTrap>((FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			array[i].timeSinceMovingUp = Time.realtimeSinceStartup - 1f;
		}
	}

	private void SetCaveReverb(PlayerControllerB playerScript)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if (RoundManager.Instance.currentDungeonType != 4)
		{
			return;
		}
		GameObject[] array = GameObject.FindGameObjectsWithTag("CaveNode");
		for (int i = 0; i < array.Length; i++)
		{
			if (Vector3.Distance(array[i].transform.position, ((Component)playerScript).transform.position) < 12f)
			{
				playerScript.reverbPreset = caveReverb;
			}
		}
	}

	private void TeleportPlayerOutWithInverseTeleporter(int playerObj, Vector3 teleportPos)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		if (StartOfRound.Instance.allPlayerScripts[playerObj].isPlayerDead)
		{
			((MonoBehaviour)this).StartCoroutine(teleportBodyOut(playerObj, teleportPos));
			return;
		}
		SpikeTrapsReactToInverseTeleport();
		SetCaveReverb(StartOfRound.Instance.allPlayerScripts[playerObj]);
		PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[playerObj];
		SetPlayerTeleporterId(playerControllerB, -1);
		playerControllerB.DropAllHeldItems();
		if (Object.op_Implicit((Object)(object)Object.FindObjectOfType<AudioReverbPresets>()))
		{
			Object.FindObjectOfType<AudioReverbPresets>().audioPresets[2].ChangeAudioReverbForPlayer(playerControllerB);
		}
		playerControllerB.isInElevator = false;
		playerControllerB.isInHangarShipRoom = false;
		playerControllerB.isInsideFactory = true;
		playerControllerB.averageVelocity = 0f;
		playerControllerB.velocityLastFrame = Vector3.zero;
		StartOfRound.Instance.allPlayerScripts[playerObj].TeleportPlayer(teleportPos);
		StartOfRound.Instance.allPlayerScripts[playerObj].beamOutParticle.Play();
		shipTeleporterAudio.PlayOneShot(teleporterBeamUpSFX);
		StartOfRound.Instance.allPlayerScripts[playerObj].movementAudio.PlayOneShot(teleporterBeamUpSFX);
		if ((Object)(object)playerControllerB == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			Debug.Log((object)"Teleporter shaking camera");
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void TeleportPlayerBodyOutServerRpc(int playerObj, Vector3 teleportPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(660932683u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObj);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref teleportPos);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 660932683u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				TeleportPlayerBodyOutClientRpc(playerObj, teleportPos);
			}
		}
	}

	[ClientRpc]
	public void TeleportPlayerBodyOutClientRpc(int playerObj, Vector3 teleportPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1544539621u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObj);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref teleportPos);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1544539621u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				((MonoBehaviour)this).StartCoroutine(teleportBodyOut(playerObj, teleportPos));
			}
		}
	}

	private IEnumerator teleportBodyOut(int playerObj, Vector3 teleportPosition)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		float startTime = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)StartOfRound.Instance.allPlayerScripts[playerObj].deadBody != (Object)null || Time.realtimeSinceStartup - startTime > 2f));
		if (StartOfRound.Instance.inShipPhase || SceneManager.sceneCount <= 1)
		{
			yield break;
		}
		DeadBodyInfo deadBody = StartOfRound.Instance.allPlayerScripts[playerObj].deadBody;
		SetPlayerTeleporterId(StartOfRound.Instance.allPlayerScripts[playerObj], -1);
		if ((Object)(object)deadBody != (Object)null)
		{
			deadBody.attachedTo = null;
			deadBody.attachedLimb = null;
			deadBody.secondaryAttachedLimb = null;
			deadBody.secondaryAttachedTo = null;
			if ((Object)(object)deadBody.grabBodyObject != (Object)null && deadBody.grabBodyObject.isHeld && (Object)(object)deadBody.grabBodyObject.playerHeldBy != (Object)null)
			{
				deadBody.grabBodyObject.playerHeldBy.DropAllHeldItems();
			}
			deadBody.isInShip = false;
			deadBody.parentedToShip = false;
			((Component)deadBody).transform.SetParent((Transform)null, true);
			deadBody.SetRagdollPositionSafely(teleportPosition, disableSpecialEffects: true);
		}
	}

	private IEnumerator beamUpPlayer()
	{
		shipTeleporterAudio.PlayOneShot(teleporterSpinSFX);
		PlayerControllerB playerToBeamUp = StartOfRound.Instance.mapScreen.targetedPlayer;
		if ((Object)(object)playerToBeamUp == (Object)null)
		{
			Debug.Log((object)"Targeted player is null");
			yield break;
		}
		if ((Object)(object)playerToBeamUp.redirectToEnemy != (Object)null)
		{
			Debug.Log((object)$"Attemping to teleport enemy '{((Object)((Component)playerToBeamUp.redirectToEnemy).gameObject).name}' (tied to player #{playerToBeamUp.playerClientId}) to ship.");
			if (StartOfRound.Instance.shipIsLeaving)
			{
				Debug.Log((object)$"Ship could not teleport enemy '{((Object)((Component)playerToBeamUp.redirectToEnemy).gameObject).name}' (tied to player #{playerToBeamUp.playerClientId}) because the ship is leaving the nav mesh.");
			}
			playerToBeamUp.redirectToEnemy.ShipTeleportEnemy();
			yield return (object)new WaitForSeconds(3f);
			shipTeleporterAudio.PlayOneShot(teleporterBeamUpSFX);
			if (GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
		}
		SetPlayerTeleporterId(playerToBeamUp, 1);
		if ((Object)(object)playerToBeamUp.deadBody != (Object)null)
		{
			if ((Object)(object)playerToBeamUp.deadBody.beamUpParticle == (Object)null)
			{
				yield break;
			}
			playerToBeamUp.deadBody.beamUpParticle.Play();
			playerToBeamUp.deadBody.bodyAudio.PlayOneShot(beamUpPlayerBodySFX);
		}
		else
		{
			playerToBeamUp.beamUpParticle.Play();
			playerToBeamUp.movementAudio.PlayOneShot(beamUpPlayerBodySFX);
		}
		Debug.Log((object)"Teleport A");
		yield return (object)new WaitForSeconds(3f);
		bool flag = false;
		if ((Object)(object)playerToBeamUp.deadBody != (Object)null)
		{
			if ((Object)(object)playerToBeamUp.deadBody.grabBodyObject == (Object)null || !playerToBeamUp.deadBody.grabBodyObject.isHeldByEnemy)
			{
				flag = true;
				playerToBeamUp.deadBody.attachedTo = null;
				playerToBeamUp.deadBody.attachedLimb = null;
				playerToBeamUp.deadBody.secondaryAttachedLimb = null;
				playerToBeamUp.deadBody.secondaryAttachedTo = null;
				playerToBeamUp.deadBody.SetRagdollPositionSafely(teleporterPosition.position, disableSpecialEffects: true);
				((Component)playerToBeamUp.deadBody).transform.SetParent(StartOfRound.Instance.elevatorTransform, true);
				if ((Object)(object)playerToBeamUp.deadBody.grabBodyObject != (Object)null && playerToBeamUp.deadBody.grabBodyObject.isHeld && (Object)(object)playerToBeamUp.deadBody.grabBodyObject.playerHeldBy != (Object)null)
				{
					playerToBeamUp.deadBody.grabBodyObject.playerHeldBy.DropAllHeldItems();
				}
			}
		}
		else
		{
			flag = true;
			playerToBeamUp.DropAllHeldItems();
			if (Object.op_Implicit((Object)(object)Object.FindObjectOfType<AudioReverbPresets>()))
			{
				Object.FindObjectOfType<AudioReverbPresets>().audioPresets[3].ChangeAudioReverbForPlayer(playerToBeamUp);
			}
			playerToBeamUp.isInElevator = true;
			playerToBeamUp.isInHangarShipRoom = true;
			playerToBeamUp.isInsideFactory = false;
			playerToBeamUp.averageVelocity = 0f;
			playerToBeamUp.velocityLastFrame = Vector3.zero;
			if (flag == Object.op_Implicit((Object)(object)GameNetworkManager.Instance.localPlayerController))
			{
				TimeOfDay.Instance.SetInsideLightingDimness(doNotLerp: false, setValueTo: true);
			}
			playerToBeamUp.TeleportPlayer(teleporterPosition.position, withRotation: true, 160f);
		}
		Debug.Log((object)"Teleport B");
		SetPlayerTeleporterId(playerToBeamUp, -1);
		if (flag)
		{
			shipTeleporterAudio.PlayOneShot(teleporterBeamUpSFX);
			if (GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
		}
		Debug.Log((object)"Teleport C");
	}

	private void SetPlayerTeleporterId(PlayerControllerB playerScript, int teleporterId)
	{
		playerScript.shipTeleporterId = teleporterId;
		playersBeingTeleported[playerScript.playerClientId] = (int)playerScript.playerClientId;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ShipTeleporter()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(389447712u, new RpcReceiveHandler(__rpc_handler_389447712));
		NetworkManager.__rpc_func_table.Add(2773756087u, new RpcReceiveHandler(__rpc_handler_2773756087));
		NetworkManager.__rpc_func_table.Add(3033548568u, new RpcReceiveHandler(__rpc_handler_3033548568));
		NetworkManager.__rpc_func_table.Add(3527914562u, new RpcReceiveHandler(__rpc_handler_3527914562));
		NetworkManager.__rpc_func_table.Add(660932683u, new RpcReceiveHandler(__rpc_handler_660932683));
		NetworkManager.__rpc_func_table.Add(1544539621u, new RpcReceiveHandler(__rpc_handler_1544539621));
	}

	private static void __rpc_handler_389447712(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShipTeleporter)(object)target).PressTeleportButtonServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2773756087(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShipTeleporter)(object)target).PressTeleportButtonClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3033548568(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObj = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObj);
			Vector3 teleportPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref teleportPos);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShipTeleporter)(object)target).TeleportPlayerOutServerRpc(playerObj, teleportPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3527914562(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObj = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObj);
			Vector3 teleportPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref teleportPos);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShipTeleporter)(object)target).TeleportPlayerOutClientRpc(playerObj, teleportPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_660932683(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObj = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObj);
			Vector3 teleportPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref teleportPos);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShipTeleporter)(object)target).TeleportPlayerBodyOutServerRpc(playerObj, teleportPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1544539621(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObj = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObj);
			Vector3 teleportPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref teleportPos);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShipTeleporter)(object)target).TeleportPlayerBodyOutClientRpc(playerObj, teleportPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ShipTeleporter";
	}
}
