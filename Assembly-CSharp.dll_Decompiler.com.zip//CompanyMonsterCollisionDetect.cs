using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class CompanyMonsterCollisionDetect : MonoBehaviour
{
	public int monsterAnimationID;

	private void OnTriggerEnter(Collider other)
	{
		if (!((Object)(object)NetworkManager.Singleton == (Object)null) && ((Component)other).CompareTag("Player"))
		{
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)null && !component.isPlayerDead && ((NetworkBehaviour)component).IsOwner)
			{
				Object.FindObjectOfType<DepositItemsDesk>().CollisionDetect(monsterAnimationID);
			}
		}
	}
}
