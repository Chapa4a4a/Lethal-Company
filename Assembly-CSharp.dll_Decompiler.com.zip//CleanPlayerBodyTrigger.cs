using GameNetcodeStuff;
using UnityEngine;

public class CleanPlayerBodyTrigger : MonoBehaviour
{
	private bool enableCleaning = true;

	public void EnableCleaningTrigger(bool enable)
	{
		enableCleaning = enable;
	}

	private void OnTriggerStay(Collider other)
	{
		if (enableCleaning && ((Component)other).CompareTag("Player"))
		{
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)null)
			{
				component.RemoveBloodFromBody();
			}
		}
	}
}
