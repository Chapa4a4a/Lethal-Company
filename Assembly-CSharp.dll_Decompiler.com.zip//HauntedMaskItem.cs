using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class HauntedMaskItem : GrabbableObject, IVisibleThreat
{
	private bool maskOn;

	private bool attaching;

	private bool clampedToHead;

	private float lastIntervalCheck;

	private float attachTimer = 5f;

	private bool finishedAttaching;

	public AudioSource maskAudio;

	public AudioClip maskAttachAudio;

	public AudioClip maskAttachAudioLocal;

	public Animator maskAnimator;

	public MeshRenderer maskEyesFilled;

	public GameObject headMaskPrefab;

	public Transform currentHeadMask;

	public Vector3 headPositionOffset;

	public Vector3 headRotationOffset;

	private PlayerControllerB previousPlayerHeldBy;

	public EnemyType mimicEnemy;

	private bool holdingLastFrame;

	public bool maskIsHaunted = true;

	public int maskTypeId;

	ThreatType IVisibleThreat.type => ThreatType.Item;

	bool IVisibleThreat.IsThreatDead()
	{
		return false;
	}

	GrabbableObject IVisibleThreat.GetHeldObject()
	{
		return null;
	}

	int IVisibleThreat.SendSpecialBehaviour(int id)
	{
		return 0;
	}

	int IVisibleThreat.GetInterestLevel()
	{
		return 0;
	}

	int IVisibleThreat.GetThreatLevel(Vector3 seenByPosition)
	{
		if (isHeld)
		{
			if (holdingLastFrame)
			{
				return 4;
			}
			return 2;
		}
		return 1;
	}

	Transform IVisibleThreat.GetThreatLookTransform()
	{
		return ((Component)this).transform;
	}

	Transform IVisibleThreat.GetThreatTransform()
	{
		return ((Component)this).transform;
	}

	Vector3 IVisibleThreat.GetThreatVelocity()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		return Vector3.zero;
	}

	float IVisibleThreat.GetVisibility()
	{
		if (isPocketed)
		{
			return 0f;
		}
		return 1f;
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		if (!attaching && !finishedAttaching && !((Object)(object)playerHeldBy == (Object)null) && ((NetworkBehaviour)this).IsOwner)
		{
			playerHeldBy.playerBodyAnimator.SetBool("HoldMask", buttonDown);
			Debug.Log((object)"attaching: {attaching}; finishedAttaching: {finishedAttaching}");
			Debug.Log((object)$"Setting maskOn {buttonDown}");
			maskOn = buttonDown;
			playerHeldBy.activatingItem = buttonDown;
		}
	}

	public override void EquipItem()
	{
		base.EquipItem();
		lastIntervalCheck = Time.realtimeSinceStartup + 10f;
		previousPlayerHeldBy = playerHeldBy;
		holdingLastFrame = true;
	}

	public override void DiscardItem()
	{
		base.DiscardItem();
		if ((Object)(object)currentHeadMask != (Object)null)
		{
			Debug.Log((object)"Discard item called; not going through since headmask is not null");
			return;
		}
		Debug.Log((object)$"Discard item called; headmask null: {(Object)(object)currentHeadMask == (Object)null}");
		previousPlayerHeldBy.activatingItem = false;
		maskOn = false;
		CancelAttachToPlayerOnLocalClient();
	}

	public override void PocketItem()
	{
		base.PocketItem();
		if ((Object)(object)currentHeadMask != (Object)null)
		{
			Debug.Log((object)"Discard item called; not going through since headmask is not null");
			return;
		}
		Debug.Log((object)$"Discard item called; headmask null: {(Object)(object)currentHeadMask == (Object)null}");
		maskOn = false;
		playerHeldBy.activatingItem = false;
		CancelAttachToPlayerOnLocalClient();
	}

	private void CancelAttachToPlayerOnLocalClient()
	{
		attachTimer = 8f;
		attaching = false;
		maskAnimator.SetBool("attaching", false);
		if ((Object)(object)previousPlayerHeldBy != (Object)null)
		{
			previousPlayerHeldBy.activatingItem = false;
			previousPlayerHeldBy.playerBodyAnimator.SetBool("HoldMask", false);
		}
		finishedAttaching = false;
		if ((Object)(object)currentHeadMask != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)currentHeadMask).gameObject);
		}
		if (holdingLastFrame)
		{
			holdingLastFrame = false;
		}
		try
		{
			if ((Object)(object)previousPlayerHeldBy.currentVoiceChatAudioSource == (Object)null)
			{
				StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
			}
			if ((Object)(object)previousPlayerHeldBy.currentVoiceChatAudioSource != (Object)null)
			{
				((Component)previousPlayerHeldBy.currentVoiceChatAudioSource).GetComponent<AudioLowPassFilter>().lowpassResonanceQ = 1f;
				OccludeAudio component = ((Component)previousPlayerHeldBy.currentVoiceChatAudioSource).GetComponent<OccludeAudio>();
				component.overridingLowPass = false;
				component.lowPassOverride = 20000f;
				previousPlayerHeldBy.voiceMuffledByEnemy = false;
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Caught exception while attempting to unmuffle player voice from mask item: {arg}");
		}
	}

	public void BeginAttachment()
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			AttachToPlayerOnLocalClient();
			AttachServerRpc();
		}
	}

	[ServerRpc]
	public void AttachServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2665559382u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2665559382u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			AttachClientRpc();
		}
	}

	[ClientRpc]
	public void AttachClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2055165511u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2055165511u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				AttachToPlayerOnLocalClient();
			}
		}
	}

	private void AttachToPlayerOnLocalClient()
	{
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		attaching = true;
		maskAnimator.SetBool("attaching", true);
		((Renderer)maskEyesFilled).enabled = true;
		try
		{
			if ((Object)(object)previousPlayerHeldBy.currentVoiceChatAudioSource == (Object)null)
			{
				StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
			}
			if ((Object)(object)previousPlayerHeldBy.currentVoiceChatAudioSource != (Object)null)
			{
				((Component)previousPlayerHeldBy.currentVoiceChatAudioSource).GetComponent<AudioLowPassFilter>().lowpassResonanceQ = 3f;
				OccludeAudio component = ((Component)previousPlayerHeldBy.currentVoiceChatAudioSource).GetComponent<OccludeAudio>();
				component.overridingLowPass = true;
				component.lowPassOverride = 300f;
				previousPlayerHeldBy.voiceMuffledByEnemy = true;
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Caught exception while attempting to muffle player voice from mask item: {arg}");
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			HUDManager.Instance.UIAudio.PlayOneShot(maskAttachAudioLocal, 1f);
		}
		else
		{
			previousPlayerHeldBy.movementAudio.PlayOneShot(maskAttachAudio, 1f);
			WalkieTalkie.TransmitOneShotAudio(previousPlayerHeldBy.movementAudio, maskAttachAudio);
		}
		RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 8f, 0.6f, 0, isInShipRoom && StartOfRound.Instance.hangarDoorsClosed);
	}

	public void MaskClampToHeadAnimationEvent()
	{
		Debug.Log((object)"Mask clamp animation event called");
		if (attaching && !((Object)(object)previousPlayerHeldBy == (Object)null))
		{
			Debug.Log((object)"Creating currentHeadMask");
			currentHeadMask = Object.Instantiate<GameObject>(headMaskPrefab, (Transform)null).transform;
			PositionHeadMaskWithOffset();
			previousPlayerHeldBy.playerBodyAnimator.SetBool("HoldMask", false);
			Debug.Log((object)$"Destroying object in hand; headmask null: {(Object)(object)currentHeadMask == (Object)null}");
			DestroyObjectInHand(previousPlayerHeldBy);
			clampedToHead = true;
		}
	}

	private void FinishAttaching()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner && !finishedAttaching)
		{
			finishedAttaching = true;
			if (!previousPlayerHeldBy.AllowPlayerDeath())
			{
				Debug.Log((object)"Player could not die so the mask did not spawn a mimic");
				CancelAttachToPlayerOnLocalClient();
				return;
			}
			bool isInsideFactory = previousPlayerHeldBy.isInsideFactory;
			Vector3 position = ((Component)previousPlayerHeldBy).transform.position;
			previousPlayerHeldBy.KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Suffocation, maskTypeId);
			CreateMimicServerRpc(isInsideFactory, position);
		}
	}

	[ServerRpc]
	public void CreateMimicServerRpc(bool inFactory, Vector3 playerPositionAtDeath)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1065539967u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inFactory, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref playerPositionAtDeath);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1065539967u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		if ((Object)(object)previousPlayerHeldBy == (Object)null)
		{
			Debug.LogError((object)"Previousplayerheldby is null so the mask mimic could not be spawned");
		}
		Debug.Log((object)"Server creating mimic from mask");
		Vector3 navMeshPosition = RoundManager.Instance.GetNavMeshPosition(playerPositionAtDeath, default(NavMeshHit), 10f);
		if (RoundManager.Instance.GotNavMeshPositionResult)
		{
			if ((Object)(object)mimicEnemy == (Object)null)
			{
				Debug.Log((object)"No mimic enemy set for mask");
				return;
			}
			NetworkObjectReference netObjectRef = RoundManager.Instance.SpawnEnemyGameObject(navMeshPosition, ((Component)previousPlayerHeldBy).transform.eulerAngles.y, -1, mimicEnemy);
			NetworkObject val3 = default(NetworkObject);
			if (((NetworkObjectReference)(ref netObjectRef)).TryGet(ref val3, (NetworkManager)null))
			{
				Debug.Log((object)"Got network object for mask enemy");
				MaskedPlayerEnemy component = ((Component)val3).GetComponent<MaskedPlayerEnemy>();
				component.SetSuit(previousPlayerHeldBy.currentSuitID);
				component.mimickingPlayer = previousPlayerHeldBy;
				component.SetEnemyOutside(!inFactory);
				component.SetVisibilityOfMaskedEnemy();
				component.SetMaskType(maskTypeId);
				previousPlayerHeldBy.redirectToEnemy = component;
				if ((Object)(object)previousPlayerHeldBy.deadBody != (Object)null)
				{
					previousPlayerHeldBy.deadBody.DeactivateBody(setActive: false);
				}
			}
			CreateMimicClientRpc(netObjectRef, inFactory);
		}
		else
		{
			Debug.Log((object)"No nav mesh found; no mimic could be created");
		}
	}

	[ClientRpc]
	public void CreateMimicClientRpc(NetworkObjectReference netObjectRef, bool inFactory)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3721656136u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inFactory, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3721656136u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				((MonoBehaviour)this).StartCoroutine(waitForMimicEnemySpawn(netObjectRef, inFactory));
			}
		}
	}

	private IEnumerator waitForMimicEnemySpawn(NetworkObjectReference netObjectRef, bool inFactory)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		NetworkObject netObject = null;
		float startTime = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => Time.realtimeSinceStartup - startTime > 20f || ((NetworkObjectReference)(ref netObjectRef)).TryGet(ref netObject, (NetworkManager)null)));
		if ((Object)(object)previousPlayerHeldBy.deadBody == (Object)null)
		{
			startTime = Time.realtimeSinceStartup;
			yield return (object)new WaitUntil((Func<bool>)(() => Time.realtimeSinceStartup - startTime > 20f || (Object)(object)previousPlayerHeldBy.deadBody != (Object)null));
		}
		if (!((Object)(object)previousPlayerHeldBy.deadBody == (Object)null))
		{
			previousPlayerHeldBy.deadBody.DeactivateBody(setActive: false);
			if ((Object)(object)netObject != (Object)null)
			{
				Debug.Log((object)"Got network object for mask enemy client");
				MaskedPlayerEnemy component = ((Component)netObject).GetComponent<MaskedPlayerEnemy>();
				component.mimickingPlayer = previousPlayerHeldBy;
				component.SetSuit(previousPlayerHeldBy.currentSuitID);
				component.SetEnemyOutside(!inFactory);
				component.SetVisibilityOfMaskedEnemy();
				component.SetMaskType(maskTypeId);
				previousPlayerHeldBy.redirectToEnemy = component;
			}
		}
	}

	public override void Update()
	{
		base.Update();
		if (!maskIsHaunted || !((NetworkBehaviour)this).IsOwner || (Object)(object)previousPlayerHeldBy == (Object)null || !maskOn || !holdingLastFrame || finishedAttaching)
		{
			return;
		}
		if (!attaching)
		{
			if (!StartOfRound.Instance.shipIsLeaving && (!StartOfRound.Instance.inShipPhase || !((Object)(object)StartOfRound.Instance.testRoom == (Object)null)) && Time.realtimeSinceStartup > lastIntervalCheck)
			{
				lastIntervalCheck = Time.realtimeSinceStartup + 5f;
				if (Random.Range(0, 100) < 65)
				{
					Debug.Log((object)"Got 15% chance");
					BeginAttachment();
				}
			}
		}
		else
		{
			attachTimer -= Time.deltaTime;
			if (previousPlayerHeldBy.isPlayerDead)
			{
				CancelAttachToPlayerOnLocalClient();
			}
			else if (attachTimer <= 0f)
			{
				FinishAttaching();
			}
		}
	}

	public override void OnDestroy()
	{
		((NetworkBehaviour)this).OnDestroy();
		if ((Object)(object)currentHeadMask != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)currentHeadMask).gameObject);
		}
	}

	public override void LateUpdate()
	{
		base.LateUpdate();
		if (!((Object)(object)previousPlayerHeldBy == (Object)null) && clampedToHead && (Object)(object)currentHeadMask != (Object)null)
		{
			if (previousPlayerHeldBy.isPlayerDead)
			{
				Object.Destroy((Object)(object)((Component)currentHeadMask).gameObject);
			}
			else
			{
				PositionHeadMaskWithOffset();
			}
		}
	}

	private void PositionHeadMaskWithOffset()
	{
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			currentHeadMask.rotation = ((Component)previousPlayerHeldBy.gameplayCamera).transform.rotation;
			currentHeadMask.Rotate(headRotationOffset);
			currentHeadMask.position = ((Component)previousPlayerHeldBy.gameplayCamera).transform.position;
			Vector3 val = headPositionOffset;
			val = ((Component)previousPlayerHeldBy.gameplayCamera).transform.rotation * val;
			Transform obj = currentHeadMask;
			obj.position += val;
		}
		else
		{
			currentHeadMask.rotation = previousPlayerHeldBy.playerGlobalHead.rotation;
			currentHeadMask.Rotate(headRotationOffset);
			currentHeadMask.position = previousPlayerHeldBy.playerGlobalHead.position;
			Vector3 val2 = headPositionOffset + Vector3.up * 0.25f;
			val2 = previousPlayerHeldBy.playerGlobalHead.rotation * val2;
			Transform obj2 = currentHeadMask;
			obj2.position += val2;
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_HauntedMaskItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2665559382u, new RpcReceiveHandler(__rpc_handler_2665559382));
		NetworkManager.__rpc_func_table.Add(2055165511u, new RpcReceiveHandler(__rpc_handler_2055165511));
		NetworkManager.__rpc_func_table.Add(1065539967u, new RpcReceiveHandler(__rpc_handler_1065539967));
		NetworkManager.__rpc_func_table.Add(3721656136u, new RpcReceiveHandler(__rpc_handler_3721656136));
	}

	private static void __rpc_handler_2665559382(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HauntedMaskItem)(object)target).AttachServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2055165511(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HauntedMaskItem)(object)target).AttachClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1065539967(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool inFactory = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inFactory, default(ForPrimitives));
			Vector3 playerPositionAtDeath = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref playerPositionAtDeath);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((HauntedMaskItem)(object)target).CreateMimicServerRpc(inFactory, playerPositionAtDeath);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3721656136(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference netObjectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
			bool inFactory = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inFactory, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((HauntedMaskItem)(object)target).CreateMimicClientRpc(netObjectRef, inFactory);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "HauntedMaskItem";
	}
}
