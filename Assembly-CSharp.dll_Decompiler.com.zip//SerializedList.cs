using Unity.Netcode;

internal struct SerializedList : INetworkSerializable
{
	public ulong[] Value;

	unsafe void INetworkSerializable.NetworkSerialize<T>(BufferSerializer<T> serializer)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		((BufferSerializer<ulong>*)(&serializer))->SerializeValue<ulong>(ref Value, default(ForPrimitives));
	}
}
