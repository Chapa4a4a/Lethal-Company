using System;
using System.Collections;
using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class ThunderAndLightningScript : MonoBehaviour
{
	private class LightningBoltHandler
	{
		private ThunderAndLightningScript script;

		private readonly Random random = new Random();

		public float VolumeMultiplier { get; set; }

		public LightningBoltHandler(ThunderAndLightningScript script)
		{
			this.script = script;
			CalculateNextLightningTime();
		}

		private void UpdateLighting()
		{
			if (script.lightningInProgress)
			{
				return;
			}
			if (script.ModifySkyboxExposure)
			{
				script.skyboxExposureStorm = 0.35f;
				if ((Object)(object)script.skyboxMaterial != (Object)null && script.skyboxMaterial.HasProperty("_Exposure"))
				{
					script.skyboxMaterial.SetFloat("_Exposure", script.skyboxExposureStorm);
				}
			}
			CheckForLightning();
		}

		private void CalculateNextLightningTime()
		{
			script.nextLightningTime = DigitalRuby.ThunderAndLightning.LightningBoltScript.TimeSinceStart + script.LightningIntervalTimeRange.Random(random);
			script.lightningInProgress = false;
			if (script.ModifySkyboxExposure && script.skyboxMaterial.HasProperty("_Exposure"))
			{
				script.skyboxMaterial.SetFloat("_Exposure", script.skyboxExposureStorm);
			}
		}

		public IEnumerator ProcessLightning(Vector3? _start, Vector3? _end, bool intense, bool visible)
		{
			script.lightningInProgress = true;
			float intensity;
			float time;
			AudioClip[] sounds;
			if (intense)
			{
				float num = Random.Range(0f, 1f);
				intensity = Mathf.Lerp(2f, 8f, num);
				time = 5f / intensity;
				sounds = script.ThunderSoundsIntense;
			}
			else
			{
				float num2 = Random.Range(0f, 1f);
				intensity = Mathf.Lerp(0f, 2f, num2);
				time = 30f / intensity;
				sounds = script.ThunderSoundsNormal;
			}
			if ((Object)(object)script.skyboxMaterial != (Object)null && script.ModifySkyboxExposure)
			{
				script.skyboxMaterial.SetFloat("_Exposure", Mathf.Max(intensity * 0.5f, script.skyboxExposureStorm));
			}
			Strike(_start, _end, intense, intensity, script.Camera, visible ? script.Camera : null);
			CalculateNextLightningTime();
			if (intensity >= 1f && sounds != null && sounds.Length != 0)
			{
				yield return new WaitForSecondsLightning(time);
				AudioClip val;
				do
				{
					val = sounds[Random.Range(0, sounds.Length - 1)];
				}
				while (sounds.Length > 1 && (Object)(object)val == (Object)(object)script.lastThunderSound);
				script.lastThunderSound = val;
				script.audioSourceThunder.PlayOneShot(val, intensity * 0.5f * VolumeMultiplier);
			}
		}

		private void Strike(Vector3? _start, Vector3? _end, bool intense, float intensity, Camera camera, Camera visibleInCamera)
		{
			//IL_0084: Unknown result type (might be due to invalid IL or missing references)
			//IL_0089: Unknown result type (might be due to invalid IL or missing references)
			//IL_0153: Unknown result type (might be due to invalid IL or missing references)
			//IL_0155: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0130: Unknown result type (might be due to invalid IL or missing references)
			//IL_0135: Unknown result type (might be due to invalid IL or missing references)
			//IL_013a: Unknown result type (might be due to invalid IL or missing references)
			//IL_014c: Unknown result type (might be due to invalid IL or missing references)
			//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_0238: Unknown result type (might be due to invalid IL or missing references)
			//IL_023a: Unknown result type (might be due to invalid IL or missing references)
			//IL_023c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0241: Unknown result type (might be due to invalid IL or missing references)
			//IL_020d: Unknown result type (might be due to invalid IL or missing references)
			//IL_022b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0263: Unknown result type (might be due to invalid IL or missing references)
			//IL_025d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0268: Unknown result type (might be due to invalid IL or missing references)
			//IL_027c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0276: Unknown result type (might be due to invalid IL or missing references)
			//IL_0281: Unknown result type (might be due to invalid IL or missing references)
			//IL_0283: Unknown result type (might be due to invalid IL or missing references)
			//IL_0285: Unknown result type (might be due to invalid IL or missing references)
			//IL_0287: Unknown result type (might be due to invalid IL or missing references)
			//IL_0289: Unknown result type (might be due to invalid IL or missing references)
			//IL_028e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0292: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_0333: Unknown result type (might be due to invalid IL or missing references)
			//IL_033a: Unknown result type (might be due to invalid IL or missing references)
			float num = (intense ? (-1000f) : (-5000f));
			float num2 = (intense ? 1000f : 5000f);
			float num3 = (intense ? 500f : 2500f);
			float num4 = ((Random.Range(0, 2) == 0) ? Random.Range(num, 0f - num3) : Random.Range(num3, num2));
			float lightningYStart = script.LightningYStart;
			float num5 = ((Random.Range(0, 2) == 0) ? Random.Range(num, 0f - num3) : Random.Range(num3, num2));
			Vector3 val = ((Component)script.Camera).transform.position;
			val.x += num4;
			val.y = lightningYStart;
			val.z += num5;
			if ((Object)(object)visibleInCamera != (Object)null)
			{
				Quaternion rotation = ((Component)visibleInCamera).transform.rotation;
				((Component)visibleInCamera).transform.rotation = Quaternion.Euler(0f, ((Quaternion)(ref rotation)).eulerAngles.y, 0f);
				float num6 = Random.Range((float)visibleInCamera.pixelWidth * 0.1f, (float)visibleInCamera.pixelWidth * 0.9f);
				float num7 = Random.Range(visibleInCamera.nearClipPlane + num3 + num3, num2);
				val = visibleInCamera.ScreenToWorldPoint(new Vector3(num6, 0f, num7));
				val.y = lightningYStart;
				((Component)visibleInCamera).transform.rotation = rotation;
			}
			Vector3 val2 = val;
			num4 = Random.Range(-100f, 100f);
			lightningYStart = ((Random.Range(0, 4) == 0) ? Random.Range(-1f, 600f) : (-1f));
			num5 += Random.Range(-100f, 100f);
			val2.x += num4;
			val2.y = lightningYStart;
			val2.z += num5;
			val2.x += num3 * ((Component)camera).transform.forward.x;
			val2.z += num3 * ((Component)camera).transform.forward.z;
			Vector3 val3;
			while (true)
			{
				val3 = val - val2;
				if (!(((Vector3)(ref val3)).magnitude < 500f))
				{
					break;
				}
				val2.x += num3 * ((Component)camera).transform.forward.x;
				val2.z += num3 * ((Component)camera).transform.forward.z;
			}
			val = (Vector3)(((_003F?)_start) ?? val);
			val2 = (Vector3)(((_003F?)_end) ?? val2);
			Vector3 val4 = val;
			val3 = val - val2;
			RaycastHit val5 = default(RaycastHit);
			if (Physics.Raycast(val4, ((Vector3)(ref val3)).normalized, ref val5, float.MaxValue))
			{
				val2 = ((RaycastHit)(ref val5)).point;
			}
			int generations = script.LightningBoltScript.Generations;
			RangeOfFloats trunkWidthRange = script.LightningBoltScript.TrunkWidthRange;
			if (Random.value < script.CloudLightningChance)
			{
				script.LightningBoltScript.TrunkWidthRange = default(RangeOfFloats);
				script.LightningBoltScript.Generations = 1;
			}
			script.LightningBoltScript.LightParameters.LightIntensity = intensity * 0.5f;
			script.LightningBoltScript.Trigger(val, val2);
			script.LightningBoltScript.TrunkWidthRange = trunkWidthRange;
			script.LightningBoltScript.Generations = generations;
		}

		private void CheckForLightning()
		{
			if (Time.time >= script.nextLightningTime)
			{
				bool intense = Random.value < script.LightningIntenseProbability;
				((MonoBehaviour)script).StartCoroutine(ProcessLightning(null, null, intense, script.LightningAlwaysVisible));
			}
		}

		public void Update()
		{
			UpdateLighting();
		}
	}

	[Tooltip("Lightning bolt script - optional, leave null if you don't want lightning bolts")]
	public LightningBoltPrefabScript LightningBoltScript;

	[Tooltip("Camera where the lightning should be centered over. Defaults to main camera.")]
	public Camera Camera;

	[SingleLine("Random interval between strikes.")]
	public RangeOfFloats LightningIntervalTimeRange = new RangeOfFloats
	{
		Minimum = 10f,
		Maximum = 25f
	};

	[Tooltip("Probability (0-1) of an intense lightning bolt that hits really close. Intense lightning has increased brightness and louder thunder compared to normal lightning, and the thunder sounds plays a lot sooner.")]
	[Range(0f, 1f)]
	public float LightningIntenseProbability = 0.2f;

	[Tooltip("Sounds to play for normal thunder. One will be chosen at random for each lightning strike. Depending on intensity, some normal lightning may not play a thunder sound.")]
	public AudioClip[] ThunderSoundsNormal;

	[Tooltip("Sounds to play for intense thunder. One will be chosen at random for each lightning strike.")]
	public AudioClip[] ThunderSoundsIntense;

	[Tooltip("Whether lightning strikes should always try to be in the camera view")]
	public bool LightningAlwaysVisible = true;

	[Tooltip("The chance lightning will simply be in the clouds with no visible bolt")]
	[Range(0f, 1f)]
	public float CloudLightningChance = 0.5f;

	[Tooltip("Whether to modify the skybox exposure when lightning is created")]
	public bool ModifySkyboxExposure;

	[Tooltip("Base point light range for lightning bolts. Increases as intensity increases.")]
	[Range(1f, 10000f)]
	public float BaseLightRange = 2000f;

	[Tooltip("Starting y value for the lightning strikes")]
	[Range(0f, 100000f)]
	public float LightningYStart = 500f;

	[Tooltip("Volume multiplier")]
	[Range(0f, 1f)]
	public float VolumeMultiplier = 1f;

	private float skyboxExposureOriginal;

	private float skyboxExposureStorm;

	private float nextLightningTime;

	private bool lightningInProgress;

	private AudioSource audioSourceThunder;

	private LightningBoltHandler lightningBoltHandler;

	private Material skyboxMaterial;

	private AudioClip lastThunderSound;

	public float SkyboxExposureOriginal => skyboxExposureOriginal;

	public bool EnableLightning { get; set; }

	private void Start()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Expected O, but got Unknown
		//IL_0043: Expected O, but got Unknown
		EnableLightning = true;
		if ((Object)(object)Camera == (Object)null)
		{
			Camera = Camera.main;
		}
		if ((Object)(object)RenderSettings.skybox != (Object)null)
		{
			Material val = new Material(RenderSettings.skybox);
			RenderSettings.skybox = val;
			skyboxMaterial = val;
		}
		skyboxExposureOriginal = (skyboxExposureStorm = (((Object)(object)skyboxMaterial == (Object)null || !skyboxMaterial.HasProperty("_Exposure")) ? 1f : skyboxMaterial.GetFloat("_Exposure")));
		audioSourceThunder = ((Component)this).gameObject.AddComponent<AudioSource>();
		lightningBoltHandler = new LightningBoltHandler(this);
		lightningBoltHandler.VolumeMultiplier = VolumeMultiplier;
	}

	private void Update()
	{
		if (lightningBoltHandler != null && EnableLightning)
		{
			lightningBoltHandler.VolumeMultiplier = VolumeMultiplier;
			lightningBoltHandler.Update();
		}
	}

	public void CallNormalLightning()
	{
		CallNormalLightning(null, null);
	}

	public void CallNormalLightning(Vector3? start, Vector3? end)
	{
		((MonoBehaviour)this).StartCoroutine(lightningBoltHandler.ProcessLightning(start, end, intense: false, visible: true));
	}

	public void CallIntenseLightning()
	{
		CallIntenseLightning(null, null);
	}

	public void CallIntenseLightning(Vector3? start, Vector3? end)
	{
		((MonoBehaviour)this).StartCoroutine(lightningBoltHandler.ProcessLightning(start, end, intense: true, visible: true));
	}
}
