namespace DigitalRuby.ThunderAndLightning;

public class LightningQualityMaximum
{
	public int MaximumGenerations { get; set; }

	public float MaximumLightPercent { get; set; }

	public float MaximumShadowPercent { get; set; }
}
