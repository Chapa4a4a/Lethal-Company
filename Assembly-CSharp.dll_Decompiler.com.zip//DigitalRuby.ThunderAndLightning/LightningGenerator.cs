using System;
using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningGenerator
{
	internal const float oneOver255 = 0.003921569f;

	internal const float mainTrunkMultiplier = 0.003921569f;

	public static readonly LightningGenerator GeneratorInstance = new LightningGenerator();

	private void GetPerpendicularVector(ref Vector3 directionNormalized, out Vector3 side)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		if (directionNormalized == Vector3.zero)
		{
			side = Vector3.right;
			return;
		}
		float x = directionNormalized.x;
		float y = directionNormalized.y;
		float z = directionNormalized.z;
		float num = Mathf.Abs(x);
		float num2 = Mathf.Abs(y);
		float num3 = Mathf.Abs(z);
		float num4;
		float num5;
		float num6;
		if (num >= num2 && num2 >= num3)
		{
			num4 = 1f;
			num5 = 1f;
			num6 = (0f - (y * num4 + z * num5)) / x;
		}
		else if (num2 >= num3)
		{
			num6 = 1f;
			num5 = 1f;
			num4 = (0f - (x * num6 + z * num5)) / y;
		}
		else
		{
			num6 = 1f;
			num4 = 1f;
			num5 = (0f - (x * num6 + y * num4)) / z;
		}
		Vector3 val = new Vector3(num6, num4, num5);
		side = ((Vector3)(ref val)).normalized;
	}

	protected virtual void OnGenerateLightningBolt(LightningBolt bolt, Vector3 start, Vector3 end, LightningBoltParameters parameters)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		GenerateLightningBoltStandard(bolt, start, end, parameters.Generations, parameters.Generations, 0f, parameters);
	}

	public bool ShouldCreateFork(LightningBoltParameters parameters, int generation, int totalGenerations)
	{
		if (generation > parameters.generationWhereForksStop && generation >= totalGenerations - parameters.forkednessCalculated)
		{
			return (float)parameters.Random.NextDouble() < parameters.Forkedness;
		}
		return false;
	}

	public void CreateFork(LightningBolt bolt, LightningBoltParameters parameters, int generation, int totalGenerations, Vector3 start, Vector3 midPoint)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		if (ShouldCreateFork(parameters, generation, totalGenerations))
		{
			Vector3 val = (midPoint - start) * parameters.ForkMultiplier();
			Vector3 end = midPoint + val;
			GenerateLightningBoltStandard(bolt, midPoint, end, generation, totalGenerations, 0f, parameters);
		}
	}

	public void GenerateLightningBoltStandard(LightningBolt bolt, Vector3 start, Vector3 end, int generation, int totalGenerations, float offsetAmount, LightningBoltParameters parameters)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		if (generation < 1)
		{
			return;
		}
		LightningBoltSegmentGroup lightningBoltSegmentGroup = bolt.AddGroup();
		lightningBoltSegmentGroup.Segments.Add(new LightningBoltSegment
		{
			Start = start,
			End = end
		});
		float num = (float)generation / (float)totalGenerations;
		num *= num;
		lightningBoltSegmentGroup.LineWidth = parameters.TrunkWidth * num;
		lightningBoltSegmentGroup.Generation = generation;
		lightningBoltSegmentGroup.Color = parameters.Color;
		if (generation == parameters.Generations && (parameters.MainTrunkTintColor.r != byte.MaxValue || parameters.MainTrunkTintColor.g != byte.MaxValue || parameters.MainTrunkTintColor.b != byte.MaxValue || parameters.MainTrunkTintColor.a != byte.MaxValue))
		{
			lightningBoltSegmentGroup.Color.r = (byte)(0.003921569f * (float)(int)lightningBoltSegmentGroup.Color.r * (float)(int)parameters.MainTrunkTintColor.r);
			lightningBoltSegmentGroup.Color.g = (byte)(0.003921569f * (float)(int)lightningBoltSegmentGroup.Color.g * (float)(int)parameters.MainTrunkTintColor.g);
			lightningBoltSegmentGroup.Color.b = (byte)(0.003921569f * (float)(int)lightningBoltSegmentGroup.Color.b * (float)(int)parameters.MainTrunkTintColor.b);
			lightningBoltSegmentGroup.Color.a = (byte)(0.003921569f * (float)(int)lightningBoltSegmentGroup.Color.a * (float)(int)parameters.MainTrunkTintColor.a);
		}
		lightningBoltSegmentGroup.Color.a = (byte)(255f * num);
		lightningBoltSegmentGroup.EndWidthMultiplier = parameters.EndWidthMultiplier * parameters.ForkEndWidthMultiplier;
		if (offsetAmount <= 0f)
		{
			Vector3 val = end - start;
			offsetAmount = ((Vector3)(ref val)).magnitude * ((generation == totalGenerations) ? parameters.ChaosFactor : parameters.ChaosFactorForks);
		}
		while (generation-- > 0)
		{
			int startIndex = lightningBoltSegmentGroup.StartIndex;
			lightningBoltSegmentGroup.StartIndex = lightningBoltSegmentGroup.Segments.Count;
			for (int i = startIndex; i < lightningBoltSegmentGroup.StartIndex; i++)
			{
				start = lightningBoltSegmentGroup.Segments[i].Start;
				end = lightningBoltSegmentGroup.Segments[i].End;
				Vector3 val2 = (start + end) * 0.5f;
				RandomVector(bolt, ref start, ref end, offsetAmount, parameters.Random, out var result);
				val2 += result;
				lightningBoltSegmentGroup.Segments.Add(new LightningBoltSegment
				{
					Start = start,
					End = val2
				});
				lightningBoltSegmentGroup.Segments.Add(new LightningBoltSegment
				{
					Start = val2,
					End = end
				});
				CreateFork(bolt, parameters, generation, totalGenerations, start, val2);
			}
			offsetAmount *= 0.5f;
		}
	}

	public Vector3 RandomDirection3D(Random random)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		float num = 2f * (float)random.NextDouble() - 1f;
		Vector3 result = RandomDirection2D(random) * Mathf.Sqrt(1f - num * num);
		result.z = num;
		return result;
	}

	public Vector3 RandomDirection2D(Random random)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		float num = (float)random.NextDouble() * 2f * MathF.PI;
		return new Vector3(Mathf.Cos(num), Mathf.Sin(num), 0f);
	}

	public Vector3 RandomDirection2DXZ(Random random)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		float num = (float)random.NextDouble() * 2f * MathF.PI;
		return new Vector3(Mathf.Cos(num), 0f, Mathf.Sin(num));
	}

	public void RandomVector(LightningBolt bolt, ref Vector3 start, ref Vector3 end, float offsetAmount, Random random, out Vector3 result)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val;
		if (bolt.CameraMode == CameraMode.Perspective)
		{
			val = end - start;
			Vector3 directionNormalized = ((Vector3)(ref val)).normalized;
			Vector3 side = Vector3.Cross(start, end);
			if (side == Vector3.zero)
			{
				GetPerpendicularVector(ref directionNormalized, out side);
			}
			else
			{
				((Vector3)(ref side)).Normalize();
			}
			float num = ((float)random.NextDouble() + 0.1f) * offsetAmount;
			float num2 = (float)random.NextDouble() * MathF.PI;
			directionNormalized *= (float)Math.Sin(num2);
			Quaternion val2 = default(Quaternion);
			val2.x = directionNormalized.x;
			val2.y = directionNormalized.y;
			val2.z = directionNormalized.z;
			val2.w = (float)Math.Cos(num2);
			result = val2 * side * num;
		}
		else if (bolt.CameraMode == CameraMode.OrthographicXY)
		{
			end.z = start.z;
			val = end - start;
			Vector3 normalized = ((Vector3)(ref val)).normalized;
			Vector3 val3 = default(Vector3);
			((Vector3)(ref val3))._002Ector(0f - normalized.y, normalized.x, 0f);
			float num3 = (float)random.NextDouble() * offsetAmount * 2f - offsetAmount;
			result = val3 * num3;
		}
		else
		{
			end.y = start.y;
			val = end - start;
			Vector3 normalized2 = ((Vector3)(ref val)).normalized;
			Vector3 val4 = default(Vector3);
			((Vector3)(ref val4))._002Ector(0f - normalized2.z, 0f, normalized2.x);
			float num4 = (float)random.NextDouble() * offsetAmount * 2f - offsetAmount;
			result = val4 * num4;
		}
	}

	public void GenerateLightningBolt(LightningBolt bolt, LightningBoltParameters parameters)
	{
		GenerateLightningBolt(bolt, parameters, out var _, out var _);
	}

	public void GenerateLightningBolt(LightningBolt bolt, LightningBoltParameters parameters, out Vector3 start, out Vector3 end)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		start = parameters.ApplyVariance(parameters.Start, parameters.StartVariance);
		end = parameters.ApplyVariance(parameters.End, parameters.EndVariance);
		OnGenerateLightningBolt(bolt, start, end, parameters);
	}
}
