using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class MeshHelper
{
	private Mesh mesh;

	private int[] triangles;

	private Vector3[] vertices;

	private Vector3[] normals;

	private float[] normalizedAreaWeights;

	public Mesh Mesh => mesh;

	public int[] Triangles => triangles;

	public Vector3[] Vertices => vertices;

	public Vector3[] Normals => normals;

	public MeshHelper(Mesh mesh)
	{
		this.mesh = mesh;
		triangles = mesh.triangles;
		vertices = mesh.vertices;
		normals = mesh.normals;
		CalculateNormalizedAreaWeights();
	}

	public void GenerateRandomPoint(ref RaycastHit hit, out int triangleIndex)
	{
		triangleIndex = SelectRandomTriangle();
		GetRaycastFromTriangleIndex(triangleIndex, ref hit);
	}

	public void GetRaycastFromTriangleIndex(int triangleIndex, ref RaycastHit hit)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = GenerateRandomBarycentricCoordinates();
		Vector3 val2 = vertices[triangles[triangleIndex]];
		Vector3 val3 = vertices[triangles[triangleIndex + 1]];
		Vector3 val4 = vertices[triangles[triangleIndex + 2]];
		((RaycastHit)(ref hit)).barycentricCoordinate = val;
		((RaycastHit)(ref hit)).point = val2 * val.x + val3 * val.y + val4 * val.z;
		if (normals == null)
		{
			Vector3 val5 = Vector3.Cross(val4 - val3, val2 - val3);
			((RaycastHit)(ref hit)).normal = ((Vector3)(ref val5)).normalized;
			return;
		}
		val2 = normals[triangles[triangleIndex]];
		val3 = normals[triangles[triangleIndex + 1]];
		val4 = normals[triangles[triangleIndex + 2]];
		((RaycastHit)(ref hit)).normal = val2 * val.x + val3 * val.y + val4 * val.z;
	}

	private float[] CalculateSurfaceAreas(out float totalSurfaceArea)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		totalSurfaceArea = 0f;
		float[] array = new float[triangles.Length / 3];
		for (int i = 0; i < triangles.Length; i += 3)
		{
			Vector3 val = vertices[triangles[i]];
			Vector3 val2 = vertices[triangles[i + 1]];
			Vector3 val3 = vertices[triangles[i + 2]];
			Vector3 val4 = val - val2;
			float sqrMagnitude = ((Vector3)(ref val4)).sqrMagnitude;
			val4 = val - val3;
			float sqrMagnitude2 = ((Vector3)(ref val4)).sqrMagnitude;
			val4 = val2 - val3;
			float sqrMagnitude3 = ((Vector3)(ref val4)).sqrMagnitude;
			float num2 = PathGenerator.SquareRoot((2f * sqrMagnitude * sqrMagnitude2 + 2f * sqrMagnitude2 * sqrMagnitude3 + 2f * sqrMagnitude3 * sqrMagnitude - sqrMagnitude * sqrMagnitude - sqrMagnitude2 * sqrMagnitude2 - sqrMagnitude3 * sqrMagnitude3) / 16f);
			array[num++] = num2;
			totalSurfaceArea += num2;
		}
		return array;
	}

	private void CalculateNormalizedAreaWeights()
	{
		normalizedAreaWeights = CalculateSurfaceAreas(out var totalSurfaceArea);
		if (normalizedAreaWeights.Length != 0)
		{
			float num = 0f;
			for (int i = 0; i < normalizedAreaWeights.Length; i++)
			{
				float num2 = normalizedAreaWeights[i] / totalSurfaceArea;
				normalizedAreaWeights[i] = num;
				num += num2;
			}
		}
	}

	private int SelectRandomTriangle()
	{
		float value = Random.value;
		int num = 0;
		int num2 = normalizedAreaWeights.Length - 1;
		while (num < num2)
		{
			int num3 = (num + num2) / 2;
			if (normalizedAreaWeights[num3] < value)
			{
				num = num3 + 1;
			}
			else
			{
				num2 = num3;
			}
		}
		return num * 3;
	}

	private Vector3 GenerateRandomBarycentricCoordinates()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = default(Vector3);
		((Vector3)(ref val))._002Ector(Random.Range(Mathf.Epsilon, 1f), Random.Range(Mathf.Epsilon, 1f), Random.Range(Mathf.Epsilon, 1f));
		return val / (val.x + val.y + val.z);
	}
}
