using System;
using System.Collections;
using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningWhipSpell : LightningSpellScript
{
	[Header("Whip")]
	[Tooltip("Attach the whip to what object")]
	public GameObject AttachTo;

	[Tooltip("Rotate the whip with this object")]
	public GameObject RotateWith;

	[Tooltip("Whip handle")]
	public GameObject WhipHandle;

	[Tooltip("Whip start")]
	public GameObject WhipStart;

	[Tooltip("Whip spring")]
	public GameObject WhipSpring;

	[Tooltip("Whip crack audio source")]
	public AudioSource WhipCrackAudioSource;

	[HideInInspector]
	public Action<Vector3> CollisionCallback;

	private IEnumerator WhipForward()
	{
		for (int i = 0; i < WhipStart.transform.childCount; i++)
		{
			Rigidbody component = ((Component)WhipStart.transform.GetChild(i)).gameObject.GetComponent<Rigidbody>();
			if ((Object)(object)component != (Object)null)
			{
				component.drag = 0f;
				component.velocity = Vector3.zero;
				component.angularVelocity = Vector3.zero;
			}
		}
		WhipSpring.SetActive(true);
		Vector3 position = WhipStart.GetComponent<Rigidbody>().position;
		RaycastHit val = default(RaycastHit);
		Vector3 whipPositionForwards;
		Vector3 position2;
		if (Physics.Raycast(position, Direction, ref val, MaxDistance, LayerMask.op_Implicit(CollisionMask)))
		{
			Vector3 val2 = ((RaycastHit)(ref val)).point - position;
			Vector3 normalized = ((Vector3)(ref val2)).normalized;
			whipPositionForwards = position + normalized * MaxDistance;
			position2 = position - normalized * 25f;
		}
		else
		{
			whipPositionForwards = position + Direction * MaxDistance;
			position2 = position - Direction * 25f;
		}
		WhipSpring.GetComponent<Rigidbody>().position = position2;
		yield return new WaitForSecondsLightning(0.25f);
		WhipSpring.GetComponent<Rigidbody>().position = whipPositionForwards;
		yield return new WaitForSecondsLightning(0.1f);
		if ((Object)(object)WhipCrackAudioSource != (Object)null)
		{
			WhipCrackAudioSource.Play();
		}
		yield return new WaitForSecondsLightning(0.1f);
		if ((Object)(object)CollisionParticleSystem != (Object)null)
		{
			CollisionParticleSystem.Play();
		}
		ApplyCollisionForce(SpellEnd.transform.position);
		WhipSpring.SetActive(false);
		if (CollisionCallback != null)
		{
			CollisionCallback(SpellEnd.transform.position);
		}
		yield return new WaitForSecondsLightning(0.1f);
		for (int j = 0; j < WhipStart.transform.childCount; j++)
		{
			Rigidbody component2 = ((Component)WhipStart.transform.GetChild(j)).gameObject.GetComponent<Rigidbody>();
			if ((Object)(object)component2 != (Object)null)
			{
				component2.velocity = Vector3.zero;
				component2.angularVelocity = Vector3.zero;
				component2.drag = 0.5f;
			}
		}
	}

	protected override void Start()
	{
		base.Start();
		WhipSpring.SetActive(false);
		WhipHandle.SetActive(false);
	}

	protected override void Update()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		((Component)this).gameObject.transform.position = AttachTo.transform.position;
		((Component)this).gameObject.transform.rotation = RotateWith.transform.rotation;
	}

	protected override void OnCastSpell()
	{
		((MonoBehaviour)this).StartCoroutine(WhipForward());
	}

	protected override void OnStopSpell()
	{
	}

	protected override void OnActivated()
	{
		base.OnActivated();
		WhipHandle.SetActive(true);
	}

	protected override void OnDeactivated()
	{
		base.OnDeactivated();
		WhipHandle.SetActive(false);
	}
}
