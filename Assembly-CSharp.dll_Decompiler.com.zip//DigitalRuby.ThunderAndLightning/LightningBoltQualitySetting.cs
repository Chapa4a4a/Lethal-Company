namespace DigitalRuby.ThunderAndLightning;

public enum LightningBoltQualitySetting
{
	UseScript,
	LimitToQualitySetting
}
