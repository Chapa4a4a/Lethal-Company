namespace DigitalRuby.ThunderAndLightning;

public enum CameraMode
{
	Auto,
	Perspective,
	OrthographicXY,
	OrthographicXZ,
	Unknown
}
