using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningLightsabreScript : LightningBoltPrefabScript
{
	[Header("Lightsabre Properties")]
	[Tooltip("Height of the blade")]
	public float BladeHeight = 19f;

	[Tooltip("How long it takes to turn the lightsabre on and off")]
	public float ActivationTime = 0.5f;

	[Tooltip("Sound to play when the lightsabre turns on")]
	public AudioSource StartSound;

	[Tooltip("Sound to play when the lightsabre turns off")]
	public AudioSource StopSound;

	[Tooltip("Sound to play when the lightsabre stays on")]
	public AudioSource ConstantSound;

	private int state;

	private Vector3 bladeStart;

	private Vector3 bladeDir;

	private float bladeTime;

	private float bladeIntensity;

	protected override void Start()
	{
		base.Start();
	}

	protected override void Update()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (state == 2 || state == 3)
		{
			bladeTime += LightningBoltScript.DeltaTime;
			float num = Mathf.Lerp(0.01f, 1f, bladeTime / ActivationTime);
			Vector3 position = bladeStart + bladeDir * num * BladeHeight;
			Destination.transform.position = position;
			GlowIntensity = bladeIntensity * ((state == 3) ? num : (1f - num));
			if (bladeTime >= ActivationTime)
			{
				GlowIntensity = bladeIntensity;
				bladeTime = 0f;
				if (state == 2)
				{
					ManualMode = true;
					state = 0;
				}
				else
				{
					state = 1;
				}
			}
		}
		base.Update();
	}

	public bool TurnOn(bool value)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (state == 2 || state == 3 || (state == 1 && value) || (state == 0 && !value))
		{
			return false;
		}
		bladeStart = Destination.transform.position;
		ManualMode = false;
		bladeIntensity = GlowIntensity;
		if (value)
		{
			bladeDir = (Camera.orthographic ? ((Component)this).transform.up : ((Component)this).transform.forward);
			state = 3;
			StartSound.Play();
			StopSound.Stop();
			ConstantSound.Play();
		}
		else
		{
			bladeDir = -(Camera.orthographic ? ((Component)this).transform.up : ((Component)this).transform.forward);
			state = 2;
			StartSound.Stop();
			StopSound.Play();
			ConstantSound.Stop();
		}
		return true;
	}

	public void TurnOnGUI(bool value)
	{
		TurnOn(value);
	}
}
