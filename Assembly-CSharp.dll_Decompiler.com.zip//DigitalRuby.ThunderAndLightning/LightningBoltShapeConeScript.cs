using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningBoltShapeConeScript : LightningBoltPrefabScriptBase
{
	[Header("Lightning Cone Properties")]
	[Tooltip("Radius at base of cone where lightning can emit from")]
	public float InnerRadius = 0.1f;

	[Tooltip("Radius at outer part of the cone where lightning emits to")]
	public float OuterRadius = 4f;

	[Tooltip("The length of the cone from the center of the inner and outer circle")]
	public float Length = 4f;

	public override void CreateLightningBolt(LightningBoltParameters parameters)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = Random.insideUnitCircle * InnerRadius;
		Vector3 start = ((Component)this).transform.rotation * new Vector3(val.x, val.y, 0f);
		Vector2 val2 = Random.insideUnitCircle * OuterRadius;
		Vector3 end = ((Component)this).transform.rotation * new Vector3(val2.x, val2.y, 0f) + ((Component)this).transform.forward * Length;
		parameters.Start = start;
		parameters.End = end;
		base.CreateLightningBolt(parameters);
	}
}
