using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningBoltShapeSphereScript : LightningBoltPrefabScriptBase
{
	[Header("Lightning Sphere Properties")]
	[Tooltip("Radius inside the sphere where lightning can emit from")]
	public float InnerRadius = 0.1f;

	[Tooltip("Radius of the sphere")]
	public float Radius = 4f;

	public override void CreateLightningBolt(LightningBoltParameters parameters)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 start = Random.insideUnitSphere * InnerRadius;
		Vector3 end = Random.onUnitSphere * Radius;
		parameters.Start = start;
		parameters.End = end;
		base.CreateLightningBolt(parameters);
	}
}
