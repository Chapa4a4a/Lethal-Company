using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningFieldScript : LightningBoltPrefabScriptBase
{
	[Header("Lightning Field Properties")]
	[Tooltip("The minimum length for a field segment")]
	public float MinimumLength = 0.01f;

	private float minimumLengthSquared;

	[Tooltip("The bounds to put the field in.")]
	public Bounds FieldBounds;

	[Tooltip("Optional light for the lightning field to emit")]
	public Light Light;

	private Vector3 RandomPointInBounds()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		float num = Random.Range(((Bounds)(ref FieldBounds)).min.x, ((Bounds)(ref FieldBounds)).max.x);
		float num2 = Random.Range(((Bounds)(ref FieldBounds)).min.y, ((Bounds)(ref FieldBounds)).max.y);
		float num3 = Random.Range(((Bounds)(ref FieldBounds)).min.z, ((Bounds)(ref FieldBounds)).max.z);
		return new Vector3(num, num2, num3);
	}

	protected override void Start()
	{
		base.Start();
		if ((Object)(object)Light != (Object)null)
		{
			((Behaviour)Light).enabled = false;
		}
	}

	protected override void Update()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (!(Time.timeScale <= 0f) && (Object)(object)Light != (Object)null)
		{
			((Component)Light).transform.position = ((Bounds)(ref FieldBounds)).center;
			Light.intensity = Random.Range(2.8f, 3.2f);
		}
	}

	public override void CreateLightningBolt(LightningBoltParameters parameters)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		minimumLengthSquared = MinimumLength * MinimumLength;
		for (int i = 0; i < 16; i++)
		{
			parameters.Start = RandomPointInBounds();
			parameters.End = RandomPointInBounds();
			Vector3 val = parameters.End - parameters.Start;
			if (((Vector3)(ref val)).sqrMagnitude >= minimumLengthSquared)
			{
				break;
			}
		}
		if ((Object)(object)Light != (Object)null)
		{
			((Behaviour)Light).enabled = true;
		}
		base.CreateLightningBolt(parameters);
	}
}
