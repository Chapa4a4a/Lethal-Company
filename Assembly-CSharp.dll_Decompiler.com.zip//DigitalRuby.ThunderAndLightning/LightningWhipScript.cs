using System.Collections;
using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

[RequireComponent(typeof(AudioSource))]
public class LightningWhipScript : MonoBehaviour
{
	public AudioClip WhipCrack;

	public AudioClip WhipCrackThunder;

	private AudioSource audioSource;

	private GameObject whipStart;

	private GameObject whipEndStrike;

	private GameObject whipHandle;

	private GameObject whipSpring;

	private Vector2 prevDrag;

	private bool dragging;

	private bool canWhip = true;

	private IEnumerator WhipForward()
	{
		if (!canWhip)
		{
			yield break;
		}
		canWhip = false;
		for (int i = 0; i < whipStart.transform.childCount; i++)
		{
			Rigidbody2D component = ((Component)whipStart.transform.GetChild(i)).gameObject.GetComponent<Rigidbody2D>();
			if ((Object)(object)component != (Object)null)
			{
				component.drag = 0f;
			}
		}
		audioSource.PlayOneShot(WhipCrack);
		((Behaviour)whipSpring.GetComponent<SpringJoint2D>()).enabled = true;
		whipSpring.GetComponent<Rigidbody2D>().position = whipHandle.GetComponent<Rigidbody2D>().position + new Vector2(-15f, 5f);
		yield return new WaitForSecondsLightning(0.2f);
		whipSpring.GetComponent<Rigidbody2D>().position = whipHandle.GetComponent<Rigidbody2D>().position + new Vector2(15f, 2.5f);
		yield return new WaitForSecondsLightning(0.15f);
		audioSource.PlayOneShot(WhipCrackThunder, 0.5f);
		yield return new WaitForSecondsLightning(0.15f);
		whipEndStrike.GetComponent<ParticleSystem>().Play();
		((Behaviour)whipSpring.GetComponent<SpringJoint2D>()).enabled = false;
		yield return new WaitForSecondsLightning(0.65f);
		for (int j = 0; j < whipStart.transform.childCount; j++)
		{
			Rigidbody2D component2 = ((Component)whipStart.transform.GetChild(j)).gameObject.GetComponent<Rigidbody2D>();
			if ((Object)(object)component2 != (Object)null)
			{
				component2.velocity = Vector2.zero;
				component2.drag = 0.5f;
			}
		}
		canWhip = true;
	}

	private void Start()
	{
		whipStart = GameObject.Find("WhipStart");
		whipEndStrike = GameObject.Find("WhipEndStrike");
		whipHandle = GameObject.Find("WhipHandle");
		whipSpring = GameObject.Find("WhipSpring");
		audioSource = ((Component)this).GetComponent<AudioSource>();
	}

	private void Update()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		if (!dragging && Input.GetMouseButtonDown(0))
		{
			Vector2 val = Vector2.op_Implicit(Camera.main.ScreenToWorldPoint(Input.mousePosition));
			Collider2D val2 = Physics2D.OverlapPoint(val);
			if ((Object)(object)val2 != (Object)null && (Object)(object)((Component)val2).gameObject == (Object)(object)whipHandle)
			{
				dragging = true;
				prevDrag = val;
			}
		}
		else if (dragging && Input.GetMouseButton(0))
		{
			Vector2 val3 = Vector2.op_Implicit(Camera.main.ScreenToWorldPoint(Input.mousePosition));
			Vector2 val4 = val3 - prevDrag;
			Rigidbody2D component = whipHandle.GetComponent<Rigidbody2D>();
			component.MovePosition(component.position + val4);
			prevDrag = val3;
		}
		else
		{
			dragging = false;
		}
		if (Input.GetKeyDown((KeyCode)32))
		{
			((MonoBehaviour)this).StartCoroutine(WhipForward());
		}
	}
}
