namespace DigitalRuby.ThunderAndLightning;

public enum LightningCustomTransformState
{
	Started,
	Executing,
	Ended
}
