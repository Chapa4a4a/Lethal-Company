using System;
using System.Collections.Generic;
using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningParticleSpellScript : LightningSpellScript, ICollisionHandler
{
	[Header("Particle system")]
	public ParticleSystem ParticleSystem;

	[Tooltip("Particle system collision interval. This time must elapse before another collision will be registered.")]
	public float CollisionInterval;

	protected float collisionTimer;

	[HideInInspector]
	public Action<GameObject, List<ParticleCollisionEvent>, int> CollisionCallback;

	[Header("Particle Light Properties")]
	[Tooltip("Whether to enable point lights for the particles")]
	public bool EnableParticleLights = true;

	[SingleLineClamp("Possible range for particle lights", 0.001, 100.0)]
	public RangeOfFloats ParticleLightRange = new RangeOfFloats
	{
		Minimum = 2f,
		Maximum = 5f
	};

	[SingleLineClamp("Possible range of intensity for particle lights", 0.009999999776482582, 8.0)]
	public RangeOfFloats ParticleLightIntensity = new RangeOfFloats
	{
		Minimum = 0.2f,
		Maximum = 0.3f
	};

	[Tooltip("Possible range of colors for particle lights")]
	public Color ParticleLightColor1 = Color.white;

	[Tooltip("Possible range of colors for particle lights")]
	public Color ParticleLightColor2 = Color.white;

	[Tooltip("The culling mask for particle lights")]
	public LayerMask ParticleLightCullingMask = LayerMask.op_Implicit(-1);

	private Particle[] particles = (Particle[])(object)new Particle[512];

	private readonly List<GameObject> particleLights = new List<GameObject>();

	private void PopulateParticleLight(Light src)
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		src.bounceIntensity = 0f;
		src.type = (LightType)2;
		src.shadows = (LightShadows)0;
		src.color = new Color(Random.Range(ParticleLightColor1.r, ParticleLightColor2.r), Random.Range(ParticleLightColor1.g, ParticleLightColor2.g), Random.Range(ParticleLightColor1.b, ParticleLightColor2.b), 1f);
		src.cullingMask = LayerMask.op_Implicit(ParticleLightCullingMask);
		src.intensity = Random.Range(ParticleLightIntensity.Minimum, ParticleLightIntensity.Maximum);
		src.range = Random.Range(ParticleLightRange.Minimum, ParticleLightRange.Maximum);
	}

	private void UpdateParticleLights()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected O, but got Unknown
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		if (EnableParticleLights)
		{
			int num = ParticleSystem.GetParticles(particles);
			while (particleLights.Count < num)
			{
				GameObject val = new GameObject("LightningParticleSpellLight");
				((Object)val).hideFlags = (HideFlags)61;
				PopulateParticleLight(val.AddComponent<Light>());
				particleLights.Add(val);
			}
			while (particleLights.Count > num)
			{
				Object.Destroy((Object)(object)particleLights[particleLights.Count - 1]);
				particleLights.RemoveAt(particleLights.Count - 1);
			}
			for (int i = 0; i < num; i++)
			{
				particleLights[i].transform.position = ((Particle)(ref particles[i])).position;
			}
		}
	}

	private void UpdateParticleSystems()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)EmissionParticleSystem != (Object)null && EmissionParticleSystem.isPlaying)
		{
			((Component)EmissionParticleSystem).transform.position = SpellStart.transform.position;
			((Component)EmissionParticleSystem).transform.forward = Direction;
		}
		if ((Object)(object)ParticleSystem != (Object)null)
		{
			if (ParticleSystem.isPlaying)
			{
				((Component)ParticleSystem).transform.position = SpellStart.transform.position;
				((Component)ParticleSystem).transform.forward = Direction;
			}
			UpdateParticleLights();
		}
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();
		foreach (GameObject particleLight in particleLights)
		{
			Object.Destroy((Object)(object)particleLight);
		}
	}

	protected override void Start()
	{
		base.Start();
	}

	protected override void Update()
	{
		base.Update();
		UpdateParticleSystems();
		collisionTimer -= LightningBoltScript.DeltaTime;
	}

	protected override void OnCastSpell()
	{
		if ((Object)(object)ParticleSystem != (Object)null)
		{
			ParticleSystem.Play();
			UpdateParticleSystems();
		}
	}

	protected override void OnStopSpell()
	{
		if ((Object)(object)ParticleSystem != (Object)null)
		{
			ParticleSystem.Stop();
		}
	}

	void ICollisionHandler.HandleCollision(GameObject obj, List<ParticleCollisionEvent> collisions, int collisionCount)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (collisionTimer <= 0f)
		{
			collisionTimer = CollisionInterval;
			ParticleCollisionEvent val = collisions[0];
			PlayCollisionSound(((ParticleCollisionEvent)(ref val)).intersection);
			val = collisions[0];
			ApplyCollisionForce(((ParticleCollisionEvent)(ref val)).intersection);
			if (CollisionCallback != null)
			{
				CollisionCallback(obj, collisions, collisionCount);
			}
		}
	}
}
