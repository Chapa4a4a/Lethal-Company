using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningGeneratorPath : LightningGenerator
{
	public static readonly LightningGeneratorPath PathGeneratorInstance = new LightningGeneratorPath();

	public void GenerateLightningBoltPath(LightningBolt bolt, Vector3 start, Vector3 end, LightningBoltParameters parameters)
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_030b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0312: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		if (parameters.Points.Count < 2)
		{
			Debug.LogError((object)"Lightning path should have at least two points");
			return;
		}
		int generations = parameters.Generations;
		int totalGenerations = generations;
		float num = ((generations == parameters.Generations) ? parameters.ChaosFactor : parameters.ChaosFactorForks);
		int num2 = parameters.SmoothingFactor - 1;
		LightningBoltSegmentGroup lightningBoltSegmentGroup = bolt.AddGroup();
		lightningBoltSegmentGroup.LineWidth = parameters.TrunkWidth;
		lightningBoltSegmentGroup.Generation = generations--;
		lightningBoltSegmentGroup.EndWidthMultiplier = parameters.EndWidthMultiplier;
		lightningBoltSegmentGroup.Color = parameters.Color;
		if (generations == parameters.Generations && (parameters.MainTrunkTintColor.r != byte.MaxValue || parameters.MainTrunkTintColor.g != byte.MaxValue || parameters.MainTrunkTintColor.b != byte.MaxValue || parameters.MainTrunkTintColor.a != byte.MaxValue))
		{
			lightningBoltSegmentGroup.Color.r = (byte)(0.003921569f * (float)(int)lightningBoltSegmentGroup.Color.r * (float)(int)parameters.MainTrunkTintColor.r);
			lightningBoltSegmentGroup.Color.g = (byte)(0.003921569f * (float)(int)lightningBoltSegmentGroup.Color.g * (float)(int)parameters.MainTrunkTintColor.g);
			lightningBoltSegmentGroup.Color.b = (byte)(0.003921569f * (float)(int)lightningBoltSegmentGroup.Color.b * (float)(int)parameters.MainTrunkTintColor.b);
			lightningBoltSegmentGroup.Color.a = (byte)(0.003921569f * (float)(int)lightningBoltSegmentGroup.Color.a * (float)(int)parameters.MainTrunkTintColor.a);
		}
		parameters.Start = parameters.Points[0] + start;
		parameters.End = parameters.Points[parameters.Points.Count - 1] + end;
		end = parameters.Start;
		for (int i = 1; i < parameters.Points.Count; i++)
		{
			start = end;
			end = parameters.Points[i];
			Vector3 val = end - start;
			float num3 = PathGenerator.SquareRoot(((Vector3)(ref val)).sqrMagnitude);
			if (num > 0f)
			{
				end = ((bolt.CameraMode == CameraMode.Perspective) ? (end + num3 * num * RandomDirection3D(parameters.Random)) : ((bolt.CameraMode != CameraMode.OrthographicXY) ? (end + num3 * num * RandomDirection2DXZ(parameters.Random)) : (end + num3 * num * RandomDirection2D(parameters.Random))));
				val = end - start;
			}
			lightningBoltSegmentGroup.Segments.Add(new LightningBoltSegment
			{
				Start = start,
				End = end
			});
			float offsetAmount = num3 * num;
			RandomVector(bolt, ref start, ref end, offsetAmount, parameters.Random, out var result);
			if (ShouldCreateFork(parameters, generations, totalGenerations))
			{
				Vector3 val2 = val * parameters.ForkMultiplier() * (float)num2 * 0.5f;
				Vector3 end2 = end + val2 + result;
				GenerateLightningBoltStandard(bolt, start, end2, generations, totalGenerations, 0f, parameters);
			}
			if (--num2 == 0)
			{
				num2 = parameters.SmoothingFactor - 1;
			}
		}
	}

	protected override void OnGenerateLightningBolt(LightningBolt bolt, Vector3 start, Vector3 end, LightningBoltParameters parameters)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		GenerateLightningBoltPath(bolt, start, end, parameters);
	}
}
