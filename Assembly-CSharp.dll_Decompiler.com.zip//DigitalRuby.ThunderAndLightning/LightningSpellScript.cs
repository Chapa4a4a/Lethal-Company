using System.Collections;
using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public abstract class LightningSpellScript : MonoBehaviour
{
	[Header("Direction and distance")]
	[Tooltip("The start point of the spell. Set this to a muzzle end or hand.")]
	public GameObject SpellStart;

	[Tooltip("The end point of the spell. Set this to an empty game object. This will change depending on things like collisions, randomness, etc. Not all spells need an end object, but create this anyway to be sure.")]
	public GameObject SpellEnd;

	[HideInInspector]
	[Tooltip("The direction of the spell. Should be normalized. Does not change unless explicitly modified.")]
	public Vector3 Direction;

	[Tooltip("The maximum distance of the spell")]
	public float MaxDistance = 15f;

	[Header("Collision")]
	[Tooltip("Whether the collision is an exploision. If not explosion, collision is directional.")]
	public bool CollisionIsExplosion;

	[Tooltip("The radius of the collision explosion")]
	public float CollisionRadius = 1f;

	[Tooltip("The force to explode with when there is a collision")]
	public float CollisionForce = 50f;

	[Tooltip("Collision force mode")]
	public ForceMode CollisionForceMode = (ForceMode)1;

	[Tooltip("The particle system for collisions. For best effects, this should emit particles in bursts at time 0 and not loop.")]
	public ParticleSystem CollisionParticleSystem;

	[Tooltip("The layers that the spell should collide with")]
	public LayerMask CollisionMask = LayerMask.op_Implicit(-1);

	[Tooltip("Collision audio source")]
	public AudioSource CollisionAudioSource;

	[Tooltip("Collision audio clips. One will be chosen at random and played one shot with CollisionAudioSource.")]
	public AudioClip[] CollisionAudioClips;

	[Tooltip("Collision sound volume range.")]
	public RangeOfFloats CollisionVolumeRange = new RangeOfFloats
	{
		Minimum = 0.4f,
		Maximum = 0.6f
	};

	[Header("Duration and Cooldown")]
	[Tooltip("The duration in seconds that the spell will last. Not all spells support a duration. For one shot spells, this is how long the spell cast / emission light, etc. will last.")]
	public float Duration;

	[Tooltip("The cooldown in seconds. Once cast, the spell must wait for the cooldown before being cast again.")]
	public float Cooldown;

	[Header("Emission")]
	[Tooltip("Emission sound")]
	public AudioSource EmissionSound;

	[Tooltip("Emission particle system. For best results use world space, turn off looping and play on awake.")]
	public ParticleSystem EmissionParticleSystem;

	[Tooltip("Light to illuminate when spell is cast")]
	public Light EmissionLight;

	private int stopToken;

	protected float DurationTimer { get; private set; }

	protected float CooldownTimer { get; private set; }

	public bool Casting { get; private set; }

	public bool CanCastSpell
	{
		get
		{
			if (!Casting)
			{
				return CooldownTimer <= 0f;
			}
			return false;
		}
	}

	private IEnumerator StopAfterSecondsCoRoutine(float seconds)
	{
		int token = stopToken;
		yield return new WaitForSecondsLightning(seconds);
		if (token == stopToken)
		{
			StopSpell();
		}
	}

	protected void ApplyCollisionForce(Vector3 point)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		if (!(CollisionForce > 0f) || !(CollisionRadius > 0f))
		{
			return;
		}
		Collider[] array = Physics.OverlapSphere(point, CollisionRadius, LayerMask.op_Implicit(CollisionMask));
		for (int i = 0; i < array.Length; i++)
		{
			Rigidbody component = ((Component)array[i]).GetComponent<Rigidbody>();
			if ((Object)(object)component != (Object)null)
			{
				if (CollisionIsExplosion)
				{
					component.AddExplosionForce(CollisionForce, point, CollisionRadius, CollisionForce * 0.02f, CollisionForceMode);
				}
				else
				{
					component.AddForce(CollisionForce * Direction, CollisionForceMode);
				}
			}
		}
	}

	protected void PlayCollisionSound(Vector3 pos)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)CollisionAudioSource != (Object)null && CollisionAudioClips != null && CollisionAudioClips.Length != 0)
		{
			int num = Random.Range(0, CollisionAudioClips.Length - 1);
			float num2 = Random.Range(CollisionVolumeRange.Minimum, CollisionVolumeRange.Maximum);
			((Component)CollisionAudioSource).transform.position = pos;
			CollisionAudioSource.PlayOneShot(CollisionAudioClips[num], num2);
		}
	}

	protected virtual void Start()
	{
		if ((Object)(object)EmissionLight != (Object)null)
		{
			((Behaviour)EmissionLight).enabled = false;
		}
	}

	protected virtual void Update()
	{
		CooldownTimer = Mathf.Max(0f, CooldownTimer - LightningBoltScript.DeltaTime);
		DurationTimer = Mathf.Max(0f, DurationTimer - LightningBoltScript.DeltaTime);
	}

	protected virtual void LateUpdate()
	{
	}

	protected virtual void OnDestroy()
	{
	}

	protected abstract void OnCastSpell();

	protected abstract void OnStopSpell();

	protected virtual void OnActivated()
	{
	}

	protected virtual void OnDeactivated()
	{
	}

	public bool CastSpell()
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		if (!CanCastSpell)
		{
			return false;
		}
		Casting = true;
		DurationTimer = Duration;
		CooldownTimer = Cooldown;
		OnCastSpell();
		if (Duration > 0f)
		{
			StopAfterSeconds(Duration);
		}
		if ((Object)(object)EmissionParticleSystem != (Object)null)
		{
			EmissionParticleSystem.Play();
		}
		if ((Object)(object)EmissionLight != (Object)null)
		{
			((Component)EmissionLight).transform.position = SpellStart.transform.position;
			((Behaviour)EmissionLight).enabled = true;
		}
		if ((Object)(object)EmissionSound != (Object)null)
		{
			EmissionSound.Play();
		}
		return true;
	}

	public void StopSpell()
	{
		if (Casting)
		{
			stopToken++;
			if ((Object)(object)EmissionParticleSystem != (Object)null)
			{
				EmissionParticleSystem.Stop();
			}
			if ((Object)(object)EmissionLight != (Object)null)
			{
				((Behaviour)EmissionLight).enabled = false;
			}
			if ((Object)(object)EmissionSound != (Object)null && EmissionSound.loop)
			{
				EmissionSound.Stop();
			}
			DurationTimer = 0f;
			Casting = false;
			OnStopSpell();
		}
	}

	public void ActivateSpell()
	{
		OnActivated();
	}

	public void DeactivateSpell()
	{
		OnDeactivated();
	}

	public void StopAfterSeconds(float seconds)
	{
		((MonoBehaviour)this).StartCoroutine(StopAfterSecondsCoRoutine(seconds));
	}

	public static GameObject FindChildRecursively(Transform t, string name)
	{
		if (((Object)t).name == name)
		{
			return ((Component)t).gameObject;
		}
		for (int i = 0; i < t.childCount; i++)
		{
			GameObject val = FindChildRecursively(t.GetChild(i), name);
			if ((Object)(object)val != (Object)null)
			{
				return val;
			}
		}
		return null;
	}
}
