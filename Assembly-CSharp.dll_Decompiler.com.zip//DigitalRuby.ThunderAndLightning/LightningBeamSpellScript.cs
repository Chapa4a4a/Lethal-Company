using System;
using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningBeamSpellScript : LightningSpellScript
{
	[Header("Beam")]
	[Tooltip("The lightning path script creating the beam of lightning")]
	public LightningBoltPathScriptBase LightningPathScript;

	[Tooltip("Give the end point some randomization")]
	public float EndPointRandomization = 1.5f;

	[HideInInspector]
	public Action<RaycastHit> CollisionCallback;

	private void CheckCollision()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit obj = default(RaycastHit);
		if (Physics.Raycast(SpellStart.transform.position, Direction, ref obj, MaxDistance, LayerMask.op_Implicit(CollisionMask)))
		{
			SpellEnd.transform.position = ((RaycastHit)(ref obj)).point;
			Transform transform = SpellEnd.transform;
			transform.position += Random.insideUnitSphere * EndPointRandomization;
			PlayCollisionSound(SpellEnd.transform.position);
			if ((Object)(object)CollisionParticleSystem != (Object)null)
			{
				((Component)CollisionParticleSystem).transform.position = ((RaycastHit)(ref obj)).point;
				CollisionParticleSystem.Play();
			}
			ApplyCollisionForce(((RaycastHit)(ref obj)).point);
			if (CollisionCallback != null)
			{
				CollisionCallback(obj);
			}
		}
		else
		{
			if ((Object)(object)CollisionParticleSystem != (Object)null)
			{
				CollisionParticleSystem.Stop();
			}
			SpellEnd.transform.position = SpellStart.transform.position + Direction * MaxDistance;
			Transform transform2 = SpellEnd.transform;
			transform2.position += Random.insideUnitSphere * EndPointRandomization;
		}
	}

	protected override void Start()
	{
		base.Start();
		LightningPathScript.ManualMode = true;
	}

	protected override void LateUpdate()
	{
		base.LateUpdate();
		if (base.Casting)
		{
			CheckCollision();
		}
	}

	protected override void OnCastSpell()
	{
		LightningPathScript.ManualMode = false;
	}

	protected override void OnStopSpell()
	{
		LightningPathScript.ManualMode = true;
	}
}
