using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace DigitalRuby.ThunderAndLightning;

public class LightningBoltTransformTrackerScript : MonoBehaviour
{
	[Tooltip("The lightning script to track.")]
	public LightningBoltPrefabScript LightningScript;

	[Tooltip("The transform to track which will be where the bolts are emitted from.")]
	public Transform StartTarget;

	[Tooltip("(Optional) The transform to track which will be where the bolts are emitted to. If no end target is specified, lightning will simply move to stay on top of the start target.")]
	public Transform EndTarget;

	[SingleLine("Scaling limits.")]
	public RangeOfFloats ScaleLimit = new RangeOfFloats
	{
		Minimum = 0.1f,
		Maximum = 10f
	};

	private readonly Dictionary<Transform, LightningCustomTransformStateInfo> transformStartPositions = new Dictionary<Transform, LightningCustomTransformStateInfo>();

	private void Start()
	{
		if ((Object)(object)LightningScript != (Object)null)
		{
			((UnityEventBase)LightningScript.CustomTransformHandler).RemoveAllListeners();
			((UnityEvent<LightningCustomTransformStateInfo>)LightningScript.CustomTransformHandler).AddListener((UnityAction<LightningCustomTransformStateInfo>)CustomTransformHandler);
		}
	}

	private static float AngleBetweenVector2(Vector2 vec1, Vector2 vec2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = vec2 - vec1;
		Vector2 normalized = ((Vector2)(ref val)).normalized;
		return Vector2.Angle(Vector2.right, normalized) * Mathf.Sign(vec2.y - vec1.y);
	}

	private static void UpdateTransform(LightningCustomTransformStateInfo state, LightningBoltPrefabScript script, RangeOfFloats scaleLimit)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)state.Transform == (Object)null || (Object)(object)state.StartTransform == (Object)null)
		{
			return;
		}
		if ((Object)(object)state.EndTransform == (Object)null)
		{
			state.Transform.position = state.StartTransform.position - state.BoltStartPosition;
			return;
		}
		Quaternion val;
		if ((script.CameraMode == CameraMode.Auto && script.Camera.orthographic) || script.CameraMode == CameraMode.OrthographicXY)
		{
			float num = AngleBetweenVector2(Vector2.op_Implicit(state.BoltStartPosition), Vector2.op_Implicit(state.BoltEndPosition));
			val = Quaternion.AngleAxis(AngleBetweenVector2(Vector2.op_Implicit(state.StartTransform.position), Vector2.op_Implicit(state.EndTransform.position)) - num, Vector3.forward);
		}
		if (script.CameraMode == CameraMode.OrthographicXZ)
		{
			float num2 = AngleBetweenVector2(new Vector2(state.BoltStartPosition.x, state.BoltStartPosition.z), new Vector2(state.BoltEndPosition.x, state.BoltEndPosition.z));
			val = Quaternion.AngleAxis(AngleBetweenVector2(new Vector2(state.StartTransform.position.x, state.StartTransform.position.z), new Vector2(state.EndTransform.position.x, state.EndTransform.position.z)) - num2, Vector3.up);
		}
		else
		{
			Vector3 val2 = state.BoltEndPosition - state.BoltStartPosition;
			Quaternion val3 = Quaternion.LookRotation(((Vector3)(ref val2)).normalized);
			val2 = state.EndTransform.position - state.StartTransform.position;
			val = Quaternion.LookRotation(((Vector3)(ref val2)).normalized) * Quaternion.Inverse(val3);
		}
		state.Transform.rotation = val;
		float num3 = Vector3.Distance(state.BoltStartPosition, state.BoltEndPosition);
		float num4 = Vector3.Distance(state.EndTransform.position, state.StartTransform.position);
		float num5 = Mathf.Clamp((num3 < Mathf.Epsilon) ? 1f : (num4 / num3), scaleLimit.Minimum, scaleLimit.Maximum);
		state.Transform.localScale = new Vector3(num5, num5, num5);
		Vector3 val4 = val * (num5 * state.BoltStartPosition);
		state.Transform.position = state.StartTransform.position - val4;
	}

	public void CustomTransformHandler(LightningCustomTransformStateInfo state)
	{
		if (((Behaviour)this).enabled)
		{
			if ((Object)(object)LightningScript == (Object)null)
			{
				Debug.LogError((object)"LightningScript property must be set to non-null.");
			}
			else if (state.State == LightningCustomTransformState.Executing)
			{
				UpdateTransform(state, LightningScript, ScaleLimit);
			}
			else if (state.State == LightningCustomTransformState.Started)
			{
				state.StartTransform = StartTarget;
				state.EndTransform = EndTarget;
				transformStartPositions[((Component)this).transform] = state;
			}
			else
			{
				transformStartPositions.Remove(((Component)this).transform);
			}
		}
	}
}
