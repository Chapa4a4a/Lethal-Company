using UnityEngine;

namespace DigitalRuby.ThunderAndLightning;

public class LightningBoltPrefabScript : LightningBoltPrefabScriptBase
{
	[Header("Start/end")]
	[Tooltip("The source game object, can be null")]
	public GameObject Source;

	[Tooltip("The destination game object, can be null")]
	public GameObject Destination;

	[Tooltip("X, Y and Z for variance from the start point. Use positive values.")]
	public Vector3 StartVariance;

	[Tooltip("X, Y and Z for variance from the end point. Use positive values.")]
	public Vector3 EndVariance;

	public override void CreateLightningBolt(LightningBoltParameters parameters)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		parameters.Start = (((Object)(object)Source == (Object)null) ? parameters.Start : Source.transform.position);
		parameters.End = (((Object)(object)Destination == (Object)null) ? parameters.End : Destination.transform.position);
		parameters.StartVariance = StartVariance;
		parameters.EndVariance = EndVariance;
		base.CreateLightningBolt(parameters);
	}
}
