using Unity.Netcode;
using UnityEngine;

public class SyncWithServerOnSpawn : NetworkBehaviour
{
	public RoundManager roundManager;

	private bool hasSynced;

	private void Start()
	{
	}

	public void SyncWithServer()
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		NetworkObject component = ((Component)this).gameObject.GetComponent<NetworkObject>();
		if ((Object)(object)component != (Object)null)
		{
			component.Spawn(true);
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "SyncWithServerOnSpawn";
	}
}
