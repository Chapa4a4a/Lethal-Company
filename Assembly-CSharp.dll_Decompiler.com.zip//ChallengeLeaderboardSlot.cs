using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ChallengeLeaderboardSlot : MonoBehaviour
{
	public RawImage profileIcon;

	public TextMeshProUGUI userNameText;

	public TextMeshProUGUI rankNumText;

	public TextMeshProUGUI scrapCollectedText;

	public SteamId steamId;

	public void SetSlotValues(string userName, int rankNum, int scrapCollected, SteamId playerSteamId, int entryDetails)
	{
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		((TMP_Text)userNameText).text = userName.Substring(0, Mathf.Min(userName.Length, 15));
		((TMP_Text)rankNumText).text = $"#{rankNum}";
		switch (entryDetails)
		{
		case 2:
			((TMP_Text)scrapCollectedText).text = "(Removed score)";
			break;
		case 3:
			((TMP_Text)scrapCollectedText).text = "Deceased";
			break;
		default:
			((TMP_Text)scrapCollectedText).text = $"${scrapCollected} Collected";
			break;
		}
		steamId = playerSteamId;
		((Graphic)profileIcon).color = Color.white;
		HUDManager.FillImageWithSteamProfile(profileIcon, SteamId.op_Implicit(SteamId.op_Implicit(playerSteamId)), large: false);
	}

	public void ClickProfileIcon()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (!GameNetworkManager.Instance.disableSteam && SteamId.op_Implicit(steamId) != 0L)
		{
			SteamFriends.OpenUserOverlay(steamId, "steamid");
		}
	}
}
