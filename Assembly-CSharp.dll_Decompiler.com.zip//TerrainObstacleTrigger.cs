using Unity.Netcode;
using UnityEngine;

public class TerrainObstacleTrigger : MonoBehaviour
{
	private void OnTriggerEnter(Collider other)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		VehicleController component = ((Component)other).GetComponent<VehicleController>();
		if (!((Object)(object)component == (Object)null) && ((NetworkBehaviour)component).IsOwner && ((Vector3)(ref component.averageVelocity)).magnitude > 5f && Vector3.Angle(component.averageVelocity, ((Component)this).transform.position - component.mainRigidbody.position) < 80f)
		{
			RoundManager.Instance.DestroyTreeOnLocalClient(((Component)this).transform.position);
			component.CarReactToObstacle(component.mainRigidbody.position - ((Component)this).transform.position, ((Component)this).transform.position, Vector3.zero, CarObstacleType.Object, 1f, null, dealDamage: false);
		}
	}
}
