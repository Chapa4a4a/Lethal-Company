using GameNetcodeStuff;
using UnityEngine.Events;

public class PlayerEvent : UnityEvent<PlayerControllerB>
{
}
