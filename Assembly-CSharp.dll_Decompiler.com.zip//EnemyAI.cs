using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public abstract class EnemyAI : NetworkBehaviour
{
	public EnemyType enemyType;

	[Space(5f)]
	public SkinnedMeshRenderer[] skinnedMeshRenderers;

	public MeshRenderer[] meshRenderers;

	public Animator creatureAnimator;

	public AudioSource creatureVoice;

	public AudioSource creatureSFX;

	public Transform eye;

	public AudioClip dieSFX;

	[Space(3f)]
	public EnemyBehaviourState[] enemyBehaviourStates;

	public EnemyBehaviourState currentBehaviourState;

	public int currentBehaviourStateIndex;

	public int previousBehaviourStateIndex;

	public int currentOwnershipOnThisClient = -1;

	public bool isInsidePlayerShip;

	[Header("AI Calculation / Netcode")]
	public float AIIntervalTime = 0.2f;

	public bool inSpecialAnimation;

	public PlayerControllerB inSpecialAnimationWithPlayer;

	[HideInInspector]
	public Vector3 serverPosition;

	[HideInInspector]
	public Vector3 serverRotation;

	private float previousYRotation;

	private float targetYRotation;

	public NavMeshAgent agent;

	[HideInInspector]
	public NavMeshPath path1;

	public GameObject[] allAINodes;

	public Transform targetNode;

	public Transform favoriteSpot;

	[HideInInspector]
	public float tempDist;

	[HideInInspector]
	public float mostOptimalDistance;

	[HideInInspector]
	public float pathDistance;

	[HideInInspector]
	public NetworkObject thisNetworkObject;

	public int thisEnemyIndex;

	public bool isClientCalculatingAI;

	public float updatePositionThreshold = 1f;

	private Vector3 tempVelocity;

	public PlayerControllerB targetPlayer;

	public bool movingTowardsTargetPlayer;

	public bool moveTowardsDestination = true;

	public Vector3 destination;

	public float addPlayerVelocityToDestination;

	private float updateDestinationInterval;

	public float syncMovementSpeed = 0.22f;

	public float timeSinceSpawn;

	public float exitVentAnimationTime = 1f;

	public bool ventAnimationFinished;

	[Space(5f)]
	public bool isEnemyDead;

	public bool daytimeEnemyLeaving;

	public int enemyHP = 3;

	public GameObject[] nodesTempArray;

	public float openDoorSpeedMultiplier;

	public bool useSecondaryAudiosOnAnimatedObjects;

	public AISearchRoutine currentSearch;

	public Coroutine searchCoroutine;

	public Coroutine chooseTargetNodeCoroutine;

	private RaycastHit raycastHit;

	private Ray LOSRay;

	public bool DebugEnemy;

	public int stunnedIndefinitely;

	public float stunNormalizedTimer;

	public float postStunInvincibilityTimer;

	public PlayerControllerB stunnedByPlayer;

	protected float setDestinationToPlayerInterval;

	public bool debugEnemyAI;

	[HideInInspector]
	public bool removedPowerLevel;

	public bool isOutside;

	public bool hitsPhysicsObjects;

	private Random searchRoutineRandom;

	private int getFarthestNodeAsyncBookmark;

	public bool gotFarthestNodeAsync;

	private Collider[] overlapColliders;

	protected GameObject nestObject;

	public virtual void SetEnemyStunned(bool setToStunned, float setToStunTime = 1f, PlayerControllerB setStunnedByPlayer = null)
	{
		if (isEnemyDead || !enemyType.canBeStunned)
		{
			return;
		}
		if (setToStunned)
		{
			if (!(postStunInvincibilityTimer >= 0f))
			{
				if (stunNormalizedTimer <= 0f && (Object)(object)creatureVoice != (Object)null)
				{
					creatureVoice.PlayOneShot(enemyType.stunSFX);
				}
				stunnedByPlayer = setStunnedByPlayer;
				postStunInvincibilityTimer = 0.5f;
				stunNormalizedTimer = setToStunTime;
			}
		}
		else
		{
			stunnedByPlayer = null;
			if (stunNormalizedTimer > 0f)
			{
				stunNormalizedTimer = 0f;
			}
		}
	}

	public virtual void UseNestSpawnObject(EnemyAINestSpawnObject nestSpawnObject)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		((Behaviour)agent).enabled = false;
		((Component)this).transform.position = ((Component)nestSpawnObject).transform.position;
		((Component)this).transform.rotation = ((Component)nestSpawnObject).transform.rotation;
		((Behaviour)agent).enabled = true;
		if (RoundManager.Instance.enemyNestSpawnObjects.Contains(nestSpawnObject))
		{
			RoundManager.Instance.enemyNestSpawnObjects.Remove(nestSpawnObject);
		}
		nestObject = ((Component)nestSpawnObject).gameObject;
		if (!enemyType.useMinEnemyThresholdForNest)
		{
			Debug.Log((object)$"Enemy {((Object)((Component)this).gameObject).name} #{thisEnemyIndex} destroying nest object '{((Component)nestSpawnObject).gameObject}'");
			Object.Destroy((Object)(object)((Component)nestSpawnObject).gameObject);
		}
	}

	public virtual void Start()
	{
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Expected O, but got Unknown
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			overlapColliders = (Collider[])(object)new Collider[1];
			agent = ((Component)this).gameObject.GetComponentInChildren<NavMeshAgent>();
			skinnedMeshRenderers = ((Component)this).gameObject.GetComponentsInChildren<SkinnedMeshRenderer>();
			meshRenderers = ((Component)this).gameObject.GetComponentsInChildren<MeshRenderer>();
			if ((Object)(object)creatureAnimator == (Object)null)
			{
				creatureAnimator = ((Component)this).gameObject.GetComponentInChildren<Animator>();
			}
			thisNetworkObject = ((Component)this).gameObject.GetComponentInChildren<NetworkObject>();
			thisEnemyIndex = RoundManager.Instance.numberOfEnemiesInScene;
			RoundManager.Instance.numberOfEnemiesInScene++;
			isOutside = enemyType.isOutsideEnemy;
			if (enemyType.isOutsideEnemy)
			{
				allAINodes = GameObject.FindGameObjectsWithTag("OutsideAINode");
				if ((Object)(object)enemyType.nestSpawnPrefab != (Object)null)
				{
					for (int i = 0; i < RoundManager.Instance.enemyNestSpawnObjects.Count; i++)
					{
						if ((Object)(object)RoundManager.Instance.enemyNestSpawnObjects[i] == (Object)null)
						{
							RoundManager.Instance.enemyNestSpawnObjects.RemoveAt(i);
						}
						else if ((Object)(object)RoundManager.Instance.enemyNestSpawnObjects[i].enemyType == (Object)(object)enemyType)
						{
							UseNestSpawnObject(RoundManager.Instance.enemyNestSpawnObjects[i]);
							break;
						}
					}
				}
				if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
				{
					EnableEnemyMesh(!StartOfRound.Instance.hangarDoorsClosed || !GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom);
				}
			}
			else
			{
				allAINodes = GameObject.FindGameObjectsWithTag("AINode");
			}
			if (!((NetworkBehaviour)this).IsServer)
			{
				RoundManager.Instance.SpawnedEnemies.Add(this);
			}
			path1 = new NavMeshPath();
			openDoorSpeedMultiplier = enemyType.doorSpeedMultiplier;
			serverPosition = ((Component)this).transform.position;
			if (((NetworkBehaviour)this).IsOwner)
			{
				SyncPositionToClients();
			}
			else
			{
				SetClientCalculatingAI(enable: false);
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error when initializing enemy variables for {((Object)((Component)this).gameObject).name} : {arg}");
		}
	}

	public PlayerControllerB MeetsStandardPlayerCollisionConditions(Collider other, bool inKillAnimation = false, bool overrideIsInsideFactoryCheck = false)
	{
		if (isEnemyDead)
		{
			return null;
		}
		if (!ventAnimationFinished)
		{
			return null;
		}
		if (inKillAnimation)
		{
			return null;
		}
		if (stunNormalizedTimer >= 0f)
		{
			return null;
		}
		PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
		if ((Object)(object)component == (Object)null || (Object)(object)component != (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			return null;
		}
		if (!PlayerIsTargetable(component, cannotBeInShip: false, overrideIsInsideFactoryCheck))
		{
			Debug.Log((object)"Player is not targetable");
			return null;
		}
		return component;
	}

	public virtual void OnCollideWithPlayer(Collider other)
	{
		if (debugEnemyAI)
		{
			Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Collided with player!"));
		}
	}

	public virtual void OnCollideWithEnemy(Collider other, EnemyAI collidedEnemy = null)
	{
		if (((NetworkBehaviour)this).IsServer && debugEnemyAI)
		{
			Debug.Log((object)(((Object)((Component)this).gameObject).name + " collided with enemy!: " + ((Object)((Component)other).gameObject).name));
		}
	}

	public void SwitchToBehaviourState(int stateIndex)
	{
		SwitchToBehaviourStateOnLocalClient(stateIndex);
		SwitchToBehaviourServerRpc(stateIndex);
	}

	[ServerRpc(RequireOwnership = false)]
	public void SwitchToBehaviourServerRpc(int stateIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2081148948u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, stateIndex);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2081148948u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && ((NetworkBehaviour)this).NetworkObject.IsSpawned)
			{
				SwitchToBehaviourClientRpc(stateIndex);
			}
		}
	}

	[ClientRpc]
	public void SwitchToBehaviourClientRpc(int stateIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2962895088u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, stateIndex);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2962895088u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && stateIndex != currentBehaviourStateIndex)
			{
				SwitchToBehaviourStateOnLocalClient(stateIndex);
			}
		}
	}

	public void SwitchToBehaviourStateOnLocalClient(int stateIndex)
	{
		if (currentBehaviourStateIndex != stateIndex)
		{
			previousBehaviourStateIndex = currentBehaviourStateIndex;
			currentBehaviourStateIndex = stateIndex;
			currentBehaviourState = enemyBehaviourStates[stateIndex];
			PlayAudioOfCurrentState();
			PlayAnimationOfCurrentState();
		}
	}

	public void PlayAnimationOfCurrentState()
	{
		if (!((Object)(object)creatureAnimator == (Object)null))
		{
			if (currentBehaviourState.IsAnimTrigger)
			{
				creatureAnimator.SetTrigger(currentBehaviourState.parameterString);
			}
			else
			{
				creatureAnimator.SetBool(currentBehaviourState.parameterString, currentBehaviourState.boolValue);
			}
		}
	}

	public void PlayAudioOfCurrentState()
	{
		if (Object.op_Implicit((Object)(object)creatureVoice))
		{
			if (currentBehaviourState.playOneShotVoice)
			{
				creatureVoice.PlayOneShot(currentBehaviourState.VoiceClip);
				WalkieTalkie.TransmitOneShotAudio(creatureVoice, currentBehaviourState.VoiceClip, creatureVoice.volume);
			}
			else if ((Object)(object)currentBehaviourState.VoiceClip != (Object)null)
			{
				creatureVoice.clip = currentBehaviourState.VoiceClip;
				creatureVoice.Play();
			}
		}
		if (Object.op_Implicit((Object)(object)creatureSFX))
		{
			if (currentBehaviourState.playOneShotSFX)
			{
				creatureSFX.PlayOneShot(currentBehaviourState.SFXClip);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, currentBehaviourState.SFXClip, creatureSFX.volume);
			}
			else if ((Object)(object)currentBehaviourState.SFXClip != (Object)null)
			{
				creatureSFX.clip = currentBehaviourState.SFXClip;
				creatureSFX.Play();
			}
		}
	}

	public void SetMovingTowardsTargetPlayer(PlayerControllerB playerScript)
	{
		movingTowardsTargetPlayer = true;
		targetPlayer = playerScript;
	}

	public bool SetDestinationToPosition(Vector3 position, bool checkForPath = false)
	{
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected O, but got Unknown
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if (checkForPath)
		{
			position = RoundManager.Instance.GetNavMeshPosition(position, RoundManager.Instance.navHit, 1.75f);
			path1 = new NavMeshPath();
			if (!agent.CalculatePath(position, path1))
			{
				return false;
			}
			if (Vector3.Distance(path1.corners[path1.corners.Length - 1], RoundManager.Instance.GetNavMeshPosition(position, RoundManager.Instance.navHit, 2.7f)) > 1.55f)
			{
				return false;
			}
		}
		moveTowardsDestination = true;
		movingTowardsTargetPlayer = false;
		destination = RoundManager.Instance.GetNavMeshPosition(position, RoundManager.Instance.navHit, -1f);
		return true;
	}

	public virtual void DoAIInterval()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (moveTowardsDestination)
		{
			agent.SetDestination(destination);
		}
		SyncPositionToClients();
	}

	public void SyncPositionToClients()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(serverPosition, ((Component)this).transform.position) > updatePositionThreshold)
		{
			serverPosition = ((Component)this).transform.position;
			if (((NetworkBehaviour)this).IsServer)
			{
				UpdateEnemyPositionClientRpc(serverPosition);
			}
			else
			{
				UpdateEnemyPositionServerRpc(serverPosition);
			}
		}
	}

	public PlayerControllerB CheckLineOfSightForPlayer(float width = 45f, int range = 60, int proximityAwareness = -1)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		if (isOutside && !enemyType.canSeeThroughFog && TimeOfDay.Instance.currentLevelWeather == LevelWeatherType.Foggy)
		{
			range = Mathf.Clamp(range, 0, 30);
		}
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			Vector3 position = ((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position;
			if (Vector3.Distance(position, eye.position) < (float)range && !Physics.Linecast(eye.position, position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				Vector3 val = position - eye.position;
				if (Vector3.Angle(eye.forward, val) < width || (proximityAwareness != -1 && Vector3.Distance(eye.position, position) < (float)proximityAwareness))
				{
					return StartOfRound.Instance.allPlayerScripts[i];
				}
			}
		}
		return null;
	}

	public PlayerControllerB CheckLineOfSightForClosestPlayer(float width = 45f, int range = 60, int proximityAwareness = -1, float bufferDistance = 0f)
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		if (isOutside && !enemyType.canSeeThroughFog && TimeOfDay.Instance.currentLevelWeather == LevelWeatherType.Foggy)
		{
			range = Mathf.Clamp(range, 0, 30);
		}
		float num = 1000f;
		float num2 = 1000f;
		int num3 = -1;
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			Vector3 position = ((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position;
			if (DebugEnemy)
			{
				Debug.DrawLine(eye.position, position, Color.green, AIIntervalTime);
			}
			if (!Physics.Linecast(eye.position, position, ref raycastHit, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				Vector3 val = position - eye.position;
				num = Vector3.Distance(eye.position, position);
				if ((Vector3.Angle(eye.forward, val) < width || (proximityAwareness != -1 && num < (float)proximityAwareness)) && num < num2)
				{
					num2 = num;
					num3 = i;
				}
			}
			else if (DebugEnemy)
			{
				Debug.Log((object)$"{enemyType.enemyName} #{thisEnemyIndex}: LOS check for player #{i} hit an object: {((RaycastHit)(ref raycastHit)).point}, {((Object)((Component)((RaycastHit)(ref raycastHit)).collider).gameObject).name}, {((Object)((Component)((Component)((RaycastHit)(ref raycastHit)).collider).transform).gameObject).name}; {((Object)((RaycastHit)(ref raycastHit)).collider).name}", (Object)(object)((Component)((RaycastHit)(ref raycastHit)).collider).gameObject);
			}
		}
		if ((Object)(object)targetPlayer != (Object)null && num3 != -1 && (Object)(object)targetPlayer != (Object)(object)StartOfRound.Instance.allPlayerScripts[num3] && bufferDistance > 0f && Mathf.Abs(num2 - Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position)) < bufferDistance)
		{
			return null;
		}
		if (num3 < 0)
		{
			return null;
		}
		mostOptimalDistance = num2;
		return StartOfRound.Instance.allPlayerScripts[num3];
	}

	public PlayerControllerB[] GetAllPlayersInLineOfSight(float width = 45f, int range = 60, Transform eyeObject = null, float proximityCheck = -1f, int layerMask = -1)
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		if (layerMask == -1)
		{
			layerMask = StartOfRound.Instance.collidersAndRoomMaskAndDefault;
		}
		if ((Object)(object)eyeObject == (Object)null)
		{
			eyeObject = eye;
		}
		if (isOutside && !enemyType.canSeeThroughFog && TimeOfDay.Instance.currentLevelWeather == LevelWeatherType.Foggy)
		{
			range = Mathf.Clamp(range, 0, 30);
		}
		List<PlayerControllerB> list = new List<PlayerControllerB>(4);
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (!PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[i]))
			{
				continue;
			}
			Vector3 position = ((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position;
			if (Vector3.Distance(eye.position, position) < (float)range && !Physics.Linecast(eyeObject.position, position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				Vector3 val = position - eyeObject.position;
				if (Vector3.Angle(eyeObject.forward, val) < width || Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position) < proximityCheck)
				{
					list.Add(StartOfRound.Instance.allPlayerScripts[i]);
				}
			}
		}
		if (list.Count == 4)
		{
			return StartOfRound.Instance.allPlayerScripts;
		}
		if (list.Count > 0)
		{
			return list.ToArray();
		}
		return null;
	}

	public bool CheckLineOfSightForPosition(Vector3 objectPosition, float width = 45f, int range = 60, float proximityAwareness = -1f, Transform overrideEye = null)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		if (!isOutside)
		{
			if (objectPosition.y > -80f)
			{
				return false;
			}
		}
		else if (objectPosition.y < -100f)
		{
			return false;
		}
		Transform val = (((Object)(object)overrideEye != (Object)null) ? overrideEye : ((!((Object)(object)eye == (Object)null)) ? eye : ((Component)this).transform));
		RaycastHit val2 = default(RaycastHit);
		if (Vector3.Distance(val.position, objectPosition) < (float)range && !Physics.Linecast(val.position, objectPosition, ref val2, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			Vector3 val3 = objectPosition - val.position;
			if (debugEnemyAI)
			{
				Debug.DrawRay(val.position, objectPosition - val.position, Color.green, 2f);
			}
			if (Vector3.Angle(val.forward, val3) < width || Vector3.Distance(((Component)this).transform.position, objectPosition) < proximityAwareness)
			{
				return true;
			}
		}
		return false;
	}

	public GameObject CheckLineOfSight(List<GameObject> objectsToLookFor, float width = 45f, int range = 60, float proximityAwareness = -1f, Transform useEye = null, int[] itemIdExceptions = null)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)useEye == (Object)null)
		{
			useEye = eye;
		}
		GrabbableObject component = ((Component)((Component)this).transform).GetComponent<GrabbableObject>();
		for (int i = 0; i < objectsToLookFor.Count; i++)
		{
			if ((Object)(object)objectsToLookFor[i] == (Object)null)
			{
				objectsToLookFor.TrimExcess();
				continue;
			}
			Vector3 position = objectsToLookFor[i].transform.position;
			if (!isOutside)
			{
				if (position.y > -80f)
				{
					continue;
				}
			}
			else if (position.y < -100f)
			{
				continue;
			}
			if (!(Vector3.Distance(useEye.position, objectsToLookFor[i].transform.position) < (float)range) || Physics.Linecast(useEye.position, position + Vector3.up * 0.05f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				continue;
			}
			Vector3 val = position - useEye.position;
			if (!(Vector3.Angle(useEye.forward, val) < width) && !(Vector3.Distance(((Component)this).transform.position, position) < proximityAwareness))
			{
				continue;
			}
			if (itemIdExceptions != null)
			{
				GrabbableObject component2 = objectsToLookFor[i].GetComponent<GrabbableObject>();
				if (!((Object)(object)component2 != (Object)null) || !((Object)(object)component2 != (Object)(object)component) || component2.isHeld || component2.deactivated)
				{
					continue;
				}
				for (int j = 0; j < itemIdExceptions.Length; j++)
				{
					_ = component2.itemProperties.itemId;
					_ = itemIdExceptions[j];
				}
			}
			return objectsToLookFor[i];
		}
		return null;
	}

	public void StartSearch(Vector3 startOfSearch, AISearchRoutine newSearch = null)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		StopSearch(currentSearch);
		movingTowardsTargetPlayer = false;
		if (newSearch == null)
		{
			currentSearch = new AISearchRoutine();
			newSearch = currentSearch;
		}
		else
		{
			currentSearch = newSearch;
		}
		currentSearch.currentSearchStartPosition = startOfSearch;
		currentSearch.startedSearchAtSelf = Vector3.Distance(startOfSearch, ((Component)this).transform.position) < 2f;
		if (currentSearch.unsearchedNodes.Count <= 0)
		{
			currentSearch.unsearchedNodes = allAINodes.ToList();
		}
		searchRoutineRandom = new Random(RoundUpToNearestFive(startOfSearch.x) + RoundUpToNearestFive(startOfSearch.z));
		searchCoroutine = ((MonoBehaviour)this).StartCoroutine(CurrentSearchCoroutine());
		currentSearch.inProgress = true;
	}

	private int RoundUpToNearestFive(float x)
	{
		return (int)(x / 5f) * 5;
	}

	public void StopSearch(AISearchRoutine search, bool clear = true)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (search != null)
		{
			if (searchCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(searchCoroutine);
			}
			if (chooseTargetNodeCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(chooseTargetNodeCoroutine);
			}
			search.calculatingNodeInSearch = false;
			search.inProgress = false;
			if (clear)
			{
				search.unsearchedNodes = allAINodes.ToList();
				search.timesFinishingSearch = 0;
				search.nodesEliminatedInCurrentSearch = 0;
				search.currentTargetNode = null;
				search.currentSearchStartPosition = Vector3.zero;
				search.nextTargetNode = null;
				search.choseTargetNode = false;
				search.startedSearchAtSelf = false;
			}
		}
	}

	private IEnumerator CurrentSearchCoroutine()
	{
		yield return null;
		while (searchCoroutine != null && ((NetworkBehaviour)this).IsOwner)
		{
			yield return null;
			if (currentSearch.unsearchedNodes.Count <= 0)
			{
				FinishedCurrentSearchRoutine();
				if (!currentSearch.loopSearch)
				{
					currentSearch.inProgress = false;
					searchCoroutine = null;
					yield break;
				}
				currentSearch.unsearchedNodes = allAINodes.ToList();
				currentSearch.timesFinishingSearch++;
				currentSearch.nodesEliminatedInCurrentSearch = 0;
				yield return (object)new WaitForSeconds(1f);
			}
			if (currentSearch.choseTargetNode && currentSearch.unsearchedNodes.Contains(currentSearch.nextTargetNode))
			{
				if (debugEnemyAI)
				{
					Debug.Log((object)$"finding next node: {currentSearch.choseTargetNode}; node already found ahead of time");
				}
				currentSearch.currentTargetNode = currentSearch.nextTargetNode;
			}
			else
			{
				if (debugEnemyAI)
				{
					Debug.Log((object)"finding next node; calculation not finished ahead of time");
				}
				currentSearch.waitingForTargetNode = true;
				StartCalculatingNextTargetNode();
				yield return (object)new WaitUntil((Func<bool>)(() => currentSearch.choseTargetNode));
			}
			currentSearch.waitingForTargetNode = false;
			if (currentSearch.unsearchedNodes.Count <= 0 || (Object)(object)currentSearch.currentTargetNode == (Object)null)
			{
				continue;
			}
			if (debugEnemyAI)
			{
				int num = 0;
				for (int j = 0; j < currentSearch.unsearchedNodes.Count; j++)
				{
					if ((Object)(object)currentSearch.unsearchedNodes[j] == (Object)(object)currentSearch.currentTargetNode)
					{
						Debug.Log((object)$"Found node {currentSearch.unsearchedNodes[j]} within list of unsearched nodes at index {j}");
						num++;
					}
				}
				Debug.Log((object)$"Copies of the node {currentSearch.currentTargetNode} found in list: {num}");
				Debug.Log((object)$"unsearched nodes contains {currentSearch.currentTargetNode}? : {currentSearch.unsearchedNodes.Contains(currentSearch.currentTargetNode)}");
				Debug.Log((object)$"Removing {currentSearch.currentTargetNode} from unsearched nodes list with Remove()");
			}
			currentSearch.unsearchedNodes.Remove(currentSearch.currentTargetNode);
			if (debugEnemyAI)
			{
				Debug.Log((object)$"Removed. Does list now contain {currentSearch.currentTargetNode}?: {currentSearch.unsearchedNodes.Contains(currentSearch.currentTargetNode)}");
			}
			SetDestinationToPosition(currentSearch.currentTargetNode.transform.position);
			for (int i = currentSearch.unsearchedNodes.Count - 1; i >= 0; i--)
			{
				if (Vector3.Distance(currentSearch.currentTargetNode.transform.position, currentSearch.unsearchedNodes[i].transform.position) < currentSearch.searchPrecision)
				{
					EliminateNodeFromSearch(i);
				}
				if (i % 10 == 0)
				{
					yield return null;
				}
			}
			StartCalculatingNextTargetNode();
			int timeSpent = 0;
			while (searchCoroutine != null)
			{
				if (debugEnemyAI)
				{
					Debug.Log((object)"Current search not null");
				}
				timeSpent++;
				if (timeSpent >= 32 || (currentSearch.onlySearchNodesInLOS && Physics.Linecast(currentSearch.currentTargetNode.transform.position, currentSearch.currentSearchStartPosition, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)))
				{
					break;
				}
				yield return (object)new WaitForSeconds(0.5f);
				if (Vector3.Distance(((Component)this).transform.position, currentSearch.currentTargetNode.transform.position) < currentSearch.searchPrecision)
				{
					if (debugEnemyAI)
					{
						Debug.Log((object)("Enemy: Reached the target " + ((Object)currentSearch.currentTargetNode).name));
					}
					ReachedNodeInSearch();
					break;
				}
				if (debugEnemyAI)
				{
					Debug.Log((object)$"Enemy: We have not reached the target node {((Object)currentSearch.currentTargetNode.transform).name}, distance: {Vector3.Distance(((Component)this).transform.position, currentSearch.currentTargetNode.transform.position)} ; {currentSearch.searchPrecision}");
				}
			}
			if (debugEnemyAI)
			{
				Debug.Log((object)"Reached destination node");
			}
		}
		if (!((NetworkBehaviour)this).IsOwner)
		{
			StopSearch(currentSearch);
		}
	}

	private void StartCalculatingNextTargetNode()
	{
		if (debugEnemyAI)
		{
			Debug.Log((object)"Calculating next target node");
			Debug.Log((object)$"Is calculate node coroutine null? : {chooseTargetNodeCoroutine == null}; choseTargetNode: {currentSearch.choseTargetNode}");
		}
		if (chooseTargetNodeCoroutine == null)
		{
			if (debugEnemyAI)
			{
				Debug.Log((object)"NODE A");
			}
			currentSearch.choseTargetNode = false;
			chooseTargetNodeCoroutine = ((MonoBehaviour)this).StartCoroutine(ChooseNextNodeInSearchRoutine());
		}
		else if (!currentSearch.calculatingNodeInSearch)
		{
			if (debugEnemyAI)
			{
				Debug.Log((object)"NODE B");
			}
			currentSearch.choseTargetNode = false;
			currentSearch.calculatingNodeInSearch = true;
			((MonoBehaviour)this).StopCoroutine(chooseTargetNodeCoroutine);
			chooseTargetNodeCoroutine = ((MonoBehaviour)this).StartCoroutine(ChooseNextNodeInSearchRoutine());
		}
	}

	private IEnumerator ChooseNextNodeInSearchRoutine()
	{
		yield return null;
		float closestDist = 500f;
		bool gotNode = false;
		GameObject chosenNode = null;
		for (int j = 0; j < currentSearch.unsearchedNodes.Count; j++)
		{
		}
		for (int i = currentSearch.unsearchedNodes.Count - 1; i >= 0; i--)
		{
			if (!((NetworkBehaviour)this).IsOwner)
			{
				currentSearch.calculatingNodeInSearch = false;
				yield break;
			}
			if (i % 5 == 0)
			{
				yield return null;
			}
			if (Vector3.Distance(currentSearch.currentSearchStartPosition, currentSearch.unsearchedNodes[i].transform.position) > currentSearch.searchWidth)
			{
				EliminateNodeFromSearch(i);
			}
			else if (agent.isOnNavMesh && PathIsIntersectedByLineOfSight(currentSearch.unsearchedNodes[i].transform.position, currentSearch.startedSearchAtSelf, avoidLineOfSight: false))
			{
				EliminateNodeFromSearch(i);
			}
			else if (currentSearch.onlySearchNodesInLOS && Physics.Linecast(currentSearch.unsearchedNodes[i].transform.position, currentSearch.currentSearchStartPosition, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				EliminateNodeFromSearch(i);
			}
			else
			{
				if (!currentSearch.startedSearchAtSelf)
				{
					GetPathDistance(currentSearch.unsearchedNodes[i].transform.position, currentSearch.currentSearchStartPosition);
				}
				if (pathDistance < closestDist && (!currentSearch.randomized || !gotNode || searchRoutineRandom.Next(0, 100) < 65))
				{
					closestDist = pathDistance;
					chosenNode = currentSearch.unsearchedNodes[i];
					gotNode = true;
					if (closestDist <= 0f && !currentSearch.randomized)
					{
						break;
					}
				}
			}
		}
		if (debugEnemyAI)
		{
			Debug.Log((object)$"NODE C; chosen node: {chosenNode}");
		}
		if (currentSearch.waitingForTargetNode)
		{
			currentSearch.currentTargetNode = chosenNode;
			if (debugEnemyAI)
			{
				Debug.Log((object)"NODE C1");
			}
		}
		else
		{
			currentSearch.nextTargetNode = chosenNode;
			if (debugEnemyAI)
			{
				Debug.Log((object)"NODE C2");
			}
		}
		currentSearch.choseTargetNode = true;
		if (debugEnemyAI)
		{
			Debug.Log((object)$"Chose target node?: {currentSearch.choseTargetNode} ");
		}
		currentSearch.calculatingNodeInSearch = false;
		chooseTargetNodeCoroutine = null;
	}

	public virtual void ReachedNodeInSearch()
	{
	}

	private void EliminateNodeFromSearch(GameObject node)
	{
		currentSearch.unsearchedNodes.Remove(node);
		currentSearch.nodesEliminatedInCurrentSearch++;
	}

	private void EliminateNodeFromSearch(int index)
	{
		currentSearch.unsearchedNodes.RemoveAt(index);
		currentSearch.nodesEliminatedInCurrentSearch++;
	}

	public virtual void FinishedCurrentSearchRoutine()
	{
	}

	public bool TargetClosestPlayer(float bufferDistance = 1.5f, bool requireLineOfSight = false, float viewWidth = 70f)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		mostOptimalDistance = 2000f;
		PlayerControllerB playerControllerB = targetPlayer;
		targetPlayer = null;
		for (int i = 0; i < StartOfRound.Instance.connectedPlayersAmount + 1; i++)
		{
			if (PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[i]) && !PathIsIntersectedByLineOfSight(((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position, calculatePathDistance: false, avoidLineOfSight: false) && (!requireLineOfSight || CheckLineOfSightForPosition(((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position, viewWidth, 40)))
			{
				tempDist = Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position);
				if (tempDist < mostOptimalDistance)
				{
					mostOptimalDistance = tempDist;
					targetPlayer = StartOfRound.Instance.allPlayerScripts[i];
				}
			}
		}
		if ((Object)(object)targetPlayer != (Object)null && bufferDistance > 0f && (Object)(object)playerControllerB != (Object)null && Mathf.Abs(mostOptimalDistance - Vector3.Distance(((Component)this).transform.position, ((Component)playerControllerB).transform.position)) < bufferDistance)
		{
			targetPlayer = playerControllerB;
		}
		return (Object)(object)targetPlayer != (Object)null;
	}

	public PlayerControllerB GetClosestPlayer(bool requireLineOfSight = false, bool cannotBeInShip = false, bool cannotBeNearShip = false)
	{
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB result = null;
		mostOptimalDistance = 2000f;
		for (int i = 0; i < 4; i++)
		{
			if (!PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[i], cannotBeInShip))
			{
				continue;
			}
			if (cannotBeNearShip)
			{
				if (StartOfRound.Instance.allPlayerScripts[i].isInElevator)
				{
					continue;
				}
				bool flag = false;
				for (int j = 0; j < RoundManager.Instance.spawnDenialPoints.Length; j++)
				{
					if (Vector3.Distance(RoundManager.Instance.spawnDenialPoints[j].transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position) < 10f)
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					continue;
				}
			}
			if (!requireLineOfSight || !Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.25f, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position, 256))
			{
				tempDist = Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position);
				if (tempDist < mostOptimalDistance)
				{
					mostOptimalDistance = tempDist;
					result = StartOfRound.Instance.allPlayerScripts[i];
				}
			}
		}
		return result;
	}

	public bool PlayerIsTargetable(PlayerControllerB playerScript, bool cannotBeInShip = false, bool overrideInsideFactoryCheck = false)
	{
		if (cannotBeInShip && playerScript.isInHangarShipRoom)
		{
			Debug.Log((object)"Targetable A");
			return false;
		}
		if (playerScript.isPlayerControlled && !playerScript.isPlayerDead && (Object)(object)playerScript.inAnimationWithEnemy == (Object)null && (overrideInsideFactoryCheck || playerScript.isInsideFactory != isOutside) && playerScript.sinkingValue < 0.73f)
		{
			if (isOutside && StartOfRound.Instance.hangarDoorsClosed)
			{
				return playerScript.isInHangarShipRoom == isInsidePlayerShip;
			}
			return true;
		}
		return false;
	}

	public Transform ChooseFarthestNodeFromPosition(Vector3 pos, bool avoidLineOfSight = false, int offset = 0, bool doAsync = false, int maxAsyncIterations = 50, bool capDistance = false)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		if (!doAsync || gotFarthestNodeAsync || getFarthestNodeAsyncBookmark <= 0 || nodesTempArray == null || nodesTempArray.Length == 0)
		{
			nodesTempArray = allAINodes.OrderByDescending((GameObject x) => Vector3.Distance(pos, x.transform.position)).ToArray();
		}
		Transform transform = nodesTempArray[0].transform;
		int num = 0;
		if (doAsync)
		{
			if (getFarthestNodeAsyncBookmark >= nodesTempArray.Length)
			{
				getFarthestNodeAsyncBookmark = 0;
			}
			num = getFarthestNodeAsyncBookmark;
			gotFarthestNodeAsync = false;
		}
		for (int i = num; i < nodesTempArray.Length; i++)
		{
			if (doAsync && i - getFarthestNodeAsyncBookmark > maxAsyncIterations)
			{
				gotFarthestNodeAsync = false;
				getFarthestNodeAsyncBookmark = i;
				return null;
			}
			if ((!capDistance || !(Vector3.Distance(((Component)this).transform.position, nodesTempArray[i].transform.position) > 60f)) && !PathIsIntersectedByLineOfSight(nodesTempArray[i].transform.position, calculatePathDistance: false, avoidLineOfSight))
			{
				mostOptimalDistance = Vector3.Distance(pos, nodesTempArray[i].transform.position);
				transform = nodesTempArray[i].transform;
				if (offset == 0 || i >= nodesTempArray.Length - 1)
				{
					break;
				}
				offset--;
			}
		}
		getFarthestNodeAsyncBookmark = 0;
		gotFarthestNodeAsync = true;
		return transform;
	}

	public Transform ChooseClosestNodeToPosition(Vector3 pos, bool avoidLineOfSight = false, int offset = 0)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		nodesTempArray = allAINodes.OrderBy((GameObject x) => Vector3.Distance(pos, x.transform.position)).ToArray();
		Transform transform = nodesTempArray[0].transform;
		for (int i = 0; i < nodesTempArray.Length; i++)
		{
			if (!PathIsIntersectedByLineOfSight(nodesTempArray[i].transform.position, calculatePathDistance: false, avoidLineOfSight))
			{
				mostOptimalDistance = Vector3.Distance(pos, nodesTempArray[i].transform.position);
				transform = nodesTempArray[i].transform;
				if (offset == 0 || i >= nodesTempArray.Length - 1)
				{
					break;
				}
				offset--;
			}
		}
		return transform;
	}

	public bool PathIsIntersectedByLineOfSight(Vector3 targetPos, bool calculatePathDistance = false, bool avoidLineOfSight = true, bool checkLOSToTargetPlayer = false)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0364: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_04df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0454: Unknown result type (might be due to invalid IL or missing references)
		//IL_0465: Unknown result type (might be due to invalid IL or missing references)
		//IL_046f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0474: Unknown result type (might be due to invalid IL or missing references)
		//IL_047e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_0498: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0389: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		//IL_041a: Unknown result type (might be due to invalid IL or missing references)
		//IL_041f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		pathDistance = 0f;
		if (agent.isOnNavMesh && !agent.CalculatePath(targetPos, path1))
		{
			if (DebugEnemy)
			{
				Debug.Log((object)$"Path could not be calculated: {targetPos}");
				Debug.DrawLine(((Component)this).transform.position, targetPos, Color.yellow, 5f);
				Debug.Break();
			}
			return true;
		}
		if (DebugEnemy)
		{
			for (int i = 1; i < path1.corners.Length; i++)
			{
				Debug.DrawLine(path1.corners[i - 1], path1.corners[i], Color.red);
			}
		}
		if (path1 == null || path1.corners.Length == 0)
		{
			return true;
		}
		if (Vector3.Distance(path1.corners[path1.corners.Length - 1], RoundManager.Instance.GetNavMeshPosition(targetPos, RoundManager.Instance.navHit, 2.7f)) > 1.55f)
		{
			if (DebugEnemy)
			{
				Debug.Log((object)$"Path is not complete; final waypoint of path was too far from target position: {targetPos}");
			}
			return true;
		}
		bool flag = false;
		if (calculatePathDistance)
		{
			for (int j = 1; j < path1.corners.Length; j++)
			{
				pathDistance += Vector3.Distance(path1.corners[j - 1], path1.corners[j]);
				if ((!avoidLineOfSight && !checkLOSToTargetPlayer) || j > 15)
				{
					continue;
				}
				if (!flag && j > 8 && Vector3.Distance(path1.corners[j - 1], path1.corners[j]) < 2f)
				{
					if (DebugEnemy)
					{
						Debug.Log((object)$"Distance between corners {j} and {j - 1} under 3 meters; skipping LOS check");
						Debug.DrawRay(path1.corners[j - 1] + Vector3.up * 0.2f, path1.corners[j] + Vector3.up * 0.2f, Color.magenta, 0.2f);
					}
					flag = true;
					continue;
				}
				flag = false;
				if ((Object)(object)targetPlayer != (Object)null && checkLOSToTargetPlayer && !Physics.Linecast(path1.corners[j - 1], ((Component)targetPlayer).transform.position + Vector3.up * 0.3f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					return true;
				}
				if (avoidLineOfSight && Physics.Linecast(path1.corners[j - 1], path1.corners[j], 262144))
				{
					if (DebugEnemy)
					{
						Debug.Log((object)$"{enemyType.enemyName}: The path is blocked by line of sight at corner {j}");
					}
					return true;
				}
			}
		}
		else if (avoidLineOfSight)
		{
			for (int k = 1; k < path1.corners.Length; k++)
			{
				if (DebugEnemy)
				{
					Debug.DrawLine(path1.corners[k - 1], path1.corners[k], Color.green);
				}
				if (!flag && k > 8 && Vector3.Distance(path1.corners[k - 1], path1.corners[k]) < 2f)
				{
					if (DebugEnemy)
					{
						Debug.Log((object)$"Distance between corners {k} and {k - 1} under 3 meters; skipping LOS check");
						Debug.DrawRay(path1.corners[k - 1] + Vector3.up * 0.2f, path1.corners[k] + Vector3.up * 0.2f, Color.magenta, 0.2f);
					}
					flag = true;
					continue;
				}
				if ((Object)(object)targetPlayer != (Object)null && checkLOSToTargetPlayer && !Physics.Linecast(Vector3.Lerp(path1.corners[k - 1], path1.corners[k], 0.5f) + Vector3.up * 0.25f, ((Component)targetPlayer).transform.position + Vector3.up * 0.25f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					return true;
				}
				if (Physics.Linecast(path1.corners[k - 1], path1.corners[k], 262144))
				{
					if (DebugEnemy)
					{
						Debug.Log((object)$"{enemyType.enemyName}: The path is blocked by line of sight at corner {k}");
					}
					return true;
				}
				if (k > 15)
				{
					if (DebugEnemy)
					{
						Debug.Log((object)(enemyType.enemyName + ": Reached corner 15, stopping checks now"));
					}
					return false;
				}
			}
		}
		return false;
	}

	public bool GetPathDistance(Vector3 targetPos, Vector3 sourcePos)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		pathDistance = 0f;
		if (!NavMesh.CalculatePath(sourcePos, targetPos, agent.areaMask, path1))
		{
			if (DebugEnemy)
			{
				Debug.Log((object)"GetPathDistance: Path could not be calculated");
			}
			return false;
		}
		if (path1 == null || path1.corners.Length == 0)
		{
			return false;
		}
		if (Vector3.Distance(path1.corners[path1.corners.Length - 1], RoundManager.Instance.GetNavMeshPosition(targetPos, RoundManager.Instance.navHit, 2.7f)) > 1.5f)
		{
			if (DebugEnemy)
			{
				Debug.Log((object)"GetPathDistance: Path is not complete; final waypoint of path was too far from target position");
			}
			return false;
		}
		for (int i = 1; i < path1.corners.Length; i++)
		{
			pathDistance += Vector3.Distance(path1.corners[i - 1], path1.corners[i]);
		}
		return true;
	}

	public virtual void Update()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		if (enemyType.isDaytimeEnemy && !daytimeEnemyLeaving)
		{
			CheckTimeOfDayToLeave();
		}
		if (stunnedIndefinitely <= 0)
		{
			if (stunNormalizedTimer >= 0f)
			{
				stunNormalizedTimer -= Time.deltaTime / enemyType.stunTimeMultiplier;
			}
			else
			{
				stunnedByPlayer = null;
				if (postStunInvincibilityTimer >= 0f)
				{
					postStunInvincibilityTimer -= Time.deltaTime * 5f;
				}
			}
		}
		if (!ventAnimationFinished && timeSinceSpawn < exitVentAnimationTime + 0.005f * (float)RoundManager.Instance.numberOfEnemiesInScene)
		{
			timeSinceSpawn += Time.deltaTime;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				_ = serverPosition;
				if (serverPosition != Vector3.zero)
				{
					((Component)this).transform.position = serverPosition;
					((Component)this).transform.eulerAngles = new Vector3(((Component)this).transform.eulerAngles.x, targetYRotation, ((Component)this).transform.eulerAngles.z);
				}
			}
			else if (updateDestinationInterval >= 0f)
			{
				updateDestinationInterval -= Time.deltaTime;
			}
			else
			{
				SyncPositionToClients();
				updateDestinationInterval = 0.1f;
			}
			return;
		}
		if (!inSpecialAnimation && !ventAnimationFinished)
		{
			ventAnimationFinished = true;
			if ((Object)(object)creatureAnimator != (Object)null)
			{
				creatureAnimator.SetBool("inSpawningAnimation", false);
			}
		}
		if (!((NetworkBehaviour)this).IsOwner)
		{
			if (currentSearch.inProgress)
			{
				StopSearch(currentSearch);
			}
			SetClientCalculatingAI(enable: false);
			if (!inSpecialAnimation)
			{
				if (RoundManager.Instance.currentDungeonType == 4 && Vector3.Distance(((Component)this).transform.position, RoundManager.Instance.currentMineshaftElevator.elevatorInsidePoint.position) < 1f)
				{
					serverPosition += RoundManager.Instance.currentMineshaftElevator.elevatorInsidePoint.position - RoundManager.Instance.currentMineshaftElevator.previousElevatorPosition;
				}
				((Component)this).transform.position = Vector3.SmoothDamp(((Component)this).transform.position, serverPosition, ref tempVelocity, syncMovementSpeed);
				((Component)this).transform.eulerAngles = new Vector3(((Component)this).transform.eulerAngles.x, Mathf.LerpAngle(((Component)this).transform.eulerAngles.y, targetYRotation, 15f * Time.deltaTime), ((Component)this).transform.eulerAngles.z);
			}
			timeSinceSpawn += Time.deltaTime;
			return;
		}
		if (isEnemyDead)
		{
			SetClientCalculatingAI(enable: false);
			return;
		}
		if (!inSpecialAnimation)
		{
			SetClientCalculatingAI(enable: true);
		}
		if (movingTowardsTargetPlayer && (Object)(object)targetPlayer != (Object)null)
		{
			NavigateTowardsTargetPlayer();
		}
		if (inSpecialAnimation)
		{
			return;
		}
		if (updateDestinationInterval >= 0f)
		{
			updateDestinationInterval -= Time.deltaTime;
		}
		else
		{
			DoAIInterval();
			updateDestinationInterval = AIIntervalTime + Random.Range(-0.015f, 0.015f);
		}
		if (Mathf.Abs(previousYRotation - ((Component)this).transform.eulerAngles.y) > 6f)
		{
			previousYRotation = ((Component)this).transform.eulerAngles.y;
			targetYRotation = previousYRotation;
			if (((NetworkBehaviour)this).IsServer)
			{
				UpdateEnemyRotationClientRpc((short)previousYRotation);
			}
			else
			{
				UpdateEnemyRotationServerRpc((short)previousYRotation);
			}
		}
	}

	public virtual void NavigateTowardsTargetPlayer()
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		if (setDestinationToPlayerInterval <= 0f)
		{
			setDestinationToPlayerInterval = 0.25f;
			destination = RoundManager.Instance.GetNavMeshPosition(((Component)targetPlayer).transform.position, RoundManager.Instance.navHit, 2.7f);
		}
		else
		{
			destination = new Vector3(((Component)targetPlayer).transform.position.x, destination.y, ((Component)targetPlayer).transform.position.z);
			setDestinationToPlayerInterval -= Time.deltaTime;
		}
		if (addPlayerVelocityToDestination > 0f)
		{
			if ((Object)(object)targetPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				destination += Vector3.Normalize(targetPlayer.thisController.velocity * 100f) * addPlayerVelocityToDestination;
			}
			else if (targetPlayer.timeSincePlayerMoving < 0.25f)
			{
				destination += Vector3.Normalize((targetPlayer.serverPlayerPosition - targetPlayer.oldPlayerPosition) * 100f) * addPlayerVelocityToDestination;
			}
		}
	}

	public void KillEnemyOnOwnerClient(bool overrideDestroy = false)
	{
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		bool flag = enemyType.destroyOnDeath;
		if (overrideDestroy)
		{
			flag = true;
		}
		if ((!enemyType.canDie && !flag) || isEnemyDead)
		{
			return;
		}
		Debug.Log((object)$"Kill enemy called! destroy: {flag}");
		if (flag)
		{
			if (((NetworkBehaviour)this).IsServer)
			{
				Debug.Log((object)"Kill enemy called on server, destroy true");
				KillEnemy(destroy: true);
			}
			else
			{
				KillEnemyServerRpc(destroy: true);
			}
		}
		else
		{
			KillEnemy();
			if (((NetworkBehaviour)this).NetworkObject.IsSpawned)
			{
				KillEnemyServerRpc(destroy: false);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KillEnemyServerRpc(bool destroy)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1810146992u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref destroy, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1810146992u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			Debug.Log((object)$"Kill enemy server rpc called with destroy {destroy}");
			if (destroy)
			{
				KillEnemy(destroy);
			}
			else
			{
				KillEnemyClientRpc(destroy);
			}
		}
	}

	[ClientRpc]
	public void KillEnemyClientRpc(bool destroy)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1614111717u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref destroy, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1614111717u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			Debug.Log((object)$"Kill enemy client rpc called; {destroy}");
			if (!isEnemyDead)
			{
				KillEnemy(destroy);
			}
		}
	}

	public virtual void KillEnemy(bool destroy = false)
	{
		if (destroy && enemyType.canBeDestroyed)
		{
			Debug.Log((object)"Destroy enemy called");
			if (((NetworkBehaviour)this).IsServer)
			{
				Debug.Log((object)"Despawn network object in kill enemy called!");
				if (thisNetworkObject.IsSpawned)
				{
					thisNetworkObject.Despawn(true);
				}
			}
		}
		else
		{
			if (!enemyType.canDie)
			{
				return;
			}
			ScanNodeProperties componentInChildren = ((Component)this).gameObject.GetComponentInChildren<ScanNodeProperties>();
			if ((Object)(object)componentInChildren != (Object)null && Object.op_Implicit((Object)(object)((Component)componentInChildren).gameObject.GetComponent<Collider>()))
			{
				((Component)componentInChildren).gameObject.GetComponent<Collider>().enabled = false;
			}
			isEnemyDead = true;
			if ((Object)(object)creatureVoice != (Object)null)
			{
				creatureVoice.PlayOneShot(dieSFX);
				Debug.Log((object)("Playing death sound for enemy: " + enemyType.enemyName));
			}
			try
			{
				if ((Object)(object)creatureAnimator != (Object)null)
				{
					creatureAnimator.SetBool("Stunned", false);
					creatureAnimator.SetBool("stunned", false);
					creatureAnimator.SetBool("stun", false);
					creatureAnimator.SetTrigger("KillEnemy");
					creatureAnimator.SetBool("Dead", true);
				}
			}
			catch (Exception arg)
			{
				Debug.LogError((object)$"enemy did not have bool in animator in KillEnemy, error returned; {arg}");
			}
			CancelSpecialAnimationWithPlayer();
			SubtractFromPowerLevel();
			((Behaviour)agent).enabled = false;
		}
	}

	public virtual void CancelSpecialAnimationWithPlayer()
	{
		if (Object.op_Implicit((Object)(object)inSpecialAnimationWithPlayer))
		{
			inSpecialAnimationWithPlayer.inSpecialInteractAnimation = false;
			inSpecialAnimationWithPlayer.snapToServerPosition = false;
			inSpecialAnimationWithPlayer.inAnimationWithEnemy = null;
			inSpecialAnimationWithPlayer = null;
		}
		inSpecialAnimation = false;
	}

	public override void OnDestroy()
	{
		((NetworkBehaviour)this).OnDestroy();
		if (RoundManager.Instance.SpawnedEnemies.Contains(this))
		{
			RoundManager.Instance.SpawnedEnemies.Remove(this);
		}
		SubtractFromPowerLevel();
		CancelSpecialAnimationWithPlayer();
		if (searchCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(searchCoroutine);
		}
		if (chooseTargetNodeCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(chooseTargetNodeCoroutine);
		}
	}

	private void SubtractFromPowerLevel()
	{
		if (!removedPowerLevel)
		{
			removedPowerLevel = true;
			if (enemyType.isDaytimeEnemy)
			{
				RoundManager.Instance.currentDaytimeEnemyPower = Mathf.Max(RoundManager.Instance.currentDaytimeEnemyPower - enemyType.PowerLevel, 0f);
				return;
			}
			if (enemyType.isOutsideEnemy)
			{
				RoundManager.Instance.currentOutsideEnemyPower = Mathf.Max(RoundManager.Instance.currentOutsideEnemyPower - enemyType.PowerLevel, 0f);
				return;
			}
			RoundManager.Instance.cannotSpawnMoreInsideEnemies = false;
			RoundManager.Instance.currentEnemyPower = Mathf.Max(RoundManager.Instance.currentEnemyPower - enemyType.PowerLevel, 0f);
		}
	}

	[ServerRpc]
	private void UpdateEnemyRotationServerRpc(short rotationY)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3079913705u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, rotationY);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3079913705u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			UpdateEnemyRotationClientRpc(rotationY);
		}
	}

	[ClientRpc]
	private void UpdateEnemyRotationClientRpc(short rotationY)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1258118513u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, rotationY);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1258118513u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				previousYRotation = ((Component)this).transform.eulerAngles.y;
				targetYRotation = rotationY;
			}
		}
	}

	[ServerRpc]
	private void UpdateEnemyPositionServerRpc(Vector3 newPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(255411420u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPos);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 255411420u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			UpdateEnemyPositionClientRpc(newPos);
		}
	}

	[ClientRpc]
	private void UpdateEnemyPositionClientRpc(Vector3 newPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4287979896u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPos);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4287979896u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				serverPosition = newPos;
				OnSyncPositionFromServer(newPos);
			}
		}
	}

	public virtual void OnSyncPositionFromServer(Vector3 newPos)
	{
	}

	public virtual void OnDrawGizmos()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner && debugEnemyAI)
		{
			Gizmos.DrawSphere(destination, 0.5f);
			Gizmos.DrawLine(((Component)this).transform.position, destination);
		}
	}

	public void ChangeOwnershipOfEnemy(ulong newOwnerClientId)
	{
		if (StartOfRound.Instance.ClientPlayerList.TryGetValue(newOwnerClientId, out var value))
		{
			Debug.Log((object)$"Switching ownership of {((Object)enemyType).name} #{thisEnemyIndex} to player #{value} ({StartOfRound.Instance.allPlayerScripts[value].playerUsername})");
			if (currentOwnershipOnThisClient == value)
			{
				Debug.Log((object)$"unable to set owner of {((Object)enemyType).name} #{thisEnemyIndex} to player #{value}; reason B; {((NetworkBehaviour)this).NetworkObject.OwnerClientId}");
				return;
			}
			ulong ownerClientId = ((Component)this).gameObject.GetComponent<NetworkObject>().OwnerClientId;
			if (ownerClientId == newOwnerClientId)
			{
				Debug.Log((object)$"unable to set owner of {((Object)enemyType).name} #{thisEnemyIndex} to player #{value} with id {newOwnerClientId}; current ownerclientId: {ownerClientId}");
			}
			else
			{
				Debug.Log((object)$"{enemyType.enemyName}: setting ownership to {value} from currentownershiponclient {currentOwnershipOnThisClient}");
				currentOwnershipOnThisClient = value;
				if (!((NetworkBehaviour)this).IsServer)
				{
					ChangeEnemyOwnerServerRpc(newOwnerClientId);
					return;
				}
				thisNetworkObject.ChangeOwnership(newOwnerClientId);
				ChangeEnemyOwnerServerRpc(newOwnerClientId);
			}
		}
		else
		{
			Debug.LogError((object)$"Attempted to switch ownership of enemy {((Object)((Component)this).gameObject).name} to a player which does not have a link between client id and player object. Attempted clientId: {newOwnerClientId}");
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ChangeEnemyOwnerServerRpc(ulong clientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3587030867u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, clientId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3587030867u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (((Component)this).gameObject.GetComponent<NetworkObject>().OwnerClientId != clientId)
			{
				thisNetworkObject.ChangeOwnership(clientId);
			}
			if (StartOfRound.Instance.ClientPlayerList.TryGetValue(clientId, out var value))
			{
				currentOwnershipOnThisClient = value;
				ChangeEnemyOwnerClientRpc(value);
			}
		}
	}

	[ClientRpc]
	public void ChangeEnemyOwnerClientRpc(int playerVal)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(245785831u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerVal);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 245785831u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				currentOwnershipOnThisClient = playerVal;
			}
		}
	}

	public void SetClientCalculatingAI(bool enable)
	{
		isClientCalculatingAI = enable;
		((Behaviour)agent).enabled = enable;
	}

	public virtual void EnableEnemyMesh(bool enable, bool overrideDoNotSet = false)
	{
		int layer = ((!enable) ? 23 : 19);
		for (int i = 0; i < skinnedMeshRenderers.Length; i++)
		{
			if (!((Component)skinnedMeshRenderers[i]).CompareTag("DoNotSet") || overrideDoNotSet)
			{
				((Component)skinnedMeshRenderers[i]).gameObject.layer = layer;
			}
		}
		for (int j = 0; j < meshRenderers.Length; j++)
		{
			if (!((Component)meshRenderers[j]).CompareTag("DoNotSet") || overrideDoNotSet)
			{
				((Component)meshRenderers[j]).gameObject.layer = layer;
			}
		}
	}

	public virtual void SetEnemyOutside(bool outside = false)
	{
		isOutside = outside;
		if (outside)
		{
			allAINodes = GameObject.FindGameObjectsWithTag("OutsideAINode");
		}
		else
		{
			allAINodes = GameObject.FindGameObjectsWithTag("AINode");
		}
	}

	public virtual void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
	}

	public virtual void HitFromExplosion(float distance)
	{
		if (debugEnemyAI)
		{
			Debug.Log((object)$"{enemyType.enemyName} #{thisEnemyIndex} hit by explosion");
		}
	}

	public void HitEnemyOnLocalClient(int force = 1, Vector3 hitDirection = default(Vector3), PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		Debug.Log((object)$"Local client hit enemy {((Object)((Component)agent).transform).name} #{thisEnemyIndex} with force of {force}.");
		int playerWhoHit2 = -1;
		if ((Object)(object)playerWhoHit != (Object)null)
		{
			playerWhoHit2 = (int)playerWhoHit.playerClientId;
			HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		}
		HitEnemyServerRpc(force, playerWhoHit2, playHitSFX, hitID);
	}

	[ServerRpc(RequireOwnership = false)]
	public void HitEnemyServerRpc(int force, int playerWhoHit, bool playHitSFX, int hitID = -1)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3538577804u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, force);
				BytePacker.WriteValueBitPacked(val2, playerWhoHit);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref playHitSFX, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, hitID);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3538577804u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				HitEnemyClientRpc(force, playerWhoHit, playHitSFX, hitID);
			}
		}
	}

	[ClientRpc]
	public void HitEnemyClientRpc(int force, int playerWhoHit, bool playHitSFX, int hitID = -1)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(601871377u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, force);
			BytePacker.WriteValueBitPacked(val2, playerWhoHit);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref playHitSFX, default(ForPrimitives));
			BytePacker.WriteValueBitPacked(val2, hitID);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 601871377u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerWhoHit != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
		{
			if (playerWhoHit == -1)
			{
				HitEnemy(force, null, playHitSFX, hitID);
			}
			else
			{
				HitEnemy(force, StartOfRound.Instance.allPlayerScripts[playerWhoHit], playHitSFX, hitID);
			}
		}
	}

	public virtual void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		if (playHitSFX && (Object)(object)enemyType.hitBodySFX != (Object)null && !isEnemyDead)
		{
			creatureSFX.PlayOneShot(enemyType.hitBodySFX);
			WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.hitBodySFX);
		}
		if ((Object)(object)creatureVoice != (Object)null)
		{
			creatureVoice.PlayOneShot(enemyType.hitEnemyVoiceSFX);
		}
		if (debugEnemyAI)
		{
			Debug.Log((object)$"Enemy #{thisEnemyIndex} was hit with force of {force}");
		}
		if ((Object)(object)playerWhoHit != (Object)null)
		{
			Debug.Log((object)$"Client #{playerWhoHit.playerClientId} hit enemy {((Object)((Component)agent).transform).name} with force of {force}.");
		}
	}

	public virtual void ReceiveLoudNoiseBlast(Vector3 position, float angle)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(position, ((Component)this).transform.position);
		if (num < 60f)
		{
			float num2 = 0f;
			if (angle < 35f)
			{
				num2 = ((!(num < 25f)) ? 0.7f : 1f);
				DetectNoise(position, num2, 0, 41888);
			}
			else if (angle < 16f)
			{
				num2 = 1f;
				DetectNoise(position, num2, 0, 41888);
			}
		}
	}

	private void CheckTimeOfDayToLeave()
	{
		if (!((Object)(object)TimeOfDay.Instance == (Object)null) && TimeOfDay.Instance.timeHasStarted && TimeOfDay.Instance.normalizedTimeOfDay > enemyType.normalizedTimeInDayToLeave && isOutside)
		{
			daytimeEnemyLeaving = true;
			DaytimeEnemyLeave();
		}
	}

	public virtual void DaytimeEnemyLeave()
	{
		if (debugEnemyAI)
		{
			Debug.Log((object)(((Object)((Component)this).gameObject).name + ": Daytime enemy leave function called"));
		}
	}

	public void LogEnemyError(string error)
	{
		Debug.LogError((object)$"{((Object)enemyType).name} #{thisEnemyIndex}: {error}");
	}

	public virtual void AnimationEventA()
	{
	}

	public virtual void AnimationEventB()
	{
	}

	public virtual void AnimationEventC()
	{
	}

	public virtual void AnimationEventD()
	{
	}

	public virtual void ShipTeleportEnemy()
	{
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_EnemyAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2081148948u, new RpcReceiveHandler(__rpc_handler_2081148948));
		NetworkManager.__rpc_func_table.Add(2962895088u, new RpcReceiveHandler(__rpc_handler_2962895088));
		NetworkManager.__rpc_func_table.Add(1810146992u, new RpcReceiveHandler(__rpc_handler_1810146992));
		NetworkManager.__rpc_func_table.Add(1614111717u, new RpcReceiveHandler(__rpc_handler_1614111717));
		NetworkManager.__rpc_func_table.Add(3079913705u, new RpcReceiveHandler(__rpc_handler_3079913705));
		NetworkManager.__rpc_func_table.Add(1258118513u, new RpcReceiveHandler(__rpc_handler_1258118513));
		NetworkManager.__rpc_func_table.Add(255411420u, new RpcReceiveHandler(__rpc_handler_255411420));
		NetworkManager.__rpc_func_table.Add(4287979896u, new RpcReceiveHandler(__rpc_handler_4287979896));
		NetworkManager.__rpc_func_table.Add(3587030867u, new RpcReceiveHandler(__rpc_handler_3587030867));
		NetworkManager.__rpc_func_table.Add(245785831u, new RpcReceiveHandler(__rpc_handler_245785831));
		NetworkManager.__rpc_func_table.Add(3538577804u, new RpcReceiveHandler(__rpc_handler_3538577804));
		NetworkManager.__rpc_func_table.Add(601871377u, new RpcReceiveHandler(__rpc_handler_601871377));
	}

	private static void __rpc_handler_2081148948(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int stateIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref stateIndex);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((EnemyAI)(object)target).SwitchToBehaviourServerRpc(stateIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2962895088(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int stateIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref stateIndex);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EnemyAI)(object)target).SwitchToBehaviourClientRpc(stateIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1810146992(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool destroy = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref destroy, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((EnemyAI)(object)target).KillEnemyServerRpc(destroy);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1614111717(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool destroy = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref destroy, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EnemyAI)(object)target).KillEnemyClientRpc(destroy);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3079913705(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			short rotationY = default(short);
			ByteUnpacker.ReadValueBitPacked(reader, ref rotationY);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((EnemyAI)(object)target).UpdateEnemyRotationServerRpc(rotationY);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1258118513(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			short rotationY = default(short);
			ByteUnpacker.ReadValueBitPacked(reader, ref rotationY);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EnemyAI)(object)target).UpdateEnemyRotationClientRpc(rotationY);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_255411420(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 newPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newPos);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((EnemyAI)(object)target).UpdateEnemyPositionServerRpc(newPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4287979896(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newPos);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EnemyAI)(object)target).UpdateEnemyPositionClientRpc(newPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3587030867(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong clientId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((EnemyAI)(object)target).ChangeEnemyOwnerServerRpc(clientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_245785831(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerVal = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerVal);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EnemyAI)(object)target).ChangeEnemyOwnerClientRpc(playerVal);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3538577804(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int force = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref force);
			int playerWhoHit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoHit);
			bool playHitSFX = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref playHitSFX, default(ForPrimitives));
			int hitID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref hitID);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((EnemyAI)(object)target).HitEnemyServerRpc(force, playerWhoHit, playHitSFX, hitID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_601871377(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int force = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref force);
			int playerWhoHit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoHit);
			bool playHitSFX = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref playHitSFX, default(ForPrimitives));
			int hitID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref hitID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EnemyAI)(object)target).HitEnemyClientRpc(force, playerWhoHit, playHitSFX, hitID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "EnemyAI";
	}
}
