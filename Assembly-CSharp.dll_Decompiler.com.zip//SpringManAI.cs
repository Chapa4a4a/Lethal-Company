using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class SpringManAI : EnemyAI
{
	public AISearchRoutine searchForPlayers;

	private float checkLineOfSightInterval;

	private bool hasEnteredChaseMode;

	private bool stoppingMovement;

	private bool hasStopped;

	public AnimationStopPoints animStopPoints;

	private float currentChaseSpeed = 14.5f;

	private float currentAnimSpeed = 1f;

	private PlayerControllerB previousTarget;

	private bool wasOwnerLastFrame;

	private float stopAndGoMinimumInterval;

	private float hitPlayerTimer;

	public AudioClip[] springNoises;

	public AudioClip enterCooldownSFX;

	public Collider mainCollider;

	private float loseAggroTimer;

	private float timeSinceHittingPlayer;

	private bool movingOnOffMeshLink;

	private Coroutine offMeshLinkCoroutine;

	private float stopMovementTimer;

	public float timeSpentMoving;

	public float onCooldownPhase;

	private bool setOnCooldown;

	public float timeAtLastCooldown;

	private bool inCooldownAnimation;

	private Vector3 previousPosition;

	private float checkPositionInterval;

	private bool isMakingDistance;

	[ServerRpc(RequireOwnership = false)]
	public void SetCoilheadOnCooldownServerRpc(bool setTrue)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1507778120u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setTrue, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1507778120u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetCoilheadOnCooldownClientRpc(setTrue);
			}
		}
	}

	[ClientRpc]
	public void SetCoilheadOnCooldownClientRpc(bool setTrue)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1116073473u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setTrue, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1116073473u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			timeSpentMoving = 0f;
			if (setTrue)
			{
				onCooldownPhase = 20f;
				setOnCooldown = true;
				inCooldownAnimation = true;
				SwitchToBehaviourStateOnLocalClient(0);
				creatureVoice.PlayOneShot(enterCooldownSFX);
			}
			else
			{
				onCooldownPhase = 0f;
				setOnCooldown = false;
				timeAtLastCooldown = Time.realtimeSinceStartup;
			}
		}
	}

	public bool PlayerHasHorizontalLOS(PlayerControllerB player)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((Component)this).transform.position - ((Component)player).transform.position;
		val.y = 0f;
		return Vector3.Angle(((Component)player).transform.forward, val) < 68f;
	}

	public override void DoAIInterval()
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_0409: Unknown result type (might be due to invalid IL or missing references)
		//IL_0413: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		//IL_031f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.allPlayersDead || isEnemyDead)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			if (!((NetworkBehaviour)this).IsServer)
			{
				ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
				break;
			}
			if (onCooldownPhase > 0f)
			{
				agent.speed = 0f;
				SetDestinationToPosition(((Component)this).transform.position);
				onCooldownPhase -= AIIntervalTime;
				break;
			}
			if (setOnCooldown)
			{
				setOnCooldown = false;
				SetCoilheadOnCooldownClientRpc(setTrue: false);
			}
			loseAggroTimer = 0f;
			for (int j = 0; j < StartOfRound.Instance.allPlayerScripts.Length; j++)
			{
				if (PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[j]))
				{
					if ((StartOfRound.Instance.allPlayerScripts[j].HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.25f, 68f) || StartOfRound.Instance.allPlayerScripts[j].HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 1.6f, 68f)) && PlayerHasHorizontalLOS(StartOfRound.Instance.allPlayerScripts[j]))
					{
						targetPlayer = StartOfRound.Instance.allPlayerScripts[j];
						SwitchToBehaviourState(1);
					}
					if (!PathIsIntersectedByLineOfSight(((Component)StartOfRound.Instance.allPlayerScripts[j]).transform.position, calculatePathDistance: false, avoidLineOfSight: false) && !Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.5f, ((Component)StartOfRound.Instance.allPlayerScripts[j].gameplayCamera).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault) && Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[j]).transform.position) < 30f)
					{
						SwitchToBehaviourState(1);
						return;
					}
				}
			}
			agent.speed = 6f;
			if (!searchForPlayers.inProgress)
			{
				movingTowardsTargetPlayer = false;
				SetDestinationToPosition(((Component)this).transform.position);
				StartSearch(((Component)this).transform.position, searchForPlayers);
			}
			break;
		}
		case 1:
		{
			if (searchForPlayers.inProgress)
			{
				StopSearch(searchForPlayers);
			}
			if (TargetClosestPlayer())
			{
				if ((Object)(object)previousTarget != (Object)(object)targetPlayer)
				{
					previousTarget = targetPlayer;
					ChangeOwnershipOfEnemy(targetPlayer.actualClientId);
				}
				if (!(Time.realtimeSinceStartup - timeSinceHittingPlayer > 7f) || stoppingMovement)
				{
					break;
				}
				if (Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position) > 40f && !CheckLineOfSightForPosition(((Component)targetPlayer.gameplayCamera).transform.position, 180f, 140))
				{
					loseAggroTimer += AIIntervalTime;
					if (loseAggroTimer > 4.5f)
					{
						SwitchToBehaviourState(0);
						ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
					}
				}
				else
				{
					loseAggroTimer = 0f;
				}
				break;
			}
			bool flag = false;
			for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
			{
				if ((StartOfRound.Instance.allPlayerScripts[i].HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.6f, 68f) || StartOfRound.Instance.allPlayerScripts[i].HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 3f, 68f)) && PlayerHasHorizontalLOS(StartOfRound.Instance.allPlayerScripts[i]))
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				loseAggroTimer += AIIntervalTime;
				if (loseAggroTimer > 1f)
				{
					SwitchToBehaviourState(0);
					ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
				}
			}
			break;
		}
		}
	}

	private IEnumerator Parabola(NavMeshAgent agent, float height, float duration)
	{
		OffMeshLinkData data = agent.currentOffMeshLinkData;
		Vector3 startPos = ((Component)agent).transform.position;
		Vector3 endPos = ((OffMeshLinkData)(ref data)).endPos + Vector3.up * agent.baseOffset;
		float normalizedTime = 0f;
		Debug.Log((object)$"Beginning off mesh link movement. {((OffMeshLinkData)(ref data)).valid}; {((OffMeshLinkData)(ref data)).activated}; {((NetworkBehaviour)this).IsOwner}");
		while (normalizedTime < 1f && ((OffMeshLinkData)(ref data)).valid && ((OffMeshLinkData)(ref data)).activated && ((NetworkBehaviour)this).IsOwner)
		{
			float num = height * 4f * (normalizedTime - normalizedTime * normalizedTime);
			Debug.Log((object)$"Moving on off mesh link; time: {normalizedTime}; y: {num}");
			((Component)agent).transform.position = Vector3.Lerp(startPos, endPos, normalizedTime) + num * Vector3.up;
			normalizedTime += Time.deltaTime / duration;
			yield return null;
		}
		agent.CompleteOffMeshLink();
		Debug.Log((object)$"Completed off mesh link without interruption, position: {((Component)this).transform.position}");
		offMeshLinkCoroutine = null;
	}

	private void StopOffMeshLinkMovement()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		if (offMeshLinkCoroutine == null)
		{
			return;
		}
		((MonoBehaviour)this).StopCoroutine(offMeshLinkCoroutine);
		offMeshLinkCoroutine = null;
		OffMeshLinkData currentOffMeshLinkData = agent.currentOffMeshLinkData;
		agent.CompleteOffMeshLink();
		if (((OffMeshLinkData)(ref currentOffMeshLinkData)).valid)
		{
			Debug.Log((object)$"Completed off mesh EARLY link due to an interruption; position: {((Component)this).transform.position}");
			if (Vector3.Distance(((Component)this).transform.position, ((OffMeshLinkData)(ref currentOffMeshLinkData)).startPos) < Vector3.Distance(((Component)this).transform.position, ((OffMeshLinkData)(ref currentOffMeshLinkData)).endPos))
			{
				Debug.Log((object)$"Warping agent to start position at {((OffMeshLinkData)(ref currentOffMeshLinkData)).startPos}");
				agent.Warp(((OffMeshLinkData)(ref currentOffMeshLinkData)).startPos);
			}
			else
			{
				Debug.Log((object)$"Warping agent to end position at {((OffMeshLinkData)(ref currentOffMeshLinkData)).endPos}");
				agent.Warp(((OffMeshLinkData)(ref currentOffMeshLinkData)).endPos);
			}
		}
		else
		{
			Debug.Log((object)"Off mesh link data invalid; agent completing off mesh link anyway");
		}
	}

	private void DoSpringAnimation(bool springPopUp = false)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.6f, 70f, 25))
		{
			float num = Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position);
			if (num < 4f)
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.9f);
			}
			else if (num < 9f)
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.4f);
			}
		}
		if (currentAnimSpeed > 2f || springPopUp)
		{
			RoundManager.PlayRandomClip(creatureVoice, springNoises, randomize: false);
			if (animStopPoints.animationPosition == 1)
			{
				creatureAnimator.SetTrigger("springBoing");
			}
			else
			{
				creatureAnimator.SetTrigger("springBoingPosition2");
			}
		}
	}

	public override void Update()
	{
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0500: Unknown result type (might be due to invalid IL or missing references)
		//IL_051d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_0388: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0440: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead)
		{
			return;
		}
		if (hitPlayerTimer >= 0f)
		{
			hitPlayerTimer -= Time.deltaTime;
		}
		if (!((NetworkBehaviour)this).IsOwner)
		{
			stopMovementTimer = 5f;
			loseAggroTimer = 0f;
			if (offMeshLinkCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(offMeshLinkCoroutine);
			}
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (agent.isOnOffMeshLink)
			{
				if (!stoppingMovement)
				{
					OffMeshLinkData currentOffMeshLinkData = agent.currentOffMeshLinkData;
					if (((OffMeshLinkData)(ref currentOffMeshLinkData)).activated)
					{
						if (offMeshLinkCoroutine == null)
						{
							offMeshLinkCoroutine = ((MonoBehaviour)this).StartCoroutine(Parabola(agent, 0.6f, 0.5f));
						}
						goto IL_00d4;
					}
				}
				StopOffMeshLinkMovement();
			}
			else if (offMeshLinkCoroutine != null)
			{
				StopOffMeshLinkMovement();
			}
		}
		goto IL_00d4;
		IL_00d4:
		creatureAnimator.SetBool("OnCooldown", setOnCooldown);
		if (setOnCooldown)
		{
			mainCollider.isTrigger = true;
			stoppingMovement = true;
			hasStopped = true;
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			agent.autoTraverseOffMeshLink = false;
			creatureAnimator.SetFloat("walkSpeed", 4.7f);
			stoppingMovement = false;
			hasStopped = false;
			break;
		case 1:
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				if (onCooldownPhase > 0f)
				{
					SwitchToBehaviourState(0);
					break;
				}
				if (stopAndGoMinimumInterval > 0f)
				{
					stopAndGoMinimumInterval -= Time.deltaTime;
				}
				if (!wasOwnerLastFrame)
				{
					wasOwnerLastFrame = true;
					if (!stoppingMovement && hitPlayerTimer < 0.12f)
					{
						agent.speed = currentChaseSpeed;
					}
					else
					{
						agent.speed = 0f;
					}
				}
				bool flag = false;
				for (int i = 0; i < 4; i++)
				{
					if (PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[i]) && (StartOfRound.Instance.allPlayerScripts[i].HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.6f, 68f) || StartOfRound.Instance.allPlayerScripts[i].HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 3f, 68f)) && PlayerHasHorizontalLOS(StartOfRound.Instance.allPlayerScripts[i]) && Vector3.Distance(((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position, eye.position) > 0.3f)
					{
						flag = true;
					}
				}
				if (stunNormalizedTimer > 0f)
				{
					flag = true;
				}
				if (flag != stoppingMovement && stopAndGoMinimumInterval <= 0f)
				{
					stopAndGoMinimumInterval = 0.15f;
					if (flag)
					{
						SetAnimationStopServerRpc();
					}
					else
					{
						SetAnimationGoServerRpc();
					}
					stoppingMovement = flag;
				}
			}
			float num = 0f;
			if (stoppingMovement)
			{
				if (animStopPoints.canAnimationStop || stopMovementTimer > 0.27f)
				{
					if (!hasStopped)
					{
						hasStopped = true;
						DoSpringAnimation();
					}
					else if (inCooldownAnimation)
					{
						inCooldownAnimation = false;
						DoSpringAnimation(springPopUp: true);
					}
					if ((Object)(object)RoundManager.Instance.currentMineshaftElevator != (Object)null && Vector3.Distance(((Component)this).transform.position, RoundManager.Instance.currentMineshaftElevator.elevatorInsidePoint.position) < 1f)
					{
						num = 0.5f;
					}
					if (mainCollider.isTrigger && Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position) > 0.3f)
					{
						mainCollider.isTrigger = false;
					}
					creatureAnimator.SetFloat("walkSpeed", 0f);
					currentAnimSpeed = 0f;
					if (((NetworkBehaviour)this).IsOwner)
					{
						agent.speed = 0f;
						movingTowardsTargetPlayer = false;
						SetDestinationToPosition(((Component)this).transform.position);
					}
				}
				else
				{
					stopMovementTimer += Time.deltaTime;
				}
			}
			else
			{
				stopMovementTimer = 0f;
				if (hasStopped)
				{
					hasStopped = false;
					mainCollider.isTrigger = true;
					isMakingDistance = true;
				}
				currentAnimSpeed = Mathf.Lerp(currentAnimSpeed, 6f, 5f * Time.deltaTime);
				creatureAnimator.SetFloat("walkSpeed", currentAnimSpeed);
				inCooldownAnimation = false;
				if (((NetworkBehaviour)this).IsServer)
				{
					if (checkPositionInterval <= 0f)
					{
						checkPositionInterval = 0.65f;
						isMakingDistance = Vector3.Distance(((Component)this).transform.position, previousPosition) > 0.5f;
						previousPosition = ((Component)this).transform.position;
					}
					else
					{
						checkPositionInterval -= Time.deltaTime;
					}
					num = ((!isMakingDistance) ? 0.2f : 1f);
				}
				if (((NetworkBehaviour)this).IsOwner)
				{
					agent.speed = Mathf.Lerp(agent.speed, currentChaseSpeed, 4.5f * Time.deltaTime);
					movingTowardsTargetPlayer = true;
				}
			}
			if (((NetworkBehaviour)this).IsServer)
			{
				if (num > 0f)
				{
					timeSpentMoving += Time.deltaTime * num;
				}
				if (timeSpentMoving > 9f)
				{
					onCooldownPhase = 11f;
					setOnCooldown = true;
					inCooldownAnimation = true;
					SetCoilheadOnCooldownClientRpc(setTrue: true);
					SwitchToBehaviourStateOnLocalClient(0);
				}
			}
			break;
		}
		}
	}

	[ServerRpc]
	public void SetAnimationStopServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1502362896u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1502362896u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetAnimationStopClientRpc();
		}
	}

	[ClientRpc]
	public void SetAnimationStopClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(718630829u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 718630829u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				stoppingMovement = true;
			}
		}
	}

	[ServerRpc]
	public void SetAnimationGoServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(339140592u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 339140592u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetAnimationGoClientRpc();
		}
	}

	[ClientRpc]
	public void SetAnimationGoClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3626523253u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3626523253u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				stoppingMovement = false;
			}
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (!stoppingMovement && currentBehaviourStateIndex == 1 && !(hitPlayerTimer >= 0f) && !setOnCooldown && !((double)(Time.realtimeSinceStartup - timeAtLastCooldown) < 0.45))
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				hitPlayerTimer = 0.2f;
				playerControllerB.DamagePlayer(90, hasDamageSFX: true, callRPC: true, CauseOfDeath.Mauling, 2);
				playerControllerB.JumpToFearLevel(1f);
				timeSinceHittingPlayer = Time.realtimeSinceStartup;
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_SpringManAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1507778120u, new RpcReceiveHandler(__rpc_handler_1507778120));
		NetworkManager.__rpc_func_table.Add(1116073473u, new RpcReceiveHandler(__rpc_handler_1116073473));
		NetworkManager.__rpc_func_table.Add(1502362896u, new RpcReceiveHandler(__rpc_handler_1502362896));
		NetworkManager.__rpc_func_table.Add(718630829u, new RpcReceiveHandler(__rpc_handler_718630829));
		NetworkManager.__rpc_func_table.Add(339140592u, new RpcReceiveHandler(__rpc_handler_339140592));
		NetworkManager.__rpc_func_table.Add(3626523253u, new RpcReceiveHandler(__rpc_handler_3626523253));
	}

	private static void __rpc_handler_1507778120(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool coilheadOnCooldownServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref coilheadOnCooldownServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SpringManAI)(object)target).SetCoilheadOnCooldownServerRpc(coilheadOnCooldownServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1116073473(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool coilheadOnCooldownClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref coilheadOnCooldownClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SpringManAI)(object)target).SetCoilheadOnCooldownClientRpc(coilheadOnCooldownClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1502362896(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SpringManAI)(object)target).SetAnimationStopServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_718630829(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SpringManAI)(object)target).SetAnimationStopClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_339140592(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SpringManAI)(object)target).SetAnimationGoServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3626523253(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SpringManAI)(object)target).SetAnimationGoClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "SpringManAI";
	}
}
