using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class LassoManAI : EnemyAI
{
	public AISearchRoutine searchForPlayers;

	private float checkLineOfSightInterval;

	public float maxSearchAndRoamRadius = 100f;

	[Space(5f)]
	public float noticePlayerTimer;

	private bool hasEnteredChaseMode;

	private bool lostPlayerInChase;

	private bool beginningChasingThisClient;

	private float timeSinceHittingPlayer;

	public DeadBodyInfo currentlyHeldBody;

	public override void Start()
	{
		base.Start();
		searchForPlayers.searchWidth = maxSearchAndRoamRadius;
	}

	public override void DoAIInterval()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.livingPlayers == 0 || isEnemyDead)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (!searchForPlayers.inProgress)
			{
				StartSearch(((Component)this).transform.position, searchForPlayers);
				Debug.Log((object)$"Crawler: Started new search; is searching?: {searchForPlayers.inProgress}");
			}
			break;
		case 1:
			if (lostPlayerInChase)
			{
				if (!searchForPlayers.inProgress)
				{
					searchForPlayers.searchWidth = 30f;
					StartSearch(((Component)targetPlayer).transform.position, searchForPlayers);
					Debug.Log((object)"Crawler: Lost player in chase; beginning search where the player was last seen");
				}
			}
			else if (searchForPlayers.inProgress)
			{
				StopSearch(searchForPlayers);
				movingTowardsTargetPlayer = true;
				Debug.Log((object)"Crawler: Found player during chase; stopping search coroutine and moving after target player");
			}
			break;
		}
	}

	public override void FinishedCurrentSearchRoutine()
	{
		base.FinishedCurrentSearchRoutine();
		searchForPlayers.searchWidth = Mathf.Clamp(searchForPlayers.searchWidth + 20f, 1f, maxSearchAndRoamRadius);
	}

	public override void Update()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead)
		{
			return;
		}
		if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position, 60f, 8, 5f))
		{
			if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position) < 7f)
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(1f);
			}
			else
			{
				GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(0.5f, 0.6f);
			}
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			if (hasEnteredChaseMode)
			{
				hasEnteredChaseMode = false;
				beginningChasingThisClient = false;
				noticePlayerTimer = 0f;
				useSecondaryAudiosOnAnimatedObjects = false;
				openDoorSpeedMultiplier = 0.6f;
				agent.speed = 5f;
			}
			if (checkLineOfSightInterval <= 0.05f)
			{
				checkLineOfSightInterval += Time.deltaTime;
				break;
			}
			checkLineOfSightInterval = 0f;
			PlayerControllerB playerControllerB2;
			if ((Object)(object)stunnedByPlayer != (Object)null)
			{
				playerControllerB2 = stunnedByPlayer;
				noticePlayerTimer = 1f;
			}
			else
			{
				playerControllerB2 = CheckLineOfSightForPlayer(55f);
			}
			if ((Object)(object)playerControllerB2 == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				Debug.Log((object)$"Seeing player; {noticePlayerTimer}");
				noticePlayerTimer = Mathf.Clamp(noticePlayerTimer + 0.05f, 0f, 10f);
				if (noticePlayerTimer > 0.1f && !beginningChasingThisClient)
				{
					beginningChasingThisClient = true;
					BeginChasingPlayerServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
					Debug.Log((object)"Begin chasing local client");
				}
			}
			else
			{
				noticePlayerTimer -= Time.deltaTime;
			}
			break;
		}
		case 1:
		{
			if (!hasEnteredChaseMode)
			{
				hasEnteredChaseMode = true;
				lostPlayerInChase = false;
				checkLineOfSightInterval = 0f;
				noticePlayerTimer = 0f;
				beginningChasingThisClient = false;
				useSecondaryAudiosOnAnimatedObjects = true;
				openDoorSpeedMultiplier = 1.5f;
				agent.speed = 6f;
			}
			if (!((NetworkBehaviour)this).IsOwner || stunNormalizedTimer > 0f)
			{
				break;
			}
			if (checkLineOfSightInterval <= 0.075f)
			{
				checkLineOfSightInterval += Time.deltaTime;
				break;
			}
			checkLineOfSightInterval = 0f;
			if (lostPlayerInChase)
			{
				if (Object.op_Implicit((Object)(object)CheckLineOfSightForPlayer(55f)))
				{
					noticePlayerTimer = 0f;
					lostPlayerInChase = false;
					MakeScreechNoiseServerRpc();
					break;
				}
				noticePlayerTimer -= 0.075f;
				if (noticePlayerTimer < -15f)
				{
					SwitchToBehaviourState(0);
				}
				break;
			}
			PlayerControllerB playerControllerB = CheckLineOfSightForPlayer(55f);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				Debug.Log((object)"Seeing player!!!!");
				noticePlayerTimer = 0f;
				if ((Object)(object)playerControllerB != (Object)(object)targetPlayer)
				{
					targetPlayer = playerControllerB;
				}
			}
			else
			{
				noticePlayerTimer += 0.075f;
				if (noticePlayerTimer > 2.5f)
				{
					lostPlayerInChase = true;
				}
			}
			break;
		}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void BeginChasingPlayerServerRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1325919844u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1325919844u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				BeginChasingPlayerClientRpc(playerObjectId);
			}
		}
	}

	[ClientRpc]
	public void BeginChasingPlayerClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1984359406u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1984359406u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SwitchToBehaviourStateOnLocalClient(1);
				SetMovingTowardsTargetPlayer(StartOfRound.Instance.allPlayerScripts[playerObjectId]);
			}
		}
	}

	[ServerRpc]
	public void MakeScreechNoiseServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3259100395u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3259100395u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			MakeScreechNoiseClientRpc();
		}
	}

	[ClientRpc]
	public void MakeScreechNoiseClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(668114799u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 668114799u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && !networkManager.IsClient && networkManager.IsHost)
			{
			}
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
		if (!isEnemyDead && (Object)(object)component != (Object)null && (Object)(object)component == (Object)(object)GameNetworkManager.Instance.localPlayerController && (Object)(object)component.inAnimationWithEnemy == (Object)null && !component.isPlayerDead && timeSinceHittingPlayer > 0.5f)
		{
			timeSinceHittingPlayer = 0f;
			component.DamagePlayer(40, hasDamageSFX: true, callRPC: true, CauseOfDeath.Strangulation);
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		base.KillEnemy();
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (!isEnemyDead)
		{
			creatureAnimator.SetTrigger("HurtEnemy");
			enemyHP--;
			if (enemyHP <= 0 && ((NetworkBehaviour)this).IsOwner)
			{
				KillEnemyOnOwnerClient();
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_LassoManAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1325919844u, new RpcReceiveHandler(__rpc_handler_1325919844));
		NetworkManager.__rpc_func_table.Add(1984359406u, new RpcReceiveHandler(__rpc_handler_1984359406));
		NetworkManager.__rpc_func_table.Add(3259100395u, new RpcReceiveHandler(__rpc_handler_3259100395));
		NetworkManager.__rpc_func_table.Add(668114799u, new RpcReceiveHandler(__rpc_handler_668114799));
	}

	private static void __rpc_handler_1325919844(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((LassoManAI)(object)target).BeginChasingPlayerServerRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1984359406(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((LassoManAI)(object)target).BeginChasingPlayerClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3259100395(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((LassoManAI)(object)target).MakeScreechNoiseServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_668114799(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((LassoManAI)(object)target).MakeScreechNoiseClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "LassoManAI";
	}
}
