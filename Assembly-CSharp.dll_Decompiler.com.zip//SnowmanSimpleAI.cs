using System;
using Unity.Netcode;
using UnityEngine;

public class SnowmanSimpleAI : MonoBehaviour
{
	private bool snowmanTurns;

	private float snowmanInterval;

	private void Start()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)RoundManager.Instance).IsServer)
		{
			Random random = new Random(StartOfRound.Instance.randomMapSeed + (int)((Component)this).transform.position.x);
			snowmanInterval = Random.Range(0f, 7f);
			if (random.Next(0, 100) < 30)
			{
				snowmanTurns = true;
			}
		}
	}

	private void Update()
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		if (!snowmanTurns || !((NetworkBehaviour)RoundManager.Instance).IsServer || !(Time.realtimeSinceStartup - snowmanInterval > 8f))
		{
			return;
		}
		snowmanInterval = Time.realtimeSinceStartup;
		bool flag = true;
		int num = -1;
		float num2 = 1000f;
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled && !StartOfRound.Instance.allPlayerScripts[i].isInsideFactory)
			{
				float num3 = Vector3.Distance(((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position, ((Component)this).transform.position);
				if (num3 < num2)
				{
					num = i;
					num2 = num3;
				}
				if (StartOfRound.Instance.allPlayerScripts[i].HasLineOfSightToPosition(((Component)this).transform.position, 90f, 200, 2f))
				{
					flag = false;
					break;
				}
			}
		}
		if (flag)
		{
			if (num != -1 && (StartOfRound.Instance.livingPlayers != 1 || Random.Range(0, 100) <= 14) && Random.Range(0, 100) <= 27)
			{
				RoundManager.Instance.tempTransform.position = ((Component)this).transform.parent.position;
				RoundManager.Instance.tempTransform.LookAt(((Component)StartOfRound.Instance.allPlayerScripts[num]).transform.position);
				float num4 = Vector3.Angle(RoundManager.Instance.tempTransform.eulerAngles, ((Component)this).transform.parent.eulerAngles);
				Vector3 eulerAngles = RoundManager.Instance.tempTransform.eulerAngles;
				eulerAngles.x = 0f;
				eulerAngles.z = 0f;
				bool laugh = num4 > 30f && (Random.Range(0, 100) < 50 || num2 < 8f);
				RoundManager.Instance.TurnSnowmanServerRpc(((Component)this).transform.parent.position, eulerAngles, laugh);
			}
		}
		else if (num != -1 && num2 > 50f)
		{
			RoundManager.Instance.tempTransform.position = ((Component)this).transform.parent.position;
			RoundManager.Instance.tempTransform.LookAt(((Component)StartOfRound.Instance.allPlayerScripts[num]).transform.position);
			if (!(Vector3.Angle(RoundManager.Instance.tempTransform.eulerAngles, ((Component)this).transform.parent.eulerAngles) < 10f))
			{
				Vector3 eulerAngles2 = RoundManager.Instance.tempTransform.eulerAngles;
				eulerAngles2.x = 0f;
				eulerAngles2.z = 0f;
				bool laugh2 = false;
				RoundManager.Instance.TurnSnowmanServerRpc(((Component)this).transform.parent.position, eulerAngles2, laugh2);
			}
		}
	}
}
