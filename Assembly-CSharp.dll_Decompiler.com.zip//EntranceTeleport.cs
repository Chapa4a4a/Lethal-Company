using System.Collections;
using Unity.Netcode;
using UnityEngine;

public class EntranceTeleport : NetworkBehaviour
{
	public bool isEntranceToBuilding;

	public Transform entrancePoint;

	public Transform exitPoint;

	public int entranceId;

	public StartOfRound playersManager;

	public int audioReverbPreset = -1;

	public AudioSource entrancePointAudio;

	private AudioSource exitPointAudio;

	public AudioClip[] doorAudios;

	private InteractTrigger triggerScript;

	private float checkForEnemiesInterval;

	private bool enemyNearLastCheck;

	private bool gotExitPoint;

	private bool checkedForFirstTime;

	public float timeAtLastUse;

	private void Awake()
	{
		playersManager = Object.FindObjectOfType<StartOfRound>();
		triggerScript = ((Component)this).gameObject.GetComponent<InteractTrigger>();
		checkForEnemiesInterval = 10f;
	}

	public bool FindExitPoint()
	{
		EntranceTeleport[] array = Object.FindObjectsOfType<EntranceTeleport>();
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].isEntranceToBuilding != isEntranceToBuilding && array[i].entranceId == entranceId)
			{
				if ((Object)(object)array[i].entrancePointAudio != (Object)null)
				{
					exitPointAudio = array[i].entrancePointAudio;
				}
				exitPoint = array[i].entrancePoint;
			}
		}
		if ((Object)(object)exitPoint == (Object)null)
		{
			return false;
		}
		return true;
	}

	public void TeleportPlayer()
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		if (!FindExitPoint())
		{
			flag = true;
		}
		if (flag)
		{
			HUDManager.Instance.DisplayTip("???", "The entrance appears to be blocked.");
			return;
		}
		Transform thisPlayerBody = GameNetworkManager.Instance.localPlayerController.thisPlayerBody;
		GameNetworkManager.Instance.localPlayerController.TeleportPlayer(exitPoint.position);
		GameNetworkManager.Instance.localPlayerController.isInElevator = false;
		GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom = false;
		thisPlayerBody.eulerAngles = new Vector3(thisPlayerBody.eulerAngles.x, exitPoint.eulerAngles.y, thisPlayerBody.eulerAngles.z);
		SetAudioPreset((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		if (!checkedForFirstTime)
		{
			checkedForFirstTime = true;
			if (RoundManager.Instance.currentDungeonType != -1 && isEntranceToBuilding && (RoundManager.Instance.currentDungeonType == 0 || RoundManager.Instance.currentDungeonType == 1 || RoundManager.Instance.currentDungeonType == 4) && !ES3.Load<bool>($"PlayedDungeonEntrance{RoundManager.Instance.currentDungeonType}", "LCGeneralSaveData", false))
			{
				((MonoBehaviour)this).StartCoroutine(playMusicOnDelay());
			}
		}
		for (int i = 0; i < GameNetworkManager.Instance.localPlayerController.ItemSlots.Length; i++)
		{
			if ((Object)(object)GameNetworkManager.Instance.localPlayerController.ItemSlots[i] != (Object)null)
			{
				GameNetworkManager.Instance.localPlayerController.ItemSlots[i].isInFactory = isEntranceToBuilding;
			}
		}
		timeAtLastUse = Time.realtimeSinceStartup;
		TeleportPlayerServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		GameNetworkManager.Instance.localPlayerController.isInsideFactory = isEntranceToBuilding;
	}

	private IEnumerator playMusicOnDelay()
	{
		yield return (object)new WaitForSeconds(0.6f);
		ES3.Save<bool>($"PlayedDungeonEntrance{RoundManager.Instance.currentDungeonType}", true, "LCGeneralSaveData");
		HUDManager.Instance.UIAudio.PlayOneShot(RoundManager.Instance.dungeonFlowTypes[RoundManager.Instance.currentDungeonType].firstTimeAudio);
	}

	[ServerRpc(RequireOwnership = false)]
	public void TeleportPlayerServerRpc(int playerObj)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4279190381u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObj);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4279190381u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				TeleportPlayerClientRpc(playerObj);
			}
		}
	}

	[ClientRpc]
	public void TeleportPlayerClientRpc(int playerObj)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3168414823u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerObj);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3168414823u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || (Object)(object)playersManager.allPlayerScripts[playerObj] == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			return;
		}
		FindExitPoint();
		playersManager.allPlayerScripts[playerObj].TeleportPlayer(exitPoint.position, withRotation: true, exitPoint.eulerAngles.y);
		playersManager.allPlayerScripts[playerObj].isInElevator = false;
		playersManager.allPlayerScripts[playerObj].isInHangarShipRoom = false;
		PlayAudioAtTeleportPositions();
		playersManager.allPlayerScripts[playerObj].isInsideFactory = isEntranceToBuilding;
		for (int i = 0; i < playersManager.allPlayerScripts[playerObj].ItemSlots.Length; i++)
		{
			if ((Object)(object)playersManager.allPlayerScripts[playerObj].ItemSlots[i] != (Object)null)
			{
				playersManager.allPlayerScripts[playerObj].ItemSlots[i].isInFactory = isEntranceToBuilding;
			}
		}
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead && (Object)(object)playersManager.allPlayerScripts[playerObj] == (Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript)
		{
			SetAudioPreset(playerObj);
		}
		timeAtLastUse = Time.realtimeSinceStartup;
	}

	private void SetAudioPreset(int playerObj)
	{
		if (audioReverbPreset != -1)
		{
			Object.FindObjectOfType<AudioReverbPresets>().audioPresets[audioReverbPreset].ChangeAudioReverbForPlayer(StartOfRound.Instance.allPlayerScripts[playerObj]);
			if ((Object)(object)entrancePointAudio != (Object)null)
			{
				PlayAudioAtTeleportPositions();
			}
		}
	}

	public void PlayAudioAtTeleportPositions()
	{
		if (doorAudios.Length != 0)
		{
			entrancePointAudio.PlayOneShot(doorAudios[Random.Range(0, doorAudios.Length)]);
			exitPointAudio.PlayOneShot(doorAudios[Random.Range(0, doorAudios.Length)]);
		}
	}

	private void Update()
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)triggerScript == (Object)null || !isEntranceToBuilding)
		{
			return;
		}
		if (checkForEnemiesInterval <= 0f)
		{
			if (!gotExitPoint)
			{
				if (FindExitPoint())
				{
					gotExitPoint = true;
				}
				return;
			}
			checkForEnemiesInterval = 1f;
			bool flag = false;
			for (int i = 0; i < RoundManager.Instance.SpawnedEnemies.Count; i++)
			{
				if (Vector3.Distance(((Component)RoundManager.Instance.SpawnedEnemies[i]).transform.position, ((Component)exitPoint).transform.position) < 7.7f && !RoundManager.Instance.SpawnedEnemies[i].isEnemyDead)
				{
					flag = true;
					break;
				}
			}
			if (flag && !enemyNearLastCheck)
			{
				enemyNearLastCheck = true;
				triggerScript.hoverTip = "[Near activity detected!]";
			}
			else if (enemyNearLastCheck)
			{
				enemyNearLastCheck = false;
				triggerScript.hoverTip = "Enter: [LMB]";
			}
		}
		else
		{
			checkForEnemiesInterval -= Time.deltaTime;
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_EntranceTeleport()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(4279190381u, new RpcReceiveHandler(__rpc_handler_4279190381));
		NetworkManager.__rpc_func_table.Add(3168414823u, new RpcReceiveHandler(__rpc_handler_3168414823));
	}

	private static void __rpc_handler_4279190381(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObj = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObj);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((EntranceTeleport)(object)target).TeleportPlayerServerRpc(playerObj);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3168414823(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObj = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObj);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EntranceTeleport)(object)target).TeleportPlayerClientRpc(playerObj);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "EntranceTeleport";
	}
}
