using Unity.Netcode;
using UnityEngine;

public class KiwiBabyItem : GrabbableObject
{
	public Animator babyAnimator;

	public bool screaming;

	public int currentAnimation;

	private float timeHeld;

	public AudioSource eggAudio;

	public AudioClip peepAudio;

	public AudioClip screamAudio;

	public AudioClip breakEggSFX;

	private float screamingOnFloorTimer;

	private bool staring;

	private float screamTimer;

	private float stopScreamTimer;

	private bool countingScreamTimer;

	private bool takenIntoOrbit;

	public GiantKiwiAI mamaAI;

	public float timeLastAbandoned;

	public Vector3 positionWhenLastAbandoned;

	public bool hasScreamed;

	private float makeNoiseInterval;

	public AudioClip scream3SFX;

	[ServerRpc]
	public void SetScreamingServerRpc(bool scream)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2654954731u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref scream, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2654954731u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetScreamingClientRpc(scream);
		}
	}

	[ClientRpc]
	public void SetScreamingClientRpc(bool scream)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1784909488u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref scream, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1784909488u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && screaming != scream)
		{
			screaming = scream;
			if (scream)
			{
				countingScreamTimer = false;
				stopScreamTimer = 3f;
				currentAnimation = 3;
				hasScreamed = true;
			}
			else
			{
				currentAnimation = 1;
			}
		}
	}

	[ServerRpc]
	public void BreakOutServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(84321064u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 84321064u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			BreakOutClientRpc();
		}
	}

	[ClientRpc]
	public void BreakOutClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(788004645u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 788004645u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && currentAnimation == 0)
			{
				currentAnimation = 1;
				eggAudio.PlayOneShot(breakEggSFX);
			}
		}
	}

	public override void Start()
	{
		base.Start();
		screamTimer = 13f;
		mamaAI = Object.FindObjectOfType<GiantKiwiAI>();
		if (StartOfRound.Instance.inShipPhase)
		{
			takenIntoOrbit = true;
			currentAnimation = 4;
		}
	}

	public override void ReactToSellingItemOnCounter()
	{
		base.ReactToSellingItemOnCounter();
		currentAnimation = 5;
		eggAudio.pitch = Random.Range(0.93f, 1.15f);
		eggAudio.PlayOneShot(scream3SFX);
		babyAnimator.SetInteger("babyAnimation", 5);
	}

	public override void Update()
	{
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (currentAnimation == 5)
		{
			return;
		}
		if (StartOfRound.Instance.inShipPhase || takenIntoOrbit)
		{
			currentAnimation = 4;
			if (screaming)
			{
				screaming = false;
				takenIntoOrbit = true;
			}
			if (currentAnimation == 4)
			{
				eggAudio.Stop();
			}
		}
		else if (!eggAudio.isPlaying)
		{
			if (screaming)
			{
				eggAudio.clip = screamAudio;
				eggAudio.Play();
			}
			else if (currentAnimation == 1)
			{
				eggAudio.clip = peepAudio;
				eggAudio.Play();
			}
		}
		else if (currentAnimation == 4)
		{
			eggAudio.Stop();
		}
		babyAnimator.SetInteger("babyAnimation", currentAnimation);
		if ((Object)(object)mamaAI == (Object)null)
		{
			return;
		}
		if (isHeld || isHeldByEnemy)
		{
			float num = Vector3.Distance(((Component)this).transform.position, mamaAI.birdNest.transform.position);
			Debug.Log((object)$"Baby bird distance to nest : {num}", (Object)(object)((Component)this).gameObject);
			if (num > 5f)
			{
				if (!countingScreamTimer)
				{
					countingScreamTimer = true;
				}
			}
			else if (num < 4.8f && countingScreamTimer)
			{
				countingScreamTimer = false;
				screamTimer = 6f;
				screaming = false;
			}
		}
		if (countingScreamTimer)
		{
			Debug.Log((object)$"Counting scream timer; timer: {screamTimer}");
			if (screamTimer > 0f)
			{
				screamTimer -= Time.deltaTime;
				if (countingScreamTimer)
				{
					switch (currentAnimation)
					{
					case 0:
						if (screamTimer < 7f && ((NetworkBehaviour)this).IsOwner)
						{
							eggAudio.PlayOneShot(breakEggSFX);
							currentAnimation = 1;
							BreakOutServerRpc();
						}
						break;
					case 1:
						makeNoiseInterval -= Time.deltaTime;
						if (makeNoiseInterval < 0f)
						{
							makeNoiseInterval = 0.5f;
							RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 10f, 0.6f, 0, StartOfRound.Instance.hangarDoorsClosed && isInShipRoom);
						}
						if (screamTimer < 3f)
						{
							currentAnimation = 2;
						}
						break;
					case 2:
						if (eggAudio.isPlaying)
						{
							eggAudio.Stop();
						}
						break;
					case 4:
						if (eggAudio.isPlaying)
						{
							eggAudio.Stop();
						}
						break;
					}
				}
			}
			else if (!screaming)
			{
				Debug.Log((object)$"Start screaming; {screamTimer}");
				countingScreamTimer = false;
				screaming = true;
				hasScreamed = true;
				currentAnimation = 3;
				stopScreamTimer = 3f;
				if (((NetworkBehaviour)this).IsOwner)
				{
					SetScreamingServerRpc(scream: true);
				}
			}
		}
		if (screaming && !isHeld)
		{
			stopScreamTimer -= Time.deltaTime;
			if (stopScreamTimer < 0f && ((NetworkBehaviour)this).IsOwner)
			{
				screaming = false;
				currentAnimation = 4;
				SetScreamingServerRpc(scream: false);
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_KiwiBabyItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2654954731u, new RpcReceiveHandler(__rpc_handler_2654954731));
		NetworkManager.__rpc_func_table.Add(1784909488u, new RpcReceiveHandler(__rpc_handler_1784909488));
		NetworkManager.__rpc_func_table.Add(84321064u, new RpcReceiveHandler(__rpc_handler_84321064));
		NetworkManager.__rpc_func_table.Add(788004645u, new RpcReceiveHandler(__rpc_handler_788004645));
	}

	private static void __rpc_handler_2654954731(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool screamingServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref screamingServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((KiwiBabyItem)(object)target).SetScreamingServerRpc(screamingServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1784909488(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool screamingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref screamingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((KiwiBabyItem)(object)target).SetScreamingClientRpc(screamingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_84321064(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((KiwiBabyItem)(object)target).BreakOutServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_788004645(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((KiwiBabyItem)(object)target).BreakOutClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "KiwiBabyItem";
	}
}
