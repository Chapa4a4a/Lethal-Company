using System.Collections.Generic;
using System.Linq;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;

public class ClaySurgeonAI : EnemyAI
{
	public float minDistance;

	public float maxDistance;

	[Space(5f)]
	public float jumpSpeed = 5f;

	public float jumpTime = 0.25f;

	public float startingInterval = 2f;

	public float endingInterval = 0.2f;

	public int snareBeatAmount;

	[Space(3f)]
	public float currentInterval;

	private float beatTimer;

	[Space(5f)]
	public ClaySurgeonAI master;

	private bool isMaster;

	[Space(5f)]
	public bool isJumping;

	private float jumpTimer;

	private bool jumpingLastFrame;

	private int beatsSinceSeeingPlayer;

	private bool hasLOS;

	public SimpleEvent SendDanceBeat;

	private int currentHour;

	private bool jumpCycle;

	public AISearchRoutine searchRoutine;

	private float timeSinceSnip;

	private float snareIntervalTimer;

	public AudioSource musicAudio;

	public AudioSource musicAudio2;

	public AudioClip snareDrum;

	public AudioClip[] paradeClips;

	public AudioClip snipScissors;

	private int previousParadeClip;

	public List<ClaySurgeonAI> allClaySurgeons;

	private int snareNum;

	public float snareOffset;

	public MeshRenderer[] scissorBlades;

	public SkinnedMeshRenderer skin;

	public Material scissorGuyMat;

	private Material thisMaterial;

	private RaycastHit hit;

	private bool listeningToMasterSurgeon;

	private bool choseMasterSurgeon;

	private void Awake()
	{
		thisMaterial = ((Renderer)scissorBlades[0]).material;
		((Renderer)scissorBlades[1]).sharedMaterial = thisMaterial;
		((Renderer)skin).sharedMaterial = thisMaterial;
	}

	[ClientRpc]
	public void SyncMasterClaySurgeonClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Expected O, but got Unknown
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3353392677u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3353392677u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		master = this;
		isMaster = true;
		TimeOfDay.Instance.onHourChanged.AddListener(new UnityAction(HourChanged));
		SendDanceBeat = new SimpleEvent();
		allClaySurgeons = Object.FindObjectsByType<ClaySurgeonAI>((FindObjectsSortMode)0).ToList();
		for (int i = 0; i < allClaySurgeons.Count; i++)
		{
			if (!((Object)(object)allClaySurgeons[i] == (Object)(object)this))
			{
				allClaySurgeons[i].master = this;
				allClaySurgeons[i].ListenToMasterSurgeon();
				Object.Destroy((Object)(object)((Component)allClaySurgeons[i].musicAudio2).gameObject);
			}
		}
	}

	public void ListenToMasterSurgeon()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Expected O, but got Unknown
		if (!listeningToMasterSurgeon)
		{
			listeningToMasterSurgeon = true;
			((UnityEvent)master.SendDanceBeat).AddListener(new UnityAction(DanceBeat));
			if ((Object)(object)musicAudio2 != (Object)null)
			{
				Object.Destroy((Object)(object)((Component)musicAudio2).gameObject);
			}
			if (!master.allClaySurgeons.Contains(this))
			{
				master.allClaySurgeons.Add(this);
			}
		}
	}

	public override void Start()
	{
		base.Start();
		HourChanged();
	}

	private void LateUpdate()
	{
		if (!choseMasterSurgeon)
		{
			choseMasterSurgeon = true;
			ChooseMasterSurgeon();
		}
	}

	private void ChooseMasterSurgeon()
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Expected O, but got Unknown
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (((NetworkBehaviour)this).IsServer && !listeningToMasterSurgeon)
		{
			ClaySurgeonAI[] array = Object.FindObjectsByType<ClaySurgeonAI>((FindObjectsSortMode)0);
			int num = 1000;
			int num2 = -50;
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i].thisEnemyIndex < num)
				{
					num = array[i].thisEnemyIndex;
					num2 = i;
				}
			}
			master = array[num2];
			if ((Object)(object)master == (Object)(object)this)
			{
				isMaster = true;
				TimeOfDay.Instance.onHourChanged.AddListener(new UnityAction(HourChanged));
				SendDanceBeat = new SimpleEvent();
				allClaySurgeons = array.ToList();
				for (int j = 0; j < allClaySurgeons.Count; j++)
				{
					if (!((Object)(object)allClaySurgeons[j] == (Object)(object)this))
					{
						allClaySurgeons[j].master = this;
						allClaySurgeons[j].ListenToMasterSurgeon();
					}
				}
				SyncMasterClaySurgeonClientRpc();
			}
			if (!isMaster && (Object)(object)musicAudio2 != (Object)null)
			{
				Object.Destroy((Object)(object)((Component)musicAudio2).gameObject);
			}
		}
		else if ((Object)(object)musicAudio2 != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)musicAudio2).gameObject);
		}
	}

	public override void OnDestroy()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Expected O, but got Unknown
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Expected O, but got Unknown
		base.OnDestroy();
		if (isMaster)
		{
			TimeOfDay.Instance.onHourChanged.RemoveListener(new UnityAction(HourChanged));
		}
		else if ((Object)(object)master != (Object)null)
		{
			master.allClaySurgeons.Remove(this);
			if (master.SendDanceBeat != null)
			{
				((UnityEvent)master.SendDanceBeat).RemoveListener(new UnityAction(DanceBeat));
			}
		}
	}

	public override void DoAIInterval()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		PlayerControllerB playerControllerB = targetPlayer;
		if (TargetClosestPlayer(5f, requireLineOfSight: true, 120f))
		{
			hasLOS = true;
			beatsSinceSeeingPlayer = 0;
			if (searchRoutine.inProgress)
			{
				StopSearch(searchRoutine);
			}
		}
		else if (beatsSinceSeeingPlayer > 6)
		{
			if (hasLOS)
			{
				hasLOS = false;
			}
			if (!searchRoutine.inProgress)
			{
				StartSearch(((Component)this).transform.position, searchRoutine);
			}
		}
		else if ((Object)(object)playerControllerB != (Object)null)
		{
			targetPlayer = playerControllerB;
		}
	}

	private void PlayMusic()
	{
		if (snareIntervalTimer <= 0f)
		{
			snareIntervalTimer = 100f;
			musicAudio.PlayOneShot(snareDrum);
			WalkieTalkie.TransmitOneShotAudio(musicAudio, snareDrum);
			if (isMaster)
			{
				musicAudio2.PlayOneShot(snareDrum);
			}
		}
		else
		{
			snareIntervalTimer -= Time.deltaTime;
		}
	}

	private void SetMusicVolume()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		float num2 = 1000f;
		for (int i = 0; i < allClaySurgeons.Count; i++)
		{
			if (!((Object)(object)allClaySurgeons[i] == (Object)null) && !allClaySurgeons[i].isEnemyDead)
			{
				num = Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)allClaySurgeons[i]).transform.position);
				if (num < num2)
				{
					num2 = num;
				}
			}
		}
		if (num2 < 40f)
		{
			float num3 = ((!(num2 < 20f)) ? Mathf.Lerp(1f, 0.25f, num2 / 50f) : Mathf.Lerp(0.4f, 0f, num2 / 10f));
			musicAudio2.volume = Mathf.Lerp(musicAudio2.volume, num3, 2.5f * Time.deltaTime);
		}
		else
		{
			musicAudio2.volume = Mathf.Lerp(musicAudio2.volume, 0f, 4f * Time.deltaTime);
		}
	}

	private void SetVisibility()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position + Vector3.up * 0.7f);
		thisMaterial.SetFloat("_AlphaCutoff", (num - minDistance) / (maxDistance - minDistance));
		PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
		if (!localPlayerController.isPlayerDead && (Object)(object)localPlayerController != (Object)null && num < 15f && num > maxDistance + 2f)
		{
			localPlayerController.IncreaseFearLevelOverTime(0.37f, 0.25f);
		}
	}

	public override void Update()
	{
		base.Update();
		SetVisibility();
		if (isMaster)
		{
			SetDanceClock();
			SetMusicVolume();
		}
		if (StartOfRound.Instance.allPlayersDead || (Object)(object)master == (Object)null)
		{
			return;
		}
		if (isMaster)
		{
			PlayMusic();
		}
		timeSinceSnip += Time.deltaTime;
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (isEnemyDead || stunNormalizedTimer > 0f)
		{
			agent.speed = 0f;
		}
		else if (isJumping)
		{
			if (timeSinceSnip < 0.7f)
			{
				timeSinceSnip += Time.deltaTime;
				agent.speed = 0f;
			}
			jumpTimer -= Time.deltaTime;
			if (jumpTimer <= 0f)
			{
				isJumping = false;
				agent.speed = 0f;
			}
			else
			{
				agent.speed = jumpSpeed;
			}
		}
		if (isMaster)
		{
			if (beatTimer <= 0f)
			{
				beatTimer = currentInterval;
				DoBeatOnOwnerClient();
			}
			else
			{
				beatTimer -= Time.deltaTime;
			}
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (!(timeSinceSnip < 1f))
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				playerControllerB.KillPlayer(Vector3.up * 14f, spawnBody: true, CauseOfDeath.Snipped, 7);
				KillPlayerServerRpc();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KillPlayerServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4262444463u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4262444463u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				KillPlayerClientRpc();
			}
		}
	}

	[ClientRpc]
	public void KillPlayerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1539261657u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1539261657u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				agent.speed = 0f;
				beatTimer += 2f;
			}
			snareIntervalTimer = Mathf.Min(snareIntervalTimer + 2f, 4f);
			timeSinceSnip = 0f;
			creatureAnimator.SetTrigger("snip");
			creatureSFX.PlayOneShot(snipScissors);
		}
	}

	private void DoBeatOnOwnerClient()
	{
		DanceBeat();
		((UnityEvent)SendDanceBeat).Invoke();
		DoBeatServerRpc();
	}

	[ServerRpc]
	public void DoBeatServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3465640270u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3465640270u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DoBeatClientRpc();
		}
	}

	[ClientRpc]
	public void DoBeatClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1141998134u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1141998134u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
		{
			if (isMaster)
			{
				DanceBeat();
			}
			if (SendDanceBeat != null)
			{
				((UnityEvent)SendDanceBeat).Invoke();
			}
		}
	}

	private void HourChanged()
	{
		currentInterval = Mathf.Clamp(Mathf.Lerp(startingInterval, endingInterval, (float)TimeOfDay.Instance.hour / (float)TimeOfDay.Instance.numberOfHours), endingInterval, startingInterval);
	}

	private void DanceBeat()
	{
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		if (stunNormalizedTimer > 0f)
		{
			return;
		}
		isJumping = true;
		jumpTimer = jumpTime;
		jumpCycle = !jumpCycle;
		creatureAnimator.SetBool("walkCycle", jumpCycle);
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		beatsSinceSeeingPlayer++;
		if (hasLOS && (Object)(object)targetPlayer != (Object)null)
		{
			Vector3 val = ((Component)targetPlayer).transform.position;
			if (Physics.Raycast(((Component)targetPlayer).transform.position + Vector3.up * 0.5f, Vector3.down, ref hit, 7f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				val = ((RaycastHit)(ref hit)).point;
			}
			Vector3 onUnitSphere = Random.onUnitSphere;
			onUnitSphere.y = 0f;
			Ray val2 = default(Ray);
			((Ray)(ref val2))._002Ector(val, onUnitSphere);
			float num = Vector3.Distance(((Component)this).transform.position, val);
			val = ((!Physics.Raycast(val2, ref hit, num, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)) ? ((Ray)(ref val2)).GetPoint(num) : ((RaycastHit)(ref hit)).point);
			SetDestinationToPosition(val);
		}
	}

	public override void AnimationEventA()
	{
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		base.AnimationEventA();
		if (((NetworkBehaviour)this).IsOwner)
		{
			SyncPositionToClients();
		}
		if (!(timeSinceSnip < 0.4f))
		{
			int num = Random.Range(0, paradeClips.Length);
			if (num == previousParadeClip)
			{
				num = (num + 1) % paradeClips.Length;
			}
			previousParadeClip = num;
			float pitch = Random.Range(0.95f, 1.05f);
			musicAudio.pitch = pitch;
			musicAudio.PlayOneShot(paradeClips[num]);
			WalkieTalkie.TransmitOneShotAudio(musicAudio, paradeClips[num]);
			snareIntervalTimer = currentInterval - snareOffset;
			snareNum = 0;
			PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
			if (!localPlayerController.isPlayerDead && localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.7f, 70f, (int)maxDistance - 1))
			{
				localPlayerController.JumpToFearLevel(0.85f);
			}
			if (isMaster)
			{
				musicAudio2.pitch = pitch;
				musicAudio2.PlayOneShot(paradeClips[num]);
			}
		}
	}

	private void SetDanceClock()
	{
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ClaySurgeonAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3353392677u, new RpcReceiveHandler(__rpc_handler_3353392677));
		NetworkManager.__rpc_func_table.Add(4262444463u, new RpcReceiveHandler(__rpc_handler_4262444463));
		NetworkManager.__rpc_func_table.Add(1539261657u, new RpcReceiveHandler(__rpc_handler_1539261657));
		NetworkManager.__rpc_func_table.Add(3465640270u, new RpcReceiveHandler(__rpc_handler_3465640270));
		NetworkManager.__rpc_func_table.Add(1141998134u, new RpcReceiveHandler(__rpc_handler_1141998134));
	}

	private static void __rpc_handler_3353392677(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ClaySurgeonAI)(object)target).SyncMasterClaySurgeonClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4262444463(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ClaySurgeonAI)(object)target).KillPlayerServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1539261657(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ClaySurgeonAI)(object)target).KillPlayerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3465640270(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ClaySurgeonAI)(object)target).DoBeatServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1141998134(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ClaySurgeonAI)(object)target).DoBeatClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ClaySurgeonAI";
	}
}
