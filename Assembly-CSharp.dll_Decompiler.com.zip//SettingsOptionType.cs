using System;

[Serializable]
public enum SettingsOptionType
{
	LookSens,
	Gamma,
	OnlineMode,
	MicPushToTalk,
	MicEnabled,
	MicDevice,
	ChangeBinding,
	CancelOrConfirm,
	MasterVolume,
	FramerateCap,
	FullscreenType,
	InvertYAxis,
	SpiderSafeMode
}
