using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class NutcrackerEnemyAI : EnemyAI
{
	private int previousBehaviourState = -1;

	private int previousBehaviourStateAIInterval = -1;

	public static float timeAtNextInspection;

	private bool inspectingLocalPlayer;

	private float localPlayerTurnDistance;

	private bool isInspecting;

	private bool hasGun;

	private int randomSeedNumber;

	public GameObject gunPrefab;

	public ShotgunItem gun;

	public Transform gunPoint;

	private NetworkObjectReference gunObjectRef;

	public AISearchRoutine patrol;

	public AISearchRoutine attackSearch;

	public Transform torsoContainer;

	public float currentTorsoRotation;

	public int targetTorsoDegrees;

	public float torsoTurnSpeed = 2f;

	public AudioSource torsoTurnAudio;

	public AudioSource longRangeAudio;

	public AudioClip[] torsoFinishTurningClips;

	public AudioClip aimSFX;

	public AudioClip kickSFX;

	public GameObject shotgunShellPrefab;

	private bool torsoTurning;

	private Random NutcrackerRandom;

	private int timesDoingInspection;

	private Coroutine inspectionCoroutine;

	public int lastPlayerSeenMoving = -1;

	private float timeSinceSeeingTarget;

	private float timeSinceInspecting;

	private float timeSinceFiringGun;

	private bool aimingGun;

	private bool reloadingGun;

	private Vector3 lastSeenPlayerPos;

	private RaycastHit rayHit;

	private Coroutine gunCoroutine;

	private bool isLeaderScript;

	private Vector3 positionLastCheck;

	private Vector3 strafePosition;

	private bool reachedStrafePosition;

	private bool lostPlayerInChase;

	private float timeSinceHittingPlayer;

	private Coroutine waitToFireGunCoroutine;

	private float walkCheckInterval;

	private int timesSeeingSamePlayer;

	private int previousPlayerSeenWhenAiming = -1;

	private float speedWhileAiming;

	public override void Start()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		if (((NetworkBehaviour)this).IsServer)
		{
			InitializeNutcrackerValuesServerRpc();
			if (enemyType.numberSpawned <= 1)
			{
				isLeaderScript = true;
			}
		}
		rayHit = default(RaycastHit);
	}

	[ServerRpc]
	public void InitializeNutcrackerValuesServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1465144951u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1465144951u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			GameObject val3 = Object.Instantiate<GameObject>(gunPrefab, ((Component)this).transform.position + Vector3.up * 0.5f, Quaternion.identity, RoundManager.Instance.spawnedScrapContainer);
			val3.GetComponent<NetworkObject>().Spawn(false);
			GrabGun(val3);
			randomSeedNumber = Random.Range(0, 10000);
			InitializeNutcrackerValuesClientRpc(randomSeedNumber, NetworkObjectReference.op_Implicit(val3.GetComponent<NetworkObject>()));
		}
	}

	[ClientRpc]
	public void InitializeNutcrackerValuesClientRpc(int randomSeed, NetworkObjectReference gunObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(322560977u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, randomSeed);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref gunObject, default(ForNetworkSerializable));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 322560977u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				randomSeedNumber = randomSeed;
				gunObjectRef = gunObject;
			}
		}
	}

	private void GrabGun(GameObject gunObject)
	{
		gun = gunObject.GetComponent<ShotgunItem>();
		if ((Object)(object)gun == (Object)null)
		{
			LogEnemyError("Gun in GrabGun function did not contain ShotgunItem component.");
			return;
		}
		Debug.Log((object)"Setting gun scrap value");
		gun.SetScrapValue(60);
		RoundManager.Instance.totalScrapValueInLevel += gun.scrapValue;
		gun.parentObject = gunPoint;
		gun.isHeldByEnemy = true;
		gun.grabbableToEnemies = false;
		gun.grabbable = false;
		gun.shellsLoaded = 2;
		gun.GrabItemFromEnemy(this);
	}

	private void DropGun(Vector3 dropPosition)
	{
		if ((Object)(object)gun == (Object)null)
		{
			LogEnemyError("Could not drop gun since no gun was held!");
			return;
		}
		gun.DiscardItemFromEnemy();
		gun.isHeldByEnemy = false;
		gun.grabbableToEnemies = true;
		gun.grabbable = true;
	}

	private void SpawnShotgunShells()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			for (int i = 0; i < 2; i++)
			{
				Vector3 val = ((Component)this).transform.position + Vector3.up * 0.6f;
				val += new Vector3(Random.Range(-0.8f, 0.8f), 0f, Random.Range(-0.8f, 0.8f));
				GameObject obj = Object.Instantiate<GameObject>(shotgunShellPrefab, val, Quaternion.identity, RoundManager.Instance.spawnedScrapContainer);
				obj.GetComponent<GrabbableObject>().fallTime = 0f;
				obj.GetComponent<NetworkObject>().Spawn(false);
			}
		}
	}

	[ServerRpc]
	public void DropGunServerRpc(Vector3 dropPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3846014741u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref dropPosition);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3846014741u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DropGunClientRpc(dropPosition);
		}
	}

	[ClientRpc]
	public void DropGunClientRpc(Vector3 dropPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3142489771u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref dropPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3142489771u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)gun == (Object)null))
			{
				DropGun(dropPosition);
			}
		}
	}

	public override void DoAIInterval()
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_033f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (isEnemyDead || stunNormalizedTimer > 0f || (Object)(object)gun == (Object)null)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (previousBehaviourStateAIInterval != currentBehaviourStateIndex)
			{
				previousBehaviourStateAIInterval = currentBehaviourStateIndex;
				agent.stoppingDistance = 0.02f;
			}
			if (!patrol.inProgress)
			{
				StartSearch(((Component)this).transform.position, patrol);
			}
			break;
		case 1:
			if (previousBehaviourStateAIInterval != currentBehaviourStateIndex)
			{
				previousBehaviourStateAIInterval = currentBehaviourStateIndex;
				if (patrol.inProgress)
				{
					StopSearch(patrol);
				}
			}
			break;
		case 2:
			if (previousBehaviourStateAIInterval != currentBehaviourStateIndex)
			{
				previousBehaviourStateAIInterval = currentBehaviourStateIndex;
				if (patrol.inProgress)
				{
					StopSearch(patrol);
				}
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if (timeSinceSeeingTarget < 0.5f)
			{
				if (attackSearch.inProgress)
				{
					StopSearch(attackSearch);
				}
				reachedStrafePosition = false;
				SetDestinationToPosition(lastSeenPlayerPos);
				agent.stoppingDistance = 1f;
				if (lostPlayerInChase)
				{
					lostPlayerInChase = false;
					SetLostPlayerInChaseServerRpc(lostPlayer: false);
				}
				break;
			}
			agent.stoppingDistance = 0.02f;
			if (timeSinceSeeingTarget > 12f)
			{
				if (!reloadingGun && timeSinceFiringGun > 0.5f)
				{
					SwitchToBehaviourState(1);
				}
			}
			else if (!reachedStrafePosition)
			{
				if (!agent.CalculatePath(lastSeenPlayerPos, path1))
				{
					break;
				}
				if (DebugEnemy)
				{
					for (int i = 1; i < path1.corners.Length; i++)
					{
						Debug.DrawLine(path1.corners[i - 1], path1.corners[i], Color.red, AIIntervalTime);
					}
				}
				if (path1.corners.Length > 1)
				{
					Ray val = default(Ray);
					((Ray)(ref val))._002Ector(path1.corners[path1.corners.Length - 1], path1.corners[path1.corners.Length - 1] - path1.corners[path1.corners.Length - 2]);
					if (Physics.Raycast(val, ref rayHit, 5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
					{
						strafePosition = RoundManager.Instance.GetNavMeshPosition(((Ray)(ref val)).GetPoint(Mathf.Max(0f, ((RaycastHit)(ref rayHit)).distance - 2f)));
					}
					else
					{
						strafePosition = RoundManager.Instance.GetNavMeshPosition(((Ray)(ref val)).GetPoint(6f));
					}
				}
				else
				{
					strafePosition = lastSeenPlayerPos;
				}
				SetDestinationToPosition(strafePosition);
				if (Vector3.Distance(((Component)this).transform.position, strafePosition) < 2f)
				{
					reachedStrafePosition = true;
				}
			}
			else
			{
				if (!lostPlayerInChase)
				{
					lostPlayerInChase = true;
					SetLostPlayerInChaseServerRpc(lostPlayer: true);
				}
				if (!attackSearch.inProgress)
				{
					StartSearch(strafePosition, attackSearch);
				}
			}
			break;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetLostPlayerInChaseServerRpc(bool lostPlayer)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1948237339u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref lostPlayer, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1948237339u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetLostPlayerInChaseClientRpc(lostPlayer);
			}
		}
	}

	[ClientRpc]
	public void SetLostPlayerInChaseClientRpc(bool lostPlayer)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1780697749u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref lostPlayer, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1780697749u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
		{
			lostPlayerInChase = lostPlayer;
			if (!lostPlayer)
			{
				timeSinceSeeingTarget = 0f;
			}
		}
	}

	private bool GrabGunIfNotHolding()
	{
		if ((Object)(object)gun != (Object)null)
		{
			return true;
		}
		NetworkObject val = default(NetworkObject);
		if (((NetworkObjectReference)(ref gunObjectRef)).TryGet(ref val, (NetworkManager)null))
		{
			gun = ((Component)val).gameObject.GetComponent<ShotgunItem>();
			GrabGun(((Component)gun).gameObject);
		}
		return (Object)(object)gun != (Object)null;
	}

	public void TurnTorsoToTargetDegrees()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		currentTorsoRotation = Mathf.MoveTowardsAngle(currentTorsoRotation, (float)targetTorsoDegrees, Time.deltaTime * torsoTurnSpeed);
		torsoContainer.localEulerAngles = new Vector3(currentTorsoRotation + 90f, 90f, 90f);
		if (Mathf.Abs(currentTorsoRotation - (float)targetTorsoDegrees) > 5f)
		{
			if (!torsoTurning)
			{
				torsoTurning = true;
				torsoTurnAudio.Play();
			}
		}
		else if (torsoTurning)
		{
			torsoTurning = false;
			torsoTurnAudio.Stop();
			RoundManager.PlayRandomClip(torsoTurnAudio, torsoFinishTurningClips);
		}
		torsoTurnAudio.volume = Mathf.Lerp(torsoTurnAudio.volume, 1f, Time.deltaTime * 2f);
	}

	private void SetTargetDegreesToPosition(Vector3 pos)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		pos.y = ((Component)this).transform.position.y;
		Vector3 val = pos - ((Component)this).transform.position;
		targetTorsoDegrees = (int)Vector3.Angle(val, ((Component)this).transform.forward);
		if (Vector3.Cross(((Component)this).transform.forward, val).y > 0f)
		{
			targetTorsoDegrees = 360 - targetTorsoDegrees;
		}
		torsoTurnSpeed = 455f;
	}

	private void StartInspectionTurn()
	{
		if (!isInspecting && !isEnemyDead)
		{
			timesDoingInspection++;
			if (inspectionCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(inspectionCoroutine);
			}
			inspectionCoroutine = ((MonoBehaviour)this).StartCoroutine(InspectionTurn());
		}
	}

	private IEnumerator InspectionTurn()
	{
		yield return (object)new WaitForSeconds(0.75f);
		isInspecting = true;
		NutcrackerRandom = new Random(randomSeedNumber + timesDoingInspection);
		int degrees = 0;
		int turnTime = 1;
		for (int i = 0; i < 8; i++)
		{
			degrees = Mathf.Min(degrees + NutcrackerRandom.Next(45, 95), 360);
			if (Physics.Raycast(eye.position, eye.forward, 5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				turnTime = 1;
			}
			else
			{
				int num = ((!((float)turnTime > 2f)) ? 4 : (turnTime / 3));
				turnTime = NutcrackerRandom.Next(1, Mathf.Max(num, 3));
			}
			targetTorsoDegrees = degrees;
			torsoTurnSpeed = NutcrackerRandom.Next(275, 855) / turnTime;
			yield return (object)new WaitForSeconds((float)turnTime);
			if (degrees >= 360)
			{
				break;
			}
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			SwitchToBehaviourState(0);
		}
	}

	public void StopInspection()
	{
		if (isInspecting)
		{
			isInspecting = false;
		}
		if (inspectionCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(inspectionCoroutine);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SeeMovingThreatServerRpc(int playerId, bool enterAttackFromPatrolMode = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2806509823u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enterAttackFromPatrolMode, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2806509823u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SeeMovingThreatClientRpc(playerId, enterAttackFromPatrolMode);
			}
		}
	}

	[ClientRpc]
	public void SeeMovingThreatClientRpc(int playerId, bool enterAttackFromPatrolMode = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3996049734u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enterAttackFromPatrolMode, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3996049734u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (currentBehaviourStateIndex == 1 || (enterAttackFromPatrolMode && currentBehaviourStateIndex == 0)))
			{
				SwitchTargetToPlayer(playerId);
				SwitchToBehaviourStateOnLocalClient(2);
			}
		}
	}

	private void GlobalNutcrackerClock()
	{
		if (isLeaderScript && Time.realtimeSinceStartup - timeAtNextInspection > 2f)
		{
			timeAtNextInspection = Time.realtimeSinceStartup + Random.Range(6f, 15f);
		}
	}

	public override void Update()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0414: Unknown result type (might be due to invalid IL or missing references)
		//IL_043a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0475: Unknown result type (might be due to invalid IL or missing references)
		//IL_047a: Unknown result type (might be due to invalid IL or missing references)
		//IL_048b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0496: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_062d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0648: Unknown result type (might be due to invalid IL or missing references)
		//IL_0658: Unknown result type (might be due to invalid IL or missing references)
		//IL_066c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_054e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0567: Unknown result type (might be due to invalid IL or missing references)
		//IL_0577: Unknown result type (might be due to invalid IL or missing references)
		//IL_057c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05af: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		TurnTorsoToTargetDegrees();
		if (isEnemyDead)
		{
			StopInspection();
			return;
		}
		GlobalNutcrackerClock();
		if (!isEnemyDead && !GrabGunIfNotHolding())
		{
			return;
		}
		if (walkCheckInterval <= 0f)
		{
			walkCheckInterval = 0.1f;
			Animator obj = creatureAnimator;
			Vector3 val = ((Component)this).transform.position - positionLastCheck;
			obj.SetBool("IsWalking", ((Vector3)(ref val)).sqrMagnitude > 0.001f);
			positionLastCheck = ((Component)this).transform.position;
		}
		else
		{
			walkCheckInterval -= Time.deltaTime;
		}
		if (stunNormalizedTimer >= 0f)
		{
			agent.speed = 0f;
			return;
		}
		timeSinceSeeingTarget += Time.deltaTime;
		timeSinceInspecting += Time.deltaTime;
		timeSinceFiringGun += Time.deltaTime;
		timeSinceHittingPlayer += Time.deltaTime;
		creatureAnimator.SetInteger("State", currentBehaviourStateIndex);
		creatureAnimator.SetBool("Aiming", aimingGun);
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (previousBehaviourState != currentBehaviourStateIndex)
			{
				creatureAnimator.SetBool("AimDown", false);
				isInspecting = false;
				lostPlayerInChase = false;
				creatureVoice.Stop();
				previousBehaviourState = currentBehaviourStateIndex;
			}
			agent.speed = 5.5f;
			targetTorsoDegrees = 0;
			torsoTurnSpeed = 525f;
			if (((NetworkBehaviour)this).IsOwner && Time.realtimeSinceStartup > timeAtNextInspection && timeSinceInspecting > 4f)
			{
				if (Random.Range(0, 100) < 40 || ((Object)(object)GetClosestPlayer() != (Object)null && mostOptimalDistance < 27f))
				{
					SwitchToBehaviourState(1);
				}
				else
				{
					timeSinceInspecting = 2f;
				}
			}
			break;
		case 1:
			if (previousBehaviourState != currentBehaviourStateIndex)
			{
				creatureAnimator.SetBool("AimDown", false);
				localPlayerTurnDistance = 0f;
				StartInspectionTurn();
				creatureVoice.Stop();
				if (previousBehaviourState != 2)
				{
					longRangeAudio.PlayOneShot(enemyType.audioClips[3]);
				}
				lostPlayerInChase = false;
				previousBehaviourState = currentBehaviourStateIndex;
			}
			timeSinceInspecting = 0f;
			agent.speed = 0f;
			if (isInspecting && CheckLineOfSightForLocalPlayer(70f, 60, 1) && IsLocalPlayerMoving())
			{
				isInspecting = false;
				SeeMovingThreatServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
			break;
		case 2:
			if (previousBehaviourState != currentBehaviourStateIndex)
			{
				if (previousBehaviourState != 1)
				{
					longRangeAudio.PlayOneShot(enemyType.audioClips[3]);
				}
				StopInspection();
				previousBehaviourState = currentBehaviourStateIndex;
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
				if (reloadingGun || aimingGun || (timeSinceFiringGun < 1.2f && timeSinceSeeingTarget < 0.5f) || timeSinceHittingPlayer < 1f)
				{
					if (aimingGun && !reloadingGun)
					{
						agent.speed = speedWhileAiming;
					}
					else
					{
						agent.speed = 0f;
					}
				}
				else
				{
					agent.speed = 7f;
				}
			}
			if (((NetworkBehaviour)this).IsOwner && timeSinceFiringGun > 0.75f && gun.shellsLoaded <= 0 && !reloadingGun && !aimingGun)
			{
				reloadingGun = true;
				ReloadGunServerRpc();
			}
			if (lastPlayerSeenMoving == -1)
			{
				break;
			}
			if (lostPlayerInChase)
			{
				targetTorsoDegrees = 0;
			}
			else
			{
				SetTargetDegreesToPosition(lastSeenPlayerPos);
			}
			if (CheckLineOfSightForPosition(((Component)StartOfRound.Instance.allPlayerScripts[lastPlayerSeenMoving].gameplayCamera).transform.position, 70f, 60, 1f))
			{
				timeSinceSeeingTarget = 0f;
				lastSeenPlayerPos = ((Component)StartOfRound.Instance.allPlayerScripts[lastPlayerSeenMoving]).transform.position;
				creatureAnimator.SetBool("AimDown", Vector3.Distance(lastSeenPlayerPos, ((Component)this).transform.position) < 2f && lastSeenPlayerPos.y - ((Component)this).transform.position.y < 1f);
			}
			if (!CheckLineOfSightForLocalPlayer(70f, 25, 1))
			{
				break;
			}
			if ((int)GameNetworkManager.Instance.localPlayerController.playerClientId == lastPlayerSeenMoving && timeSinceSeeingTarget < 8f)
			{
				if (timeSinceFiringGun > 0.75f && !reloadingGun && !aimingGun && timeSinceHittingPlayer > 1f && Vector3.Angle(gun.shotgunRayPoint.forward, ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position - gun.shotgunRayPoint.position) < 30f)
				{
					timeSinceFiringGun = 0f;
					agent.speed = 0f;
					AimGunServerRpc(((Component)this).transform.position);
				}
				if (lostPlayerInChase)
				{
					lostPlayerInChase = false;
					SetLostPlayerInChaseServerRpc(lostPlayer: false);
				}
				timeSinceSeeingTarget = 0f;
				lastSeenPlayerPos = ((Component)GameNetworkManager.Instance.localPlayerController).transform.position;
			}
			else if (IsLocalPlayerMoving())
			{
				bool flag = (int)GameNetworkManager.Instance.localPlayerController.playerClientId == lastPlayerSeenMoving;
				if (flag)
				{
					timeSinceSeeingTarget = 0f;
				}
				if (Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[lastPlayerSeenMoving]).transform.position) - Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) > 3f || (timeSinceSeeingTarget > 3f && !flag))
				{
					lastPlayerSeenMoving = (int)GameNetworkManager.Instance.localPlayerController.playerClientId;
					SwitchTargetServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
				}
			}
			break;
		}
	}

	[ServerRpc]
	public void ReloadGunServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3736826466u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3736826466u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (aimingGun)
			{
				reloadingGun = false;
			}
			else
			{
				ReloadGunClientRpc();
			}
		}
	}

	[ClientRpc]
	public void ReloadGunClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(894193044u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 894193044u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				StopAimingGun();
				gun.shellsLoaded = 2;
				gunCoroutine = ((MonoBehaviour)this).StartCoroutine(ReloadGun());
			}
		}
	}

	private IEnumerator ReloadGun()
	{
		reloadingGun = true;
		creatureSFX.PlayOneShot(enemyType.audioClips[2]);
		creatureAnimator.SetBool("Reloading", true);
		yield return (object)new WaitForSeconds(0.32f);
		gun.gunAnimator.SetBool("Reloading", true);
		yield return (object)new WaitForSeconds(0.92f);
		gun.gunAnimator.SetBool("Reloading", false);
		creatureAnimator.SetBool("Reloading", false);
		yield return (object)new WaitForSeconds(0.5f);
		reloadingGun = false;
	}

	private void StopReloading()
	{
		reloadingGun = false;
		gun.gunAnimator.SetBool("Reloading", false);
		creatureAnimator.SetBool("Reloading", false);
		if (gunCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(gunCoroutine);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void AimGunServerRpc(Vector3 enemyPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1572138691u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref enemyPos);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1572138691u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !reloadingGun)
		{
			if (gun.shellsLoaded <= 0)
			{
				aimingGun = false;
				ReloadGunClientRpc();
			}
			else if (!reloadingGun)
			{
				aimingGun = true;
				AimGunClientRpc(enemyPos);
			}
		}
	}

	[ClientRpc]
	public void AimGunClientRpc(Vector3 enemyPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2018420059u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref enemyPos);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2018420059u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				StopReloading();
				gunCoroutine = ((MonoBehaviour)this).StartCoroutine(AimGun(enemyPos));
			}
		}
	}

	private IEnumerator AimGun(Vector3 enemyPos)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		aimingGun = true;
		if (lastPlayerSeenMoving == previousPlayerSeenWhenAiming)
		{
			timesSeeingSamePlayer++;
		}
		else
		{
			previousPlayerSeenWhenAiming = lastPlayerSeenMoving;
			timesSeeingSamePlayer = 1;
		}
		longRangeAudio.PlayOneShot(aimSFX);
		if (timesSeeingSamePlayer >= 3)
		{
			speedWhileAiming = 2.25f;
		}
		else
		{
			speedWhileAiming = 0f;
		}
		updatePositionThreshold = 0.45f;
		serverPosition = enemyPos;
		if (enemyHP <= 1)
		{
			yield return (object)new WaitForSeconds(0.5f);
		}
		else if (gun.shellsLoaded == 1)
		{
			yield return (object)new WaitForSeconds(1.3f);
		}
		else
		{
			yield return (object)new WaitForSeconds(1.75f);
		}
		yield return (object)new WaitForEndOfFrame();
		if (((NetworkBehaviour)this).IsOwner)
		{
			FireGunServerRpc();
		}
		timeSinceFiringGun = 0f;
		yield return (object)new WaitForSeconds(0.35f);
		aimingGun = false;
		inSpecialAnimation = false;
		updatePositionThreshold = 1f;
		creatureVoice.Play();
		creatureVoice.pitch = Random.Range(0.9f, 1.1f);
	}

	[ServerRpc]
	public void FireGunServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3870955307u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3870955307u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (stunNormalizedTimer <= 0f)
			{
				FireGunClientRpc();
			}
			else
			{
				((MonoBehaviour)this).StartCoroutine(waitToFireGun());
			}
		}
	}

	[ClientRpc]
	public void FireGunClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(998664398u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 998664398u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				FireGun(gun.shotgunRayPoint.position, gun.shotgunRayPoint.forward);
			}
		}
	}

	private IEnumerator waitToFireGun()
	{
		yield return (object)new WaitUntil((Func<bool>)(() => stunNormalizedTimer <= 0f));
		yield return (object)new WaitForSeconds(0.5f);
		FireGunClientRpc();
	}

	private void StopAimingGun()
	{
		inSpecialAnimation = false;
		updatePositionThreshold = 1f;
		aimingGun = false;
		if (gunCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(gunCoroutine);
		}
	}

	private void FireGun(Vector3 gunPosition, Vector3 gunForward)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		creatureAnimator.ResetTrigger("ShootGun");
		creatureAnimator.SetTrigger("ShootGun");
		if ((Object)(object)gun == (Object)null)
		{
			LogEnemyError("No gun held on local client, unable to shoot");
		}
		else
		{
			gun.ShootGun(gunPosition, gunForward);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SwitchTargetServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3532402073u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3532402073u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SwitchTargetClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void SwitchTargetClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3858844829u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3858844829u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SwitchTargetToPlayer(playerId);
			}
		}
	}

	private void SwitchTargetToPlayer(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		lastPlayerSeenMoving = playerId;
		timeSinceSeeingTarget = 0f;
		lastSeenPlayerPos = ((Component)StartOfRound.Instance.allPlayerScripts[playerId]).transform.position;
	}

	public bool CheckLineOfSightForLocalPlayer(float width = 45f, int range = 60, int proximityAwareness = -1)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position;
		if (Vector3.Distance(position, eye.position) < (float)range && !Physics.Linecast(eye.position, position, StartOfRound.Instance.collidersAndRoomMaskAndDefault))
		{
			Vector3 val = position - eye.position;
			if (Vector3.Angle(eye.forward, val) < width || (proximityAwareness != -1 && Vector3.Distance(eye.position, position) < (float)proximityAwareness))
			{
				return true;
			}
		}
		return false;
	}

	private bool IsLocalPlayerMoving()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		localPlayerTurnDistance += StartOfRound.Instance.playerLookMagnitudeThisFrame;
		if (localPlayerTurnDistance > 0.1f && Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position) < 10f)
		{
			return true;
		}
		if (GameNetworkManager.Instance.localPlayerController.performingEmote)
		{
			return true;
		}
		if (Time.realtimeSinceStartup - StartOfRound.Instance.timeAtMakingLastPersonalMovement < 0.25f)
		{
			return true;
		}
		if (GameNetworkManager.Instance.localPlayerController.timeSincePlayerMoving < 0.05f)
		{
			return true;
		}
		return false;
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		base.OnCollideWithPlayer(other);
		if (!isEnemyDead && !(timeSinceHittingPlayer < 1f) && !(stunNormalizedTimer >= 0f))
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other, reloadingGun || aimingGun);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				timeSinceHittingPlayer = 0f;
				LegKickPlayerServerRpc((int)playerControllerB.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void LegKickPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3881699224u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3881699224u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				LegKickPlayerClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void LegKickPlayerClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3893799727u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3893799727u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				LegKickPlayer(playerId);
			}
		}
	}

	private void LegKickPlayer(int playerId)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		timeSinceHittingPlayer = 0f;
		PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[playerId];
		RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
		RoundManager.Instance.tempTransform.LookAt(((Component)playerControllerB).transform.position);
		((Component)this).transform.eulerAngles = new Vector3(0f, RoundManager.Instance.tempTransform.eulerAngles.y, 0f);
		serverRotation = new Vector3(0f, RoundManager.Instance.tempTransform.eulerAngles.y, 0f);
		Vector3 bodyVelocity = Vector3.Normalize((((Component)playerControllerB).transform.position + Vector3.up * 0.75f - ((Component)this).transform.position) * 100f) * 25f;
		playerControllerB.KillPlayer(bodyVelocity, spawnBody: true, CauseOfDeath.Kicking);
		creatureAnimator.SetTrigger("Kick");
		creatureSFX.Stop();
		torsoTurnAudio.volume = 0f;
		creatureSFX.PlayOneShot(kickSFX);
		if (currentBehaviourStateIndex != 2)
		{
			SwitchTargetToPlayer(playerId);
			SwitchToBehaviourStateOnLocalClient(2);
		}
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (!isEnemyDead)
		{
			if (isInspecting || currentBehaviourStateIndex == 2)
			{
				creatureSFX.PlayOneShot(enemyType.audioClips[0]);
				enemyHP -= force;
			}
			else
			{
				creatureSFX.PlayOneShot(enemyType.audioClips[1]);
			}
			if ((Object)(object)playerWhoHit != (Object)null)
			{
				SeeMovingThreatServerRpc((int)playerWhoHit.playerClientId, enterAttackFromPatrolMode: true);
			}
			if (enemyHP <= 0 && ((NetworkBehaviour)this).IsOwner)
			{
				KillEnemyOnOwnerClient();
			}
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		base.KillEnemy(destroy);
		targetTorsoDegrees = 0;
		StopInspection();
		StopReloading();
		if (((NetworkBehaviour)this).IsOwner)
		{
			DropGunServerRpc(gunPoint.position);
			((MonoBehaviour)this).StartCoroutine(spawnShotgunShellsOnDelay());
		}
		creatureVoice.Stop();
		torsoTurnAudio.Stop();
		creatureSFX.Stop();
	}

	private IEnumerator spawnShotgunShellsOnDelay()
	{
		yield return (object)new WaitForSeconds(1.2f);
		SpawnShotgunShells();
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_NutcrackerEnemyAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1465144951u, new RpcReceiveHandler(__rpc_handler_1465144951));
		NetworkManager.__rpc_func_table.Add(322560977u, new RpcReceiveHandler(__rpc_handler_322560977));
		NetworkManager.__rpc_func_table.Add(3846014741u, new RpcReceiveHandler(__rpc_handler_3846014741));
		NetworkManager.__rpc_func_table.Add(3142489771u, new RpcReceiveHandler(__rpc_handler_3142489771));
		NetworkManager.__rpc_func_table.Add(1948237339u, new RpcReceiveHandler(__rpc_handler_1948237339));
		NetworkManager.__rpc_func_table.Add(1780697749u, new RpcReceiveHandler(__rpc_handler_1780697749));
		NetworkManager.__rpc_func_table.Add(2806509823u, new RpcReceiveHandler(__rpc_handler_2806509823));
		NetworkManager.__rpc_func_table.Add(3996049734u, new RpcReceiveHandler(__rpc_handler_3996049734));
		NetworkManager.__rpc_func_table.Add(3736826466u, new RpcReceiveHandler(__rpc_handler_3736826466));
		NetworkManager.__rpc_func_table.Add(894193044u, new RpcReceiveHandler(__rpc_handler_894193044));
		NetworkManager.__rpc_func_table.Add(1572138691u, new RpcReceiveHandler(__rpc_handler_1572138691));
		NetworkManager.__rpc_func_table.Add(2018420059u, new RpcReceiveHandler(__rpc_handler_2018420059));
		NetworkManager.__rpc_func_table.Add(3870955307u, new RpcReceiveHandler(__rpc_handler_3870955307));
		NetworkManager.__rpc_func_table.Add(998664398u, new RpcReceiveHandler(__rpc_handler_998664398));
		NetworkManager.__rpc_func_table.Add(3532402073u, new RpcReceiveHandler(__rpc_handler_3532402073));
		NetworkManager.__rpc_func_table.Add(3858844829u, new RpcReceiveHandler(__rpc_handler_3858844829));
		NetworkManager.__rpc_func_table.Add(3881699224u, new RpcReceiveHandler(__rpc_handler_3881699224));
		NetworkManager.__rpc_func_table.Add(3893799727u, new RpcReceiveHandler(__rpc_handler_3893799727));
	}

	private static void __rpc_handler_1465144951(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).InitializeNutcrackerValuesServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_322560977(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int randomSeed = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref randomSeed);
			NetworkObjectReference gunObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref gunObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).InitializeNutcrackerValuesClientRpc(randomSeed, gunObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3846014741(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 dropPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref dropPosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).DropGunServerRpc(dropPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3142489771(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 dropPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref dropPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).DropGunClientRpc(dropPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1948237339(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool lostPlayerInChaseServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref lostPlayerInChaseServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).SetLostPlayerInChaseServerRpc(lostPlayerInChaseServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1780697749(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool lostPlayerInChaseClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref lostPlayerInChaseClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).SetLostPlayerInChaseClientRpc(lostPlayerInChaseClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2806509823(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			bool enterAttackFromPatrolMode = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enterAttackFromPatrolMode, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).SeeMovingThreatServerRpc(playerId, enterAttackFromPatrolMode);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3996049734(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			bool enterAttackFromPatrolMode = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enterAttackFromPatrolMode, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).SeeMovingThreatClientRpc(playerId, enterAttackFromPatrolMode);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3736826466(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).ReloadGunServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_894193044(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).ReloadGunClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1572138691(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 enemyPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref enemyPos);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).AimGunServerRpc(enemyPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2018420059(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 enemyPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref enemyPos);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).AimGunClientRpc(enemyPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3870955307(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).FireGunServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_998664398(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).FireGunClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3532402073(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).SwitchTargetServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3858844829(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).SwitchTargetClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3881699224(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((NutcrackerEnemyAI)(object)target).LegKickPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3893799727(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((NutcrackerEnemyAI)(object)target).LegKickPlayerClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "NutcrackerEnemyAI";
	}
}
