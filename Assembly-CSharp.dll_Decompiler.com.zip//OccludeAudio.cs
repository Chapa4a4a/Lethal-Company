using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class OccludeAudio : MonoBehaviour
{
	private AudioLowPassFilter lowPassFilter;

	private AudioReverbFilter reverbFilter;

	public bool useReverb;

	private bool occluded;

	private AudioSource thisAudio;

	private float checkInterval;

	public bool overridingLowPass;

	public float lowPassOverride = 20000f;

	public bool debugLog;

	private void Start()
	{
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		lowPassFilter = ((Component)this).gameObject.GetComponent<AudioLowPassFilter>();
		if ((Object)(object)lowPassFilter == (Object)null)
		{
			lowPassFilter = ((Component)this).gameObject.AddComponent<AudioLowPassFilter>();
			lowPassFilter.cutoffFrequency = 20000f;
		}
		if (useReverb)
		{
			reverbFilter = ((Component)this).gameObject.GetComponent<AudioReverbFilter>();
			if ((Object)(object)reverbFilter == (Object)null)
			{
				reverbFilter = ((Component)this).gameObject.AddComponent<AudioReverbFilter>();
			}
			reverbFilter.reverbPreset = (AudioReverbPreset)13;
			reverbFilter.reverbPreset = (AudioReverbPreset)27;
			reverbFilter.dryLevel = -1f;
			reverbFilter.decayTime = 0.8f;
			reverbFilter.room = -2300f;
		}
		thisAudio = ((Component)this).gameObject.GetComponent<AudioSource>();
		if ((Object)(object)StartOfRound.Instance != (Object)null && Physics.Linecast(((Component)this).transform.position, ((Component)StartOfRound.Instance.audioListener).transform.position, 256, (QueryTriggerInteraction)1))
		{
			occluded = true;
		}
		else
		{
			occluded = false;
		}
		checkInterval = Random.Range(0f, 0.4f);
	}

	private void Update()
	{
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		if (thisAudio.isVirtual)
		{
			return;
		}
		if (useReverb && (Object)(object)GameNetworkManager.Instance != (Object)null && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
		{
			if (GameNetworkManager.Instance.localPlayerController.isInsideFactory || (GameNetworkManager.Instance.localPlayerController.isPlayerDead && (Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript != (Object)null && GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript.isInsideFactory))
			{
				if (SoundManager.Instance.echoEnabled)
				{
					reverbFilter.dryLevel = Mathf.Lerp(reverbFilter.dryLevel, Mathf.Clamp(0f - 4.5f * (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position) / (thisAudio.maxDistance / 12f)), -1270f, -1f), Time.deltaTime * 8f);
				}
				else
				{
					reverbFilter.dryLevel = Mathf.Lerp(reverbFilter.dryLevel, Mathf.Clamp(0f - 3.4f * (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position) / (thisAudio.maxDistance / 5f)), -300f, -1f), Time.deltaTime * 8f);
				}
				((Behaviour)reverbFilter).enabled = true;
			}
			else
			{
				((Behaviour)reverbFilter).enabled = false;
			}
		}
		if (!overridingLowPass)
		{
			if (occluded)
			{
				lowPassFilter.cutoffFrequency = Mathf.Lerp(lowPassFilter.cutoffFrequency, Mathf.Clamp(2500f / (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position) / (thisAudio.maxDistance / 2f)), 900f, 4000f), Time.deltaTime * 8f);
			}
			else
			{
				lowPassFilter.cutoffFrequency = Mathf.Lerp(lowPassFilter.cutoffFrequency, 10000f, Time.deltaTime * 8f);
			}
		}
		else
		{
			lowPassFilter.cutoffFrequency = lowPassOverride;
		}
		if (checkInterval >= 0.5f)
		{
			checkInterval = Random.Range(0f, 0.04f);
			if (Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.audioListener).transform.position) < Mathf.Min(thisAudio.maxDistance, 110f))
			{
				RaycastHit val = default(RaycastHit);
				if (Physics.Linecast(((Component)this).transform.position, ((Component)StartOfRound.Instance.audioListener).transform.position, ref val, 256, (QueryTriggerInteraction)1))
				{
					_ = debugLog;
					occluded = true;
				}
				else
				{
					occluded = false;
				}
			}
		}
		else
		{
			checkInterval += Time.deltaTime;
		}
	}
}
