using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class RadMechAI : EnemyAI, IVisibleThreat
{
	public Vector3 lookVector;

	private int previousBehaviour;

	public AISearchRoutine searchForPlayers;

	[Header("Sight variables")]
	public float fov;

	[Header("Movement Variables")]
	public float timeBetweenSteps;

	public float timeToTakeStep;

	public float stepMovementSpeed;

	private float walkStepTimer = 1f;

	private bool takingStep;

	private bool leftFoot;

	private bool disableWalking;

	public Transform torsoContainer;

	public Threat targetedThreat;

	public Transform focusedThreatTransform;

	private Collider targetedThreatCollider;

	private Coroutine spotlightCoroutine;

	public Material defaultMat;

	public Material spotlightMat;

	public GameObject spotlight;

	public AudioClip spotlightOff;

	public AudioClip spotlightFlicker;

	public Collider ownCollider;

	public Transform leftFootPoint;

	public Transform rightFootPoint;

	public ParticleSystem rightFootParticle;

	public ParticleSystem leftFootParticle;

	public ParticleSystem bothFeetParticle;

	private int visibleThreatsMask = 524296;

	private bool lostCreatureInChase;

	private bool lostCreatureInChaseDebounce;

	private float losTimer;

	private bool hasLOS;

	private float syncLOSInterval;

	private bool SyncedLOSState;

	private int checkForPathInterval;

	public bool isAlerted;

	public float alertTimer;

	public AudioSource LocalLRADAudio;

	public AudioSource LocalLRADAudio2;

	private float LRADAudio2BroadcastTimer;

	public GameObject lradAudioPrefab;

	public GameObject lradAudio2Prefab;

	public Transform torsoDefaultRotation;

	public GameObject missilePrefab;

	private float explodeMissileTimer;

	private float currentMissileSpeed;

	public GameObject explosionPrefab;

	public GameObject blastMarkPrefab;

	public ParticleSystem gunArmParticle;

	public bool aimingGun;

	private bool waitingForNextShot;

	private float shootTimer;

	public Coroutine aimGunCoroutine;

	public Transform gunPoint;

	public Transform gunArm;

	public AudioClip[] shootGunSFX;

	public AudioClip[] largeExplosionSFX;

	public AudioSource explosionAudio;

	public float forwardAngleCompensation = 0.25f;

	private bool hadLOSDuringLastShot;

	public Transform defaultArmRotation;

	private float shootCooldown;

	private bool inFlyingMode;

	private bool inSky;

	private Vector3 flightDestination;

	private Coroutine flyingCoroutine;

	private Vector3 landingPosition;

	private bool finishingFlight;

	private bool changedDirectionInFlight;

	private float flyTimer;

	public Transform flyingModeEye;

	public ParticleSystem smokeRightLeg;

	public ParticleSystem smokeLeftLeg;

	public static List<GameObject> PooledBlastMarks = new List<GameObject>();

	private Vector3 previousExplosionPosition;

	[Header("Grab and torch players")]
	public ParticleSystem blowtorchParticle;

	public AudioSource blowtorchAudio;

	public bool attemptingGrab;

	private bool waitingToAttemptGrab;

	public bool inTorchPlayerAnimation;

	public Coroutine torchPlayerCoroutine;

	public Transform AttemptGrabPoint;

	private float attemptGrabTimer;

	private float timeSinceGrabbingPlayer;

	public Transform centerPosition;

	public Transform holdPlayerPoint;

	private bool blowtorchActivated;

	private bool startedUpdatePlayerPosCoroutine;

	public AudioSource flyingDistantAudio;

	public AudioSource spotlightOnAudio;

	[Header("Firing variables")]
	public int missilesFired;

	public float missileWarbleLevel = 1f;

	public float fireRate;

	public float fireRateVariance = 0.4f;

	public float missileSpeed = 0.5f;

	public float gunArmSpeed = 80f;

	[Space(3f)]
	public float shootUptime = 1.25f;

	public float shootDowntime = 0.92f;

	[Space(5f)]
	public bool chargingForward;

	public float chargeForwardSpeed;

	public GameObject startChargingEffectContainer;

	private bool startedChargeEffect;

	private float beginChargingTimer;

	public AudioSource chargeForwardAudio;

	public AudioSource engineSFX;

	public ParticleSystem chargeParticle;

	ThreatType IVisibleThreat.type => ThreatType.RadMech;

	bool IVisibleThreat.IsThreatDead()
	{
		return isEnemyDead;
	}

	GrabbableObject IVisibleThreat.GetHeldObject()
	{
		return null;
	}

	int IVisibleThreat.SendSpecialBehaviour(int id)
	{
		return 0;
	}

	int IVisibleThreat.GetThreatLevel(Vector3 seenByPosition)
	{
		int num = 0;
		num = 7;
		if (isAlerted)
		{
			num += 3;
		}
		return num;
	}

	int IVisibleThreat.GetInterestLevel()
	{
		return 0;
	}

	Transform IVisibleThreat.GetThreatLookTransform()
	{
		return eye;
	}

	Transform IVisibleThreat.GetThreatTransform()
	{
		return ((Component)this).transform;
	}

	Vector3 IVisibleThreat.GetThreatVelocity()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			return agent.velocity;
		}
		return Vector3.zero;
	}

	float IVisibleThreat.GetVisibility()
	{
		if (isEnemyDead)
		{
			return 0f;
		}
		if (spotlight.activeSelf)
		{
			if (isAlerted)
			{
				return 1f;
			}
			return 0.85f;
		}
		return 0.5f;
	}

	public override void Start()
	{
		base.Start();
	}

	private void SpawnBlastMark(Vector3 pos, Quaternion rot)
	{
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (PooledBlastMarks.Count >= 64)
		{
			for (int num = 63; num >= 0; num--)
			{
				if ((Object)(object)PooledBlastMarks[num] == (Object)null)
				{
					PooledBlastMarks.RemoveAt(num);
				}
				else
				{
					PooledBlastMarks[num].transform.position = pos;
					PooledBlastMarks[num].transform.rotation = rot;
				}
			}
		}
		else
		{
			GameObject item = Object.Instantiate<GameObject>(blastMarkPrefab, pos, rot, RoundManager.Instance.mapPropsContainer.transform);
			PooledBlastMarks.Add(item);
		}
	}

	private void LateUpdate()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null)
		{
			if (inSpecialAnimationWithPlayer.isPlayerDead && (Object)(object)inSpecialAnimationWithPlayer.deadBody != (Object)null)
			{
				inSpecialAnimationWithPlayer.deadBody.matchPositionExactly = true;
				inSpecialAnimationWithPlayer.deadBody.attachedLimb = inSpecialAnimationWithPlayer.deadBody.bodyParts[5];
				inSpecialAnimationWithPlayer.deadBody.attachedTo = holdPlayerPoint;
			}
			((Component)inSpecialAnimationWithPlayer).transform.position = holdPlayerPoint.position - holdPlayerPoint.up * 0.7f;
			((Component)inSpecialAnimationWithPlayer).transform.rotation = holdPlayerPoint.rotation;
		}
		if (((NetworkBehaviour)this).IsServer && !LocalLRADAudio2.isPlaying && isAlerted)
		{
			if (LRADAudio2BroadcastTimer > 0.05f)
			{
				LRADAudio2BroadcastTimer = 0f;
				int num = Random.Range(4, enemyType.audioClips.Length);
				LocalLRADAudio2.clip = enemyType.audioClips[num];
				LocalLRADAudio2.Play();
				ChangeBroadcastClipClientRpc(num);
			}
			else
			{
				LRADAudio2BroadcastTimer += Time.deltaTime;
			}
		}
	}

	[ClientRpc]
	public void ChangeBroadcastClipClientRpc(int clipIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3910336672u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clipIndex);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3910336672u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				LocalLRADAudio2.clip = enemyType.audioClips[clipIndex];
				LocalLRADAudio2.Play();
			}
		}
	}

	public void ChangeFlightLandingPosition(Vector3 newLandingPosition)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsServer && inSky)
		{
			RoundManager.Instance.GetNavMeshPosition(newLandingPosition, default(NavMeshHit), 8f, -353);
			if (RoundManager.Instance.GotNavMeshPositionResult)
			{
				changedDirectionInFlight = true;
				landingPosition = newLandingPosition;
				ChangeFlightLandingPositionClientRpc(newLandingPosition);
			}
		}
	}

	[ClientRpc]
	public void ChangeFlightLandingPositionClientRpc(Vector3 newLandingPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(492577947u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref newLandingPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 492577947u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				landingPosition = newLandingPosition;
				serverPosition = newLandingPosition;
			}
		}
	}

	public void EndFlight()
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			finishingFlight = true;
			flyTimer = 0f;
			EndFlightClientRpc();
		}
	}

	[ClientRpc]
	public void EndFlightClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2143274786u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2143274786u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				finishingFlight = true;
				flyTimer = 0f;
			}
		}
	}

	public void SetChargingForward(bool setCharging)
	{
		if (chargingForward != setCharging)
		{
			SetChargingForwardOnLocalClient(setCharging);
			SetChargingForwardClientRpc(setCharging);
		}
	}

	[ClientRpc]
	public void SetChargingForwardClientRpc(bool charging)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(220033949u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref charging, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 220033949u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				SetChargingForwardOnLocalClient(charging);
			}
		}
	}

	public void SetChargingForwardOnLocalClient(bool charging)
	{
		if (charging != chargingForward)
		{
			creatureAnimator.SetBool("charging", charging);
			startChargingEffectContainer.SetActive(charging);
			beginChargingTimer = 0f;
			startedChargeEffect = false;
			if (charging)
			{
				StompBothFeet();
				chargeParticle.Play();
				agent.angularSpeed = 120f;
				agent.acceleration = 25f;
			}
			else
			{
				agent.speed = 0f;
				chargeParticle.Stop();
				agent.angularSpeed = 220f;
				agent.acceleration = 60f;
			}
			chargingForward = charging;
		}
	}

	public void StartFlying()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsServer && !inFlyingMode)
		{
			Vector3 val = ChooseLandingPosition();
			if (val == Vector3.zero)
			{
				Debug.Log((object)$"Mech #{thisEnemyIndex} could not get a landing position!");
				disableWalking = false;
				((Behaviour)agent).enabled = true;
				SwitchToBehaviourState(0);
			}
			else
			{
				EnterFlight(val);
				EnterFlightClientRpc(val);
			}
		}
	}

	private void EnterFlight(Vector3 newLandingPosition)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		creatureAnimator.SetBool("Flying", true);
		inFlyingMode = true;
		((Behaviour)agent).enabled = false;
		inSpecialAnimation = true;
		serverPosition = newLandingPosition;
		flyTimer = 0f;
		smokeRightLeg.Play();
		smokeLeftLeg.Play();
		changedDirectionInFlight = false;
		inSky = false;
		landingPosition = newLandingPosition;
	}

	private Vector3 ChooseLandingPosition()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		for (int i = Random.Range(0, Mathf.Min(15, allAINodes.Length)); i < allAINodes.Length; i++)
		{
			Transform val = ChooseFarthestNodeFromPosition(((Component)this).transform.position, avoidLineOfSight: false, i);
			if (!Physics.Raycast(val.position, Vector3.up, 15f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				Vector3 navMeshPosition = RoundManager.Instance.GetNavMeshPosition(val.position, default(NavMeshHit), 10f, -353);
				if (RoundManager.Instance.GotNavMeshPositionResult)
				{
					return navMeshPosition;
				}
			}
		}
		return Vector3.zero;
	}

	[ClientRpc]
	public void EnterFlightClientRpc(Vector3 newLandingPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(773938193u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref newLandingPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 773938193u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				EnterFlight(newLandingPosition);
			}
		}
	}

	public void SetMechAlertedToThreat()
	{
		if (!isAlerted)
		{
			isAlerted = true;
			alertTimer = 0f;
			LocalLRADAudio.Play();
		}
	}

	[ClientRpc]
	public void SetMechAlertedClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(930524462u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 930524462u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				isAlerted = true;
				alertTimer = 0f;
			}
		}
	}

	public void SetAimingGun(bool setAiming)
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			if (setAiming)
			{
				shootCooldown = 0f;
			}
			aimingGun = setAiming;
			SetChargingForwardOnLocalClient(charging: false);
			if (!aimingGun)
			{
				creatureAnimator.SetBool("AimGun", false);
			}
			SetAimingClientRpc(setAiming);
		}
	}

	[ClientRpc]
	public void SetAimingClientRpc(bool aiming)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(742303271u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref aiming, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 742303271u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
		{
			aimingGun = aiming;
			SetChargingForwardOnLocalClient(charging: false);
			if (!aimingGun)
			{
				creatureAnimator.SetBool("AimGun", false);
			}
		}
	}

	public void StartShootGun()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsServer)
		{
			Vector3 position = gunPoint.position;
			Quaternion rotation = gunPoint.rotation;
			ShootGun(position, ((Quaternion)(ref rotation)).eulerAngles);
			Vector3 position2 = gunPoint.position;
			rotation = gunPoint.rotation;
			ShootGunClientRpc(position2, ((Quaternion)(ref rotation)).eulerAngles);
		}
	}

	[ClientRpc]
	public void ShootGunClientRpc(Vector3 startPos, Vector3 startRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(355979910u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref startPos);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref startRot);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 355979910u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				ShootGun(startPos, startRot);
			}
		}
	}

	public void ShootGun(Vector3 startPos, Vector3 startRot)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		if (creatureAnimator.GetBool("AimGun"))
		{
			creatureAnimator.SetTrigger("ShootGun");
		}
		currentMissileSpeed = 0.2f;
		GameObject obj = Object.Instantiate<GameObject>(missilePrefab, startPos, Quaternion.Euler(startRot), RoundManager.Instance.mapPropsContainer.transform);
		missilesFired++;
		obj.GetComponent<RadMechMissile>().RadMechScript = this;
		gunArmParticle.Play();
		RoundManager.PlayRandomClip(creatureSFX, shootGunSFX);
		if (Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position) < 16f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
		}
	}

	public void StartExplosion(Vector3 explosionPosition, Vector3 forwardRotation, bool calledByClient = false)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsServer)
		{
			SetExplosion(explosionPosition, forwardRotation);
			SetExplosionClientRpc(explosionPosition, forwardRotation);
		}
		else if (calledByClient)
		{
			SetExplosionServerRpc(explosionPosition, forwardRotation);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetExplosionServerRpc(Vector3 explosionPosition, Vector3 forwardRotation)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4127084456u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref explosionPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref forwardRotation);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4127084456u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetExplosionClientRpc(explosionPosition, forwardRotation, calledByClient: true);
			}
		}
	}

	[ClientRpc]
	public void SetExplosionClientRpc(Vector3 explosionPosition, Vector3 forwardRotation, bool calledByClient = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2435131453u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref explosionPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref forwardRotation);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref calledByClient, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2435131453u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (!((NetworkBehaviour)this).IsServer || calledByClient))
			{
				SetExplosion(explosionPosition, forwardRotation);
			}
		}
	}

	public void SetExplosion(Vector3 explosionPosition, Vector3 forwardRotation)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, explosionPosition - forwardRotation * 0.1f) < 8f)
		{
			Landmine.SpawnExplosion(explosionPosition - forwardRotation * 0.1f, spawnExplosionEffect: true, 1f, 7f, 30, 65f, explosionPrefab);
		}
		else
		{
			Landmine.SpawnExplosion(explosionPosition - forwardRotation * 0.1f, spawnExplosionEffect: true, 1f, 7f, 30, 35f, explosionPrefab);
		}
		((Component)explosionAudio).transform.position = explosionPosition + Vector3.up * 0.5f;
		RoundManager.PlayRandomClip(explosionAudio, largeExplosionSFX);
		if (!(Vector3.Distance(previousExplosionPosition, explosionPosition) < 4f))
		{
			RaycastHit val = default(RaycastHit);
			if (Physics.Raycast(explosionPosition - forwardRotation * 0.1f, forwardRotation, ref val, 4f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				_ = ((RaycastHit)(ref val)).normal;
			}
			SpawnBlastMark(explosionPosition, Quaternion.Euler(forwardRotation));
		}
	}

	public void AimGunArmTowardsTarget()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		if (!aimingGun || inSpecialAnimation)
		{
			gunArm.rotation = Quaternion.Lerp(gunArm.rotation, defaultArmRotation.rotation, 3f * Time.deltaTime);
			return;
		}
		RoundManager.Instance.tempTransform.position = gunArm.position;
		RoundManager.Instance.tempTransform.LookAt(targetedThreat.lastSeenPosition);
		Transform tempTransform = RoundManager.Instance.tempTransform;
		tempTransform.rotation *= Quaternion.Euler(90f, 0f, 0f);
		RoundManager.Instance.tempTransform.localEulerAngles = new Vector3(gunArm.eulerAngles.x, RoundManager.Instance.tempTransform.localEulerAngles.y, RoundManager.Instance.tempTransform.localEulerAngles.z);
		gunArm.rotation = Quaternion.RotateTowards(gunArm.rotation, RoundManager.Instance.tempTransform.rotation, gunArmSpeed * Time.deltaTime);
		gunArm.localEulerAngles = new Vector3(0f, 0f, gunArm.localEulerAngles.z);
	}

	public void CancelSpecialAnimations()
	{
		if (aimGunCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(aimGunCoroutine);
		}
	}

	public override void FinishedCurrentSearchRoutine()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		base.FinishedCurrentSearchRoutine();
		if (currentBehaviourStateIndex == 0 && ((NetworkBehaviour)this).IsServer && !Physics.Raycast(((Component)this).transform.position, Vector3.up, 60f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			SwitchToBehaviourState(2);
		}
	}

	public override void DoAIInterval()
	{
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			CheckSightForThreat();
			break;
		case 1:
			if (inSpecialAnimation || attemptingGrab)
			{
				break;
			}
			MoveTowardsThreat();
			if (!isAlerted)
			{
				if (alertTimer > 1.4f || (hasLOS && Vector3.Distance(((Component)this).transform.position, focusedThreatTransform.position) < 8f) || Vector3.Distance(((Component)this).transform.position, focusedThreatTransform.position) < 4f)
				{
					SetMechAlertedToThreat();
				}
			}
			else
			{
				if (aimingGun || !(shootCooldown <= 1f))
				{
					break;
				}
				float num = Vector3.Distance(((Component)this).transform.position, focusedThreatTransform.position);
				if (hasLOS)
				{
					if (num > 38f)
					{
						SetChargingForward(setCharging: true);
					}
					else if (!chargingForward)
					{
						SetAimingGun(setAiming: true);
					}
					else if (num < 25f)
					{
						SetAimingGun(setAiming: true);
					}
				}
			}
			break;
		}
	}

	private void LookForPlayersInFlight()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		IVisibleThreat visibleThreat = default(IVisibleThreat);
		RaycastHit val = default(RaycastHit);
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (CheckLineOfSightForPosition(((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position, 35f, 120, -1f, flyingModeEye) && ((Component)StartOfRound.Instance.allPlayerScripts[i]).TryGetComponent<IVisibleThreat>(ref visibleThreat) && !(visibleThreat.GetVisibility() < 0.8f) && Physics.Raycast(((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position, Vector3.down, ref val, 7f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				ChangeFlightLandingPosition(((RaycastHit)(ref val)).point);
				break;
			}
		}
	}

	public void MoveTowardsThreat()
	{
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		if (targetedThreat.threatScript == null || (Object)(object)focusedThreatTransform == (Object)null)
		{
			if (!CheckSightForThreat())
			{
				losTimer = 0f;
				SwitchToBehaviourState(0);
			}
			return;
		}
		if (!lostCreatureInChase)
		{
			if (lostCreatureInChaseDebounce)
			{
				lostCreatureInChaseDebounce = false;
				SetLostCreatureInChaseClientRpc(lostInChase: false);
				losTimer = 0f;
			}
			if (searchForPlayers.inProgress)
			{
				StopSearch(searchForPlayers);
			}
			hasLOS = CheckLineOfSightForPosition(focusedThreatTransform.position) && targetedThreat.threatScript.GetVisibility() > 0f;
			if (hasLOS || (losTimer < 2f && Vector3.Distance(focusedThreatTransform.position, ((Component)this).transform.position) < 14f))
			{
				losTimer = 0f;
				alertTimer += AIIntervalTime * Mathf.Max(targetedThreat.threatScript.GetVisibility(), 0.3f);
			}
			else
			{
				if (!aimingGun)
				{
					losTimer += AIIntervalTime;
					alertTimer = Mathf.Max(alertTimer - AIIntervalTime, 0f);
				}
				if (CheckSightForThreat())
				{
					hasLOS = true;
					return;
				}
			}
			if (hasLOS != SyncedLOSState)
			{
				syncLOSInterval += AIIntervalTime;
				if (syncLOSInterval > 0.6f)
				{
					SyncedLOSState = hasLOS;
					SetHasLineOfSightClientRpc(hasLOS);
				}
			}
			checkForPathInterval = (checkForPathInterval + 1) % 10;
			if (!SetDestinationToPosition(targetedThreat.lastSeenPosition, checkForPathInterval == 0) || Vector3.Distance(agent.destination, ((Component)this).transform.position) < 1.75f || losTimer > 10f)
			{
				lostCreatureInChase = true;
			}
			return;
		}
		if (!lostCreatureInChaseDebounce)
		{
			lostCreatureInChaseDebounce = true;
			losTimer = 0f;
			SetLostCreatureInChaseClientRpc(lostInChase: true);
			SetChargingForwardOnLocalClient(charging: false);
			if (!searchForPlayers.inProgress)
			{
				StartSearch(((Component)this).transform.position, searchForPlayers);
			}
		}
		if (CheckLineOfSightForPosition(focusedThreatTransform.position) && targetedThreat.threatScript.GetVisibility() > 0f && SetDestinationToPosition(targetedThreat.lastSeenPosition, checkForPath: true))
		{
			targetedThreat.lastSeenPosition = focusedThreatTransform.position;
			lostCreatureInChase = false;
		}
		else if (CheckSightForThreat())
		{
			lostCreatureInChase = false;
		}
		else if (!aimingGun)
		{
			losTimer += AIIntervalTime;
			if (losTimer > 10f || (losTimer > 5f && Vector3.Distance(((Component)this).transform.position, targetedThreat.lastSeenPosition) < 2f))
			{
				losTimer = 0f;
				SwitchToBehaviourState(0);
			}
		}
	}

	[ClientRpc]
	public void SetHasLineOfSightClientRpc(bool hasLineOfSight)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3895603057u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref hasLineOfSight, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3895603057u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				hasLOS = hasLineOfSight;
			}
		}
	}

	[ClientRpc]
	public void SetLostCreatureInChaseClientRpc(bool lostInChase)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1452186173u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref lostInChase, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1452186173u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				lostCreatureInChase = lostInChase;
				SetChargingForwardOnLocalClient(charging: false);
			}
		}
	}

	public override void Update()
	{
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_050d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0513: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_053d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0552: Unknown result type (might be due to invalid IL or missing references)
		//IL_056d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0581: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_034c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e3: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		timeSinceGrabbingPlayer += Time.deltaTime;
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		beginChargingTimer += Time.deltaTime;
		if (chargingForward)
		{
			chargeForwardAudio.volume = Mathf.Lerp(chargeForwardAudio.volume, 0.35f, 2f * Time.deltaTime);
			if (!chargeForwardAudio.isPlaying)
			{
				chargeForwardAudio.Play();
			}
		}
		else
		{
			if (!engineSFX.isPlaying && !inSky)
			{
				engineSFX.Play();
			}
			if (chargeForwardAudio.volume > 0.02f)
			{
				chargeForwardAudio.volume = Mathf.Lerp(chargeForwardAudio.volume, 0f, 2f * Time.deltaTime);
			}
			else if (chargeForwardAudio.isPlaying)
			{
				chargeForwardAudio.Stop();
			}
		}
		if (!ventAnimationFinished)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			flyingDistantAudio.volume = Mathf.Lerp(flyingDistantAudio.volume, 0f, 2f * Time.deltaTime);
			if (!inSpecialAnimation)
			{
				if (currentBehaviourStateIndex != previousBehaviour)
				{
					lostCreatureInChase = false;
					timeBetweenSteps = 0.7f;
					DisableSpotlight();
					isAlerted = false;
					alertTimer = 0f;
					LocalLRADAudio.Stop();
					LocalLRADAudio2.Stop();
					if (aimingGun && ((NetworkBehaviour)this).IsServer)
					{
						SetAimingGun(setAiming: false);
					}
					SetChargingForwardOnLocalClient(charging: false);
					previousBehaviour = currentBehaviourStateIndex;
				}
				if (!((NetworkBehaviour)this).IsServer)
				{
					break;
				}
				if (!searchForPlayers.inProgress)
				{
					StartSearch(((Component)this).transform.position, searchForPlayers);
				}
			}
			if (((NetworkBehaviour)this).IsServer && currentBehaviourStateIndex != previousBehaviour && previousBehaviourStateIndex == 2)
			{
				finishingFlight = false;
				if (inFlyingMode)
				{
					inFlyingMode = false;
					disableWalking = false;
				}
				if (!inTorchPlayerAnimation)
				{
					inSpecialAnimation = false;
				}
			}
			break;
		case 1:
			flyingDistantAudio.volume = Mathf.Lerp(flyingDistantAudio.volume, 0f, 2f * Time.deltaTime);
			if (inSpecialAnimation)
			{
				break;
			}
			if (currentBehaviourStateIndex != previousBehaviour)
			{
				EnableSpotlight();
				previousBehaviour = currentBehaviourStateIndex;
			}
			if (aimingGun)
			{
				shootCooldown = Mathf.Min(shootCooldown + Time.deltaTime * shootUptime, 10f);
				if (!inSpecialAnimation)
				{
					AimAndShootCycle();
				}
			}
			else
			{
				shootCooldown = Mathf.Max(shootCooldown - Time.deltaTime * shootDowntime, 0f);
			}
			if (hasLOS && (Object)(object)focusedThreatTransform != (Object)null)
			{
				targetedThreat.lastSeenPosition = focusedThreatTransform.position + targetedThreat.threatScript.GetThreatVelocity();
			}
			if (isAlerted)
			{
				timeBetweenSteps = 0.2f;
			}
			else if (lostCreatureInChase)
			{
				timeBetweenSteps = 0.7f;
			}
			else
			{
				timeBetweenSteps = 1.1f;
			}
			break;
		case 2:
			if (currentBehaviourStateIndex != previousBehaviour)
			{
				if (previousBehaviour == 1)
				{
					DisableSpotlight();
				}
				previousBehaviour = currentBehaviourStateIndex;
			}
			if (searchForPlayers.inProgress)
			{
				StopSearch(searchForPlayers);
				break;
			}
			if (finishingFlight)
			{
				creatureAnimator.SetBool("Flying", false);
				flyTimer += Time.deltaTime;
				if (!inSky || flyTimer > 10f)
				{
					inFlyingMode = false;
					((Behaviour)agent).enabled = true;
					inSpecialAnimation = false;
					disableWalking = false;
					if (smokeRightLeg.isPlaying)
					{
						smokeRightLeg.Stop();
						smokeLeftLeg.Stop();
					}
					if (((NetworkBehaviour)this).IsServer)
					{
						disableWalking = false;
						((Behaviour)agent).enabled = true;
						finishingFlight = false;
						SwitchToBehaviourState(0);
						return;
					}
				}
			}
			else if (inFlyingMode)
			{
				flyTimer += Time.deltaTime;
				if (inSky || flyTimer > 10f)
				{
					flyingDistantAudio.volume = Mathf.Lerp(flyingDistantAudio.volume, 1f, 2f * Time.deltaTime);
					inSky = true;
					((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, landingPosition, 12f * Time.deltaTime);
					RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
					RoundManager.Instance.tempTransform.LookAt(landingPosition);
					((Component)this).transform.eulerAngles = new Vector3(0f, Mathf.LerpAngle(((Component)this).transform.eulerAngles.y, RoundManager.Instance.tempTransform.eulerAngles.y, 2f * Time.deltaTime), 0f);
					if (((NetworkBehaviour)this).IsServer && Vector3.Distance(((Component)this).transform.position, new Vector3(landingPosition.x, ((Component)this).transform.position.y, landingPosition.z)) < 0.4f)
					{
						EndFlight();
					}
					else if (((NetworkBehaviour)this).IsOwner)
					{
						if (inFlyingMode && inSky && !changedDirectionInFlight)
						{
							LookForPlayersInFlight();
						}
						break;
					}
				}
				else
				{
					flyingDistantAudio.volume = Mathf.Lerp(flyingDistantAudio.volume, 0f, 2f * Time.deltaTime);
				}
			}
			if (!((NetworkBehaviour)this).IsServer)
			{
				return;
			}
			if (!inFlyingMode)
			{
				disableWalking = true;
				if (!takingStep)
				{
					StartFlying();
				}
			}
			break;
		}
		if (!inSpecialAnimation)
		{
			AttemptGrabIfClose();
			DoFootstepCycle();
			AimGunArmTowardsTarget();
			TurnTorsoToTarget();
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (!(timeSinceGrabbingPlayer < 1f) && attemptingGrab && !inSpecialAnimation && !GameNetworkManager.Instance.localPlayerController.isInElevator)
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
			if ((Object)(object)playerControllerB != (Object)null && !Physics.Linecast(centerPosition.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position + Vector3.up * 0.6f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				timeSinceGrabbingPlayer = 0f;
				GrabPlayerServerRpc((int)playerControllerB.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void GrabPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3707286996u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3707286996u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && attemptingGrab && !inTorchPlayerAnimation && !Object.op_Implicit((Object)(object)inSpecialAnimationWithPlayer) && !inSpecialAnimation && !StartOfRound.Instance.allPlayerScripts[playerId].isPlayerDead && !Object.op_Implicit((Object)(object)StartOfRound.Instance.allPlayerScripts[playerId].inAnimationWithEnemy))
		{
			inTorchPlayerAnimation = true;
			inSpecialAnimationWithPlayer = StartOfRound.Instance.allPlayerScripts[playerId];
			inSpecialAnimation = true;
			((Behaviour)agent).enabled = false;
			attemptingGrab = false;
			int enemyYRot = (int)((Component)this).transform.eulerAngles.y;
			RaycastHit val3 = default(RaycastHit);
			if (Physics.Raycast(centerPosition.position, centerPosition.forward, ref val3, 6f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				enemyYRot = (int)RoundManager.Instance.YRotationThatFacesTheFarthestFromPosition(centerPosition.position, 20f, 5);
			}
			GrabPlayerClientRpc(playerId, ((Component)this).transform.position, enemyYRot);
		}
	}

	[ClientRpc]
	public void GrabPlayerClientRpc(int playerId, Vector3 enemyPosition, int enemyYRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2279077176u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref enemyPosition);
				BytePacker.WriteValueBitPacked(val2, enemyYRot);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2279077176u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				BeginTorchPlayer(StartOfRound.Instance.allPlayerScripts[playerId], enemyPosition, enemyYRot);
			}
		}
	}

	private void BeginTorchPlayer(PlayerControllerB playerBeingTorched, Vector3 enemyPosition, int enemyYRot)
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		inSpecialAnimationWithPlayer = playerBeingTorched;
		if (inSpecialAnimationWithPlayer.inSpecialInteractAnimation && (Object)(object)inSpecialAnimationWithPlayer.currentTriggerInAnimationWith != (Object)null)
		{
			inSpecialAnimationWithPlayer.currentTriggerInAnimationWith.CancelAnimationExternally();
		}
		inSpecialAnimationWithPlayer.inSpecialInteractAnimation = true;
		inSpecialAnimationWithPlayer.inAnimationWithEnemy = this;
		inSpecialAnimationWithPlayer.isInElevator = false;
		inSpecialAnimationWithPlayer.isInHangarShipRoom = false;
		inSpecialAnimationWithPlayer.freeRotationInInteractAnimation = true;
		if (torchPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(torchPlayerCoroutine);
		}
		torchPlayerCoroutine = ((MonoBehaviour)this).StartCoroutine(TorchPlayerAnimation(enemyPosition, enemyYRot));
	}

	private IEnumerator TorchPlayerAnimation(Vector3 enemyPosition, int enemyYRot)
	{
		creatureAnimator.SetBool("AttemptingGrab", true);
		creatureAnimator.SetBool("GrabSuccessful", true);
		creatureAnimator.SetBool("GrabUnsuccessful", false);
		float startTime = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => blowtorchActivated || Time.realtimeSinceStartup - startTime > 6f));
		startTime = Time.realtimeSinceStartup;
		while (blowtorchActivated && Time.realtimeSinceStartup - startTime < 6f)
		{
			yield return (object)new WaitForSeconds(0.25f);
			inSpecialAnimationWithPlayer.DamagePlayer(20, hasDamageSFX: true, callRPC: true, CauseOfDeath.Burning, 6);
		}
		if ((Object)(object)inSpecialAnimationWithPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController && !inSpecialAnimationWithPlayer.isPlayerDead)
		{
			inSpecialAnimationWithPlayer.KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Burning, 6);
		}
		yield return (object)new WaitForSeconds(1.5f);
		CancelTorchPlayerAnimation();
		if (((NetworkBehaviour)this).IsServer)
		{
			inTorchPlayerAnimation = false;
			inSpecialAnimationWithPlayer = null;
			inSpecialAnimation = false;
			((Behaviour)agent).enabled = true;
		}
	}

	public void CancelTorchPlayerAnimation()
	{
		inTorchPlayerAnimation = false;
		inSpecialAnimation = false;
		disableWalking = false;
		attemptGrabTimer = 5f;
		if (((NetworkBehaviour)this).IsServer)
		{
			((Behaviour)agent).enabled = true;
		}
		creatureAnimator.SetBool("GrabSuccessful", false);
		creatureAnimator.SetBool("AttemptingGrab", false);
		creatureAnimator.SetBool("GrabUnsuccessful", false);
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null)
		{
			inSpecialAnimationWithPlayer.inSpecialInteractAnimation = false;
			inSpecialAnimationWithPlayer.inAnimationWithEnemy = null;
			inSpecialAnimationWithPlayer.freeRotationInInteractAnimation = false;
			if ((Object)(object)inSpecialAnimationWithPlayer.deadBody != (Object)null)
			{
				inSpecialAnimationWithPlayer.deadBody.matchPositionExactly = false;
				inSpecialAnimationWithPlayer.deadBody.attachedLimb = null;
				inSpecialAnimationWithPlayer.deadBody.attachedTo = null;
			}
			inSpecialAnimationWithPlayer.ResetZAndXRotation();
			inSpecialAnimationWithPlayer = null;
		}
		if (blowtorchActivated)
		{
			DisableBlowtorch();
		}
		if (torchPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(torchPlayerCoroutine);
		}
	}

	public void StartGrabAttempt()
	{
		if (currentBehaviourStateIndex != 2)
		{
			attemptingGrab = true;
			attemptGrabTimer = 1.5f;
			creatureAnimator.SetBool("AttemptingGrab", true);
			creatureAnimator.SetBool("GrabUnsuccessful", false);
			creatureAnimator.SetBool("GrabSuccessful", false);
			disableWalking = true;
			StartGrabAttemptClientRpc();
		}
	}

	[ClientRpc]
	public void StartGrabAttemptClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1073473023u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1073473023u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				creatureAnimator.SetBool("AttemptingGrab", true);
				creatureAnimator.SetBool("GrabUnsuccessful", false);
				creatureAnimator.SetBool("GrabSuccessful", false);
				attemptingGrab = true;
			}
		}
	}

	public void FinishAttemptGrab()
	{
		attemptingGrab = false;
		attemptGrabTimer = 5f;
		creatureAnimator.SetBool("GrabUnsuccessful", true);
		creatureAnimator.SetBool("AttemptingGrab", false);
		disableWalking = false;
		FinishAttemptingGrabClientRpc();
	}

	[ClientRpc]
	public void FinishAttemptingGrabClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3684373613u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3684373613u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				attemptingGrab = false;
				disableWalking = false;
				creatureAnimator.SetBool("GrabUnsuccessful", true);
				creatureAnimator.SetBool("AttemptingGrab", false);
			}
		}
	}

	public void AttemptGrabIfClose()
	{
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer || inSpecialAnimation || currentBehaviourStateIndex == 2)
		{
			return;
		}
		if (waitingToAttemptGrab)
		{
			if (!takingStep)
			{
				waitingToAttemptGrab = false;
				StartGrabAttempt();
			}
		}
		else if (attemptingGrab)
		{
			attemptGrabTimer -= Time.deltaTime;
			if (attemptGrabTimer < 0f)
			{
				FinishAttemptGrab();
			}
		}
		else if (attemptGrabTimer < 0f)
		{
			for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
			{
				if (StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled && Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position) < 5.2f)
				{
					waitingToAttemptGrab = true;
					disableWalking = true;
					return;
				}
			}
			attemptGrabTimer = 0.4f;
		}
		else
		{
			attemptGrabTimer -= Time.deltaTime;
		}
	}

	public void AimAndShootCycle()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (takingStep || !(stunNormalizedTimer <= 0f))
		{
			return;
		}
		creatureAnimator.SetBool("AimGun", true);
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (shootTimer > fireRate)
		{
			float num = Vector3.Distance(targetedThreat.lastSeenPosition, ((Component)this).transform.position);
			if (shootCooldown > 4.75f || chargingForward)
			{
				SetAimingGun(setAiming: false);
				return;
			}
			if (!hadLOSDuringLastShot && (!hasLOS || num < 6f))
			{
				SetAimingGun(setAiming: false);
				return;
			}
			shootTimer = 0f + Random.Range((0f - fireRateVariance) * 0.5f, fireRateVariance * 0.5f);
			StartShootGun();
			hadLOSDuringLastShot = hasLOS && num < 40f;
		}
		else
		{
			shootTimer += Time.deltaTime;
		}
	}

	public void TurnTorsoToTarget()
	{
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		if (currentBehaviourStateIndex == 1 && !lostCreatureInChase && Vector3.Distance(((Component)this).transform.position, targetedThreat.lastSeenPosition) > 3f)
		{
			RoundManager.Instance.tempTransform.position = torsoContainer.position + Vector3.up * 1f;
			RoundManager.Instance.tempTransform.LookAt(targetedThreat.lastSeenPosition);
			Transform tempTransform = RoundManager.Instance.tempTransform;
			tempTransform.rotation *= Quaternion.Euler(0f, 90f, 0f);
			float num = 0f;
			if (aimingGun)
			{
				num = Vector3.Angle(targetedThreat.lastSeenPosition - ((Component)this).transform.position, ((Component)this).transform.forward) * forwardAngleCompensation;
			}
			RoundManager.Instance.tempTransform.localEulerAngles = new Vector3(torsoContainer.eulerAngles.x, torsoContainer.eulerAngles.y, RoundManager.Instance.tempTransform.localEulerAngles.z + num);
			torsoContainer.rotation = Quaternion.RotateTowards(torsoContainer.rotation, RoundManager.Instance.tempTransform.rotation, 80f * Time.deltaTime);
		}
		else
		{
			torsoContainer.rotation = Quaternion.Lerp(torsoContainer.rotation, torsoDefaultRotation.rotation, 3f * Time.deltaTime);
		}
	}

	public bool CheckSightForThreat()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_030d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return false;
		}
		int num = Physics.OverlapSphereNonAlloc(eye.position + eye.forward * 58f + -eye.up * 10f, 60f, RoundManager.Instance.tempColliderResults, visibleThreatsMask, (QueryTriggerInteraction)2);
		Collider val = null;
		RaycastHit val2 = default(RaycastHit);
		IVisibleThreat visibleThreat = default(IVisibleThreat);
		for (int i = 0; i < num; i++)
		{
			if ((Object)(object)RoundManager.Instance.tempColliderResults[i] == (Object)(object)ownCollider)
			{
				continue;
			}
			if ((Object)(object)RoundManager.Instance.tempColliderResults[i] == (Object)(object)targetedThreatCollider && currentBehaviourStateIndex == 1)
			{
				val = RoundManager.Instance.tempColliderResults[i];
				continue;
			}
			float num2 = Vector3.Distance(eye.position, ((Component)RoundManager.Instance.tempColliderResults[i]).transform.position);
			float num3 = Vector3.Angle(((Component)RoundManager.Instance.tempColliderResults[i]).transform.position - eye.position, eye.forward);
			if (num2 > 2f && num3 > fov)
			{
				continue;
			}
			if (Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.7f, ((Component)RoundManager.Instance.tempColliderResults[i]).transform.position + Vector3.up * 0.5f, ref val2, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				if (debugEnemyAI)
				{
					Debug.DrawRay(((RaycastHit)(ref val2)).point, Vector3.up * 0.5f, Color.magenta, AIIntervalTime);
				}
				continue;
			}
			EnemyAI component = ((Component)((Component)RoundManager.Instance.tempColliderResults[i]).transform).GetComponent<EnemyAI>();
			if ((!((Object)(object)component != (Object)null) || !(((object)component).GetType() == typeof(RadMechAI))) && ((Component)((Component)RoundManager.Instance.tempColliderResults[i]).transform).TryGetComponent<IVisibleThreat>(ref visibleThreat))
			{
				float visibility = visibleThreat.GetVisibility();
				if (!(visibility < 0.2f) && (!(visibility <= 0.58f) || !(num2 > 30f)))
				{
					targetedThreatCollider = RoundManager.Instance.tempColliderResults[i];
					SetTargetedThreat(visibleThreat, ((Component)RoundManager.Instance.tempColliderResults[i]).transform.position + Vector3.up * 0.5f, num2);
					focusedThreatTransform = visibleThreat.GetThreatTransform();
					NetworkObject component2 = ((Component)focusedThreatTransform).gameObject.GetComponent<NetworkObject>();
					SwitchToBehaviourStateOnLocalClient(1);
					SetTargetToThreatClientRpc(NetworkObjectReference.op_Implicit(component2), targetedThreat.lastSeenPosition);
					return true;
				}
			}
		}
		if (Object.op_Implicit((Object)(object)val))
		{
			if (Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.7f, ((Component)val).transform.position + Vector3.up * 0.5f, ref val2, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				return false;
			}
			if (!((Component)((Component)val).transform).TryGetComponent<IVisibleThreat>(ref visibleThreat))
			{
				return false;
			}
			if (visibleThreat.GetVisibility() < 0.2f)
			{
				return false;
			}
			return true;
		}
		return false;
	}

	[ClientRpc]
	public void SetTargetToThreatClientRpc(NetworkObjectReference netObject, Vector3 lastSeenPos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1292035047u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObject, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref lastSeenPos);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1292035047u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref netObject)).TryGet(ref val3, (NetworkManager)null))
		{
			IVisibleThreat visibleThreat = default(IVisibleThreat);
			if (!((Component)((Component)val3).transform).TryGetComponent<IVisibleThreat>(ref visibleThreat))
			{
				Debug.LogError((object)"Error: RadMech could not get IVisibleThreat in transform of network object sent in RPC (SetTargetToThreatClientRpc)");
				return;
			}
			focusedThreatTransform = visibleThreat.GetThreatTransform();
			float dist = Vector3.Distance(eye.position, focusedThreatTransform.position);
			SetTargetedThreat(visibleThreat, lastSeenPos, dist);
		}
		else
		{
			Debug.LogError((object)$"Error: RadMech could not find threat NetworkObject sent by RPC through reference; ID: {((NetworkObjectReference)(ref netObject)).NetworkObjectId}");
		}
		SwitchToBehaviourStateOnLocalClient(1);
	}

	public void SetTargetedThreat(IVisibleThreat newThreat, Vector3 lastSeenPos, float dist)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		targetedThreat.type = newThreat.type;
		targetedThreat.timeLastSeen = Time.realtimeSinceStartup;
		targetedThreat.lastSeenPosition = lastSeenPos;
		targetedThreat.distanceToThreat = dist;
		targetedThreat.threatLevel = newThreat.GetThreatLevel(eye.position);
		targetedThreat.threatScript = newThreat;
	}

	private void DoFootstepCycle()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (chargingForward && !disableWalking && !aimingGun)
		{
			if (beginChargingTimer < 0.4f)
			{
				agent.speed = 4f;
				return;
			}
			agent.speed = chargeForwardSpeed;
			if (startedChargeEffect)
			{
				return;
			}
			startedChargeEffect = true;
			startChargingEffectContainer.SetActive(true);
			engineSFX.Stop();
			float num = Vector3.Distance(((Component)this).transform.position - ((Component)this).transform.forward * 5f, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position);
			if (num < 25f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
				if (num < 12f)
				{
					Landmine.SpawnExplosion(((Component)this).transform.position + Vector3.up * 0.2f, spawnExplosionEffect: false, 2f, 5f, 30, 45f);
				}
			}
		}
		else if (takingStep)
		{
			if (walkStepTimer <= 0f)
			{
				walkStepTimer = timeBetweenSteps;
				takingStep = false;
				agent.speed = 0f;
			}
			else
			{
				agent.speed = stepMovementSpeed;
				walkStepTimer -= Time.deltaTime;
			}
		}
		else if (!disableWalking && !aimingGun && !(stunNormalizedTimer > 0f))
		{
			if (walkStepTimer <= 0f)
			{
				walkStepTimer = timeToTakeStep;
				leftFoot = !leftFoot;
				takingStep = true;
				TakeStepForwardAnimation(leftFoot);
			}
			else
			{
				walkStepTimer -= Time.deltaTime;
			}
		}
	}

	private void TakeStepForwardAnimation(bool leftFootForward)
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			creatureAnimator.SetBool("leftFootForward", leftFootForward);
			if (leftFootForward)
			{
				TakeLeftStepForwardClientRpc();
			}
			else
			{
				TakeRightStepForwardClientRpc();
			}
		}
	}

	[ClientRpc]
	public void TakeLeftStepForwardClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4188407647u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4188407647u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				creatureAnimator.SetBool("leftFootForward", true);
			}
		}
	}

	[ClientRpc]
	public void TakeRightStepForwardClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3884530962u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3884530962u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				creatureAnimator.SetBool("leftFootForward", false);
			}
		}
	}

	public void EnableBlowtorch()
	{
		((Component)blowtorchParticle).gameObject.SetActive(false);
		((Component)blowtorchParticle).gameObject.SetActive(true);
		blowtorchParticle.Play();
		blowtorchAudio.Play();
		blowtorchActivated = true;
	}

	public void DisableBlowtorch()
	{
		blowtorchParticle.Stop();
		blowtorchAudio.Stop();
		blowtorchActivated = false;
	}

	public void DisableThrusterSmoke()
	{
		smokeLeftLeg.Stop();
		smokeRightLeg.Stop();
	}

	public void EnableThrusterSmoke()
	{
		smokeLeftLeg.Play();
		smokeRightLeg.Play();
	}

	public void HasEnteredSky()
	{
		inSky = true;
		engineSFX.Stop();
	}

	public void FinishFlyingAnimation()
	{
		inSky = false;
	}

	public void FlickerFace()
	{
		creatureVoice.PlayOneShot(spotlightFlicker);
		if (spotlightCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(spotlightCoroutine);
			spotlightCoroutine = null;
		}
		spotlightCoroutine = ((MonoBehaviour)this).StartCoroutine(flickerSpotlightAnim());
	}

	private IEnumerator flickerSpotlightAnim()
	{
		for (int i = 0; i < 5; i++)
		{
			spotlight.SetActive(true);
			((Renderer)skinnedMeshRenderers[0]).sharedMaterial = spotlightMat;
			yield return (object)new WaitForSeconds(Random.Range(0.06f, 0.3f));
			spotlight.SetActive(false);
			((Renderer)skinnedMeshRenderers[0]).sharedMaterial = defaultMat;
		}
	}

	public void EnableSpotlight()
	{
		spotlight.SetActive(true);
		((Renderer)skinnedMeshRenderers[0]).sharedMaterial = spotlightMat;
		spotlightOnAudio.Play();
	}

	public void DisableSpotlight()
	{
		spotlight.SetActive(false);
		((Renderer)skinnedMeshRenderers[0]).sharedMaterial = defaultMat;
		creatureVoice.PlayOneShot(spotlightOff);
	}

	public void StompLeftFoot()
	{
		Stomp(leftFootPoint, leftFootParticle);
	}

	public void StompRightFoot()
	{
		Stomp(rightFootPoint, rightFootParticle);
	}

	public void StompBothFeet()
	{
		Stomp(((Component)this).transform, leftFootParticle, rightFootParticle, 10f);
	}

	private void Stomp(Transform stompTransform, ParticleSystem particle, ParticleSystem particle2 = null, float radius = 5f)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
		float num = Vector3.Distance(((Component)localPlayerController).transform.position, stompTransform.position);
		particle.Play();
		if ((Object)(object)particle2 != (Object)null)
		{
			particle2.Play();
		}
		RoundManager.PlayRandomClip(creatureSFX, enemyType.audioClips, randomize: true, 1f, 1115, 4);
		if (num < 12f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
		}
		else if (num < 24f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
		}
		Vector3 val = Vector3.Normalize(((Component)localPlayerController.gameplayCamera).transform.position - stompTransform.position) * 15f / Vector3.Distance(((Component)localPlayerController.gameplayCamera).transform.position, stompTransform.position);
		if (num < radius)
		{
			if ((double)num < (double)radius * 0.175)
			{
				localPlayerController.DamagePlayer(70, hasDamageSFX: true, callRPC: true, CauseOfDeath.Crushing, 0, fallDamage: false, Vector3.down * 40f);
			}
			else if (num < radius * 0.5f)
			{
				localPlayerController.DamagePlayer(30, hasDamageSFX: true, callRPC: true, CauseOfDeath.Crushing, 0, fallDamage: false, Vector3.down * 40f);
			}
			localPlayerController.externalForceAutoFade += val;
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_RadMechAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3910336672u, new RpcReceiveHandler(__rpc_handler_3910336672));
		NetworkManager.__rpc_func_table.Add(492577947u, new RpcReceiveHandler(__rpc_handler_492577947));
		NetworkManager.__rpc_func_table.Add(2143274786u, new RpcReceiveHandler(__rpc_handler_2143274786));
		NetworkManager.__rpc_func_table.Add(220033949u, new RpcReceiveHandler(__rpc_handler_220033949));
		NetworkManager.__rpc_func_table.Add(773938193u, new RpcReceiveHandler(__rpc_handler_773938193));
		NetworkManager.__rpc_func_table.Add(930524462u, new RpcReceiveHandler(__rpc_handler_930524462));
		NetworkManager.__rpc_func_table.Add(742303271u, new RpcReceiveHandler(__rpc_handler_742303271));
		NetworkManager.__rpc_func_table.Add(355979910u, new RpcReceiveHandler(__rpc_handler_355979910));
		NetworkManager.__rpc_func_table.Add(4127084456u, new RpcReceiveHandler(__rpc_handler_4127084456));
		NetworkManager.__rpc_func_table.Add(2435131453u, new RpcReceiveHandler(__rpc_handler_2435131453));
		NetworkManager.__rpc_func_table.Add(3895603057u, new RpcReceiveHandler(__rpc_handler_3895603057));
		NetworkManager.__rpc_func_table.Add(1452186173u, new RpcReceiveHandler(__rpc_handler_1452186173));
		NetworkManager.__rpc_func_table.Add(3707286996u, new RpcReceiveHandler(__rpc_handler_3707286996));
		NetworkManager.__rpc_func_table.Add(2279077176u, new RpcReceiveHandler(__rpc_handler_2279077176));
		NetworkManager.__rpc_func_table.Add(1073473023u, new RpcReceiveHandler(__rpc_handler_1073473023));
		NetworkManager.__rpc_func_table.Add(3684373613u, new RpcReceiveHandler(__rpc_handler_3684373613));
		NetworkManager.__rpc_func_table.Add(1292035047u, new RpcReceiveHandler(__rpc_handler_1292035047));
		NetworkManager.__rpc_func_table.Add(4188407647u, new RpcReceiveHandler(__rpc_handler_4188407647));
		NetworkManager.__rpc_func_table.Add(3884530962u, new RpcReceiveHandler(__rpc_handler_3884530962));
	}

	private static void __rpc_handler_3910336672(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).ChangeBroadcastClipClientRpc(clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_492577947(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newLandingPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newLandingPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).ChangeFlightLandingPositionClientRpc(newLandingPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2143274786(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).EndFlightClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_220033949(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool chargingForwardClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref chargingForwardClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).SetChargingForwardClientRpc(chargingForwardClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_773938193(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newLandingPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newLandingPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).EnterFlightClientRpc(newLandingPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_930524462(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).SetMechAlertedClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_742303271(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool aimingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref aimingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).SetAimingClientRpc(aimingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_355979910(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 startPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref startPos);
			Vector3 startRot = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref startRot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).ShootGunClientRpc(startPos, startRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4127084456(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 explosionPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref explosionPosition);
			Vector3 forwardRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref forwardRotation);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RadMechAI)(object)target).SetExplosionServerRpc(explosionPosition, forwardRotation);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2435131453(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 explosionPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref explosionPosition);
			Vector3 forwardRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref forwardRotation);
			bool calledByClient = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref calledByClient, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).SetExplosionClientRpc(explosionPosition, forwardRotation, calledByClient);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3895603057(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool hasLineOfSightClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref hasLineOfSightClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).SetHasLineOfSightClientRpc(hasLineOfSightClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1452186173(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool lostCreatureInChaseClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref lostCreatureInChaseClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).SetLostCreatureInChaseClientRpc(lostCreatureInChaseClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3707286996(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RadMechAI)(object)target).GrabPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2279077176(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			Vector3 enemyPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref enemyPosition);
			int enemyYRot = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref enemyYRot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).GrabPlayerClientRpc(playerId, enemyPosition, enemyYRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1073473023(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).StartGrabAttemptClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3684373613(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).FinishAttemptingGrabClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1292035047(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference netObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref netObject, default(ForNetworkSerializable));
			Vector3 lastSeenPos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref lastSeenPos);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).SetTargetToThreatClientRpc(netObject, lastSeenPos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4188407647(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).TakeLeftStepForwardClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3884530962(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadMechAI)(object)target).TakeRightStepForwardClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "RadMechAI";
	}
}
