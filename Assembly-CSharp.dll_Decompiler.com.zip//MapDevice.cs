using System.Collections;
using UnityEngine;

public class MapDevice : GrabbableObject
{
	public Camera mapCamera;

	public Animator mapAnimatorTransition;

	public Light mapLight;

	private Coroutine pingMapCoroutine;

	public override void Start()
	{
		base.Start();
		mapCamera = GameObject.FindGameObjectWithTag("MapCamera").GetComponent<Camera>();
		mapAnimatorTransition = ((Component)mapCamera).gameObject.GetComponentInChildren<Animator>();
		mapLight = ((Component)mapCamera).gameObject.GetComponentInChildren<Light>();
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		if (pingMapCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(pingMapCoroutine);
		}
		pingMapCoroutine = ((MonoBehaviour)this).StartCoroutine(pingMapSystem());
		base.ItemActivate(used);
	}

	private IEnumerator pingMapSystem()
	{
		((Behaviour)mapCamera).enabled = true;
		mapAnimatorTransition.SetTrigger("Transition");
		yield return (object)new WaitForSeconds(0.035f);
		if (playerHeldBy.isInsideFactory)
		{
			((Component)mapCamera).transform.position = new Vector3(((Component)playerHeldBy).transform.position.x + 8.6f, -20f, ((Component)playerHeldBy).transform.position.z - 3f);
		}
		else
		{
			((Component)mapCamera).transform.position = new Vector3(((Component)playerHeldBy).transform.position.x + 8.6f, 50f, ((Component)playerHeldBy).transform.position.z - 3f);
		}
		yield return (object)new WaitForSeconds(0.2f);
		((Behaviour)mapLight).enabled = true;
		mapCamera.Render();
		((Behaviour)mapLight).enabled = false;
		((Behaviour)mapCamera).enabled = false;
	}

	public override void DiscardItem()
	{
		isBeingUsed = false;
		base.DiscardItem();
	}

	public override void EquipItem()
	{
		base.EquipItem();
		playerHeldBy.equippedUsableItemQE = true;
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "MapDevice";
	}
}
