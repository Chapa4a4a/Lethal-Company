using Unity.Netcode;
using UnityEngine;

public class SteamValveHazard : MonoBehaviour
{
	public float valveCrackTime;

	public float valveBurstTime;

	private bool valveHasBurst;

	private bool valveHasCracked;

	private bool valveHasBeenRepaired;

	public InteractTrigger triggerScript;

	[Header("Fog")]
	public Animator fogAnimator;

	public Animator valveAnimator;

	public float fogSizeMultiplier;

	public float currentFogSize;

	[Header("Other Effects")]
	public ParticleSystem valveSteamParticle;

	public AudioClip[] pipeFlowingSFX;

	public AudioClip valveTwistSFX;

	public AudioClip valveBurstSFX;

	public AudioClip valveCrackSFX;

	public AudioClip steamBlowSFX;

	public AudioSource valveAudio;

	public GameObject spawnParticleWhenCracked;

	public SteamValveFixInteraction fixInteract;

	private void Start()
	{
		if (pipeFlowingSFX.Length != 0)
		{
			valveAudio.pitch = Random.Range(0.85f, 1.1f);
			valveAudio.clip = pipeFlowingSFX[Random.Range(0, pipeFlowingSFX.Length)];
			valveAudio.Play();
		}
	}

	private void Update()
	{
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		if (StartOfRound.Instance.allPlayersDead || (Object)(object)NetworkManager.Singleton == (Object)null || !GameNetworkManager.Instance.gameHasStarted)
		{
			return;
		}
		if (valveHasBeenRepaired)
		{
			currentFogSize = Mathf.Clamp(currentFogSize - Time.deltaTime / 4f, 0.01f, 1f * fogSizeMultiplier);
			fogAnimator.SetFloat("time", currentFogSize);
		}
		else if (!valveHasCracked && valveCrackTime > 0f && TimeOfDay.Instance.normalizedTimeOfDay > valveCrackTime)
		{
			valveHasCracked = true;
			CrackValve();
		}
		else if (!valveHasBurst && valveBurstTime > 0f && TimeOfDay.Instance.normalizedTimeOfDay > valveBurstTime)
		{
			valveHasBurst = true;
			BurstValve();
		}
		else if (valveHasBurst && (Object)(object)fogAnimator != (Object)null)
		{
			currentFogSize = Mathf.Clamp(currentFogSize + Time.deltaTime / 12f, 0f, 1f * fogSizeMultiplier);
			fogAnimator.SetFloat("time", currentFogSize);
			if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)valveAudio).transform.position) < 10f)
			{
				HUDManager.Instance.increaseHelmetCondensation = true;
				HUDManager.Instance.DisplayStatusEffect("VISIBILITY LOW!\n\nSteam leak detected in area");
			}
		}
	}

	private void CrackValve()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		valveAudio.PlayOneShot(valveCrackSFX);
		WalkieTalkie.TransmitOneShotAudio(valveAudio, valveCrackSFX);
		if ((Object)(object)valveSteamParticle != (Object)null)
		{
			MainModule main = valveSteamParticle.main;
			((MainModule)(ref main)).loop = false;
			valveSteamParticle.Play();
		}
	}

	private void BurstValve()
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)spawnParticleWhenCracked != (Object)null)
		{
			Object.Instantiate<GameObject>(spawnParticleWhenCracked, ((Component)this).transform.position, Quaternion.identity, RoundManager.Instance.mapPropsContainer.transform);
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		MainModule main = valveSteamParticle.main;
		((MainModule)(ref main)).loop = true;
		valveSteamParticle.Play();
		valveAudio.clip = steamBlowSFX;
		valveAudio.Play();
		valveAudio.PlayOneShot(valveBurstSFX);
		WalkieTalkie.TransmitOneShotAudio(valveAudio, valveBurstSFX);
		if ((Object)(object)triggerScript != (Object)null)
		{
			triggerScript.interactable = true;
		}
	}

	public void FixValveLocalClient()
	{
		if (valveHasBurst && !valveHasBeenRepaired)
		{
			valveSteamParticle.Stop(true, (ParticleSystemStopBehavior)1);
			valveAudio.clip = pipeFlowingSFX[Random.Range(0, pipeFlowingSFX.Length)];
			valveAudio.Play();
			valveAudio.PlayOneShot(valveTwistSFX, 1f);
			WalkieTalkie.TransmitOneShotAudio(valveAudio, valveTwistSFX);
			valveAnimator.SetTrigger("TwistValve");
			valveHasBeenRepaired = true;
			triggerScript.interactable = false;
		}
	}

	public void FixValve()
	{
		fixInteract.FixValve();
	}
}
