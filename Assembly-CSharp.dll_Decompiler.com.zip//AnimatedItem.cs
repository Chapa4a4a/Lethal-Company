using System;
using UnityEngine;

public class AnimatedItem : GrabbableObject
{
	public string grabItemBoolString;

	public string dropItemTriggerString;

	public bool makeAnimationWhenDropping;

	public Animator itemAnimator;

	public AudioSource itemAudio;

	public AudioClip grabAudio;

	public AudioClip dropAudio;

	public bool loopGrabAudio;

	public bool loopDropAudio;

	[Range(0f, 100f)]
	public int chanceToTriggerAnimation = 100;

	public int chanceToTriggerAlternateMesh;

	public Mesh alternateMesh;

	private Mesh normalMesh;

	private Random itemRandomChance;

	public float noiseRange;

	public float noiseLoudness;

	private int timesPlayedInOneSpot;

	private float makeNoiseInterval;

	private Vector3 lastPosition;

	public AudioLowPassFilter itemAudioLowPassFilter;

	private bool wasInPocket;

	public override void Start()
	{
		base.Start();
		itemRandomChance = new Random(StartOfRound.Instance.randomMapSeed + StartOfRound.Instance.currentLevelID + itemProperties.itemId);
		if (chanceToTriggerAlternateMesh > 0)
		{
			normalMesh = ((Component)this).gameObject.GetComponent<MeshFilter>().mesh;
		}
	}

	public override void EquipItem()
	{
		base.EquipItem();
		if ((Object)(object)itemAudioLowPassFilter != (Object)null)
		{
			itemAudioLowPassFilter.cutoffFrequency = 20000f;
		}
		itemAudio.volume = 1f;
		if (chanceToTriggerAlternateMesh > 0)
		{
			if (itemRandomChance.Next(0, 100) < chanceToTriggerAlternateMesh)
			{
				((Component)this).gameObject.GetComponent<MeshFilter>().mesh = alternateMesh;
				itemAudio.Stop();
				return;
			}
			((Component)this).gameObject.GetComponent<MeshFilter>().mesh = normalMesh;
		}
		if (!wasInPocket)
		{
			if (itemRandomChance.Next(0, 100) > chanceToTriggerAnimation)
			{
				itemAudio.Stop();
				return;
			}
		}
		else
		{
			wasInPocket = false;
		}
		if ((Object)(object)itemAnimator != (Object)null)
		{
			itemAnimator.SetBool(grabItemBoolString, true);
		}
		if ((Object)(object)itemAudio != (Object)null)
		{
			itemAudio.clip = grabAudio;
			itemAudio.loop = loopGrabAudio;
			itemAudio.Play();
		}
	}

	public override void DiscardItem()
	{
		base.DiscardItem();
		if ((Object)(object)itemAnimator != (Object)null)
		{
			itemAnimator.SetBool(grabItemBoolString, false);
		}
		if (chanceToTriggerAlternateMesh > 0)
		{
			((Component)this).gameObject.GetComponent<MeshFilter>().mesh = normalMesh;
		}
		if (!makeAnimationWhenDropping)
		{
			itemAudio.Stop();
			return;
		}
		if (itemRandomChance.Next(0, 100) < chanceToTriggerAnimation)
		{
			itemAudio.Stop();
			return;
		}
		if ((Object)(object)itemAnimator != (Object)null)
		{
			itemAnimator.SetTrigger(dropItemTriggerString);
		}
		if ((Object)(object)itemAudio != (Object)null)
		{
			itemAudio.loop = loopDropAudio;
			itemAudio.clip = dropAudio;
			itemAudio.Play();
			if ((Object)(object)itemAudioLowPassFilter != (Object)null)
			{
				itemAudioLowPassFilter.cutoffFrequency = 20000f;
			}
			itemAudio.volume = 1f;
		}
	}

	public override void PocketItem()
	{
		base.PocketItem();
		wasInPocket = true;
		if ((Object)(object)itemAudio != (Object)null)
		{
			if ((Object)(object)itemAudioLowPassFilter != (Object)null)
			{
				itemAudioLowPassFilter.cutoffFrequency = 1700f;
			}
			itemAudio.volume = 0.5f;
		}
	}

	public override void Update()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if ((Object)(object)itemAudio == (Object)null || !itemAudio.isPlaying)
		{
			return;
		}
		if (makeNoiseInterval <= 0f)
		{
			makeNoiseInterval = 0.75f;
			if (Vector3.Distance(lastPosition, ((Component)this).transform.position) < 4f)
			{
				timesPlayedInOneSpot++;
			}
			else
			{
				timesPlayedInOneSpot = 0;
			}
			if (isPocketed)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, noiseRange / 2f, noiseLoudness / 2f, timesPlayedInOneSpot, isInElevator && StartOfRound.Instance.hangarDoorsClosed);
			}
			else
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, noiseRange, noiseLoudness, timesPlayedInOneSpot, isInElevator && StartOfRound.Instance.hangarDoorsClosed);
			}
		}
		else
		{
			makeNoiseInterval -= Time.deltaTime;
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "AnimatedItem";
	}
}
