using System;
using System.Collections;
using Dissonance;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class IngamePlayerSettings : MonoBehaviour
{
	[Serializable]
	public class Settings
	{
		public bool playerHasFinishedSetup;

		public bool startInOnlineMode = true;

		public float gammaSetting;

		public int lookSensitivity = 10;

		public bool invertYAxis;

		public float masterVolume = 1f;

		public int framerateCapIndex;

		public FullScreenMode fullScreenType;

		[Header("MIC SETTINGS")]
		public bool micEnabled = true;

		public bool pushToTalk;

		public int micDeviceIndex;

		public string micDevice = string.Empty;

		[Header("BINDINGS")]
		public string keyBindings = string.Empty;

		[Header("ACCESSIBILITY")]
		public bool spiderSafeMode;

		public Settings(bool finishedSetup = true, bool onlineMode = true)
		{
			playerHasFinishedSetup = finishedSetup;
			startInOnlineMode = onlineMode;
		}

		public void CopySettings(Settings copyFrom)
		{
			//IL_0086: Unknown result type (might be due to invalid IL or missing references)
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			playerHasFinishedSetup = copyFrom.playerHasFinishedSetup;
			startInOnlineMode = copyFrom.startInOnlineMode;
			gammaSetting = copyFrom.gammaSetting;
			lookSensitivity = copyFrom.lookSensitivity;
			micEnabled = copyFrom.micEnabled;
			pushToTalk = copyFrom.pushToTalk;
			micDeviceIndex = copyFrom.micDeviceIndex;
			micDevice = copyFrom.micDevice;
			keyBindings = copyFrom.keyBindings;
			masterVolume = copyFrom.masterVolume;
			framerateCapIndex = copyFrom.framerateCapIndex;
			fullScreenType = copyFrom.fullScreenType;
			invertYAxis = copyFrom.invertYAxis;
			spiderSafeMode = copyFrom.spiderSafeMode;
		}
	}

	public Settings settings;

	public Settings unsavedSettings;

	public AudioSource SettingsAudio;

	public Volume universalVolume;

	private DissonanceComms comms;

	public bool redoLaunchSettings;

	public bool changesNotApplied;

	public RebindingOperation rebindingOperation;

	private SettingsOption currentRebindingKeyUI;

	public PlayerInput playerInput;

	public bool encounteredErrorDuringSave;

	public static IngamePlayerSettings Instance { get; private set; }

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
			((MonoBehaviour)this).StartCoroutine(waitToLoadSettings());
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private IEnumerator waitToLoadSettings()
	{
		ES3.Init();
		yield return (object)new WaitForSeconds(0.5f);
		try
		{
			LoadSettingsFromPrefs();
			UpdateGameToMatchSettings();
		}
		catch (Exception e)
		{
			DisplaySaveFileError(e);
			yield break;
		}
		PreInitSceneScript preInitSceneScript = Object.FindObjectOfType<PreInitSceneScript>();
		preInitSceneScript.SetLaunchPanelsEnabled();
		if (settings.playerHasFinishedSetup && (Object)(object)preInitSceneScript != (Object)null)
		{
			preInitSceneScript.SkipToFinalSetting();
		}
	}

	private void DisplaySaveFileError(Exception e)
	{
		Debug.LogError((object)$"Error while loading general save data file!: {e}, enabling error panel for player");
		encounteredErrorDuringSave = true;
		PreInitSceneScript preInitSceneScript = Object.FindObjectOfType<PreInitSceneScript>();
		if ((Object)(object)preInitSceneScript != (Object)null)
		{
			preInitSceneScript.EnableFileCorruptedScreen();
		}
	}

	public void LoadSettingsFromPrefs()
	{
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		string text = "LCGeneralSaveData";
		settings.playerHasFinishedSetup = ES3.Load<bool>("PlayerFinishedSetup", text, false);
		settings.startInOnlineMode = ES3.Load<bool>("StartInOnlineMode", text, false);
		settings.gammaSetting = ES3.Load<float>("Gamma", text, 0f);
		settings.masterVolume = ES3.Load<float>("MasterVolume", text, 1f);
		settings.lookSensitivity = ES3.Load<int>("LookSens", text, 10);
		settings.micEnabled = ES3.Load<bool>("MicEnabled", text, true);
		settings.pushToTalk = ES3.Load<bool>("PushToTalk", text, false);
		settings.micDevice = ES3.Load<string>("CurrentMic", text, "LCNoMic");
		settings.keyBindings = ES3.Load<string>("Bindings", text, string.Empty);
		settings.framerateCapIndex = ES3.Load<int>("FPSCap", text, 0);
		settings.fullScreenType = (FullScreenMode)ES3.Load<int>("ScreenMode", text, 1);
		settings.invertYAxis = ES3.Load<bool>("InvertYAxis", text, false);
		settings.spiderSafeMode = ES3.Load<bool>("SpiderSafeMode", text, false);
		if (!string.IsNullOrEmpty(settings.keyBindings))
		{
			InputActionRebindingExtensions.LoadBindingOverridesFromJson((IInputActionCollection2)(object)playerInput.actions, settings.keyBindings, true);
		}
		unsavedSettings.CopySettings(settings);
	}

	public void SaveSettingsToPrefs()
	{
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Expected I4, but got Unknown
		string text = "LCGeneralSaveData";
		try
		{
			ES3.Save<bool>("PlayerFinishedSetup", settings.playerHasFinishedSetup, text);
			ES3.Save<bool>("StartInOnlineMode", settings.startInOnlineMode, text);
			ES3.Save<float>("Gamma", settings.gammaSetting, text);
			ES3.Save<float>("MasterVolume", settings.masterVolume, text);
			ES3.Save<int>("LookSens", settings.lookSensitivity, text);
			ES3.Save<bool>("MicEnabled", settings.micEnabled, text);
			ES3.Save<bool>("PushToTalk", settings.pushToTalk, text);
			ES3.Save<string>("CurrentMic", settings.micDevice, text);
			ES3.Save<string>("Bindings", settings.keyBindings, text);
			ES3.Save<int>("FPSCap", settings.framerateCapIndex, text);
			ES3.Save<int>("ScreenMode", (int)settings.fullScreenType, text);
			ES3.Save<bool>("InvertYAxis", settings.invertYAxis, text);
			ES3.Save<bool>("SpiderSafeMode", settings.spiderSafeMode, text);
		}
		catch (Exception e)
		{
			DisplaySaveFileError(e);
		}
	}

	public void UpdateAllKeybindOptions()
	{
		SettingsOption[] array = Object.FindObjectsOfType<SettingsOption>(true);
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetBindingToCurrentSetting();
		}
		KepRemapPanel kepRemapPanel = Object.FindObjectOfType<KepRemapPanel>();
		if ((Object)(object)kepRemapPanel != (Object)null)
		{
			Debug.Log((object)"Reseting keybind UI");
			kepRemapPanel.ResetKeybindsUI();
		}
	}

	public void UpdateGameToMatchSettings()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Expected I4, but got Unknown
		ChangeGamma(0, settings.gammaSetting);
		SetFramerateCap(settings.framerateCapIndex);
		SetFullscreenMode((int)settings.fullScreenType);
		AudioListener.volume = settings.masterVolume;
		UpdateMicPushToTalkButton();
		RefreshAndDisplayCurrentMicrophone();
		SettingsOption[] array = Object.FindObjectsOfType<SettingsOption>(true);
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetValueToMatchSettings();
		}
		if ((Object)(object)comms != (Object)null && (Object)(object)StartOfRound.Instance != (Object)null)
		{
			comms.IsMuted = !settings.micEnabled;
		}
	}

	public void SetOption(SettingsOptionType optionType, int value)
	{
		if ((Object)(object)GameNetworkManager.Instance != (Object)null)
		{
			SettingsAudio.PlayOneShot(GameNetworkManager.Instance.buttonTuneSFX);
		}
		Debug.Log((object)$"Set settings not applied!; {optionType}");
		SetChangesNotAppliedTextVisible();
		switch (optionType)
		{
		case SettingsOptionType.Gamma:
			ChangeGamma(value);
			break;
		case SettingsOptionType.MasterVolume:
			ChangeMasterVolume(value);
			break;
		case SettingsOptionType.LookSens:
			ChangeLookSens(value);
			break;
		case SettingsOptionType.MicDevice:
			SwitchMicrophoneSetting();
			break;
		case SettingsOptionType.MicEnabled:
			SetMicrophoneEnabled();
			break;
		case SettingsOptionType.MicPushToTalk:
			SetMicPushToTalk();
			break;
		case SettingsOptionType.FramerateCap:
			SetFramerateCap(value);
			break;
		case SettingsOptionType.FullscreenType:
			SetFullscreenMode(value);
			break;
		case SettingsOptionType.InvertYAxis:
			SetInvertYAxis();
			break;
		case SettingsOptionType.SpiderSafeMode:
			SetSpiderSafeMode();
			break;
		case SettingsOptionType.OnlineMode:
		case SettingsOptionType.ChangeBinding:
		case SettingsOptionType.CancelOrConfirm:
			break;
		}
	}

	private void SetSpiderSafeMode()
	{
		unsavedSettings.spiderSafeMode = !unsavedSettings.spiderSafeMode;
	}

	private void SetInvertYAxis()
	{
		unsavedSettings.invertYAxis = !unsavedSettings.invertYAxis;
	}

	private void SetFullscreenMode(int value)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		Screen.fullScreenMode = (FullScreenMode)value;
		unsavedSettings.fullScreenType = (FullScreenMode)value;
	}

	private void SetFramerateCap(int value)
	{
		switch (value)
		{
		case 0:
			QualitySettings.vSyncCount = 1;
			Application.targetFrameRate = -1;
			break;
		case 1:
			QualitySettings.vSyncCount = 0;
			Application.targetFrameRate = 250;
			break;
		default:
			QualitySettings.vSyncCount = 0;
			switch (value)
			{
			case 2:
				Application.targetFrameRate = 144;
				break;
			case 3:
				Application.targetFrameRate = 120;
				break;
			case 4:
				Application.targetFrameRate = 60;
				break;
			case 5:
				Application.targetFrameRate = 30;
				break;
			}
			break;
		}
		unsavedSettings.framerateCapIndex = value;
	}

	public void ChangeGamma(int setTo, float overrideWithFloat = -500f)
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Expected O, but got Unknown
		float num = Mathf.Clamp((float)setTo * 0.05f, -0.85f, 2f);
		if (overrideWithFloat != -500f)
		{
			num = overrideWithFloat;
		}
		LiftGammaGain val = default(LiftGammaGain);
		if (universalVolume.sharedProfile.TryGet<LiftGammaGain>(ref val))
		{
			((VolumeParameter)val.gamma).SetValue((VolumeParameter)new Vector4Parameter(new Vector4(0f, 0f, 0f, num), true));
		}
		unsavedSettings.gammaSetting = num;
	}

	public void ChangeMasterVolume(int setTo)
	{
		unsavedSettings.masterVolume = (float)setTo / 100f;
		AudioListener.volume = (float)setTo / 100f;
	}

	public void ChangeLookSens(int setTo)
	{
		unsavedSettings.lookSensitivity = setTo;
		Debug.Log((object)$"Set mouse sensitivity to new value: {setTo}");
	}

	public void RefreshAndDisplayCurrentMicrophone(bool saveResult = true)
	{
		Settings settings = ((!saveResult) ? unsavedSettings : this.settings);
		settings.micDeviceIndex = 0;
		bool flag = false;
		string text = ((!saveResult) ? unsavedSettings.micDevice : this.settings.micDevice);
		for (int i = 0; i < Microphone.devices.Length; i++)
		{
			if (Microphone.devices[i] == text)
			{
				settings.micDeviceIndex = i;
				settings.micDevice = Microphone.devices[i];
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			if (Microphone.devices.Length == 0)
			{
				SetSettingsOptionsText(SettingsOptionType.MicDevice, "No device found \n (click to refresh)");
				settings.micDevice = "LCNoMic";
				Debug.Log((object)"No recording devices found");
				return;
			}
			settings.micDevice = Microphone.devices[0];
		}
		SetSettingsOptionsText(SettingsOptionType.MicDevice, "Current input device: \n " + settings.micDevice);
		if (saveResult && (Object)(object)comms != (Object)null)
		{
			comms.MicrophoneName = settings.micDevice;
		}
	}

	public void SetSettingsOptionsText(SettingsOptionType optionType, string setToText)
	{
		SettingsOption[] array = Object.FindObjectsOfType<SettingsOption>(true);
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].optionType == optionType && (Object)(object)array[i].textElement != (Object)null)
			{
				((TMP_Text)array[i].textElement).text = setToText;
			}
		}
	}

	public void SwitchMicrophoneSetting()
	{
		if (Microphone.devices.Length == 0)
		{
			Debug.Log((object)"No mics found when trying to switch");
			return;
		}
		Debug.Log((object)"Switching microphone");
		unsavedSettings.micDeviceIndex = ++unsavedSettings.micDeviceIndex % Microphone.devices.Length;
		unsavedSettings.micDevice = Microphone.devices[unsavedSettings.micDeviceIndex];
		SetSettingsOptionsText(SettingsOptionType.MicDevice, "Current input device: \n " + unsavedSettings.micDevice);
		DisplayPlayerMicVolume displayPlayerMicVolume = Object.FindObjectOfType<DisplayPlayerMicVolume>();
		if ((Object)(object)displayPlayerMicVolume != (Object)null)
		{
			displayPlayerMicVolume.SwitchMicrophone();
		}
		if ((Object)(object)comms != (Object)null)
		{
			comms.MicrophoneName = unsavedSettings.micDevice;
		}
	}

	public void SetMicrophoneEnabled()
	{
		unsavedSettings.micEnabled = !unsavedSettings.micEnabled;
		if ((Object)(object)comms != (Object)null && (Object)(object)StartOfRound.Instance != (Object)null)
		{
			comms.IsMuted = !settings.micEnabled;
		}
	}

	public void SetMicPushToTalk()
	{
		unsavedSettings.pushToTalk = !unsavedSettings.pushToTalk;
		if (unsavedSettings.pushToTalk)
		{
			SetSettingsOptionsText(SettingsOptionType.MicPushToTalk, "MODE: Push to talk");
		}
		else
		{
			SetSettingsOptionsText(SettingsOptionType.MicPushToTalk, "MODE: Voice activation");
		}
	}

	public void UpdateMicPushToTalkButton()
	{
		if (settings.pushToTalk)
		{
			SetSettingsOptionsText(SettingsOptionType.MicPushToTalk, "MODE: Push to talk");
		}
		else
		{
			SetSettingsOptionsText(SettingsOptionType.MicPushToTalk, "MODE: Voice activation");
		}
	}

	public void SetPlayerFinishedLaunchOptions()
	{
		settings.playerHasFinishedSetup = true;
		unsavedSettings.playerHasFinishedSetup = true;
		ES3.Save<bool>("PlayerFinishedSetup", true, "LCGeneralSaveData");
	}

	public void SetLaunchInOnlineMode(bool enable)
	{
		settings.startInOnlineMode = enable;
		unsavedSettings.startInOnlineMode = enable;
		ES3.Save<bool>("StartInOnlineMode", enable, "LCGeneralSaveData");
	}

	public void RebindKey(InputActionReference rebindableAction, SettingsOption optionUI, int rebindIndex, bool gamepadRebinding = false)
	{
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		if (rebindingOperation != null)
		{
			rebindingOperation.Dispose();
			if ((Object)(object)currentRebindingKeyUI != (Object)null)
			{
				((Behaviour)currentRebindingKeyUI.currentlyUsedKeyText).enabled = true;
				currentRebindingKeyUI.waitingForInput.SetActive(false);
			}
		}
		((Behaviour)optionUI.currentlyUsedKeyText).enabled = false;
		optionUI.waitingForInput.SetActive(true);
		playerInput.DeactivateInput();
		currentRebindingKeyUI = optionUI;
		bool getBindingIndexManually = rebindIndex != -1;
		if (rebindIndex == -1)
		{
			rebindIndex = 0;
		}
		Debug.Log((object)$"Rebinding starting.. rebindIndex: {rebindIndex}");
		if (gamepadRebinding)
		{
			rebindingOperation = InputActionRebindingExtensions.PerformInteractiveRebinding(rebindableAction.action, rebindIndex).OnMatchWaitForAnother(0.1f).WithControlsHavingToMatchPath("<Gamepad>")
				.WithCancelingThrough(playerInput.actions.FindAction("OpenMenu", false).controls[2])
				.OnComplete((Action<RebindingOperation>)delegate
				{
					CompleteRebind(optionUI, getBindingIndexManually, rebindIndex);
				})
				.Start();
		}
		else
		{
			rebindingOperation = InputActionRebindingExtensions.PerformInteractiveRebinding(rebindableAction.action, rebindIndex).OnMatchWaitForAnother(0.1f).WithControlsHavingToMatchPath("<Keyboard>")
				.WithControlsHavingToMatchPath("<Mouse>")
				.WithControlsExcluding("<Mouse>/scroll/y")
				.WithCancelingThrough(playerInput.actions.FindAction("OpenMenu", false).controls[0])
				.OnComplete((Action<RebindingOperation>)delegate
				{
					CompleteRebind(optionUI, getBindingIndexManually, rebindIndex);
				})
				.Start();
		}
		Debug.Log((object)"Rebinding starting.. B");
	}

	public void CompleteRebind(SettingsOption optionUI, bool getBindingIndexManually, int setBindingIndex = 0)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		InputAction action = rebindingOperation.action;
		if (rebindingOperation != null)
		{
			rebindingOperation.Dispose();
		}
		playerInput.ActivateInput();
		int num;
		if (!getBindingIndexManually)
		{
			num = InputActionRebindingExtensions.GetBindingIndexForControl(action, action.controls[0]);
			Debug.Log((object)$"Setting binding index to default which is {num}");
		}
		else
		{
			Debug.Log((object)$"Setting binding index to manual which is {setBindingIndex}");
			num = setBindingIndex;
		}
		TextMeshProUGUI currentlyUsedKeyText = optionUI.currentlyUsedKeyText;
		InputBinding val = action.bindings[num];
		((TMP_Text)currentlyUsedKeyText).text = InputControlPath.ToHumanReadableString(((InputBinding)(ref val)).effectivePath, (HumanReadableStringOptions)2, (InputControl)null);
		((Behaviour)optionUI.currentlyUsedKeyText).enabled = true;
		optionUI.waitingForInput.SetActive(false);
		Debug.Log((object)"Rebinding finishing.. A");
		unsavedSettings.keyBindings = InputActionRebindingExtensions.SaveBindingOverridesAsJson((IInputActionCollection2)(object)playerInput.actions);
		SetChangesNotAppliedTextVisible();
		Debug.Log((object)"Rebinding finishing.. B");
	}

	public void CancelRebind(SettingsOption optionUI = null)
	{
		if (rebindingOperation != null)
		{
			rebindingOperation.Dispose();
		}
		try
		{
			playerInput.ActivateInput();
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Unable to activate input!: {arg}");
		}
		if (!((Object)(object)optionUI == (Object)null))
		{
			((Behaviour)optionUI.currentlyUsedKeyText).enabled = true;
			optionUI.waitingForInput.SetActive(false);
		}
	}

	public void ResetSettingsToDefault()
	{
		SetChangesNotAppliedTextVisible(visible: false);
		Settings copyFrom = new Settings(settings.playerHasFinishedSetup, settings.startInOnlineMode);
		settings.CopySettings(copyFrom);
		unsavedSettings.CopySettings(copyFrom);
		SaveSettingsToPrefs();
		UpdateGameToMatchSettings();
	}

	public void ResetAllKeybinds()
	{
		CancelRebind();
		InputActionRebindingExtensions.RemoveAllBindingOverrides((IInputActionCollection2)(object)playerInput.actions);
		unsavedSettings.keyBindings = string.Empty;
		SetChangesNotAppliedTextVisible();
		UpdateAllKeybindOptions();
	}

	public void SaveChangedSettings()
	{
		SetChangesNotAppliedTextVisible(visible: false);
		Debug.Log((object)"Saving changed settings");
		settings.CopySettings(unsavedSettings);
		SaveSettingsToPrefs();
		UpdateGameToMatchSettings();
	}

	public void DisplayConfirmChangesScreen(bool visible)
	{
		MenuManager menuManager = Object.FindObjectOfType<MenuManager>();
		if ((Object)(object)menuManager != (Object)null)
		{
			menuManager.PleaseConfirmChangesSettingsPanel.SetActive(visible);
			menuManager.KeybindsPanel.SetActive(!visible);
			((Selectable)menuManager.PleaseConfirmChangesSettingsPanelBackButton).Select();
			return;
		}
		QuickMenuManager quickMenuManager = Object.FindObjectOfType<QuickMenuManager>();
		if ((Object)(object)quickMenuManager != (Object)null)
		{
			quickMenuManager.PleaseConfirmChangesSettingsPanel.SetActive(visible);
			quickMenuManager.KeybindsPanel.SetActive(!visible);
			((Selectable)quickMenuManager.PleaseConfirmChangesSettingsPanelBackButton).Select();
		}
	}

	public void DiscardChangedSettings()
	{
		SetChangesNotAppliedTextVisible(visible: false);
		Debug.Log((object)"Discarding changed settings");
		unsavedSettings.CopySettings(settings);
		if (!string.IsNullOrEmpty(settings.keyBindings))
		{
			InputActionRebindingExtensions.LoadBindingOverridesFromJson((IInputActionCollection2)(object)playerInput.actions, settings.keyBindings, true);
		}
		else
		{
			InputActionRebindingExtensions.RemoveAllBindingOverrides((IInputActionCollection2)(object)playerInput.actions);
		}
		UpdateGameToMatchSettings();
	}

	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= OnSceneLoaded;
	}

	private void OnDisable()
	{
		SceneManager.sceneLoaded -= OnSceneLoaded;
	}

	private void OnEnable()
	{
		SceneManager.sceneLoaded += OnSceneLoaded;
	}

	private void OnSceneLoaded(Scene scene, LoadSceneMode loadType)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if ((int)loadType == 0)
		{
			UpdateGameToMatchSettings();
			comms = Object.FindObjectOfType<DissonanceComms>();
		}
	}

	private void SetChangesNotAppliedTextVisible(bool visible = true)
	{
		changesNotApplied = visible;
		MenuManager menuManager = Object.FindObjectOfType<MenuManager>();
		if ((Object)(object)menuManager != (Object)null)
		{
			((Behaviour)menuManager.changesNotAppliedText).enabled = visible;
			if (visible)
			{
				((TMP_Text)menuManager.settingsBackButton).text = "DISCARD";
			}
			else
			{
				((TMP_Text)menuManager.settingsBackButton).text = "BACK";
			}
			return;
		}
		QuickMenuManager quickMenuManager = Object.FindObjectOfType<QuickMenuManager>();
		if ((Object)(object)quickMenuManager != (Object)null)
		{
			((Behaviour)quickMenuManager.changesNotAppliedText).enabled = visible;
			if (visible)
			{
				((TMP_Text)quickMenuManager.settingsBackButton).text = "Discard changes";
			}
			else
			{
				((TMP_Text)quickMenuManager.settingsBackButton).text = "Back";
			}
		}
	}
}
