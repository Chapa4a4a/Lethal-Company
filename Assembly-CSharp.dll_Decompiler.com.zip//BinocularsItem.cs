public class BinocularsItem : GrabbableObject
{
	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "BinocularsItem";
	}
}
