using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class SandSpiderAI : EnemyAI
{
	private float[] legDistances = new float[12]
	{
		2.2f, 2.2f, 1.8f, 1.8f, 1.3f, 1.3f, 1.5f, 1.5f, 1f, 1f,
		0.6f, 0.6f
	};

	public Vector3[] legPositions;

	public Transform[] legDefaultPositions;

	public Transform[] legTargets;

	public Transform abdomen;

	public Transform mouthTarget;

	public bool burrowing;

	public Transform turnCompass;

	public Vector3 wallPosition;

	public Vector3 wallNormal;

	public Vector3 floorPosition;

	private bool onWall;

	private RaycastHit rayHit;

	private Ray ray;

	public bool lookingForWallPosition;

	private bool gotWallPositionInLOS;

	private float tryWallPositionInterval;

	private bool reachedWallPosition;

	public Transform meshContainer;

	public Vector3 meshContainerPosition;

	public Vector3 meshContainerTarget;

	private Quaternion meshContainerTargetRotation;

	public float spiderSpeed;

	public float calculatePathToAgentInterval;

	public bool navigateMeshTowardsPosition;

	public Vector3 navigateToPositionTarget;

	public NavMeshHit navHit;

	public List<SandSpiderWebTrap> webTraps = new List<SandSpiderWebTrap>();

	public GameObject webTrapPrefab;

	public int maxWebTrapsToPlace;

	private float timeSincePlacingWebTrap;

	public Vector3 meshContainerServerPosition;

	public Vector3 meshContainerServerRotation;

	private Vector3 refVel;

	public Transform homeNode;

	public AISearchRoutine patrolHomeBase;

	private bool setDestinationToHomeBase;

	private float chaseTimer;

	private bool overrideSpiderLookRotation;

	private bool watchFromDistance;

	public float overrideAnimation;

	private float overrideAnimationWeight;

	private float timeSinceHittingPlayer;

	private DeadBodyInfo currentlyHeldBody;

	public Mesh playerBodyWebMesh;

	public Material playerBodyWebMat;

	private bool spooledPlayerBody;

	private bool spoolingPlayerBody;

	private Coroutine turnBodyIntoWebCoroutine;

	private bool decidedChanceToHangBodyEarly;

	public GameObject hangBodyPhysicsPrefab;

	private Coroutine grabBodyCoroutine;

	private float waitOnWallTimer;

	public AudioClip[] footstepSFX;

	public AudioSource footstepAudio;

	public AudioClip hitWebSFX;

	public AudioClip attackSFX;

	public AudioClip spoolPlayerSFX;

	public AudioClip hangPlayerSFX;

	public AudioClip breakWebSFX;

	public AudioClip hitSpiderSFX;

	private float lookAtPlayerInterval;

	public Rigidbody meshContainerRigidbody;

	private RaycastHit rayHitB;

	public MeshRenderer spiderSafeModeMesh;

	public SkinnedMeshRenderer spiderNormalMesh;

	private bool spiderSafeEnabled;

	public override void Start()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		meshContainerPosition = ((Component)this).transform.position;
		meshContainerTarget = ((Component)this).transform.position;
		navHit = default(NavMeshHit);
		rayHitB = default(RaycastHit);
		patrolHomeBase.searchWidth = 17f;
		patrolHomeBase.searchPrecision = 3f;
		maxWebTrapsToPlace = Random.Range(6, 9);
		homeNode = ChooseClosestNodeToPosition(((Component)this).transform.position, avoidLineOfSight: false, 2);
		meshContainerTargetRotation = Quaternion.identity;
	}

	public override void DoAIInterval()
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (isEnemyDead)
		{
			return;
		}
		if (lookingForWallPosition && !gotWallPositionInLOS)
		{
			gotWallPositionInLOS = GetWallPositionForSpiderMesh();
		}
		if (navigateMeshTowardsPosition)
		{
			CalculateSpiderPathToPosition();
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			setDestinationToHomeBase = false;
			lookingForWallPosition = false;
			reachedWallPosition = false;
			if (!patrolHomeBase.inProgress)
			{
				StartSearch(homeNode.position, patrolHomeBase);
			}
			break;
		case 1:
			movingTowardsTargetPlayer = false;
			if (!lookingForWallPosition)
			{
				if (Vector3.Distance(((Component)this).transform.position, homeNode.position) > 7f)
				{
					patrolHomeBase.searchWidth = 6f;
					if (!patrolHomeBase.inProgress)
					{
						if (PathIsIntersectedByLineOfSight(homeNode.position, calculatePathDistance: false, avoidLineOfSight: false))
						{
							homeNode = ChooseClosestNodeToPosition(((Component)this).transform.position, avoidLineOfSight: false, 2);
						}
						StartSearch(homeNode.position, patrolHomeBase);
					}
					break;
				}
				if ((Object)(object)currentlyHeldBody != (Object)null && !spooledPlayerBody)
				{
					if (turnBodyIntoWebCoroutine == null)
					{
						turnBodyIntoWebCoroutine = ((MonoBehaviour)this).StartCoroutine(turnBodyIntoWeb());
						SpiderTurnBodyIntoWebServerRpc();
					}
					break;
				}
				if ((Object)(object)currentlyHeldBody != (Object)null && !decidedChanceToHangBodyEarly)
				{
					if (Random.Range(0, 100) < 150)
					{
						HangBodyFromCeiling();
						SpiderHangBodyServerRpc();
					}
					decidedChanceToHangBodyEarly = true;
				}
				if (patrolHomeBase.inProgress)
				{
					StopSearch(patrolHomeBase);
				}
				lookingForWallPosition = true;
				reachedWallPosition = false;
				break;
			}
			if (reachedWallPosition)
			{
				if ((Object)(object)currentlyHeldBody != (Object)null)
				{
					HangBodyFromCeiling();
					SpiderHangBodyServerRpc();
				}
				for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
				{
					if (PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[i]) && !Physics.Linecast(meshContainer.position, ((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position, StartOfRound.Instance.collidersAndRoomMask))
					{
						float num = Vector3.Distance(((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position, meshContainer.position);
						if (num < 5f)
						{
							TriggerChaseWithPlayer(StartOfRound.Instance.allPlayerScripts[i]);
							break;
						}
						if (num < 10f)
						{
							Vector3 position = ((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position;
							float num2 = Vector3.Dot(position - meshContainer.position, wallNormal);
							Vector3 val = position - num2 * wallNormal;
							meshContainerTargetRotation = Quaternion.LookRotation(val, wallNormal);
							overrideSpiderLookRotation = true;
							break;
						}
					}
				}
			}
			overrideSpiderLookRotation = false;
			break;
		case 2:
			if (patrolHomeBase.inProgress)
			{
				StopSearch(patrolHomeBase);
			}
			if (watchFromDistance && !TargetClosestPlayer(2f, requireLineOfSight: true, 80f))
			{
				StopChasing();
			}
			if (!((Object)(object)targetPlayer == (Object)null))
			{
				if (targetPlayer.isPlayerDead && (Object)(object)targetPlayer.deadBody != (Object)null && (!SetDestinationToPosition(((Component)targetPlayer.deadBody.bodyParts[6]).transform.position, checkForPath: true) || (Object)(object)targetPlayer.deadBody.attachedTo != (Object)null))
				{
					targetPlayer = null;
					StopChasing(moveTowardsDeadPlayerBody: true);
				}
				if (watchFromDistance)
				{
					SetDestinationToPosition(((Component)ChooseClosestNodeToPosition(((Component)targetPlayer).transform.position, avoidLineOfSight: false, 4)).transform.position);
				}
			}
			break;
		}
	}

	private IEnumerator turnBodyIntoWeb()
	{
		if ((Object)(object)currentlyHeldBody == (Object)null)
		{
			Debug.LogError((object)"Sand Spider: Tried to wrap body but it could not be found.");
			yield break;
		}
		spoolingPlayerBody = true;
		overrideAnimation = 4.05f;
		creatureAnimator.SetTrigger("spool");
		creatureSFX.PlayOneShot(spoolPlayerSFX);
		yield return (object)new WaitForSeconds(0.9f);
		if ((Object)(object)currentlyHeldBody.attachedTo != (Object)(object)mouthTarget)
		{
			CancelSpoolingBody();
		}
		currentlyHeldBody.ChangeMesh(playerBodyWebMesh, playerBodyWebMat);
		yield return (object)new WaitForSeconds(3.105f);
		spooledPlayerBody = true;
		spoolingPlayerBody = false;
		turnBodyIntoWebCoroutine = null;
		if ((Object)(object)currentlyHeldBody.attachedTo != (Object)(object)mouthTarget)
		{
			CancelSpoolingBody();
		}
	}

	private void CancelSpoolingBody()
	{
		if (turnBodyIntoWebCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(turnBodyIntoWebCoroutine);
		}
		if ((Object)(object)currentlyHeldBody != (Object)null)
		{
			currentlyHeldBody.attachedLimb = null;
			currentlyHeldBody.attachedTo = null;
			currentlyHeldBody = null;
		}
		spooledPlayerBody = false;
		spoolingPlayerBody = false;
	}

	[ServerRpc]
	public void SpiderTurnBodyIntoWebServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(224635274u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 224635274u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SpiderTurnBodyIntoWebClientRpc();
		}
	}

	[ClientRpc]
	public void SpiderTurnBodyIntoWebClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2894295549u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2894295549u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner && !isEnemyDead && turnBodyIntoWebCoroutine == null)
			{
				turnBodyIntoWebCoroutine = ((MonoBehaviour)this).StartCoroutine(turnBodyIntoWeb());
			}
		}
	}

	[ServerRpc]
	public void SpiderHangBodyServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1372568795u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1372568795u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SpiderHangBodyClientRpc();
		}
	}

	[ClientRpc]
	public void SpiderHangBodyClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(180633541u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 180633541u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				HangBodyFromCeiling();
			}
		}
	}

	private void HangBodyFromCeiling()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)currentlyHeldBody == (Object)null)
		{
			Debug.LogError((object)"Sand spider: Held body was null, couldn't hang up");
			return;
		}
		Vector3 val = abdomen.position + Vector3.up * 6f;
		if (Physics.Raycast(abdomen.position, Vector3.up, ref rayHit, 25f, StartOfRound.Instance.collidersAndRoomMaskAndDefault))
		{
			val = ((RaycastHit)(ref rayHit)).point;
		}
		SetLineRendererPoints component = Object.Instantiate<GameObject>(hangBodyPhysicsPrefab, val, Quaternion.identity, RoundManager.Instance.mapPropsContainer.transform).GetComponent<SetLineRendererPoints>();
		component.target.position = ((Component)currentlyHeldBody.bodyParts[6]).transform.position;
		currentlyHeldBody.attachedTo = component.target;
		decidedChanceToHangBodyEarly = false;
		currentlyHeldBody.bodyAudio.volume = 0.8f;
		currentlyHeldBody.bodyAudio.PlayOneShot(hangPlayerSFX);
		currentlyHeldBody = null;
	}

	[ServerRpc]
	public void GrabBodyServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(196846835u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 196846835u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			GrabBodyClientRpc(playerId);
		}
	}

	[ClientRpc]
	public void GrabBodyClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4242200834u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4242200834u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
		{
			if (grabBodyCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(grabBodyCoroutine);
			}
			grabBodyCoroutine = ((MonoBehaviour)this).StartCoroutine(WaitForBodyToGrab(playerId));
		}
	}

	private void GrabBody(DeadBodyInfo body)
	{
		currentlyHeldBody = body;
		currentlyHeldBody.attachedLimb = currentlyHeldBody.bodyParts[6];
		currentlyHeldBody.attachedTo = mouthTarget;
		currentlyHeldBody.matchPositionExactly = true;
	}

	private IEnumerator WaitForBodyToGrab(int playerId)
	{
		float timeAtStartOfWait = Time.timeSinceLevelLoad;
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)StartOfRound.Instance.allPlayerScripts[playerId].deadBody != (Object)null || Time.timeSinceLevelLoad - timeAtStartOfWait > 10f));
		if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerId].deadBody == (Object)null)
		{
			Debug.LogError((object)"SandSpider: Grab body RPC was called, but body did not spawn within 10 seconds on this client.");
		}
		DeadBodyInfo deadBody = StartOfRound.Instance.allPlayerScripts[playerId].deadBody;
		GrabBody(deadBody);
	}

	private void CalculateSpiderPathToPosition()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (NavMesh.CalculatePath(meshContainer.position, navigateToPositionTarget, agent.areaMask, path1))
		{
			if (path1.corners.Length > 1)
			{
				meshContainerTarget = path1.corners[1];
				if (!overrideSpiderLookRotation)
				{
					SetSpiderLookAtPosition(path1.corners[1]);
				}
			}
			else
			{
				meshContainerTarget = navigateToPositionTarget;
				if (!overrideSpiderLookRotation)
				{
					SetSpiderLookAtPosition(navigateToPositionTarget);
				}
			}
		}
		else
		{
			meshContainer.position = RoundManager.Instance.GetNavMeshPosition(meshContainer.position, navHit, 5f, agent.areaMask);
			meshContainerTarget = meshContainer.position;
		}
	}

	public override void Update()
	{
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03be: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_0459: Unknown result type (might be due to invalid IL or missing references)
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0565: Unknown result type (might be due to invalid IL or missing references)
		//IL_0570: Unknown result type (might be due to invalid IL or missing references)
		//IL_060c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0617: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (spiderSafeEnabled != IngamePlayerSettings.Instance.unsavedSettings.spiderSafeMode)
		{
			spiderSafeEnabled = IngamePlayerSettings.Instance.unsavedSettings.spiderSafeMode;
			((Renderer)spiderSafeModeMesh).enabled = spiderSafeEnabled;
			((Renderer)spiderNormalMesh).enabled = !spiderSafeEnabled;
		}
		timeSinceHittingPlayer += Time.deltaTime;
		if (isEnemyDead)
		{
			agent.speed = 0f;
			spiderSpeed = 0f;
			creatureAnimator.SetBool("moving", false);
			return;
		}
		if (!((NetworkBehaviour)this).IsOwner)
		{
			creatureAnimator.SetBool("moving", ((Vector3)(ref refVel)).sqrMagnitude > 0.002f);
			return;
		}
		creatureAnimator.SetBool("moving", ((Vector3)(ref refVel)).sqrMagnitude * Time.deltaTime * 25f > 0.002f);
		SyncMeshContainerPositionToClients();
		CalculateMeshMovement();
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			setDestinationToHomeBase = false;
			lookingForWallPosition = false;
			movingTowardsTargetPlayer = false;
			overrideSpiderLookRotation = false;
			waitOnWallTimer = 11f;
			if (stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
				spiderSpeed = 0f;
			}
			else
			{
				agent.speed = 4.25f;
				spiderSpeed = 4.25f;
			}
			PlayerControllerB closestPlayer = GetClosestPlayer(requireLineOfSight: true);
			if ((Object)(object)closestPlayer != (Object)null && CheckLineOfSightForPosition(((Component)closestPlayer.gameplayCamera).transform.position, 80f, 15, 2f))
			{
				targetPlayer = closestPlayer;
				SwitchToBehaviourState(2);
				chaseTimer = 12.5f;
				watchFromDistance = mostOptimalDistance > 8f;
			}
			if (timeSincePlacingWebTrap > 4f)
			{
				if (AttemptPlaceWebTrap())
				{
					timeSincePlacingWebTrap = Random.Range(0.5f, 1f);
				}
				else
				{
					timeSincePlacingWebTrap = 0.17f;
				}
				if (webTraps.Count > maxWebTrapsToPlace)
				{
					SwitchToBehaviourState(1);
				}
			}
			else
			{
				timeSincePlacingWebTrap += Time.deltaTime;
			}
			break;
		}
		case 1:
			if (spoolingPlayerBody || stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
				spiderSpeed = 0f;
			}
			else
			{
				agent.speed = 4.5f;
				spiderSpeed = 3.75f;
			}
			if (webTraps.Count < maxWebTrapsToPlace && (Object)(object)currentlyHeldBody == (Object)null)
			{
				waitOnWallTimer -= Time.deltaTime;
			}
			if (waitOnWallTimer <= 0f)
			{
				SwitchToBehaviourState(0);
			}
			break;
		case 2:
			setDestinationToHomeBase = false;
			reachedWallPosition = false;
			lookingForWallPosition = false;
			waitOnWallTimer = 11f;
			if (spoolingPlayerBody)
			{
				CancelSpoolingBody();
			}
			if ((Object)(object)targetPlayer == (Object)null)
			{
				StopChasing();
				break;
			}
			if (onWall)
			{
				movingTowardsTargetPlayer = true;
				agent.speed = 4.25f;
				spiderSpeed = 4.25f;
				break;
			}
			if (watchFromDistance)
			{
				if (lookAtPlayerInterval <= 0f)
				{
					lookAtPlayerInterval = 3f;
					movingTowardsTargetPlayer = false;
					overrideSpiderLookRotation = true;
					Vector3 position = ((Component)targetPlayer).transform.position;
					position.y = meshContainer.position.y;
					SetSpiderLookAtPosition(position);
				}
				else
				{
					lookAtPlayerInterval -= Time.deltaTime;
				}
				agent.speed = 0f;
				spiderSpeed = 0f;
				if (Physics.Linecast(meshContainer.position, ((Component)targetPlayer.gameplayCamera).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault))
				{
					StopChasing();
				}
				else if (Vector3.Distance(((Component)targetPlayer.gameplayCamera).transform.position, ((Component)this).transform.position) < 5f || stunNormalizedTimer > 0f)
				{
					watchFromDistance = false;
				}
				break;
			}
			switch (enemyHP)
			{
			default:
				agent.speed = 4.4f;
				spiderSpeed = 4.4f;
				break;
			case 2:
				agent.speed = 4.58f;
				spiderSpeed = 4.58f;
				break;
			case 1:
				agent.speed = 5.04f;
				spiderSpeed = 5.04f;
				break;
			}
			movingTowardsTargetPlayer = true;
			overrideSpiderLookRotation = false;
			if (timeSinceHittingPlayer < 0.5f)
			{
				agent.speed = 0.7f;
				spiderSpeed = 0.4f;
			}
			if (targetPlayer.isPlayerDead && (Object)(object)targetPlayer.deadBody != (Object)null)
			{
				if (Vector3.Distance(((Component)targetPlayer.deadBody.bodyParts[6]).transform.position, meshContainer.position) < 3.7f)
				{
					spooledPlayerBody = false;
					GrabBody(targetPlayer.deadBody);
					GrabBodyServerRpc((int)targetPlayer.playerClientId);
					SwitchToBehaviourState(1);
				}
				else
				{
					targetPlayer = null;
					StopChasing();
				}
			}
			else if (!PlayerIsTargetable(targetPlayer) || (Vector3.Distance(((Component)targetPlayer).transform.position, homeNode.position) > 12f && Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position) > 5f))
			{
				chaseTimer -= Time.deltaTime;
				if (chaseTimer <= 0f)
				{
					targetPlayer = null;
					StopChasing();
				}
			}
			break;
		}
		if (stunNormalizedTimer > 0f)
		{
			spiderSpeed = 0f;
			agent.speed = 0f;
		}
	}

	private void StopChasing(bool moveTowardsDeadPlayerBody = false)
	{
		overrideSpiderLookRotation = false;
		movingTowardsTargetPlayer = false;
		lookingForWallPosition = false;
		if (webTraps.Count > maxWebTrapsToPlace || moveTowardsDeadPlayerBody)
		{
			SwitchToBehaviourState(1);
		}
		else
		{
			SwitchToBehaviourState(0);
		}
	}

	private void CalculateMeshMovement()
	{
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		if (lookingForWallPosition && gotWallPositionInLOS)
		{
			if (!onWall)
			{
				agent.obstacleAvoidanceType = (ObstacleAvoidanceType)4;
				navigateMeshTowardsPosition = true;
				navigateToPositionTarget = floorPosition;
				if (!overrideSpiderLookRotation)
				{
					turnCompass.position = meshContainer.position;
					turnCompass.LookAt(floorPosition, Vector3.up);
					meshContainerTargetRotation = turnCompass.rotation;
				}
				if (Vector3.Distance(((Component)meshContainer).transform.position, floorPosition) < 0.7f)
				{
					onWall = true;
				}
			}
			else
			{
				agent.obstacleAvoidanceType = (ObstacleAvoidanceType)0;
				navigateMeshTowardsPosition = false;
				meshContainerTarget = wallPosition;
				if (!reachedWallPosition && Vector3.Distance(meshContainer.position, wallPosition) < 0.1f)
				{
					reachedWallPosition = true;
				}
				if (!overrideSpiderLookRotation)
				{
					turnCompass.position = meshContainer.position;
					turnCompass.LookAt(wallPosition, wallNormal);
					meshContainerTargetRotation = turnCompass.rotation;
				}
			}
			return;
		}
		if (!lookingForWallPosition)
		{
			gotWallPositionInLOS = false;
			reachedWallPosition = false;
		}
		if (!onWall)
		{
			agent.obstacleAvoidanceType = (ObstacleAvoidanceType)4;
			if (!navigateMeshTowardsPosition)
			{
				CalculateSpiderPathToPosition();
				navigateMeshTowardsPosition = true;
			}
			navigateToPositionTarget = ((Component)this).transform.position + Vector3.Normalize(agent.desiredVelocity) * 2f;
			return;
		}
		agent.obstacleAvoidanceType = (ObstacleAvoidanceType)0;
		navigateMeshTowardsPosition = false;
		meshContainerTarget = floorPosition;
		if (!overrideSpiderLookRotation)
		{
			turnCompass.position = meshContainer.position;
			turnCompass.LookAt(floorPosition, wallNormal);
			meshContainerTargetRotation = turnCompass.rotation;
		}
		if (Vector3.Distance(((Component)meshContainer).transform.position, floorPosition) < 1.1f)
		{
			onWall = false;
		}
	}

	private void SetSpiderLookAtPosition(Vector3 lookAt)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		turnCompass.position = meshContainer.position;
		turnCompass.LookAt(lookAt, Vector3.up);
		meshContainerTargetRotation = turnCompass.rotation;
	}

	private bool GetWallPositionForSpiderMesh()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		float num = 6f;
		if (Physics.Raycast(((Component)this).transform.position, Vector3.up, ref rayHit, 22f, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
		{
			num = ((!((Object)(object)currentlyHeldBody != (Object)null)) ? (((RaycastHit)(ref rayHit)).distance - 1.3f) : (((RaycastHit)(ref rayHit)).distance - 2f));
		}
		float num2 = RoundManager.Instance.YRotationThatFacesTheNearestFromPosition(((Component)this).transform.position + Vector3.up * num, 10f);
		if (num2 != -777f)
		{
			turnCompass.eulerAngles = new Vector3(0f, num2, 0f);
			ray = new Ray(((Component)this).transform.position + Vector3.up * num, turnCompass.forward);
			if (Physics.Raycast(ray, ref rayHit, 10.1f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				wallPosition = ((Ray)(ref ray)).GetPoint(((RaycastHit)(ref rayHit)).distance - 0.2f);
				wallNormal = ((RaycastHit)(ref rayHit)).normal;
				if (Physics.Raycast(wallPosition, Vector3.down, ref rayHitB, 7f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					floorPosition = ((RaycastHit)(ref rayHitB)).point;
					return true;
				}
			}
		}
		return false;
	}

	public void LateUpdate()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		if (isEnemyDead)
		{
			meshContainer.eulerAngles = new Vector3(0f, meshContainer.eulerAngles.y, 0f);
			creatureAnimator.SetLayerWeight(creatureAnimator.GetLayerIndex("MoveLegs"), 0f);
		}
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			Vector3 val = meshContainerPosition;
			meshContainerPosition = Vector3.MoveTowards(meshContainerPosition, meshContainerTarget, spiderSpeed * Time.deltaTime);
			refVel = val - meshContainerPosition;
			meshContainer.position = meshContainerPosition;
			meshContainer.rotation = Quaternion.Lerp(meshContainer.rotation, meshContainerTargetRotation, 8f * Time.deltaTime);
		}
		else
		{
			meshContainer.position = Vector3.SmoothDamp(meshContainerPosition, meshContainerServerPosition, ref refVel, 4f * Time.deltaTime);
			meshContainerPosition = meshContainer.position;
			meshContainer.rotation = Quaternion.Lerp(meshContainer.rotation, Quaternion.Euler(meshContainerServerRotation), 9f * Time.deltaTime);
		}
		if (overrideAnimation <= 0f && stunNormalizedTimer <= 0f)
		{
			if (overrideAnimationWeight > 0.05f)
			{
				overrideAnimationWeight = Mathf.Lerp(overrideAnimationWeight, 0f, 20f * Time.deltaTime);
			}
			else
			{
				overrideAnimationWeight = 0f;
			}
			MoveLegsProcedurally();
		}
		else
		{
			overrideAnimation -= Time.deltaTime;
			overrideAnimationWeight = Mathf.Lerp(overrideAnimationWeight, 1f, 20f * Time.deltaTime);
		}
		creatureAnimator.SetBool("stunned", stunNormalizedTimer > 0f);
		creatureAnimator.SetLayerWeight(creatureAnimator.GetLayerIndex("MoveLegs"), overrideAnimationWeight);
	}

	public void MoveLegsProcedurally()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < legTargets.Length; i++)
		{
			legTargets[i].position = Vector3.Lerp(legTargets[i].position, legPositions[i], 35f * Time.deltaTime);
		}
		bool flag = false;
		for (int j = 0; j < legPositions.Length; j++)
		{
			Vector3 val = legPositions[j] - legDefaultPositions[j].position;
			if (((Vector3)(ref val)).sqrMagnitude > legDistances[j] * 1.4f)
			{
				legPositions[j] = legDefaultPositions[j].position;
				flag = true;
			}
		}
		if (flag)
		{
			footstepAudio.pitch = Random.Range(0.6f, 1.2f);
			footstepAudio.PlayOneShot(footstepSFX[Random.Range(0, footstepSFX.Length)], Random.Range(0.1f, 1f));
			WalkieTalkie.TransmitOneShotAudio(footstepAudio, footstepSFX[Random.Range(0, footstepSFX.Length)], Mathf.Clamp(Random.Range(-0.4f, 0.8f), 0f, 1f));
		}
	}

	[ServerRpc]
	public void SyncMeshContainerPositionServerRpc(Vector3 syncPosition, Vector3 syncRotation)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Invalid comparison between Unknown and I4
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3294703349u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref syncPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref syncRotation);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3294703349u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncMeshContainerPositionClientRpc(syncPosition, syncRotation);
		}
	}

	[ClientRpc]
	public void SyncMeshContainerPositionClientRpc(Vector3 syncPosition, Vector3 syncRotation)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3344227036u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref syncPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref syncRotation);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3344227036u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				meshContainerServerPosition = syncPosition;
				meshContainerServerRotation = syncRotation;
			}
		}
	}

	public void SyncMeshContainerPositionToClients()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(meshContainerServerPosition, ((Component)this).transform.position) > 0.5f || Vector3.SignedAngle(meshContainerServerRotation, meshContainer.eulerAngles, Vector3.up) > 30f)
		{
			meshContainerServerPosition = meshContainer.position;
			meshContainerServerRotation = meshContainer.eulerAngles;
			if (((NetworkBehaviour)this).IsServer)
			{
				SyncMeshContainerPositionClientRpc(meshContainerServerPosition, meshContainer.eulerAngles);
			}
			else
			{
				SyncMeshContainerPositionServerRpc(meshContainerServerPosition, meshContainer.eulerAngles);
			}
		}
	}

	private bool AttemptPlaceWebTrap()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < webTraps.Count; i++)
		{
			if (Vector3.Distance(((Component)webTraps[i]).transform.position, abdomen.position) < 0.6f)
			{
				return false;
			}
		}
		Vector3 val = Vector3.Scale(Random.onUnitSphere, new Vector3(1f, Random.Range(0.5f, 1f), 1f));
		val.y = Mathf.Min(0f, val.y);
		ray = new Ray(abdomen.position + Vector3.up * 0.4f, val);
		if (Physics.Raycast(ray, ref rayHit, 7f, StartOfRound.Instance.collidersAndRoomMask))
		{
			if (((RaycastHit)(ref rayHit)).distance < 2f)
			{
				return false;
			}
			Debug.Log((object)$"Got spider web raycast; end point: {((RaycastHit)(ref rayHit)).point}; {((RaycastHit)(ref rayHit)).distance}");
			Vector3 point = ((RaycastHit)(ref rayHit)).point;
			if (Physics.Raycast(abdomen.position, Vector3.down, ref rayHit, 10f, StartOfRound.Instance.collidersAndRoomMask))
			{
				Vector3 startPosition = ((RaycastHit)(ref rayHit)).point + Vector3.up * 0.2f;
				SpawnWebTrapServerRpc(startPosition, point);
			}
		}
		return false;
	}

	[ServerRpc]
	public void SpawnWebTrapServerRpc(Vector3 startPosition, Vector3 endPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Invalid comparison between Unknown and I4
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3159704048u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref startPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref endPosition);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3159704048u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SpawnWebTrapClientRpc(startPosition, endPosition);
		}
	}

	[ClientRpc]
	public void SpawnWebTrapClientRpc(Vector3 startPosition, Vector3 endPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2600337163u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref startPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref endPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2600337163u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				GameObject obj = Object.Instantiate<GameObject>(webTrapPrefab, startPosition, Quaternion.identity, RoundManager.Instance.mapPropsContainer.transform);
				obj.transform.LookAt(endPosition);
				SandSpiderWebTrap componentInChildren = obj.GetComponentInChildren<SandSpiderWebTrap>();
				webTraps.Add(componentInChildren);
				componentInChildren.trapID = webTraps.Count - 1;
				componentInChildren.mainScript = this;
				componentInChildren.zScale = Vector3.Distance(startPosition, endPosition) / 4f;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PlayerTripWebServerRpc(int trapID, int playerNum)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2685725483u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, trapID);
				BytePacker.WriteValueBitPacked(val2, playerNum);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2685725483u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PlayerTripWebClientRpc(trapID, playerNum);
			}
		}
	}

	[ClientRpc]
	public void PlayerTripWebClientRpc(int trapID, int playerNum)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1467254034u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, trapID);
			BytePacker.WriteValueBitPacked(val2, playerNum);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1467254034u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[playerNum];
		if (webTraps.Count - 1 >= trapID && playerControllerB.isPlayerControlled)
		{
			webTraps[trapID].webAudio.Play();
			webTraps[trapID].webAudio.PlayOneShot(hitWebSFX);
			if ((Object)(object)webTraps[trapID].currentTrappedPlayer != (Object)null)
			{
				webTraps[trapID].currentTrappedPlayer = playerControllerB;
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
				TriggerChaseWithPlayer(playerControllerB);
			}
		}
	}

	private void ChasePlayer(PlayerControllerB player)
	{
		if (((NetworkBehaviour)this).IsOwner && PlayerIsTargetable(player))
		{
			TriggerChaseWithPlayer(player);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void BreakWebServerRpc(int trapID, int playerWhoHit)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(327820463u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, trapID);
				BytePacker.WriteValueBitPacked(val2, playerWhoHit);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 327820463u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				Vector3 position = webTraps[trapID].centerOfWeb.position;
				BreakWebClientRpc(position, trapID);
				ChasePlayer(StartOfRound.Instance.allPlayerScripts[playerWhoHit]);
			}
		}
	}

	[ClientRpc]
	public void BreakWebClientRpc(Vector3 webPosition, int trapID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3975888531u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref webPosition);
				BytePacker.WriteValueBitPacked(val2, trapID);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3975888531u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				AudioSource.PlayClipAtPoint(breakWebSFX, webPosition);
				RemoveWeb(trapID);
			}
		}
	}

	private void RemoveWeb(int trapID)
	{
		if ((Object)(object)webTraps[trapID].currentTrappedPlayer != (Object)null)
		{
			if ((Object)(object)webTraps[trapID].currentTrappedPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				webTraps[trapID].currentTrappedPlayer.isMovementHindered--;
				webTraps[trapID].currentTrappedPlayer.hinderedMultiplier *= 0.5f;
			}
			webTraps[trapID].currentTrappedPlayer = null;
		}
		Object.Destroy((Object)(object)((Component)((Component)webTraps[trapID]).gameObject.transform.parent).gameObject);
		for (int i = 0; i < webTraps.Count; i++)
		{
			if (i > trapID)
			{
				webTraps[i].trapID--;
			}
		}
		webTraps.RemoveAt(trapID);
	}

	public void TriggerChaseWithPlayer(PlayerControllerB playerScript)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		if ((currentBehaviourStateIndex != 2 || watchFromDistance) && (currentBehaviourStateIndex != 1 || !((Object)(object)currentlyHeldBody != (Object)null) || !spooledPlayerBody) && !PathIsIntersectedByLineOfSight(((Component)playerScript).transform.position, calculatePathDistance: false, avoidLineOfSight: false) && (Vector3.Distance(((Component)playerScript).transform.position, homeNode.position) < 25f || Vector3.Distance(((Component)playerScript).transform.position, meshContainer.position) < 15f))
		{
			watchFromDistance = false;
			targetPlayer = playerScript;
			chaseTimer = 12.5f;
			SwitchToBehaviourState(2);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PlayerLeaveWebServerRpc(int trapID, int playerNum)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4039894120u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, trapID);
				BytePacker.WriteValueBitPacked(val2, playerNum);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4039894120u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PlayerLeaveWebClientRpc(trapID, playerNum);
			}
		}
	}

	[ClientRpc]
	public void PlayerLeaveWebClientRpc(int trapID, int playerNum)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(902229680u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, trapID);
				BytePacker.WriteValueBitPacked(val2, playerNum);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 902229680u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (Object)(object)webTraps[trapID].currentTrappedPlayer == (Object)(object)StartOfRound.Instance.allPlayerScripts[playerNum])
			{
				webTraps[trapID].currentTrappedPlayer = null;
				webTraps[trapID].webAudio.Stop();
			}
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (!isEnemyDead && !onWall)
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other, spoolingPlayerBody);
			if ((Object)(object)playerControllerB != (Object)null && timeSinceHittingPlayer > 1f)
			{
				timeSinceHittingPlayer = 0f;
				playerControllerB.DamagePlayer(90, hasDamageSFX: true, callRPC: true, CauseOfDeath.Mauling);
				HitPlayerServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (!isEnemyDead)
		{
			creatureSFX.PlayOneShot(hitSpiderSFX, 1f);
			WalkieTalkie.TransmitOneShotAudio(creatureSFX, hitSpiderSFX);
			enemyHP -= force;
			if (enemyHP <= 0)
			{
				KillEnemyOnOwnerClient();
			}
			else if (((NetworkBehaviour)this).IsOwner)
			{
				TriggerChaseWithPlayer(playerWhoHit);
			}
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		base.KillEnemy(destroy);
		CancelSpoolingBody();
		overrideAnimation = 1f;
	}

	[ServerRpc(RequireOwnership = false)]
	public void HitPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1418960684u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1418960684u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				HitPlayerClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void HitPlayerClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2819158268u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2819158268u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				creatureAnimator.SetTrigger("attack");
				overrideAnimation = 0.8f;
				creatureSFX.PlayOneShot(attackSFX);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, attackSFX);
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_SandSpiderAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(224635274u, new RpcReceiveHandler(__rpc_handler_224635274));
		NetworkManager.__rpc_func_table.Add(2894295549u, new RpcReceiveHandler(__rpc_handler_2894295549));
		NetworkManager.__rpc_func_table.Add(1372568795u, new RpcReceiveHandler(__rpc_handler_1372568795));
		NetworkManager.__rpc_func_table.Add(180633541u, new RpcReceiveHandler(__rpc_handler_180633541));
		NetworkManager.__rpc_func_table.Add(196846835u, new RpcReceiveHandler(__rpc_handler_196846835));
		NetworkManager.__rpc_func_table.Add(4242200834u, new RpcReceiveHandler(__rpc_handler_4242200834));
		NetworkManager.__rpc_func_table.Add(3294703349u, new RpcReceiveHandler(__rpc_handler_3294703349));
		NetworkManager.__rpc_func_table.Add(3344227036u, new RpcReceiveHandler(__rpc_handler_3344227036));
		NetworkManager.__rpc_func_table.Add(3159704048u, new RpcReceiveHandler(__rpc_handler_3159704048));
		NetworkManager.__rpc_func_table.Add(2600337163u, new RpcReceiveHandler(__rpc_handler_2600337163));
		NetworkManager.__rpc_func_table.Add(2685725483u, new RpcReceiveHandler(__rpc_handler_2685725483));
		NetworkManager.__rpc_func_table.Add(1467254034u, new RpcReceiveHandler(__rpc_handler_1467254034));
		NetworkManager.__rpc_func_table.Add(327820463u, new RpcReceiveHandler(__rpc_handler_327820463));
		NetworkManager.__rpc_func_table.Add(3975888531u, new RpcReceiveHandler(__rpc_handler_3975888531));
		NetworkManager.__rpc_func_table.Add(4039894120u, new RpcReceiveHandler(__rpc_handler_4039894120));
		NetworkManager.__rpc_func_table.Add(902229680u, new RpcReceiveHandler(__rpc_handler_902229680));
		NetworkManager.__rpc_func_table.Add(1418960684u, new RpcReceiveHandler(__rpc_handler_1418960684));
		NetworkManager.__rpc_func_table.Add(2819158268u, new RpcReceiveHandler(__rpc_handler_2819158268));
	}

	private static void __rpc_handler_224635274(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).SpiderTurnBodyIntoWebServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2894295549(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).SpiderTurnBodyIntoWebClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1372568795(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).SpiderHangBodyServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_180633541(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).SpiderHangBodyClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_196846835(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).GrabBodyServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4242200834(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).GrabBodyClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3294703349(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 syncPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref syncPosition);
			Vector3 syncRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref syncRotation);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).SyncMeshContainerPositionServerRpc(syncPosition, syncRotation);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3344227036(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 syncPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref syncPosition);
			Vector3 syncRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref syncRotation);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).SyncMeshContainerPositionClientRpc(syncPosition, syncRotation);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3159704048(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 startPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref startPosition);
			Vector3 endPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref endPosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).SpawnWebTrapServerRpc(startPosition, endPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2600337163(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 startPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref startPosition);
			Vector3 endPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref endPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).SpawnWebTrapClientRpc(startPosition, endPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2685725483(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int trapID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref trapID);
			int playerNum = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).PlayerTripWebServerRpc(trapID, playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1467254034(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int trapID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref trapID);
			int playerNum = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).PlayerTripWebClientRpc(trapID, playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_327820463(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int trapID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref trapID);
			int playerWhoHit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoHit);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).BreakWebServerRpc(trapID, playerWhoHit);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3975888531(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 webPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref webPosition);
			int trapID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref trapID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).BreakWebClientRpc(webPosition, trapID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4039894120(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int trapID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref trapID);
			int playerNum = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).PlayerLeaveWebServerRpc(trapID, playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_902229680(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int trapID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref trapID);
			int playerNum = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).PlayerLeaveWebClientRpc(trapID, playerNum);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1418960684(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SandSpiderAI)(object)target).HitPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2819158268(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SandSpiderAI)(object)target).HitPlayerClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "SandSpiderAI";
	}
}
