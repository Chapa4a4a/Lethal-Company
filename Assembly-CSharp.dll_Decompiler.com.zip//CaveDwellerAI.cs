using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Animations.Rigging;

public class CaveDwellerAI : EnemyAI
{
	public AudioSource walkingAudio;

	public AudioClip growlSFX;

	public AudioClip[] fakeCrySFX;

	public AudioSource clickingAudio1;

	public AudioSource clickingAudio2;

	public AudioSource screamAudio;

	public AudioSource screamAudioNonDiagetic;

	private bool isFakingBabyVoice = true;

	[Header("Maneater Variables")]
	public float sneakSpeed;

	public float attackDistance;

	public float leapSpeed;

	public float leapTime;

	public float screamTime;

	public float cooldownTime;

	public float chaseSpeed;

	public float baseSearchWidth;

	private float currentSearchWidth;

	[Space(3f)]
	public static float CaveDwellerDeafenAmount;

	private float caveDwellerDeafenAmountSmoothed;

	public float deafeningMaxDistance;

	public float deafeningMinDistance;

	public float maxDeafenAmount;

	public AISearchRoutine searchRoutine;

	private bool inKillAnimation;

	public List<Transform> ignoredNodes = new List<Transform>();

	private Vector3 caveHidingSpot;

	private bool screaming;

	private bool leaping;

	private float screamTimer;

	private float leapTimer;

	private bool chasingAfterLeap;

	private int previousBehaviourState = -1;

	private bool startingKillAnimationLocalClient;

	private Coroutine killAnimationCoroutine;

	private DeadBodyInfo bodyBeingCarried;

	public Transform bodyRagdollPoint;

	public ParticleSystem killPlayerParticle1;

	public ParticleSystem killPlayerParticle2;

	private bool startedLeapingThisFrame;

	private Vector3 agentLocalVelocity;

	private Vector3 previousPosition;

	public Transform animationContainer;

	private bool movedSinceLastCheck;

	public DampedTransform headRig;

	public Transform[] bodyPoints;

	private float noPlayersTimer;

	private bool wasOutsideLastFrame;

	private bool beganCooldown;

	public AudioClip cooldownSFX;

	[Header("Baby AI")]
	public AudioSource babyCryingAudio;

	public AudioSource babyVoice;

	public AudioClip squirmingSFX;

	public AudioClip transformationSFX;

	public AudioClip[] scaredBabyVoiceSFX;

	public AudioClip biteSFX;

	public ParticleSystem babyTearsParticle;

	public ParticleSystem babyFoamAtMouthParticle;

	public BabyState babyState;

	private int previousBabyState = -1;

	[Space(5f)]
	public float lonelinessMeter = 0.5f;

	public float stressMeter;

	public float growthMeter;

	public float growthSpeedMultiplier = 1f;

	public float moodinessMultiplier = 1f;

	[Space(3f)]
	public float decreaseLonelinessMultiplier = 0.07f;

	public float increaseLonelinessMultiplier = 0.03f;

	[Space(5f)]
	public List<BabyPlayerMemory> playerMemory = new List<BabyPlayerMemory>();

	private int playersSeen;

	private float currentActivityTimer;

	private float activityTimerOffset;

	public GameObject observingObject;

	public bool sittingDown;

	public bool babyRunning;

	public bool babyCrying;

	private bool stopCryingWhenReleased;

	public int rockingBaby;

	public bool holdingBaby;

	public float rockBabyTimer;

	public PlayerControllerB playerHolding;

	private Coroutine dropBabyCoroutine;

	public CaveDwellerPhysicsProp propScript;

	public bool hasPlayerFoundBaby;

	private bool pathingTowardsNearestPlayer;

	public AISearchRoutine babySearchRoutine;

	public MultiAimConstraint babyLookRig;

	public Transform babyLookTarget;

	private float pingAttentionTimer;

	private int focusLevel;

	public Vector3 pingAttentionPosition;

	private float timeAtLastPingAttention;

	private float fallOverWhileSittingChanceInterval;

	private float cantFindObservedObjectTimer;

	private float timeSpentObservingTimer;

	private Vector3 runningFromPosition;

	public bool eatingScrap;

	public GrabbableObject observingScrap;

	private float timeSinceEatingScrap;

	private float eatScrapRandomCheckInterval;

	private PlayerControllerB observingPlayer;

	private bool gettingFarthestNodeFromSpotAsync;

	private Transform farthestNodeFromRunningSpot;

	public Transform BabyEye;

	public Animator babyCreatureAnimator;

	public float lookVerticalOffset = 1f;

	private float timeAtLastHeardNoise;

	private float babyCryLonelyThreshold = 0.9f;

	private float babyFollowPlayersThreshold = 0.6f;

	private float babyRoamFromPlayersThreshold = 0.34f;

	private float babyCrySquirmingThreshold = 0.07f;

	private float timeSinceCheckingForScrap;

	private int scrapEaten;

	public Transform spine2;

	public float rollOverTimer;

	public bool rolledOver;

	public bool babySquirming;

	private int[] ignoreItemIds = new int[1] { 819501 };

	private List<GameObject> seenScrap = new List<GameObject>();

	public GameObject babyContainer;

	public GameObject adultContainer;

	private float timeSinceCryingFromScarySight;

	private RaycastHit hit;

	private float fakeCryTimer;

	private bool clickingMandibles;

	private float timeSinceBiting;

	private bool wasBodyVisible;

	private Vector3 positionAtLeavingLOS;

	private float shakeCameraInterval;

	private float checkMovingInterval;

	private bool pursuingPlayerInSneakMode;

	private float changeOwnershipInterval;

	private float scareBabyWhileHoldingCooldown;

	public AudioClip pukeSFX;

	private bool nearTransforming;

	private bool babyPuked;

	private float checkIfTrappedInterval;

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (currentBehaviourStateIndex == 0)
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				if ((Object)(object)playerWhoHit != (Object)null)
				{
					ScareBaby(((Component)playerWhoHit).transform.position);
				}
				else
				{
					ScareBaby(((Component)this).transform.position);
				}
				growthMeter += 0.6f;
			}
		}
		else if (!inSpecialAnimation)
		{
			enemyHP--;
			if (((NetworkBehaviour)this).IsOwner && enemyHP <= 0)
			{
				KillEnemyOnOwnerClient();
			}
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if (currentBehaviourStateIndex == 0)
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				ScareBaby(((Component)this).transform.position);
				growthMeter += 0.6f;
			}
		}
		else if (!inSpecialAnimation && adultContainer.activeSelf)
		{
			if (inKillAnimation)
			{
				FinishKillAnimation(completed: false);
			}
			walkingAudio.Stop();
			creatureVoice.Stop();
			creatureSFX.Stop();
			screamAudio.Stop();
			base.KillEnemy();
		}
	}

	private bool IsBodyVisibleToTarget()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)targetPlayer == (Object)null)
		{
			return false;
		}
		for (int i = 0; i < bodyPoints.Length; i++)
		{
			if (targetPlayer.HasLineOfSightToPosition(((Component)bodyPoints[i]).transform.position, 45f, 15))
			{
				return true;
			}
		}
		return false;
	}

	private void InitializeBabyValues()
	{
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			playerMemory.Add(new BabyPlayerMemory((ulong)i));
		}
		HoarderBugAI.RefreshGrabbableObjectsInMapList();
	}

	private BabyPlayerMemory GetBabyMemoryOfPlayer(PlayerControllerB player)
	{
		for (int i = 0; i < playerMemory.Count; i++)
		{
			if (playerMemory[i].playerId == player.playerClientId)
			{
				return playerMemory[i];
			}
		}
		return null;
	}

	private void IncreaseBabyGrowthMeter()
	{
		float num = 1.3f;
		if (rockingBaby == 2 && stopCryingWhenReleased)
		{
			num = 4f;
		}
		else if (babyRunning)
		{
			num = 1.8f;
		}
		if (babyCrying)
		{
			if (!hasPlayerFoundBaby)
			{
				growthMeter += 0.1f * growthSpeedMultiplier * Time.deltaTime;
			}
			else
			{
				growthMeter = Mathf.Clamp(growthMeter + growthSpeedMultiplier * num * Time.deltaTime, 0f, 25f);
			}
		}
		if (!nearTransforming && growthMeter > 0.8f)
		{
			nearTransforming = true;
			SetBabyNearTransformingServerRpc();
		}
		if (growthMeter > 1f)
		{
			TransformIntoAdult();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabyNearTransformingServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(412902375u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 412902375u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabyNearTransformingClientRpc();
			}
		}
	}

	[ClientRpc]
	public void SetBabyNearTransformingClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3265969319u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3265969319u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				nearTransforming = true;
			}
		}
	}

	public void PickUpBabyLocalClient()
	{
		Debug.Log((object)$"Player held by null?: {(Object)(object)propScript.playerHeldBy == (Object)null}");
		Debug.Log((object)$"Player held by: {propScript.playerHeldBy}");
		Debug.Log((object)$"Player held by playerclientid: {propScript.playerHeldBy.playerClientId}");
		currentOwnershipOnThisClient = (int)propScript.playerHeldBy.playerClientId;
		Debug.Log((object)$"Set currentownershiponthisclient to {currentOwnershipOnThisClient}");
		inSpecialAnimation = true;
		((Behaviour)agent).enabled = false;
		holdingBaby = true;
		if (dropBabyCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(dropBabyCoroutine);
		}
		if (((NetworkBehaviour)this).IsServer && babyState == BabyState.RolledOver)
		{
			babyState = BabyState.Roaming;
		}
		SetRolledOverLocalClient(setRolled: false, scared: false);
		playerHolding = propScript.playerHeldBy;
	}

	public void DropBabyLocalClient()
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		holdingBaby = false;
		rockingBaby = 0;
		playerHolding = null;
		Debug.Log((object)"Drop baby A");
		if (currentBehaviourStateIndex != 0)
		{
			return;
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			Debug.Log((object)$"Set ownership of creature. Currentownershiponthisclient: {currentOwnershipOnThisClient}");
			ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
		}
		serverPosition = ((Component)this).transform.position;
		bool flag = true;
		Vector3 itemFloorPosition = propScript.GetItemFloorPosition(((Component)propScript.previousPlayerHeldBy).transform.position + Vector3.up * 0.5f);
		Vector3 navMeshPosition = RoundManager.Instance.GetNavMeshPosition(itemFloorPosition, default(NavMeshHit), 10f);
		Debug.Log((object)$"Drop on position: {navMeshPosition}");
		Debug.DrawRay(propScript.startFallingPosition, Vector3.up * 1f, Color.white, 10f);
		Debug.DrawRay(navMeshPosition, Vector3.up * 0.75f, Color.red, 10f);
		if (!RoundManager.Instance.GotNavMeshPositionResult || DebugEnemy)
		{
			flag = false;
			itemFloorPosition = propScript.startFallingPosition;
			Debug.Log((object)$"Drop Baby C; {propScript.startFallingPosition}");
			if ((Object)(object)((Component)propScript).transform.parent != (Object)null)
			{
				itemFloorPosition = ((Component)propScript).transform.parent.TransformPoint(propScript.startFallingPosition);
			}
			Debug.Log((object)$"Drop Baby C global; {propScript.startFallingPosition}");
			Transform val = ChooseClosestNodeToPositionNoPathCheck(itemFloorPosition);
			navMeshPosition = RoundManager.Instance.GetNavMeshPosition(((Component)val).transform.position);
			Debug.Log((object)$"Got nav mesh position : {RoundManager.Instance.GotNavMeshPositionResult}; {navMeshPosition}; dist: {Vector3.Distance(((Component)this).transform.position, ((Component)val).transform.position)}");
			Debug.DrawRay(navMeshPosition, Vector3.up * 1.2f, Color.magenta, 10f);
		}
		Debug.Log((object)"Drop baby D");
		if ((Object)(object)((Component)propScript).transform.parent == (Object)null)
		{
			propScript.targetFloorPosition = navMeshPosition;
		}
		else
		{
			propScript.targetFloorPosition = ((Component)propScript).transform.parent.InverseTransformPoint(navMeshPosition);
		}
		Debug.DrawRay(propScript.targetFloorPosition, Vector3.up * 2f, Color.yellow, 5f);
		if (flag)
		{
			if (dropBabyCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(dropBabyCoroutine);
			}
			dropBabyCoroutine = ((MonoBehaviour)this).StartCoroutine(DropBabyAnimation(navMeshPosition));
		}
		else
		{
			Debug.Log((object)$"Drop baby F; got no floor target; drop pos: {navMeshPosition}");
			((Component)this).transform.position = navMeshPosition;
			inSpecialAnimation = false;
		}
	}

	public Transform ChooseClosestNodeToPositionNoPathCheck(Vector3 pos)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		nodesTempArray = allAINodes.OrderBy((GameObject x) => Vector3.Distance(pos, x.transform.position)).ToArray();
		return nodesTempArray[0].transform;
	}

	private IEnumerator DropBabyAnimation(Vector3 dropOnPosition)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		float time = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => propScript.reachedFloorTarget || Time.realtimeSinceStartup - time > 2f));
		Debug.Log((object)"Drop baby E");
		if (currentBehaviourStateIndex == 0)
		{
			((Component)this).transform.position = dropOnPosition;
			inSpecialAnimation = false;
			if (((NetworkBehaviour)this).IsServer && (Object)(object)propScript.previousPlayerHeldBy != (Object)null && propScript.previousPlayerHeldBy.isPlayerDead)
			{
				ScareBaby(((Component)this).transform.position);
			}
		}
		dropBabyCoroutine = null;
	}

	public void PingAttention(int newFocusLevel, float timeToLook, Vector3 attentionPosition, bool sync = true)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (!(pingAttentionTimer >= 0f) || newFocusLevel >= focusLevel)
		{
			focusLevel = newFocusLevel;
			pingAttentionTimer = timeToLook;
			pingAttentionPosition = attentionPosition;
			timeAtLastPingAttention = Time.realtimeSinceStartup;
			if (sync)
			{
				PingAttentionServerRpc(timeToLook, attentionPosition);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PingAttentionServerRpc(float timeToLook, Vector3 attentionPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(354890398u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToLook, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref attentionPosition);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 354890398u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PingAttentionClientRpc(timeToLook, attentionPosition);
			}
		}
	}

	[ClientRpc]
	public void PingAttentionClientRpc(float timeToLook, Vector3 attentionPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2092554489u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToLook, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref attentionPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2092554489u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				pingAttentionTimer = timeToLook;
				pingAttentionPosition = attentionPosition;
			}
		}
	}

	public PlayerControllerB[] GetAllPlayerBodiesInLineOfSight(float width = 45f, int range = 60, Transform eyeObject = null, float proximityCheck = -1f, int layerMask = -1)
	{
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		if (layerMask == -1)
		{
			layerMask = StartOfRound.Instance.collidersAndRoomMaskAndDefault;
		}
		if ((Object)(object)eyeObject == (Object)null)
		{
			eyeObject = eye;
		}
		if (isOutside && !enemyType.canSeeThroughFog && TimeOfDay.Instance.currentLevelWeather == LevelWeatherType.Foggy)
		{
			range = Mathf.Clamp(range, 0, 30);
		}
		List<PlayerControllerB> list = new List<PlayerControllerB>(4);
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (!StartOfRound.Instance.allPlayerScripts[i].isPlayerDead || (Object)(object)StartOfRound.Instance.allPlayerScripts[i].deadBody == (Object)null)
			{
				continue;
			}
			Vector3 position = ((Component)StartOfRound.Instance.allPlayerScripts[i].deadBody.bodyParts[5]).transform.position;
			if (Vector3.Distance(eye.position, position) < (float)range && !Physics.Linecast(eyeObject.position, position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				Vector3 val = position - eyeObject.position;
				if (Vector3.Angle(eyeObject.forward, val) < width || Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position) < proximityCheck)
				{
					list.Add(StartOfRound.Instance.allPlayerScripts[i]);
				}
			}
		}
		if (list.Count == 4)
		{
			return StartOfRound.Instance.allPlayerScripts;
		}
		if (list.Count > 0)
		{
			return list.ToArray();
		}
		return null;
	}

	private bool BabyObserveScrap()
	{
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		if (Time.realtimeSinceStartup - timeSinceCheckingForScrap < 1f || lonelinessMeter > 0.85f)
		{
			return false;
		}
		GameObject val = CheckLineOfSight(HoarderBugAI.grabbableObjectsInMap, 130f, 12, 3f, BabyEye, ignoreItemIds);
		if ((Object)(object)val != (Object)null && ((Object)(object)observingPlayer == (Object)null || (lonelinessMeter < babyFollowPlayersThreshold && !observingPlayer.isPlayerDead)))
		{
			if (!hasPlayerFoundBaby && HoarderBugAI.HoarderBugItems != null && HoarderBugAI.HoarderBugItems.Count > 0)
			{
				for (int i = 0; i < HoarderBugAI.HoarderBugItems.Count; i++)
				{
					if ((Object)(object)HoarderBugAI.HoarderBugItems[i].itemGrabbableObject == (Object)(object)val)
					{
						return false;
					}
				}
			}
			GrabbableObject component = val.GetComponent<GrabbableObject>();
			if ((Object)(object)component != (Object)null && (Object)(object)component != (Object)(object)propScript && ((NetworkBehaviour)component).NetworkObject.IsSpawned && (!seenScrap.Contains(val) || Random.Range(0, 100) < 4))
			{
				observingObject = val;
				observingScrap = component;
				focusLevel = 2;
				babyState = BabyState.Observing;
				observingPlayer = null;
				SetBabyObservingObjectServerRpc(NetworkObjectReference.op_Implicit(((NetworkBehaviour)component).NetworkObject));
				return true;
			}
		}
		return false;
	}

	private void DoBabyAIInterval()
	{
		//IL_0547: Unknown result type (might be due to invalid IL or missing references)
		//IL_054c: Unknown result type (might be due to invalid IL or missing references)
		//IL_055b: Unknown result type (might be due to invalid IL or missing references)
		//IL_056b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0496: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0678: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_060d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0775: Unknown result type (might be due to invalid IL or missing references)
		//IL_0785: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f6: Unknown result type (might be due to invalid IL or missing references)
		if (holdingBaby || rolledOver)
		{
			return;
		}
		bool num = !babyRunning;
		bool flag = false;
		if (num)
		{
			if (!babyCrying)
			{
				PlayerControllerB[] allPlayerBodiesInLineOfSight = GetAllPlayerBodiesInLineOfSight(50f, 20, BabyEye, 2f);
				if (allPlayerBodiesInLineOfSight != null)
				{
					for (int i = 0; i < allPlayerBodiesInLineOfSight.Length; i++)
					{
						BabyPlayerMemory babyMemoryOfPlayer = GetBabyMemoryOfPlayer(allPlayerBodiesInLineOfSight[i]);
						if (babyMemoryOfPlayer != null && babyMemoryOfPlayer.orderSeen != -1)
						{
							if (babyMemoryOfPlayer.likeMeter > 0.4f && (Object)(object)allPlayerBodiesInLineOfSight[i].deadBody.grabBodyObject != (Object)null && (Object)(object)((NetworkBehaviour)allPlayerBodiesInLineOfSight[i].deadBody.grabBodyObject).NetworkObject != (Object)null && ((NetworkBehaviour)allPlayerBodiesInLineOfSight[i].deadBody.grabBodyObject).NetworkObject.IsSpawned)
							{
								babyState = BabyState.Observing;
								observingScrap = null;
								observingObject = ((Component)((Component)allPlayerBodiesInLineOfSight[i].deadBody.bodyParts[6]).transform).gameObject;
								observingPlayer = allPlayerBodiesInLineOfSight[i];
								flag = true;
								SetBabyObservingObjectServerRpc(NetworkObjectReference.op_Implicit(((NetworkBehaviour)allPlayerBodiesInLineOfSight[i].deadBody.grabBodyObject).NetworkObject));
							}
							babyMemoryOfPlayer.isPlayerDead = true;
						}
					}
				}
			}
			int num2 = -1;
			bool flag2 = false;
			if ((Object)(object)observingPlayer != (Object)null)
			{
				num2 = (int)observingPlayer.playerClientId;
			}
			int num3 = -1;
			PlayerControllerB[] allPlayersInLineOfSight = GetAllPlayersInLineOfSight(120f, 30, BabyEye, 3f);
			if (allPlayersInLineOfSight != null)
			{
				for (int j = 0; j < allPlayersInLineOfSight.Length; j++)
				{
					Debug.DrawLine(((Component)BabyEye).transform.position, ((Component)allPlayersInLineOfSight[j].gameplayCamera).transform.position, Color.green, 1f);
					BabyPlayerMemory babyMemoryOfPlayer2 = GetBabyMemoryOfPlayer(allPlayersInLineOfSight[j]);
					if (babyMemoryOfPlayer2 == null)
					{
						continue;
					}
					if (Time.realtimeSinceStartup - babyMemoryOfPlayer2.timeAtLastSighting > 4f)
					{
						babyMemoryOfPlayer2.timeAtLastNoticing = Time.realtimeSinceStartup;
					}
					babyMemoryOfPlayer2.timeAtLastSighting = Time.realtimeSinceStartup;
					if (babyMemoryOfPlayer2.orderSeen == -1)
					{
						if (playersSeen == 0)
						{
							babyMemoryOfPlayer2.likeMeter = Random.Range(0.4f, 0.8f);
							if (num3 < 3 || pingAttentionTimer <= 0f)
							{
								flag2 = true;
							}
						}
						else
						{
							babyMemoryOfPlayer2.likeMeter = Random.Range(-0.2f, 0.5f);
							if (focusLevel <= 2 || pingAttentionTimer <= 0f || ((Object)(object)observingScrap != (Object)null && timeSpentObservingTimer > 4f))
							{
								flag2 = true;
							}
						}
						playersSeen++;
						babyMemoryOfPlayer2.orderSeen = playersSeen;
					}
					else if (Time.realtimeSinceStartup - babyMemoryOfPlayer2.timeAtLastSighting > 26f && babyMemoryOfPlayer2.likeMeter > 0.25f && lonelinessMeter > babyRoamFromPlayersThreshold)
					{
						if (focusLevel < 2 || pingAttentionTimer <= 0f || ((Object)(object)observingScrap != (Object)null && timeSpentObservingTimer > 4f))
						{
							flag2 = true;
						}
					}
					else if (lonelinessMeter > 0.75f && !Object.op_Implicit((Object)(object)observingPlayer))
					{
						flag2 = true;
					}
					if (flag2)
					{
						if (num2 != -1)
						{
							BabyPlayerMemory babyMemoryOfPlayer3 = GetBabyMemoryOfPlayer(StartOfRound.Instance.allPlayerScripts[num2]);
							if (babyMemoryOfPlayer2.likeMeter > babyMemoryOfPlayer3.likeMeter)
							{
								num2 = (int)allPlayersInLineOfSight[j].playerClientId;
								num3 = 3;
							}
						}
						else
						{
							num2 = (int)allPlayersInLineOfSight[j].playerClientId;
							num3 = 3;
						}
					}
					flag2 = false;
				}
				if (num2 != -1 && !flag)
				{
					babyState = BabyState.Observing;
					focusLevel = num3;
					observingScrap = null;
					observingObject = ((Component)StartOfRound.Instance.allPlayerScripts[num2].gameplayCamera).gameObject;
					observingPlayer = StartOfRound.Instance.allPlayerScripts[num2];
					flag = true;
					SetBabyObservingPlayerServerRpc(num2, 1);
				}
			}
			if (!babyCrying && !flag && BabyObserveScrap())
			{
				flag = true;
			}
		}
		switch (babyState)
		{
		case BabyState.Roaming:
			if (pathingTowardsNearestPlayer)
			{
				if (babySearchRoutine.inProgress)
				{
					StopSearch(babySearchRoutine);
				}
				if (TargetClosestPlayer())
				{
					SetMovingTowardsTargetPlayer(targetPlayer);
				}
				break;
			}
			if (sittingDown)
			{
				agent.speed = 0f;
				break;
			}
			if (!isInsidePlayerShip && !babySearchRoutine.inProgress)
			{
				Transform val = ChooseClosestNodeToPosition(((Component)this).transform.position, avoidLineOfSight: false, Random.Range(5, allAINodes.Length / 2));
				Vector3 position = val.position;
				Debug.Log((object)("Starting search at node " + ((Object)val).name), (Object)(object)((Component)val).gameObject);
				StartSearch(position, babySearchRoutine);
			}
			if (babyCrying)
			{
				agent.speed = 2.5f;
			}
			else
			{
				agent.speed = 4f;
			}
			break;
		case BabyState.Observing:
		{
			if ((Object)(object)observingObject == (Object)null)
			{
				break;
			}
			if (babySearchRoutine.inProgress)
			{
				StopSearch(babySearchRoutine);
			}
			Vector3 position2 = observingObject.transform.position;
			position2.y = ((Component)BabyEye).transform.position.y;
			if (!CheckLineOfSightForPosition(position2, 120f, 10, 3f, BabyEye))
			{
				cantFindObservedObjectTimer = Mathf.Max(cantFindObservedObjectTimer + AIIntervalTime, 0f);
				if (cantFindObservedObjectTimer > 2.3f)
				{
					babyState = BabyState.Roaming;
					break;
				}
				if (sittingDown)
				{
					sittingDown = false;
					SetBabySittingServerRpc(sit: false);
				}
				Vector3 navMeshPosition = RoundManager.Instance.GetNavMeshPosition(observingObject.transform.position, default(NavMeshHit), 6f);
				if (RoundManager.Instance.GotNavMeshPositionResult)
				{
					SetDestinationToPosition(navMeshPosition);
					agent.speed = 4.2f;
				}
				break;
			}
			if (Object.op_Implicit((Object)(object)observingPlayer) && (observingPlayer.isPlayerDead || (observingPlayer.criticallyInjured && Time.realtimeSinceStartup - timeSinceCryingFromScarySight > 12f)))
			{
				timeSinceCryingFromScarySight = Time.realtimeSinceStartup;
				ScareBaby(((Component)observingPlayer).transform.position);
				break;
			}
			if (!babyCrying && Time.realtimeSinceStartup - timeSinceCryingFromScarySight > 5f && Object.op_Implicit((Object)(object)observingScrap) && observingScrap.itemProperties.itemId == 123984)
			{
				CaveDwellerPhysicsProp caveDwellerPhysicsProp = observingScrap as CaveDwellerPhysicsProp;
				if ((Object)(object)caveDwellerPhysicsProp != (Object)null && caveDwellerPhysicsProp.caveDwellerScript.babyCrying)
				{
					timeSinceCryingFromScarySight = Time.realtimeSinceStartup;
					SetCryingLocalClient(setCrying: true);
					SetBabyCryingServerRpc(setCry: true);
					break;
				}
			}
			if (eatingScrap)
			{
				if ((Object)(object)observingScrap != (Object)null && !observingScrap.isHeld && SetDestinationToPosition(observingObject.transform.position))
				{
					if (sittingDown)
					{
						sittingDown = false;
						SetBabySittingServerRpc(sit: false);
					}
					agent.speed = 3.6f;
					if (Vector3.Distance(((Component)this).transform.position, observingObject.transform.position) < 0.9f)
					{
						eatingScrap = false;
						babyState = BabyState.Roaming;
						((NetworkBehaviour)observingScrap).NetworkObject.Despawn(true);
						StopObserving(eatScrap: true);
						break;
					}
					if (Time.realtimeSinceStartup - timeSinceEatingScrap > 7f)
					{
						eatingScrap = false;
					}
				}
				else
				{
					if (!observingScrap.isHeld && (Object)(object)observingScrap.playerHeldBy != (Object)null)
					{
						BabyPlayerMemory babyMemoryOfPlayer4 = GetBabyMemoryOfPlayer(observingScrap.playerHeldBy);
						babyMemoryOfPlayer4.likeMeter = Mathf.Max(babyMemoryOfPlayer4.likeMeter - 0.2f, -0.5f);
					}
					eatingScrap = false;
				}
			}
			else if ((Object)(object)observingPlayer == (Object)null && (Object)(object)observingScrap != (Object)null && !observingScrap.isHeld && observingScrap.itemProperties.itemId != 123984 && Time.realtimeSinceStartup - eatScrapRandomCheckInterval > 3f)
			{
				if (!seenScrap.Contains(observingObject))
				{
					seenScrap.Add(observingObject);
					if (seenScrap.Count > 5)
					{
						seenScrap.RemoveAt(0);
					}
				}
				eatScrapRandomCheckInterval = Time.realtimeSinceStartup;
				if ((Random.Range(0, 100) < 20 || (isInsidePlayerShip && Random.Range(0, 100) < 70)) && (Time.realtimeSinceStartup - timeSinceEatingScrap > 25f || (Time.realtimeSinceStartup - timeSinceEatingScrap > 1f && Random.Range(0, 100) < 40)))
				{
					eatingScrap = true;
					timeSinceEatingScrap = Time.realtimeSinceStartup;
				}
			}
			cantFindObservedObjectTimer = Mathf.Min(cantFindObservedObjectTimer - AIIntervalTime, 0f);
			BabyPlayerMemory babyPlayerMemory = null;
			if ((Object)(object)observingPlayer != (Object)null)
			{
				babyPlayerMemory = GetBabyMemoryOfPlayer(observingPlayer);
			}
			if ((Object)(object)observingPlayer != (Object)null && observingPlayer.isPlayerDead && (Object)(object)observingPlayer.deadBody != (Object)null && babyPlayerMemory != null && babyPlayerMemory.orderSeen != -1 && babyPlayerMemory.likeMeter > 0.4f)
			{
				ScareBaby(((Component)observingPlayer.deadBody.bodyParts[5]).transform.position);
			}
			break;
		}
		case BabyState.Running:
		{
			if (babySearchRoutine.inProgress)
			{
				StopSearch(babySearchRoutine);
			}
			if ((Object)(object)farthestNodeFromRunningSpot == (Object)null)
			{
				gettingFarthestNodeFromSpotAsync = true;
				break;
			}
			SetDestinationToPosition(((Component)farthestNodeFromRunningSpot).transform.position);
			agent.speed = 6.25f;
			if (Vector3.Distance(((Component)this).transform.position, ((Component)farthestNodeFromRunningSpot).transform.position) < 4f)
			{
				if (babyCrying)
				{
					farthestNodeFromRunningSpot = null;
					break;
				}
				babyState = BabyState.Roaming;
			}
			if (babyCrying)
			{
				break;
			}
			float num4 = Vector3.Distance(((Component)this).transform.position, runningFromPosition);
			if (num4 > 16f)
			{
				if (Time.realtimeSinceStartup - currentActivityTimer > 10f)
				{
					babyState = BabyState.Roaming;
				}
			}
			else if (num4 > 26f)
			{
				babyState = BabyState.Roaming;
			}
			break;
		}
		case BabyState.RolledOver:
			if (babySearchRoutine.inProgress)
			{
				StopSearch(babySearchRoutine);
			}
			agent.speed = 0f;
			break;
		}
	}

	private void ScareBaby(Vector3 runFromPosition)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (sittingDown && !holdingBaby)
		{
			SetRolledOverLocalClient(setRolled: true, scared: true);
			SetBabyRolledOverServerRpc(rolledOver: true, scared: true);
			return;
		}
		runningFromPosition = runFromPosition;
		currentActivityTimer = Time.realtimeSinceStartup;
		farthestNodeFromRunningSpot = null;
		SetCryingLocalClient(setCrying: true);
		babyState = BabyState.Running;
		if ((Object)(object)propScript.playerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			propScript.playerHeldBy.DiscardHeldObject();
		}
		ScareBabyServerRpc();
	}

	[ServerRpc(RequireOwnership = false)]
	public void ScareBabyServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1374882881u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1374882881u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ScareBabyClientRpc();
			}
		}
	}

	[ClientRpc]
	public void ScareBabyClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4230781752u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4230781752u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
		{
			SetCryingLocalClient(setCrying: true);
			babyRunning = true;
			if ((Object)(object)propScript.playerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				propScript.playerHeldBy.DiscardHeldObject();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabySittingServerRpc(bool sit)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1144090475u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref sit, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1144090475u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabySittingClientRpc(sit);
			}
		}
	}

	[ClientRpc]
	public void SetBabySittingClientRpc(bool sit)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2098313814u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref sit, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2098313814u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				sittingDown = sit;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabyRolledOverServerRpc(bool rolledOver, bool scared)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4101944549u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref rolledOver, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref scared, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4101944549u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabyRolledOverClientRpc(rolledOver, scared);
			}
		}
	}

	[ClientRpc]
	public void SetBabyRolledOverClientRpc(bool setRolled, bool scared)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1836135136u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setRolled, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref scared, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1836135136u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				SetRolledOverLocalClient(setRolled, scared);
			}
		}
	}

	private void PlayBabyScaredAudio()
	{
		RoundManager.PlayRandomClip(babyVoice, scaredBabyVoiceSFX);
	}

	private void SetRolledOverLocalClient(bool setRolled, bool scared)
	{
		Debug.Log((object)$"Set rolled local client to {setRolled}; scared: {scared}");
		if (scared && setRolled)
		{
			PlayBabyScaredAudio();
			rollOverTimer = 0.7f;
		}
		else if (setRolled && !rolledOver)
		{
			babyState = BabyState.RolledOver;
			rollOverTimer = 0f;
		}
		rolledOver = setRolled;
		Debug.Log((object)$"Set fall over anim: {setRolled}");
		babyCreatureAnimator.SetBool("FallOver", setRolled);
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabyCryingServerRpc(bool setCry)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2038363846u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setCry, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2038363846u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabyCryingClientRpc(setCry);
			}
		}
	}

	[ClientRpc]
	public void SetBabyCryingClientRpc(bool setCry)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1443484045u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setCry, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1443484045u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				SetCryingLocalClient(setCry);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabyBServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(547761068u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 547761068u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabyBClientRpc();
			}
		}
	}

	[ClientRpc]
	public void SetBabyBClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2728788472u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2728788472u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && !networkManager.IsClient && networkManager.IsHost)
			{
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabyRunningServerRpc(bool setRunning)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2669712327u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setRunning, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2669712327u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabyRunningClientRpc(setRunning);
			}
		}
	}

	[ClientRpc]
	public void SetBabyRunningClientRpc(bool setRunning)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3854344690u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setRunning, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3854344690u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				babyRunning = setRunning;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabySquirmingServerRpc(bool setSquirm)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3479454888u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setSquirm, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3479454888u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabySquirmingClientRpc(setSquirm);
			}
		}
	}

	[ClientRpc]
	public void SetBabySquirmingClientRpc(bool setSquirm)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3633542544u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setSquirm, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3633542544u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				babySquirming = setSquirm;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ClearBabyObservingServerRpc(bool eatScrap)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1944396819u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref eatScrap, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1944396819u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClearBabyObservingClientRpc(eatScrap);
			}
		}
	}

	[ClientRpc]
	public void ClearBabyObservingClientRpc(bool eatScrap)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4108007701u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref eatScrap, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4108007701u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
		{
			observingPlayer = null;
			observingObject = null;
			observingScrap = null;
			if (eatScrap)
			{
				scrapEaten++;
				babyCreatureAnimator.SetTrigger("Bite");
				babyVoice.PlayOneShot(biteSFX);
				timeSinceBiting = Time.realtimeSinceStartup;
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)babyLookRig).weight = 0f;
				float num = Mathf.Lerp(1f, 1.6f, Mathf.Min((float)scrapEaten, 5f) / 5f);
				spine2.localScale = new Vector3(num, 1f, num);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabyObservingPlayerServerRpc(int playerId, int setFocusLevel)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(843410401u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				BytePacker.WriteValueBitPacked(val2, setFocusLevel);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 843410401u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabyObservingPlayerClientRpc(playerId, setFocusLevel);
			}
		}
	}

	[ClientRpc]
	public void SetBabyObservingPlayerClientRpc(int playerId, int setFocusLevel)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4106177627u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				BytePacker.WriteValueBitPacked(val2, setFocusLevel);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4106177627u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				observingScrap = null;
				observingPlayer = StartOfRound.Instance.allPlayerScripts[playerId];
				focusLevel = setFocusLevel;
				observingObject = ((Component)((Component)StartOfRound.Instance.allPlayerScripts[playerId].gameplayCamera).transform).gameObject;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetBabyObservingObjectServerRpc(NetworkObjectReference netObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3360410662u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObject, default(ForNetworkSerializable));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3360410662u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetBabyObservingObjectClientRpc(netObject);
			}
		}
	}

	[ClientRpc]
	public void SetBabyObservingObjectClientRpc(NetworkObjectReference netObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(353948947u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObject, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 353948947u, val, (RpcDelivery)0);
		}
		NetworkObject val3 = default(NetworkObject);
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && ((NetworkObjectReference)(ref netObject)).TryGet(ref val3, (NetworkManager)null))
		{
			observingObject = ((Component)val3).gameObject;
			GrabbableObject component = observingObject.GetComponent<GrabbableObject>();
			if ((Object)(object)component != (Object)null)
			{
				observingScrap = component;
			}
		}
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesPlayedInOneSpot, noiseID);
		if (noiseID == 6 || noiseID == 7 || (!((NetworkBehaviour)this).IsServer && noiseID != 75) || isEnemyDead || noiseLoudness <= 0.1f || Time.realtimeSinceStartup - timeAtLastHeardNoise < 3f || Vector3.Distance(noisePosition, ((Component)this).transform.position + Vector3.up * 0.4f) < 0.8f)
		{
			return;
		}
		float num = Vector3.Distance(noisePosition, ((Component)this).transform.position);
		if (Physics.Linecast(((Component)this).transform.position, noisePosition, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			noiseLoudness *= 0.6f;
			num += 3f;
		}
		if (pingAttentionTimer > 0f)
		{
			if (focusLevel >= 3)
			{
				if (num > 7f || noiseLoudness <= 0.7f)
				{
					return;
				}
			}
			else if (focusLevel == 2)
			{
				if (num > 14f || noiseLoudness <= 0.4f)
				{
					return;
				}
			}
			else if (focusLevel <= 1 && (num > 20f || noiseLoudness <= 0.25f))
			{
				return;
			}
		}
		timeAtLastHeardNoise = Time.realtimeSinceStartup;
		int newFocusLevel = 1;
		Debug.Log((object)$"Heard noise; noise loudness: {noiseLoudness}; noise distance: {num}");
		if (!((NetworkBehaviour)this).IsServer || noiseID == 75 || ((!(num < 10f) || !(noiseLoudness >= 0.3f)) && (!(num < 14f) || !(noiseLoudness >= 0.85f))))
		{
			newFocusLevel = ((!(noiseLoudness > 0.6f)) ? 2 : 3);
		}
		else if (Time.realtimeSinceStartup - scareBabyWhileHoldingCooldown > 0.4f)
		{
			if (babyCrying)
			{
				ScareBaby(noisePosition);
				return;
			}
			scareBabyWhileHoldingCooldown = Time.realtimeSinceStartup;
			SetCryingLocalClient(setCrying: true);
			SetBabyCryingServerRpc(setCry: true);
			return;
		}
		PingAttention(newFocusLevel, 0.5f, noisePosition + Vector3.up * 0.6f);
	}

	private void BabyObserveAnimation()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0338: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		bool num = babyRunning || babyCrying || rolledOver || Time.realtimeSinceStartup - timeSinceBiting < 0.75f;
		bool flag = (Object)(object)observingObject != (Object)null && Physics.Linecast(((Component)BabyEye).transform.position, observingObject.transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1);
		if (num || flag)
		{
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)babyLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)babyLookRig).weight, 0f, Time.deltaTime * 3f);
			agent.angularSpeed = 320f;
			return;
		}
		Vector3 val;
		if (pingAttentionTimer > 0f && ((Object)(object)observingObject == (Object)null || Vector3.Distance(observingObject.transform.position, pingAttentionPosition) > 1.6f))
		{
			val = pingAttentionPosition - Vector3.up * lookVerticalOffset;
			Debug.DrawRay(val, Vector3.up * 0.25f, Color.cyan);
		}
		else
		{
			if (!((Object)(object)observingObject != (Object)null) || holdingBaby)
			{
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)babyLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)babyLookRig).weight, 0f, Time.deltaTime * 3f);
				agent.angularSpeed = 320f;
				return;
			}
			val = observingObject.transform.position - Vector3.up * lookVerticalOffset;
			Debug.DrawRay(val, Vector3.up * 0.25f, Color.cyan);
		}
		((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)babyLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)babyLookRig).weight, 1f, Time.deltaTime * 8f);
		babyLookTarget.position = Vector3.Lerp(babyLookTarget.position, val, Time.deltaTime * 8f);
		float num2 = Vector3.Angle(((Component)this).transform.forward, Vector3.Scale(new Vector3(1f, 0f, 1f), val - ((Component)this).transform.position));
		if (num2 > 10f)
		{
			if (!movedSinceLastCheck && !sittingDown)
			{
				agent.angularSpeed = 0f;
				if (Vector3.Dot(new Vector3(val.x, ((Component)this).transform.position.y, val.z) - ((Component)this).transform.position, ((Component)this).transform.right) > 0f)
				{
					Transform transform = ((Component)this).transform;
					transform.rotation *= Quaternion.Euler(0f, 605f * Mathf.Max(num2 / 180f, 0.2f) * Time.deltaTime, 0f);
				}
				else
				{
					Transform transform2 = ((Component)this).transform;
					transform2.rotation *= Quaternion.Euler(0f, -605f * Mathf.Max(num2 / 180f, 0.2f) * Time.deltaTime, 0f);
				}
			}
			else
			{
				agent.angularSpeed = 220f;
			}
		}
		else
		{
			agent.angularSpeed = 25f;
		}
	}

	private void SitCycle()
	{
		if (sittingDown)
		{
			if (Time.realtimeSinceStartup - currentActivityTimer > 12f + activityTimerOffset && !isInsidePlayerShip)
			{
				currentActivityTimer = Time.realtimeSinceStartup;
				activityTimerOffset = 7f;
				sittingDown = false;
				SetBabySittingServerRpc(sit: false);
			}
			else if (Time.realtimeSinceStartup - fallOverWhileSittingChanceInterval > 3f)
			{
				fallOverWhileSittingChanceInterval = Time.realtimeSinceStartup;
				if (Random.Range(0, 100) < 10)
				{
					SetRolledOverLocalClient(setRolled: true, scared: false);
					SetBabyRolledOverServerRpc(rolledOver: true, scared: false);
				}
			}
		}
		else if (isInsidePlayerShip || Time.realtimeSinceStartup - currentActivityTimer > 14f + activityTimerOffset)
		{
			currentActivityTimer = Time.realtimeSinceStartup;
			activityTimerOffset = 8f;
			sittingDown = true;
			fallOverWhileSittingChanceInterval = Time.realtimeSinceStartup;
			SetBabySittingServerRpc(sit: true);
		}
	}

	private void StopObserving(bool eatScrap)
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		observingObject = null;
		observingScrap = null;
		observingPlayer = null;
		if (eatScrap)
		{
			scrapEaten++;
			babyCreatureAnimator.SetTrigger("Bite");
			babyVoice.PlayOneShot(biteSFX);
			timeSinceBiting = Time.realtimeSinceStartup;
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)babyLookRig).weight = 0f;
			float num = Mathf.Lerp(1f, 1.6f, Mathf.Min((float)scrapEaten, 3f) / 3f);
			spine2.localScale = new Vector3(num, 1f, num);
		}
		ClearBabyObservingServerRpc(eatScrap);
	}

	private void SetCryingLocalClient(bool setCrying)
	{
		Debug.Log((object)$"Baby crying set to {setCrying}");
		if (!babyCrying && setCrying)
		{
			Debug.Log((object)"Baby crying set true; play");
			babyCrying = true;
			babyCryingAudio.Play();
			babyTearsParticle.Play(true);
		}
		else if (!setCrying && babyCrying)
		{
			Debug.Log((object)"Baby crying  set false");
			babyCrying = false;
			babyTearsParticle.Stop(true, (ParticleSystemStopBehavior)1);
		}
	}

	private void BabyUpdate()
	{
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0423: Unknown result type (might be due to invalid IL or missing references)
		//IL_0428: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0569: Unknown result type (might be due to invalid IL or missing references)
		//IL_0579: Unknown result type (might be due to invalid IL or missing references)
		//IL_0611: Unknown result type (might be due to invalid IL or missing references)
		//IL_0616: Unknown result type (might be due to invalid IL or missing references)
		//IL_0620: Unknown result type (might be due to invalid IL or missing references)
		//IL_0625: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a49: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aaf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0add: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b38: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b28: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0beb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bfd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc6: Unknown result type (might be due to invalid IL or missing references)
		babyCreatureAnimator.SetBool("Sitting", sittingDown);
		babyCreatureAnimator.SetBool("BabyRunning", babyRunning);
		babyCreatureAnimator.SetBool("HoldingBaby", holdingBaby);
		babyCreatureAnimator.SetBool("BabyCrying", babyCrying);
		babyCreatureAnimator.SetBool("Squirming", babySquirming);
		pingAttentionTimer -= Time.deltaTime;
		BabyObserveAnimation();
		if (StartOfRound.Instance.shipIsLeaving)
		{
			propScript.grabbable = false;
			if ((Object)(object)playerHolding != (Object)null)
			{
				playerHolding.DiscardHeldObject();
			}
		}
		else if (!inSpecialAnimation)
		{
			propScript.grabbable = true;
		}
		if (babySquirming)
		{
			if (!babyVoice.isPlaying || (Object)(object)babyVoice.clip != (Object)(object)squirmingSFX)
			{
				babyVoice.clip = squirmingSFX;
				babyVoice.Play();
			}
		}
		else if ((Object)(object)babyVoice.clip == (Object)(object)squirmingSFX && babyVoice.isPlaying)
		{
			babyVoice.Stop();
		}
		if (babyCrying)
		{
			babyCryingAudio.pitch = Mathf.Lerp(babyCryingAudio.pitch, 1f, 2f * Time.deltaTime);
			babyCryingAudio.volume = Mathf.Lerp(babyCryingAudio.volume, 1f, 2f * Time.deltaTime);
		}
		else
		{
			babyCryingAudio.pitch = Mathf.Lerp(babyCryingAudio.pitch, 0.85f, 3f * Time.deltaTime);
			babyCryingAudio.volume = Mathf.Lerp(babyCryingAudio.volume, 0f, 3.6f * Time.deltaTime);
			if (babyCryingAudio.volume <= 0.07f && babyCryingAudio.isPlaying)
			{
				babyCryingAudio.Stop();
				if (!babyPuked && nearTransforming)
				{
					babyPuked = true;
					babyVoice.PlayOneShot(pukeSFX);
					WalkieTalkie.TransmitOneShotAudio(babyVoice, pukeSFX);
					babyFoamAtMouthParticle.Play(true);
				}
			}
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (holdingBaby && (Object)(object)playerHolding != (Object)null)
		{
			hasPlayerFoundBaby = true;
			if (Time.realtimeSinceStartup - scareBabyWhileHoldingCooldown > 0.4f && Time.realtimeSinceStartup - playerHolding.timeSinceTakingDamage < 0.38f)
			{
				scareBabyWhileHoldingCooldown = Time.realtimeSinceStartup;
				if (babyCrying)
				{
					ScareBaby(((Component)this).transform.position);
				}
				else
				{
					SetCryingLocalClient(setCrying: true);
					SetBabyCryingServerRpc(setCry: true);
				}
			}
		}
		if (babyCrying)
		{
			if (babySquirming)
			{
				babySquirming = false;
				SetBabySquirmingServerRpc(setSquirm: false);
			}
			if (!stopCryingWhenReleased && !isOutside)
			{
				lonelinessMeter = 0.7f;
				if (rockingBaby != 0 && babyState == BabyState.Running)
				{
					babyState = BabyState.Roaming;
				}
				if (rockingBaby == 1)
				{
					rockBabyTimer += Time.deltaTime * 0.7f;
				}
				else if (rockingBaby == 2)
				{
					rockBabyTimer += Time.deltaTime * 0.4f;
				}
				if (rockBabyTimer > 1f)
				{
					SetCryingLocalClient(setCrying: false);
					SetBabyCryingServerRpc(setCry: false);
				}
			}
		}
		else
		{
			rockBabyTimer = 0f;
			if (rockingBaby == 2)
			{
				stressMeter += Time.deltaTime * 0.8f;
				if (stressMeter >= 1f)
				{
					stressMeter = 0f;
					stopCryingWhenReleased = true;
					babyState = BabyState.Running;
					runningFromPosition = ((Component)this).transform.position;
					farthestNodeFromRunningSpot = null;
					SetCryingLocalClient(setCrying: true);
					SetBabyCryingServerRpc(setCry: true);
				}
			}
			else if (rockingBaby == 1 && (Object)(object)propScript.playerHeldBy != (Object)null && lonelinessMeter > 0.6f)
			{
				BabyPlayerMemory babyMemoryOfPlayer = GetBabyMemoryOfPlayer(propScript.playerHeldBy);
				babyMemoryOfPlayer.likeMeter = Mathf.Min(new float[1] { babyMemoryOfPlayer.likeMeter + Time.deltaTime * 0.035f });
			}
		}
		if (isOutside && !isInsidePlayerShip && !babyCrying)
		{
			SetCryingLocalClient(setCrying: true);
			SetBabyCryingServerRpc(setCry: true);
		}
		IncreaseBabyGrowthMeter();
		if (currentBehaviourStateIndex != 0)
		{
			return;
		}
		if (rolledOver)
		{
			rollOverTimer += Time.deltaTime;
			if (!babyCrying && rollOverTimer > 1.3f)
			{
				SetCryingLocalClient(setCrying: true);
				SetBabyCryingServerRpc(setCry: true);
			}
		}
		if (!holdingBaby)
		{
			if (babySquirming)
			{
				babySquirming = false;
				SetBabySquirmingServerRpc(setSquirm: false);
			}
			if (stopCryingWhenReleased)
			{
				stopCryingWhenReleased = false;
				SetCryingLocalClient(setCrying: false);
				SetBabyCryingServerRpc(setCry: false);
			}
			if ((Object)(object)observingPlayer != (Object)null && Vector3.Distance(((Component)this).transform.position, ((Component)observingPlayer).transform.position) < 12f)
			{
				BabyPlayerMemory babyMemoryOfPlayer2 = GetBabyMemoryOfPlayer(observingPlayer);
				lonelinessMeter = Mathf.Max(0f, lonelinessMeter - Time.deltaTime * (decreaseLonelinessMultiplier / Mathf.Max(babyMemoryOfPlayer2.likeMeter * 3f, 0.45f)) * moodinessMultiplier);
			}
			else
			{
				if (!hasPlayerFoundBaby)
				{
					for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
					{
						if (PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[i]) && StartOfRound.Instance.allPlayerScripts[i].HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.25f, 140f, 50, 5f))
						{
							hasPlayerFoundBaby = true;
							break;
						}
					}
				}
				if (playersSeen > 0 || hasPlayerFoundBaby)
				{
					lonelinessMeter = Mathf.Min(1f, lonelinessMeter + Time.deltaTime * increaseLonelinessMultiplier * moodinessMultiplier);
				}
				else
				{
					lonelinessMeter = Mathf.Min(1f, lonelinessMeter + Time.deltaTime * 0.01f * moodinessMultiplier);
				}
			}
			if (holdingBaby)
			{
				return;
			}
			switch (babyState)
			{
			case BabyState.Roaming:
				if (previousBabyState != (int)babyState)
				{
					currentActivityTimer = Time.realtimeSinceStartup;
					activityTimerOffset = Random.Range(-10f, 10f);
					leapTimer = 0f;
					if (Object.op_Implicit((Object)(object)observingObject))
					{
						StopObserving(eatScrap: false);
					}
					eatingScrap = false;
					if (sittingDown)
					{
						sittingDown = false;
						SetBabySittingServerRpc(sit: false);
					}
					if (babyRunning)
					{
						babyRunning = false;
						SetBabyRunningServerRpc(setRunning: false);
					}
					previousBabyState = (int)babyState;
				}
				if (playersSeen == 0)
				{
					if (pathingTowardsNearestPlayer)
					{
						if (Time.realtimeSinceStartup - currentActivityTimer > 20f + activityTimerOffset)
						{
							currentActivityTimer = Time.realtimeSinceStartup;
							pathingTowardsNearestPlayer = false;
						}
					}
					else if (Time.realtimeSinceStartup - currentActivityTimer > 26f)
					{
						currentActivityTimer = Time.realtimeSinceStartup;
						activityTimerOffset = Random.Range(-6f, 6f);
						pathingTowardsNearestPlayer = true;
					}
				}
				else
				{
					pathingTowardsNearestPlayer = false;
					if (lonelinessMeter >= 0.99f && !babyCrying)
					{
						SetCryingLocalClient(setCrying: true);
						SetBabyCryingServerRpc(setCry: true);
					}
					if (babyCrying)
					{
						if (sittingDown)
						{
							sittingDown = false;
							SetBabySittingServerRpc(sit: false);
						}
					}
					else
					{
						SitCycle();
					}
				}
				if ((Object)(object)observingObject != (Object)null && !eatingScrap)
				{
					timeSpentObservingTimer += Time.deltaTime;
					if (timeSpentObservingTimer > 3f)
					{
						timeSpentObservingTimer = 0f;
						StopObserving(eatScrap: false);
					}
				}
				break;
			case BabyState.Observing:
			{
				if (previousBabyState != (int)babyState)
				{
					timeSpentObservingTimer = 0f;
					cantFindObservedObjectTimer = 0f;
					currentActivityTimer = Time.realtimeSinceStartup;
					eatingScrap = false;
					leapTimer = 0f;
					if (babyRunning)
					{
						babyRunning = false;
						SetBabyRunningServerRpc(setRunning: false);
					}
					previousBabyState = (int)babyState;
				}
				if (eatingScrap)
				{
					break;
				}
				BabyPlayerMemory babyPlayerMemory = null;
				if ((Object)(object)observingPlayer != (Object)null)
				{
					babyPlayerMemory = GetBabyMemoryOfPlayer(observingPlayer);
				}
				float num = 4.7f;
				if (Object.op_Implicit((Object)(object)observingScrap))
				{
					num = 2f;
				}
				else if (Object.op_Implicit((Object)(object)observingPlayer) && babyPlayerMemory != null && babyPlayerMemory.likeMeter < 0.25f && lonelinessMeter < 0.75f)
				{
					num = 6.7f;
				}
				float num2 = Vector3.Distance(((Component)this).transform.position, observingObject.transform.position);
				if (num - num2 > 1.5f)
				{
					Ray val2 = default(Ray);
					((Ray)(ref val2))._002Ector(((Component)this).transform.position, ((Component)this).transform.position + Vector3.up * 0.2f - observingObject.transform.position + Vector3.up * 0.2f);
					((Ray)(ref val2)).direction = new Vector3(((Ray)(ref val2)).direction.x, 0f, ((Ray)(ref val2)).direction.z);
					Debug.DrawRay(((Component)this).transform.position, ((Ray)(ref val2)).direction, Color.cyan);
					Vector3 pos = ((!Physics.Raycast(val2, ref hit, 10f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)) ? ((Ray)(ref val2)).GetPoint(10f) : ((RaycastHit)(ref hit)).point);
					if (babyPlayerMemory != null && babyPlayerMemory.likeMeter < 0.25f)
					{
						babyPlayerMemory.likeMeter = Mathf.Max(babyPlayerMemory.likeMeter - AIIntervalTime * 0.2f, -0.5f);
						stressMeter = Mathf.Min(stressMeter + AIIntervalTime, 1f);
						if (stressMeter > 1f)
						{
							stressMeter = 0f;
							babyPlayerMemory.likeMeter = -0.2f;
							ScareBaby(observingObject.transform.position);
						}
					}
					if (sittingDown)
					{
						sittingDown = false;
						SetBabySittingServerRpc(sit: false);
					}
					pos = RoundManager.Instance.GetNavMeshPosition(pos, default(NavMeshHit), 6f);
					agent.speed = 4.6f;
					SetDestinationToPosition(pos);
				}
				else if (num2 > num)
				{
					if (sittingDown)
					{
						sittingDown = false;
						SetBabySittingServerRpc(sit: false);
					}
					agent.speed = 4.2f;
					SetDestinationToPosition(observingObject.transform.position);
				}
				else
				{
					SitCycle();
					agent.speed = 0f;
				}
				if ((Object)(object)observingPlayer != (Object)null)
				{
					timeSpentObservingTimer += Time.deltaTime;
					if (lonelinessMeter < babyRoamFromPlayersThreshold && timeSpentObservingTimer > 6f)
					{
						babyState = BabyState.Roaming;
					}
				}
				else
				{
					timeSpentObservingTimer += Time.deltaTime;
					if (timeSpentObservingTimer > 12f || lonelinessMeter > 0.88f)
					{
						babyState = BabyState.Roaming;
					}
				}
				break;
			}
			case BabyState.Running:
				if (previousBabyState != (int)babyState)
				{
					currentActivityTimer = Time.realtimeSinceStartup;
					farthestNodeFromRunningSpot = null;
					stressMeter = 0f;
					if (Object.op_Implicit((Object)(object)observingObject))
					{
						StopObserving(eatScrap: false);
					}
					eatingScrap = false;
					if (sittingDown)
					{
						sittingDown = false;
						SetBabySittingServerRpc(sit: false);
					}
					babyRunning = true;
					previousBabyState = (int)babyState;
				}
				if (gettingFarthestNodeFromSpotAsync && (Object)(object)farthestNodeFromRunningSpot == (Object)null)
				{
					Transform val = ChooseFarthestNodeFromPosition(runningFromPosition, avoidLineOfSight: false, 0, doAsync: true);
					if (gotFarthestNodeAsync)
					{
						farthestNodeFromRunningSpot = val;
						gettingFarthestNodeFromSpotAsync = false;
					}
				}
				break;
			case BabyState.RolledOver:
				if (previousBabyState != (int)babyState)
				{
					currentActivityTimer = Time.realtimeSinceStartup;
					farthestNodeFromRunningSpot = null;
					stressMeter = 0f;
					if (Object.op_Implicit((Object)(object)observingObject))
					{
						StopObserving(eatScrap: false);
					}
					eatingScrap = false;
					previousBabyState = (int)babyState;
				}
				break;
			}
			return;
		}
		BabyPlayerMemory babyMemoryOfPlayer3 = GetBabyMemoryOfPlayer(playerHolding);
		if (babySearchRoutine.inProgress)
		{
			StopSearch(babySearchRoutine);
		}
		if (!babyCrying)
		{
			if (babyMemoryOfPlayer3.likeMeter < 0.1f)
			{
				lonelinessMeter = Mathf.Max(0f, lonelinessMeter - Time.deltaTime * 0.025f);
			}
			else
			{
				lonelinessMeter = 0.75f;
			}
			if (lonelinessMeter < babyCrySquirmingThreshold)
			{
				stopCryingWhenReleased = true;
				SetCryingLocalClient(setCrying: true);
				SetBabyCryingServerRpc(setCry: true);
			}
			else if (!babySquirming && lonelinessMeter < babyRoamFromPlayersThreshold)
			{
				babySquirming = true;
				SetBabySquirmingServerRpc(setSquirm: true);
			}
		}
	}

	private Vector3 GetCavePosition(Random randomSeed)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		GameObject[] array = GameObject.FindGameObjectsWithTag("CaveNode");
		if (array == null || array.Length == 0)
		{
			return ChooseFarthestNodeFromPosition(RoundManager.FindMainEntrancePosition(), avoidLineOfSight: false, randomSeed.Next(0, Mathf.Min(allAINodes.Length, 40))).position;
		}
		List<GameObject> list = array.ToList();
		Transform transform = list[0].transform;
		for (int i = 0; i < 15; i++)
		{
			if (list.Count == 0)
			{
				break;
			}
			int index = randomSeed.Next(0, list.Count);
			transform = list[index].transform;
			if (!PathIsIntersectedByLineOfSight(transform.position, calculatePathDistance: false, avoidLineOfSight: false))
			{
				return transform.position;
			}
			list.Remove(list[index]);
			for (int num = list.Count - 1; num >= 0; num--)
			{
				if (Vector3.Distance(list[num].transform.position, transform.position) < 30f)
				{
					list.Remove(list[num]);
				}
			}
		}
		return ChooseClosestNodeToPosition(((Component)this).transform.position).position;
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncCaveHidingSpotServerRpc(Vector3 setHidingSpot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(564389360u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref setHidingSpot);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 564389360u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SyncCaveHidingSpotClientRpc(setHidingSpot);
			}
		}
	}

	[ClientRpc]
	public void SyncCaveHidingSpotClientRpc(Vector3 setHidingSpot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3993334803u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref setHidingSpot);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3993334803u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				caveHidingSpot = setHidingSpot;
			}
		}
	}

	public override void Start()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		currentSearchWidth = baseSearchWidth;
		if (((NetworkBehaviour)this).IsServer)
		{
			Random randomSeed = new Random(StartOfRound.Instance.randomMapSeed + 249);
			caveHidingSpot = GetCavePosition(randomSeed);
			SyncCaveHidingSpotServerRpc(caveHidingSpot);
		}
		InitializeBabyValues();
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		base.OnCollideWithPlayer(other);
		if (!(leapTimer < 0.02f) && currentBehaviourStateIndex == 3 && !isEnemyDead)
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other, inKillAnimation || startingKillAnimationLocalClient);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				KillPlayerAnimationServerRpc((int)playerControllerB.playerClientId);
				startingKillAnimationLocalClient = true;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KillPlayerAnimationServerRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3591556954u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerObjectId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3591556954u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (!inKillAnimation)
			{
				inKillAnimation = true;
				KillPlayerAnimationClientRpc(playerObjectId);
			}
			else
			{
				CancelKillAnimationClientRpc(playerObjectId);
			}
		}
	}

	[ClientRpc]
	public void CancelKillAnimationClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(40847295u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 40847295u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId == playerObjectId)
			{
				startingKillAnimationLocalClient = false;
			}
		}
	}

	[ClientRpc]
	public void KillPlayerAnimationClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1117359351u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerObjectId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1117359351u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[playerObjectId];
			if ((Object)(object)playerControllerB == (Object)null || playerControllerB.isPlayerDead || !playerControllerB.isInsideFactory)
			{
				FinishKillAnimation(completed: false);
			}
			if (currentBehaviourStateIndex == 3)
			{
				chasingAfterLeap = true;
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 0f;
				leaping = false;
				screaming = false;
				screamTimer = screamTime;
				creatureAnimator.SetBool("Leaping", false);
				creatureAnimator.SetBool("Screaming", false);
				startedLeapingThisFrame = false;
			}
			if ((Object)(object)playerControllerB == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				playerControllerB.KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Mauling);
				startingKillAnimationLocalClient = false;
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
				agent.speed = 0f;
			}
			inKillAnimation = true;
			creatureAnimator.SetBool("killing", true);
			if (killAnimationCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(killAnimationCoroutine);
			}
			killAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(killAnimation(playerControllerB));
		}
	}

	private IEnumerator killAnimation(PlayerControllerB killingPlayer)
	{
		float timeAtStart = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => Time.realtimeSinceStartup - timeAtStart > 2f || (Object)(object)killingPlayer.deadBody != (Object)null));
		if ((Object)(object)killingPlayer.deadBody != (Object)null)
		{
			GrabBody(killingPlayer.deadBody);
			yield return (object)new WaitForSeconds(0.5f);
			killPlayerParticle1.Play();
			if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position) < 10f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
			}
			yield return (object)new WaitForSeconds(1.5f);
			killPlayerParticle2.Play();
			if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position) < 10f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
			yield return (object)new WaitForSeconds(0.25f);
			FinishKillAnimation(completed: true);
		}
		else
		{
			FinishKillAnimation(completed: false);
		}
	}

	private void GrabBody(DeadBodyInfo body)
	{
		bodyBeingCarried = body;
		bodyBeingCarried.attachedTo = bodyRagdollPoint;
		bodyBeingCarried.attachedLimb = bodyBeingCarried.bodyParts[5];
		bodyBeingCarried.matchPositionExactly = false;
	}

	private void DropBody()
	{
		if ((Object)(object)bodyBeingCarried != (Object)null)
		{
			bodyBeingCarried.attachedTo = null;
			bodyBeingCarried.attachedLimb = null;
			bodyBeingCarried.matchPositionExactly = false;
			bodyBeingCarried = null;
		}
	}

	public void FinishKillAnimation(bool completed)
	{
		inKillAnimation = false;
		inSpecialAnimation = false;
		creatureAnimator.SetBool("killing", false);
		((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 1f;
		DropBody();
	}

	private void CalculateAnimationDirection(float maxSpeed = 1f)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		if (checkMovingInterval <= 0f)
		{
			checkMovingInterval = 0.1f;
			bool flag = Vector3.Distance(((Component)this).transform.position, previousPosition) > 0.06f;
			if (currentBehaviourStateIndex == 0)
			{
				babyCreatureAnimator.SetBool("moving", flag);
			}
			else
			{
				creatureAnimator.SetBool("moving", flag);
				if (flag && !leaping)
				{
					walkingAudio.volume = Mathf.Lerp(walkingAudio.volume, 1f, 5f * Time.deltaTime);
					if (!walkingAudio.isPlaying)
					{
						walkingAudio.Play();
					}
				}
				else
				{
					if (walkingAudio.isPlaying && walkingAudio.volume <= 0.05f)
					{
						walkingAudio.Pause();
					}
					walkingAudio.volume = Mathf.Lerp(walkingAudio.volume, 0f, 5f * Time.deltaTime);
				}
			}
			previousPosition = ((Component)this).transform.position;
		}
		else
		{
			checkMovingInterval -= Time.deltaTime;
		}
	}

	public override void Update()
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (inKillAnimation || isEnemyDead || StartOfRound.Instance.livingPlayers == 0)
		{
			return;
		}
		CalculateAnimationDirection(1.6f);
		SetClickingAudioVolume();
		if (!((NetworkBehaviour)this).IsOwner && ((!holdingBaby && dropBabyCoroutine == null) || currentBehaviourStateIndex != 0))
		{
			((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.localEulerAngles.y, 0f);
		}
		if (wasOutsideLastFrame && ((Component)this).transform.position.y < -80f)
		{
			wasOutsideLastFrame = false;
			SetEnemyOutside();
		}
		else if (!wasOutsideLastFrame && ((Component)this).transform.position.y > -80f)
		{
			wasOutsideLastFrame = true;
			SetEnemyOutside(outside: true);
		}
		if (currentBehaviourStateIndex == 0)
		{
			if (((NetworkBehaviour)this).IsServer && (holdingBaby || rolledOver))
			{
				if (babySearchRoutine.inProgress)
				{
					StopSearch(babySearchRoutine);
				}
				agent.speed = 0f;
			}
			BabyUpdate();
			return;
		}
		if (((NetworkBehaviour)this).IsServer)
		{
			if (changeOwnershipInterval <= 0f)
			{
				changeOwnershipInterval = 0.3f;
				PlayerControllerB playerControllerB = targetPlayer;
				targetPlayer = null;
				float num = 4f;
				mostOptimalDistance = 2000f;
				for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
				{
					if (PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[i]))
					{
						tempDist = Vector3.Distance(((Component)this).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position);
						if (tempDist < mostOptimalDistance)
						{
							mostOptimalDistance = tempDist;
							targetPlayer = StartOfRound.Instance.allPlayerScripts[i];
						}
					}
				}
				if ((Object)(object)targetPlayer != (Object)null && num > 0f && (Object)(object)playerControllerB != (Object)null && Mathf.Abs(mostOptimalDistance - Vector3.Distance(((Component)this).transform.position, ((Component)playerControllerB).transform.position)) < num)
				{
					targetPlayer = playerControllerB;
				}
				if ((Object)(object)targetPlayer != (Object)null && !inKillAnimation && targetPlayer.actualClientId != ((NetworkBehaviour)this).NetworkObject.OwnerClientId && (chasingAfterLeap || currentBehaviourStateIndex != 3))
				{
					ChangeOwnershipOfEnemy(targetPlayer.actualClientId);
					return;
				}
			}
			else
			{
				changeOwnershipInterval -= Time.deltaTime;
			}
		}
		DoNonBabyUpdateLogic();
	}

	public override void DoAIInterval()
	{
		base.DoAIInterval();
		if (inKillAnimation || isEnemyDead || inSpecialAnimation)
		{
			return;
		}
		if (StartOfRound.Instance.livingPlayers == 0)
		{
			base.DoAIInterval();
		}
		else if (currentBehaviourStateIndex == 0)
		{
			if (((NetworkBehaviour)this).IsServer)
			{
				DoBabyAIInterval();
			}
		}
		else
		{
			DoAIIntervalChaseLogic();
		}
	}

	private void TransformIntoAdult()
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			SwitchToBehaviourStateOnLocalClient(1);
			TurnIntoAdultServerRpc();
			StartTransformationAnim();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void TurnIntoAdultServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3603438927u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3603438927u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				TurnIntoAdultClientRpc();
			}
		}
	}

	[ClientRpc]
	public void TurnIntoAdultClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1779072459u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1779072459u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				SwitchToBehaviourStateOnLocalClient(1);
				StartTransformationAnim();
			}
		}
	}

	private void StartTransformationAnim()
	{
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		agent.acceleration = 425f;
		agent.angularSpeed = 700f;
		syncMovementSpeed = 0.15f;
		addPlayerVelocityToDestination = 1f;
		updatePositionThreshold = 0.8f;
		propScript.EnablePhysics(enable: false);
		propScript.grabbable = false;
		propScript.grabbableToEnemies = false;
		((Behaviour)propScript).enabled = false;
		if ((Object)(object)propScript.playerHeldBy != (Object)null && (Object)(object)propScript.playerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			propScript.playerHeldBy.DropAllHeldItemsAndSync();
		}
		if (dropBabyCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(dropBabyCoroutine);
		}
		if (babySearchRoutine.inProgress)
		{
			StopSearch(babySearchRoutine);
		}
		Vector3 position = ((Component)this).transform.position;
		inSpecialAnimation = true;
		((Behaviour)agent).enabled = false;
		Vector3 val = (serverPosition = RoundManager.Instance.GetNavMeshPosition(position, default(NavMeshHit), 10f));
		((Component)this).transform.position = val;
		((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.localEulerAngles.y, 0f);
		position = val;
		Debug.DrawRay(val, Vector3.up * 2f, Color.magenta, 7f);
		((MonoBehaviour)this).StartCoroutine(becomeAdultAnimation(position));
	}

	private IEnumerator becomeAdultAnimation(Vector3 setToPos)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		creatureSFX.volume = 1f;
		creatureSFX.PlayOneShot(transformationSFX);
		WalkieTalkie.TransmitOneShotAudio(creatureSFX, transformationSFX);
		babyCreatureAnimator.SetBool("Transform", true);
		yield return (object)new WaitForSeconds(0.5f);
		babyContainer.SetActive(false);
		adultContainer.SetActive(true);
		yield return (object)new WaitForSeconds(1.7f);
		inSpecialAnimation = false;
		if (isOutside)
		{
			leapSpeed += 8f;
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			((Component)this).transform.position = setToPos;
			((Behaviour)agent).enabled = true;
		}
		Debug.DrawRay(setToPos, Vector3.up * 2f, Color.magenta, 7f);
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetFakingBabyVoiceServerRpc(bool fakingBabyVoice)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(899164507u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref fakingBabyVoice, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 899164507u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetFakingBabyVoiceClientRpc(fakingBabyVoice);
			}
		}
	}

	[ClientRpc]
	public void SetFakingBabyVoiceClientRpc(bool faking)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1247942403u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref faking, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1247942403u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				isFakingBabyVoice = faking;
			}
		}
	}

	private void DoNonBabyUpdateLogic()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0537: Unknown result type (might be due to invalid IL or missing references)
		//IL_0542: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0338: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		//IL_069b: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_041a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0756: Unknown result type (might be due to invalid IL or missing references)
		//IL_0761: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f5: Unknown result type (might be due to invalid IL or missing references)
		if (!isEnemyDead && GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.5f, 100f, 30, 3f))
		{
			GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.7f);
		}
		if (((NetworkBehaviour)this).IsOwner && Time.realtimeSinceStartup - checkIfTrappedInterval > 15f)
		{
			checkIfTrappedInterval = Time.realtimeSinceStartup;
			if ((Object)(object)ChooseClosestNodeToPosition(((Component)this).transform.position) == (Object)(object)nodesTempArray[0].transform && PathIsIntersectedByLineOfSight(nodesTempArray[0].transform.position, calculatePathDistance: false, avoidLineOfSight: false))
			{
				bool flag = false;
				for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
				{
					if (StartOfRound.Instance.allPlayerScripts[i].HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 1.3f, 100f, 70, 12f))
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					((Behaviour)agent).enabled = false;
					((Component)this).transform.position = RoundManager.Instance.GetNavMeshPosition(ChooseClosestNodeToPositionNoPathCheck(((Component)this).transform.position).position);
					return;
				}
			}
		}
		switch (currentBehaviourStateIndex)
		{
		case 1:
			if (currentBehaviourStateIndex != previousBehaviourState)
			{
				screamTimer = screamTime;
				creatureAnimator.SetBool("Screaming", false);
				creatureAnimator.SetBool("Leaping", false);
				creatureAnimator.SetBool("FinishedLeaping", false);
				useSecondaryAudiosOnAnimatedObjects = false;
				openDoorSpeedMultiplier = 1f;
				beganCooldown = true;
				screaming = false;
				leaping = false;
				chasingAfterLeap = false;
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 0f;
				previousBehaviourState = currentBehaviourStateIndex;
			}
			agent.speed = 6f;
			break;
		case 2:
		{
			if (currentBehaviourStateIndex != previousBehaviourState)
			{
				screamTimer = screamTime;
				ignoredNodes.Clear();
				creatureAnimator.SetBool("Screaming", false);
				creatureAnimator.SetBool("Leaping", false);
				creatureAnimator.SetBool("FinishedLeaping", false);
				useSecondaryAudiosOnAnimatedObjects = false;
				openDoorSpeedMultiplier = 1f;
				beganCooldown = true;
				screaming = false;
				leaping = false;
				chasingAfterLeap = false;
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 0f;
				previousBehaviourState = currentBehaviourStateIndex;
			}
			if (!((NetworkBehaviour)this).IsOwner || (Object)(object)targetNode == (Object)null)
			{
				break;
			}
			bool flag2 = IsBodyVisibleToTarget();
			if (!flag2 && (Object)(object)targetNode != (Object)null)
			{
				if (wasBodyVisible)
				{
					wasBodyVisible = false;
					positionAtLeavingLOS = ((Component)this).transform.position;
				}
				if (Vector3.Distance(((Component)this).transform.position, ((Component)targetNode).transform.position) < 1f)
				{
					agent.speed = 0f;
				}
				else
				{
					agent.speed = sneakSpeed;
				}
			}
			else if (flag2)
			{
				if (!wasBodyVisible)
				{
					wasBodyVisible = true;
				}
				agent.speed = sneakSpeed + 4f;
			}
			else
			{
				agent.speed = sneakSpeed;
			}
			if (!wasBodyVisible && Vector3.Distance(((Component)this).transform.position, positionAtLeavingLOS) > 7f)
			{
				Debug.DrawRay(positionAtLeavingLOS, Vector3.up, Color.yellow, 0.7f);
				ignoredNodes.Clear();
			}
			if (Vector3.Distance(((Component)this).transform.position, ((Component)targetNode).transform.position) < 0.5f && flag2 && !ignoredNodes.Contains(targetNode))
			{
				if (ignoredNodes.Count < 16)
				{
					ignoredNodes.Add(targetNode);
					break;
				}
				ignoredNodes.RemoveAt(0);
				ignoredNodes.Add(targetNode);
			}
			break;
		}
		case 3:
			if (currentBehaviourStateIndex != previousBehaviourState)
			{
				if (TargetClosestPlayer())
				{
					SetMovingTowardsTargetPlayer(targetPlayer);
				}
				useSecondaryAudiosOnAnimatedObjects = true;
				openDoorSpeedMultiplier = 1.5f;
				currentSearchWidth = Mathf.Max(currentSearchWidth - 35f, baseSearchWidth);
				startedLeapingThisFrame = false;
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 0f;
				previousBehaviourState = currentBehaviourStateIndex;
			}
			if (leaping && leapTimer > 0.1f)
			{
				if (shakeCameraInterval <= 0f && Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position) < 12f)
				{
					shakeCameraInterval = 0.05f;
					HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
				}
				else
				{
					shakeCameraInterval -= Time.deltaTime;
				}
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				screaming = false;
				startedLeapingThisFrame = false;
				leapTimer = Mathf.Max(leapTimer - Time.deltaTime, 0f);
				if (leapTimer <= 0f && !beganCooldown)
				{
					beganCooldown = true;
					creatureVoice.PlayOneShot(cooldownSFX);
					creatureAnimator.SetBool("FinishedLeaping", true);
				}
				if (stunNormalizedTimer > 0f)
				{
					leapTimer = 0f;
				}
				if (leaping && leapTimer <= 0f)
				{
					leaping = false;
					creatureAnimator.SetBool("Leaping", false);
					creatureAnimator.SetBool("Screaming", false);
				}
				screamTimer -= Time.deltaTime;
			}
			else
			{
				if ((Object)(object)targetPlayer == (Object)null)
				{
					break;
				}
				float num = 15f;
				if (isOutside)
				{
					num = 35f;
				}
				if (chasingAfterLeap)
				{
					if (Physics.Linecast(((Component)targetPlayer.gameplayCamera).transform.position, ((Component)this).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) && (Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position) > num || (!isOutside && Vector3.Distance(caveHidingSpot, ((Component)this).transform.position) > currentSearch.searchWidth + 30f)))
					{
						SwitchToBehaviourState(2);
						break;
					}
					agent.speed = chaseSpeed;
					float num2 = attackDistance - 3f;
					if (isOutside)
					{
						num2 += 18f;
					}
					if (Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position) < num2)
					{
						chasingAfterLeap = false;
					}
					break;
				}
				if (!screaming)
				{
					((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 0f;
					beganCooldown = false;
					creatureAnimator.SetBool("Screaming", true);
					creatureAnimator.SetBool("FinishedLeaping", false);
					screaming = true;
					agent.speed = 0f;
					isFakingBabyVoice = false;
					creatureVoice.PlayOneShot(growlSFX);
					WalkieTalkie.TransmitOneShotAudio(creatureVoice, growlSFX);
					DoScreamServerRpc();
				}
				if (leaping)
				{
					leapTimer -= Time.deltaTime;
					if (!startedLeapingThisFrame)
					{
						startedLeapingThisFrame = true;
						creatureAnimator.SetBool("Leaping", true);
						float pitch = Random.Range(0.95f, 1.05f);
						screamAudio.pitch = pitch;
						screamAudio.Play();
						screamAudioNonDiagetic.pitch = pitch;
						screamAudioNonDiagetic.Play();
						leapTimer = leapTime;
						DoLeapServerRpc();
					}
					if (stunNormalizedTimer > 0f)
					{
						leapTimer = 0f;
					}
					else
					{
						agent.speed = leapSpeed;
					}
					if (leapTimer <= 0f)
					{
						agent.speed = 0f;
						screamTimer += Time.deltaTime;
						if (screamTimer > cooldownTime)
						{
							chasingAfterLeap = true;
							((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 1f;
							leaping = false;
							screaming = false;
							screamTimer = screamTime;
							creatureAnimator.SetBool("Leaping", false);
							creatureAnimator.SetBool("Screaming", false);
							creatureAnimator.SetBool("FinishedLeaping", false);
							startedLeapingThisFrame = false;
							FinishLeapServerRpc();
						}
						else if (!beganCooldown)
						{
							beganCooldown = true;
							creatureVoice.PlayOneShot(cooldownSFX);
							creatureAnimator.SetBool("FinishedLeaping", true);
						}
					}
					else
					{
						agent.speed = leapSpeed;
					}
				}
				else
				{
					screamTimer -= Time.deltaTime;
					if (screamTimer <= 0f)
					{
						leaping = true;
						break;
					}
					agent.speed = 0f;
					LookAtTargetPlayer();
				}
			}
			break;
		}
	}

	private void LookAtTargetPlayer()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)targetPlayer == (Object)null))
		{
			Vector3 position = ((Component)targetPlayer).transform.position;
			position.y = ((Component)this).transform.position.y;
			RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
			RoundManager.Instance.tempTransform.LookAt(position);
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, RoundManager.Instance.tempTransform.rotation, 14f * Time.deltaTime);
		}
	}

	private void DoAIIntervalChaseLogic()
	{
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		if (inSpecialAnimation || inKillAnimation)
		{
			return;
		}
		bool flag = TargetClosestPlayer(4f);
		if (currentBehaviourStateIndex == 3)
		{
			if (searchRoutine.inProgress)
			{
				StopSearch(searchRoutine);
			}
			if (TargetClosestPlayer())
			{
				noPlayersTimer = 0f;
				SetMovingTowardsTargetPlayer(targetPlayer);
			}
			else if (noPlayersTimer > 2.5f)
			{
				SwitchToBehaviourState(1);
			}
			else
			{
				noPlayersTimer += AIIntervalTime;
			}
			return;
		}
		fakeCryTimer -= AIIntervalTime;
		if (isFakingBabyVoice)
		{
			if (fakeCryTimer <= 0f)
			{
				fakeCryTimer = Mathf.Max(Random.Range(-2f, 7f), 4.2f);
				clickingMandibles = false;
				int num = Random.Range(0, fakeCrySFX.Length);
				DoFakeCryLocalClient(num);
				MakeFakeCryServerRpc(num);
			}
		}
		else if (fakeCryTimer <= 0f)
		{
			if (Random.Range(0, 100) < 65)
			{
				fakeCryTimer = 9f;
				clickingMandibles = true;
				SetClickingMandiblesServerRpc();
			}
			else
			{
				isFakingBabyVoice = true;
				SetFakingBabyVoiceServerRpc(fakingBabyVoice: true);
			}
		}
		if (!flag)
		{
			if (noPlayersTimer > 2.5f)
			{
				RoamAroundCaveSpot(gotTarget: false);
			}
			else
			{
				noPlayersTimer += AIIntervalTime;
			}
			return;
		}
		noPlayersTimer = 0f;
		float num2 = ((!isOutside) ? Vector3.Distance(((Component)targetPlayer).transform.position, caveHidingSpot) : Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position));
		float num3 = attackDistance;
		if (isOutside)
		{
			num3 += 16f;
		}
		float num4 = Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position);
		if ((num4 < num3 && !Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.25f, ((Component)targetPlayer).transform.position + Vector3.up * 0.25f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)) || num4 < 4.5f)
		{
			SwitchToBehaviourState(3);
		}
		else if (pursuingPlayerInSneakMode)
		{
			if (num2 > searchRoutine.searchWidth + 30f)
			{
				pursuingPlayerInSneakMode = false;
			}
			if (searchRoutine.inProgress)
			{
				StopSearch(searchRoutine);
			}
			if (currentBehaviourStateIndex == 1)
			{
				SwitchToBehaviourState(2);
			}
			if (isFakingBabyVoice && targetPlayer.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.75f, 90f, 20, 2f))
			{
				isFakingBabyVoice = false;
				fakeCryTimer = 18f;
				SetFakingBabyVoiceServerRpc(fakingBabyVoice: false);
				if (Random.Range(0, 100) < 30)
				{
					clickingMandibles = true;
					SetClickingMandiblesServerRpc();
				}
			}
			ChooseClosestNodeToPlayer();
		}
		else
		{
			if (num2 < searchRoutine.searchWidth + 15f)
			{
				pursuingPlayerInSneakMode = true;
			}
			RoamAroundCaveSpot(gotTarget: true);
		}
	}

	private void DoFakeCryLocalClient(int fakeCryIndex)
	{
		clickingMandibles = false;
		creatureVoice.PlayOneShot(fakeCrySFX[fakeCryIndex], 1f);
		WalkieTalkie.TransmitOneShotAudio(creatureVoice, fakeCrySFX[fakeCryIndex]);
	}

	[ServerRpc(RequireOwnership = false)]
	public void MakeFakeCryServerRpc(int clipIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3054383276u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clipIndex);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3054383276u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				MakeFakeCryClientRpc(clipIndex);
			}
		}
	}

	[ClientRpc]
	public void MakeFakeCryClientRpc(int clipIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2345289708u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clipIndex);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2345289708u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				DoFakeCryLocalClient(clipIndex);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetClickingMandiblesServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1458788125u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1458788125u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetClickingMandiblesClientRpc();
			}
		}
	}

	[ClientRpc]
	public void SetClickingMandiblesClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4059480218u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4059480218u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				clickingMandibles = true;
				fakeCryTimer = 9f;
			}
		}
	}

	private void RoamAroundCaveSpot(bool gotTarget, float distToTarget = -1f)
	{
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		if (currentBehaviourStateIndex == 2)
		{
			SwitchToBehaviourState(1);
		}
		if (!gotTarget)
		{
			if (isOutside)
			{
				if (!searchRoutine.inProgress)
				{
					Transform val = ChooseClosestNodeToPosition(((Component)this).transform.position, avoidLineOfSight: false, Random.Range(0, allAINodes.Length / 2));
					searchRoutine.searchPrecision = 16f;
					if ((Object)(object)val != (Object)null)
					{
						StartSearch(val.position, searchRoutine);
					}
					currentSearchWidth = 200f;
				}
			}
			else
			{
				if (searchRoutine.inProgress)
				{
					StopSearch(searchRoutine);
				}
				SetDestinationToPosition(caveHidingSpot);
				currentSearchWidth = Mathf.Max(currentSearchWidth - AIIntervalTime * 1.5f, baseSearchWidth);
			}
			return;
		}
		if (isOutside)
		{
			currentSearchWidth = 100f;
		}
		else if (currentSearchWidth - Vector3.Distance(caveHidingSpot, ((Component)targetPlayer).transform.position) < 16f)
		{
			currentSearchWidth = Mathf.Min(currentSearchWidth + AIIntervalTime * 1.7f, baseSearchWidth + 80f);
		}
		searchRoutine.searchWidth = currentSearchWidth;
		if (searchRoutine.inProgress)
		{
			return;
		}
		if (isOutside)
		{
			Transform val2 = ChooseClosestNodeToPosition(((Component)this).transform.position, avoidLineOfSight: false, Random.Range(0, allAINodes.Length / 2));
			if ((Object)(object)val2 != (Object)null)
			{
				StartSearch(val2.position, searchRoutine);
			}
		}
		else
		{
			StartSearch(caveHidingSpot, searchRoutine);
		}
	}

	public void ChooseClosestNodeToPlayer()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)targetNode == (Object)null)
		{
			targetNode = allAINodes[0].transform;
		}
		Transform val = ChooseClosestNodeToPositionNoLOS(((Component)targetPlayer).transform.position + Vector3.up, avoidLineOfSight: true);
		if ((Object)(object)val != (Object)null)
		{
			targetNode = val;
		}
		SetDestinationToPosition(targetNode.position);
	}

	public Transform ChooseClosestNodeToPositionNoLOS(Vector3 pos, bool avoidLineOfSight = false, int offset = 0)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		nodesTempArray = allAINodes.OrderBy((GameObject x) => Vector3.Distance(pos, x.transform.position)).ToArray();
		Transform transform = nodesTempArray[0].transform;
		float num = Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position);
		bool flag = false;
		for (int i = 0; i < nodesTempArray.Length; i++)
		{
			if (ignoredNodes.Contains(nodesTempArray[i].transform) || Vector3.Distance(caveHidingSpot, nodesTempArray[i].transform.position) > searchRoutine.searchWidth || Vector3.Distance(((Component)this).transform.position, nodesTempArray[i].transform.position) > 40f || !Physics.Linecast(nodesTempArray[i].transform.position + Vector3.up, pos, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				continue;
			}
			bool flag2 = !wasBodyVisible;
			if (PathIsIntersectedByLineOfSight(nodesTempArray[i].transform.position, calculatePathDistance: true, flag2, flag2) || (pathDistance > num + 16f && !wasBodyVisible))
			{
				continue;
			}
			if (wasBodyVisible)
			{
				bool flag3 = false;
				for (int j = 1; j < path1.corners.Length; j++)
				{
					if (Vector3.Distance(Vector3.Lerp(path1.corners[j - 1], path1.corners[j], 0.5f), ((Component)targetPlayer).transform.position) < 8f || Vector3.Distance(path1.corners[j], ((Component)targetPlayer).transform.position) < 8f || num - Vector3.Distance(path1.corners[j], ((Component)targetPlayer).transform.position) > 4f)
					{
						flag3 = true;
						break;
					}
				}
				if (flag3)
				{
					continue;
				}
			}
			mostOptimalDistance = Vector3.Distance(pos, nodesTempArray[i].transform.position);
			transform = nodesTempArray[i].transform;
			if (offset == 0 || i >= nodesTempArray.Length - 1)
			{
				flag = true;
				break;
			}
			offset--;
		}
		if (!flag)
		{
			ignoredNodes.Clear();
			return nodesTempArray[Mathf.Min(Random.Range(6, 15), nodesTempArray.Length)].transform;
		}
		return transform;
	}

	[ServerRpc(RequireOwnership = false)]
	public void FinishLeapServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4220522402u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4220522402u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				FinishLeapClientRpc();
			}
		}
	}

	[ClientRpc]
	public void FinishLeapClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3655632335u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3655632335u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				syncMovementSpeed = 0.2f;
				chasingAfterLeap = true;
				screaming = false;
				leaping = false;
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 1f;
				creatureAnimator.SetBool("Screaming", false);
				creatureAnimator.SetBool("Leaping", false);
				creatureAnimator.SetBool("FinishedLeaping", false);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void DoLeapServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1893129902u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1893129902u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DoLeapClientRpc();
			}
		}
	}

	[ClientRpc]
	public void DoLeapClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2641086547u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2641086547u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
		{
			leaping = true;
			leapTimer = leapTime;
			syncMovementSpeed = 0.09f;
			if (Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) < 10f)
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(1f);
			}
			beganCooldown = false;
			creatureAnimator.SetBool("Leaping", true);
			creatureAnimator.SetBool("FinishedLeaping", false);
			float pitch = Random.Range(0.95f, 1.05f);
			screamAudio.pitch = pitch;
			creatureVoice.Stop();
			screamAudio.Play();
			screamAudioNonDiagetic.pitch = pitch;
			screamAudioNonDiagetic.Play();
			WalkieTalkie.TransmitOneShotAudio(screamAudio, screamAudio.clip);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void DoScreamServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(188700017u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 188700017u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DoScreamClientRpc();
			}
		}
	}

	[ClientRpc]
	public void DoScreamClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4070120220u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4070120220u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				syncMovementSpeed = 0.09f;
				beganCooldown = false;
				chasingAfterLeap = false;
				isFakingBabyVoice = false;
				fakeCryTimer = 18f;
				((RigConstraint<DampedTransformJob, DampedTransformData, DampedTransformJobBinder<DampedTransformData>>)(object)headRig).weight = 0f;
				creatureVoice.Stop();
				creatureVoice.PlayOneShot(growlSFX);
				WalkieTalkie.TransmitOneShotAudio(creatureVoice, growlSFX);
				creatureAnimator.SetBool("Screaming", true);
				creatureAnimator.SetBool("FinishedLeaping", false);
				screaming = true;
			}
		}
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
	}

	private void LateUpdate()
	{
	}

	private void SetClickingAudioVolume()
	{
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)StartOfRound.Instance.audioListener == (Object)null)
		{
			return;
		}
		bool flag = true;
		float diageticMasterVolume = 0f;
		if (currentBehaviourStateIndex == 0 || isFakingBabyVoice || (screaming && !leaping))
		{
			clickingAudio1.volume = Mathf.Lerp(clickingAudio1.volume, 0f, Time.deltaTime * 5f);
			clickingAudio2.volume = Mathf.Lerp(clickingAudio2.volume, 0f, Time.deltaTime * 5f);
			diageticMasterVolume = 0f;
			flag = false;
		}
		else if (currentBehaviourStateIndex != 3 && clickingMandibles)
		{
			clickingAudio1.volume = Mathf.Lerp(clickingAudio1.volume, 1f, Time.deltaTime * 5f);
			clickingAudio2.volume = Mathf.Lerp(clickingAudio1.volume, 0f, Time.deltaTime * 5f);
			diageticMasterVolume = 0f;
			flag = false;
		}
		else if (chasingAfterLeap)
		{
			clickingAudio1.volume = Mathf.Lerp(clickingAudio1.volume, 1f, Time.deltaTime * 1.5f);
			clickingAudio2.volume = Mathf.Lerp(clickingAudio2.volume, 1f, Time.deltaTime * 1.5f);
		}
		else
		{
			clickingAudio1.volume = Mathf.Lerp(clickingAudio1.volume, 0f, Time.deltaTime * 1.5f);
			clickingAudio2.volume = Mathf.Lerp(clickingAudio2.volume, 0f, Time.deltaTime * 1.5f);
		}
		if (clickingAudio1.volume < 0.02f)
		{
			clickingAudio1.Stop();
		}
		else if (!clickingAudio1.isPlaying)
		{
			clickingAudio1.Play();
		}
		if (clickingAudio2.volume < 0.02f)
		{
			clickingAudio2.Stop();
		}
		else if (!clickingAudio2.isPlaying)
		{
			clickingAudio2.Play();
		}
		if (flag)
		{
			if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
			{
				CaveDwellerDeafenAmount = 0f;
			}
			else
			{
				float num = Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position);
				if (!leaping || leapTimer <= 0f)
				{
					maxDeafenAmount = -9f;
				}
				else if (leapTimer > 0.5f)
				{
					maxDeafenAmount = -20f;
				}
				else
				{
					maxDeafenAmount = -13f;
				}
				diageticMasterVolume = Mathf.Clamp((num - deafeningMinDistance) / (deafeningMaxDistance - deafeningMinDistance), 0f, 1f);
				diageticMasterVolume = Mathf.Abs(diageticMasterVolume - 1f) * maxDeafenAmount;
				diageticMasterVolume = Mathf.Clamp(diageticMasterVolume, maxDeafenAmount, 0f);
			}
		}
		SoundManager.Instance.SetDiageticMasterVolume(diageticMasterVolume);
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_CaveDwellerAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Expected O, but got Unknown
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Expected O, but got Unknown
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Expected O, but got Unknown
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Expected O, but got Unknown
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Expected O, but got Unknown
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Expected O, but got Unknown
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Expected O, but got Unknown
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Expected O, but got Unknown
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Expected O, but got Unknown
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Expected O, but got Unknown
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Expected O, but got Unknown
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Expected O, but got Unknown
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Expected O, but got Unknown
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Expected O, but got Unknown
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Expected O, but got Unknown
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Expected O, but got Unknown
		//IL_0413: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Expected O, but got Unknown
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Expected O, but got Unknown
		//IL_0449: Unknown result type (might be due to invalid IL or missing references)
		//IL_0453: Expected O, but got Unknown
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Expected O, but got Unknown
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(412902375u, new RpcReceiveHandler(__rpc_handler_412902375));
		NetworkManager.__rpc_func_table.Add(3265969319u, new RpcReceiveHandler(__rpc_handler_3265969319));
		NetworkManager.__rpc_func_table.Add(354890398u, new RpcReceiveHandler(__rpc_handler_354890398));
		NetworkManager.__rpc_func_table.Add(2092554489u, new RpcReceiveHandler(__rpc_handler_2092554489));
		NetworkManager.__rpc_func_table.Add(1374882881u, new RpcReceiveHandler(__rpc_handler_1374882881));
		NetworkManager.__rpc_func_table.Add(4230781752u, new RpcReceiveHandler(__rpc_handler_4230781752));
		NetworkManager.__rpc_func_table.Add(1144090475u, new RpcReceiveHandler(__rpc_handler_1144090475));
		NetworkManager.__rpc_func_table.Add(2098313814u, new RpcReceiveHandler(__rpc_handler_2098313814));
		NetworkManager.__rpc_func_table.Add(4101944549u, new RpcReceiveHandler(__rpc_handler_4101944549));
		NetworkManager.__rpc_func_table.Add(1836135136u, new RpcReceiveHandler(__rpc_handler_1836135136));
		NetworkManager.__rpc_func_table.Add(2038363846u, new RpcReceiveHandler(__rpc_handler_2038363846));
		NetworkManager.__rpc_func_table.Add(1443484045u, new RpcReceiveHandler(__rpc_handler_1443484045));
		NetworkManager.__rpc_func_table.Add(547761068u, new RpcReceiveHandler(__rpc_handler_547761068));
		NetworkManager.__rpc_func_table.Add(2728788472u, new RpcReceiveHandler(__rpc_handler_2728788472));
		NetworkManager.__rpc_func_table.Add(2669712327u, new RpcReceiveHandler(__rpc_handler_2669712327));
		NetworkManager.__rpc_func_table.Add(3854344690u, new RpcReceiveHandler(__rpc_handler_3854344690));
		NetworkManager.__rpc_func_table.Add(3479454888u, new RpcReceiveHandler(__rpc_handler_3479454888));
		NetworkManager.__rpc_func_table.Add(3633542544u, new RpcReceiveHandler(__rpc_handler_3633542544));
		NetworkManager.__rpc_func_table.Add(1944396819u, new RpcReceiveHandler(__rpc_handler_1944396819));
		NetworkManager.__rpc_func_table.Add(4108007701u, new RpcReceiveHandler(__rpc_handler_4108007701));
		NetworkManager.__rpc_func_table.Add(843410401u, new RpcReceiveHandler(__rpc_handler_843410401));
		NetworkManager.__rpc_func_table.Add(4106177627u, new RpcReceiveHandler(__rpc_handler_4106177627));
		NetworkManager.__rpc_func_table.Add(3360410662u, new RpcReceiveHandler(__rpc_handler_3360410662));
		NetworkManager.__rpc_func_table.Add(353948947u, new RpcReceiveHandler(__rpc_handler_353948947));
		NetworkManager.__rpc_func_table.Add(564389360u, new RpcReceiveHandler(__rpc_handler_564389360));
		NetworkManager.__rpc_func_table.Add(3993334803u, new RpcReceiveHandler(__rpc_handler_3993334803));
		NetworkManager.__rpc_func_table.Add(3591556954u, new RpcReceiveHandler(__rpc_handler_3591556954));
		NetworkManager.__rpc_func_table.Add(40847295u, new RpcReceiveHandler(__rpc_handler_40847295));
		NetworkManager.__rpc_func_table.Add(1117359351u, new RpcReceiveHandler(__rpc_handler_1117359351));
		NetworkManager.__rpc_func_table.Add(3603438927u, new RpcReceiveHandler(__rpc_handler_3603438927));
		NetworkManager.__rpc_func_table.Add(1779072459u, new RpcReceiveHandler(__rpc_handler_1779072459));
		NetworkManager.__rpc_func_table.Add(899164507u, new RpcReceiveHandler(__rpc_handler_899164507));
		NetworkManager.__rpc_func_table.Add(1247942403u, new RpcReceiveHandler(__rpc_handler_1247942403));
		NetworkManager.__rpc_func_table.Add(3054383276u, new RpcReceiveHandler(__rpc_handler_3054383276));
		NetworkManager.__rpc_func_table.Add(2345289708u, new RpcReceiveHandler(__rpc_handler_2345289708));
		NetworkManager.__rpc_func_table.Add(1458788125u, new RpcReceiveHandler(__rpc_handler_1458788125));
		NetworkManager.__rpc_func_table.Add(4059480218u, new RpcReceiveHandler(__rpc_handler_4059480218));
		NetworkManager.__rpc_func_table.Add(4220522402u, new RpcReceiveHandler(__rpc_handler_4220522402));
		NetworkManager.__rpc_func_table.Add(3655632335u, new RpcReceiveHandler(__rpc_handler_3655632335));
		NetworkManager.__rpc_func_table.Add(1893129902u, new RpcReceiveHandler(__rpc_handler_1893129902));
		NetworkManager.__rpc_func_table.Add(2641086547u, new RpcReceiveHandler(__rpc_handler_2641086547));
		NetworkManager.__rpc_func_table.Add(188700017u, new RpcReceiveHandler(__rpc_handler_188700017));
		NetworkManager.__rpc_func_table.Add(4070120220u, new RpcReceiveHandler(__rpc_handler_4070120220));
	}

	private static void __rpc_handler_412902375(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabyNearTransformingServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3265969319(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabyNearTransformingClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_354890398(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timeToLook = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToLook, default(ForPrimitives));
			Vector3 attentionPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref attentionPosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).PingAttentionServerRpc(timeToLook, attentionPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2092554489(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timeToLook = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToLook, default(ForPrimitives));
			Vector3 attentionPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref attentionPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).PingAttentionClientRpc(timeToLook, attentionPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1374882881(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).ScareBabyServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4230781752(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).ScareBabyClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1144090475(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool babySittingServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref babySittingServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabySittingServerRpc(babySittingServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2098313814(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool babySittingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref babySittingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabySittingClientRpc(babySittingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4101944549(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			bool scared = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref scared, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabyRolledOverServerRpc(flag, scared);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1836135136(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool setRolled = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setRolled, default(ForPrimitives));
			bool scared = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref scared, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabyRolledOverClientRpc(setRolled, scared);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2038363846(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool babyCryingServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref babyCryingServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabyCryingServerRpc(babyCryingServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1443484045(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool babyCryingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref babyCryingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabyCryingClientRpc(babyCryingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_547761068(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabyBServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2728788472(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabyBClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2669712327(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool babyRunningServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref babyRunningServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabyRunningServerRpc(babyRunningServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3854344690(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool babyRunningClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref babyRunningClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabyRunningClientRpc(babyRunningClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3479454888(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool babySquirmingServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref babySquirmingServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabySquirmingServerRpc(babySquirmingServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3633542544(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool babySquirmingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref babySquirmingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabySquirmingClientRpc(babySquirmingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1944396819(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool eatScrap = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref eatScrap, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).ClearBabyObservingServerRpc(eatScrap);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4108007701(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool eatScrap = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref eatScrap, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).ClearBabyObservingClientRpc(eatScrap);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_843410401(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int setFocusLevel = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setFocusLevel);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabyObservingPlayerServerRpc(playerId, setFocusLevel);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4106177627(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int setFocusLevel = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setFocusLevel);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabyObservingPlayerClientRpc(playerId, setFocusLevel);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3360410662(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference babyObservingObjectServerRpc = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref babyObservingObjectServerRpc, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetBabyObservingObjectServerRpc(babyObservingObjectServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_353948947(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference babyObservingObjectClientRpc = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref babyObservingObjectClientRpc, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetBabyObservingObjectClientRpc(babyObservingObjectClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_564389360(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 setHidingSpot = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref setHidingSpot);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SyncCaveHidingSpotServerRpc(setHidingSpot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3993334803(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 setHidingSpot = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref setHidingSpot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SyncCaveHidingSpotClientRpc(setHidingSpot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3591556954(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).KillPlayerAnimationServerRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_40847295(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).CancelKillAnimationClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1117359351(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).KillPlayerAnimationClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3603438927(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).TurnIntoAdultServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1779072459(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).TurnIntoAdultClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_899164507(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool fakingBabyVoiceServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref fakingBabyVoiceServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetFakingBabyVoiceServerRpc(fakingBabyVoiceServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1247942403(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool fakingBabyVoiceClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref fakingBabyVoiceClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetFakingBabyVoiceClientRpc(fakingBabyVoiceClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3054383276(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).MakeFakeCryServerRpc(clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2345289708(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).MakeFakeCryClientRpc(clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1458788125(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).SetClickingMandiblesServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4059480218(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).SetClickingMandiblesClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4220522402(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).FinishLeapServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3655632335(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).FinishLeapClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1893129902(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).DoLeapServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2641086547(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).DoLeapClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_188700017(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CaveDwellerAI)(object)target).DoScreamServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4070120220(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CaveDwellerAI)(object)target).DoScreamClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "CaveDwellerAI";
	}
}
