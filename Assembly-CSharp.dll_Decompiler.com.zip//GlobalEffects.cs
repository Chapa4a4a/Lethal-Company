using Unity.Netcode;
using UnityEngine;

public class GlobalEffects : NetworkBehaviour
{
	private StartOfRound playersManager;

	public bool ownedByPlayer;

	public static GlobalEffects Instance { get; private set; }

	private void Awake()
	{
		if (!ownedByPlayer)
		{
			if (!((Object)(object)Instance == (Object)null))
			{
				Object.Destroy((Object)(object)((Component)this).gameObject);
				return;
			}
			Instance = this;
		}
		playersManager = Object.FindObjectOfType<StartOfRound>();
	}

	public void PlayAnimAndAudioServer(ServerAnimAndAudio serverAnimAndAudio)
	{
		playersManager.allPlayerObjects[playersManager.thisClientPlayerId].GetComponentInChildren<GlobalEffects>().PlayAnimAndAudioServerFromSenderObject(serverAnimAndAudio);
	}

	public void PlayAnimAndAudioServerFromSenderObject(ServerAnimAndAudio serverAnimAndAudio)
	{
		PlayAnimAndAudioServerRpc(serverAnimAndAudio);
	}

	[ServerRpc(RequireOwnership = false)]
	private void PlayAnimAndAudioServerRpc(ServerAnimAndAudio serverAnimAndAudio)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2259057361u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<ServerAnimAndAudio>(ref serverAnimAndAudio, default(ForNetworkSerializable));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2259057361u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PlayAnimAndAudioClientRpc(serverAnimAndAudio);
			}
		}
	}

	[ClientRpc]
	private void PlayAnimAndAudioClientRpc(ServerAnimAndAudio serverAnimAndAudio)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2993461149u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<ServerAnimAndAudio>(ref serverAnimAndAudio, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2993461149u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			NetworkObject val3 = default(NetworkObject);
			if (((NetworkObjectReference)(ref serverAnimAndAudio.animatorObj)).TryGet(ref val3, (NetworkManager)null))
			{
				((Component)val3).GetComponent<Animator>().SetTrigger(serverAnimAndAudio.animationString);
			}
			NetworkObject val4 = default(NetworkObject);
			if (((NetworkObjectReference)(ref serverAnimAndAudio.audioObj)).TryGet(ref val4, (NetworkManager)null))
			{
				((Component)val4).GetComponent<AudioSource>().PlayOneShot(((Component)val4).GetComponent<AudioSource>().clip);
			}
		}
	}

	public void PlayAnimationServer(ServerAnimation serverAnimation)
	{
		playersManager.allPlayerObjects[playersManager.thisClientPlayerId].GetComponentInChildren<GlobalEffects>().PlayAnimationServerFromSenderObject(serverAnimation);
	}

	public void PlayAnimationServerFromSenderObject(ServerAnimation serverAnimation)
	{
		PlayAnimationServerRpc(serverAnimation);
	}

	[ServerRpc(RequireOwnership = false)]
	private void PlayAnimationServerRpc(ServerAnimation serverAnimation)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2698736096u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<ServerAnimation>(ref serverAnimation, default(ForNetworkSerializable));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2698736096u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PlayAnimationClientRpc(serverAnimation);
			}
		}
	}

	[ClientRpc]
	private void PlayAnimationClientRpc(ServerAnimation serverAnimation)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(780678780u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<ServerAnimation>(ref serverAnimation, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 780678780u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref serverAnimation.animatorObj)).TryGet(ref val3, (NetworkManager)null))
		{
			if (serverAnimation.isTrigger)
			{
				((Component)val3).GetComponent<Animator>().SetTrigger(serverAnimation.animationString);
			}
			else
			{
				((Component)val3).GetComponent<Animator>().SetBool(serverAnimation.animationString, serverAnimation.setTrue);
			}
		}
		else
		{
			Debug.LogWarning((object)("Was not able to retrieve NetworkObject from NetworkObjectReference; string " + serverAnimation.animationString));
		}
	}

	public void PlayAudioServer(ServerAudio serverAudio)
	{
		playersManager.allPlayerObjects[playersManager.thisClientPlayerId].GetComponentInChildren<GlobalEffects>().PlayAudioServerFromSenderObject(serverAudio);
	}

	public void PlayAudioServerFromSenderObject(ServerAudio serverAudio)
	{
		PlayAudioServerRpc(serverAudio);
	}

	[ServerRpc(RequireOwnership = false)]
	private void PlayAudioServerRpc(ServerAudio serverAudio)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1842858504u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<ServerAudio>(ref serverAudio, default(ForNetworkSerializable));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1842858504u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PlayAudioClientRpc(serverAudio);
			}
		}
	}

	[ClientRpc]
	private void PlayAudioClientRpc(ServerAudio serverAudio)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(182727243u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<ServerAudio>(ref serverAudio, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 182727243u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref serverAudio.audioObj)).TryGet(ref val3, (NetworkManager)null))
		{
			AudioSource component = ((Component)val3).gameObject.GetComponent<AudioSource>();
			if (serverAudio.oneshot)
			{
				component.PlayOneShot(component.clip, 1f);
				return;
			}
			component.loop = serverAudio.looped;
			component.Play();
		}
		else
		{
			Debug.LogWarning((object)"Was not able to retrieve NetworkObject from NetworkObjectReference; audio");
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_GlobalEffects()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2259057361u, new RpcReceiveHandler(__rpc_handler_2259057361));
		NetworkManager.__rpc_func_table.Add(2993461149u, new RpcReceiveHandler(__rpc_handler_2993461149));
		NetworkManager.__rpc_func_table.Add(2698736096u, new RpcReceiveHandler(__rpc_handler_2698736096));
		NetworkManager.__rpc_func_table.Add(780678780u, new RpcReceiveHandler(__rpc_handler_780678780));
		NetworkManager.__rpc_func_table.Add(1842858504u, new RpcReceiveHandler(__rpc_handler_1842858504));
		NetworkManager.__rpc_func_table.Add(182727243u, new RpcReceiveHandler(__rpc_handler_182727243));
	}

	private static void __rpc_handler_2259057361(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ServerAnimAndAudio serverAnimAndAudio = default(ServerAnimAndAudio);
			((FastBufferReader)(ref reader)).ReadValueSafe<ServerAnimAndAudio>(ref serverAnimAndAudio, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GlobalEffects)(object)target).PlayAnimAndAudioServerRpc(serverAnimAndAudio);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2993461149(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ServerAnimAndAudio serverAnimAndAudio = default(ServerAnimAndAudio);
			((FastBufferReader)(ref reader)).ReadValueSafe<ServerAnimAndAudio>(ref serverAnimAndAudio, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GlobalEffects)(object)target).PlayAnimAndAudioClientRpc(serverAnimAndAudio);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2698736096(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ServerAnimation serverAnimation = default(ServerAnimation);
			((FastBufferReader)(ref reader)).ReadValueSafe<ServerAnimation>(ref serverAnimation, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GlobalEffects)(object)target).PlayAnimationServerRpc(serverAnimation);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_780678780(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ServerAnimation serverAnimation = default(ServerAnimation);
			((FastBufferReader)(ref reader)).ReadValueSafe<ServerAnimation>(ref serverAnimation, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GlobalEffects)(object)target).PlayAnimationClientRpc(serverAnimation);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1842858504(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ServerAudio serverAudio = default(ServerAudio);
			((FastBufferReader)(ref reader)).ReadValueSafe<ServerAudio>(ref serverAudio, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GlobalEffects)(object)target).PlayAudioServerRpc(serverAudio);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_182727243(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ServerAudio serverAudio = default(ServerAudio);
			((FastBufferReader)(ref reader)).ReadValueSafe<ServerAudio>(ref serverAudio, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GlobalEffects)(object)target).PlayAudioClientRpc(serverAudio);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "GlobalEffects";
	}
}
