using UnityEngine;

public class TestScript : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
