using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class KepRemapPanel : MonoBehaviour
{
	public List<RemappableKey> remappableKeys = new List<RemappableKey>();

	public List<GameObject> keySlots = new List<GameObject>();

	public GameObject keyRemapSlotPrefab;

	public RectTransform keyRemapContainer;

	public float maxVertical;

	public float horizontalOffset;

	public float verticalOffset;

	public int currentVertical;

	public int currentHorizontal;

	public GameObject sectionTextPrefab;

	public void ResetKeybindsUI()
	{
		UnloadKeybindsUI();
		LoadKeybindsUI();
	}

	private void OnDisable()
	{
		UnloadKeybindsUI();
	}

	public void UnloadKeybindsUI()
	{
		for (int i = 0; i < keySlots.Count; i++)
		{
			Object.Destroy((Object)(object)keySlots[i]);
		}
		keySlots.Clear();
	}

	public void LoadKeybindsUI()
	{
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		currentVertical = 0;
		currentHorizontal = 0;
		Vector2 anchoredPosition = default(Vector2);
		((Vector2)(ref anchoredPosition))._002Ector(horizontalOffset * (float)currentHorizontal, verticalOffset * (float)currentVertical);
		bool flag = false;
		int num = 0;
		for (int i = 0; i < remappableKeys.Count; i++)
		{
			if ((Object)(object)remappableKeys[i].currentInput == (Object)null)
			{
				continue;
			}
			GameObject val = Object.Instantiate<GameObject>(keyRemapSlotPrefab, (Transform)(object)keyRemapContainer);
			keySlots.Add(val);
			((TMP_Text)val.GetComponentInChildren<TextMeshProUGUI>()).text = remappableKeys[i].ControlName;
			val.GetComponent<RectTransform>().anchoredPosition = anchoredPosition;
			SettingsOption componentInChildren = val.GetComponentInChildren<SettingsOption>();
			componentInChildren.rebindableAction = remappableKeys[i].currentInput;
			componentInChildren.rebindableActionBindingIndex = remappableKeys[i].rebindingIndex;
			componentInChildren.gamepadOnlyRebinding = remappableKeys[i].gamepadOnly;
			Debug.Log((object)$"{remappableKeys[i].ControlName}: rebind controls length: {remappableKeys[i].currentInput.action.controls.Count}");
			Debug.Log((object)$"{remappableKeys[i].ControlName}: rebind control binding index is {remappableKeys[i].rebindingIndex}");
			InputBinding val2;
			for (int j = 0; j < remappableKeys[i].currentInput.action.controls.Count; j++)
			{
				object arg = j;
				val2 = remappableKeys[i].currentInput.action.bindings[InputActionRebindingExtensions.GetBindingIndexForControl(remappableKeys[i].currentInput.action, remappableKeys[i].currentInput.action.controls[j])];
				Debug.Log((object)$"control #{arg}: ${InputControlPath.ToHumanReadableString(((InputBinding)(ref val2)).effectivePath, (HumanReadableStringOptions)2, (InputControl)null)}");
			}
			int rebindingIndex = remappableKeys[i].rebindingIndex;
			int num2 = Mathf.Max(rebindingIndex, 0);
			TextMeshProUGUI currentlyUsedKeyText = componentInChildren.currentlyUsedKeyText;
			val2 = componentInChildren.rebindableAction.action.bindings[num2];
			((TMP_Text)currentlyUsedKeyText).text = InputControlPath.ToHumanReadableString(((InputBinding)(ref val2)).effectivePath, (HumanReadableStringOptions)2, (InputControl)null);
			Debug.Log((object)$"bindingIndex of {((TMP_Text)componentInChildren.currentlyUsedKeyText).text} : {rebindingIndex}; display bindingIndex: {num2}");
			if (!flag && i + 1 < remappableKeys.Count && remappableKeys[i + 1].gamepadOnly)
			{
				num = (int)(maxVertical + 2f);
				currentVertical = 0;
				currentHorizontal = 0;
				GameObject val3 = Object.Instantiate<GameObject>(sectionTextPrefab, (Transform)(object)keyRemapContainer);
				val3.GetComponent<RectTransform>().anchoredPosition = new Vector2(-40f, (0f - verticalOffset) * (float)num);
				((TMP_Text)val3.GetComponentInChildren<TextMeshProUGUI>()).text = "REBIND CONTROLLERS";
				keySlots.Add(val3);
				flag = true;
			}
			else
			{
				currentVertical++;
				if ((float)currentVertical > maxVertical)
				{
					currentVertical = 0;
					currentHorizontal++;
				}
			}
			((Vector2)(ref anchoredPosition))._002Ector(horizontalOffset * (float)currentHorizontal, (0f - verticalOffset) * (float)(currentVertical + num));
		}
	}

	private void OnEnable()
	{
		LoadKeybindsUI();
	}
}
