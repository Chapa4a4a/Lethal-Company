public enum SpecialHUDMenu
{
	None,
	BeltBagInventory
}
