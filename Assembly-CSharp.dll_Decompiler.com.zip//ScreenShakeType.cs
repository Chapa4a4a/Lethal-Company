public enum ScreenShakeType
{
	Small,
	Big,
	Long,
	VeryStrong
}
