using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class BlobAI : EnemyAI
{
	[Header("Fluid simulation")]
	public Transform centerPoint;

	public Transform[] SlimeRaycastTargets;

	public Rigidbody[] SlimeBones;

	private Vector3[] SlimeBonePositions = (Vector3[])(object)new Vector3[8];

	public float slimeRange = 8f;

	public float currentSlimeRange;

	private float[] maxDistanceForSlimeRays = new float[8];

	private float[] distanceOfRaysLastFrame = new float[8];

	private int partsMovingUpSlope;

	private Ray slimeRay;

	private RaycastHit slimeRayHit;

	private RaycastHit slimePlayerRayHit;

	private float timeSinceHittingLocalPlayer;

	[Header("Behaviors")]
	public AISearchRoutine searchForPlayers;

	private float tamedTimer;

	private float angeredTimer;

	private Material thisSlimeMaterial;

	private float slimeJiggleAmplitude;

	private float slimeJiggleDensity;

	[Header("SFX")]
	public AudioSource movableAudioSource;

	public AudioClip agitatedSFX;

	public AudioClip jiggleSFX;

	public AudioClip hitSlimeSFX;

	public AudioClip killPlayerSFX;

	public AudioClip idleSFX;

	private Collider[] ragdollColliders;

	private Coroutine eatPlayerBodyCoroutine;

	private DeadBodyInfo bodyBeingCarried;

	private int slimeMask = 268470529;

	public Mesh emptySuitMesh;

	public override void Start()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		ragdollColliders = (Collider[])(object)new Collider[4];
		base.Start();
		thisSlimeMaterial = ((Renderer)skinnedMeshRenderers[0]).material;
		for (int i = 0; i < maxDistanceForSlimeRays.Length; i++)
		{
			maxDistanceForSlimeRays[i] = 3.7f;
			SlimeBonePositions[i] = ((Component)SlimeBones[i]).transform.position;
		}
	}

	public override void DoAIInterval()
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (!isEnemyDead && !StartOfRound.Instance.allPlayersDead)
		{
			if (TargetClosestPlayer(4f))
			{
				StopSearch(searchForPlayers);
				movingTowardsTargetPlayer = true;
			}
			else
			{
				movingTowardsTargetPlayer = false;
				StartSearch(((Component)this).transform.position, searchForPlayers);
			}
		}
	}

	private void SimulateSurfaceTensionInRaycasts(int i)
	{
		float num = distanceOfRaysLastFrame[(i + 1) % SlimeRaycastTargets.Length];
		float num2 = ((i != 0) ? distanceOfRaysLastFrame[i - 1] : distanceOfRaysLastFrame[SlimeRaycastTargets.Length - 1]);
		float num3 = Mathf.Clamp((num2 + num) / 2f, 0.5f, 200f);
		float num4 = 1f;
		if (num3 < 2f)
		{
			num4 = 2f;
		}
		maxDistanceForSlimeRays[i] = Mathf.Clamp(num3 * 2f * num4, 0f, currentSlimeRange);
	}

	private void FixedUpdate()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		if (!ventAnimationFinished)
		{
			return;
		}
		for (int i = 0; i < SlimeBonePositions.Length; i++)
		{
			if (Vector3.Distance(centerPoint.position, SlimeBonePositions[i]) > distanceOfRaysLastFrame[i])
			{
				SlimeBones[i].MovePosition(Vector3.Lerp(SlimeBones[i].position, SlimeBonePositions[i], 10f * Time.deltaTime));
			}
			else
			{
				SlimeBones[i].MovePosition(Vector3.Lerp(SlimeBones[i].position, SlimeBonePositions[i], 5f * Time.deltaTime));
			}
		}
	}

	public override void Update()
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (!ventAnimationFinished || !((Object)(object)creatureAnimator != (Object)null))
		{
			return;
		}
		((Behaviour)creatureAnimator).enabled = false;
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		timeSinceHittingLocalPlayer += Time.deltaTime;
		partsMovingUpSlope = 0;
		Vector3 val = serverPosition;
		for (int i = 0; i < SlimeRaycastTargets.Length; i++)
		{
			Vector3 val2 = SlimeRaycastTargets[i].position - centerPoint.position;
			slimeRay = new Ray(val, val2);
			RaycastCollisionWithPlayers(Vector3.Distance(val, ((Component)SlimeBones[i]).transform.position));
			if (Physics.Raycast(slimeRay, ref slimeRayHit, maxDistanceForSlimeRays[i], slimeMask, (QueryTriggerInteraction)1))
			{
				MoveSlimeBoneToRaycastHit(0f, i);
				continue;
			}
			Vector3 navMeshPosition = RoundManager.Instance.GetNavMeshPosition(((Ray)(ref slimeRay)).GetPoint(maxDistanceForSlimeRays[i]));
			SlimeBonePositions[i] = Vector3.Lerp(SlimeBonePositions[i], navMeshPosition, 1f * Time.deltaTime);
			distanceOfRaysLastFrame[i] = maxDistanceForSlimeRays[i];
		}
		if (stunNormalizedTimer > 0f)
		{
			thisSlimeMaterial.SetFloat("_Frequency", 4f);
			slimeJiggleDensity = Mathf.Lerp(slimeJiggleDensity, 1f, 10f * Time.deltaTime);
			thisSlimeMaterial.SetFloat("_Ripple_Density", slimeJiggleDensity);
			slimeJiggleAmplitude = Mathf.Lerp(slimeJiggleAmplitude, 0.17f, 10f * Time.deltaTime);
			thisSlimeMaterial.SetFloat("_Amplitude", slimeJiggleAmplitude);
			agent.speed = 0f;
			currentSlimeRange = Mathf.Lerp(currentSlimeRange, 2f, Time.deltaTime * 4f);
			angeredTimer = 7f;
			return;
		}
		if (angeredTimer > 0f)
		{
			angeredTimer -= Time.deltaTime;
			currentSlimeRange = Mathf.Lerp(currentSlimeRange, slimeRange + 6f, Time.deltaTime * 3f);
			thisSlimeMaterial.SetFloat("_Frequency", 3f);
			slimeJiggleDensity = Mathf.Lerp(slimeJiggleDensity, 1f, 10f * Time.deltaTime);
			thisSlimeMaterial.SetFloat("_Ripple_Density", slimeJiggleDensity);
			slimeJiggleAmplitude = Mathf.Lerp(slimeJiggleAmplitude, 0.14f, 10f * Time.deltaTime);
			thisSlimeMaterial.SetFloat("_Amplitude", slimeJiggleAmplitude);
			if ((Object)(object)creatureSFX.clip != (Object)(object)agitatedSFX)
			{
				creatureSFX.clip = agitatedSFX;
				creatureSFX.Play();
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
				agent.stoppingDistance = 0.1f;
				agent.speed = 0.6f;
			}
			return;
		}
		if (tamedTimer > 0f)
		{
			tamedTimer -= Time.deltaTime;
			currentSlimeRange = 1.5f;
			thisSlimeMaterial.SetFloat("_Frequency", 4.3f);
			slimeJiggleDensity = Mathf.Lerp(slimeJiggleDensity, 1.3f, 10f * Time.deltaTime);
			thisSlimeMaterial.SetFloat("_Ripple_Density", slimeJiggleDensity);
			slimeJiggleAmplitude = Mathf.Lerp(slimeJiggleAmplitude, 0.2f, 10f * Time.deltaTime);
			thisSlimeMaterial.SetFloat("_Amplitude", slimeJiggleAmplitude);
			if ((Object)(object)creatureSFX.clip != (Object)(object)jiggleSFX)
			{
				creatureSFX.clip = jiggleSFX;
				creatureSFX.Play();
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
				agent.stoppingDistance = 5f;
				agent.speed = Mathf.Lerp(agent.speed, 3f, 0.7f * Time.deltaTime);
			}
			return;
		}
		if (partsMovingUpSlope >= 2)
		{
			currentSlimeRange = Mathf.Clamp(slimeRange / 2f, 1.5f, 100f);
		}
		else
		{
			currentSlimeRange = slimeRange;
		}
		thisSlimeMaterial.SetFloat("_Frequency", 2f);
		slimeJiggleDensity = Mathf.Lerp(slimeJiggleDensity, 0.6f, 10f * Time.deltaTime);
		thisSlimeMaterial.SetFloat("_Ripple_Density", slimeJiggleDensity);
		slimeJiggleAmplitude = Mathf.Lerp(slimeJiggleAmplitude, 0.15f, 10f * Time.deltaTime);
		thisSlimeMaterial.SetFloat("_Amplitude", slimeJiggleAmplitude);
		if ((Object)(object)creatureSFX.clip != (Object)(object)idleSFX)
		{
			creatureSFX.clip = idleSFX;
			creatureSFX.Play();
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			agent.stoppingDistance = 0.1f;
			agent.speed = 0.5f;
		}
	}

	private void MoveSlimeBoneToRaycastHit(float currentRangeOfRaycast, int i)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		float num = 1.8f;
		if (((RaycastHit)(ref slimeRayHit)).distance + currentRangeOfRaycast < distanceOfRaysLastFrame[i])
		{
			num = 5f;
		}
		SlimeBonePositions[i] = Vector3.Lerp(SlimeBonePositions[i], ((Ray)(ref slimeRay)).GetPoint(((RaycastHit)(ref slimeRayHit)).distance), num * Time.deltaTime);
		distanceOfRaysLastFrame[i] = ((RaycastHit)(ref slimeRayHit)).distance + currentRangeOfRaycast;
	}

	private void RaycastCollisionWithPlayers(float maxDistance)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		maxDistance -= 1.55f;
		if (Physics.SphereCast(slimeRay, 0.7f, ref slimePlayerRayHit, maxDistance, 2312) && ((Component)((RaycastHit)(ref slimePlayerRayHit)).collider).gameObject.CompareTag("Player"))
		{
			OnCollideWithPlayer(((RaycastHit)(ref slimePlayerRayHit)).collider);
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (timeSinceHittingLocalPlayer < 0.25f || (tamedTimer > 0f && angeredTimer < 0f))
		{
			return;
		}
		PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
		if ((Object)(object)playerControllerB != (Object)null)
		{
			timeSinceHittingLocalPlayer = 0f;
			playerControllerB.DamagePlayer(35);
			if (playerControllerB.isPlayerDead)
			{
				SlimeKillPlayerEffectServerRpc((int)playerControllerB.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SlimeKillPlayerEffectServerRpc(int playerKilled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3848306567u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerKilled);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3848306567u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SlimeKillPlayerEffectClientRpc(playerKilled);
			}
		}
	}

	[ClientRpc]
	public void SlimeKillPlayerEffectClientRpc(int playerKilled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1531516867u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerKilled);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1531516867u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			creatureSFX.PlayOneShot(killPlayerSFX);
			angeredTimer = 0f;
			if (eatPlayerBodyCoroutine == null)
			{
				eatPlayerBodyCoroutine = ((MonoBehaviour)this).StartCoroutine(eatPlayerBody(playerKilled));
			}
		}
	}

	private IEnumerator eatPlayerBody(int playerKilled)
	{
		yield return null;
		PlayerControllerB playerScript = StartOfRound.Instance.allPlayerScripts[playerKilled];
		float startTime = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)playerScript.deadBody != (Object)null || Time.realtimeSinceStartup - startTime > 2f));
		if ((Object)(object)playerScript.deadBody == (Object)null)
		{
			Debug.Log((object)"Blob: Player body was not spawned or found within 2 seconds.");
			yield break;
		}
		playerScript.deadBody.attachedLimb = playerScript.deadBody.bodyParts[6];
		playerScript.deadBody.attachedTo = centerPoint;
		playerScript.deadBody.matchPositionExactly = false;
		yield return (object)new WaitForSeconds(2f);
		playerScript.deadBody.attachedTo = null;
		playerScript.deadBody.ChangeMesh(emptySuitMesh);
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		angeredTimer = 18f;
		if ((Object)(object)playerWhoHit != (Object)null)
		{
			((Component)movableAudioSource).transform.position = ((Component)playerWhoHit.gameplayCamera).transform.position + ((Component)playerWhoHit.gameplayCamera).transform.forward * 1.5f;
		}
		else
		{
			((Component)movableAudioSource).transform.position = centerPoint.position;
		}
		movableAudioSource.PlayOneShot(hitSlimeSFX);
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesPlayedInOneSpot, noiseID);
		if (noiseID == 5 && !Physics.Linecast(((Component)this).transform.position, noisePosition, StartOfRound.Instance.collidersAndRoomMask) && Vector3.Distance(((Component)this).transform.position, noisePosition) < 12f)
		{
			tamedTimer = 2f;
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_BlobAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3848306567u, new RpcReceiveHandler(__rpc_handler_3848306567));
		NetworkManager.__rpc_func_table.Add(1531516867u, new RpcReceiveHandler(__rpc_handler_1531516867));
	}

	private static void __rpc_handler_3848306567(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerKilled = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerKilled);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BlobAI)(object)target).SlimeKillPlayerEffectServerRpc(playerKilled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1531516867(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerKilled = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerKilled);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BlobAI)(object)target).SlimeKillPlayerEffectClientRpc(playerKilled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "BlobAI";
	}
}
