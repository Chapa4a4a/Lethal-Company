using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SelectUIForGamepad : MonoBehaviour
{
	public bool doOnStart;

	private void Start()
	{
		if (doOnStart && ((Component)this).gameObject.activeSelf)
		{
			((Selectable)((Component)this).gameObject.GetComponent<Button>()).Select();
		}
	}

	private void OnEnable()
	{
		((Selectable)((Component)this).gameObject.GetComponent<Button>()).Select();
	}

	private void OnDisable()
	{
		if (!((Object)(object)EventSystem.current == (Object)null))
		{
			EventSystem.current.SetSelectedGameObject((GameObject)null);
		}
	}
}
