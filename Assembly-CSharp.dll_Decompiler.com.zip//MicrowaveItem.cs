using System.Collections;
using UnityEngine;

public class MicrowaveItem : MonoBehaviour
{
	public GameObject mainObject;

	private Coroutine microwaveOnDelay;

	public AudioSource whirringAudio;

	public AudioClip microwaveOpen;

	public AudioClip microwaveClose;

	public void TurnOnMicrowave(bool on)
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		if (!on)
		{
			whirringAudio.PlayOneShot(microwaveClose);
			GrabbableObject[] componentsInChildren = mainObject.GetComponentsInChildren<GrabbableObject>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].rotateObject = true;
			}
			if (microwaveOnDelay != null)
			{
				((MonoBehaviour)this).StopCoroutine(microwaveOnDelay);
			}
			microwaveOnDelay = ((MonoBehaviour)this).StartCoroutine(startMicrowaveOnDelay());
		}
		else
		{
			if (microwaveOnDelay != null)
			{
				((MonoBehaviour)this).StopCoroutine(microwaveOnDelay);
			}
			Collider[] array = Physics.OverlapSphere(mainObject.transform.position, 5f, 64, (QueryTriggerInteraction)2);
			for (int j = 0; j < array.Length; j++)
			{
				((Component)array[j]).GetComponent<GrabbableObject>().rotateObject = false;
			}
			whirringAudio.Stop();
			whirringAudio.PlayOneShot(microwaveOpen);
		}
	}

	private IEnumerator startMicrowaveOnDelay()
	{
		yield return (object)new WaitForSeconds(0.25f);
		RoundManager.Instance.PlayAudibleNoise(mainObject.transform.position, 8f, 0.6f, 0, StartOfRound.Instance.hangarDoorsClosed);
		yield return (object)new WaitForSeconds(0.5f);
		whirringAudio.Play();
	}
}
