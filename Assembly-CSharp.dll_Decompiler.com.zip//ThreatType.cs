using System;

[Serializable]
public enum ThreatType
{
	Player,
	Projectile,
	Bees,
	EyelessDog,
	ForestGiant,
	Item,
	RadMech,
	BaboonHawk,
	BushWolf,
	GiantKiwi
}
