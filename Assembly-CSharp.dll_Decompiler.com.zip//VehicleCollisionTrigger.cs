using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class VehicleCollisionTrigger : MonoBehaviour
{
	public VehicleController mainScript;

	private float timeSinceHittingPlayer;

	private float timeSinceHittingEnemy;

	public BoxCollider insideTruckNavMeshBounds;

	public EnemyAI[] enemiesLastHit;

	private int enemyIndex;

	private void Start()
	{
		enemiesLastHit = new EnemyAI[3];
	}

	private void OnTriggerEnter(Collider other)
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0451: Unknown result type (might be due to invalid IL or missing references)
		//IL_0456: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_0528: Unknown result type (might be due to invalid IL or missing references)
		//IL_052d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0485: Unknown result type (might be due to invalid IL or missing references)
		//IL_048a: Unknown result type (might be due to invalid IL or missing references)
		//IL_049b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0566: Unknown result type (might be due to invalid IL or missing references)
		//IL_056b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0573: Unknown result type (might be due to invalid IL or missing references)
		//IL_059c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05df: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		if (!mainScript.hasBeenSpawned || (mainScript.magnetedToShip && mainScript.magnetTime > 0.8f))
		{
			return;
		}
		if (((Component)other).gameObject.CompareTag("Player"))
		{
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)component == (Object)null || mainScript.localPlayerInPassengerSeat || Time.realtimeSinceStartup - timeSinceHittingPlayer < 0.25f)
			{
				return;
			}
			float num = ((Vector3)(ref mainScript.averageVelocity)).magnitude;
			if (num < 2f)
			{
				return;
			}
			Vector3 val = ((Component)component).transform.position - mainScript.mainRigidbody.position;
			float num2 = Vector3.Angle(Vector3.Normalize(mainScript.averageVelocity * 1000f), Vector3.Normalize(val * 1000f));
			if (num2 > 70f)
			{
				return;
			}
			if (num2 < 30f && mainScript.EngineRPM > 400f)
			{
				num += 6f;
			}
			if ((((Component)component.gameplayCamera).transform.position - mainScript.mainRigidbody.position).y < -0.1f)
			{
				num *= 2f;
			}
			timeSinceHittingPlayer = Time.realtimeSinceStartup;
			Vector3 val2 = Vector3.ClampMagnitude(mainScript.averageVelocity, 40f);
			if ((Object)(object)component == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				if ((Object)(object)mainScript.physicsRegion.physicsTransform == (Object)(object)GameNetworkManager.Instance.localPlayerController.physicsParent)
				{
					return;
				}
				if (num > 20f)
				{
					GameNetworkManager.Instance.localPlayerController.KillPlayer(val2, spawnBody: true, CauseOfDeath.Crushing);
				}
				else
				{
					int num3 = 0;
					if (num > 15f)
					{
						num3 = 80;
					}
					else if (num > 12f)
					{
						num3 = 60;
					}
					else if (num > 8f)
					{
						num3 = 40;
					}
					if (num3 > 0)
					{
						GameNetworkManager.Instance.localPlayerController.DamagePlayer(num3, hasDamageSFX: true, callRPC: true, CauseOfDeath.Crushing, 0, fallDamage: false, val2);
					}
				}
				if (!GameNetworkManager.Instance.localPlayerController.isPlayerDead && ((Vector3)(ref GameNetworkManager.Instance.localPlayerController.externalForceAutoFade)).sqrMagnitude < ((Vector3)(ref mainScript.averageVelocity)).sqrMagnitude)
				{
					GameNetworkManager.Instance.localPlayerController.externalForceAutoFade = mainScript.averageVelocity;
				}
			}
			else if (((NetworkBehaviour)mainScript).IsOwner && ((Vector3)(ref mainScript.averageVelocity)).magnitude > 1.8f)
			{
				mainScript.CarReactToObstacle(mainScript.averageVelocity, ((Component)component).transform.position, mainScript.averageVelocity, CarObstacleType.Player);
			}
		}
		else
		{
			if (!((Component)other).gameObject.CompareTag("Enemy"))
			{
				return;
			}
			Debug.Log((object)("Truck got collision from enemy; " + ((Object)((Component)other).gameObject).name));
			if (Time.realtimeSinceStartup - timeSinceHittingEnemy < 0.25f)
			{
				return;
			}
			EnemyAICollisionDetect component2 = ((Component)other).gameObject.GetComponent<EnemyAICollisionDetect>();
			Debug.Log((object)$"Truck collision: is enemyCollisoinScript null? : {(Object)(object)component2 == (Object)null}");
			if ((Object)(object)component2 == (Object)null || (Object)(object)component2.mainScript == (Object)null || component2.mainScript.isEnemyDead)
			{
				Debug.Log((object)$"Truck collision: {(Object)(object)component2 == (Object)null} || {(Object)(object)component2.mainScript == (Object)null} || {component2.mainScript.isEnemyDead}");
				return;
			}
			if (Vector3.Angle(mainScript.averageVelocity, ((Component)component2.mainScript).transform.position - ((Component)this).transform.position) > 130f)
			{
				Debug.Log((object)$"Angle/vel check did not pass; {Vector3.Angle(mainScript.averageVelocity, ((Component)component2.mainScript).transform.position - ((Component)this).transform.position)}");
				return;
			}
			if (mainScript.backDoorOpen && ((Vector3)(ref mainScript.averageVelocity)).magnitude < 2f && (((Collider)insideTruckNavMeshBounds).ClosestPoint(((Component)component2.mainScript).transform.position) == ((Component)component2.mainScript).transform.position || ((Collider)insideTruckNavMeshBounds).ClosestPoint(component2.mainScript.agent.destination) == component2.mainScript.agent.destination))
			{
				Debug.Log((object)"Truck collision: Enemy colliding with truck is inside the back of the truck; return");
				return;
			}
			bool dealDamage = false;
			for (int i = 0; i < enemiesLastHit.Length; i++)
			{
				if ((Object)(object)enemiesLastHit[i] == (Object)(object)component2.mainScript)
				{
					if (Time.realtimeSinceStartup - timeSinceHittingEnemy < 0.6f)
					{
						dealDamage = true;
					}
					if (((Vector3)(ref mainScript.averageVelocity)).magnitude < 4f)
					{
						dealDamage = true;
					}
				}
			}
			timeSinceHittingEnemy = Time.realtimeSinceStartup;
			bool flag = false;
			Vector3 position = ((Component)component2).transform.position;
			switch (component2.mainScript.enemyType.EnemySize)
			{
			case EnemySize.Tiny:
				flag = mainScript.CarReactToObstacle(mainScript.averageVelocity, position, mainScript.averageVelocity, CarObstacleType.Enemy, 1f, component2.mainScript, dealDamage);
				break;
			case EnemySize.Giant:
				flag = mainScript.CarReactToObstacle(mainScript.averageVelocity, position, mainScript.averageVelocity, CarObstacleType.Enemy, 3f, component2.mainScript, dealDamage);
				break;
			case EnemySize.Medium:
				flag = mainScript.CarReactToObstacle(mainScript.averageVelocity, position, mainScript.averageVelocity, CarObstacleType.Enemy, 2f, component2.mainScript, dealDamage);
				break;
			}
			if (flag)
			{
				enemyIndex = (enemyIndex + 1) % 3;
				enemiesLastHit[enemyIndex] = component2.mainScript;
				return;
			}
			for (int j = 0; j < enemiesLastHit.Length; j++)
			{
				if ((Object)(object)enemiesLastHit[j] == (Object)(object)component2.mainScript)
				{
					enemiesLastHit[j] = null;
				}
			}
		}
	}
}
