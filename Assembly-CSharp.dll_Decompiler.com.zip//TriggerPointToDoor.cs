using UnityEngine;

public class TriggerPointToDoor : MonoBehaviour
{
	public DoorLock pointToDoor;
}
