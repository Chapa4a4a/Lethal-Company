using UnityEngine;

public class facePlayerOnAxis : MonoBehaviour
{
	private Transform playerCamera;

	public Transform turnAxis;

	private bool gotPlayer;

	private void Update()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)StartOfRound.Instance.audioListener != (Object)null)
		{
			((Component)this).transform.LookAt(((Component)StartOfRound.Instance.audioListener).transform.position, turnAxis.up);
		}
	}
}
