using Unity.Netcode;
using UnityEngine;

public class KeyItem : GrabbableObject
{
	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val = default(RaycastHit);
		if ((Object)(object)playerHeldBy == (Object)null || !((NetworkBehaviour)this).IsOwner || !Physics.Raycast(new Ray(((Component)playerHeldBy.gameplayCamera).transform.position, ((Component)playerHeldBy.gameplayCamera).transform.forward), ref val, 3f, 2816))
		{
			return;
		}
		DoorLock doorLock = ((Component)((RaycastHit)(ref val)).transform).GetComponent<DoorLock>();
		if ((Object)(object)doorLock == (Object)null)
		{
			TriggerPointToDoor component = ((Component)((RaycastHit)(ref val)).transform).GetComponent<TriggerPointToDoor>();
			if ((Object)(object)component != (Object)null)
			{
				doorLock = component.pointToDoor;
			}
		}
		if ((Object)(object)doorLock != (Object)null && doorLock.isLocked && !doorLock.isPickingLock)
		{
			doorLock.UnlockDoorSyncWithServer();
			playerHeldBy.DespawnHeldObject();
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "KeyItem";
	}
}
