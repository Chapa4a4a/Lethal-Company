using Unity.Netcode;

public struct ServerAnimation : INetworkSerializable
{
	public string animationString;

	public NetworkObjectReference animatorObj;

	public bool isTrigger;

	public bool setTrue;

	public unsafe void NetworkSerialize<T>(BufferSerializer<T> serializer) where T : IReaderWriter
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		((BufferSerializer<NetworkObjectReference>*)(&serializer))->SerializeValue<NetworkObjectReference>(ref animatorObj, default(ForNetworkSerializable));
		((BufferSerializer<bool>*)(&serializer))->SerializeValue<bool>(ref isTrigger, default(ForPrimitives));
		if (!isTrigger)
		{
			((BufferSerializer<bool>*)(&serializer))->SerializeValue<bool>(ref setTrue, default(ForPrimitives));
		}
	}
}
