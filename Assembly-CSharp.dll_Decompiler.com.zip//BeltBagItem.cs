using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class BeltBagItem : GrabbableObject
{
	public Animator beltBagAnimator;

	public AudioSource bagAudio;

	public Vector3 beltBagTorsoOffset;

	public Vector3 beltBagTorsoOffsetRotation;

	public bool subtractOffset;

	public Transform hangingBeltTarget;

	public PlayerControllerB currentPlayerChecking;

	private bool tryingCheckBag;

	public List<GrabbableObject> objectsInBag = new List<GrabbableObject>();

	private BeltBagInventoryUI beltBagUI;

	public bool tryingAddToBag;

	public AudioClip zipUpBagSFX;

	public AudioClip[] unzipBagSFX;

	public AudioClip[] grabItemInBagSFX;

	public AudioClip beltBagUnclipSFX;

	private bool wasPocketed;

	private float timeAtLastGrabbingItemInBag;

	private int placingItemsInBag;

	public BeltBagItem insideAnotherBeltBag;

	public InteractTrigger useBagTrigger;

	public void GrabItemInBag()
	{
		if (Time.realtimeSinceStartup - timeAtLastGrabbingItemInBag > 0.17f)
		{
			timeAtLastGrabbingItemInBag = Time.realtimeSinceStartup;
			RoundManager.PlayRandomClip(bagAudio, grabItemInBagSFX, randomize: true, 1f, -1);
			GrabItemInBagServerRpc();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void GrabItemInBagServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(622177509u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 622177509u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				GrabItemInBagClientRpc();
			}
		}
	}

	[ClientRpc]
	public void GrabItemInBagClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2703921983u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2703921983u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)currentPlayerChecking == (Object)(object)GameNetworkManager.Instance.localPlayerController))
			{
				RoundManager.PlayRandomClip(bagAudio, grabItemInBagSFX, randomize: true, 1f, -1);
			}
		}
	}

	public void TryAddObjectToBag(GrabbableObject gObject)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (!tryingAddToBag && !objectsInBag.Contains(gObject))
		{
			NetworkObject component = ((Component)gObject).GetComponent<NetworkObject>();
			if (!((Object)(object)component == (Object)null))
			{
				tryingAddToBag = true;
				TryAddObjectToBagServerRpc(NetworkObjectReference.op_Implicit(component), (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void TryAddObjectToBagServerRpc(NetworkObjectReference netObjectRef, int playerWhoAdded)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2988305002u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, playerWhoAdded);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2988305002u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref netObjectRef)).TryGet(ref val3, (NetworkManager)null))
		{
			GrabbableObject component = ((Component)val3).GetComponent<GrabbableObject>();
			if ((Object)(object)component != (Object)null && !component.isHeld && !component.heldByPlayerOnServer && !component.isHeldByEnemy)
			{
				if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerWhoAdded] == (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					tryingAddToBag = false;
				}
				component.heldByPlayerOnServer = true;
				PutObjectInBagLocalClient(component);
				TryAddObjectToBagClientRpc(netObjectRef, playerWhoAdded);
				return;
			}
		}
		CancelAddObjectToBagClientRpc(playerWhoAdded);
	}

	[ClientRpc]
	public void TryAddObjectToBagClientRpc(NetworkObjectReference netObjectRef, int playerWhoAdded)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3900201301u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, playerWhoAdded);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3900201301u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerWhoAdded] == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			tryingAddToBag = false;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref netObjectRef)).TryGet(ref val3, (NetworkManager)null))
		{
			GrabbableObject component = ((Component)val3).GetComponent<GrabbableObject>();
			if ((Object)(object)component != (Object)null)
			{
				PutObjectInBagLocalClient(component);
			}
		}
	}

	[ClientRpc]
	public void CancelAddObjectToBagClientRpc(int playerWhoAdded)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1076504254u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoAdded);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1076504254u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)StartOfRound.Instance.allPlayerScripts[playerWhoAdded] != (Object)(object)GameNetworkManager.Instance.localPlayerController))
			{
				tryingAddToBag = false;
			}
		}
	}

	public void PutObjectInBagLocalClient(GrabbableObject gObject)
	{
		if (!objectsInBag.Contains(gObject))
		{
			objectsInBag.Add(gObject);
		}
		if ((Object)(object)currentPlayerChecking == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			beltBagUI.FillSlots(this);
		}
		BeltBagItem beltBagItem = gObject as BeltBagItem;
		if ((Object)(object)beltBagItem != (Object)null)
		{
			beltBagItem.insideAnotherBeltBag = this;
		}
		RoundManager.PlayRandomClip(bagAudio, grabItemInBagSFX, randomize: true, 1f, -1);
		((MonoBehaviour)this).StartCoroutine(putObjectInBagAnimation(gObject));
	}

	private IEnumerator putObjectInBagAnimation(GrabbableObject gObject)
	{
		float time = 0f;
		Vector3 startingPosition = ((Component)gObject).transform.position;
		gObject.EnablePhysics(enable: false);
		((Component)gObject).transform.SetParent((Transform)null);
		gObject.startFallingPosition = ((Component)gObject).transform.position;
		gObject.targetFloorPosition = ((Component)gObject).transform.position;
		placingItemsInBag++;
		while (time < 1f)
		{
			time += Time.deltaTime * 14f;
			gObject.targetFloorPosition = Vector3.Lerp(startingPosition, ((Component)this).transform.position, time / 1f);
			yield return null;
		}
		placingItemsInBag--;
		gObject.targetFloorPosition = new Vector3(3000f, -400f, 3000f);
		gObject.startFallingPosition = new Vector3(3000f, -400f, 3000f);
	}

	public void OnDisable()
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		for (int i = 0; i < objectsInBag.Count; i++)
		{
			if (!objectsInBag[i].isHeld && !objectsInBag[i].isHeldByEnemy)
			{
				Object.Destroy((Object)(object)((Component)objectsInBag[i]).gameObject);
			}
		}
	}

	public void RemoveObjectFromBag(int objectId)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		NetworkObject networkObject = ((NetworkBehaviour)objectsInBag[objectId]).NetworkObject;
		bool flag = false;
		bool flag2 = false;
		Vector3 hitPoint;
		NetworkObject physicsRegionOfDroppedObject = GetPhysicsRegionOfDroppedObject(null, out hitPoint);
		if ((Object)(object)physicsRegionOfDroppedObject == (Object)null)
		{
			hitPoint = GetItemFloorPosition();
			Bounds bounds = StartOfRound.Instance.shipInnerRoomBounds.bounds;
			if (((Bounds)(ref bounds)).Contains(hitPoint))
			{
				flag2 = true;
				flag = true;
				hitPoint = StartOfRound.Instance.elevatorTransform.InverseTransformPoint(hitPoint);
			}
			else
			{
				bounds = StartOfRound.Instance.shipBounds.bounds;
				if (((Bounds)(ref bounds)).Contains(hitPoint))
				{
					flag2 = true;
					hitPoint = StartOfRound.Instance.elevatorTransform.InverseTransformPoint(hitPoint);
				}
				else
				{
					hitPoint = StartOfRound.Instance.propsContainer.InverseTransformPoint(hitPoint);
				}
			}
		}
		if (Object.op_Implicit((Object)(object)physicsRegionOfDroppedObject))
		{
			RemoveFromBagLocalClientNonElevatorParent(NetworkObjectReference.op_Implicit(networkObject), NetworkObjectReference.op_Implicit(physicsRegionOfDroppedObject), hitPoint, isInFactory);
			RemoveFromBagNonElevatorParentServerRpc(NetworkObjectReference.op_Implicit(networkObject), NetworkObjectReference.op_Implicit(physicsRegionOfDroppedObject), hitPoint, (int)GameNetworkManager.Instance.localPlayerController.playerClientId, isInFactory);
		}
		else
		{
			RemoveFromBagLocalClient(NetworkObjectReference.op_Implicit(networkObject), flag2, flag, hitPoint, isInFactory);
			RemoveFromBagServerRpc(NetworkObjectReference.op_Implicit(networkObject), flag2, flag, hitPoint, (int)GameNetworkManager.Instance.localPlayerController.playerClientId, isInFactory);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void RemoveFromBagServerRpc(NetworkObjectReference objectRef, bool setInElevator, bool setInShip, Vector3 targetPosition, int playerWhoRemoved, bool inFactory)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4159001947u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setInElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setInShip, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetPosition);
			BytePacker.WriteValueBitPacked(val2, playerWhoRemoved);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inFactory, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4159001947u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerWhoRemoved] != (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				RemoveFromBagLocalClient(objectRef, setInElevator, setInShip, targetPosition, inFactory);
			}
			RemoveFromBagClientRpc(objectRef, setInElevator, setInShip, targetPosition, playerWhoRemoved, inFactory);
		}
	}

	[ClientRpc]
	public void RemoveFromBagClientRpc(NetworkObjectReference objectRef, bool setInElevator, bool setInShip, Vector3 targetPosition, int playerWhoRemoved, bool inFactory)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1949909770u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setInElevator, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setInShip, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetPosition);
				BytePacker.WriteValueBitPacked(val2, playerWhoRemoved);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inFactory, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1949909770u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer && (Object)(object)StartOfRound.Instance.allPlayerScripts[playerWhoRemoved] != (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				RemoveFromBagLocalClient(objectRef, setInElevator, setInShip, targetPosition, inFactory);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void RemoveFromBagNonElevatorParentServerRpc(NetworkObjectReference objectRef, NetworkObjectReference nonElevatorParent, Vector3 targetPosition, int playerWhoRemoved, bool inFactory)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1618346907u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref nonElevatorParent, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetPosition);
			BytePacker.WriteValueBitPacked(val2, playerWhoRemoved);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inFactory, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1618346907u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerWhoRemoved] != (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				RemoveFromBagLocalClientNonElevatorParent(objectRef, nonElevatorParent, targetPosition, inFactory);
			}
			RemoveFromBagNonElevatorParentClientRpc(objectRef, nonElevatorParent, targetPosition, playerWhoRemoved, inFactory);
		}
	}

	[ClientRpc]
	public void RemoveFromBagNonElevatorParentClientRpc(NetworkObjectReference objectRef, NetworkObjectReference nonElevatorParent, Vector3 targetPosition, int playerWhoRemoved, bool inFactory)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2809290913u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref nonElevatorParent, default(ForNetworkSerializable));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetPosition);
				BytePacker.WriteValueBitPacked(val2, playerWhoRemoved);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inFactory, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2809290913u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer && (Object)(object)StartOfRound.Instance.allPlayerScripts[playerWhoRemoved] != (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				RemoveFromBagLocalClientNonElevatorParent(objectRef, nonElevatorParent, targetPosition, inFactory);
			}
		}
	}

	private void RemoveFromBagLocalClientNonElevatorParent(NetworkObjectReference objectRef, NetworkObjectReference parentNetworkObj, Vector3 targetPosition, bool inFactory)
	{
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		GrabbableObject grabbableObject = null;
		NetworkObject val = default(NetworkObject);
		if (((NetworkObjectReference)(ref objectRef)).TryGet(ref val, (NetworkManager)null))
		{
			for (int i = 0; i < objectsInBag.Count; i++)
			{
				if ((Object)(object)((NetworkBehaviour)objectsInBag[i]).NetworkObject == (Object)(object)val)
				{
					grabbableObject = objectsInBag[i];
					objectsInBag.Remove(grabbableObject);
				}
			}
		}
		if (!((Object)(object)grabbableObject == (Object)null))
		{
			if (((NetworkBehaviour)this).IsServer)
			{
				grabbableObject.heldByPlayerOnServer = false;
			}
			grabbableObject.fallTime = 0f;
			grabbableObject.hasHitGround = false;
			grabbableObject.isInFactory = inFactory;
			NetworkObject val2 = default(NetworkObject);
			if (((NetworkObjectReference)(ref parentNetworkObj)).TryGet(ref val2, (NetworkManager)null))
			{
				((Component)grabbableObject).transform.SetParent(((Component)val2).transform);
			}
			GameNetworkManager.Instance.localPlayerController.SetItemInElevator(droppedInShipRoom: false, droppedInElevator: false, grabbableObject);
			if ((Object)(object)((Component)grabbableObject).transform.parent != (Object)null)
			{
				grabbableObject.startFallingPosition = ((Component)grabbableObject).transform.parent.InverseTransformPoint(((Component)this).transform.position + Vector3.up * 0.07f);
			}
			else
			{
				grabbableObject.startFallingPosition = ((Component)this).transform.position + Vector3.up * 0.07f;
			}
			grabbableObject.targetFloorPosition = targetPosition;
			grabbableObject.EnablePhysics(enable: true);
			BeltBagItem beltBagItem = grabbableObject as BeltBagItem;
			if ((Object)(object)beltBagItem != (Object)null)
			{
				beltBagItem.insideAnotherBeltBag = null;
			}
		}
	}

	private void RemoveFromBagLocalClient(NetworkObjectReference objectRef, bool inElevator, bool inShip, Vector3 targetPosition, bool inFactory)
	{
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		GrabbableObject grabbableObject = null;
		NetworkObject val = default(NetworkObject);
		if (((NetworkObjectReference)(ref objectRef)).TryGet(ref val, (NetworkManager)null))
		{
			for (int i = 0; i < objectsInBag.Count; i++)
			{
				if ((Object)(object)((NetworkBehaviour)objectsInBag[i]).NetworkObject == (Object)(object)val)
				{
					grabbableObject = objectsInBag[i];
					objectsInBag.Remove(grabbableObject);
				}
			}
		}
		if (!((Object)(object)grabbableObject == (Object)null))
		{
			if (((NetworkBehaviour)this).IsServer)
			{
				grabbableObject.heldByPlayerOnServer = false;
			}
			grabbableObject.fallTime = 0f;
			grabbableObject.hasHitGround = false;
			grabbableObject.isInFactory = inFactory;
			if (inElevator)
			{
				((Component)grabbableObject).transform.SetParent(StartOfRound.Instance.elevatorTransform, true);
			}
			else
			{
				((Component)grabbableObject).transform.SetParent(StartOfRound.Instance.propsContainer, true);
			}
			GameNetworkManager.Instance.localPlayerController.SetItemInElevator(inElevator, inShip, grabbableObject);
			if ((Object)(object)((Component)grabbableObject).transform.parent != (Object)null)
			{
				grabbableObject.startFallingPosition = ((Component)grabbableObject).transform.parent.InverseTransformPoint(((Component)this).transform.position + Vector3.up * 0.07f);
			}
			grabbableObject.targetFloorPosition = targetPosition;
			grabbableObject.EnablePhysics(enable: true);
			BeltBagItem beltBagItem = grabbableObject as BeltBagItem;
			if ((Object)(object)beltBagItem != (Object)null)
			{
				beltBagItem.insideAnotherBeltBag = null;
			}
		}
	}

	public override void Start()
	{
		base.Start();
		beltBagUI = Object.FindObjectOfType<BeltBagInventoryUI>(true);
	}

	public override void LateUpdate()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		base.LateUpdate();
		hangingBeltTarget.position = ((Component)this).transform.position - Vector3.up * 25f;
		if (!((Object)(object)currentPlayerChecking != (Object)null))
		{
			return;
		}
		if (currentPlayerChecking.isPlayerDead || !currentPlayerChecking.isPlayerControlled)
		{
			currentPlayerChecking = null;
			beltBagAnimator.SetBool("Opened", false);
		}
		else if ((Object)(object)currentPlayerChecking == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			bool flag = false;
			if (Vector3.Distance(((Component)currentPlayerChecking).transform.position, ((Component)this).transform.position) > 4.25f || Vector3.Angle(((Component)currentPlayerChecking).transform.forward, ((Component)this).transform.position - ((Component)currentPlayerChecking).transform.position) > 120f)
			{
				flag = true;
			}
			else if (HUDManager.Instance.currentSpecialMenu != SpecialHUDMenu.BeltBagInventory)
			{
				flag = true;
			}
			if (flag)
			{
				StopCheckingBagLocalClient(isLocalClient: true);
				StopCheckingBagServerRpc();
			}
		}
	}

	public void TryCheckBagContents()
	{
		if (!tryingCheckBag && !((Object)(object)currentPlayerChecking != (Object)null) && placingItemsInBag <= 0 && !beltBagUI.displaying)
		{
			TryCheckingBagServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void TryCheckingBagServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4205663608u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4205663608u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if ((Object)(object)currentPlayerChecking == (Object)null && placingItemsInBag == 0)
			{
				currentPlayerChecking = StartOfRound.Instance.allPlayerScripts[playerId];
				CheckBagLocalClient();
				ConfirmCheckingBagClientRpc(playerId);
			}
			else
			{
				DenyCheckingBagClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void ConfirmCheckingBagClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1562839591u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1562839591u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				currentPlayerChecking = StartOfRound.Instance.allPlayerScripts[playerId];
				CheckBagLocalClient();
			}
		}
	}

	public void CheckBagLocalClient()
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		beltBagAnimator.SetBool("Opened", true);
		RoundManager.PlayRandomClip(bagAudio, unzipBagSFX);
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)currentPlayerChecking)
		{
			tryingCheckBag = false;
			beltBagUI.FillSlots(this);
			HUDManager.Instance.SetMouseCursorSprite(HUDManager.Instance.handOpenCursorTex, new Vector2(16f, 16f));
			GameNetworkManager.Instance.localPlayerController.SetInSpecialMenu(setInMenu: true);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StopCheckingBagServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1006051133u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1006051133u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if ((Object)(object)currentPlayerChecking != (Object)null)
			{
				StopCheckingBagLocalClient();
			}
			StopCheckingBagClientRpc();
		}
	}

	[ClientRpc]
	public void StopCheckingBagClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1465863873u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1465863873u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (Object)(object)currentPlayerChecking != (Object)null)
			{
				StopCheckingBagLocalClient();
			}
		}
	}

	private void StopCheckingBagLocalClient(bool isLocalClient = false)
	{
		if (isLocalClient)
		{
			if (HUDManager.Instance.currentSpecialMenu == SpecialHUDMenu.BeltBagInventory)
			{
				currentPlayerChecking.SetInSpecialMenu(setInMenu: false);
			}
			beltBagUI.currentBeltBag = null;
			beltBagUI.grabbingItemSlot = -1;
		}
		bagAudio.PlayOneShot(zipUpBagSFX);
		WalkieTalkie.TransmitOneShotAudio(bagAudio, zipUpBagSFX);
		beltBagAnimator.SetBool("Opened", false);
		currentPlayerChecking = null;
	}

	[ClientRpc]
	public void DenyCheckingBagClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(835120159u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 835120159u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)StartOfRound.Instance.allPlayerScripts[playerId])
			{
				tryingCheckBag = false;
			}
		}
	}

	public override void PocketItem()
	{
		if (((NetworkBehaviour)this).IsOwner && (Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.IsInspectingItem = false;
			playerHeldBy.equippedUsableItemQE = false;
		}
		isPocketed = true;
		wasPocketed = true;
		((Component)useBagTrigger).GetComponent<Collider>().enabled = true;
		((Component)this).gameObject.GetComponent<AudioSource>().PlayOneShot(itemProperties.pocketSFX, 1f);
		beltBagAnimator.SetBool("Buckled", true);
		parentObject = ((Component)playerHeldBy.lowerTorsoCostumeContainerBeltBagOffset).transform;
		if ((Object)(object)currentPlayerChecking == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			StopCheckingBagLocalClient(isLocalClient: true);
			StopCheckingBagServerRpc();
		}
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		TryCheckBagContents();
	}

	public override void ItemInteractLeftRight(bool right)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		base.ItemInteractLeftRight(right);
		if ((Object)(object)playerHeldBy == (Object)null || tryingAddToBag || objectsInBag.Count >= 15 || right)
		{
			return;
		}
		Debug.DrawRay(((Component)playerHeldBy.gameplayCamera).transform.position, ((Component)playerHeldBy.gameplayCamera).transform.forward * 4f, Color.red, 2f);
		RaycastHit val = default(RaycastHit);
		if (Physics.Raycast(((Component)playerHeldBy.gameplayCamera).transform.position, ((Component)playerHeldBy.gameplayCamera).transform.forward, ref val, 4f, 1073742144, (QueryTriggerInteraction)1))
		{
			GrabbableObject component = ((Component)((RaycastHit)(ref val)).collider).gameObject.GetComponent<GrabbableObject>();
			if (!((Object)(object)component == (Object)null) && !((Object)(object)component == (Object)(object)this) && !component.itemProperties.isScrap && !component.isHeld && !component.isHeldByEnemy && component.itemProperties.itemId != 123984 && component.itemProperties.itemId != 819501)
			{
				TryAddObjectToBag(component);
			}
		}
	}

	public override void EquipItem()
	{
		base.EquipItem();
		if (wasPocketed)
		{
			wasPocketed = false;
			bagAudio.PlayOneShot(beltBagUnclipSFX);
			WalkieTalkie.TransmitOneShotAudio(bagAudio, beltBagUnclipSFX);
		}
		if ((Object)(object)playerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			parentObject = ((Component)playerHeldBy.localItemHolder).transform;
			((Component)useBagTrigger).GetComponent<Collider>().enabled = false;
		}
		else
		{
			parentObject = ((Component)playerHeldBy.serverItemHolder).transform;
		}
		beltBagAnimator.SetBool("Buckled", false);
		playerHeldBy.equippedUsableItemQE = true;
	}

	public override void DiscardItem()
	{
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			playerHeldBy.equippedUsableItemQE = false;
		}
		wasPocketed = false;
		beltBagAnimator.SetBool("Buckled", true);
		((Component)useBagTrigger).GetComponent<Collider>().enabled = true;
		if ((Object)(object)currentPlayerChecking == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			StopCheckingBagLocalClient(isLocalClient: true);
			StopCheckingBagServerRpc();
		}
		base.DiscardItem();
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_BeltBagItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(622177509u, new RpcReceiveHandler(__rpc_handler_622177509));
		NetworkManager.__rpc_func_table.Add(2703921983u, new RpcReceiveHandler(__rpc_handler_2703921983));
		NetworkManager.__rpc_func_table.Add(2988305002u, new RpcReceiveHandler(__rpc_handler_2988305002));
		NetworkManager.__rpc_func_table.Add(3900201301u, new RpcReceiveHandler(__rpc_handler_3900201301));
		NetworkManager.__rpc_func_table.Add(1076504254u, new RpcReceiveHandler(__rpc_handler_1076504254));
		NetworkManager.__rpc_func_table.Add(4159001947u, new RpcReceiveHandler(__rpc_handler_4159001947));
		NetworkManager.__rpc_func_table.Add(1949909770u, new RpcReceiveHandler(__rpc_handler_1949909770));
		NetworkManager.__rpc_func_table.Add(1618346907u, new RpcReceiveHandler(__rpc_handler_1618346907));
		NetworkManager.__rpc_func_table.Add(2809290913u, new RpcReceiveHandler(__rpc_handler_2809290913));
		NetworkManager.__rpc_func_table.Add(4205663608u, new RpcReceiveHandler(__rpc_handler_4205663608));
		NetworkManager.__rpc_func_table.Add(1562839591u, new RpcReceiveHandler(__rpc_handler_1562839591));
		NetworkManager.__rpc_func_table.Add(1006051133u, new RpcReceiveHandler(__rpc_handler_1006051133));
		NetworkManager.__rpc_func_table.Add(1465863873u, new RpcReceiveHandler(__rpc_handler_1465863873));
		NetworkManager.__rpc_func_table.Add(835120159u, new RpcReceiveHandler(__rpc_handler_835120159));
	}

	private static void __rpc_handler_622177509(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BeltBagItem)(object)target).GrabItemInBagServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2703921983(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BeltBagItem)(object)target).GrabItemInBagClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2988305002(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference netObjectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
			int playerWhoAdded = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoAdded);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BeltBagItem)(object)target).TryAddObjectToBagServerRpc(netObjectRef, playerWhoAdded);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3900201301(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference netObjectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
			int playerWhoAdded = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoAdded);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BeltBagItem)(object)target).TryAddObjectToBagClientRpc(netObjectRef, playerWhoAdded);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1076504254(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoAdded = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoAdded);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BeltBagItem)(object)target).CancelAddObjectToBagClientRpc(playerWhoAdded);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4159001947(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			bool setInElevator = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setInElevator, default(ForPrimitives));
			bool setInShip = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setInShip, default(ForPrimitives));
			Vector3 targetPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetPosition);
			int playerWhoRemoved = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoRemoved);
			bool inFactory = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inFactory, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BeltBagItem)(object)target).RemoveFromBagServerRpc(objectRef, setInElevator, setInShip, targetPosition, playerWhoRemoved, inFactory);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1949909770(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			bool setInElevator = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setInElevator, default(ForPrimitives));
			bool setInShip = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setInShip, default(ForPrimitives));
			Vector3 targetPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetPosition);
			int playerWhoRemoved = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoRemoved);
			bool inFactory = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inFactory, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BeltBagItem)(object)target).RemoveFromBagClientRpc(objectRef, setInElevator, setInShip, targetPosition, playerWhoRemoved, inFactory);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1618346907(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			NetworkObjectReference nonElevatorParent = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref nonElevatorParent, default(ForNetworkSerializable));
			Vector3 targetPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetPosition);
			int playerWhoRemoved = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoRemoved);
			bool inFactory = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inFactory, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BeltBagItem)(object)target).RemoveFromBagNonElevatorParentServerRpc(objectRef, nonElevatorParent, targetPosition, playerWhoRemoved, inFactory);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2809290913(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			NetworkObjectReference nonElevatorParent = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref nonElevatorParent, default(ForNetworkSerializable));
			Vector3 targetPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetPosition);
			int playerWhoRemoved = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoRemoved);
			bool inFactory = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inFactory, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BeltBagItem)(object)target).RemoveFromBagNonElevatorParentClientRpc(objectRef, nonElevatorParent, targetPosition, playerWhoRemoved, inFactory);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4205663608(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BeltBagItem)(object)target).TryCheckingBagServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1562839591(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BeltBagItem)(object)target).ConfirmCheckingBagClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1006051133(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BeltBagItem)(object)target).StopCheckingBagServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1465863873(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BeltBagItem)(object)target).StopCheckingBagClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_835120159(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BeltBagItem)(object)target).DenyCheckingBagClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "BeltBagItem";
	}
}
