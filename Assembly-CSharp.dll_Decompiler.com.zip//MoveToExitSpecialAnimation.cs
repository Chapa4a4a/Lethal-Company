using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;

public class MoveToExitSpecialAnimation : NetworkBehaviour
{
	public InteractTrigger interactTrigger;

	public InteractTrigger strapsInteractTrigger;

	public AnimatedObjectTrigger animatedObjectTrigger;

	private float timeSinceAnimationStarted;

	private bool listeningForInput;

	public bool exitingDisabled;

	[Header("Electric chair variables")]
	public bool electricChair;

	private Coroutine shockChairCoroutine;

	public ParticleSystem shockChairParticle;

	public AudioSource shockChairSound;

	private void OnEnable()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Expected O, but got Unknown
		if (electricChair)
		{
			((UnityEvent)StartOfRound.Instance.ShipPowerSurgedEvent).AddListener(new UnityAction(OnShipPowerSurge));
		}
	}

	private void OnDisable()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Expected O, but got Unknown
		if (electricChair)
		{
			((UnityEvent)StartOfRound.Instance.ShipPowerSurgedEvent).RemoveListener(new UnityAction(OnShipPowerSurge));
		}
	}

	private void OnShipPowerSurge()
	{
		if (shockChairCoroutine == null)
		{
			shockChairCoroutine = ((MonoBehaviour)this).StartCoroutine(shockChair());
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PowerSurgeChairServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2269800271u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2269800271u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PowerSurgeChairClientRpc();
			}
		}
	}

	[ClientRpc]
	public void PowerSurgeChairClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1254697919u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1254697919u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				OnShipPowerSurge();
			}
		}
	}

	private IEnumerator shockChair()
	{
		shockChairParticle.Play(true);
		shockChairSound.Play();
		strapsInteractTrigger.interactable = false;
		if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).gameObject.transform.position) < 8f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.VeryStrong);
		}
		else if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).gameObject.transform.position) < 14f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
		}
		for (int i = 0; i < 11; i++)
		{
			if ((Object)(object)interactTrigger.lockedPlayer != (Object)null)
			{
				((Component)interactTrigger.lockedPlayer).GetComponent<PlayerControllerB>().DamagePlayer(10, hasDamageSFX: true, callRPC: true, CauseOfDeath.Electrocution, 3);
			}
			yield return (object)new WaitForSeconds(0.3f);
			if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).gameObject.transform.position) < 14f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
			}
		}
		yield return (object)new WaitForSeconds(0.7f);
		shockChairParticle.Stop(true, (ParticleSystemStopBehavior)1);
		shockChairSound.Stop();
		strapsInteractTrigger.interactable = true;
		yield return (object)new WaitForSeconds(0.5f);
		shockChairCoroutine = null;
	}

	public void SetExitingDisabled(bool disabled)
	{
		exitingDisabled = disabled;
		interactTrigger.interactable = !disabled;
	}

	public void Update()
	{
		if (interactTrigger.isPlayingSpecialAnimation && (Object)(object)interactTrigger.lockedPlayer != (Object)null && (Object)(object)interactTrigger.lockedPlayer == (Object)(object)((Component)GameNetworkManager.Instance.localPlayerController).transform)
		{
			if (!listeningForInput)
			{
				timeSinceAnimationStarted += Time.deltaTime;
				if (timeSinceAnimationStarted > 1f)
				{
					timeSinceAnimationStarted = 0f;
					((UnityEvent<PlayerControllerB>)StartOfRound.Instance.PlayerMoveInputEvent).AddListener((UnityAction<PlayerControllerB>)OnMoveInputDetected);
					listeningForInput = true;
				}
			}
		}
		else if (listeningForInput)
		{
			listeningForInput = false;
			((UnityEvent<PlayerControllerB>)StartOfRound.Instance.PlayerMoveInputEvent).RemoveListener((UnityAction<PlayerControllerB>)OnMoveInputDetected);
			if (animatedObjectTrigger.boolValue)
			{
				animatedObjectTrigger.TriggerAnimation(GameNetworkManager.Instance.localPlayerController);
			}
			timeSinceAnimationStarted = 0f;
		}
	}

	public void OnMoveInputDetected(PlayerControllerB playerWhoMoved)
	{
		Debug.Log((object)"Sofa chair detecting movement");
		if (!exitingDisabled && !((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)(object)playerWhoMoved) && interactTrigger.isPlayingSpecialAnimation && (Object)(object)interactTrigger.lockedPlayer != (Object)null && (Object)(object)interactTrigger.lockedPlayer == (Object)(object)((Component)GameNetworkManager.Instance.localPlayerController).transform)
		{
			interactTrigger.CancelAnimationExternally();
			listeningForInput = false;
			((UnityEvent<PlayerControllerB>)StartOfRound.Instance.PlayerMoveInputEvent).RemoveListener((UnityAction<PlayerControllerB>)OnMoveInputDetected);
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_MoveToExitSpecialAnimation()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2269800271u, new RpcReceiveHandler(__rpc_handler_2269800271));
		NetworkManager.__rpc_func_table.Add(1254697919u, new RpcReceiveHandler(__rpc_handler_1254697919));
	}

	private static void __rpc_handler_2269800271(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MoveToExitSpecialAnimation)(object)target).PowerSurgeChairServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1254697919(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MoveToExitSpecialAnimation)(object)target).PowerSurgeChairClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "MoveToExitSpecialAnimation";
	}
}
