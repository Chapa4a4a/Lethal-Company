public enum HoarderBugItemStatus
{
	Any = -1,
	Owned,
	Stolen,
	Returned
}
