using System;
using System.Collections.Generic;
using System.Linq;
using Unity.AI.Navigation;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Tilemaps;

namespace DunGen.Adapters;

[AddComponentMenu("DunGen/NavMesh/Unity NavMesh Adapter (2D)")]
public class UnityNavMesh2DAdapter : NavMeshAdapter
{
	[Serializable]
	public sealed class NavMeshAgentLinkInfo
	{
		public int AgentTypeID;

		public int AreaTypeID;

		public bool DisableLinkWhenDoorIsClosed = true;
	}

	private static Quaternion rotation = Quaternion.Euler(-90f, 0f, 0f);

	public bool AddNavMeshLinksBetweenRooms = true;

	public List<NavMeshAgentLinkInfo> NavMeshAgentTypes = new List<NavMeshAgentLinkInfo>
	{
		new NavMeshAgentLinkInfo()
	};

	public float NavMeshLinkDistanceFromDoorway = 1f;

	[SerializeField]
	private int agentTypeID;

	[SerializeField]
	private bool overrideTileSize;

	[SerializeField]
	private int tileSize = 256;

	[SerializeField]
	private bool overrideVoxelSize;

	[SerializeField]
	private float voxelSize;

	[SerializeField]
	private NavMeshData navMeshData;

	[SerializeField]
	private LayerMask layerMask = LayerMask.op_Implicit(-1);

	[SerializeField]
	private int defaultArea;

	[SerializeField]
	private bool ignoreNavMeshAgent = true;

	[SerializeField]
	private bool ignoreNavMeshObstacle = true;

	[SerializeField]
	private int unwalkableArea = 1;

	private NavMeshDataInstance m_NavMeshDataInstance;

	private Dictionary<Sprite, Mesh> cachedSpriteMeshes = new Dictionary<Sprite, Mesh>();

	public int AgentTypeID
	{
		get
		{
			return agentTypeID;
		}
		set
		{
			agentTypeID = value;
		}
	}

	public bool OverrideTileSize
	{
		get
		{
			return overrideTileSize;
		}
		set
		{
			overrideTileSize = value;
		}
	}

	public int TileSize
	{
		get
		{
			return tileSize;
		}
		set
		{
			tileSize = value;
		}
	}

	public bool OverrideVoxelSize
	{
		get
		{
			return overrideVoxelSize;
		}
		set
		{
			overrideVoxelSize = value;
		}
	}

	public float VoxelSize
	{
		get
		{
			return voxelSize;
		}
		set
		{
			voxelSize = value;
		}
	}

	public NavMeshData NavMeshData
	{
		get
		{
			return navMeshData;
		}
		set
		{
			navMeshData = value;
		}
	}

	public LayerMask LayerMask
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return layerMask;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			layerMask = value;
		}
	}

	public int DefaultArea
	{
		get
		{
			return defaultArea;
		}
		set
		{
			defaultArea = value;
		}
	}

	public bool IgnoreNavMeshAgent
	{
		get
		{
			return ignoreNavMeshAgent;
		}
		set
		{
			ignoreNavMeshAgent = value;
		}
	}

	public bool IgnoreNavMeshObstacle
	{
		get
		{
			return ignoreNavMeshObstacle;
		}
		set
		{
			ignoreNavMeshObstacle = value;
		}
	}

	public int UnwalkableArea
	{
		get
		{
			return unwalkableArea;
		}
		set
		{
			unwalkableArea = value;
		}
	}

	public override void Generate(Dungeon dungeon)
	{
		BakeNavMesh(dungeon);
		if (AddNavMeshLinksBetweenRooms)
		{
			foreach (DoorwayConnection connection in dungeon.Connections)
			{
				foreach (NavMeshAgentLinkInfo navMeshAgentType in NavMeshAgentTypes)
				{
					AddNavMeshLink(connection, navMeshAgentType);
				}
			}
		}
		if (OnProgress != null)
		{
			OnProgress(new NavMeshGenerationProgress
			{
				Description = "Done",
				Percentage = 1f
			});
		}
	}

	protected void AddData()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		if (!((NavMeshDataInstance)(ref m_NavMeshDataInstance)).valid && (Object)(object)navMeshData != (Object)null)
		{
			m_NavMeshDataInstance = NavMesh.AddNavMeshData(navMeshData, ((Component)this).transform.position, rotation);
			((NavMeshDataInstance)(ref m_NavMeshDataInstance)).owner = (Object)(object)this;
		}
	}

	protected void RemoveData()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		((NavMeshDataInstance)(ref m_NavMeshDataInstance)).Remove();
		m_NavMeshDataInstance = default(NavMeshDataInstance);
		foreach (KeyValuePair<Sprite, Mesh> cachedSpriteMesh in cachedSpriteMeshes)
		{
			Object.DestroyImmediate((Object)(object)cachedSpriteMesh.Value);
		}
		cachedSpriteMeshes.Clear();
	}

	protected virtual void BakeNavMesh(Dungeon dungeon)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		List<NavMeshBuildSource> list = CollectSources();
		Bounds val = CalculateWorldBounds(list);
		NavMeshData val2 = NavMeshBuilder.BuildNavMeshData(GetBuildSettings(), list, val, ((Component)this).transform.position, rotation);
		if ((Object)(object)val2 != (Object)null)
		{
			((Object)val2).name = ((Object)((Component)this).gameObject).name;
			RemoveData();
			navMeshData = val2;
			if (((Behaviour)this).isActiveAndEnabled)
			{
				AddData();
			}
		}
		if (OnProgress != null)
		{
			OnProgress(new NavMeshGenerationProgress
			{
				Description = "Done",
				Percentage = 1f
			});
		}
	}

	protected void AppendModifierVolumes(ref List<NavMeshBuildSource> sources)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		List<NavMeshModifierVolume> list = new List<NavMeshModifierVolume>(((Component)this).GetComponentsInChildren<NavMeshModifierVolume>());
		list.RemoveAll((NavMeshModifierVolume x) => !((Behaviour)x).isActiveAndEnabled);
		Vector3 size = default(Vector3);
		foreach (NavMeshModifierVolume item2 in list)
		{
			if ((LayerMask.op_Implicit(layerMask) & (1 << ((Component)item2).gameObject.layer)) != 0 && item2.AffectsAgentType(agentTypeID))
			{
				Vector3 val = ((Component)item2).transform.TransformPoint(item2.center);
				Vector3 lossyScale = ((Component)item2).transform.lossyScale;
				((Vector3)(ref size))._002Ector(item2.size.x * Mathf.Abs(lossyScale.x), item2.size.y * Mathf.Abs(lossyScale.y), item2.size.z * Mathf.Abs(lossyScale.z));
				NavMeshBuildSource item = default(NavMeshBuildSource);
				((NavMeshBuildSource)(ref item)).shape = (NavMeshBuildSourceShape)5;
				((NavMeshBuildSource)(ref item)).transform = Matrix4x4.TRS(val, ((Component)item2).transform.rotation, Vector3.one);
				((NavMeshBuildSource)(ref item)).size = size;
				((NavMeshBuildSource)(ref item)).area = item2.area;
				sources.Add(item);
			}
		}
	}

	protected virtual List<NavMeshBuildSource> CollectSources()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_030b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		List<NavMeshBuildSource> sources = new List<NavMeshBuildSource>();
		List<NavMeshBuildMarkup> list = new List<NavMeshBuildMarkup>();
		List<NavMeshModifier> list2 = new List<NavMeshModifier>(((Component)this).GetComponentsInChildren<NavMeshModifier>());
		list2.RemoveAll((NavMeshModifier x) => !((Behaviour)x).isActiveAndEnabled);
		foreach (NavMeshModifier item3 in list2)
		{
			if ((LayerMask.op_Implicit(layerMask) & (1 << ((Component)item3).gameObject.layer)) != 0 && item3.AffectsAgentType(agentTypeID))
			{
				NavMeshBuildMarkup item = default(NavMeshBuildMarkup);
				((NavMeshBuildMarkup)(ref item)).root = ((Component)item3).transform;
				((NavMeshBuildMarkup)(ref item)).overrideArea = item3.overrideArea;
				((NavMeshBuildMarkup)(ref item)).area = item3.area;
				((NavMeshBuildMarkup)(ref item)).ignoreFromBuild = item3.ignoreFromBuild;
				list.Add(item);
			}
		}
		SpriteRenderer[] array = Object.FindObjectsOfType<SpriteRenderer>();
		NavMeshBuildSource val2;
		foreach (SpriteRenderer val in array)
		{
			Sprite sprite = val.sprite;
			Mesh mesh = GetMesh(sprite);
			if ((Object)(object)mesh != (Object)null)
			{
				int area = (((LayerMask.op_Implicit(layerMask) & (1 << ((Component)val).gameObject.layer)) == 0) ? unwalkableArea : 0);
				List<NavMeshBuildSource> list3 = sources;
				val2 = default(NavMeshBuildSource);
				((NavMeshBuildSource)(ref val2)).transform = ((Component)val).transform.localToWorldMatrix;
				Bounds bounds = mesh.bounds;
				((NavMeshBuildSource)(ref val2)).size = ((Bounds)(ref bounds)).extents * 2f;
				((NavMeshBuildSource)(ref val2)).shape = (NavMeshBuildSourceShape)0;
				((NavMeshBuildSource)(ref val2)).area = area;
				((NavMeshBuildSource)(ref val2)).sourceObject = (Object)(object)mesh;
				((NavMeshBuildSource)(ref val2)).component = (Component)(object)val;
				list3.Add(val2);
			}
		}
		val2 = default(NavMeshBuildSource);
		((NavMeshBuildSource)(ref val2)).shape = (NavMeshBuildSourceShape)0;
		((NavMeshBuildSource)(ref val2)).area = 0;
		NavMeshBuildSource item2 = val2;
		Tilemap[] array2 = Object.FindObjectsOfType<Tilemap>();
		Vector3Int val4 = default(Vector3Int);
		foreach (Tilemap val3 in array2)
		{
			BoundsInt cellBounds = val3.cellBounds;
			int num = ((BoundsInt)(ref cellBounds)).xMin;
			while (true)
			{
				int num2 = num;
				cellBounds = val3.cellBounds;
				if (num2 >= ((BoundsInt)(ref cellBounds)).xMax)
				{
					break;
				}
				cellBounds = val3.cellBounds;
				int num3 = ((BoundsInt)(ref cellBounds)).yMin;
				while (true)
				{
					int num4 = num3;
					cellBounds = val3.cellBounds;
					if (num4 >= ((BoundsInt)(ref cellBounds)).yMax)
					{
						break;
					}
					((Vector3Int)(ref val4))._002Ector(num, num3, 0);
					if (val3.HasTile(val4))
					{
						Tile tile = val3.GetTile<Tile>(val4);
						Mesh mesh2 = GetMesh(val3.GetSprite(val4));
						if ((Object)(object)mesh2 != (Object)null)
						{
							((NavMeshBuildSource)(ref item2)).transform = Matrix4x4.TRS(val3.GetCellCenterWorld(val4) - val3.layoutGrid.cellGap, ((Component)val3).transform.rotation, ((Component)val3).transform.lossyScale) * val3.orientationMatrix * val3.GetTransformMatrix(val4);
							((NavMeshBuildSource)(ref item2)).sourceObject = (Object)(object)mesh2;
							((NavMeshBuildSource)(ref item2)).component = (Component)(object)val3;
							((NavMeshBuildSource)(ref item2)).area = (((int)tile.colliderType != 0) ? unwalkableArea : 0);
							sources.Add(item2);
						}
					}
					num3++;
				}
				num++;
			}
		}
		if (ignoreNavMeshAgent)
		{
			sources.RemoveAll((NavMeshBuildSource x) => (Object)(object)((NavMeshBuildSource)(ref x)).component != (Object)null && (Object)(object)((NavMeshBuildSource)(ref x)).component.gameObject.GetComponent<NavMeshAgent>() != (Object)null);
		}
		if (ignoreNavMeshObstacle)
		{
			sources.RemoveAll((NavMeshBuildSource x) => (Object)(object)((NavMeshBuildSource)(ref x)).component != (Object)null && (Object)(object)((NavMeshBuildSource)(ref x)).component.gameObject.GetComponent<NavMeshObstacle>() != (Object)null);
		}
		AppendModifierVolumes(ref sources);
		return sources;
	}

	protected Mesh GetMesh(Sprite sprite)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Expected O, but got Unknown
		if ((Object)(object)sprite == (Object)null)
		{
			return null;
		}
		if (!cachedSpriteMeshes.TryGetValue(sprite, out var value))
		{
			value = new Mesh
			{
				vertices = ((IEnumerable<Vector2>)sprite.vertices).Select((Func<Vector2, Vector3>)((Vector2 v) => new Vector3(v.x, v.y, 0f))).ToArray(),
				triangles = ((IEnumerable<ushort>)sprite.triangles).Select((Func<ushort, int>)((ushort i) => i)).ToArray()
			};
			value.RecalculateBounds();
			value.RecalculateNormals();
			value.RecalculateTangents();
			cachedSpriteMeshes[sprite] = value;
		}
		return value;
	}

	protected void AddNavMeshLink(DoorwayConnection connection, NavMeshAgentLinkInfo agentLinkInfo)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		GameObject gameObject = ((Component)connection.A).gameObject;
		NavMeshBuildSettings settingsByID = NavMesh.GetSettingsByID(agentLinkInfo.AgentTypeID);
		float width = Mathf.Max(connection.A.Socket.Size.x - ((NavMeshBuildSettings)(ref settingsByID)).agentRadius * 2f, 0.01f);
		NavMeshLink link = gameObject.AddComponent<NavMeshLink>();
		link.agentTypeID = agentLinkInfo.AgentTypeID;
		link.bidirectional = true;
		link.area = agentLinkInfo.AreaTypeID;
		link.startPoint = new Vector3(0f, 0f, 0f - NavMeshLinkDistanceFromDoorway);
		link.endPoint = new Vector3(0f, 0f, NavMeshLinkDistanceFromDoorway);
		link.width = width;
		if (!agentLinkInfo.DisableLinkWhenDoorIsClosed)
		{
			return;
		}
		GameObject val = (((Object)(object)connection.A.UsedDoorPrefabInstance != (Object)null) ? connection.A.UsedDoorPrefabInstance : (((Object)(object)connection.B.UsedDoorPrefabInstance != (Object)null) ? connection.B.UsedDoorPrefabInstance : null));
		if (!((Object)(object)val != (Object)null))
		{
			return;
		}
		Door component = val.GetComponent<Door>();
		((Behaviour)link).enabled = component.IsOpen;
		if ((Object)(object)component != (Object)null)
		{
			component.OnDoorStateChanged += delegate(Door d, bool o)
			{
				((Behaviour)link).enabled = o;
			};
		}
	}

	public NavMeshBuildSettings GetBuildSettings()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		NavMeshBuildSettings settingsByID = NavMesh.GetSettingsByID(agentTypeID);
		if (((NavMeshBuildSettings)(ref settingsByID)).agentTypeID == -1)
		{
			Debug.LogWarning((object)("No build settings for agent type ID " + AgentTypeID), (Object)(object)this);
			((NavMeshBuildSettings)(ref settingsByID)).agentTypeID = agentTypeID;
		}
		if (OverrideTileSize)
		{
			((NavMeshBuildSettings)(ref settingsByID)).overrideTileSize = true;
			((NavMeshBuildSettings)(ref settingsByID)).tileSize = TileSize;
		}
		if (OverrideVoxelSize)
		{
			((NavMeshBuildSettings)(ref settingsByID)).overrideVoxelSize = true;
			((NavMeshBuildSettings)(ref settingsByID)).voxelSize = VoxelSize;
		}
		return settingsByID;
	}

	protected Bounds CalculateWorldBounds(List<NavMeshBuildSource> sources)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Expected I4, but got Unknown
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		Matrix4x4 val = Matrix4x4.TRS(((Component)this).transform.position, rotation, Vector3.one);
		val = ((Matrix4x4)(ref val)).inverse;
		Bounds result = default(Bounds);
		foreach (NavMeshBuildSource source in sources)
		{
			NavMeshBuildSource current = source;
			NavMeshBuildSourceShape shape = ((NavMeshBuildSource)(ref current)).shape;
			switch ((int)shape)
			{
			case 0:
			{
				Object sourceObject2 = ((NavMeshBuildSource)(ref current)).sourceObject;
				Mesh val3 = (Mesh)(object)((sourceObject2 is Mesh) ? sourceObject2 : null);
				((Bounds)(ref result)).Encapsulate(GetWorldBounds(val * ((NavMeshBuildSource)(ref current)).transform, val3.bounds));
				break;
			}
			case 1:
			{
				Object sourceObject = ((NavMeshBuildSource)(ref current)).sourceObject;
				TerrainData val2 = (TerrainData)(object)((sourceObject is TerrainData) ? sourceObject : null);
				((Bounds)(ref result)).Encapsulate(GetWorldBounds(val * ((NavMeshBuildSource)(ref current)).transform, new Bounds(0.5f * val2.size, val2.size)));
				break;
			}
			case 2:
			case 3:
			case 4:
			case 5:
				((Bounds)(ref result)).Encapsulate(GetWorldBounds(val * ((NavMeshBuildSource)(ref current)).transform, new Bounds(Vector3.zero, ((NavMeshBuildSource)(ref current)).size)));
				break;
			}
		}
		((Bounds)(ref result)).Expand(0.1f);
		return result;
	}

	private static Vector3 Abs(Vector3 v)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		return new Vector3(Mathf.Abs(v.x), Mathf.Abs(v.y), Mathf.Abs(v.z));
	}

	private static Bounds GetWorldBounds(Matrix4x4 mat, Bounds bounds)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Abs(((Matrix4x4)(ref mat)).MultiplyVector(Vector3.right));
		Vector3 val2 = Abs(((Matrix4x4)(ref mat)).MultiplyVector(Vector3.up));
		Vector3 val3 = Abs(((Matrix4x4)(ref mat)).MultiplyVector(Vector3.forward));
		Vector3 val4 = ((Matrix4x4)(ref mat)).MultiplyPoint(((Bounds)(ref bounds)).center);
		Vector3 val5 = val * ((Bounds)(ref bounds)).size.x + val2 * ((Bounds)(ref bounds)).size.y + val3 * ((Bounds)(ref bounds)).size.z;
		return new Bounds(val4, val5);
	}
}
