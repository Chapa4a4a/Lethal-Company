using System;
using System.Collections.Generic;
using System.Linq;
using Unity.AI.Navigation;
using UnityEngine;
using UnityEngine.AI;

namespace DunGen.Adapters;

[AddComponentMenu("DunGen/NavMesh/Unity NavMesh Adapter")]
public class UnityNavMeshAdapter : NavMeshAdapter
{
	public enum RuntimeNavMeshBakeMode
	{
		PreBakedOnly,
		AddIfNoSurfaceExists,
		AlwaysRebake,
		FullDungeonBake
	}

	[Serializable]
	public sealed class NavMeshAgentLinkInfo
	{
		public int AgentTypeID;

		public int AreaTypeID;

		public bool DisableLinkWhenDoorIsClosed = true;
	}

	public RuntimeNavMeshBakeMode BakeMode = RuntimeNavMeshBakeMode.AddIfNoSurfaceExists;

	public LayerMask LayerMask = LayerMask.op_Implicit(-1);

	public bool AddNavMeshLinksBetweenRooms = true;

	public List<NavMeshAgentLinkInfo> NavMeshAgentTypes = new List<NavMeshAgentLinkInfo>
	{
		new NavMeshAgentLinkInfo()
	};

	public float NavMeshLinkDistanceFromDoorway = 2.5f;

	public bool AutoGenerateFullRebakeSurfaces = true;

	public List<NavMeshSurface> FullRebakeTargets = new List<NavMeshSurface>();

	private List<NavMeshSurface> addedSurfaces = new List<NavMeshSurface>();

	private List<NavMeshSurface> fullBakeSurfaces = new List<NavMeshSurface>();

	public override void Generate(Dungeon dungeon)
	{
		if (BakeMode == RuntimeNavMeshBakeMode.FullDungeonBake)
		{
			BakeFullDungeon(dungeon);
			return;
		}
		if (BakeMode != 0)
		{
			foreach (Tile allTile in dungeon.AllTiles)
			{
				NavMeshSurface[] componentsInChildren = ((Component)allTile).gameObject.GetComponentsInChildren<NavMeshSurface>();
				IEnumerable<NavMeshSurface> enumerable = AddMissingSurfaces(allTile, componentsInChildren);
				if (BakeMode == RuntimeNavMeshBakeMode.AlwaysRebake)
				{
					enumerable = enumerable.Concat(componentsInChildren);
				}
				else if (BakeMode == RuntimeNavMeshBakeMode.AddIfNoSurfaceExists)
				{
					IEnumerable<NavMeshSurface> second = componentsInChildren.Where((NavMeshSurface x) => (Object)(object)x.navMeshData == (Object)null);
					enumerable = enumerable.Concat(second);
				}
				foreach (NavMeshSurface item in enumerable.Distinct())
				{
					item.BuildNavMesh();
				}
			}
		}
		if (AddNavMeshLinksBetweenRooms)
		{
			foreach (DoorwayConnection connection in dungeon.Connections)
			{
				foreach (NavMeshAgentLinkInfo navMeshAgentType in NavMeshAgentTypes)
				{
					AddNavMeshLink(connection, navMeshAgentType);
				}
			}
		}
		if (OnProgress != null)
		{
			OnProgress(new NavMeshGenerationProgress
			{
				Description = "Done",
				Percentage = 1f
			});
		}
	}

	private void BakeFullDungeon(Dungeon dungeon)
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		if (AutoGenerateFullRebakeSurfaces)
		{
			foreach (NavMeshSurface fullBakeSurface in fullBakeSurfaces)
			{
				if ((Object)(object)fullBakeSurface != (Object)null)
				{
					fullBakeSurface.RemoveData();
				}
			}
			fullBakeSurfaces.Clear();
			int settingsCount = NavMesh.GetSettingsCount();
			for (int i = 0; i < settingsCount; i++)
			{
				NavMeshBuildSettings settings = NavMesh.GetSettingsByIndex(i);
				NavMeshSurface val = (from s in ((Component)dungeon).gameObject.GetComponents<NavMeshSurface>()
					where s.agentTypeID == ((NavMeshBuildSettings)(ref settings)).agentTypeID
					select s).FirstOrDefault();
				if ((Object)(object)val == (Object)null)
				{
					val = ((Component)dungeon).gameObject.AddComponent<NavMeshSurface>();
					val.agentTypeID = ((NavMeshBuildSettings)(ref settings)).agentTypeID;
					val.collectObjects = (CollectObjects)2;
					val.layerMask = LayerMask;
				}
				fullBakeSurfaces.Add(val);
				val.BuildNavMesh();
			}
		}
		else
		{
			foreach (NavMeshSurface fullRebakeTarget in FullRebakeTargets)
			{
				fullRebakeTarget.BuildNavMesh();
			}
		}
		if (OnProgress != null)
		{
			OnProgress(new NavMeshGenerationProgress
			{
				Description = "Done",
				Percentage = 1f
			});
		}
	}

	private NavMeshSurface[] AddMissingSurfaces(Tile tile, NavMeshSurface[] existingSurfaces)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		addedSurfaces.Clear();
		int settingsCount = NavMesh.GetSettingsCount();
		for (int i = 0; i < settingsCount; i++)
		{
			NavMeshBuildSettings settings = NavMesh.GetSettingsByIndex(i);
			if (!existingSurfaces.Where((NavMeshSurface x) => x.agentTypeID == ((NavMeshBuildSettings)(ref settings)).agentTypeID).Any())
			{
				NavMeshSurface val = ((Component)tile).gameObject.AddComponent<NavMeshSurface>();
				val.agentTypeID = ((NavMeshBuildSettings)(ref settings)).agentTypeID;
				val.collectObjects = (CollectObjects)2;
				val.layerMask = LayerMask;
				addedSurfaces.Add(val);
			}
		}
		return addedSurfaces.ToArray();
	}

	private void AddNavMeshLink(DoorwayConnection connection, NavMeshAgentLinkInfo agentLinkInfo)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		GameObject gameObject = ((Component)connection.A).gameObject;
		NavMeshBuildSettings settingsByID = NavMesh.GetSettingsByID(agentLinkInfo.AgentTypeID);
		float width = Mathf.Max(connection.A.Socket.Size.x - ((NavMeshBuildSettings)(ref settingsByID)).agentRadius * 2f, 0.01f);
		NavMeshLink link = gameObject.AddComponent<NavMeshLink>();
		link.agentTypeID = agentLinkInfo.AgentTypeID;
		link.bidirectional = true;
		link.area = agentLinkInfo.AreaTypeID;
		link.startPoint = new Vector3(0f, 0f, 0f - NavMeshLinkDistanceFromDoorway);
		link.endPoint = new Vector3(0f, 0f, NavMeshLinkDistanceFromDoorway);
		link.width = width;
		if (!agentLinkInfo.DisableLinkWhenDoorIsClosed)
		{
			return;
		}
		GameObject val = (((Object)(object)connection.A.UsedDoorPrefabInstance != (Object)null) ? connection.A.UsedDoorPrefabInstance : (((Object)(object)connection.B.UsedDoorPrefabInstance != (Object)null) ? connection.B.UsedDoorPrefabInstance : null));
		if (!((Object)(object)val != (Object)null))
		{
			return;
		}
		Door component = val.GetComponent<Door>();
		((Behaviour)link).enabled = component.IsOpen;
		if ((Object)(object)component != (Object)null)
		{
			component.OnDoorStateChanged += delegate(Door d, bool o)
			{
				((Behaviour)link).enabled = o;
			};
		}
	}
}
