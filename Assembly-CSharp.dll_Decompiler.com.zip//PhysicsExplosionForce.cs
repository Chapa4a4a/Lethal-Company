using UnityEngine;

public class PhysicsExplosionForce : MonoBehaviour
{
	private Rigidbody[] bodyParts;

	private void Start()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		bodyParts = ((Component)this).GetComponentsInChildren<Rigidbody>();
		for (int i = 0; i < bodyParts.Length; i++)
		{
			((Component)bodyParts[i]).GetComponent<Rigidbody>().AddExplosionForce(35000f, ((Component)this).transform.parent.position, 100f);
		}
	}

	private void Update()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < bodyParts.Length; i++)
		{
			if (!((Object)(object)bodyParts[i] == (Object)null) && ((Component)bodyParts[i]).transform.position.y < -200f)
			{
				Object.Destroy((Object)(object)((Component)this).gameObject);
				break;
			}
		}
	}
}
