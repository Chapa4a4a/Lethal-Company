public enum CompanyMonster
{
	GiantHand,
	Tentacles,
	Tongue
}
