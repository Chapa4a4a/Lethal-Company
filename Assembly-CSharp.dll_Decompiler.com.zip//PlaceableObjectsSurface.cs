using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class PlaceableObjectsSurface : NetworkBehaviour
{
	public NetworkObject parentTo;

	public Collider placeableBounds;

	public InteractTrigger triggerScript;

	private float checkHoverTipInterval;

	private void Update()
	{
		if ((Object)(object)GameNetworkManager.Instance != (Object)null && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
		{
			triggerScript.interactable = GameNetworkManager.Instance.localPlayerController.isHoldingObject;
		}
	}

	public void PlaceObject(PlayerControllerB playerWhoTriggered)
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (playerWhoTriggered.isHoldingObject && !playerWhoTriggered.isGrabbingObjectAnimation && (Object)(object)playerWhoTriggered.currentlyHeldObjectServer != (Object)null)
		{
			Debug.Log((object)"Placing object in storage; asking server for verification");
			if (!(itemPlacementPosition(((Component)playerWhoTriggered.gameplayCamera).transform, playerWhoTriggered.currentlyHeldObjectServer) == Vector3.zero))
			{
				CheckIfFurnitureIsAvailableForPlacingServerRpc((int)playerWhoTriggered.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void CheckIfFurnitureIsAvailableForPlacingServerRpc(int playerWhoTriggered)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2624827950u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2624827950u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && parentTo.IsSpawned)
		{
			PlaceableShipObject componentInChildren = ((Component)parentTo).gameObject.GetComponentInChildren<PlaceableShipObject>();
			if ((Object)(object)componentInChildren != (Object)null)
			{
				componentInChildren.lastTimeScrapWasPlaced = Time.realtimeSinceStartup;
			}
			ConfirmPlaceOnFurnitureClientRpc(playerWhoTriggered);
		}
	}

	[ClientRpc]
	public void ConfirmPlaceOnFurnitureClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3757423328u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3757423328u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerId)
		{
			return;
		}
		PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
		if (!localPlayerController.isHoldingObject || localPlayerController.isGrabbingObjectAnimation || !((Object)(object)localPlayerController.currentlyHeldObjectServer != (Object)null))
		{
			return;
		}
		Debug.Log((object)"Placing object in storage");
		Vector3 val3 = itemPlacementPosition(((Component)localPlayerController.gameplayCamera).transform, localPlayerController.currentlyHeldObjectServer);
		if (!(val3 == Vector3.zero))
		{
			if ((Object)(object)parentTo != (Object)null)
			{
				val3 = ((Component)parentTo).transform.InverseTransformPoint(val3);
			}
			localPlayerController.DiscardHeldObject(placeObject: true, parentTo, val3, matchRotationOfParent: false);
			Debug.Log((object)"discard held object called from placeobject");
		}
	}

	private Vector3 itemPlacementPosition(Transform gameplayCamera, GrabbableObject heldObject)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val = default(RaycastHit);
		if (Physics.Raycast(gameplayCamera.position, gameplayCamera.forward, ref val, 7f, 1073744640, (QueryTriggerInteraction)1))
		{
			if (placeableBounds.ClosestPoint(((RaycastHit)(ref val)).point) == ((RaycastHit)(ref val)).point)
			{
				Debug.DrawLine(((RaycastHit)(ref val)).point, ((RaycastHit)(ref val)).point + ((Component)placeableBounds).transform.up * heldObject.itemProperties.verticalOffset, Color.red, 10f);
				return ((RaycastHit)(ref val)).point + ((Component)placeableBounds).transform.up * heldObject.itemProperties.verticalOffset;
			}
			Debug.DrawLine(placeableBounds.ClosestPoint(((RaycastHit)(ref val)).point), placeableBounds.ClosestPoint(((RaycastHit)(ref val)).point) + ((Component)placeableBounds).transform.up * heldObject.itemProperties.verticalOffset, Color.green, 10f);
			return placeableBounds.ClosestPoint(((RaycastHit)(ref val)).point) + ((Component)placeableBounds).transform.up * heldObject.itemProperties.verticalOffset;
		}
		return Vector3.zero;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_PlaceableObjectsSurface()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2624827950u, new RpcReceiveHandler(__rpc_handler_2624827950));
		NetworkManager.__rpc_func_table.Add(3757423328u, new RpcReceiveHandler(__rpc_handler_3757423328));
	}

	private static void __rpc_handler_2624827950(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((PlaceableObjectsSurface)(object)target).CheckIfFurnitureIsAvailableForPlacingServerRpc(playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3757423328(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((PlaceableObjectsSurface)(object)target).ConfirmPlaceOnFurnitureClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "PlaceableObjectsSurface";
	}
}
