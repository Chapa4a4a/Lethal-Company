using System.Collections;
using Unity.Netcode;
using UnityEngine;

public class LungProp : GrabbableObject
{
	public bool isLungPowered = true;

	public bool isLungDocked = true;

	public bool isLungDockedInElevator;

	public RoundManager roundManager;

	public GameObject sparkParticle;

	private Coroutine disconnectAnimation;

	public AudioClip connectSFX;

	public AudioClip disconnectSFX;

	public AudioClip removeFromMachineSFX;

	public float lungDeviceLightIntensity;

	public MeshRenderer lungDeviceMesh;

	private Color emissiveColor;

	public EnemyType radMechEnemyType;

	public override void EquipItem()
	{
		Debug.Log((object)$"Lung apparatice was grabbed. Is owner: {((NetworkBehaviour)this).IsOwner}");
		if (isLungDocked)
		{
			isLungDocked = false;
			if (disconnectAnimation != null)
			{
				((MonoBehaviour)this).StopCoroutine(disconnectAnimation);
			}
			disconnectAnimation = ((MonoBehaviour)this).StartCoroutine(DisconnectFromMachinery());
		}
		if (isLungDockedInElevator)
		{
			isLungDockedInElevator = false;
			((Component)this).gameObject.GetComponent<AudioSource>().PlayOneShot(disconnectSFX);
			_ = isLungPowered;
		}
		base.EquipItem();
	}

	private IEnumerator DisconnectFromMachinery()
	{
		GameObject newSparkParticle = Object.Instantiate<GameObject>(sparkParticle, ((Component)this).transform.position, Quaternion.identity, (Transform)null);
		AudioSource thisAudio = ((Component)this).gameObject.GetComponent<AudioSource>();
		thisAudio.Stop();
		thisAudio.PlayOneShot(disconnectSFX, 0.7f);
		yield return (object)new WaitForSeconds(0.1f);
		newSparkParticle.SetActive(true);
		thisAudio.PlayOneShot(removeFromMachineSFX);
		if (((NetworkBehaviour)this).IsServer && Random.Range(0, 100) < 70 && RoundManager.Instance.minEnemiesToSpawn < 2)
		{
			RoundManager.Instance.minEnemiesToSpawn = 2;
		}
		yield return (object)new WaitForSeconds(1f);
		roundManager.FlickerLights();
		yield return (object)new WaitForSeconds(2.5f);
		roundManager.SwitchPower(on: false);
		roundManager.powerOffPermanently = true;
		yield return (object)new WaitForSeconds(0.75f);
		HUDManager.Instance.RadiationWarningHUD();
		if (!((NetworkBehaviour)this).IsServer || (Object)(object)radMechEnemyType == (Object)null)
		{
			yield break;
		}
		EnemyAINestSpawnObject[] array = Object.FindObjectsByType<EnemyAINestSpawnObject>((FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if ((Object)(object)array[i].enemyType == (Object)(object)radMechEnemyType)
			{
				RoundManager.Instance.SpawnEnemyGameObject(RoundManager.Instance.outsideAINodes[0].transform.position, 0f, -1, radMechEnemyType);
			}
		}
	}

	public override void Start()
	{
		base.Start();
		roundManager = Object.FindObjectOfType<RoundManager>();
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "LungProp";
	}
}
