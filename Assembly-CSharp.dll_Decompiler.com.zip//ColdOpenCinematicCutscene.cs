using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class ColdOpenCinematicCutscene : MonoBehaviour
{
	public Camera cam;

	public Transform camContainer;

	public Transform camTarget;

	private InputActionAsset inputAsset;

	public float cameraUp;

	public float maxCameraUp = 40f;

	public float minCameraUp = -60f;

	[Space(5f)]
	public float cameraTurn;

	public float maxCameraTurn = 80f;

	public float minCameraTurn = -80f;

	private float startInputTimer;

	public Animator cameraAnimator;

	public float lookSens = 0.008f;

	private void TurnCamera(Vector2 input)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		input = input * lookSens * (float)IngamePlayerSettings.Instance.settings.lookSensitivity;
		cameraTurn += input.x;
		cameraTurn = Mathf.Clamp(cameraTurn, minCameraTurn, maxCameraTurn);
		cameraUp -= input.y;
		cameraUp = Mathf.Clamp(cameraUp, -60f, 40f);
		((Component)camTarget).transform.localEulerAngles = new Vector3(cameraUp, cameraTurn, ((Component)camTarget).transform.localEulerAngles.z);
		camTarget.eulerAngles = new Vector3(camTarget.eulerAngles.x, camTarget.eulerAngles.y, 0f);
		((Component)camContainer).transform.rotation = Quaternion.Lerp(((Component)camContainer).transform.rotation, camTarget.rotation, 12f * Time.deltaTime);
	}

	public void Start()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		inputAsset = IngamePlayerSettings.Instance.playerInput.actions;
		Cursor.visible = false;
		Cursor.lockState = (CursorLockMode)1;
		cameraTurn = camTarget.localEulerAngles.y;
		AudioListener.volume = Mathf.Max(IngamePlayerSettings.Instance.settings.masterVolume, 0.3f);
	}

	public void Update()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)inputAsset == (Object)null)
		{
			Debug.LogError((object)"Input asset not found!");
			return;
		}
		startInputTimer += Time.deltaTime;
		if (startInputTimer > 0.5f)
		{
			TurnCamera(inputAsset.FindAction("Look", false).ReadValue<Vector2>());
		}
	}

	public void ShakeCameraSmall()
	{
		cameraAnimator.SetTrigger("shake");
	}

	public void ShakeCameraLong()
	{
		cameraAnimator.SetTrigger("vibrateLong");
	}

	public void EndColdOpenCutscene()
	{
		Cursor.visible = true;
		Cursor.lockState = (CursorLockMode)0;
		SceneManager.LoadScene("MainMenu");
	}
}
