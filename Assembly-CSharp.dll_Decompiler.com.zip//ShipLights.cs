using Unity.Netcode;
using UnityEngine;

public class ShipLights : NetworkBehaviour
{
	public bool areLightsOn = true;

	public Animator shipLightsAnimator;

	[ServerRpc(RequireOwnership = false)]
	public void SetShipLightsServerRpc(bool setLightsOn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1625678258u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setLightsOn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1625678258u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetShipLightsClientRpc(setLightsOn);
			}
		}
	}

	[ClientRpc]
	public void SetShipLightsClientRpc(bool setLightsOn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1484401029u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setLightsOn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1484401029u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				areLightsOn = setLightsOn;
				shipLightsAnimator.SetBool("lightsOn", areLightsOn);
				Debug.Log((object)$"Received set ship lights RPC. Lights on?: {areLightsOn}");
			}
		}
	}

	public void ToggleShipLights()
	{
		areLightsOn = !areLightsOn;
		shipLightsAnimator.SetBool("lightsOn", areLightsOn);
		SetShipLightsServerRpc(areLightsOn);
		Debug.Log((object)$"Toggling ship lights RPC. lights now: {areLightsOn}");
	}

	public void SetShipLightsBoolean(bool setLights)
	{
		areLightsOn = setLights;
		shipLightsAnimator.SetBool("lightsOn", areLightsOn);
		SetShipLightsServerRpc(areLightsOn);
		Debug.Log((object)$"Calling ship lights boolean RPC: {areLightsOn}");
	}

	public void ToggleShipLightsOnLocalClientOnly()
	{
		areLightsOn = !areLightsOn;
		shipLightsAnimator.SetBool("lightsOn", areLightsOn);
		Debug.Log((object)$"Set ship lights on client only: {areLightsOn}");
	}

	public void SetShipLightsOnLocalClientOnly(bool setLightsOn)
	{
		areLightsOn = setLightsOn;
		shipLightsAnimator.SetBool("lightsOn", areLightsOn);
		Debug.Log((object)$"Set ship lights on client only: {areLightsOn}");
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ShipLights()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1625678258u, new RpcReceiveHandler(__rpc_handler_1625678258));
		NetworkManager.__rpc_func_table.Add(1484401029u, new RpcReceiveHandler(__rpc_handler_1484401029));
	}

	private static void __rpc_handler_1625678258(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool shipLightsServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref shipLightsServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShipLights)(object)target).SetShipLightsServerRpc(shipLightsServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1484401029(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool shipLightsClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref shipLightsClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShipLights)(object)target).SetShipLightsClientRpc(shipLightsClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ShipLights";
	}
}
