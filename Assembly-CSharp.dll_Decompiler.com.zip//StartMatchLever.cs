using Unity.Netcode;
using UnityEngine;

public class StartMatchLever : NetworkBehaviour
{
	public bool singlePlayerEnabled;

	public bool leverHasBeenPulled;

	public InteractTrigger triggerScript;

	public StartOfRound playersManager;

	public Animator leverAnimatorObject;

	private float updateInterval;

	private bool clientSentRPC;

	public bool hasDisplayedTimeWarning;

	public void LeverAnimation()
	{
		if (!GameNetworkManager.Instance.localPlayerController.isPlayerDead && !playersManager.travellingToNewLevel && (!playersManager.inShipPhase || playersManager.connectedPlayersAmount + 1 > 1 || singlePlayerEnabled))
		{
			if (playersManager.shipHasLanded)
			{
				PullLeverAnim(leverPulled: false);
				clientSentRPC = true;
				PlayLeverPullEffectsServerRpc(leverPulled: false);
			}
			else if (playersManager.inShipPhase)
			{
				PullLeverAnim(leverPulled: true);
				clientSentRPC = true;
				PlayLeverPullEffectsServerRpc(leverPulled: true);
			}
		}
	}

	private void PullLeverAnim(bool leverPulled)
	{
		Debug.Log((object)$"Lever animation: setting bool to {leverPulled}");
		leverAnimatorObject.SetBool("pullLever", leverPulled);
		leverHasBeenPulled = leverPulled;
		triggerScript.interactable = false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void PlayLeverPullEffectsServerRpc(bool leverPulled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2406447821u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref leverPulled, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2406447821u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PlayLeverPullEffectsClientRpc(leverPulled);
			}
		}
	}

	[ClientRpc]
	private void PlayLeverPullEffectsClientRpc(bool leverPulled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2951629574u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref leverPulled, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2951629574u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (clientSentRPC)
			{
				clientSentRPC = false;
				Debug.Log((object)"Sent lever animation RPC on this client");
			}
			else
			{
				PullLeverAnim(leverPulled);
			}
		}
	}

	public void PullLever()
	{
		if (leverHasBeenPulled)
		{
			StartGame();
		}
		else
		{
			EndGame();
		}
	}

	public void StartGame()
	{
		if (playersManager.travellingToNewLevel || !playersManager.inShipPhase || (playersManager.connectedPlayersAmount + 1 <= 1 && !singlePlayerEnabled))
		{
			return;
		}
		if (playersManager.fullyLoadedPlayers.Count >= playersManager.connectedPlayersAmount + 1)
		{
			if (!((NetworkBehaviour)this).IsServer)
			{
				playersManager.StartGameServerRpc();
			}
			else
			{
				playersManager.StartGame();
			}
		}
		else
		{
			triggerScript.hoverTip = "[ Players are loading. ]";
			Debug.Log((object)"Attempted to start the game while routing to a new planet");
			Debug.Log((object)$"Number of loaded players: {playersManager.fullyLoadedPlayers}");
			updateInterval = 4f;
			CancelStartGame();
		}
	}

	[ClientRpc]
	public void CancelStartGameClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2142553593u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2142553593u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				CancelStartGame();
			}
		}
	}

	private void CancelStartGame()
	{
		leverHasBeenPulled = false;
		leverAnimatorObject.SetBool("pullLever", false);
	}

	public void EndGame()
	{
		if ((GameNetworkManager.Instance.localPlayerController.isPlayerDead || playersManager.shipHasLanded) && !playersManager.shipIsLeaving && !playersManager.shipLeftAutomatically)
		{
			triggerScript.interactable = false;
			playersManager.shipIsLeaving = true;
			playersManager.EndGameServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	public void BeginHoldingInteractOnLever()
	{
		if (playersManager.inShipPhase && !hasDisplayedTimeWarning && StartOfRound.Instance.currentLevel.planetHasTime)
		{
			hasDisplayedTimeWarning = true;
			if (TimeOfDay.Instance.daysUntilDeadline <= 0)
			{
				triggerScript.timeToHold = 4f;
				HUDManager.Instance.DisplayTip("HALT!", "You have 0 days left to meet the quota. Use the terminal to route to the company and sell.", isWarning: true);
			}
		}
	}

	private void Start()
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			triggerScript.hoverTip = "[ Must be server host. ]";
			triggerScript.interactable = false;
		}
	}

	private void Update()
	{
		if (updateInterval <= 0f)
		{
			updateInterval = 2f;
			if (!leverHasBeenPulled)
			{
				if (!((NetworkBehaviour)this).IsServer && !GameNetworkManager.Instance.gameHasStarted)
				{
					return;
				}
				if (playersManager.connectedPlayersAmount + 1 > 1 || singlePlayerEnabled)
				{
					if (GameNetworkManager.Instance.gameHasStarted)
					{
						triggerScript.hoverTip = "Land ship : [LMB]";
					}
					else
					{
						triggerScript.hoverTip = "Start game : [LMB]";
					}
				}
				else
				{
					triggerScript.hoverTip = "[ At least two players needed to start! ]";
				}
			}
			else
			{
				triggerScript.hoverTip = "Start ship : [LMB]";
			}
		}
		else
		{
			updateInterval -= Time.deltaTime;
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_StartMatchLever()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2406447821u, new RpcReceiveHandler(__rpc_handler_2406447821));
		NetworkManager.__rpc_func_table.Add(2951629574u, new RpcReceiveHandler(__rpc_handler_2951629574));
		NetworkManager.__rpc_func_table.Add(2142553593u, new RpcReceiveHandler(__rpc_handler_2142553593));
	}

	private static void __rpc_handler_2406447821(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool leverPulled = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref leverPulled, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StartMatchLever)(object)target).PlayLeverPullEffectsServerRpc(leverPulled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2951629574(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool leverPulled = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref leverPulled, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartMatchLever)(object)target).PlayLeverPullEffectsClientRpc(leverPulled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2142553593(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StartMatchLever)(object)target).CancelStartGameClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "StartMatchLever";
	}
}
