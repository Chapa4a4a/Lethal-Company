using System;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class UnlockableSuit : NetworkBehaviour
{
	public NetworkVariable<int> syncedSuitID = new NetworkVariable<int>(-1, (NetworkVariableReadPermission)0, (NetworkVariableWritePermission)0);

	public int suitID = -1;

	public Material suitMaterial;

	public SkinnedMeshRenderer suitRenderer;

	private void Update()
	{
		if (!((Object)(object)GameNetworkManager.Instance == (Object)null) && !((Object)(object)NetworkManager.Singleton == (Object)null) && !NetworkManager.Singleton.ShutdownInProgress && suitID != syncedSuitID.Value)
		{
			suitID = syncedSuitID.Value;
			suitMaterial = StartOfRound.Instance.unlockablesList.unlockables[suitID].suitMaterial;
			((Renderer)suitRenderer).material = suitMaterial;
			((Component)this).gameObject.GetComponent<InteractTrigger>().hoverTip = "Change: " + StartOfRound.Instance.unlockablesList.unlockables[suitID].unlockableName;
		}
	}

	public void SwitchSuitToThis(PlayerControllerB playerWhoTriggered = null)
	{
		if ((Object)(object)playerWhoTriggered == (Object)null)
		{
			playerWhoTriggered = GameNetworkManager.Instance.localPlayerController;
		}
		if (playerWhoTriggered.currentSuitID != suitID)
		{
			SwitchSuitForPlayer(playerWhoTriggered, suitID);
			SwitchSuitServerRpc((int)playerWhoTriggered.playerClientId);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SwitchSuitServerRpc(int playerID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3672046368u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerID);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3672046368u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SwitchSuitClientRpc(playerID);
			}
		}
	}

	[ClientRpc]
	public void SwitchSuitClientRpc(int playerID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2137061089u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerID);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2137061089u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerID)
			{
				SwitchSuitForPlayer(StartOfRound.Instance.allPlayerScripts[playerID], suitID);
			}
		}
	}

	public static void SwitchSuitForAllPlayers(int suitID, bool playAudio = false)
	{
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			Material material = StartOfRound.Instance.unlockablesList.unlockables[suitID].suitMaterial;
			PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[i];
			if (playAudio && playerControllerB.currentSuitID != suitID)
			{
				playerControllerB.movementAudio.PlayOneShot(StartOfRound.Instance.changeSuitSFX);
			}
			((Renderer)playerControllerB.thisPlayerModel).material = material;
			((Renderer)playerControllerB.thisPlayerModelLOD1).material = material;
			((Renderer)playerControllerB.thisPlayerModelLOD2).material = material;
			((Renderer)playerControllerB.thisPlayerModelArms).material = material;
			playerControllerB.currentSuitID = suitID;
		}
	}

	public static void SwitchSuitForPlayer(PlayerControllerB player, int suitID, bool playAudio = true)
	{
		if (playAudio && player.currentSuitID != suitID)
		{
			player.movementAudio.PlayOneShot(StartOfRound.Instance.changeSuitSFX);
		}
		Material material = StartOfRound.Instance.unlockablesList.unlockables[suitID].suitMaterial;
		((Renderer)player.thisPlayerModel).material = material;
		((Renderer)player.thisPlayerModelLOD1).material = material;
		((Renderer)player.thisPlayerModelLOD2).material = material;
		((Renderer)player.thisPlayerModelArms).material = material;
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)(object)player)
		{
			ChangePlayerCostumeElement(player.headCostumeContainer, StartOfRound.Instance.unlockablesList.unlockables[suitID].headCostumeObject);
			ChangePlayerCostumeElement(player.lowerTorsoCostumeContainer, StartOfRound.Instance.unlockablesList.unlockables[suitID].lowerTorsoCostumeObject);
		}
		else
		{
			ChangePlayerCostumeElement(player.headCostumeContainerLocal, StartOfRound.Instance.unlockablesList.unlockables[suitID].headCostumeObject);
		}
		player.currentSuitID = suitID;
	}

	public static void ChangePlayerCostumeElement(Transform costumeContainer, GameObject newCostume)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Expected O, but got Unknown
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		foreach (Transform item in costumeContainer)
		{
			Transform val = item;
			if (!((Component)val).CompareTag("DoNotSet"))
			{
				Object.Destroy((Object)(object)((Component)val).gameObject);
			}
		}
		if (!((Object)(object)newCostume == (Object)null))
		{
			Object.Instantiate<GameObject>(newCostume, ((Component)costumeContainer).transform.position, ((Component)costumeContainer).transform.rotation, ((Component)costumeContainer).transform);
		}
	}

	protected override void __initializeVariables()
	{
		if (syncedSuitID == null)
		{
			throw new Exception("UnlockableSuit.syncedSuitID cannot be null. All NetworkVariableBase instances must be initialized.");
		}
		((NetworkVariableBase)syncedSuitID).Initialize((NetworkBehaviour)(object)this);
		((NetworkBehaviour)this).__nameNetworkVariable((NetworkVariableBase)(object)syncedSuitID, "syncedSuitID");
		base.NetworkVariableFields.Add((NetworkVariableBase)(object)syncedSuitID);
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_UnlockableSuit()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3672046368u, new RpcReceiveHandler(__rpc_handler_3672046368));
		NetworkManager.__rpc_func_table.Add(2137061089u, new RpcReceiveHandler(__rpc_handler_2137061089));
	}

	private static void __rpc_handler_3672046368(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerID);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((UnlockableSuit)(object)target).SwitchSuitServerRpc(playerID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2137061089(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((UnlockableSuit)(object)target).SwitchSuitClientRpc(playerID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "UnlockableSuit";
	}
}
