using Unity.Netcode;
using Unity.Netcode.Components;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(NetworkTransform))]
public class NetworkRigidbodyModifiable : NetworkBehaviour
{
	private Rigidbody m_Rigidbody;

	private NetworkTransform m_NetworkTransform;

	private bool m_OriginalKinematic;

	public bool kinematicOnOwner;

	public bool nonKinematicWhenDropping;

	private RigidbodyInterpolation m_OriginalInterpolation;

	private bool m_IsAuthority;

	private bool HasAuthority => m_NetworkTransform.CanCommitToTransform;

	private void Awake()
	{
		m_Rigidbody = ((Component)this).GetComponent<Rigidbody>();
		m_NetworkTransform = ((Component)this).GetComponent<NetworkTransform>();
	}

	private void FixedUpdate()
	{
		if (((NetworkBehaviour)this).NetworkManager.IsListening && HasAuthority != m_IsAuthority)
		{
			m_IsAuthority = HasAuthority;
			UpdateRigidbodyKinematicMode();
		}
	}

	public void UpdateRigidbodyKinematicMode()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if (!m_IsAuthority)
		{
			m_OriginalKinematic = m_Rigidbody.isKinematic;
			m_Rigidbody.isKinematic = true;
			m_OriginalInterpolation = m_Rigidbody.interpolation;
			m_Rigidbody.interpolation = (RigidbodyInterpolation)0;
			return;
		}
		if (kinematicOnOwner)
		{
			m_Rigidbody.isKinematic = true;
		}
		else if (nonKinematicWhenDropping)
		{
			m_Rigidbody.isKinematic = false;
			nonKinematicWhenDropping = false;
		}
		else
		{
			m_Rigidbody.isKinematic = m_OriginalKinematic;
		}
		m_Rigidbody.interpolation = m_OriginalInterpolation;
	}

	public override void OnNetworkSpawn()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		m_IsAuthority = HasAuthority;
		m_OriginalKinematic = m_Rigidbody.isKinematic;
		m_OriginalInterpolation = m_Rigidbody.interpolation;
		UpdateRigidbodyKinematicMode();
	}

	public override void OnNetworkDespawn()
	{
		UpdateRigidbodyKinematicMode();
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "NetworkRigidbodyModifiable";
	}
}
