using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Animations.Rigging;

public class BushWolfEnemy : EnemyAI, IVisibleThreat
{
	[Header("Bush Wolf Variables")]
	public float changeNestRangeSpeed = 0.75f;

	public float dragForce = 7f;

	public float nestRange = 15f;

	private float baseNestRange;

	public float attackDistance = 5f;

	private float baseAttackDistance;

	public float speedMultiplier;

	[Space(5f)]
	public Transform[] proceduralBodyTargets;

	public Transform[] IKTargetContainers;

	private float resetIKOffsetsInterval;

	private RaycastHit hit;

	public bool hideBodyOnTerrain;

	private int previousState = -1;

	private Collider[] nearbyColliders;

	private Vector3 aggressivePosition;

	private Vector3 mostHiddenPosition;

	private bool foundSpawningPoint;

	private bool inKillAnimation;

	private float velX;

	private float velZ;

	private Vector3 previousPosition;

	private Vector3 agentLocalVelocity;

	public Transform animationContainer;

	private float timeSpentHiding;

	private float timeSinceAdjustingPosition;

	private Vector3 currentHidingSpot;

	public bool isHiding;

	public PlayerControllerB staringAtPlayer;

	public PlayerControllerB lastPlayerStaredAt;

	private bool backedUpFromWatchingPlayer;

	private float staringAtPlayerTimer;

	public float spottedMeter;

	private int checkForPlayerDistanceInterval;

	private int checkPlayer;

	public Vector3 rotAxis;

	public Transform turnCompass;

	private float maxAnimSpeed = 1.25f;

	private bool looking;

	private bool dragging;

	private bool startedShootingTongue;

	private float shootTongueTimer;

	public Transform tongue;

	public Transform tongueStartPoint;

	private float tongueLengthNormalized;

	private bool failedTongueShoot;

	private float randomForceInterval;

	private PlayerControllerB lastHitByPlayer;

	private float timeSinceTakingDamage;

	private float timeSinceKillingPlayer;

	private Coroutine killPlayerCoroutine;

	private DeadBodyInfo body;

	public Transform playerBodyHeadPoint;

	private float timeSinceChangingState;

	private Transform tongueTarget;

	private float tongueScale;

	public AudioClip snarlSFX;

	public AudioClip[] growlSFX;

	public AudioSource growlAudio;

	public AudioClip shootTongueSFX;

	private float timeAtLastGrowl;

	private bool playedTongueAudio;

	public AudioSource tongueAudio;

	public AudioClip tongueShootSFX;

	private bool changedHidingSpot;

	public ParticleSystem spitParticle;

	public Transform playerAnimationHeadPoint;

	public PlayerControllerB draggingPlayer;

	private float timeSinceCheckHomeBase;

	private int timesFailingTongueShoot;

	public Rig bendHeadBack;

	private float timeSinceLOSBlocked;

	public AudioClip killSFX;

	private float timeSinceCall;

	public AudioSource callClose;

	public AudioSource callFar;

	private float matingCallTimer;

	public AudioClip[] callsClose;

	public AudioClip[] callsFar;

	public AudioClip hitBushWolfSFX;

	private float timeSinceHitting;

	private float noTargetTimer;

	private float waitOutsideShipTimer;

	private Vector3 hiddenPos;

	ThreatType IVisibleThreat.type => ThreatType.BushWolf;

	bool IVisibleThreat.IsThreatDead()
	{
		return isEnemyDead;
	}

	GrabbableObject IVisibleThreat.GetHeldObject()
	{
		return null;
	}

	int IVisibleThreat.SendSpecialBehaviour(int id)
	{
		return 0;
	}

	int IVisibleThreat.GetThreatLevel(Vector3 seenByPosition)
	{
		int num = 0;
		if (dragging && !startedShootingTongue)
		{
			return 1;
		}
		num = ((enemyHP >= 2) ? 3 : 2);
		if (Time.realtimeSinceStartup - timeSinceCall < 5f)
		{
			num += 3;
		}
		return num;
	}

	int IVisibleThreat.GetInterestLevel()
	{
		return 0;
	}

	Transform IVisibleThreat.GetThreatLookTransform()
	{
		return eye;
	}

	Transform IVisibleThreat.GetThreatTransform()
	{
		return ((Component)this).transform;
	}

	Vector3 IVisibleThreat.GetThreatVelocity()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			return agent.velocity;
		}
		return agentLocalVelocity;
	}

	float IVisibleThreat.GetVisibility()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (isEnemyDead)
		{
			return 0f;
		}
		if ((dragging && !startedShootingTongue) || Time.realtimeSinceStartup - timeSinceCall < 5f)
		{
			return 0.8f;
		}
		if (Vector3.Distance(((Component)this).transform.position, currentHidingSpot) < baseNestRange - 3f)
		{
			return 0.18f;
		}
		return 0.5f;
	}

	public override void AnimationEventA()
	{
		base.AnimationEventA();
		spitParticle.Play(true);
	}

	public override void Start()
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		resetIKOffsetsInterval = 15f;
		nearbyColliders = (Collider[])(object)new Collider[10];
		EnableEnemyMesh(enable: false);
		inSpecialAnimation = true;
		((Behaviour)agent).enabled = false;
		baseAttackDistance = attackDistance;
		if (((NetworkBehaviour)this).IsServer)
		{
			if (!GetBiggestWeedPatch())
			{
				KillEnemyOnOwnerClient(overrideDestroy: true);
				return;
			}
			CalculateNestRange(useCurrentHidingSpot: false);
			SyncWeedPositionsServerRpc(mostHiddenPosition, aggressivePosition, nestRange);
		}
	}

	private void CalculateNestRange(bool useCurrentHidingSpot)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = mostHiddenPosition;
		if (useCurrentHidingSpot)
		{
			val = currentHidingSpot;
		}
		Collider[] array = Physics.OverlapSphere(mostHiddenPosition, 50f, 65536, (QueryTriggerInteraction)2);
		if (array == null)
		{
			Debug.Log((object)"Got no colliders for nest range");
			return;
		}
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		for (int i = 0; i < array.Length; i++)
		{
			num2 = Vector3.Distance(val, ((Component)array[i]).transform.position);
			if (num2 > num3)
			{
				num3 = num2;
			}
			num += num2;
		}
		num = num / (float)array.Length + 16f;
		nestRange = num;
		baseNestRange = nestRange;
	}

	public override void OnDrawGizmos()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		base.OnDrawGizmos();
		if (debugEnemyAI)
		{
			Gizmos.DrawWireSphere(mostHiddenPosition, nestRange);
			Gizmos.DrawSphere(hiddenPos, 5f);
		}
	}

	[ServerRpc]
	public void SyncWeedPositionsServerRpc(Vector3 hiddenPosition, Vector3 aggressivePosition, float nest)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Invalid comparison between Unknown and I4
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4128579861u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref hiddenPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref aggressivePosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref nest, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4128579861u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncWeedPositionsClientRpc(hiddenPosition, aggressivePosition, nest);
		}
	}

	[ClientRpc]
	public void SyncWeedPositionsClientRpc(Vector3 hiddenPosition, Vector3 agg, float nest)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3617357318u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref hiddenPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref agg);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref nest, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3617357318u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				mostHiddenPosition = hiddenPosition;
				aggressivePosition = agg;
				currentHidingSpot = mostHiddenPosition;
				nestRange = nest;
				baseNestRange = nest;
			}
		}
	}

	private bool GetBiggestWeedPatch()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		GameObject[] array = GameObject.FindGameObjectsWithTag("MoldSpore");
		if (array == null || array.Length == 0)
		{
			Debug.Log((object)"Bush wolf: No game objects found with spore tag; cancelling");
			return false;
		}
		GameObject val = GameObject.FindGameObjectWithTag("MoldAttractionPoint");
		int num = 0;
		int num2 = 0;
		List<GameObject> list = new List<GameObject>();
		GameObject val2 = array[0];
		for (int i = 0; i < array.Length; i++)
		{
			num2 = Physics.OverlapSphereNonAlloc(array[i].transform.position, 5f, nearbyColliders, 65536, (QueryTriggerInteraction)2);
			Debug.Log((object)$"{i}: Mold spore {((Object)array[i].gameObject).name} at {array[i].transform.position} surrounded by {num2}");
			if ((num >= 3 && num - num2 >= 1) || num2 >= 2)
			{
				list.Add(array[i]);
			}
			if (num2 > num)
			{
				num = num2;
				val2 = array[i];
			}
		}
		Debug.Log((object)$"Bush wolf: Most surrounding spores is {num}");
		Debug.DrawRay(val2.transform.position, Vector3.up * 5f, Color.green, 10f);
		if (num == 0)
		{
			Debug.Log((object)"Bush wolf: All spores found were lone spores; cancelling");
			return false;
		}
		mostHiddenPosition = RoundManager.Instance.GetNavMeshPosition(val2.transform.position, default(NavMeshHit), 8f);
		if ((Object)(object)val != (Object)null)
		{
			if (Vector3.Distance(val2.transform.position, val.transform.position) > 35f)
			{
				float num3 = 45f;
				float num4 = 0f;
				GameObject val3 = null;
				for (int j = 0; j < list.Count; j++)
				{
					num4 = Vector3.Distance(list[j].transform.position, val.transform.position);
					if (num4 < num3)
					{
						num3 = num4;
						val3 = list[j];
					}
				}
				if ((Object)(object)val3 != (Object)null)
				{
					aggressivePosition = RoundManager.Instance.GetNavMeshPosition(val3.transform.position, default(NavMeshHit), 8f);
					if (!RoundManager.Instance.GotNavMeshPositionResult)
					{
						aggressivePosition = mostHiddenPosition;
					}
				}
			}
			else
			{
				aggressivePosition = mostHiddenPosition;
			}
		}
		return true;
	}

	public PlayerControllerB GetClosestPlayerToNest()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB result = null;
		mostOptimalDistance = 2000f;
		for (int i = 0; i < 4; i++)
		{
			if (PlayerIsTargetable(StartOfRound.Instance.allPlayerScripts[i]))
			{
				tempDist = Vector3.Distance(currentHidingSpot, ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position);
				if (tempDist < mostOptimalDistance)
				{
					mostOptimalDistance = tempDist;
					result = StartOfRound.Instance.allPlayerScripts[i];
				}
			}
		}
		return result;
	}

	public override void DoAIInterval()
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0430: Unknown result type (might be due to invalid IL or missing references)
		//IL_0436: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.livingPlayers == 0 || !foundSpawningPoint || isEnemyDead)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			if (checkForPlayerDistanceInterval < 1)
			{
				checkForPlayerDistanceInterval++;
				break;
			}
			checkForPlayerDistanceInterval = 0;
			PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[checkPlayer];
			if (PlayerIsTargetable(playerControllerB) && !PathIsIntersectedByLineOfSight(((Component)playerControllerB).transform.position, calculatePathDistance: true, avoidLineOfSight: false))
			{
				float num = Vector3.Distance(((Component)this).transform.position, ((Component)playerControllerB).transform.position);
				bool flag = (playerControllerB.timeSincePlayerMoving > 0.7f && num < attackDistance - 4.75f) || num < attackDistance - 7f;
				if (timeSinceChangingState > 0.35f && flag && !Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.6f, ((Component)playerControllerB.gameplayCamera).transform.position - Vector3.up * 0.3f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					SwitchToBehaviourStateOnLocalClient(2);
					SyncTargetPlayerAndAttackServerRpc((int)playerControllerB.playerClientId);
				}
				else if (pathDistance < nestRange && Vector3.Distance(((Component)playerControllerB).transform.position, currentHidingSpot) < nestRange)
				{
					Debug.Log((object)$"Beginning attack on '{playerControllerB.playerUsername}'; distance: {pathDistance}");
					targetPlayer = playerControllerB;
					SwitchToBehaviourState(1);
				}
			}
			checkPlayer = (checkPlayer + 1) % StartOfRound.Instance.allPlayerScripts.Length;
			break;
		}
		case 1:
		{
			bool flag2 = false;
			PlayerControllerB closestPlayer = GetClosestPlayer();
			if ((Object)(object)closestPlayer != (Object)null)
			{
				flag2 = true;
				float num2 = mostOptimalDistance;
				PlayerControllerB closestPlayerToNest = GetClosestPlayerToNest();
				if ((Object)(object)closestPlayerToNest != (Object)null && (Object)(object)closestPlayerToNest != (Object)(object)targetPlayer && (num2 > 9f || spottedMeter > 0.45f) && Vector3.Distance(((Component)this).transform.position, ((Component)closestPlayerToNest).transform.position) - num2 < 15f)
				{
					SetMovingTowardsTargetPlayer(closestPlayerToNest);
				}
				else
				{
					SetMovingTowardsTargetPlayer(closestPlayer);
				}
			}
			if (flag2)
			{
				noTargetTimer = 0f;
				float num3 = Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position);
				bool flag3 = (targetPlayer.timeSincePlayerMoving > 0.7f && num3 < attackDistance - 5f) || num3 < attackDistance - 7f;
				if (Vector3.Distance(currentHidingSpot, ((Component)targetPlayer).transform.position) > nestRange + 9f)
				{
					timeSinceAdjustingPosition = 0f;
					SwitchToBehaviourState(0);
				}
				else if (timeSinceChangingState > 0.35f && flag3 && !Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.6f, ((Component)targetPlayer.gameplayCamera).transform.position - Vector3.up * 0.3f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					SwitchToBehaviourStateOnLocalClient(2);
					SyncTargetPlayerAndAttackServerRpc((int)targetPlayer.playerClientId);
				}
				else
				{
					ChooseClosestNodeToPlayer();
				}
			}
			else if (timeSinceChangingState > 0.25f)
			{
				if (noTargetTimer > 0.5f)
				{
					noTargetTimer = 0f;
					timeSinceAdjustingPosition = 0f;
					SwitchToBehaviourState(0);
				}
				else
				{
					noTargetTimer += AIIntervalTime;
				}
			}
			break;
		}
		case 2:
			if (dragging && !startedShootingTongue && (PathIsIntersectedByLineOfSight(currentHidingSpot, calculatePathDistance: false, avoidLineOfSight: false) || shootTongueTimer > 35f || (shootTongueTimer > 12f && Vector3.Distance(((Component)this).transform.position, currentHidingSpot) > 20f)))
			{
				timesFailingTongueShoot++;
				SwitchToBehaviourState(1);
			}
			break;
		}
	}

	[ServerRpc]
	public void SyncTargetPlayerAndAttackServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2030618602u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2030618602u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncTargetPlayerAndAttackClientRpc(playerId);
		}
	}

	[ClientRpc]
	public void SyncTargetPlayerAndAttackClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(445373695u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 445373695u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				targetPlayer = StartOfRound.Instance.allPlayerScripts[playerId];
				SwitchToBehaviourStateOnLocalClient(2);
			}
		}
	}

	[ServerRpc]
	public void SyncNewHidingSpotServerRpc(Vector3 newHidingSpot, float nest)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Invalid comparison between Unknown and I4
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1220991600u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newHidingSpot);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref nest, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1220991600u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncNewHidingSpotClientRpc(newHidingSpot, nest);
		}
	}

	[ClientRpc]
	public void SyncNewHidingSpotClientRpc(Vector3 newHidingSpot, float nest)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1730122673u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref newHidingSpot);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref nest, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1730122673u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				currentHidingSpot = newHidingSpot;
				nestRange = nest;
				baseNestRange = nest;
			}
		}
	}

	public Transform ChooseClosestHiddenNode(Vector3 pos)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		nodesTempArray = allAINodes.OrderBy((GameObject x) => Vector3.Distance(pos, x.transform.position)).ToArray();
		Transform val = null;
		if ((Object)(object)targetNode != (Object)null)
		{
			Physics.Linecast(((Component)targetPlayer.gameplayCamera).transform.position, ((Component)targetNode).transform.position, 1024, (QueryTriggerInteraction)1);
		}
		else
			_ = 0;
		for (int i = 0; i < nodesTempArray.Length; i++)
		{
			if (!(Vector3.Distance(nodesTempArray[i].transform.position, currentHidingSpot) > nestRange) && !PathIsIntersectedByLineOfSight(nodesTempArray[i].transform.position))
			{
				mostOptimalDistance = Vector3.Distance(pos, nodesTempArray[i].transform.position);
				if ((Object)(object)val != (Object)null && mostOptimalDistance - Vector3.Distance(val.position, pos) > 10f)
				{
					break;
				}
				if (Physics.Linecast(((Component)targetPlayer.gameplayCamera).transform.position, nodesTempArray[i].transform.position, 1024, (QueryTriggerInteraction)1))
				{
					val = nodesTempArray[i].transform;
					break;
				}
				if (!targetPlayer.HasLineOfSightToPosition(nodesTempArray[i].transform.position + Vector3.up * 1.5f, 110f, 40))
				{
					val = nodesTempArray[i].transform;
					break;
				}
				if (spottedMeter > 0.9f && Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position) < 12f)
				{
					val = nodesTempArray[i].transform;
				}
			}
		}
		if ((Object)(object)val != (Object)null)
		{
			mostOptimalDistance = Vector3.Distance(pos, ((Component)val).transform.position);
		}
		return val;
	}

	public void ChooseClosestNodeToPlayer()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)targetNode == (Object)null)
		{
			targetNode = allAINodes[0].transform;
		}
		Transform val = ChooseClosestHiddenNode(((Component)targetPlayer).transform.position);
		if ((Object)(object)val != (Object)null)
		{
			targetNode = val;
		}
		Vector3 val2 = Vector3.Normalize((((Component)this).transform.position - ((Component)targetPlayer).transform.position) * 100f) * 4f;
		val2.y = 0f;
		if ((Object)(object)targetNode != (Object)null)
		{
			mostOptimalDistance = Vector3.Distance(((Component)this).transform.position, targetNode.position + val2);
		}
		float num = targetPlayer.LineOfSightToPositionAngle(((Component)this).transform.position + Vector3.up * 0.75f, 70);
		float num2 = Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position);
		bool flag = num != -361f && num2 < 10f && ((num < 10f && spottedMeter > 0.25f) || (num > 90f && Vector3.Distance(((Component)targetPlayer).transform.position, currentHidingSpot) < nestRange - 7f));
		if (targetPlayer.isInElevator)
		{
			if (waitOutsideShipTimer > 18f && Vector3.Distance(((Component)this).transform.position, StartOfRound.Instance.elevatorTransform.position) < 27f)
			{
				movingTowardsTargetPlayer = true;
			}
			else
			{
				SetDestinationToPosition(targetNode.position + val2, checkForPath: true);
			}
		}
		else if (flag || (num2 - mostOptimalDistance < 0.5f && (!PathIsIntersectedByLineOfSight(((Component)targetPlayer).transform.position) || num2 < 8f)))
		{
			movingTowardsTargetPlayer = true;
		}
		else
		{
			SetDestinationToPosition(targetNode.position + val2, checkForPath: true);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetAnimationSpeedServerRpc(float animSpeed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2647215443u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref animSpeed, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2647215443u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetAnimationSpeedClientRpc(animSpeed);
			}
		}
	}

	[ClientRpc]
	public void SetAnimationSpeedClientRpc(float animSpeed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1175673081u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref animSpeed, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1175673081u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				maxAnimSpeed = animSpeed;
			}
		}
	}

	public override void SetEnemyStunned(bool setToStunned, float setToStunTime = 1f, PlayerControllerB setStunnedByPlayer = null)
	{
		base.SetEnemyStunned(setToStunned, setToStunTime, setStunnedByPlayer);
		SwitchToBehaviourState(0);
		CancelKillAnimation();
		if (dragging && !startedShootingTongue && (Object)(object)targetPlayer != (Object)null)
		{
			dragging = false;
			targetPlayer.inShockingMinigame = false;
			targetPlayer.inSpecialInteractAnimation = false;
		}
		if ((Object)(object)setStunnedByPlayer != (Object)null)
		{
			lastHitByPlayer = setStunnedByPlayer;
		}
		timeSinceTakingDamage = 0f;
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		enemyHP -= force;
		if (enemyHP <= 0 && !isEnemyDead && ((NetworkBehaviour)this).IsOwner)
		{
			KillEnemyOnOwnerClient();
		}
		creatureAnimator.SetTrigger("HitEnemy");
		timeSinceTakingDamage = 0f;
		if ((Object)(object)playerWhoHit != (Object)null)
		{
			lastHitByPlayer = playerWhoHit;
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			CancelKillAnimation();
			if (currentBehaviourStateIndex == 2)
			{
				SwitchToBehaviourState(0);
			}
		}
		CancelReelingPlayerIn();
		creatureVoice.PlayOneShot(hitBushWolfSFX);
	}

	private void CancelReelingPlayerIn()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if (previousState == 2 || previousState == 1 || currentBehaviourStateIndex == 2)
		{
			if (dragging)
			{
				creatureVoice.Stop();
			}
			growlAudio.Stop();
			tongueAudio.Stop();
			playedTongueAudio = false;
			tongueTarget = null;
			tongue.localScale = Vector3.one;
			creatureAnimator.SetBool("ReelingPlayerIn", false);
			creatureAnimator.SetBool("ShootTongue", false);
			shootTongueTimer = 0f;
			timeSinceAdjustingPosition = 0f;
			if ((Object)(object)draggingPlayer != (Object)null)
			{
				draggingPlayer.inShockingMinigame = false;
				draggingPlayer.inSpecialInteractAnimation = false;
				draggingPlayer.shockingTarget = null;
				draggingPlayer.disableInteract = false;
			}
			draggingPlayer = null;
			dragging = false;
			startedShootingTongue = false;
		}
	}

	private void DoGrowlLocalClient()
	{
		timeAtLastGrowl = Time.realtimeSinceStartup;
		growlAudio.PlayOneShot(growlSFX[Random.Range(0, growlSFX.Length)]);
		if (((NetworkBehaviour)this).IsOwner)
		{
			DoGrowlServerRpc();
		}
	}

	[ServerRpc]
	public void DoGrowlServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(610520803u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 610520803u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DoGrowlClientRpc();
		}
	}

	[ClientRpc]
	public void DoGrowlClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2034052870u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2034052870u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				DoGrowlLocalClient();
			}
		}
	}

	[ServerRpc]
	public void SeeBushWolfServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(788204480u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 788204480u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SeeBushWolfClientRpc(playerId);
		}
	}

	[ClientRpc]
	public void SeeBushWolfClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(237023778u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 237023778u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerId == (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				SetFearLevelFromBushWolf();
			}
		}
	}

	private void SetFearLevelFromBushWolf()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
		if (Vector3.Distance(((Component)localPlayerController).transform.position, ((Component)this).transform.position) < 10f)
		{
			localPlayerController.JumpToFearLevel(0.6f);
		}
		else
		{
			localPlayerController.JumpToFearLevel(0.3f);
		}
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		CancelReelingPlayerIn();
	}

	public override void KillEnemy(bool destroy = false)
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		base.KillEnemy(destroy);
		if (!destroy)
		{
			growlAudio.Stop();
			callClose.Stop();
			callFar.Stop();
			creatureSFX.Stop();
			creatureVoice.Stop();
			CancelKillAnimation();
			creatureVoice.PlayOneShot(dieSFX);
			WalkieTalkie.TransmitOneShotAudio(creatureVoice, dieSFX);
			RoundManager.Instance.PlayAudibleNoise(((Component)creatureVoice).transform.position, 20f, 0.7f, 0, isInsidePlayerShip && StartOfRound.Instance.hangarDoorsClosed);
			CancelReelingPlayerIn();
		}
	}

	public void HitTongue(PlayerControllerB playerWhoHit, int hitID)
	{
		if (dragging && !startedShootingTongue)
		{
			int playerWhoHit2 = -1;
			if ((Object)(object)playerWhoHit != (Object)null)
			{
				playerWhoHit2 = (int)playerWhoHit.playerClientId;
				HitTongueLocalClient();
			}
			HitTongueServerRpc(playerWhoHit2);
		}
	}

	private void HitTongueLocalClient()
	{
		timeSinceTakingDamage = 0f;
		creatureVoice.PlayOneShot(hitBushWolfSFX);
		creatureAnimator.ResetTrigger("HitEnemy");
		creatureAnimator.SetTrigger("HitEnemy");
		CancelReelingPlayerIn();
		SwitchToBehaviourStateOnLocalClient(0);
	}

	[ServerRpc(RequireOwnership = false)]
	public void HitTongueServerRpc(int playerWhoHit)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1630339873u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoHit);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1630339873u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				HitTongueClientRpc(playerWhoHit);
			}
		}
	}

	[ClientRpc]
	public void HitTongueClientRpc(int playerWhoHit)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(905088005u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoHit);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 905088005u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerWhoHit)
			{
				HitTongueLocalClient();
			}
		}
	}

	private void CheckHomeBase(bool overrideInterval = false)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner || ((!overrideInterval || !(Time.realtimeSinceStartup - timeSinceCheckHomeBase > 5f)) && !(Time.realtimeSinceStartup - timeSinceCheckHomeBase > 30f)))
		{
			return;
		}
		timeSinceCheckHomeBase = Time.realtimeSinceStartup;
		Vector3 val = mostHiddenPosition;
		if (GetBiggestWeedPatch())
		{
			if (val != mostHiddenPosition || changedHidingSpot)
			{
				CalculateNestRange(useCurrentHidingSpot: false);
			}
			changedHidingSpot = false;
			SyncWeedPositionsClientRpc(mostHiddenPosition, aggressivePosition, nestRange);
		}
	}

	private void DoMatingCall()
	{
		if (((NetworkBehaviour)this).IsOwner)
		{
			MatingCallServerRpc();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void MatingCallServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4293930053u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4293930053u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				MatingCallClientRpc();
			}
		}
	}

	[ClientRpc]
	public void MatingCallClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1218980844u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1218980844u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				matingCallTimer = 2.2f;
				creatureAnimator.SetTrigger("MatingCall");
				int num = Random.Range(0, callsClose.Length);
				callClose.PlayOneShot(callsClose[num]);
				WalkieTalkie.TransmitOneShotAudio(callClose, callsClose[num]);
				callFar.PlayOneShot(callsFar[num]);
				WalkieTalkie.TransmitOneShotAudio(callFar, callsFar[num]);
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 20f, 0.6f, 0, noiseIsInsideClosedShip: false, 245403);
			}
		}
	}

	public override void Update()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_125b: Unknown result type (might be due to invalid IL or missing references)
		//IL_039b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c73: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c78: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c82: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c91: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c96: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ebd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ecd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0426: Unknown result type (might be due to invalid IL or missing references)
		//IL_0436: Unknown result type (might be due to invalid IL or missing references)
		//IL_043b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0440: Unknown result type (might be due to invalid IL or missing references)
		//IL_0456: Unknown result type (might be due to invalid IL or missing references)
		//IL_045b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0465: Unknown result type (might be due to invalid IL or missing references)
		//IL_046a: Unknown result type (might be due to invalid IL or missing references)
		//IL_046f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0702: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0738: Unknown result type (might be due to invalid IL or missing references)
		//IL_0743: Unknown result type (might be due to invalid IL or missing references)
		//IL_0762: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0506: Unknown result type (might be due to invalid IL or missing references)
		//IL_050b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0512: Unknown result type (might be due to invalid IL or missing references)
		//IL_0517: Unknown result type (might be due to invalid IL or missing references)
		//IL_0526: Unknown result type (might be due to invalid IL or missing references)
		//IL_0528: Unknown result type (might be due to invalid IL or missing references)
		//IL_052d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0993: Unknown result type (might be due to invalid IL or missing references)
		//IL_0998: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_054c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0579: Unknown result type (might be due to invalid IL or missing references)
		//IL_0589: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d35: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d5f: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_05da: Unknown result type (might be due to invalid IL or missing references)
		//IL_05df: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fa5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb5: Unknown result type (might be due to invalid IL or missing references)
		//IL_060f: Unknown result type (might be due to invalid IL or missing references)
		//IL_061a: Unknown result type (might be due to invalid IL or missing references)
		//IL_14ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_14b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_14ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_14cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_14d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1041: Unknown result type (might be due to invalid IL or missing references)
		//IL_1046: Unknown result type (might be due to invalid IL or missing references)
		//IL_1050: Unknown result type (might be due to invalid IL or missing references)
		//IL_1055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0afe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b32: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b38: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3f: Unknown result type (might be due to invalid IL or missing references)
		//IL_10b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_15a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_15aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_15d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_15dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_15e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_15ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_15f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_15fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1600: Unknown result type (might be due to invalid IL or missing references)
		//IL_1605: Unknown result type (might be due to invalid IL or missing references)
		//IL_1162: Unknown result type (might be due to invalid IL or missing references)
		//IL_1172: Unknown result type (might be due to invalid IL or missing references)
		//IL_110f: Unknown result type (might be due to invalid IL or missing references)
		//IL_111e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1558: Unknown result type (might be due to invalid IL or missing references)
		//IL_151a: Unknown result type (might be due to invalid IL or missing references)
		//IL_152a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e28: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e38: Unknown result type (might be due to invalid IL or missing references)
		//IL_1199: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bf2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bf7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c01: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c06: Unknown result type (might be due to invalid IL or missing references)
		//IL_1661: Unknown result type (might be due to invalid IL or missing references)
		//IL_1666: Unknown result type (might be due to invalid IL or missing references)
		//IL_163a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1649: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c23: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c37: Unknown result type (might be due to invalid IL or missing references)
		//IL_173a: Unknown result type (might be due to invalid IL or missing references)
		//IL_173f: Unknown result type (might be due to invalid IL or missing references)
		//IL_16d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1763: Unknown result type (might be due to invalid IL or missing references)
		//IL_1768: Unknown result type (might be due to invalid IL or missing references)
		//IL_1772: Unknown result type (might be due to invalid IL or missing references)
		//IL_1777: Unknown result type (might be due to invalid IL or missing references)
		//IL_177c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1789: Unknown result type (might be due to invalid IL or missing references)
		//IL_178e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1793: Unknown result type (might be due to invalid IL or missing references)
		//IL_179d: Unknown result type (might be due to invalid IL or missing references)
		//IL_17a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_17ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_185c: Unknown result type (might be due to invalid IL or missing references)
		//IL_185e: Unknown result type (might be due to invalid IL or missing references)
		//IL_186b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1870: Unknown result type (might be due to invalid IL or missing references)
		//IL_187a: Unknown result type (might be due to invalid IL or missing references)
		//IL_187f: Unknown result type (might be due to invalid IL or missing references)
		//IL_188a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1891: Unknown result type (might be due to invalid IL or missing references)
		//IL_18b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_18b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_18bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_16ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_17f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_17d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_17d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_17e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_17e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_17eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_19c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1709: Unknown result type (might be due to invalid IL or missing references)
		//IL_170e: Unknown result type (might be due to invalid IL or missing references)
		//IL_171c: Unknown result type (might be due to invalid IL or missing references)
		//IL_181d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1822: Unknown result type (might be due to invalid IL or missing references)
		//IL_182c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1831: Unknown result type (might be due to invalid IL or missing references)
		//IL_1836: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a10: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a12: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a17: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a27: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a32: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a37: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a57: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a5c: Unknown result type (might be due to invalid IL or missing references)
		//IL_18e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1907: Unknown result type (might be due to invalid IL or missing references)
		//IL_1926: Unknown result type (might be due to invalid IL or missing references)
		//IL_1945: Unknown result type (might be due to invalid IL or missing references)
		//IL_1958: Unknown result type (might be due to invalid IL or missing references)
		//IL_1974: Unknown result type (might be due to invalid IL or missing references)
		//IL_1989: Unknown result type (might be due to invalid IL or missing references)
		//IL_19af: Unknown result type (might be due to invalid IL or missing references)
		//IL_19b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_19bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_19c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_19c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1995: Unknown result type (might be due to invalid IL or missing references)
		//IL_1997: Unknown result type (might be due to invalid IL or missing references)
		//IL_19a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_19a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_19ab: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (looking)
		{
			looking = false;
		}
		else
		{
			agent.updateRotation = true;
		}
		if (!foundSpawningPoint)
		{
			if (!(mostHiddenPosition != Vector3.zero))
			{
				return;
			}
			Debug.DrawRay(mostHiddenPosition, Vector3.up * 2f, Color.red, 15f);
			foundSpawningPoint = true;
			Vector3 navMeshPosition = RoundManager.Instance.GetNavMeshPosition(mostHiddenPosition, default(NavMeshHit), 12f);
			if (!RoundManager.Instance.GotNavMeshPositionResult)
			{
				navMeshPosition = RoundManager.Instance.GetNavMeshPosition(aggressivePosition, default(NavMeshHit), 12f);
				if (!RoundManager.Instance.GotNavMeshPositionResult && ((NetworkBehaviour)this).IsOwner)
				{
					KillEnemyOnOwnerClient(overrideDestroy: true);
				}
			}
			((Component)this).transform.position = navMeshPosition;
			currentHidingSpot = navMeshPosition;
			inSpecialAnimation = false;
			EnableEnemyMesh(enable: true);
			isHiding = true;
			if (((NetworkBehaviour)this).IsOwner)
			{
				SetDestinationToPosition(mostHiddenPosition);
			}
			return;
		}
		if (!ventAnimationFinished)
		{
			serverPosition = mostHiddenPosition;
			((Component)this).transform.position = mostHiddenPosition;
		}
		if (inKillAnimation || isEnemyDead)
		{
			tongueTarget = null;
		}
		if (StartOfRound.Instance.livingPlayers == 0 || isEnemyDead || !foundSpawningPoint)
		{
			return;
		}
		creatureAnimator.SetBool("stunned", stunNormalizedTimer > 0f);
		if (stunNormalizedTimer > 0f || matingCallTimer >= 0f)
		{
			matingCallTimer -= Time.deltaTime;
			agent.speed = 0f;
			return;
		}
		timeSinceTakingDamage += Time.deltaTime;
		timeSinceKillingPlayer += Time.deltaTime;
		timeSinceHitting += Time.deltaTime;
		CalculateAnimationDirection(maxAnimSpeed);
		timeSinceChangingState += Time.deltaTime;
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			if (previousState != currentBehaviourStateIndex)
			{
				SetAnimationSpeedServerRpc(1.3f);
				backedUpFromWatchingPlayer = false;
				moveTowardsDestination = true;
				movingTowardsTargetPlayer = false;
				timeSpentHiding = 0f;
				timeSinceChangingState = 0f;
				CancelReelingPlayerIn();
				nestRange = Mathf.Clamp(nestRange / 2f, baseNestRange * 0.75f, 140f);
				previousState = currentBehaviourStateIndex;
			}
			if (((NetworkBehaviour)this).IsOwner && Vector3.Distance(((Component)this).transform.position, currentHidingSpot) < 16f && timeSinceChangingState > 0.5f && timeSinceTakingDamage < 2.5f && (Object)(object)lastHitByPlayer != (Object)null)
			{
				SetMovingTowardsTargetPlayer(lastHitByPlayer);
				agent.speed = 6f * speedMultiplier;
				break;
			}
			if (timeSinceKillingPlayer < 2f || timeSinceTakingDamage < 0.35f)
			{
				agent.speed = 0f;
				break;
			}
			inKillAnimation = false;
			isHiding = true;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			timeSpentHiding += Time.deltaTime;
			if (Object.op_Implicit((Object)(object)staringAtPlayer))
			{
				LookAtPosition(((Component)staringAtPlayer).transform.position);
				staringAtPlayerTimer += Time.deltaTime;
				if (staringAtPlayerTimer > 4f)
				{
					spottedMeter = 0f;
					backedUpFromWatchingPlayer = false;
					staringAtPlayer = null;
				}
				else if (staringAtPlayerTimer > 0.55f)
				{
					if (backedUpFromWatchingPlayer)
					{
						break;
					}
					backedUpFromWatchingPlayer = true;
					if (Vector3.Distance(((Component)this).transform.position, currentHidingSpot) < 6f)
					{
						Vector3 val3 = ((Component)this).transform.position - ((Component)staringAtPlayer).transform.position;
						val3.y = 0f;
						Ray val4 = default(Ray);
						((Ray)(ref val4))._002Ector(((Component)this).transform.position + Vector3.up * 0.5f, val3);
						val3 = ((!Physics.Raycast(val4, ref hit, 4.6f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)) ? ((Ray)(ref val4)).GetPoint(4.6f) : ((Ray)(ref val4)).GetPoint(Mathf.Clamp(((RaycastHit)(ref hit)).distance - 1f, 0f, ((RaycastHit)(ref hit)).distance)));
						val3 = RoundManager.Instance.GetNavMeshPosition(val3);
						Debug.DrawRay(((Component)this).transform.position + Vector3.up * 0.5f, ((Ray)(ref val4)).direction, Color.red, 5f);
						Debug.DrawRay(val3, Vector3.up, Color.green, 5f);
						if (RoundManager.Instance.GotNavMeshPositionResult)
						{
							SetDestinationToPosition(val3);
							moveTowardsDestination = true;
							agent.speed = 5f * speedMultiplier;
							if (Vector3.Distance(((Component)this).transform.position, ((Component)staringAtPlayer).transform.position) < 18f && Random.Range(0, 100) < 50 && Time.realtimeSinceStartup - timeAtLastGrowl > 5f)
							{
								DoGrowlLocalClient();
							}
							if (Physics.Linecast(((Component)staringAtPlayer.gameplayCamera).transform.position, ((Component)this).transform.position + Vector3.up * 0.5f, ref hit, 1024, (QueryTriggerInteraction)1) && Vector3.Distance(((RaycastHit)(ref hit)).point, ((Component)this).transform.position) < 6f)
							{
								SeeBushWolfServerRpc((int)staringAtPlayer.playerClientId);
							}
						}
					}
					else
					{
						agent.speed = 0f;
					}
				}
				else
				{
					agent.speed = 0f;
				}
				break;
			}
			int num3 = 0;
			int num4 = -1;
			float num5 = 2555f;
			Debug.Log((object)"Fox A");
			for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
			{
				if (StartOfRound.Instance.allPlayerScripts[i].isPlayerDead || !StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled || Object.op_Implicit((Object)(object)StartOfRound.Instance.allPlayerScripts[i].inAnimationWithEnemy) || Physics.Linecast(((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position, ((Component)this).transform.position + Vector3.up * 0.5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					continue;
				}
				Debug.Log((object)"Fox B");
				float num6 = Vector3.Distance(((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position, ((Component)this).transform.position);
				float num7 = StartOfRound.Instance.allPlayerScripts[i].LineOfSightToPositionAngle(((Component)this).transform.position, 40);
				if (num7 == -361f || num6 > 70f)
				{
					continue;
				}
				Debug.Log((object)$"Fox C; {num6}; {num7}");
				Debug.DrawLine(((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position, ((Component)this).transform.position, Color.red);
				if (num7 < 10f || (num7 < 20f && num6 < 20f))
				{
					Debug.Log((object)"Fox D");
					num3++;
					if (num3 >= Mathf.Max(StartOfRound.Instance.livingPlayers - 1, 0))
					{
						Debug.Log((object)"Fox E");
						spottedMeter = Mathf.Min(spottedMeter + 0.5f * Time.deltaTime, 1f);
					}
					if (num6 < num5)
					{
						Debug.Log((object)"Fox F");
						num5 = num6;
						num4 = i;
					}
				}
				else if (num7 < 20f)
				{
					Debug.Log((object)"Fox G");
					num3++;
					if (num3 >= Mathf.Max(StartOfRound.Instance.livingPlayers - 1, 0))
					{
						Debug.Log((object)"Fox H");
						spottedMeter = Mathf.Min(spottedMeter + 0.28f * Time.deltaTime, 1f);
					}
					if (num6 < num5)
					{
						Debug.Log((object)"Fox I");
						num5 = num6;
						num4 = i;
					}
				}
			}
			if (num3 <= 0)
			{
				Debug.Log((object)"Fox J");
				spottedMeter = Mathf.Max(spottedMeter - Time.deltaTime * 0.75f, 0f);
			}
			if (spottedMeter >= 1f && timeSinceChangingState > 1.2f)
			{
				staringAtPlayerTimer = 0f;
				backedUpFromWatchingPlayer = false;
				staringAtPlayer = StartOfRound.Instance.allPlayerScripts[num4];
				lastPlayerStaredAt = staringAtPlayer;
			}
			float num8 = 15f;
			if (timeSpentHiding > 70f && spottedMeter <= 0f && !changedHidingSpot)
			{
				currentHidingSpot = aggressivePosition;
				CalculateNestRange(useCurrentHidingSpot: true);
				SyncNewHidingSpotServerRpc(aggressivePosition, nestRange);
			}
			if (timeSpentHiding > 36f)
			{
				num8 = 4f;
			}
			else if (timeSpentHiding > 25f)
			{
				num8 = 7f;
			}
			else if (timeSpentHiding > 15f)
			{
				num8 = 10f;
			}
			Debug.Log((object)$"Fox spotted meter: {spottedMeter}");
			if (spottedMeter > 0.2f)
			{
				nestRange = Mathf.Clamp(nestRange - changeNestRangeSpeed * Mathf.Clamp(spottedMeter * 4f, 0.2f, 4f) * Time.deltaTime, baseNestRange * 0.75f, 140f);
			}
			else
			{
				nestRange += changeNestRangeSpeed * Time.deltaTime;
			}
			if (matingCallTimer <= 0f && timeSpentHiding > 10f && spottedMeter < 0.6f && Time.realtimeSinceStartup - timeSinceCall > 7f)
			{
				timeSinceCall = Time.realtimeSinceStartup;
				if (Random.Range(0, 100) < 8)
				{
					DoMatingCall();
				}
			}
			if (Time.realtimeSinceStartup - timeSinceAdjustingPosition > num8)
			{
				timeSinceAdjustingPosition = Time.realtimeSinceStartup;
				SetDestinationToPosition(RoundManager.Instance.GetNavMeshPosition(currentHidingSpot + new Vector3(Random.Range(-3f, 3f), 0f, Random.Range(-3f, 3f))));
				if (timeSinceTakingDamage < 2f)
				{
					agent.speed = 14f * speedMultiplier;
				}
				else
				{
					agent.speed = 10f * speedMultiplier;
				}
			}
			CheckHomeBase();
			break;
		}
		case 1:
		{
			if (previousState != currentBehaviourStateIndex)
			{
				spottedMeter = 0f;
				staringAtPlayer = null;
				timeSpentHiding = 0f;
				noTargetTimer = 0f;
				waitOutsideShipTimer = 0f;
				CancelReelingPlayerIn();
				previousState = currentBehaviourStateIndex;
			}
			if (timeSinceKillingPlayer < 2f || timeSinceTakingDamage < 0.35f)
			{
				agent.speed = 0f;
				break;
			}
			inKillAnimation = false;
			if (!((NetworkBehaviour)this).IsOwner || (Object)(object)targetPlayer == (Object)null)
			{
				break;
			}
			int num9 = 0;
			float num10 = 4f;
			bool flag = false;
			bool flag2 = (Object)(object)targetNode != (Object)null && Vector3.Distance(((Component)this).transform.position, targetNode.position + Vector3.Normalize((((Component)this).transform.position - ((Component)targetPlayer).transform.position) * 100f) * 4f) < 0.8f;
			bool flag3 = false;
			float num11;
			for (int j = 0; j < StartOfRound.Instance.allPlayerScripts.Length; j++)
			{
				flag3 = false;
				if (StartOfRound.Instance.allPlayerScripts[j].isPlayerDead || !StartOfRound.Instance.allPlayerScripts[j].isPlayerControlled || Object.op_Implicit((Object)(object)StartOfRound.Instance.allPlayerScripts[j].inAnimationWithEnemy) || (StartOfRound.Instance.allPlayerScripts[j].isInHangarShipRoom && isInsidePlayerShip))
				{
					continue;
				}
				num11 = Vector3.Distance(((Component)StartOfRound.Instance.allPlayerScripts[j]).transform.position, ((Component)this).transform.position);
				float num12 = StartOfRound.Instance.allPlayerScripts[j].LineOfSightToPositionAngle(((Component)this).transform.position, 40);
				if (num12 == -361f || num11 > 80f)
				{
					continue;
				}
				if (num12 < 10f || (num12 < 20f && num11 < 20f))
				{
					num9++;
					spottedMeter += Time.deltaTime * 0.6f;
					flag3 = true;
				}
				else if (num12 < 30f && num11 < 35f)
				{
					num9++;
					spottedMeter += Time.deltaTime * 0.33f;
					flag3 = true;
				}
				if (!flag3 || flag || !((Object)(object)targetNode != (Object)null))
				{
					continue;
				}
				if (Physics.Linecast(((Component)StartOfRound.Instance.allPlayerScripts[j].gameplayCamera).transform.position, ((Component)targetNode).transform.position, 1024, (QueryTriggerInteraction)1))
				{
					if (flag2)
					{
						num10 = 0f;
					}
					else if (num10 < 8f)
					{
						num10 = 10f;
					}
					continue;
				}
				num10 = 8f;
				flag = true;
				if (num11 < 14f && spottedMeter < 0.5f && !backedUpFromWatchingPlayer)
				{
					backedUpFromWatchingPlayer = true;
					SetFearLevelFromBushWolf();
				}
			}
			num11 = Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position);
			if (num9 <= 0)
			{
				spottedMeter = Mathf.Max(spottedMeter - Time.deltaTime, 0f);
				agent.speed = 6f * speedMultiplier;
			}
			else if (spottedMeter > 0.8f)
			{
				agent.speed = 10f * speedMultiplier;
				waitOutsideShipTimer = Mathf.Max(waitOutsideShipTimer - Time.deltaTime * 1.3f, 0f);
			}
			else
			{
				agent.speed = num10;
			}
			if (((StartOfRound.Instance.livingPlayers > 1 && num9 == StartOfRound.Instance.livingPlayers) || (spottedMeter > 0.95f && !flag2) || (spottedMeter <= 0f && Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position) < 11f)) && Time.realtimeSinceStartup - timeAtLastGrowl > 8f)
			{
				DoGrowlLocalClient();
			}
			if (matingCallTimer <= 0f && num11 > 12f && Time.realtimeSinceStartup - timeSinceCall > 7f)
			{
				timeSinceCall = Time.realtimeSinceStartup;
				if (Random.Range(0, 100) < 15)
				{
					DoMatingCall();
				}
			}
			if (spottedMeter > 0.05f && targetPlayer.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.5f, 60f, 30))
			{
				nestRange = Mathf.Clamp(nestRange - changeNestRangeSpeed * Mathf.Clamp(spottedMeter * 4f, 0.4f, 4f) * Time.deltaTime, baseNestRange * 0.75f, Vector3.Distance(((Component)targetPlayer).transform.position, currentHidingSpot) + 15f);
			}
			else
			{
				nestRange += changeNestRangeSpeed * Time.deltaTime;
			}
			if (targetPlayer.isInHangarShipRoom && spottedMeter < 0.5f && Vector3.Distance(((Component)this).transform.position, StartOfRound.Instance.elevatorTransform.position) < 25f)
			{
				waitOutsideShipTimer = Mathf.Min(waitOutsideShipTimer + Time.deltaTime, 20f);
			}
			if ((Object)(object)targetPlayer != (Object)null && Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position) < attackDistance + 6.5f)
			{
				LookAtPosition(((Component)targetPlayer).transform.position);
			}
			break;
		}
		case 2:
		{
			if (previousState != currentBehaviourStateIndex)
			{
				agent.speed = 0f;
				movingTowardsTargetPlayer = false;
				shootTongueTimer = 0f;
				spottedMeter = 0f;
				isHiding = false;
				failedTongueShoot = false;
				timeSinceChangingState = 0f;
				previousState = currentBehaviourStateIndex;
			}
			if ((Object)(object)targetPlayer == (Object)null)
			{
				break;
			}
			if (timeSinceKillingPlayer < 2f || timeSinceTakingDamage < 0.35f)
			{
				agent.speed = 0f;
				break;
			}
			inKillAnimation = false;
			if (((NetworkBehaviour)this).IsOwner)
			{
				LookAtPosition(((Component)targetPlayer).transform.position);
			}
			if (failedTongueShoot)
			{
				agent.speed = 0f;
				CancelReelingPlayerIn();
				if (((NetworkBehaviour)this).IsOwner && Time.realtimeSinceStartup - timeAtLastGrowl > 4f && Random.Range(0, 100) < 40)
				{
					DoGrowlLocalClient();
				}
				if (tongueLengthNormalized < -0.25f && ((NetworkBehaviour)this).IsOwner)
				{
					if (timesFailingTongueShoot >= 1)
					{
						SwitchToBehaviourState(0);
						break;
					}
					timesFailingTongueShoot++;
					SwitchToBehaviourState(1);
				}
				break;
			}
			VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
			if (targetPlayer.isPlayerDead || !targetPlayer.isPlayerControlled || Object.op_Implicit((Object)(object)targetPlayer.inAnimationWithEnemy) || stunNormalizedTimer > 0f || (targetPlayer.isInHangarShipRoom && StartOfRound.Instance.hangarDoorsClosed && !isInsidePlayerShip) || ((Object)(object)vehicleController != (Object)null && (Object)(object)targetPlayer.physicsParent != (Object)null && (Object)(object)targetPlayer.physicsParent == (Object)(object)((Component)vehicleController).transform && !vehicleController.backDoorOpen))
			{
				agent.speed = 0f;
				CancelReelingPlayerIn();
				if (((NetworkBehaviour)this).IsOwner && tongueLengthNormalized < -0.25f)
				{
					SwitchToBehaviourState(0);
				}
			}
			else if (dragging)
			{
				if (startedShootingTongue)
				{
					startedShootingTongue = false;
					shootTongueTimer = 0f;
					creatureVoice.clip = snarlSFX;
					creatureVoice.Play();
					draggingPlayer = targetPlayer;
					targetPlayer.disableInteract = true;
					timesFailingTongueShoot = 0;
					if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)targetPlayer)
					{
						targetPlayer.CancelSpecialTriggerAnimations();
						targetPlayer.DropAllHeldItemsAndSync();
					}
					CheckHomeBase();
				}
				if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)draggingPlayer)
				{
					draggingPlayer.shockingTarget = ((Component)this).transform;
				}
				agent.speed = 8f;
				Vector3 position = ((Component)targetPlayer).transform.position;
				position.y = ((Component)this).transform.position.y;
				float num = Vector3.Distance(((Component)this).transform.position, position);
				if (((NetworkBehaviour)this).IsOwner)
				{
					if ((num > 3f && shootTongueTimer < 1.3f) || num > attackDistance - 3f || (num > 4.2f && Physics.Linecast(tongueStartPoint.position, ((Component)tongueTarget).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)))
					{
						SetMovingTowardsTargetPlayer(draggingPlayer);
					}
					else
					{
						movingTowardsTargetPlayer = false;
						SetDestinationToPosition(currentHidingSpot);
					}
				}
				if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)targetPlayer)
				{
					GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(1f);
					creatureAnimator.SetBool("mouthOpen", Vector3.Distance(((Component)this).transform.position, currentHidingSpot) < 3f);
					if (num > 0.7f)
					{
						Vector3 val = ((Component)this).transform.position + ((Component)this).transform.forward * 2f + Vector3.up * 1.15f;
						float num2 = 1f;
						if (targetPlayer.activatingItem)
						{
							num2 = 1.35f;
						}
						if (targetPlayer.isInElevator && Vector3.Distance(((Component)targetPlayer).transform.position, StartOfRound.Instance.elevatorTransform.position) < 25f)
						{
							num2 = 1.7f;
						}
						Vector3 zero = Vector3.zero;
						timeSinceLOSBlocked = Mathf.Max(timeSinceLOSBlocked - Time.deltaTime, 0f);
						if (timeSinceLOSBlocked > 0f || targetPlayer.isInHangarShipRoom)
						{
							if (timeSinceLOSBlocked <= 0f)
							{
								timeSinceLOSBlocked = 0.5f;
							}
							if (targetPlayer.isInHangarShipRoom && ((Component)targetPlayer).transform.position.x < -14.3f && ((Component)targetPlayer).transform.position.x > -13.6f)
							{
								val = ((Component)targetPlayer).transform.position;
								val.z = StartOfRound.Instance.middleOfShipNode.position.z;
							}
							else
							{
								val = StartOfRound.Instance.middleOfSpaceNode.position;
							}
						}
						else if (randomForceInterval <= 0f)
						{
							Ray val2 = default(Ray);
							((Ray)(ref val2))._002Ector(((Component)targetPlayer).transform.position + Vector3.up * 0.4f, val - ((Component)targetPlayer).transform.position + Vector3.up * 0.4f);
							if (Physics.Raycast(val2, 0.8f, 268435456, (QueryTriggerInteraction)1))
							{
								randomForceInterval = 0.8f;
								PlayerControllerB playerControllerB = targetPlayer;
								playerControllerB.externalForceAutoFade += Vector3.up * 22f;
							}
							else if (Physics.Raycast(val2, 0.8f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
							{
								randomForceInterval = 0.32f;
								PlayerControllerB playerControllerB2 = targetPlayer;
								playerControllerB2.externalForceAutoFade += Random.onUnitSphere * 6f;
							}
							else
							{
								randomForceInterval = 0.45f;
							}
						}
						else
						{
							randomForceInterval -= Time.deltaTime;
						}
						zero += Vector3.Normalize((val - ((Component)targetPlayer).transform.position) * 1000f) * dragForce * num2 * Mathf.Clamp(shootTongueTimer / 2.5f, 1.15f, 2.55f);
						if (targetPlayer.isInElevator && !targetPlayer.isInHangarShipRoom && ((Component)targetPlayer).transform.position.x < -6f && ((Component)targetPlayer).transform.position.x > -9.1f && ((Component)targetPlayer).transform.position.z < -10.8f && ((Component)targetPlayer).transform.position.z > -17.3f)
						{
							zero.x = Mathf.Min(zero.x, 0f);
							zero = ((!(((Component)this).transform.position.z > ((Component)targetPlayer).transform.position.z)) ? (zero + Vector3.forward * -10f) : (zero + Vector3.forward * 10f));
						}
						zero.y = Mathf.Max(zero.y, 0f);
						if (num > attackDistance + 6f && shootTongueTimer > 1.6f)
						{
							SwitchToBehaviourState(1);
							break;
						}
						PlayerControllerB playerControllerB3 = targetPlayer;
						playerControllerB3.externalForces += zero;
						Debug.DrawRay(((Component)targetPlayer).transform.position, targetPlayer.externalForces, Color.red);
						Debug.DrawRay(((Component)targetPlayer).transform.position, targetPlayer.externalForceAutoFade, Color.blue);
					}
				}
				creatureAnimator.SetBool("ReelingPlayerIn", true);
				shootTongueTimer += Time.deltaTime;
				if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)targetPlayer)
				{
					tongueTarget = targetPlayer.upperSpineLocalPoint;
				}
				else
				{
					tongueTarget = targetPlayer.upperSpine;
				}
			}
			else if (!startedShootingTongue)
			{
				startedShootingTongue = true;
				creatureAnimator.SetBool("ShootTongue", true);
				creatureVoice.PlayOneShot(shootTongueSFX);
				tongueLengthNormalized = 0f;
			}
			else
			{
				if (timeSinceChangingState < 0.28f)
				{
					break;
				}
				if (!playedTongueAudio)
				{
					playedTongueAudio = true;
					tongueAudio.PlayOneShot(tongueShootSFX);
					tongueAudio.Play();
				}
				shootTongueTimer += Time.deltaTime;
				if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)(object)targetPlayer)
				{
					tongueTarget = targetPlayer.upperSpineLocalPoint;
				}
				else
				{
					tongueTarget = targetPlayer.upperSpine;
				}
				if (tongueLengthNormalized < 1f)
				{
					tongueLengthNormalized = Mathf.Min(tongueLengthNormalized + Time.deltaTime * 3f, 1f);
				}
				else if ((Object)(object)targetPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					if (!Physics.Linecast(tongueStartPoint.position, ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position - Vector3.up * 0.3f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) && Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) < attackDistance)
					{
						HitByEnemyServerRpc();
					}
					else
					{
						DodgedEnemyHitServerRpc();
					}
				}
				else if (shootTongueTimer > 3f)
				{
					TongueShootWasUnsuccessful();
				}
			}
			break;
		}
		}
	}

	private void TongueShootWasUnsuccessful()
	{
		shootTongueTimer = 0f;
		failedTongueShoot = true;
	}

	[ServerRpc(RequireOwnership = false)]
	public void HitByEnemyServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(909363089u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 909363089u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !failedTongueShoot)
			{
				HitByEnemyClientRpc();
			}
		}
	}

	[ClientRpc]
	public void HitByEnemyClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1849654675u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1849654675u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				dragging = true;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void DodgedEnemyHitServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3449188532u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3449188532u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DodgedEnemyHitClientRpc();
			}
		}
	}

	[ClientRpc]
	public void DodgedEnemyHitClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2800755590u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2800755590u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				TongueShootWasUnsuccessful();
			}
		}
	}

	private void LookAtPosition(Vector3 pos)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		looking = true;
		agent.updateRotation = false;
		pos.y = ((Component)this).transform.position.y;
		((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, Quaternion.LookRotation(pos - ((Component)this).transform.position, Vector3.up), 4f * Time.deltaTime);
	}

	public override void OnCollideWithEnemy(Collider other, EnemyAI collidedEnemy = null)
	{
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithEnemy(other, collidedEnemy);
		if (!((Object)(object)collidedEnemy.enemyType == (Object)(object)enemyType) && !(timeSinceHitting < 0.75f) && !dragging && !startedShootingTongue && !(stunNormalizedTimer > 0f) && !isEnemyDead)
		{
			timeSinceHitting = 0f;
			creatureAnimator.ResetTrigger("Hit");
			creatureAnimator.SetTrigger("Hit");
			creatureSFX.PlayOneShot(enemyType.audioClips[5]);
			WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[0]);
			RoundManager.Instance.PlayAudibleNoise(((Component)creatureSFX).transform.position, 8f, 0.6f);
			collidedEnemy.HitEnemy(1, null, playHitSFX: true);
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (foundSpawningPoint && !inKillAnimation && !isEnemyDead && (Object)(object)MeetsStandardPlayerCollisionConditions(other, inKillAnimation) != (Object)null)
		{
			float num = Vector3.Distance(((Component)this).transform.position, currentHidingSpot);
			bool flag = false;
			if (timeSinceTakingDamage < 2.5f && (Object)(object)lastHitByPlayer != (Object)null && num < 16f)
			{
				flag = true;
			}
			else if (num < 7f && dragging && !startedShootingTongue && (Object)(object)targetPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				flag = true;
			}
			if (flag)
			{
				GameNetworkManager.Instance.localPlayerController.KillPlayer(Vector3.up * 15f, spawnBody: true, CauseOfDeath.Mauling, 8);
				DoKillPlayerAnimationServerRpc((int)targetPlayer.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void DoKillPlayerAnimationServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3798199556u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3798199556u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DoKillPlayerAnimationClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void DoKillPlayerAnimationClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4279581158u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4279581158u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			creatureAnimator.SetTrigger("killPlayer");
			if ((Object)(object)StartOfRound.Instance.allPlayerScripts[playerId] == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				GameNetworkManager.Instance.localPlayerController.overrideGameOverSpectatePivot = playerAnimationHeadPoint;
			}
			timeSinceKillingPlayer = 0f;
			if (killPlayerCoroutine != null)
			{
				CancelKillAnimation();
			}
			inKillAnimation = true;
			growlAudio.PlayOneShot(killSFX);
			WalkieTalkie.TransmitOneShotAudio(growlAudio, killSFX);
			killPlayerCoroutine = ((MonoBehaviour)this).StartCoroutine(KillAnimationOnPlayer(StartOfRound.Instance.allPlayerScripts[playerId]));
		}
	}

	private void CancelKillAnimation()
	{
		if (inKillAnimation)
		{
			creatureAnimator.SetTrigger("cancelKillAnim");
			inKillAnimation = false;
		}
		DropBody();
		if (killPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(killPlayerCoroutine);
		}
	}

	private void DropBody()
	{
		if ((Object)(object)body != (Object)null)
		{
			body.matchPositionExactly = false;
			body.speedMultiplier = 12f;
			body.attachedTo = null;
			body.attachedLimb = null;
			body = null;
		}
	}

	private IEnumerator KillAnimationOnPlayer(PlayerControllerB player)
	{
		float time = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => Time.realtimeSinceStartup - time > 1f || (Object)(object)player.deadBody != (Object)null));
		if ((Object)(object)player.deadBody != (Object)null)
		{
			body = player.deadBody;
			body.matchPositionExactly = true;
			body.attachedTo = playerBodyHeadPoint;
			body.attachedLimb = player.deadBody.bodyParts[0];
		}
		yield return (object)new WaitForSeconds(0.25f);
		DropBody();
	}

	private void LateUpdate()
	{
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		AddProceduralOffsetToLimbsOverTerrain();
		if ((Object)(object)tongueTarget != (Object)null)
		{
			if (!((Component)tongue).gameObject.activeSelf)
			{
				((Component)tongue).gameObject.SetActive(true);
			}
			tongueLengthNormalized = Mathf.Min(tongueLengthNormalized + Time.deltaTime * 3f, 1f);
			if (tongueLengthNormalized < 1f || dragging)
			{
				Vector3 val = ((Component)tongueTarget).transform.position - tongueStartPoint.position;
				if (!dragging)
				{
					Ray val2 = default(Ray);
					((Ray)(ref val2))._002Ector(tongueStartPoint.position, val);
					val = ((!Physics.Raycast(val2, ref hit, attackDistance, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)) ? ((Ray)(ref val2)).GetPoint(attackDistance) : ((RaycastHit)(ref hit)).point);
				}
				else
				{
					val = ((Component)tongueTarget).transform.position;
				}
				tongue.position = tongueStartPoint.position;
				tongue.LookAt(val, Vector3.up);
				tongue.localScale = Vector3.Lerp(tongue.localScale, new Vector3(1f, 1f, Vector3.Distance(tongueStartPoint.position, tongueTarget.position)), tongueLengthNormalized);
			}
		}
		else
		{
			tongueLengthNormalized = Mathf.Max(tongueLengthNormalized - Time.deltaTime * 3f, -1f);
			if (tongueLengthNormalized > 0f)
			{
				tongue.position = tongueStartPoint.position;
				tongue.localScale = Vector3.Lerp(tongue.localScale, new Vector3(1f, 1f, 0.5f), tongueLengthNormalized);
			}
			else if (((Component)tongue).gameObject.activeSelf)
			{
				((Component)tongue).gameObject.SetActive(false);
			}
		}
	}

	private void CalculateAnimationDirection(float maxSpeed = 1f)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		agentLocalVelocity = animationContainer.InverseTransformDirection(Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 2f));
		hideBodyOnTerrain = ((Vector3)(ref agentLocalVelocity)).magnitude == 0f || isHiding;
		velX = Mathf.Lerp(velX, agentLocalVelocity.x, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("WalkX", Mathf.Clamp(velX, 0f - maxSpeed, maxSpeed));
		velZ = Mathf.Lerp(velZ, agentLocalVelocity.z, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("WalkZ", Mathf.Clamp(velZ, 0f - maxSpeed, maxSpeed));
		creatureAnimator.SetBool("idling", agentLocalVelocity.x == 0f && agentLocalVelocity.z == 0f);
		previousPosition = ((Component)this).transform.position;
	}

	private void AddProceduralOffsetToLimbsOverTerrain()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Unknown result type (might be due to invalid IL or missing references)
		//IL_038d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0397: Unknown result type (might be due to invalid IL or missing references)
		bool flag = stunNormalizedTimer < 0f && !dragging && !inKillAnimation && !isEnemyDead && timeSinceTakingDamage > 0.4f && matingCallTimer <= 0f;
		if (flag && Physics.Raycast(((Component)this).transform.position + Vector3.up * 1.25f, ((Component)this).transform.forward, ref hit, 3.15f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			bendHeadBack.weight = Mathf.Lerp(1f, 0f, ((RaycastHit)(ref hit)).distance / 3.15f);
		}
		else
		{
			bendHeadBack.weight = Mathf.Lerp(bendHeadBack.weight, 0f, Time.deltaTime * 5f);
		}
		if (resetIKOffsetsInterval < 0f || !hideBodyOnTerrain || !flag)
		{
			resetIKOffsetsInterval = 8f;
			for (int i = 0; i < proceduralBodyTargets.Length; i++)
			{
				proceduralBodyTargets[i].localPosition = Vector3.zero;
			}
			animationContainer.rotation = Quaternion.Lerp(animationContainer.rotation, ((Component)this).transform.rotation, 10f * Time.deltaTime);
			return;
		}
		resetIKOffsetsInterval -= Time.deltaTime;
		if (Physics.Raycast(((Component)this).transform.position + Vector3.up, Vector3.down, ref hit, 2f, 1073744129, (QueryTriggerInteraction)1) && Vector3.Angle(((RaycastHit)(ref hit)).normal, Vector3.up) < 75f)
		{
			Quaternion val = Quaternion.FromToRotation(animationContainer.up, ((RaycastHit)(ref hit)).normal) * ((Component)this).transform.rotation;
			animationContainer.rotation = Quaternion.Lerp(animationContainer.rotation, val, Time.deltaTime * 10f);
		}
		float num = 0f;
		for (int j = 0; j < proceduralBodyTargets.Length; j++)
		{
			if (j == 4 && currentBehaviourStateIndex == 2)
			{
				proceduralBodyTargets[j].localPosition = Vector3.zero;
				break;
			}
			if (Physics.Raycast(proceduralBodyTargets[j].position + ((Component)this).transform.up * 1.5f, -((Component)this).transform.up, ref hit, 5f, 1073744129, (QueryTriggerInteraction)1))
			{
				Debug.DrawRay(proceduralBodyTargets[j].position + ((Component)this).transform.up * 1.5f, -((Component)this).transform.up * 5f, Color.white);
				num = Mathf.Clamp(((RaycastHit)(ref hit)).point.y, ((Component)this).transform.position.y - 1.25f, ((Component)this).transform.position.y + 1.25f);
			}
			else
			{
				num = ((Component)this).transform.position.y;
			}
			if (j == 4)
			{
				proceduralBodyTargets[j].position = new Vector3(IKTargetContainers[j].position.x, Mathf.Lerp(proceduralBodyTargets[j].position.y, num + 0.4f, 40f * Time.deltaTime), IKTargetContainers[j].position.z);
			}
			else
			{
				proceduralBodyTargets[j].position = new Vector3(IKTargetContainers[j].position.x, Mathf.Lerp(proceduralBodyTargets[j].position.y, num, 40f * Time.deltaTime), IKTargetContainers[j].position.z);
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_BushWolfEnemy()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(4128579861u, new RpcReceiveHandler(__rpc_handler_4128579861));
		NetworkManager.__rpc_func_table.Add(3617357318u, new RpcReceiveHandler(__rpc_handler_3617357318));
		NetworkManager.__rpc_func_table.Add(2030618602u, new RpcReceiveHandler(__rpc_handler_2030618602));
		NetworkManager.__rpc_func_table.Add(445373695u, new RpcReceiveHandler(__rpc_handler_445373695));
		NetworkManager.__rpc_func_table.Add(1220991600u, new RpcReceiveHandler(__rpc_handler_1220991600));
		NetworkManager.__rpc_func_table.Add(1730122673u, new RpcReceiveHandler(__rpc_handler_1730122673));
		NetworkManager.__rpc_func_table.Add(2647215443u, new RpcReceiveHandler(__rpc_handler_2647215443));
		NetworkManager.__rpc_func_table.Add(1175673081u, new RpcReceiveHandler(__rpc_handler_1175673081));
		NetworkManager.__rpc_func_table.Add(610520803u, new RpcReceiveHandler(__rpc_handler_610520803));
		NetworkManager.__rpc_func_table.Add(2034052870u, new RpcReceiveHandler(__rpc_handler_2034052870));
		NetworkManager.__rpc_func_table.Add(788204480u, new RpcReceiveHandler(__rpc_handler_788204480));
		NetworkManager.__rpc_func_table.Add(237023778u, new RpcReceiveHandler(__rpc_handler_237023778));
		NetworkManager.__rpc_func_table.Add(1630339873u, new RpcReceiveHandler(__rpc_handler_1630339873));
		NetworkManager.__rpc_func_table.Add(905088005u, new RpcReceiveHandler(__rpc_handler_905088005));
		NetworkManager.__rpc_func_table.Add(4293930053u, new RpcReceiveHandler(__rpc_handler_4293930053));
		NetworkManager.__rpc_func_table.Add(1218980844u, new RpcReceiveHandler(__rpc_handler_1218980844));
		NetworkManager.__rpc_func_table.Add(909363089u, new RpcReceiveHandler(__rpc_handler_909363089));
		NetworkManager.__rpc_func_table.Add(1849654675u, new RpcReceiveHandler(__rpc_handler_1849654675));
		NetworkManager.__rpc_func_table.Add(3449188532u, new RpcReceiveHandler(__rpc_handler_3449188532));
		NetworkManager.__rpc_func_table.Add(2800755590u, new RpcReceiveHandler(__rpc_handler_2800755590));
		NetworkManager.__rpc_func_table.Add(3798199556u, new RpcReceiveHandler(__rpc_handler_3798199556));
		NetworkManager.__rpc_func_table.Add(4279581158u, new RpcReceiveHandler(__rpc_handler_4279581158));
	}

	private static void __rpc_handler_4128579861(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 hiddenPosition = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref hiddenPosition);
		Vector3 val = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref val);
		float nest = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref nest, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((BushWolfEnemy)(object)target).SyncWeedPositionsServerRpc(hiddenPosition, val, nest);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_3617357318(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 hiddenPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref hiddenPosition);
			Vector3 agg = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref agg);
			float nest = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref nest, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).SyncWeedPositionsClientRpc(hiddenPosition, agg, nest);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2030618602(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).SyncTargetPlayerAndAttackServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_445373695(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).SyncTargetPlayerAndAttackClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1220991600(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 newHidingSpot = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newHidingSpot);
			float nest = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref nest, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).SyncNewHidingSpotServerRpc(newHidingSpot, nest);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1730122673(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newHidingSpot = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newHidingSpot);
			float nest = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref nest, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).SyncNewHidingSpotClientRpc(newHidingSpot, nest);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2647215443(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float animationSpeedServerRpc = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref animationSpeedServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).SetAnimationSpeedServerRpc(animationSpeedServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1175673081(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float animationSpeedClientRpc = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref animationSpeedClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).SetAnimationSpeedClientRpc(animationSpeedClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_610520803(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).DoGrowlServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2034052870(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).DoGrowlClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_788204480(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).SeeBushWolfServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_237023778(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).SeeBushWolfClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1630339873(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoHit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoHit);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).HitTongueServerRpc(playerWhoHit);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_905088005(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoHit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoHit);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).HitTongueClientRpc(playerWhoHit);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4293930053(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).MatingCallServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1218980844(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).MatingCallClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_909363089(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).HitByEnemyServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1849654675(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).HitByEnemyClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3449188532(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).DodgedEnemyHitServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2800755590(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).DodgedEnemyHitClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3798199556(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BushWolfEnemy)(object)target).DoKillPlayerAnimationServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4279581158(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BushWolfEnemy)(object)target).DoKillPlayerAnimationClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "BushWolfEnemy";
	}
}
