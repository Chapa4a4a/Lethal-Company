using System.Collections;
using Unity.Netcode;
using UnityEngine;

public class ExtensionLadderItem : GrabbableObject
{
	private bool ladderActivated;

	private bool ladderAnimationBegun;

	private Coroutine ladderAnimationCoroutine;

	public Animator ladderAnimator;

	public Animator ladderRotateAnimator;

	public Transform baseNode;

	public Transform topNode;

	public Transform moveableNode;

	private RaycastHit hit;

	private int layerMask = 268437761;

	public AudioClip hitRoof;

	public AudioClip fullExtend;

	public AudioClip hitWall;

	public AudioClip ladderExtendSFX;

	public AudioClip ladderFallSFX;

	public AudioClip ladderShrinkSFX;

	public AudioClip blinkWarningSFX;

	public AudioClip lidOpenSFX;

	public AudioSource ladderAudio;

	public InteractTrigger ladderScript;

	private float rotateAmount;

	private float extendAmount;

	private float ladderTimer;

	private bool ladderBlinkWarning;

	private bool ladderShrunkAutomatically;

	public Collider interactCollider;

	public Collider bridgeCollider;

	public Collider killTrigger;

	public override void Update()
	{
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if ((Object)(object)playerHeldBy == (Object)null && !isHeld && !isHeldByEnemy && reachedFloorTarget && ladderActivated)
		{
			if (!ladderAnimationBegun)
			{
				ladderTimer = 0f;
				StartLadderAnimation();
			}
			else if (ladderAnimationBegun)
			{
				ladderTimer += Time.deltaTime;
				if (!ladderBlinkWarning && ladderTimer > 15f)
				{
					ladderBlinkWarning = true;
					ladderAnimator.SetBool("blinkWarning", true);
					ladderAudio.clip = blinkWarningSFX;
					ladderAudio.Play();
				}
				else if (ladderTimer >= 20f)
				{
					ladderActivated = false;
					ladderBlinkWarning = false;
					ladderAudio.Stop();
					ladderAnimator.SetBool("blinkWarning", false);
				}
			}
			return;
		}
		if (ladderAnimationBegun)
		{
			ladderAnimationBegun = false;
			ladderAudio.Stop();
			killTrigger.enabled = false;
			bridgeCollider.enabled = false;
			interactCollider.enabled = false;
			if (ladderAnimationCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(ladderAnimationCoroutine);
			}
			ladderAnimator.SetBool("blinkWarning", false);
			((Component)ladderAudio).transform.position = ((Component)this).transform.position;
			ladderAudio.PlayOneShot(ladderShrinkSFX);
			ladderActivated = false;
		}
		killTrigger.enabled = false;
		ladderScript.interactable = false;
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null && (Object)(object)GameNetworkManager.Instance.localPlayerController.currentTriggerInAnimationWith == (Object)(object)ladderScript)
		{
			ladderScript.CancelAnimationExternally();
		}
		if (rotateAmount > 0f)
		{
			rotateAmount = Mathf.Max(rotateAmount - Time.deltaTime * 2f, 0f);
			ladderRotateAnimator.SetFloat("rotationAmount", rotateAmount);
		}
		else
		{
			ladderRotateAnimator.SetFloat("rotationAmount", 0f);
		}
		if (extendAmount > 0f)
		{
			extendAmount = Mathf.Max(extendAmount - Time.deltaTime * 2f, 0f);
			ladderAnimator.SetFloat("extensionAmount", extendAmount);
		}
		else
		{
			ladderAnimator.SetBool("openLid", false);
			ladderAnimator.SetBool("extend", false);
			ladderAnimator.SetFloat("extensionAmount", 0f);
		}
	}

	private void StartLadderAnimation()
	{
		ladderAnimationBegun = true;
		ladderScript.interactable = false;
		if (ladderAnimationCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(ladderAnimationCoroutine);
		}
		ladderAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(LadderAnimation());
	}

	private IEnumerator LadderAnimation()
	{
		ladderAudio.volume = 1f;
		ladderScript.interactable = false;
		interactCollider.enabled = false;
		bridgeCollider.enabled = false;
		killTrigger.enabled = false;
		ladderAnimator.SetBool("openLid", false);
		ladderAnimator.SetBool("extend", false);
		yield return null;
		ladderAnimator.SetBool("openLid", true);
		((Component)ladderAudio).transform.position = ((Component)this).transform.position;
		ladderAudio.PlayOneShot(lidOpenSFX, 1f);
		RoundManager.Instance.PlayAudibleNoise(((Component)ladderAudio).transform.position, 18f, 0.8f, 0, isInShipRoom);
		yield return (object)new WaitForSeconds(1f);
		ladderAnimator.SetBool("extend", true);
		float ladderExtendAmountNormalized = GetLadderExtensionDistance() / 9.72f;
		float ladderRotateAmountNormalized = Mathf.Clamp(GetLadderRotationDegrees(ladderExtendAmountNormalized) / -90f, 0f, 0.99f);
		ladderAudio.clip = ladderExtendSFX;
		ladderAudio.Play();
		float currentNormalizedTime2 = 0f;
		float speedMultiplier2 = 0.1f;
		while (currentNormalizedTime2 < ladderExtendAmountNormalized)
		{
			speedMultiplier2 += Time.deltaTime * 2f;
			currentNormalizedTime2 = Mathf.Min(currentNormalizedTime2 + Time.deltaTime * speedMultiplier2, ladderExtendAmountNormalized);
			ladderAnimator.SetFloat("extensionAmount", currentNormalizedTime2);
			yield return null;
		}
		extendAmount = currentNormalizedTime2;
		interactCollider.enabled = true;
		bridgeCollider.enabled = false;
		killTrigger.enabled = false;
		ladderAudio.Stop();
		if (ladderExtendAmountNormalized == 1f)
		{
			((Component)ladderAudio).transform.position = ((Component)baseNode).transform.position + ((Component)baseNode).transform.up * 9.72f;
			ladderAudio.PlayOneShot(fullExtend, 0.7f);
			WalkieTalkie.TransmitOneShotAudio(ladderAudio, fullExtend, 0.7f);
			RoundManager.Instance.PlayAudibleNoise(((Component)ladderAudio).transform.position, 8f, 0.5f, 0, isInShipRoom);
		}
		else
		{
			((Component)ladderAudio).transform.position = ((Component)baseNode).transform.position + ((Component)baseNode).transform.up * (ladderExtendAmountNormalized * 9.72f);
			ladderAudio.PlayOneShot(hitRoof);
			WalkieTalkie.TransmitOneShotAudio(ladderAudio, hitRoof);
			RoundManager.Instance.PlayAudibleNoise(((Component)ladderAudio).transform.position, 17f, 0.8f, 0, isInShipRoom);
		}
		yield return (object)new WaitForSeconds(0.4f);
		ladderAudio.clip = ladderFallSFX;
		ladderAudio.Play();
		ladderAudio.volume = 0f;
		speedMultiplier2 = 0.15f;
		currentNormalizedTime2 = 0f;
		while (currentNormalizedTime2 < ladderRotateAmountNormalized)
		{
			speedMultiplier2 += Time.deltaTime * 2f;
			currentNormalizedTime2 = Mathf.Min(currentNormalizedTime2 + Time.deltaTime * speedMultiplier2, ladderRotateAmountNormalized);
			if (ladderExtendAmountNormalized > 0.6f && currentNormalizedTime2 > 0.5f)
			{
				killTrigger.enabled = true;
			}
			ladderAudio.volume = Mathf.Min(ladderAudio.volume + Time.deltaTime * 1.75f, 1f);
			ladderRotateAnimator.SetFloat("rotationAmount", currentNormalizedTime2);
			yield return null;
		}
		rotateAmount = ladderRotateAmountNormalized;
		ladderAudio.volume = 1f;
		ladderAudio.Stop();
		((Component)ladderAudio).transform.position = ((Component)moveableNode).transform.position;
		ladderAudio.PlayOneShot(hitWall, Mathf.Min(ladderRotateAmountNormalized + 0.3f, 1f));
		RoundManager.Instance.PlayAudibleNoise(((Component)ladderAudio).transform.position, 18f, 0.7f, 0, isInShipRoom);
		if (ladderRotateAmountNormalized * 90f < 45f)
		{
			ladderScript.interactable = true;
			interactCollider.enabled = true;
		}
		else
		{
			bridgeCollider.enabled = true;
		}
		killTrigger.enabled = false;
	}

	private float GetLadderExtensionDistance()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (Physics.Raycast(((Component)baseNode).transform.position, Vector3.up, ref hit, 9.72f, layerMask, (QueryTriggerInteraction)1))
		{
			return ((RaycastHit)(ref hit)).distance;
		}
		return 9.72f;
	}

	private float GetLadderRotationDegrees(float topOfLadder)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		float num = 90f;
		for (int num2 = 4; num2 >= 1; num2--)
		{
			float num3 = 2.43f * (float)num2;
			((Component)moveableNode).transform.localPosition = new Vector3(0f, num3, 0f);
			baseNode.localEulerAngles = Vector3.zero;
			for (int i = 1; i < 20; i++)
			{
				Vector3 position = ((Component)moveableNode).transform.position;
				baseNode.localEulerAngles = new Vector3((float)(-i) * 4.5f, 0f, 0f);
				if (Physics.Linecast(position, ((Component)moveableNode).transform.position, layerMask, (QueryTriggerInteraction)1))
				{
					float num4 = (float)(i - 1) * 4.5f;
					if (num4 < num)
					{
						num = num4;
					}
					break;
				}
			}
			if (num < 12f)
			{
				break;
			}
		}
		return 0f - num;
	}

	public override void DiscardItem()
	{
		base.DiscardItem();
	}

	public override void EquipItem()
	{
		base.EquipItem();
	}

	public override void DiscardItemFromEnemy()
	{
		base.DiscardItemFromEnemy();
		ladderActivated = true;
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		base.ItemActivate(used, buttonDown);
		ladderActivated = true;
		if (((NetworkBehaviour)this).IsOwner)
		{
			playerHeldBy.DiscardHeldObject();
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "ExtensionLadderItem";
	}
}
