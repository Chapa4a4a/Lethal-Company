using System;
using UnityEngine;

public class NoisemakerProp : GrabbableObject
{
	public AudioSource noiseAudio;

	public AudioSource noiseAudioFar;

	[Space(3f)]
	public AudioClip[] noiseSFX;

	public AudioClip[] noiseSFXFar;

	[Space(3f)]
	public float noiseRange;

	public float maxLoudness;

	public float minLoudness;

	public float minPitch;

	public float maxPitch;

	private Random noisemakerRandom;

	public Animator triggerAnimator;

	public override void Start()
	{
		base.Start();
		noisemakerRandom = new Random(StartOfRound.Instance.randomMapSeed + 85);
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		base.ItemActivate(used, buttonDown);
		if (!((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null))
		{
			int num = noisemakerRandom.Next(0, noiseSFX.Length);
			float num2 = (float)noisemakerRandom.Next((int)(minLoudness * 100f), (int)(maxLoudness * 100f)) / 100f;
			float pitch = (float)noisemakerRandom.Next((int)(minPitch * 100f), (int)(maxPitch * 100f)) / 100f;
			noiseAudio.pitch = pitch;
			noiseAudio.PlayOneShot(noiseSFX[num], num2);
			if ((Object)(object)noiseAudioFar != (Object)null)
			{
				noiseAudioFar.pitch = pitch;
				noiseAudioFar.PlayOneShot(noiseSFXFar[num], num2);
			}
			if ((Object)(object)triggerAnimator != (Object)null)
			{
				triggerAnimator.SetTrigger("playAnim");
			}
			WalkieTalkie.TransmitOneShotAudio(noiseAudio, noiseSFX[num], num2);
			RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, noiseRange, num2, 0, isInElevator && StartOfRound.Instance.hangarDoorsClosed);
			if (minLoudness >= 0.6f && (Object)(object)playerHeldBy != (Object)null)
			{
				playerHeldBy.timeSinceMakingLoudNoise = 0f;
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "NoisemakerProp";
	}
}
