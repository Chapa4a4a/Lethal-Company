using System.Collections;
using Unity.Netcode;
using UnityEngine;

public class ItemCharger : NetworkBehaviour
{
	public InteractTrigger triggerScript;

	public Animator chargeStationAnimator;

	private Coroutine chargeItemCoroutine;

	public AudioSource zapAudio;

	private float updateInterval;

	public void ChargeItem()
	{
		GrabbableObject currentlyHeldObjectServer = GameNetworkManager.Instance.localPlayerController.currentlyHeldObjectServer;
		if (!((Object)(object)currentlyHeldObjectServer == (Object)null) && currentlyHeldObjectServer.itemProperties.requiresBattery)
		{
			PlayChargeItemEffectServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			if (chargeItemCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(chargeItemCoroutine);
			}
			chargeItemCoroutine = ((MonoBehaviour)this).StartCoroutine(chargeItemDelayed(currentlyHeldObjectServer));
		}
	}

	private void Update()
	{
		if ((Object)(object)NetworkManager.Singleton == (Object)null)
		{
			return;
		}
		if (updateInterval > 1f)
		{
			updateInterval = 0f;
			if ((Object)(object)GameNetworkManager.Instance != (Object)null && (Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
			{
				triggerScript.interactable = (Object)(object)GameNetworkManager.Instance.localPlayerController.currentlyHeldObjectServer != (Object)null && GameNetworkManager.Instance.localPlayerController.currentlyHeldObjectServer.itemProperties.requiresBattery;
			}
		}
		else
		{
			updateInterval += Time.deltaTime;
		}
	}

	private IEnumerator chargeItemDelayed(GrabbableObject itemToCharge)
	{
		zapAudio.Play();
		yield return (object)new WaitForSeconds(0.75f);
		chargeStationAnimator.SetTrigger("zap");
		if ((Object)(object)itemToCharge != (Object)null)
		{
			itemToCharge.insertedBattery = new Battery(isEmpty: false, 1f);
			itemToCharge.SyncBatteryServerRpc(100);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PlayChargeItemEffectServerRpc(int playerChargingItem)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1188697655u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerChargingItem);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1188697655u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PlayChargeItemEffectClientRpc(playerChargingItem);
			}
		}
	}

	[ClientRpc]
	public void PlayChargeItemEffectClientRpc(int playerChargingItem)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3542355993u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerChargingItem);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3542355993u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerChargingItem)
		{
			if (chargeItemCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(chargeItemCoroutine);
			}
			chargeItemCoroutine = ((MonoBehaviour)this).StartCoroutine(chargeItemDelayed(null));
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ItemCharger()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1188697655u, new RpcReceiveHandler(__rpc_handler_1188697655));
		NetworkManager.__rpc_func_table.Add(3542355993u, new RpcReceiveHandler(__rpc_handler_3542355993));
	}

	private static void __rpc_handler_1188697655(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerChargingItem = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerChargingItem);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ItemCharger)(object)target).PlayChargeItemEffectServerRpc(playerChargingItem);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3542355993(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerChargingItem = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerChargingItem);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ItemCharger)(object)target).PlayChargeItemEffectClientRpc(playerChargingItem);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ItemCharger";
	}
}
