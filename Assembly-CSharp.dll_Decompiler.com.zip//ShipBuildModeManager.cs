using GameNetcodeStuff;
using TMPro;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.InputSystem;

public class ShipBuildModeManager : NetworkBehaviour
{
	public AudioClip beginPlacementSFX;

	public AudioClip denyPlacementSFX;

	public AudioClip cancelPlacementSFX;

	public AudioClip storeItemSFX;

	[Space(5f)]
	public bool InBuildMode;

	private bool CanConfirmPosition;

	private PlaceableShipObject placingObject;

	public Transform ghostObject;

	public MeshFilter ghostObjectMesh;

	public MeshRenderer ghostObjectRenderer;

	public MeshFilter selectionOutlineMesh;

	public MeshRenderer selectionOutlineRenderer;

	public Material ghostObjectGreen;

	public Material ghostObjectRed;

	private PlayerControllerB player;

	private int placeableShipObjectsMask = 67108864;

	private int placementMask = 2305;

	private int placementMaskAndBlockers = 134220033;

	private float timeSincePlacingObject;

	public PlayerActions playerActions;

	private RaycastHit rayHit;

	private Ray playerCameraRay;

	private BoxCollider currentCollider;

	private Collider[] collidersInPlacingObject;

	public static ShipBuildModeManager Instance { get; private set; }

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
			playerActions = new PlayerActions();
		}
		else
		{
			Object.Destroy((Object)(object)((Component)Instance).gameObject);
		}
	}

	private void OnEnable()
	{
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("BuildMode", false).performed += EnterBuildMode;
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("Delete", false).performed += StoreObject_performed;
		playerActions.Movement.Enable();
	}

	private void OnDisable()
	{
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("BuildMode", false).performed -= EnterBuildMode;
		IngamePlayerSettings.Instance.playerInput.actions.FindAction("Delete", false).performed -= StoreObject_performed;
		playerActions.Movement.Disable();
	}

	private Vector3 OffsetObjectFromWallBasedOnDimensions(Vector3 targetPosition, RaycastHit wall)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		if (placingObject.overrideWallOffset)
		{
			return ((RaycastHit)(ref wall)).point + ((RaycastHit)(ref wall)).normal * placingObject.wallOffset;
		}
		float num = (currentCollider.size.z / 2f + currentCollider.size.x / 2f) / 2f;
		return ((RaycastHit)(ref wall)).point + ((RaycastHit)(ref wall)).normal * (num + 0.01f);
	}

	private void Update()
	{
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0434: Unknown result type (might be due to invalid IL or missing references)
		//IL_0439: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_038e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0407: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		player = GameNetworkManager.Instance.localPlayerController;
		if (!PlayerMeetsConditionsToBuild(log: false))
		{
			CancelBuildMode();
		}
		if ((Object)(object)placingObject == (Object)null)
		{
			CancelBuildMode();
		}
		if (InBuildMode)
		{
			if ((Object)(object)currentCollider == (Object)null)
			{
				ref BoxCollider reference = ref currentCollider;
				Collider placeObjectCollider = placingObject.placeObjectCollider;
				reference = (BoxCollider)(object)((placeObjectCollider is BoxCollider) ? placeObjectCollider : null);
			}
			if (IngamePlayerSettings.Instance.playerInput.actions.FindAction("ReloadBatteries", false).IsPressed() || (StartOfRound.Instance.localPlayerUsingController && playerActions.Movement.InspectItem.IsPressed()))
			{
				ghostObject.eulerAngles = new Vector3(ghostObject.eulerAngles.x, ghostObject.eulerAngles.y + Time.deltaTime * 155f, ghostObject.eulerAngles.z);
			}
			playerCameraRay = new Ray(((Component)player.gameplayCamera).transform.position, ((Component)player.gameplayCamera).transform.forward);
			if (Physics.Raycast(playerCameraRay, ref rayHit, 4f, placementMask, (QueryTriggerInteraction)1))
			{
				if (Vector3.Angle(((RaycastHit)(ref rayHit)).normal, Vector3.up) < 45f)
				{
					ghostObject.position = ((RaycastHit)(ref rayHit)).point + Vector3.up * placingObject.yOffset;
				}
				else if (placingObject.AllowPlacementOnWalls)
				{
					ghostObject.position = OffsetObjectFromWallBasedOnDimensions(((RaycastHit)(ref rayHit)).point, rayHit);
					if (Physics.Raycast(ghostObject.position, Vector3.down, ref rayHit, placingObject.yOffset, placementMask, (QueryTriggerInteraction)1))
					{
						ghostObject.position += Vector3.up * ((RaycastHit)(ref rayHit)).distance;
					}
				}
				else if (Physics.Raycast(OffsetObjectFromWallBasedOnDimensions(((RaycastHit)(ref rayHit)).point, rayHit), Vector3.down, ref rayHit, 20f, placementMask, (QueryTriggerInteraction)1))
				{
					ghostObject.position = ((RaycastHit)(ref rayHit)).point + Vector3.up * placingObject.yOffset;
				}
			}
			else if (Physics.Raycast(((Ray)(ref playerCameraRay)).GetPoint(4f), Vector3.down, ref rayHit, 20f, placementMask, (QueryTriggerInteraction)1))
			{
				ghostObject.position = ((RaycastHit)(ref rayHit)).point + Vector3.up * placingObject.yOffset;
			}
			bool flag = Physics.CheckBox(ghostObject.position, currentCollider.size * 0.5f * 0.57f, Quaternion.Euler(ghostObject.eulerAngles), placementMaskAndBlockers, (QueryTriggerInteraction)1);
			if (!flag && placingObject.doCollisionPointCheck)
			{
				Vector3 val = ghostObject.position + ghostObject.forward * placingObject.collisionPointCheck.z + ghostObject.right * placingObject.collisionPointCheck.x + ghostObject.up * placingObject.collisionPointCheck.y;
				Debug.DrawRay(val, Vector3.up * 2f, Color.blue);
				if (Physics.CheckSphere(val, 1f, placementMaskAndBlockers, (QueryTriggerInteraction)1))
				{
					flag = true;
				}
			}
			int canConfirmPosition;
			if (!flag)
			{
				Bounds bounds = StartOfRound.Instance.shipInnerRoomBounds.bounds;
				canConfirmPosition = (((Bounds)(ref bounds)).Contains(ghostObject.position) ? 1 : 0);
			}
			else
			{
				canConfirmPosition = 0;
			}
			CanConfirmPosition = (byte)canConfirmPosition != 0;
			if (flag)
			{
				((Renderer)ghostObjectRenderer).sharedMaterial = ghostObjectRed;
			}
			else
			{
				((Renderer)ghostObjectRenderer).sharedMaterial = ghostObjectGreen;
			}
		}
		else
		{
			timeSincePlacingObject += Time.deltaTime;
		}
	}

	private bool PlayerMeetsConditionsToBuild(bool log = true)
	{
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		if (InBuildMode && ((Object)(object)placingObject == (Object)null || placingObject.inUse || StartOfRound.Instance.unlockablesList.unlockables[placingObject.unlockableID].inStorage))
		{
			if (log)
			{
				Debug.Log((object)"Could not build 1");
			}
			return false;
		}
		if (GameNetworkManager.Instance.localPlayerController.isTypingChat)
		{
			if (log)
			{
				Debug.Log((object)"Could not build 2");
			}
			return false;
		}
		if (player.isPlayerDead || player.inSpecialInteractAnimation || player.activatingItem)
		{
			if (log)
			{
				Debug.Log((object)"Could not build 3");
			}
			return false;
		}
		if (player.disablingJetpackControls || player.jetpackControls)
		{
			if (log)
			{
				Debug.Log((object)"Could not build 4");
			}
			return false;
		}
		if (!player.isInHangarShipRoom)
		{
			if (log)
			{
				Debug.Log((object)"Could not build 5");
			}
			return false;
		}
		if (StartOfRound.Instance.fearLevel > 0.4f)
		{
			if (log)
			{
				Debug.Log((object)"Could not build 6");
			}
			return false;
		}
		AnimatorStateInfo currentAnimatorStateInfo = StartOfRound.Instance.shipAnimator.GetCurrentAnimatorStateInfo(0);
		if (((AnimatorStateInfo)(ref currentAnimatorStateInfo)).tagHash != Animator.StringToHash("ShipIdle"))
		{
			if (log)
			{
				Debug.Log((object)"Could not build 7");
			}
			return false;
		}
		if (!StartOfRound.Instance.inShipPhase && !StartOfRound.Instance.shipHasLanded)
		{
			if (log)
			{
				Debug.Log((object)"Could not build 7b");
			}
			return false;
		}
		return true;
	}

	private void EnterBuildMode(CallbackContext context)
	{
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		if (!((CallbackContext)(ref context)).performed || (Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null || GameNetworkManager.Instance.localPlayerController.isTypingChat)
		{
			return;
		}
		if (InBuildMode)
		{
			if (!(timeSincePlacingObject <= 1f) && PlayerMeetsConditionsToBuild())
			{
				if (!CanConfirmPosition)
				{
					HUDManager.Instance.UIAudio.PlayOneShot(denyPlacementSFX);
					return;
				}
				timeSincePlacingObject = 0f;
				Debug.DrawRay(ghostObject.position, Vector3.up * 1.5f, Color.green, 2f);
				PlaceShipObject(ghostObject.position, ghostObject.eulerAngles, placingObject);
				CancelBuildMode(cancelBeforePlacement: false);
				PlaceShipObjectServerRpc(ghostObject.position, ghostObject.eulerAngles, NetworkObjectReference.op_Implicit(((Component)placingObject.parentObject).GetComponent<NetworkObject>()), (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
			return;
		}
		player = GameNetworkManager.Instance.localPlayerController;
		if (!PlayerMeetsConditionsToBuild() || (!Physics.Raycast(((Component)player.gameplayCamera).transform.position, ((Component)player.gameplayCamera).transform.forward, ref rayHit, 4f, placeableShipObjectsMask, (QueryTriggerInteraction)1) && !Physics.Raycast(((Component)player.gameplayCamera).transform.position + Vector3.up * 5f, Vector3.down, ref rayHit, 5f, placeableShipObjectsMask, (QueryTriggerInteraction)1)) || !((Component)((RaycastHit)(ref rayHit)).collider).gameObject.CompareTag("PlaceableObject"))
		{
			return;
		}
		PlaceableShipObject component = ((Component)((RaycastHit)(ref rayHit)).collider).gameObject.GetComponent<PlaceableShipObject>();
		if ((Object)(object)component == (Object)null)
		{
			return;
		}
		if (timeSincePlacingObject <= 1f)
		{
			HUDManager.Instance.UIAudio.PlayOneShot(denyPlacementSFX);
			return;
		}
		placingObject = component;
		collidersInPlacingObject = ((Component)placingObject.parentObject).GetComponentsInChildren<Collider>();
		for (int i = 0; i < collidersInPlacingObject.Length; i++)
		{
			if (!((Component)collidersInPlacingObject[i]).CompareTag("DoNotSet") && !((Component)collidersInPlacingObject[i]).CompareTag("InteractTrigger"))
			{
				collidersInPlacingObject[i].enabled = false;
			}
		}
		InBuildMode = true;
		CreateGhostObjectAndHighlight();
	}

	private void CreateGhostObjectAndHighlight()
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)placingObject == (Object)null))
		{
			((Behaviour)HUDManager.Instance.buildModeControlTip).enabled = true;
			if (StartOfRound.Instance.localPlayerUsingController)
			{
				((TMP_Text)HUDManager.Instance.buildModeControlTip).text = "Confirm: [Y]   |   Rotate: [L-shoulder]   |   Store: [B]";
			}
			else
			{
				((TMP_Text)HUDManager.Instance.buildModeControlTip).text = "Confirm: [B]   |   Rotate: [R]   |   Store: [X]";
			}
			HUDManager.Instance.UIAudio.PlayOneShot(beginPlacementSFX);
			((Component)ghostObject).transform.eulerAngles = ((Component)placingObject.mainMesh).transform.eulerAngles;
			ghostObjectMesh.mesh = placingObject.mainMesh.mesh;
			((Component)ghostObjectMesh).transform.localScale = Vector3.Scale(((Component)placingObject.mainMesh).transform.localScale, ((Component)placingObject.parentObject).transform.localScale);
			((Component)ghostObjectMesh).transform.position = ghostObject.position + (((Component)placingObject.mainMesh).transform.position - ((Component)placingObject.placeObjectCollider).transform.position);
			((Component)ghostObjectMesh).transform.localEulerAngles = Vector3.zero;
			((Renderer)ghostObjectRenderer).enabled = true;
			selectionOutlineMesh.mesh = placingObject.mainMesh.mesh;
			((Component)selectionOutlineMesh).transform.localScale = Vector3.Scale(((Component)placingObject.mainMesh).transform.localScale, ((Component)placingObject.parentObject).transform.localScale);
			((Component)selectionOutlineMesh).transform.localScale = ((Component)selectionOutlineMesh).transform.localScale * 1.04f;
			((Component)selectionOutlineMesh).transform.position = ((Component)placingObject.mainMesh).transform.position;
			((Component)selectionOutlineMesh).transform.eulerAngles = ((Component)placingObject.mainMesh).transform.eulerAngles;
			((Renderer)selectionOutlineRenderer).enabled = true;
		}
	}

	public void CancelBuildMode(bool cancelBeforePlacement = true)
	{
		if (!InBuildMode)
		{
			return;
		}
		InBuildMode = false;
		if (cancelBeforePlacement)
		{
			HUDManager.Instance.UIAudio.PlayOneShot(cancelPlacementSFX);
		}
		if ((Object)(object)placingObject != (Object)null && collidersInPlacingObject != null)
		{
			for (int i = 0; i < collidersInPlacingObject.Length; i++)
			{
				if (!((Object)(object)collidersInPlacingObject[i] == (Object)null) && !((Component)collidersInPlacingObject[i]).CompareTag("DoNotSet") && !((Component)collidersInPlacingObject[i]).CompareTag("InteractTrigger"))
				{
					collidersInPlacingObject[i].enabled = true;
				}
			}
		}
		if ((Object)(object)currentCollider != (Object)null)
		{
			((Collider)currentCollider).enabled = true;
		}
		currentCollider = null;
		((Behaviour)HUDManager.Instance.buildModeControlTip).enabled = false;
		((Renderer)ghostObjectRenderer).enabled = false;
		((Renderer)selectionOutlineRenderer).enabled = false;
	}

	private void ConfirmBuildMode_performed(CallbackContext context)
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		if (((CallbackContext)(ref context)).performed && !(timeSincePlacingObject <= 1f) && PlayerMeetsConditionsToBuild() && InBuildMode)
		{
			if (!CanConfirmPosition)
			{
				HUDManager.Instance.UIAudio.PlayOneShot(denyPlacementSFX);
				return;
			}
			timeSincePlacingObject = 0f;
			PlaceShipObject(ghostObject.position, ghostObject.eulerAngles, placingObject);
			CancelBuildMode(cancelBeforePlacement: false);
			PlaceShipObjectServerRpc(ghostObject.position, ghostObject.eulerAngles, NetworkObjectReference.op_Implicit(((Component)placingObject.parentObject).GetComponent<NetworkObject>()), (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PlaceShipObjectServerRpc(Vector3 newPosition, Vector3 newRotation, NetworkObjectReference objectRef, int playerWhoMoved)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(861494715u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newRotation);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, playerWhoMoved);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 861494715u, val, (RpcDelivery)0);
		}
		NetworkObject val3 = default(NetworkObject);
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && ((NetworkObjectReference)(ref objectRef)).TryGet(ref val3, (NetworkManager)null))
		{
			PlaceableShipObject componentInChildren = ((Component)val3).gameObject.GetComponentInChildren<PlaceableShipObject>();
			if ((Object)(object)componentInChildren != (Object)null && !StartOfRound.Instance.unlockablesList.unlockables[componentInChildren.unlockableID].inStorage)
			{
				PlaceShipObjectClientRpc(newPosition, newRotation, objectRef, playerWhoMoved);
			}
			else
			{
				Debug.Log((object)$"Error! Object was in storage on server. object id: {val3.NetworkObjectId}; name: {((Object)((Component)val3).gameObject).name}");
			}
		}
	}

	[ClientRpc]
	public void PlaceShipObjectClientRpc(Vector3 newPosition, Vector3 newRotation, NetworkObjectReference objectRef, int playerWhoMoved)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1606360774u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref newRotation);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, playerWhoMoved);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1606360774u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || (Object)(object)NetworkManager.Singleton == (Object)null || ((NetworkBehaviour)this).NetworkManager.ShutdownInProgress || (Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)StartOfRound.Instance == (Object)null || ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null && playerWhoMoved == (int)GameNetworkManager.Instance.localPlayerController.playerClientId))
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref objectRef)).TryGet(ref val3, (NetworkManager)null))
		{
			if ((Object)(object)val3 == (Object)null)
			{
				Debug.Log((object)$"Error! Could not get network object with id: {((NetworkObjectReference)(ref objectRef)).NetworkObjectId} in placeshipobjectClientRpc");
				return;
			}
			PlaceableShipObject componentInChildren = ((Component)val3).GetComponentInChildren<PlaceableShipObject>();
			if ((Object)(object)componentInChildren != (Object)null && !StartOfRound.Instance.unlockablesList.unlockables[componentInChildren.unlockableID].inStorage)
			{
				PlaceShipObject(newPosition, newRotation, componentInChildren);
			}
			else
			{
				Debug.Log((object)$"Error! Object was in storage on client. object id: {val3.NetworkObjectId}; name: {((Object)((Component)val3).gameObject).name}");
			}
		}
		else
		{
			Debug.Log((object)$"Error! Could not get network object with id: {((NetworkObjectReference)(ref objectRef)).NetworkObjectId} in placeshipobjectClientRpc");
		}
	}

	private void StoreObject_performed(CallbackContext context)
	{
		if (((CallbackContext)(ref context)).performed)
		{
			StoreObjectLocalClient();
		}
	}

	public void StoreObjectLocalClient()
	{
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		if (!(timeSincePlacingObject <= 0.25f) && InBuildMode && !((Object)(object)placingObject == (Object)null) && StartOfRound.Instance.unlockablesList.unlockables[placingObject.unlockableID].canBeStored)
		{
			bool num = Object.op_Implicit((Object)(object)((Component)placingObject.parentObject).gameObject.GetComponentInChildren<GrabbableObject>());
			HUDManager.Instance.UIAudio.PlayOneShot(storeItemSFX);
			CancelBuildMode(cancelBeforePlacement: false);
			if (num)
			{
				HUDManager.Instance.DisplayTip("Cannot store!", "This furniture contains scrap.");
				return;
			}
			if (StartOfRound.Instance.unlockablesList.unlockables[placingObject.unlockableID].inStorage)
			{
				Debug.Log((object)("Cannot store " + StartOfRound.Instance.unlockablesList.unlockables[placingObject.unlockableID].unlockableName + "; already in storage."));
				return;
			}
			timeSincePlacingObject = 0f;
			StoreObjectServerRpc(NetworkObjectReference.op_Implicit(((Component)placingObject.parentObject).GetComponent<NetworkObject>()), (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StoreObjectServerRpc(NetworkObjectReference objectRef, int playerWhoStored)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3086821980u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, playerWhoStored);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3086821980u, val, (RpcDelivery)0);
		}
		NetworkObject val3 = default(NetworkObject);
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost) || !((NetworkObjectReference)(ref objectRef)).TryGet(ref val3, (NetworkManager)null))
		{
			return;
		}
		PlaceableShipObject componentInChildren = ((Component)val3).gameObject.GetComponentInChildren<PlaceableShipObject>();
		bool flag = Object.op_Implicit((Object)(object)((Component)val3).gameObject.GetComponentInChildren<GrabbableObject>());
		if ((Object)(object)componentInChildren != (Object)null && !StartOfRound.Instance.unlockablesList.unlockables[componentInChildren.unlockableID].inStorage && !flag && Time.realtimeSinceStartup - componentInChildren.lastTimeScrapWasPlaced > 6f && StartOfRound.Instance.unlockablesList.unlockables[componentInChildren.unlockableID].canBeStored)
		{
			if (TimeOfDay.Instance.furniturePlacedAtQuotaStart.Contains(componentInChildren.unlockableID))
			{
				TimeOfDay.Instance.furniturePlacedAtQuotaStart.Remove(componentInChildren.unlockableID);
			}
			StartOfRound.Instance.unlockablesList.unlockables[componentInChildren.unlockableID].inStorage = true;
			StoreShipObjectClientRpc(objectRef, playerWhoStored, componentInChildren.unlockableID);
			if (!StartOfRound.Instance.unlockablesList.unlockables[componentInChildren.unlockableID].spawnPrefab)
			{
				componentInChildren.parentObject.disableObject = true;
				Debug.Log((object)"DISABLE OBJECT D");
			}
			else if (val3.IsSpawned)
			{
				val3.Despawn(true);
				Debug.Log((object)$"despawning object. IsSpawned? : {val3.IsSpawned}");
			}
			if (StartOfRound.Instance.SpawnedShipUnlockables.ContainsKey(componentInChildren.unlockableID))
			{
				StartOfRound.Instance.SpawnedShipUnlockables.Remove(componentInChildren.unlockableID);
			}
		}
	}

	[ClientRpc]
	public void StoreShipObjectClientRpc(NetworkObjectReference objectRef, int playerWhoStored, int unlockableID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2797045448u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, playerWhoStored);
			BytePacker.WriteValueBitPacked(val2, unlockableID);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2797045448u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || (Object)(object)NetworkManager.Singleton == (Object)null || ((NetworkBehaviour)this).NetworkManager.ShutdownInProgress || ((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (playerWhoStored == (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
		{
			HUDManager.Instance.DisplayTip("Item stored!", "You can see stored items in the terminal by using command 'STORAGE'", isWarning: false, useSave: true, "LC_StorageTip");
		}
		StartOfRound.Instance.unlockablesList.unlockables[unlockableID].inStorage = true;
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref objectRef)).TryGet(ref val3, (NetworkManager)null))
		{
			PlaceableShipObject componentInChildren = ((Component)val3).GetComponentInChildren<PlaceableShipObject>();
			if ((Object)(object)componentInChildren != (Object)null && !StartOfRound.Instance.unlockablesList.unlockables[unlockableID].spawnPrefab)
			{
				componentInChildren.parentObject.disableObject = true;
				Debug.Log((object)"DISABLE OBJECT E");
			}
		}
	}

	public void PlaceShipObject(Vector3 placementPosition, Vector3 placementRotation, PlaceableShipObject placeableObject, bool placementSFX = true)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		_ = placeableObject.parentObject.rotationOffset;
		StartOfRound.Instance.suckingFurnitureOutOfShip = false;
		StartOfRound.Instance.unlockablesList.unlockables[placeableObject.unlockableID].placedPosition = placementPosition;
		StartOfRound.Instance.unlockablesList.unlockables[placeableObject.unlockableID].placedRotation = placementRotation;
		Debug.Log((object)$"Saving placed position as: {placementPosition}");
		StartOfRound.Instance.unlockablesList.unlockables[placeableObject.unlockableID].hasBeenMoved = true;
		if ((Object)(object)placeableObject.parentObjectSecondary != (Object)null)
		{
			_ = ((Component)placeableObject.parentObjectSecondary).transform.position;
			_ = ((Component)placeableObject.parentObjectSecondary).transform.rotation;
			Quaternion val = Quaternion.Euler(placementRotation) * Quaternion.Inverse(((Component)placeableObject.mainMesh).transform.rotation);
			((Component)placeableObject.parentObjectSecondary).transform.rotation = val * ((Component)placeableObject.parentObjectSecondary).transform.rotation;
			placeableObject.parentObjectSecondary.position = placementPosition + (((Component)placeableObject.parentObjectSecondary).transform.position - ((Component)placeableObject.mainMesh).transform.position) + (((Component)placeableObject.mainMesh).transform.position - ((Component)placeableObject.placeObjectCollider).transform.position);
		}
		else if ((Object)(object)placeableObject.parentObject != (Object)null)
		{
			_ = placeableObject.parentObject.positionOffset;
			_ = ((Component)placeableObject.parentObject).transform.rotation;
			Quaternion val2 = Quaternion.Euler(placementRotation) * Quaternion.Inverse(((Component)placeableObject.mainMesh).transform.rotation);
			AutoParentToShip parentObject = placeableObject.parentObject;
			Quaternion val3 = val2 * ((Component)placeableObject.parentObject).transform.rotation;
			parentObject.rotationOffset = ((Quaternion)(ref val3)).eulerAngles;
			((Component)placeableObject.parentObject).transform.rotation = val2 * ((Component)placeableObject.parentObject).transform.rotation;
			placeableObject.parentObject.positionOffset = StartOfRound.Instance.elevatorTransform.InverseTransformPoint(placementPosition + (((Component)placeableObject.parentObject).transform.position - ((Component)placeableObject.mainMesh).transform.position) + (((Component)placeableObject.mainMesh).transform.position - ((Component)placeableObject.placeObjectCollider).transform.position));
		}
		if (placementSFX)
		{
			((Component)placeableObject).GetComponent<AudioSource>().PlayOneShot(placeableObject.placeObjectSFX);
		}
	}

	public void ResetShipObjectToDefaultPosition(PlaceableShipObject placeableObject)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		StartOfRound.Instance.unlockablesList.unlockables[placeableObject.unlockableID].placedPosition = Vector3.zero;
		StartOfRound.Instance.unlockablesList.unlockables[placeableObject.unlockableID].placedRotation = Vector3.zero;
		StartOfRound.Instance.unlockablesList.unlockables[placeableObject.unlockableID].hasBeenMoved = false;
		if ((Object)(object)placeableObject.parentObjectSecondary != (Object)null)
		{
			((Component)placeableObject.parentObjectSecondary).transform.eulerAngles = placeableObject.parentObject.startingRotation;
			placeableObject.parentObjectSecondary.position = placeableObject.parentObject.startingPosition;
		}
		else if ((Object)(object)placeableObject.parentObject != (Object)null)
		{
			placeableObject.parentObject.rotationOffset = placeableObject.parentObject.startingRotation;
			placeableObject.parentObject.positionOffset = placeableObject.parentObject.startingPosition;
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ShipBuildModeManager()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(861494715u, new RpcReceiveHandler(__rpc_handler_861494715));
		NetworkManager.__rpc_func_table.Add(1606360774u, new RpcReceiveHandler(__rpc_handler_1606360774));
		NetworkManager.__rpc_func_table.Add(3086821980u, new RpcReceiveHandler(__rpc_handler_3086821980));
		NetworkManager.__rpc_func_table.Add(2797045448u, new RpcReceiveHandler(__rpc_handler_2797045448));
	}

	private static void __rpc_handler_861494715(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newPosition);
			Vector3 newRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newRotation);
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			int playerWhoMoved = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoMoved);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShipBuildModeManager)(object)target).PlaceShipObjectServerRpc(newPosition, newRotation, objectRef, playerWhoMoved);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1606360774(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 newPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newPosition);
			Vector3 newRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref newRotation);
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			int playerWhoMoved = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoMoved);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShipBuildModeManager)(object)target).PlaceShipObjectClientRpc(newPosition, newRotation, objectRef, playerWhoMoved);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3086821980(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			int playerWhoStored = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoStored);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShipBuildModeManager)(object)target).StoreObjectServerRpc(objectRef, playerWhoStored);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2797045448(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference objectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref objectRef, default(ForNetworkSerializable));
			int playerWhoStored = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoStored);
			int unlockableID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref unlockableID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShipBuildModeManager)(object)target).StoreShipObjectClientRpc(objectRef, playerWhoStored, unlockableID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ShipBuildModeManager";
	}
}
