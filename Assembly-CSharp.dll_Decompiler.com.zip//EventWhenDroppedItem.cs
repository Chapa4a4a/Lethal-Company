using System;
using UnityEngine;

public class EventWhenDroppedItem : GrabbableObject
{
	public float noiseLoudness;

	public float noiseRange;

	[Space(3f)]
	private int timesPlayedInSameSpot;

	private Vector3 lastPositionDropped;

	public float lastPositionDroppedThresholdDistance = 25f;

	public int effectWearOffMultiplier = 1;

	public AudioSource itemAudio;

	private Random bellPitchRandom;

	public override void Start()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		bellPitchRandom = new Random((int)(((Component)this).transform.position.x + ((Component)this).transform.position.z));
	}

	public override void PlayDropSFX()
	{
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)itemProperties.dropSFX != (Object)null)
		{
			itemAudio.pitch = 1f;
			switch (bellPitchRandom.Next(0, 7))
			{
			case 1:
			{
				AudioSource obj6 = itemAudio;
				obj6.pitch *= Mathf.Pow(1.05946f, 3f);
				break;
			}
			case 2:
			{
				AudioSource obj5 = itemAudio;
				obj5.pitch *= Mathf.Pow(1.05946f, 5f);
				break;
			}
			case 3:
			{
				AudioSource obj4 = itemAudio;
				obj4.pitch /= Mathf.Pow(1.05946f, 3f);
				break;
			}
			case 4:
			{
				AudioSource obj3 = itemAudio;
				obj3.pitch /= Mathf.Pow(1.05946f, 5f);
				break;
			}
			case 5:
			{
				AudioSource obj2 = itemAudio;
				obj2.pitch /= Mathf.Pow(1.05946f, 7f);
				break;
			}
			case 6:
			{
				AudioSource obj = itemAudio;
				obj.pitch /= Mathf.Pow(1.05946f, 10f);
				break;
			}
			}
			itemAudio.PlayOneShot(itemProperties.dropSFX);
			WalkieTalkie.TransmitOneShotAudio(itemAudio, itemProperties.dropSFX);
			RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, noiseRange, noiseLoudness, timesPlayedInSameSpot, isInElevator && StartOfRound.Instance.hangarDoorsClosed, 941);
			if (Vector3.Distance(((Component)this).transform.position, lastPositionDropped) < lastPositionDroppedThresholdDistance)
			{
				timesPlayedInSameSpot += effectWearOffMultiplier;
			}
			else
			{
				timesPlayedInSameSpot = 0;
			}
		}
		hasHitGround = true;
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "EventWhenDroppedItem";
	}
}
