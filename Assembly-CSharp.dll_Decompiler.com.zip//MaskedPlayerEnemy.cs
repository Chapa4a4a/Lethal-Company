using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Animations.Rigging;

public class MaskedPlayerEnemy : EnemyAI, IVisibleThreat
{
	public SkinnedMeshRenderer rendererLOD0;

	public SkinnedMeshRenderer rendererLOD1;

	public SkinnedMeshRenderer rendererLOD2;

	private Ray enemyRay;

	private RaycastHit enemyRayHit;

	private int currentFootstepSurfaceIndex;

	private int previousFootstepClip;

	public AudioSource movementAudio;

	private bool sprinting;

	private int previousBehaviourState = -1;

	public float walkCheckInterval;

	private Vector3 positionLastCheck;

	private Coroutine teleportCoroutine;

	public ParticleSystem teleportParticle;

	public AISearchRoutine searchForPlayers;

	private Vector3 agentLocalVelocity;

	private Vector3 previousPosition;

	private float velX;

	private float velZ;

	public Transform animationContainer;

	private Vector3 currentRandomLookDirection;

	private Vector3 focusOnPosition;

	private float verticalLookAngle;

	private float currentLookAngle;

	public Transform headTiltTarget;

	private float lookAtPositionTimer;

	private float randomLookTimer;

	private bool lostPlayerInChase;

	private float lostLOSTimer;

	private bool running;

	private bool crouching;

	[Space(3f)]
	public PlayerControllerB mimickingPlayer;

	public bool allowSpawningWithoutPlayer;

	[Space(3f)]
	public Transform lerpTarget;

	public float turnSpeedMultiplier;

	public MultiRotationConstraint lookRig1;

	public MultiRotationConstraint lookRig2;

	private float stopAndStareTimer;

	public Transform stareAtTransform;

	private bool handsOut;

	private bool inKillAnimation;

	public bool startingKillAnimationLocalClient;

	private Coroutine killAnimationCoroutine;

	private Ray playerRay;

	public MeshRenderer[] maskEyesGlow;

	public Light maskEyesGlowLight;

	public ParticleSystem maskFloodParticle;

	private PlayerControllerB lastPlayerKilled;

	private float timeLookingAtLastNoise;

	private Vector3 shipHidingSpot;

	private float staminaTimer;

	private bool runningRandomly;

	private bool enemyEnabled;

	public GameObject[] maskTypes;

	public int maskTypeIndex;

	private Vector3 mainEntrancePosition;

	private float timeAtLastUsingEntrance;

	private float interestInShipCooldown;

	private List<int> playersKilled = new List<int>();

	private bool isInElevatorStartRoom;

	private MineshaftElevatorController elevatorScript;

	public Transform headTransform;

	ThreatType IVisibleThreat.type => ThreatType.RadMech;

	bool IVisibleThreat.IsThreatDead()
	{
		return isEnemyDead;
	}

	GrabbableObject IVisibleThreat.GetHeldObject()
	{
		return null;
	}

	int IVisibleThreat.SendSpecialBehaviour(int id)
	{
		return 0;
	}

	int IVisibleThreat.GetThreatLevel(Vector3 seenByPosition)
	{
		return 3;
	}

	int IVisibleThreat.GetInterestLevel()
	{
		return 0;
	}

	Transform IVisibleThreat.GetThreatLookTransform()
	{
		return eye;
	}

	Transform IVisibleThreat.GetThreatTransform()
	{
		return ((Component)this).transform;
	}

	Vector3 IVisibleThreat.GetThreatVelocity()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			return agent.velocity;
		}
		return Vector3.zero;
	}

	float IVisibleThreat.GetVisibility()
	{
		if (isEnemyDead)
		{
			return 0f;
		}
		if (crouching)
		{
			return 0.5f;
		}
		return 1f;
	}

	public override void Start()
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Expected O, but got Unknown
		try
		{
			agent = ((Component)this).gameObject.GetComponentInChildren<NavMeshAgent>();
			skinnedMeshRenderers = ((Component)this).gameObject.GetComponentsInChildren<SkinnedMeshRenderer>();
			meshRenderers = ((Component)this).gameObject.GetComponentsInChildren<MeshRenderer>();
			if ((Object)(object)creatureAnimator == (Object)null)
			{
				creatureAnimator = ((Component)this).gameObject.GetComponentInChildren<Animator>();
			}
			thisNetworkObject = ((Component)this).gameObject.GetComponentInChildren<NetworkObject>();
			serverPosition = ((Component)this).transform.position;
			thisEnemyIndex = RoundManager.Instance.numberOfEnemiesInScene;
			RoundManager.Instance.numberOfEnemiesInScene++;
			isOutside = ((Component)this).transform.position.y > -80f;
			mainEntrancePosition = RoundManager.FindMainEntrancePosition(getTeleportPosition: true, isOutside);
			if (isOutside)
			{
				if (allAINodes == null || allAINodes.Length == 0)
				{
					allAINodes = GameObject.FindGameObjectsWithTag("OutsideAINode");
				}
				if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)null)
				{
					EnableEnemyMesh(!StartOfRound.Instance.hangarDoorsClosed || !GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom);
				}
			}
			else if (allAINodes == null || allAINodes.Length == 0)
			{
				allAINodes = GameObject.FindGameObjectsWithTag("AINode");
			}
			path1 = new NavMeshPath();
			openDoorSpeedMultiplier = enemyType.doorSpeedMultiplier;
			if (((NetworkBehaviour)this).IsOwner)
			{
				SyncPositionToClients();
			}
			else
			{
				SetClientCalculatingAI(enable: false);
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error when initializing enemy variables for {((Object)((Component)this).gameObject).name} : {arg}");
		}
		lerpTarget.SetParent(RoundManager.Instance.mapPropsContainer.transform);
		enemyRayHit = default(RaycastHit);
		addPlayerVelocityToDestination = 3f;
		if (((NetworkBehaviour)this).IsServer && (Object)(object)mimickingPlayer == (Object)null)
		{
			SetEnemyAsHavingNoPlayerServerRpc();
		}
	}

	[ServerRpc]
	public void SetEnemyAsHavingNoPlayerServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3110137062u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3110137062u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetEnemyAsHavingNoPlayerClientRpc();
		}
	}

	[ClientRpc]
	public void SetEnemyAsHavingNoPlayerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1038760037u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1038760037u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				allowSpawningWithoutPlayer = true;
			}
		}
	}

	private void Awake()
	{
		SetVisibilityOfMaskedEnemy();
	}

	private void LookAndRunRandomly(bool canStartRunning = false, bool onlySetRunning = false)
	{
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		randomLookTimer -= AIIntervalTime;
		if (!runningRandomly && !running)
		{
			staminaTimer = Mathf.Min(6f, staminaTimer + AIIntervalTime);
		}
		else
		{
			staminaTimer = Mathf.Max(0f, staminaTimer - AIIntervalTime);
		}
		if (!(randomLookTimer <= 0f))
		{
			return;
		}
		randomLookTimer = Random.Range(0.7f, 5f);
		if (!runningRandomly)
		{
			int num = ((!isOutside) ? 20 : 35);
			if (onlySetRunning)
			{
				num /= 3;
			}
			if (staminaTimer >= 5f && Random.Range(0, 100) < num)
			{
				running = true;
				runningRandomly = true;
				creatureAnimator.SetBool("Running", true);
				SetRunningServerRpc(running: true);
			}
			else if (!onlySetRunning)
			{
				Vector3 onUnitSphere = Random.onUnitSphere;
				float y = 0f;
				if (Physics.Raycast(eye.position, onUnitSphere, 5f, StartOfRound.Instance.collidersRoomMaskDefaultAndPlayers))
				{
					y = RoundManager.Instance.YRotationThatFacesTheFarthestFromPosition(eye.position, 12f, 5);
				}
				onUnitSphere.y = y;
				LookAtDirectionServerRpc(onUnitSphere, Random.Range(0.25f, 2f), Random.Range(-60f, 60f));
			}
		}
		else
		{
			int num2 = ((!isOutside) ? 30 : 80);
			if (onlySetRunning)
			{
				num2 /= 5;
			}
			if (Random.Range(0, 100) > num2 || staminaTimer <= 0f)
			{
				running = false;
				runningRandomly = false;
				staminaTimer = -6f;
				creatureAnimator.SetBool("Running", false);
				SetRunningServerRpc(running: false);
			}
		}
	}

	private void TeleportMaskedEnemyAndSync(Vector3 pos, bool setOutside)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			TeleportMaskedEnemy(pos, setOutside);
			TeleportMaskedEnemyServerRpc(pos, setOutside);
		}
	}

	[ServerRpc]
	public void TeleportMaskedEnemyServerRpc(Vector3 pos, bool setOutside)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Invalid comparison between Unknown and I4
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(657232826u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setOutside, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 657232826u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			TeleportMaskedEnemyClientRpc(pos, setOutside);
		}
	}

	[ClientRpc]
	public void TeleportMaskedEnemyClientRpc(Vector3 pos, bool setOutside)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2539470808u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setOutside, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2539470808u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				TeleportMaskedEnemy(pos, setOutside);
			}
		}
	}

	private void TeleportMaskedEnemy(Vector3 pos, bool setOutside)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		timeAtLastUsingEntrance = Time.realtimeSinceStartup;
		Vector3 navMeshPosition = RoundManager.Instance.GetNavMeshPosition(pos);
		if (((NetworkBehaviour)this).IsOwner)
		{
			((Behaviour)agent).enabled = false;
			((Component)this).transform.position = navMeshPosition;
			((Behaviour)agent).enabled = true;
		}
		else
		{
			((Component)this).transform.position = navMeshPosition;
		}
		serverPosition = navMeshPosition;
		SetEnemyOutside(setOutside);
		EntranceTeleport entranceTeleport = RoundManager.FindMainEntranceScript(setOutside);
		if (entranceTeleport.doorAudios != null && entranceTeleport.doorAudios.Length != 0)
		{
			entranceTeleport.entrancePointAudio.PlayOneShot(entranceTeleport.doorAudios[0]);
			WalkieTalkie.TransmitOneShotAudio(entranceTeleport.entrancePointAudio, entranceTeleport.doorAudios[0]);
		}
	}

	private bool GoTowardsEntrance()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (!PathIsIntersectedByLineOfSight(mainEntrancePosition, calculatePathDistance: false, avoidLineOfSight: false))
		{
			SetDestinationToPosition(mainEntrancePosition);
			return true;
		}
		return false;
	}

	private bool UseElevator(bool goUp)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((!goUp) ? elevatorScript.elevatorTopPoint.position : elevatorScript.elevatorBottomPoint.position);
		Debug.Log((object)$"goUp: {goUp}");
		Debug.Log((object)$"{elevatorScript.elevatorFinishedMoving}, {!PathIsIntersectedByLineOfSight(elevatorScript.elevatorInsidePoint.position, calculatePathDistance: false, avoidLineOfSight: false)}");
		if (elevatorScript.elevatorFinishedMoving && !PathIsIntersectedByLineOfSight(elevatorScript.elevatorInsidePoint.position, calculatePathDistance: false, avoidLineOfSight: false))
		{
			Debug.Log((object)$"goUp: {goUp}, elevatormovingdown: {elevatorScript.elevatorMovingDown}");
			Debug.Log((object)$"{elevatorScript.elevatorDoorOpen}, {Vector3.Distance(((Component)this).transform.position, elevatorScript.elevatorInsidePoint.position) < 1f}, {elevatorScript.elevatorMovingDown == goUp}");
			if (elevatorScript.elevatorDoorOpen && Vector3.Distance(((Component)this).transform.position, elevatorScript.elevatorInsidePoint.position) < 1f && elevatorScript.elevatorMovingDown == goUp)
			{
				elevatorScript.PressElevatorButtonOnServer(requireFinishedMoving: true);
			}
			SetDestinationToPosition(elevatorScript.elevatorInsidePoint.position);
			return true;
		}
		if (Vector3.Distance(((Component)this).transform.position, elevatorScript.elevatorInsidePoint.position) > 1f && !PathIsIntersectedByLineOfSight(val, calculatePathDistance: false, avoidLineOfSight: false))
		{
			if (elevatorScript.elevatorDoorOpen && Vector3.Distance(((Component)this).transform.position, val) < 1f && elevatorScript.elevatorMovingDown != goUp && !elevatorScript.elevatorCalled)
			{
				elevatorScript.CallElevatorOnServer(goUp);
			}
			SetDestinationToPosition(val);
			return true;
		}
		return false;
	}

	public override void DoAIInterval()
	{
		//IL_052d: Unknown result type (might be due to invalid IL or missing references)
		//IL_053e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0716: Unknown result type (might be due to invalid IL or missing references)
		//IL_071c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_078e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (isEnemyDead)
		{
			agent.speed = 0f;
			return;
		}
		PlayerControllerB playerControllerB = null;
		switch (currentBehaviourStateIndex)
		{
		case 0:
			LookAndRunRandomly(canStartRunning: true);
			playerControllerB = CheckLineOfSightForClosestPlayer();
			if ((Object)(object)playerControllerB != (Object)null)
			{
				LookAtPlayerServerRpc((int)playerControllerB.playerClientId);
				SetMovingTowardsTargetPlayer(playerControllerB);
				SwitchToBehaviourState(1);
				break;
			}
			interestInShipCooldown += AIIntervalTime;
			if (interestInShipCooldown >= 17f && Vector3.Distance(((Component)this).transform.position, StartOfRound.Instance.elevatorTransform.position) < 22f)
			{
				SwitchToBehaviourState(2);
				break;
			}
			if (Time.realtimeSinceStartup - timeAtLastUsingEntrance > 3f)
			{
				bool flag = false;
				PlayerControllerB closestPlayer2 = GetClosestPlayer();
				if (!isOutside && (Object)(object)closestPlayer2 != (Object)null && RoundManager.Instance.currentDungeonType == 4 && Vector3.Distance(((Component)closestPlayer2).transform.position, mainEntrancePosition) < 30f)
				{
					flag = true;
				}
				if ((Object)(object)closestPlayer2 == (Object)null || flag != isInElevatorStartRoom)
				{
					bool flag2 = false;
					bool flag3 = false;
					bool flag4 = true;
					if ((Object)(object)elevatorScript == (Object)null)
					{
						elevatorScript = Object.FindObjectOfType<MineshaftElevatorController>();
						if ((Object)(object)elevatorScript == (Object)null)
						{
							flag4 = false;
						}
					}
					if (flag4)
					{
						if (isInElevatorStartRoom)
						{
							if (Vector3.Distance(((Component)this).transform.position, elevatorScript.elevatorBottomPoint.position) < 10f)
							{
								isInElevatorStartRoom = false;
							}
						}
						else if (Vector3.Distance(((Component)this).transform.position, elevatorScript.elevatorTopPoint.position) < 10f)
						{
							isInElevatorStartRoom = true;
						}
					}
					if (flag4 && RoundManager.Instance.currentDungeonType == 4 && !isOutside)
					{
						if (!isInElevatorStartRoom)
						{
							flag2 = UseElevator(goUp: true);
						}
						else
						{
							bool flag5 = false;
							for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
							{
								if (!StartOfRound.Instance.allPlayerScripts[i].isPlayerDead && StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled && StartOfRound.Instance.allPlayerScripts[i].isInsideFactory)
								{
									flag5 = true;
									break;
								}
							}
							if (!flag5)
							{
								flag3 = true;
								flag2 = GoTowardsEntrance();
							}
							else if (!flag)
							{
								flag2 = UseElevator(goUp: false);
							}
						}
					}
					else
					{
						flag3 = true;
						flag2 = GoTowardsEntrance();
					}
					if (flag3 && Vector3.Distance(((Component)this).transform.position, mainEntrancePosition) < 1f)
					{
						TeleportMaskedEnemyAndSync(RoundManager.FindMainEntrancePosition(getTeleportPosition: true, !isOutside), !isOutside);
						return;
					}
					if (flag2)
					{
						if (searchForPlayers.inProgress)
						{
							StopSearch(searchForPlayers);
						}
						return;
					}
				}
			}
			if (!searchForPlayers.inProgress)
			{
				StartSearch(((Component)this).transform.position, searchForPlayers);
			}
			break;
		case 1:
			LookAndRunRandomly(canStartRunning: true, onlySetRunning: true);
			playerControllerB = CheckLineOfSightForClosestPlayer(70f, 50, 1, 3f);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				lostPlayerInChase = false;
				lostLOSTimer = 0f;
				if ((Object)(object)playerControllerB != (Object)(object)targetPlayer)
				{
					SetMovingTowardsTargetPlayer(playerControllerB);
					LookAtPlayerServerRpc((int)playerControllerB.playerClientId);
				}
				if (mostOptimalDistance > 17f)
				{
					if (handsOut)
					{
						handsOut = false;
						SetHandsOutServerRpc(setOut: false);
					}
					if (!running)
					{
						running = true;
						creatureAnimator.SetBool("Running", true);
						SetRunningServerRpc(running: true);
					}
				}
				else if (mostOptimalDistance < 6f)
				{
					if (!handsOut)
					{
						handsOut = true;
						SetHandsOutServerRpc(setOut: true);
					}
				}
				else if (mostOptimalDistance < 12f)
				{
					if (handsOut)
					{
						handsOut = false;
						SetHandsOutServerRpc(setOut: false);
					}
					if (running && !runningRandomly)
					{
						running = false;
						creatureAnimator.SetBool("Running", false);
						SetRunningServerRpc(running: false);
					}
				}
				break;
			}
			lostLOSTimer += AIIntervalTime;
			if (lostLOSTimer > 10f)
			{
				SwitchToBehaviourState(0);
				targetPlayer = null;
			}
			else if (lostLOSTimer > 3.5f)
			{
				lostPlayerInChase = true;
				StopLookingAtTransformServerRpc();
				targetPlayer = null;
				if (running)
				{
					running = false;
					creatureAnimator.SetBool("Running", false);
					SetRunningServerRpc(running: false);
				}
				if (handsOut)
				{
					handsOut = false;
					SetHandsOutServerRpc(setOut: false);
				}
			}
			break;
		case 2:
		{
			if (!isInsidePlayerShip)
			{
				interestInShipCooldown -= AIIntervalTime;
			}
			if (Vector3.Distance(((Component)this).transform.position, StartOfRound.Instance.insideShipPositions[0].position) > 27f || interestInShipCooldown <= 0f)
			{
				SwitchToBehaviourState(0);
				break;
			}
			PlayerControllerB closestPlayer = GetClosestPlayer();
			if ((Object)(object)closestPlayer != (Object)null)
			{
				PlayerControllerB playerControllerB2 = CheckLineOfSightForClosestPlayer(70f, 20, 0);
				if ((Object)(object)playerControllerB2 != (Object)null)
				{
					if ((Object)(object)stareAtTransform != (Object)(object)((Component)playerControllerB2.gameplayCamera).transform)
					{
						LookAtPlayerServerRpc((int)playerControllerB2.playerClientId);
					}
					SetMovingTowardsTargetPlayer(playerControllerB2);
					SwitchToBehaviourState(1);
				}
				else if (isInsidePlayerShip && closestPlayer.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.7f, 4f, 20))
				{
					if ((Object)(object)stareAtTransform != (Object)(object)((Component)closestPlayer.gameplayCamera).transform)
					{
						LookAtPlayerServerRpc((int)closestPlayer.playerClientId);
					}
					SetMovingTowardsTargetPlayer(closestPlayer);
					SwitchToBehaviourState(1);
				}
				else if (mostOptimalDistance < 6f)
				{
					if ((Object)(object)stareAtTransform != (Object)(object)((Component)closestPlayer.gameplayCamera).transform)
					{
						stareAtTransform = ((Component)closestPlayer.gameplayCamera).transform;
						LookAtPlayerServerRpc((int)closestPlayer.playerClientId);
					}
				}
				else if (mostOptimalDistance > 12f && (Object)(object)stareAtTransform != (Object)null)
				{
					stareAtTransform = null;
					StopLookingAtTransformServerRpc();
				}
			}
			SetDestinationToPosition(shipHidingSpot);
			if (!crouching && Vector3.Distance(((Component)this).transform.position, shipHidingSpot) < 0.4f)
			{
				agent.speed = 0f;
				crouching = true;
				SetCrouchingServerRpc(setOut: true);
			}
			else if (crouching && Vector3.Distance(((Component)this).transform.position, shipHidingSpot) > 1f)
			{
				crouching = false;
				SetCrouchingServerRpc(setOut: false);
			}
			break;
		}
		}
		if (!((Object)(object)targetPlayer != (Object)null) || !PlayerIsTargetable(targetPlayer) || (currentBehaviourStateIndex != 1 && currentBehaviourStateIndex != 2))
		{
			return;
		}
		if (lostPlayerInChase)
		{
			movingTowardsTargetPlayer = false;
			if (!searchForPlayers.inProgress)
			{
				StartSearch(((Component)this).transform.position, searchForPlayers);
			}
		}
		else
		{
			if (searchForPlayers.inProgress)
			{
				StopSearch(searchForPlayers);
			}
			SetMovingTowardsTargetPlayer(targetPlayer);
		}
	}

	[ServerRpc]
	public void LookAtDirectionServerRpc(Vector3 dir, float time, float vertLookAngle)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Invalid comparison between Unknown and I4
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2502006210u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref dir);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref time, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref vertLookAngle, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2502006210u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			LookAtDirectionClientRpc(dir, time, vertLookAngle);
		}
	}

	[ClientRpc]
	public void LookAtDirectionClientRpc(Vector3 dir, float time, float vertLookAngle)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3625708449u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref dir);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref time, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref vertLookAngle, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3625708449u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				LookAtDirection(dir, time, vertLookAngle);
			}
		}
	}

	[ServerRpc]
	public void LookAtPositionServerRpc(Vector3 pos, float time)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Invalid comparison between Unknown and I4
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(675153417u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref time, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 675153417u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			LookAtPositionClientRpc(pos, time);
		}
	}

	[ClientRpc]
	public void LookAtPositionClientRpc(Vector3 pos, float time)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(432295350u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref time, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 432295350u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				LookAtPosition(pos, time);
			}
		}
	}

	[ServerRpc]
	public void LookAtPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1141953697u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1141953697u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			LookAtPlayerClientRpc(playerId);
		}
	}

	[ClientRpc]
	public void LookAtPlayerClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2397761797u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2397761797u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				stareAtTransform = ((Component)StartOfRound.Instance.allPlayerScripts[playerId].gameplayCamera).transform;
			}
		}
	}

	[ServerRpc]
	public void StopLookingAtTransformServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1407409549u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1407409549u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			StopLookingAtTransformClientRpc();
		}
	}

	[ClientRpc]
	public void StopLookingAtTransformClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1561581057u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1561581057u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				stareAtTransform = null;
			}
		}
	}

	[ServerRpc]
	public void SetHandsOutServerRpc(bool setOut)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(519961256u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setOut, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 519961256u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetHandsOutClientRpc(setOut);
		}
	}

	[ClientRpc]
	public void SetHandsOutClientRpc(bool setOut)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(222504553u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setOut, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 222504553u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				handsOut = setOut;
				creatureAnimator.SetBool("HandsOut", setOut);
			}
		}
	}

	[ServerRpc]
	public void SetCrouchingServerRpc(bool setOut)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2560207573u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setOut, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2560207573u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetCrouchingClientRpc(setOut);
		}
	}

	[ClientRpc]
	public void SetCrouchingClientRpc(bool setCrouch)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1162325818u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setCrouch, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1162325818u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				crouching = setCrouch;
				creatureAnimator.SetBool("Crouching", setCrouch);
			}
		}
	}

	public void LookAtFocusedPosition()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		if (inSpecialAnimation)
		{
			verticalLookAngle = Mathf.Lerp(verticalLookAngle, 0f, 10f * Time.deltaTime);
			currentLookAngle = Mathf.Lerp(currentLookAngle, verticalLookAngle, 7f);
			headTiltTarget.localEulerAngles = new Vector3(currentLookAngle, 0f, 0f);
			return;
		}
		if (lookAtPositionTimer <= 0f)
		{
			if ((Object)(object)stareAtTransform != (Object)null)
			{
				if (!(Vector3.Distance(stareAtTransform.position, ((Component)this).transform.position) > 80f))
				{
					agent.angularSpeed = 0f;
					RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
					RoundManager.Instance.tempTransform.LookAt(stareAtTransform);
					((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, RoundManager.Instance.tempTransform.rotation, turnSpeedMultiplier * Time.deltaTime);
					((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
					headTiltTarget.LookAt(stareAtTransform);
					headTiltTarget.localEulerAngles = new Vector3(headTiltTarget.localEulerAngles.x, 0f, 0f);
				}
				return;
			}
			agent.angularSpeed = 450f;
			verticalLookAngle = Mathf.Clamp(verticalLookAngle, -30f, 10f);
		}
		else
		{
			agent.angularSpeed = 0f;
			lookAtPositionTimer -= Time.deltaTime;
			RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
			RoundManager.Instance.tempTransform.LookAt(focusOnPosition);
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, RoundManager.Instance.tempTransform.rotation, turnSpeedMultiplier * Time.deltaTime);
			((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
			verticalLookAngle = Mathf.Clamp(verticalLookAngle + Random.Range(-3f * Time.deltaTime, 3f * Time.deltaTime), -70f, 70f);
		}
		currentLookAngle = Mathf.Lerp(currentLookAngle, verticalLookAngle, 7f);
		headTiltTarget.localEulerAngles = new Vector3(currentLookAngle, 0f, 0f);
	}

	public void LookAtDirection(Vector3 direction, float lookAtTime = 1f, float vertLookAngle = 0f)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		verticalLookAngle = vertLookAngle;
		direction = Vector3.Normalize(direction * 100f);
		focusOnPosition = ((Component)this).transform.position + direction * 1000f;
		lookAtPositionTimer = lookAtTime;
	}

	public void LookAtPosition(Vector3 pos, float lookAtTime = 1f)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		focusOnPosition = pos;
		lookAtPositionTimer = lookAtTime;
		float num = Vector3.Angle(((Component)this).transform.forward, pos - ((Component)this).transform.position);
		if (pos.y - headTiltTarget.position.y < 0f)
		{
			num *= -1f;
		}
		verticalLookAngle = num;
	}

	[ServerRpc]
	public void SetRunningServerRpc(bool running)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3309468324u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref running, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3309468324u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetRunningClientRpc(running);
		}
	}

	[ClientRpc]
	public void SetRunningClientRpc(bool setRunning)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3512011720u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setRunning, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3512011720u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				running = setRunning;
				creatureAnimator.SetBool("Running", setRunning);
			}
		}
	}

	private void CalculateAnimationDirection(float maxSpeed = 1f)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		creatureAnimator.SetBool("IsMoving", Vector3.Distance(((Component)this).transform.position, previousPosition) > 0f);
		agentLocalVelocity = animationContainer.InverseTransformDirection(Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 2f));
		velX = Mathf.Lerp(velX, agentLocalVelocity.x, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityX", Mathf.Clamp(velX, 0f - maxSpeed, maxSpeed));
		velZ = Mathf.Lerp(velZ, agentLocalVelocity.z, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityZ", Mathf.Clamp(velZ, 0f - maxSpeed, maxSpeed));
		previousPosition = ((Component)this).transform.position;
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesPlayedInOneSpot, noiseID);
		if (!((NetworkBehaviour)this).IsOwner || isEnemyDead || inSpecialAnimation)
		{
			return;
		}
		if (Vector3.Distance(noisePosition, ((Component)this).transform.position + Vector3.up * 0.4f) < 0.75f)
		{
			Debug.Log((object)"Can't hear noise reason A");
			return;
		}
		if (handsOut || ((Object)(object)stareAtTransform != (Object)null && Vector3.Distance(noisePosition, stareAtTransform.position) < 2f))
		{
			Debug.Log((object)"Can't hear noise reason B");
			return;
		}
		float num = Vector3.Distance(noisePosition, ((Component)this).transform.position);
		float num2 = noiseLoudness / num;
		Debug.Log((object)$"Noise heard relative loudness: {num2}");
		if (!(num2 < 0.12f) && !(Time.realtimeSinceStartup - timeLookingAtLastNoise < 3f))
		{
			timeLookingAtLastNoise = Time.realtimeSinceStartup;
			LookAtPositionServerRpc(noisePosition, Mathf.Min(num2 * 6f, 2f));
		}
	}

	public void LateUpdate()
	{
		if (!(stunNormalizedTimer >= 0f) && !isEnemyDead)
		{
			LookAtFocusedPosition();
		}
	}

	public void SetVisibilityOfMaskedEnemy()
	{
		if (allowSpawningWithoutPlayer)
		{
			if ((Object)(object)mimickingPlayer != (Object)null && (Object)(object)mimickingPlayer.deadBody != (Object)null && !mimickingPlayer.deadBody.deactivated)
			{
				if (enemyEnabled)
				{
					enemyEnabled = false;
					EnableEnemyMesh(enable: false);
				}
			}
			else if (!enemyEnabled)
			{
				enemyEnabled = true;
				EnableEnemyMesh(enable: true);
			}
		}
		else if ((Object)(object)mimickingPlayer == (Object)null || ((Object)(object)mimickingPlayer.deadBody != (Object)null && !mimickingPlayer.deadBody.deactivated))
		{
			if (enemyEnabled)
			{
				enemyEnabled = false;
				EnableEnemyMesh(enable: false);
			}
		}
		else if (!enemyEnabled)
		{
			enemyEnabled = true;
			EnableEnemyMesh(enable: true);
		}
	}

	public override void Update()
	{
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		CalculateAnimationDirection();
		SetVisibilityOfMaskedEnemy();
		if (isEnemyDead)
		{
			agent.speed = 0f;
			if (inSpecialAnimation)
			{
				FinishKillAnimation();
			}
			return;
		}
		if ((Object)(object)lastPlayerKilled != (Object)null && (Object)(object)lastPlayerKilled.deadBody != (Object)null && !lastPlayerKilled.deadBody.deactivated)
		{
			lastPlayerKilled.deadBody.DeactivateBody(setActive: false);
			lastPlayerKilled = null;
		}
		if (!enemyEnabled)
		{
			return;
		}
		if (ventAnimationFinished)
		{
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)lookRig1).weight = 0.452f;
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)lookRig2).weight = 1f;
			creatureAnimator.SetBool("Stunned", stunNormalizedTimer >= 0f);
			if (stunNormalizedTimer >= 0f)
			{
				agent.speed = 0f;
				if (((NetworkBehaviour)this).IsOwner && searchForPlayers.inProgress)
				{
					StopSearch(searchForPlayers);
				}
				if (inSpecialAnimation)
				{
					FinishKillAnimation();
				}
			}
			else
			{
				if (inSpecialAnimation)
				{
					return;
				}
				if (walkCheckInterval <= 0f)
				{
					walkCheckInterval = 0.1f;
					positionLastCheck = ((Component)this).transform.position;
				}
				else
				{
					walkCheckInterval -= Time.deltaTime;
				}
				switch (currentBehaviourStateIndex)
				{
				case 0:
					if (previousBehaviourState != currentBehaviourStateIndex)
					{
						stareAtTransform = null;
						running = false;
						runningRandomly = false;
						creatureAnimator.SetBool("Running", false);
						handsOut = false;
						creatureAnimator.SetBool("HandsOut", false);
						crouching = false;
						creatureAnimator.SetBool("Crouching", false);
						previousBehaviourState = currentBehaviourStateIndex;
					}
					if (running || runningRandomly)
					{
						agent.speed = 7f;
					}
					else
					{
						agent.speed = 3.8f;
					}
					break;
				case 1:
					if (previousBehaviourState != currentBehaviourStateIndex)
					{
						lookAtPositionTimer = 0f;
						if (previousBehaviourState == 0)
						{
							stopAndStareTimer = Random.Range(2f, 5f);
						}
						runningRandomly = false;
						running = false;
						creatureAnimator.SetBool("Running", false);
						crouching = false;
						creatureAnimator.SetBool("Crouching", false);
						previousBehaviourState = currentBehaviourStateIndex;
					}
					if (!((NetworkBehaviour)this).IsOwner)
					{
						break;
					}
					stopAndStareTimer -= Time.deltaTime;
					if (stopAndStareTimer >= 0f)
					{
						agent.speed = 0f;
						break;
					}
					if (stopAndStareTimer <= -5f)
					{
						stopAndStareTimer = Random.Range(0f, 3f);
					}
					if (running || runningRandomly)
					{
						agent.speed = 8f;
					}
					else
					{
						agent.speed = 3.8f;
					}
					break;
				case 2:
					if (previousBehaviourState != currentBehaviourStateIndex)
					{
						movingTowardsTargetPlayer = false;
						interestInShipCooldown = 17f;
						agent.speed = 5f;
						runningRandomly = false;
						running = false;
						creatureAnimator.SetBool("Running", false);
						handsOut = false;
						creatureAnimator.SetBool("HandsOut", false);
						if (((NetworkBehaviour)this).IsOwner)
						{
							ChooseShipHidingSpot();
						}
						previousBehaviourState = currentBehaviourStateIndex;
					}
					break;
				}
			}
		}
		else
		{
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)lookRig1).weight = 0f;
			((RigConstraint<MultiRotationConstraintJob, MultiRotationConstraintData, MultiRotationConstraintJobBinder<MultiRotationConstraintData>>)(object)lookRig2).weight = 0f;
		}
	}

	private void ChooseShipHidingSpot()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		for (int i = 0; i < StartOfRound.Instance.insideShipPositions.Length; i++)
		{
			if (Physics.Linecast(((Component)StartOfRound.Instance.shipDoorAudioSource).transform.position, StartOfRound.Instance.insideShipPositions[i].position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) && SetDestinationToPosition(StartOfRound.Instance.insideShipPositions[i].position, checkForPath: true))
			{
				flag = true;
				shipHidingSpot = destination;
				break;
			}
		}
		if (!flag)
		{
			shipHidingSpot = StartOfRound.Instance.insideShipPositions[Random.Range(0, StartOfRound.Instance.insideShipPositions.Length)].position;
		}
	}

	public override void ShipTeleportEnemy()
	{
		base.ShipTeleportEnemy();
		if (teleportCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(teleportCoroutine);
		}
		((MonoBehaviour)this).StartCoroutine(teleportMasked());
	}

	private IEnumerator teleportMasked()
	{
		teleportParticle.Play();
		movementAudio.PlayOneShot(Object.FindObjectOfType<ShipTeleporter>().beamUpPlayerBodySFX);
		yield return (object)new WaitForSeconds(3f);
		if (StartOfRound.Instance.shipIsLeaving)
		{
			yield break;
		}
		SetEnemyOutside(outside: true);
		isInsidePlayerShip = true;
		ShipTeleporter[] array = Object.FindObjectsOfType<ShipTeleporter>();
		ShipTeleporter shipTeleporter = null;
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				if (!array[i].isInverseTeleporter)
				{
					shipTeleporter = array[i];
				}
			}
		}
		if ((Object)(object)shipTeleporter != (Object)null)
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				((Behaviour)agent).enabled = false;
				((Component)this).transform.position = shipTeleporter.teleporterPosition.position;
				((Behaviour)agent).enabled = true;
				isInsidePlayerShip = true;
			}
			serverPosition = shipTeleporter.teleporterPosition.position;
		}
	}

	public override void SetEnemyOutside(bool outside = false)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		base.SetEnemyOutside(outside);
		mainEntrancePosition = RoundManager.FindMainEntrancePosition(getTeleportPosition: true, isOutside);
		if (searchForPlayers.inProgress)
		{
			StopSearch(searchForPlayers);
		}
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
	}

	public override void KillEnemy(bool destroy = false)
	{
		if ((Object)(object)mimickingPlayer != (Object)null)
		{
			removedPowerLevel = true;
		}
		base.KillEnemy(destroy);
		creatureAnimator.SetBool("Stunned", false);
		creatureAnimator.SetBool("Dead", true);
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		enemyHP -= force;
		stunNormalizedTimer = 0.5f;
		creatureAnimator.SetTrigger("HitEnemy");
		stopAndStareTimer = 0f;
		if (((float)Random.Range(0, 100) < 40f || enemyHP == 1) && !running)
		{
			running = true;
			runningRandomly = true;
			creatureAnimator.SetBool("Running", true);
			SetRunningServerRpc(running: true);
			staminaTimer = 5f;
		}
		if (enemyHP <= 0)
		{
			KillEnemyOnOwnerClient();
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		base.OnCollideWithPlayer(other);
		if (!(stunNormalizedTimer >= 0f) && !isEnemyDead && !(Time.realtimeSinceStartup - timeAtLastUsingEntrance < 1.75f))
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other, inKillAnimation || startingKillAnimationLocalClient || !enemyEnabled);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				startingKillAnimationLocalClient = true;
				KillPlayerAnimationServerRpc((int)playerControllerB.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KillPlayerAnimationServerRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3192502457u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerObjectId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3192502457u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (!inKillAnimation && !playersKilled.Contains(playerObjectId))
			{
				inSpecialAnimationWithPlayer = StartOfRound.Instance.allPlayerScripts[playerObjectId];
				inSpecialAnimationWithPlayer.inAnimationWithEnemy = this;
				inKillAnimation = true;
				inSpecialAnimation = true;
				isClientCalculatingAI = false;
				KillPlayerAnimationClientRpc(playerObjectId);
			}
			else
			{
				CancelKillAnimationClientRpc(playerObjectId);
			}
		}
	}

	[ClientRpc]
	public void CancelKillAnimationClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4032958935u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4032958935u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId == playerObjectId)
			{
				startingKillAnimationLocalClient = false;
			}
		}
	}

	[ClientRpc]
	public void KillPlayerAnimationClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3071650946u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerObjectId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3071650946u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		if (searchForPlayers.inProgress)
		{
			StopSearch(searchForPlayers);
		}
		inSpecialAnimationWithPlayer = StartOfRound.Instance.allPlayerScripts[playerObjectId];
		if ((Object)(object)inSpecialAnimationWithPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			startingKillAnimationLocalClient = false;
		}
		if ((Object)(object)inSpecialAnimationWithPlayer == (Object)null || inSpecialAnimationWithPlayer.isPlayerDead || inSpecialAnimationWithPlayer.isInsideFactory != !isOutside)
		{
			FinishKillAnimation();
			return;
		}
		inSpecialAnimationWithPlayer.inAnimationWithEnemy = this;
		if ((Object)(object)inSpecialAnimationWithPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			inSpecialAnimationWithPlayer.CancelSpecialTriggerAnimations();
		}
		inKillAnimation = true;
		inSpecialAnimation = true;
		creatureAnimator.SetBool("killing", true);
		((Behaviour)agent).enabled = false;
		inSpecialAnimationWithPlayer.inSpecialInteractAnimation = true;
		inSpecialAnimationWithPlayer.snapToServerPosition = true;
		Vector3 val3 = ((!((NetworkBehaviour)inSpecialAnimationWithPlayer).IsOwner) ? ((Component)inSpecialAnimationWithPlayer).transform.parent.TransformPoint(inSpecialAnimationWithPlayer.serverPlayerPosition) : ((Component)inSpecialAnimationWithPlayer).transform.position);
		Vector3 val4 = ((Component)this).transform.position - ((Component)this).transform.forward * 2f;
		val4.y = val3.y;
		playerRay = new Ray(val3, val4 - ((Component)inSpecialAnimationWithPlayer).transform.position);
		if (killAnimationCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(killAnimationCoroutine);
		}
		killAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(killAnimation());
	}

	private IEnumerator killAnimation()
	{
		WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[0]);
		creatureSFX.PlayOneShot(enemyType.audioClips[0]);
		Vector3 endPosition = ((Ray)(ref playerRay)).GetPoint(0.7f);
		if (isOutside && endPosition.y < -80f)
		{
			SetEnemyOutside();
		}
		else if (!isOutside && endPosition.y > -80f)
		{
			SetEnemyOutside(outside: true);
		}
		inSpecialAnimationWithPlayer.disableSyncInAnimation = true;
		inSpecialAnimationWithPlayer.disableLookInput = true;
		RoundManager.Instance.tempTransform.position = ((Component)inSpecialAnimationWithPlayer).transform.position;
		RoundManager.Instance.tempTransform.LookAt(endPosition);
		Quaternion startingPlayerRot = ((Component)inSpecialAnimationWithPlayer).transform.rotation;
		Quaternion targetRot = RoundManager.Instance.tempTransform.rotation;
		Vector3 startingPosition = ((Component)this).transform.position;
		for (int i = 0; i < 8; i++)
		{
			if (i > 0)
			{
				((Component)this).transform.LookAt(((Component)inSpecialAnimationWithPlayer).transform.position);
				((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
			}
			((Component)this).transform.position = Vector3.Lerp(startingPosition, endPosition, (float)i / 8f);
			((Component)inSpecialAnimationWithPlayer).transform.rotation = Quaternion.Lerp(startingPlayerRot, targetRot, (float)i / 8f);
			((Component)inSpecialAnimationWithPlayer).transform.eulerAngles = new Vector3(0f, ((Component)inSpecialAnimationWithPlayer).transform.eulerAngles.y, 0f);
			yield return null;
		}
		((Component)this).transform.position = endPosition;
		((Component)inSpecialAnimationWithPlayer).transform.rotation = targetRot;
		((Component)inSpecialAnimationWithPlayer).transform.eulerAngles = new Vector3(0f, ((Component)inSpecialAnimationWithPlayer).transform.eulerAngles.y, 0f);
		yield return (object)new WaitForSeconds(0.3f);
		SetMaskGlow(enable: true);
		yield return (object)new WaitForSeconds(1.2f);
		maskFloodParticle.Play();
		creatureSFX.PlayOneShot(enemyType.audioClips[2]);
		WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[2]);
		yield return (object)new WaitForSeconds(1.5f);
		lastPlayerKilled = inSpecialAnimationWithPlayer;
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null)
		{
			bool flag = ((Component)inSpecialAnimationWithPlayer).transform.position.y < -80f;
			inSpecialAnimationWithPlayer.KillPlayer(Vector3.zero, spawnBody: false, CauseOfDeath.Strangulation, 4);
			inSpecialAnimationWithPlayer.snapToServerPosition = false;
			if (((NetworkBehaviour)this).IsServer)
			{
				playersKilled.Add((int)inSpecialAnimationWithPlayer.playerClientId);
				NetworkObjectReference netObjectRef = RoundManager.Instance.SpawnEnemyGameObject(GetGroundPosition(((Ray)(ref playerRay)).origin), ((Component)inSpecialAnimationWithPlayer).transform.eulerAngles.y, -1, enemyType);
				NetworkObject val = default(NetworkObject);
				if (((NetworkObjectReference)(ref netObjectRef)).TryGet(ref val, (NetworkManager)null))
				{
					MaskedPlayerEnemy component = ((Component)val).GetComponent<MaskedPlayerEnemy>();
					component.SetSuit(inSpecialAnimationWithPlayer.currentSuitID);
					component.mimickingPlayer = inSpecialAnimationWithPlayer;
					component.SetEnemyOutside(!flag);
					inSpecialAnimationWithPlayer.redirectToEnemy = component;
					if ((Object)(object)inSpecialAnimationWithPlayer.deadBody != (Object)null)
					{
						inSpecialAnimationWithPlayer.deadBody.DeactivateBody(setActive: false);
					}
				}
				CreateMimicClientRpc(netObjectRef, flag, (int)inSpecialAnimationWithPlayer.playerClientId);
			}
			FinishKillAnimation(killedPlayer: true);
		}
		else
		{
			FinishKillAnimation();
		}
	}

	[ClientRpc]
	public void CreateMimicClientRpc(NetworkObjectReference netObjectRef, bool inFactory, int playerKilled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1687215509u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref inFactory, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, playerKilled);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1687215509u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				((MonoBehaviour)this).StartCoroutine(waitForMimicEnemySpawn(netObjectRef, inFactory, playerKilled));
			}
		}
	}

	private IEnumerator waitForMimicEnemySpawn(NetworkObjectReference netObjectRef, bool inFactory, int playerKilled)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB player = StartOfRound.Instance.allPlayerScripts[playerKilled];
		NetworkObject netObject = null;
		float startTime = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => Time.realtimeSinceStartup - startTime > 20f || ((NetworkObjectReference)(ref netObjectRef)).TryGet(ref netObject, (NetworkManager)null)));
		if ((Object)(object)player.deadBody == (Object)null)
		{
			startTime = Time.realtimeSinceStartup;
			yield return (object)new WaitUntil((Func<bool>)(() => Time.realtimeSinceStartup - startTime > 20f || (Object)(object)player.deadBody != (Object)null));
		}
		if (!((Object)(object)player.deadBody == (Object)null))
		{
			player.deadBody.DeactivateBody(setActive: false);
			if ((Object)(object)netObject != (Object)null)
			{
				MaskedPlayerEnemy component = ((Component)netObject).GetComponent<MaskedPlayerEnemy>();
				component.mimickingPlayer = player;
				component.SetSuit(player.currentSuitID);
				component.SetEnemyOutside(!inFactory);
				player.redirectToEnemy = component;
			}
		}
	}

	public override void CancelSpecialAnimationWithPlayer()
	{
		FinishKillAnimation();
		base.CancelSpecialAnimationWithPlayer();
	}

	public void FinishKillAnimation(bool killedPlayer = false)
	{
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		if (!killedPlayer)
		{
			creatureSFX.Stop();
		}
		if (killAnimationCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(killAnimationCoroutine);
		}
		inSpecialAnimation = false;
		inKillAnimation = false;
		creatureAnimator.SetBool("killing", false);
		startingKillAnimationLocalClient = false;
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null)
		{
			inSpecialAnimationWithPlayer.disableSyncInAnimation = false;
			inSpecialAnimationWithPlayer.disableLookInput = false;
			inSpecialAnimationWithPlayer.inSpecialInteractAnimation = false;
			inSpecialAnimationWithPlayer.snapToServerPosition = false;
			inSpecialAnimationWithPlayer.inAnimationWithEnemy = null;
		}
		SetMaskGlow(enable: false);
		maskFloodParticle.Stop(true, (ParticleSystemStopBehavior)1);
		stopAndStareTimer = 3f;
		movingTowardsTargetPlayer = false;
		if (((NetworkBehaviour)this).IsOwner)
		{
			((Component)this).transform.position = GetGroundPosition(((Component)this).transform.position);
			((Behaviour)agent).enabled = true;
			isClientCalculatingAI = true;
		}
		if (((NetworkBehaviour)this).NetworkObject.IsSpawned)
		{
			SwitchToBehaviourStateOnLocalClient(0);
			if (((NetworkBehaviour)this).IsServer)
			{
				SwitchToBehaviourState(0);
			}
		}
	}

	private Vector3 GetGroundPosition(Vector3 startingPos)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		Vector3 pos = startingPos;
		pos = RoundManager.Instance.GetNavMeshPosition(pos, default(NavMeshHit), 3f);
		if (!RoundManager.Instance.GotNavMeshPositionResult)
		{
			RaycastHit val = default(RaycastHit);
			if (Physics.Raycast(startingPos + Vector3.up * 0.15f, -Vector3.up, ref val, 50f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				pos = RoundManager.Instance.GetNavMeshPosition(((RaycastHit)(ref val)).point, default(NavMeshHit), 10f);
			}
			else
			{
				int num = Random.Range(0, allAINodes.Length);
				if (allAINodes != null && (Object)(object)allAINodes[num] != (Object)null)
				{
					pos = allAINodes[num].transform.position;
				}
			}
		}
		return pos;
	}

	public void SetSuit(int suitId)
	{
		Material suitMaterial = StartOfRound.Instance.unlockablesList.unlockables[suitId].suitMaterial;
		((Renderer)rendererLOD0).material = suitMaterial;
		((Renderer)rendererLOD1).material = suitMaterial;
		((Renderer)rendererLOD2).material = suitMaterial;
	}

	public void SetMaskType(int maskType)
	{
		switch (maskType)
		{
		case 4:
			maskTypes[0].SetActive(true);
			maskTypes[1].SetActive(false);
			maskTypeIndex = 0;
			break;
		case 5:
			maskTypes[1].SetActive(true);
			maskTypes[0].SetActive(false);
			maskTypeIndex = 1;
			break;
		}
	}

	public void GetMaterialStandingOn()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		enemyRay = new Ray(((Component)this).transform.position + Vector3.up, -Vector3.up);
		if (Physics.Raycast(enemyRay, ref enemyRayHit, 6f, StartOfRound.Instance.walkableSurfacesMask, (QueryTriggerInteraction)1))
		{
			if (((Component)((RaycastHit)(ref enemyRayHit)).collider).CompareTag(StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].surfaceTag))
			{
				return;
			}
			for (int i = 0; i < StartOfRound.Instance.footstepSurfaces.Length; i++)
			{
				if (((Component)((RaycastHit)(ref enemyRayHit)).collider).CompareTag(StartOfRound.Instance.footstepSurfaces[i].surfaceTag))
				{
					currentFootstepSurfaceIndex = i;
					break;
				}
			}
		}
		else
		{
			Debug.DrawRay(((Ray)(ref enemyRay)).origin, ((Ray)(ref enemyRay)).direction, Color.white, 0.3f);
		}
	}

	public void PlayFootstepSound()
	{
		GetMaterialStandingOn();
		int num = Random.Range(0, StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].clips.Length);
		if (num == previousFootstepClip)
		{
			num = (num + 1) % StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].clips.Length;
		}
		movementAudio.pitch = Random.Range(0.93f, 1.07f);
		float num2 = 0.95f;
		if (!sprinting)
		{
			num2 = 0.75f;
		}
		movementAudio.PlayOneShot(StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].clips[num], num2);
		previousFootstepClip = num;
		WalkieTalkie.TransmitOneShotAudio(movementAudio, StartOfRound.Instance.footstepSurfaces[currentFootstepSurfaceIndex].clips[num], num2);
	}

	public override void AnimationEventA()
	{
		base.AnimationEventA();
		PlayFootstepSound();
	}

	public void SetMaskGlow(bool enable)
	{
		((Renderer)maskEyesGlow[maskTypeIndex]).enabled = enable;
		((Behaviour)maskEyesGlowLight).enabled = enable;
		if (enable)
		{
			creatureSFX.PlayOneShot(enemyType.audioClips[1]);
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_MaskedPlayerEnemy()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3110137062u, new RpcReceiveHandler(__rpc_handler_3110137062));
		NetworkManager.__rpc_func_table.Add(1038760037u, new RpcReceiveHandler(__rpc_handler_1038760037));
		NetworkManager.__rpc_func_table.Add(657232826u, new RpcReceiveHandler(__rpc_handler_657232826));
		NetworkManager.__rpc_func_table.Add(2539470808u, new RpcReceiveHandler(__rpc_handler_2539470808));
		NetworkManager.__rpc_func_table.Add(2502006210u, new RpcReceiveHandler(__rpc_handler_2502006210));
		NetworkManager.__rpc_func_table.Add(3625708449u, new RpcReceiveHandler(__rpc_handler_3625708449));
		NetworkManager.__rpc_func_table.Add(675153417u, new RpcReceiveHandler(__rpc_handler_675153417));
		NetworkManager.__rpc_func_table.Add(432295350u, new RpcReceiveHandler(__rpc_handler_432295350));
		NetworkManager.__rpc_func_table.Add(1141953697u, new RpcReceiveHandler(__rpc_handler_1141953697));
		NetworkManager.__rpc_func_table.Add(2397761797u, new RpcReceiveHandler(__rpc_handler_2397761797));
		NetworkManager.__rpc_func_table.Add(1407409549u, new RpcReceiveHandler(__rpc_handler_1407409549));
		NetworkManager.__rpc_func_table.Add(1561581057u, new RpcReceiveHandler(__rpc_handler_1561581057));
		NetworkManager.__rpc_func_table.Add(519961256u, new RpcReceiveHandler(__rpc_handler_519961256));
		NetworkManager.__rpc_func_table.Add(222504553u, new RpcReceiveHandler(__rpc_handler_222504553));
		NetworkManager.__rpc_func_table.Add(2560207573u, new RpcReceiveHandler(__rpc_handler_2560207573));
		NetworkManager.__rpc_func_table.Add(1162325818u, new RpcReceiveHandler(__rpc_handler_1162325818));
		NetworkManager.__rpc_func_table.Add(3309468324u, new RpcReceiveHandler(__rpc_handler_3309468324));
		NetworkManager.__rpc_func_table.Add(3512011720u, new RpcReceiveHandler(__rpc_handler_3512011720));
		NetworkManager.__rpc_func_table.Add(3192502457u, new RpcReceiveHandler(__rpc_handler_3192502457));
		NetworkManager.__rpc_func_table.Add(4032958935u, new RpcReceiveHandler(__rpc_handler_4032958935));
		NetworkManager.__rpc_func_table.Add(3071650946u, new RpcReceiveHandler(__rpc_handler_3071650946));
		NetworkManager.__rpc_func_table.Add(1687215509u, new RpcReceiveHandler(__rpc_handler_1687215509));
	}

	private static void __rpc_handler_3110137062(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).SetEnemyAsHavingNoPlayerServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1038760037(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).SetEnemyAsHavingNoPlayerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_657232826(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			bool setOutside = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setOutside, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).TeleportMaskedEnemyServerRpc(pos, setOutside);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2539470808(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			bool setOutside = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setOutside, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).TeleportMaskedEnemyClientRpc(pos, setOutside);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2502006210(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 dir = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref dir);
		float time = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref time, default(ForPrimitives));
		float vertLookAngle = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref vertLookAngle, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((MaskedPlayerEnemy)(object)target).LookAtDirectionServerRpc(dir, time, vertLookAngle);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_3625708449(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 dir = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref dir);
			float time = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref time, default(ForPrimitives));
			float vertLookAngle = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref vertLookAngle, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).LookAtDirectionClientRpc(dir, time, vertLookAngle);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_675153417(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			float time = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref time, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).LookAtPositionServerRpc(pos, time);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_432295350(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			float time = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref time, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).LookAtPositionClientRpc(pos, time);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1141953697(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).LookAtPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2397761797(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).LookAtPlayerClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1407409549(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).StopLookingAtTransformServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1561581057(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).StopLookingAtTransformClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_519961256(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool handsOutServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref handsOutServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).SetHandsOutServerRpc(handsOutServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_222504553(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool handsOutClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref handsOutClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).SetHandsOutClientRpc(handsOutClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2560207573(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool crouchingServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref crouchingServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).SetCrouchingServerRpc(crouchingServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1162325818(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool crouchingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref crouchingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).SetCrouchingClientRpc(crouchingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3309468324(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool runningServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref runningServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).SetRunningServerRpc(runningServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3512011720(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool runningClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref runningClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).SetRunningClientRpc(runningClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3192502457(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MaskedPlayerEnemy)(object)target).KillPlayerAnimationServerRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4032958935(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).CancelKillAnimationClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3071650946(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).KillPlayerAnimationClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1687215509(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference netObjectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref netObjectRef, default(ForNetworkSerializable));
			bool inFactory = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref inFactory, default(ForPrimitives));
			int playerKilled = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerKilled);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MaskedPlayerEnemy)(object)target).CreateMimicClientRpc(netObjectRef, inFactory, playerKilled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "MaskedPlayerEnemy";
	}
}
