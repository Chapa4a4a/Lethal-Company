using Unity.Netcode;
using UnityEngine;

public class ShipAlarmCord : NetworkBehaviour
{
	private bool hornBlaring;

	private float cordPulledDownTimer;

	public Animator cordAnimator;

	public AudioSource hornClose;

	public AudioSource hornFar;

	public AudioSource cordAudio;

	public AudioClip cordPullSFX;

	private bool otherClientHoldingCord;

	private float playAudibleNoiseInterval;

	private int timesPlayingAtOnce;

	public PlaceableShipObject shipObjectScript;

	private int unlockableID;

	private bool localClientHoldingCord;

	private void Start()
	{
		unlockableID = shipObjectScript.unlockableID;
	}

	public void HoldCordDown()
	{
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		if (otherClientHoldingCord)
		{
			return;
		}
		Debug.Log((object)"HOLD horn local client called");
		cordPulledDownTimer = 0.3f;
		if (!hornBlaring)
		{
			Debug.Log((object)"Hornblaring setting to true!");
			localClientHoldingCord = true;
			cordAnimator.SetBool("pulled", true);
			cordAudio.PlayOneShot(cordPullSFX);
			WalkieTalkie.TransmitOneShotAudio(cordAudio, cordPullSFX);
			RoundManager.Instance.PlayAudibleNoise(((Component)cordAudio).transform.position, 4.5f, 0.5f, 0, StartOfRound.Instance.hangarDoorsClosed);
			hornBlaring = true;
			if (!hornClose.isPlaying)
			{
				hornClose.Play();
				hornFar.Play();
			}
			PullCordServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	public void StopHorn()
	{
		if (hornBlaring)
		{
			Debug.Log((object)"Stop horn local client called");
			localClientHoldingCord = false;
			hornBlaring = false;
			cordAnimator.SetBool("pulled", false);
			StopPullingCordServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	private void Update()
	{
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		if (hornBlaring)
		{
			hornFar.volume = Mathf.Min(hornFar.volume + Time.deltaTime * 0.45f, 1f);
			hornFar.pitch = Mathf.Lerp(hornFar.pitch, 0.97f, Time.deltaTime * 0.8f);
			hornClose.volume = Mathf.Min(hornClose.volume + Time.deltaTime * 0.45f, 1f);
			hornClose.pitch = Mathf.Lerp(hornClose.pitch, 0.97f, Time.deltaTime * 0.8f);
			if (hornClose.volume > 0.6f && playAudibleNoiseInterval <= 0f)
			{
				playAudibleNoiseInterval = 1f;
				RoundManager.Instance.PlayAudibleNoise(((Component)hornClose).transform.position, 30f, 0.8f, timesPlayingAtOnce, noiseIsInsideClosedShip: false, 14155);
				timesPlayingAtOnce++;
			}
			else
			{
				playAudibleNoiseInterval -= Time.deltaTime;
			}
		}
		else
		{
			hornFar.volume = Mathf.Max(hornFar.volume - Time.deltaTime * 0.3f, 0f);
			hornFar.pitch = Mathf.Lerp(hornFar.pitch, 0.88f, Time.deltaTime * 0.5f);
			hornClose.volume = Mathf.Max(hornClose.volume - Time.deltaTime * 0.3f, 0f);
			hornClose.pitch = Mathf.Lerp(hornClose.pitch, 0.88f, Time.deltaTime * 0.5f);
			if (hornClose.volume <= 0f)
			{
				hornClose.Stop();
				hornFar.Stop();
				timesPlayingAtOnce = 0;
			}
		}
		if (localClientHoldingCord)
		{
			if (cordPulledDownTimer >= 0f && !StartOfRound.Instance.unlockablesList.unlockables[unlockableID].inStorage)
			{
				cordPulledDownTimer -= Time.deltaTime;
			}
			else if (hornBlaring)
			{
				StopHorn();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PullCordServerRpc(int playerPullingCord)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(504098657u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerPullingCord);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 504098657u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PullCordClientRpc(playerPullingCord);
			}
		}
	}

	[ClientRpc]
	public void PullCordClientRpc(int playerPullingCord)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1428666593u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerPullingCord);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1428666593u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		Debug.Log((object)"Received pull cord client rpc");
		if (!((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerPullingCord)
		{
			otherClientHoldingCord = true;
			hornBlaring = true;
			cordAnimator.SetBool("pulled", true);
			cordAudio.PlayOneShot(cordPullSFX);
			WalkieTalkie.TransmitOneShotAudio(cordAudio, cordPullSFX);
			if (!hornClose.isPlaying)
			{
				hornClose.Play();
			}
			if (!hornFar.isPlaying)
			{
				hornFar.Play();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StopPullingCordServerRpc(int playerPullingCord)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(967408504u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerPullingCord);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 967408504u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StopPullingCordClientRpc(playerPullingCord);
			}
		}
	}

	[ClientRpc]
	public void StopPullingCordClientRpc(int playerPullingCord)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2882145839u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerPullingCord);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2882145839u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		Debug.Log((object)"Received STOP pull cord client rpc");
		if (!((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerPullingCord)
		{
			otherClientHoldingCord = false;
			hornBlaring = false;
			cordAnimator.SetBool("pulled", false);
			if (StartOfRound.Instance.unlockablesList.unlockables[unlockableID].inStorage)
			{
				hornFar.volume = 0f;
				hornFar.pitch = 0.8f;
				hornClose.volume = 0f;
				hornClose.pitch = 0.8f;
			}
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ShipAlarmCord()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(504098657u, new RpcReceiveHandler(__rpc_handler_504098657));
		NetworkManager.__rpc_func_table.Add(1428666593u, new RpcReceiveHandler(__rpc_handler_1428666593));
		NetworkManager.__rpc_func_table.Add(967408504u, new RpcReceiveHandler(__rpc_handler_967408504));
		NetworkManager.__rpc_func_table.Add(2882145839u, new RpcReceiveHandler(__rpc_handler_2882145839));
	}

	private static void __rpc_handler_504098657(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerPullingCord = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerPullingCord);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShipAlarmCord)(object)target).PullCordServerRpc(playerPullingCord);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1428666593(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerPullingCord = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerPullingCord);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShipAlarmCord)(object)target).PullCordClientRpc(playerPullingCord);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_967408504(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerPullingCord = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerPullingCord);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ShipAlarmCord)(object)target).StopPullingCordServerRpc(playerPullingCord);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2882145839(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerPullingCord = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerPullingCord);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ShipAlarmCord)(object)target).StopPullingCordClientRpc(playerPullingCord);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ShipAlarmCord";
	}
}
