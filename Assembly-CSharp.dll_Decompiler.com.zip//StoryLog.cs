using Unity.Netcode;
using UnityEngine;

public class StoryLog : NetworkBehaviour
{
	public int storyLogID = -1;

	private bool collected;

	public void CollectLog()
	{
		if (!((Object)(object)NetworkManager.Singleton == (Object)null) && !((Object)(object)GameNetworkManager.Instance == (Object)null) && !collected && storyLogID != -1)
		{
			collected = true;
			RemoveLogCollectible();
			if (!Object.FindObjectOfType<Terminal>().unlockedStoryLogs.Contains(storyLogID))
			{
				HUDManager.Instance.GetNewStoryLogServerRpc(storyLogID);
			}
		}
	}

	private void Start()
	{
		if (Object.FindObjectOfType<Terminal>().unlockedStoryLogs.Contains(storyLogID))
		{
			RemoveLogCollectible();
		}
	}

	private void RemoveLogCollectible()
	{
		MeshRenderer[] componentsInChildren = ((Component)this).gameObject.GetComponentsInChildren<MeshRenderer>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			((Renderer)componentsInChildren[i]).enabled = false;
		}
		((Component)this).gameObject.GetComponent<InteractTrigger>().interactable = false;
		Collider[] componentsInChildren2 = ((Component)this).GetComponentsInChildren<Collider>();
		for (int j = 0; j < componentsInChildren2.Length; j++)
		{
			componentsInChildren2[j].enabled = false;
		}
	}

	public void SetStoryLogID(int logID)
	{
		storyLogID = logID;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "StoryLog";
	}
}
