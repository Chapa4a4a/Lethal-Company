using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering.HighDefinition;

public class VehicleController : NetworkBehaviour
{
	public int vehicleID;

	[Header("Vehicle Physics")]
	public WheelCollider FrontLeftWheel;

	public WheelCollider FrontRightWheel;

	public WheelCollider BackLeftWheel;

	public WheelCollider BackRightWheel;

	public WheelCollider[] otherWheels;

	public Rigidbody mainRigidbody;

	public Transform[] driverSideExitPoints;

	public Transform[] passengerSideExitPoints;

	public InteractTrigger driverSeatTrigger;

	public InteractTrigger passengerSeatTrigger;

	public float stability = 0.3f;

	public float speed = 2f;

	public float EngineTorque = 230f;

	public float MaxEngineRPM = 3000f;

	public float MinEngineRPM = 1000f;

	public float EngineRPM;

	[Header("Vehicle Control")]
	public bool ignitionStarted;

	public Vector2 moveInputVector;

	public float steeringInput;

	public float steeringWheelTurnSpeed = 5f;

	public float carAcceleration = 5f;

	public float carMaxSpeed = 7f;

	public float brakeSpeed = 5f;

	public float idleSpeed = 2f;

	[Space(5f)]
	[Header("Car Damage")]
	public float carFragility = 1f;

	public float minimalBumpForce = 10f;

	public float mediumBumpForce = 40f;

	public float maximumBumpForce = 80f;

	public int baseCarHP;

	public int carHP = 12;

	private float timeAtLastDamage;

	public bool carDestroyed;

	[Space(5f)]
	[Header("Effects")]
	public MeshRenderer leftWheelMesh;

	public MeshRenderer rightWheelMesh;

	public MeshRenderer backLeftWheelMesh;

	public MeshRenderer backRightWheelMesh;

	public Animator steeringWheelAnimator;

	public Animator gearStickAnimator;

	public AudioSource engineAudio1;

	public AudioSource engineAudio2;

	public AudioSource rollingAudio;

	public AudioSource turbulenceAudio;

	private float turbulenceAmount;

	public bool carEngine1AudioActive;

	public bool carEngine2AudioActive;

	public bool carRollingAudioActive;

	public AudioClip revEngineStart;

	public AudioClip engineStartSuccessful;

	public AudioClip engineRun;

	public AudioClip engineRev;

	public AudioClip engineRun2;

	public AudioClip insertKey;

	public AudioClip twistKey;

	public AudioClip removeKey;

	public AudioClip sitDown;

	public AudioSource tireAudio;

	public AudioSource vehicleEngineAudio;

	public AudioSource steeringWheelAudio;

	public AudioSource skiddingAudio;

	public AudioSource gearStickAudio;

	public AudioClip[] gearStickAudios;

	public AnimatedObjectTrigger driverSideDoor;

	public AnimatedObjectTrigger passengerSideDoor;

	public InteractTrigger driverSideDoorTrigger;

	public InteractTrigger passengerSideDoorTrigger;

	public PlayerInput input;

	public bool localPlayerInControl;

	public bool localPlayerInPassengerSeat;

	public bool drivePedalPressed;

	public bool brakePedalPressed;

	public CarGearShift gear;

	public float gearStickAnimValue;

	public float steeringAnimValue;

	private float steeringWheelAnimFloat;

	public float carStress;

	public float carStressChange;

	public PlayerControllerB currentDriver;

	public PlayerControllerB currentPassenger;

	public bool testingVehicleInEditor;

	public float engineIntensityPercentage = 350f;

	public Vector3 syncedPosition;

	public Quaternion syncedRotation;

	public float syncSpeedMultiplier = 2f;

	public float syncRotationSpeed = 1f;

	public float syncCarPositionInterval;

	private bool enabledCollisionForAllPlayers = true;

	public ContactPoint[] contacts;

	public PlayerPhysicsRegion physicsRegion;

	private int exitCarLayerMask = 2305;

	private Coroutine keyIgnitionCoroutine;

	public MeshRenderer keyObject;

	public Transform ignitionTurnedPosition;

	public Transform ignitionNotTurnedPosition;

	private bool keyIsInDriverHand;

	private bool keyIsInIgnition;

	public Vector3 positionOffset;

	public Vector3 rotationOffset;

	public GameObject startKeyIgnitionTrigger;

	public GameObject removeKeyIgnitionTrigger;

	private float chanceToStartIgnition = 1f;

	private float timeAtLastGearShift;

	private RaycastHit hit;

	public AudioSource hoodAudio;

	public AudioSource pushAudio;

	public AudioSource collisionAudio1;

	public AudioSource collisionAudio2;

	public AudioClip[] maxCollisions;

	public AudioClip[] medCollisions;

	public AudioClip[] minCollisions;

	public AudioClip[] obstacleCollisions;

	public AudioClip windshieldBreak;

	public AudioSource miscAudio;

	private float audio1Time;

	private float audio2Time;

	private int audio1Type;

	private int audio2Type;

	public MeshRenderer mainBodyMesh;

	public MeshRenderer lod1Mesh;

	public MeshRenderer lod2Mesh;

	public Material windshieldBrokenMat;

	public ParticleSystem glassParticle;

	private bool windshieldBroken;

	private Vector3 truckVelocityLastFrame;

	public bool useVel;

	[Header("Radio")]
	public AudioClip[] radioClips;

	public AudioSource radioAudio;

	public AudioSource radioInterference;

	private float radioSignalQuality = 3f;

	private float radioSignalDecreaseThreshold = 50f;

	public float radioSignalTurbulence = 4f;

	private float changeRadioSignalTime;

	private bool radioOn;

	private int currentRadioClip;

	private float currentSongTime;

	private bool radioTurnedOnBefore;

	public float carHitPlayerForceFraction = 30f;

	public float carReactToPlayerHitMultiplier;

	public ParticleSystem carExhaustParticle;

	public Vector3 averageVelocity;

	public int movingAverageLength = 20;

	public int averageCount;

	private DecalProjector[] decals;

	private int decalIndex;

	public ParticleSystem hoodFireParticle;

	public AudioSource hoodFireAudio;

	private bool isHoodOnFire;

	private bool carHoodOpen;

	public Animator carHoodAnimator;

	private AudioClip carHoodOpenSFX;

	private AudioClip carHoodCloseSFX;

	public GameObject backDoorContainer;

	public GameObject destroyedTruckMesh;

	public GameObject truckDestroyedExplosion;

	private bool hoodPoppedUp;

	public float pushForceMultiplier;

	public float pushVerticalOffsetAmount;

	public GameObject headlightsContainer;

	public Material headlightsOnMat;

	public Material headlightsOffMat;

	public AudioClip headlightsToggleSFX;

	public bool magnetedToShip;

	private Vector3 magnetTargetPosition;

	private Quaternion magnetTargetRotation;

	private Quaternion magnetStartRotation;

	private Vector3 magnetStartPosition;

	public float magnetTime;

	private bool finishedMagneting;

	private bool loadedVehicleFromSave;

	private float magnetRotationTime;

	public BoxCollider boundsCollider;

	private Vector3 averageVelocityAtMagnetStart;

	public AnimationCurve magnetPositionCurve;

	public AnimationCurve magnetRotationCurve;

	private bool destroyNextFrame;

	private string lastStressType;

	private string lastDamageType;

	private float stressPerSecond;

	public Rigidbody ragdollPhysicsBody;

	public Rigidbody windwiperPhysicsBody1;

	public Rigidbody windwiperPhysicsBody2;

	public Transform windwiper1;

	public Transform windwiper2;

	public BoxCollider windshieldPhysicsCollider;

	public Animator driverSeatSpringAnimator;

	public float timeSinceSpringingDriverSeat;

	public AudioSource springAudio;

	public float springForce = 70f;

	public GameObject backLightsContainer;

	public GameObject frontCabinLightContainer;

	public MeshRenderer backLightsMesh;

	public MeshRenderer frontCabinLightMesh;

	public Material backLightOnMat;

	public bool backLightsOn;

	public AudioSource hornAudio;

	public bool honkingHorn;

	private float timeAtLastHornPing;

	private float timeAtLastEngineAudioPing;

	public float torqueForce;

	public bool backDoorOpen;

	public bool hasBeenSpawned;

	public bool inDropshipAnimation;

	private ItemDropship itemShip;

	public ParticleSystem tireSparks;

	public AudioSource extremeStressAudio;

	private bool underExtremeStress;

	private bool syncedExtremeStress;

	public Transform healthMeter;

	public Transform turboMeter;

	public Transform clipboardPosition;

	private float limitTruckVelocityTimer;

	[Header("Boost ability")]
	private bool switchGearsBoostEnabled;

	private int turboBoosts;

	private bool pressedTurbo;

	public float turboBoostForce;

	public float turboBoostUpwardForce;

	public ParticleSystem turboBoostParticle;

	public AudioSource turboBoostAudio;

	public AudioClip turboBoostSFX;

	public AudioClip turboBoostSFX2;

	public Transform oilPipePoint;

	private bool jumpingInCar;

	public float jumpForce = 4000f;

	public AudioClip jumpInCarSFX;

	private string[] carTooltips = new string[3] { "Gas pedal: [W]", "Brake pedal: [S]", "Boost: [Space]" };

	public AudioClip pourOil;

	public AudioClip pourTurbo;

	private bool setControlTips;

	public Collider ontopOfTruckCollider;

	public void SetBackDoorOpen(bool open)
	{
		backDoorOpen = open;
	}

	private void SetFrontCabinLightOn(bool setOn)
	{
		frontCabinLightContainer.SetActive(setOn);
		if (setOn)
		{
			((Renderer)frontCabinLightMesh).material = headlightsOnMat;
		}
		else
		{
			((Renderer)frontCabinLightMesh).material = headlightsOffMat;
		}
	}

	private void SetWheelFriction()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		WheelFrictionCurve val = default(WheelFrictionCurve);
		((WheelFrictionCurve)(ref val)).extremumSlip = 0.2f;
		((WheelFrictionCurve)(ref val)).extremumValue = 1f;
		((WheelFrictionCurve)(ref val)).asymptoteSlip = 0.8f;
		((WheelFrictionCurve)(ref val)).asymptoteValue = 1f;
		((WheelFrictionCurve)(ref val)).stiffness = 2f;
		FrontRightWheel.forwardFriction = val;
		FrontLeftWheel.forwardFriction = val;
		((WheelFrictionCurve)(ref val)).stiffness = 0.75f;
		BackRightWheel.forwardFriction = val;
		BackLeftWheel.forwardFriction = val;
		((WheelFrictionCurve)(ref val)).stiffness = 2f;
		((WheelFrictionCurve)(ref val)).asymptoteValue = 1f;
		((WheelFrictionCurve)(ref val)).extremumSlip = 0.7f;
		FrontRightWheel.sidewaysFriction = val;
		FrontLeftWheel.sidewaysFriction = val;
		BackRightWheel.sidewaysFriction = val;
		BackLeftWheel.sidewaysFriction = val;
	}

	private void Awake()
	{
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		contacts = (ContactPoint[])(object)new ContactPoint[24];
		((Component)ragdollPhysicsBody).transform.SetParent(RoundManager.Instance.VehiclesContainer);
		((Component)windwiperPhysicsBody1).transform.SetParent(RoundManager.Instance.VehiclesContainer);
		((Component)windwiperPhysicsBody2).transform.SetParent(RoundManager.Instance.VehiclesContainer);
		mainRigidbody.maxLinearVelocity = 50f;
		mainRigidbody.maxAngularVelocity = 4f;
		syncedPosition = ((Component)this).transform.position;
		syncedRotation = ((Component)this).transform.rotation;
	}

	private void Start()
	{
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		carHP = baseCarHP;
		SetWheelFriction();
		FrontLeftWheel.brakeTorque = 1000f;
		FrontRightWheel.brakeTorque = 1000f;
		BackLeftWheel.brakeTorque = 1000f;
		BackRightWheel.brakeTorque = 1000f;
		if (testingVehicleInEditor)
		{
			ActivateControl();
		}
		Debug.Log((object)$"Max linear velocity: {mainRigidbody.maxLinearVelocity}; dep: {mainRigidbody.maxDepenetrationVelocity}");
		mainRigidbody.automaticCenterOfMass = false;
		Rigidbody obj = mainRigidbody;
		obj.centerOfMass += new Vector3(0f, -1f, 0.25f);
		mainRigidbody.automaticInertiaTensor = false;
		mainRigidbody.maxDepenetrationVelocity = 1f;
		currentRadioClip = new Random(StartOfRound.Instance.randomMapSeed).Next(0, radioClips.Length);
		decals = (DecalProjector[])(object)new DecalProjector[24];
		if (StartOfRound.Instance.inShipPhase)
		{
			hasBeenSpawned = true;
			magnetedToShip = true;
			loadedVehicleFromSave = true;
			((Component)this).transform.position = StartOfRound.Instance.magnetPoint.position + StartOfRound.Instance.magnetPoint.forward * 7f;
			StartMagneting();
		}
	}

	public void RemoveKeyFromIgnition()
	{
		if (localPlayerInControl)
		{
			if (keyIgnitionCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(keyIgnitionCoroutine);
			}
			keyIgnitionCoroutine = ((MonoBehaviour)this).StartCoroutine(RemoveKey());
			GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 6);
			RemoveKeyFromIgnitionServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void RemoveKeyFromIgnitionServerRpc(int driverId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(269855870u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, driverId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 269855870u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				RemoveKeyFromIgnitionClientRpc(driverId);
			}
		}
	}

	[ClientRpc]
	public void RemoveKeyFromIgnitionClientRpc(int driverId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1127926854u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, driverId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1127926854u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != driverId)
		{
			if (keyIgnitionCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(keyIgnitionCoroutine);
			}
			keyIgnitionCoroutine = ((MonoBehaviour)this).StartCoroutine(RemoveKey());
		}
	}

	private IEnumerator RemoveKey()
	{
		yield return (object)new WaitForSeconds(0.26f);
		if ((Object)(object)currentDriver != (Object)null)
		{
			currentDriver.movementAudio.PlayOneShot(removeKey);
		}
		keyIsInDriverHand = true;
		SetIgnition(started: false);
		SetFrontCabinLightOn(setOn: false);
		yield return (object)new WaitForSeconds(0.73f);
		keyIsInDriverHand = false;
		keyIgnitionCoroutine = null;
	}

	public void CancelTryCarIgnition()
	{
		if (localPlayerInControl && !ignitionStarted)
		{
			if (keyIsInIgnition)
			{
				GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 3);
			}
			else
			{
				GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 0);
			}
			carEngine1AudioActive = false;
			CancelIgnitionAnimation();
			CancelTryIgnitionServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId, keyIsInIgnition);
		}
	}

	public void StartTryCarIgnition()
	{
		if (localPlayerInControl && !ignitionStarted)
		{
			if (keyIgnitionCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(keyIgnitionCoroutine);
			}
			keyIgnitionCoroutine = ((MonoBehaviour)this).StartCoroutine(TryIgnition(isLocalDriver: true));
			TryIgnitionServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId, keyIsInIgnition);
		}
	}

	private IEnumerator TryIgnition(bool isLocalDriver)
	{
		Debug.Log((object)"Starting ignition!!!");
		if (keyIsInIgnition)
		{
			if (isLocalDriver)
			{
				if (GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.GetInteger("SA_CarAnim") == 3)
				{
					GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 2);
				}
				else
				{
					GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 12);
				}
			}
			yield return (object)new WaitForSeconds(0.035f);
			keyIsInDriverHand = true;
			currentDriver.movementAudio.PlayOneShot(twistKey);
			if (!isLocalDriver)
			{
				keyIgnitionCoroutine = null;
				yield break;
			}
			yield return (object)new WaitForSeconds(0.1467f);
		}
		else
		{
			if (isLocalDriver)
			{
				GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 2);
			}
			keyIsInDriverHand = true;
			yield return (object)new WaitForSeconds(0.66f);
			currentDriver.movementAudio.PlayOneShot(insertKey);
			if (!isLocalDriver)
			{
				keyIgnitionCoroutine = null;
				yield break;
			}
			yield return (object)new WaitForSeconds(0.3f);
		}
		keyIsInIgnition = true;
		SetFrontCabinLightOn(keyIsInIgnition);
		RevCarServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		engineAudio1.clip = revEngineStart;
		engineAudio1.volume = 0.7f;
		engineAudio1.PlayOneShot(engineRev);
		carEngine1AudioActive = true;
		yield return (object)new WaitForSeconds(Random.Range(0.4f, 1.1f));
		if ((float)Random.Range(0, 100) < chanceToStartIgnition)
		{
			SetIgnition(started: true);
			keyIsInDriverHand = false;
			GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 1);
			StartIgnitionServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
		else
		{
			chanceToStartIgnition += 24f;
		}
		keyIgnitionCoroutine = null;
	}

	[ServerRpc(RequireOwnership = false)]
	public void RevCarServerRpc(int driverId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1319663544u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, driverId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1319663544u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				RevCarClientRpc(driverId);
			}
		}
	}

	[ClientRpc]
	public void RevCarClientRpc(int driverId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3214494774u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, driverId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3214494774u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != driverId)
			{
				engineAudio1.clip = revEngineStart;
				engineAudio1.volume = 0.7f;
				engineAudio1.PlayOneShot(engineRev);
				carEngine1AudioActive = true;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StartIgnitionServerRpc(int driverId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2403570091u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, driverId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2403570091u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StartIgnitionClientRpc(driverId);
			}
		}
	}

	[ClientRpc]
	public void StartIgnitionClientRpc(int driverId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3273216474u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, driverId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3273216474u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != driverId)
			{
				SetIgnition(started: true);
				CancelIgnitionAnimation();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void TryIgnitionServerRpc(int driverId, bool keyIsIn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(835626980u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, driverId);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref keyIsIn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 835626980u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				TryIgnitionClientRpc(driverId, keyIsIn);
			}
		}
	}

	[ClientRpc]
	public void TryIgnitionClientRpc(int driverId, bool keyIsIn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3548459446u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, driverId);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref keyIsIn, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3548459446u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != driverId && !ignitionStarted)
		{
			keyIsInIgnition = keyIsIn;
			if (keyIgnitionCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(keyIgnitionCoroutine);
			}
			keyIgnitionCoroutine = ((MonoBehaviour)this).StartCoroutine(TryIgnition(isLocalDriver: false));
			if (!keyIsInIgnition)
			{
				GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 0);
			}
			else
			{
				GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 3);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void CancelTryIgnitionServerRpc(int driverId, bool setKeyInSlot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4283235241u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, driverId);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setKeyInSlot, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4283235241u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				CancelTryIgnitionClientRpc(driverId, setKeyInSlot);
			}
		}
	}

	[ClientRpc]
	public void CancelTryIgnitionClientRpc(int driverId, bool setKeyInSlot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2096620717u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, driverId);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setKeyInSlot, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2096620717u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != driverId)
		{
			if (ignitionStarted)
			{
				SetIgnition(started: false);
			}
			if (keyIgnitionCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(keyIgnitionCoroutine);
			}
			carEngine1AudioActive = false;
			keyIsInIgnition = setKeyInSlot;
			SetFrontCabinLightOn(keyIsInIgnition);
		}
	}

	public void CancelIgnitionAnimation()
	{
		if (keyIgnitionCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(keyIgnitionCoroutine);
			keyIgnitionCoroutine = null;
		}
		keyIsInDriverHand = false;
	}

	public void SetIgnition(bool started)
	{
		keyIsInIgnition = started;
		SetFrontCabinLightOn(keyIsInIgnition);
		if (started)
		{
			startKeyIgnitionTrigger.SetActive(false);
			removeKeyIgnitionTrigger.SetActive(true);
		}
		else
		{
			startKeyIgnitionTrigger.SetActive(true);
			removeKeyIgnitionTrigger.SetActive(false);
		}
		if (started != ignitionStarted)
		{
			ignitionStarted = started;
			carEngine1AudioActive = started;
			if (started)
			{
				carExhaustParticle.Play();
				engineAudio1.PlayOneShot(engineStartSuccessful);
				engineAudio1.clip = engineRun;
			}
			else
			{
				carExhaustParticle.Stop(true, (ParticleSystemStopBehavior)1);
			}
		}
	}

	public void ExitDriverSideSeat()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"local player in control? : {localPlayerInControl}");
		if (!localPlayerInControl)
		{
			return;
		}
		GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 0);
		int num = CanExitCar(passengerSide: true);
		if (num != -1)
		{
			GameNetworkManager.Instance.localPlayerController.TeleportPlayer(driverSideExitPoints[num].position);
			return;
		}
		if (!driverSideDoor.boolValue)
		{
			driverSideDoor.TriggerAnimation(GameNetworkManager.Instance.localPlayerController);
		}
		GameNetworkManager.Instance.localPlayerController.TeleportPlayer(driverSideExitPoints[1].position);
	}

	public void OnPassengerExit()
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		passengerSeatTrigger.interactable = true;
		localPlayerInPassengerSeat = false;
		currentPassenger = null;
		SetVehicleCollisionForPlayer(setEnabled: true, GameNetworkManager.Instance.localPlayerController);
		PassengerLeaveVehicleServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position);
	}

	public void ExitPassengerSideSeat()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (localPlayerInPassengerSeat)
		{
			int num = CanExitCar(passengerSide: true);
			if (num != -1)
			{
				GameNetworkManager.Instance.localPlayerController.TeleportPlayer(passengerSideExitPoints[num].position);
			}
			else
			{
				GameNetworkManager.Instance.localPlayerController.TeleportPlayer(passengerSideExitPoints[1].position);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PassengerLeaveVehicleServerRpc(int playerId, Vector3 exitPoint)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2150817317u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref exitPoint);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2150817317u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PassengerLeaveVehicleClientRpc(playerId, exitPoint);
			}
		}
	}

	[ClientRpc]
	public void PassengerLeaveVehicleClientRpc(int playerId, Vector3 exitPoint)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(46680660u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref exitPoint);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 46680660u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[playerId];
		if (!((Object)(object)playerControllerB == (Object)(object)GameNetworkManager.Instance.localPlayerController))
		{
			playerControllerB.TeleportPlayer(exitPoint);
			currentPassenger = null;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				SetVehicleCollisionForPlayer(setEnabled: true, GameNetworkManager.Instance.localPlayerController);
			}
			passengerSeatTrigger.interactable = true;
		}
	}

	public void SetPlayerInCar(PlayerControllerB player)
	{
		player.movementAudio.PlayOneShot(sitDown);
	}

	public void SetPassengerInCar(PlayerControllerB player)
	{
		if (passengerSideDoor.boolValue)
		{
			passengerSideDoor.SetBoolOnClientOnly(setTo: false);
		}
		if ((Object)(object)player == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			localPlayerInPassengerSeat = true;
		}
		else
		{
			passengerSeatTrigger.interactable = false;
		}
		currentPassenger = player;
	}

	private int CanExitCar(bool passengerSide)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (passengerSide)
		{
			for (int i = 0; i < driverSideExitPoints.Length; i++)
			{
				if (!Physics.Linecast(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position, driverSideExitPoints[i].position, exitCarLayerMask, (QueryTriggerInteraction)1))
				{
					return i;
				}
			}
			return -1;
		}
		for (int j = 0; j < passengerSideExitPoints.Length; j++)
		{
			if (!Physics.Linecast(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position, passengerSideExitPoints[j].position, exitCarLayerMask, (QueryTriggerInteraction)1))
			{
				return j;
			}
		}
		return -1;
	}

	public void TakeControlOfVehicle()
	{
		if ((Object)(object)currentDriver != (Object)null)
		{
			GameNetworkManager.Instance.localPlayerController.CancelSpecialTriggerAnimations();
			return;
		}
		if (driverSideDoor.boolValue)
		{
			driverSideDoor.TriggerAnimation(GameNetworkManager.Instance.localPlayerController);
		}
		ActivateControl();
		GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetFloat("animationSpeed", 0.5f);
		if (ignitionStarted)
		{
			GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 1);
		}
		else
		{
			GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 0);
		}
		driverSideDoorTrigger.hoverTip = "Exit : [LMB]";
		SetVehicleCollisionForPlayer(setEnabled: false, GameNetworkManager.Instance.localPlayerController);
		if (!testingVehicleInEditor)
		{
			SetPlayerInControlOfVehicleServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	public void LoseControlOfVehicle()
	{
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		driverSideDoorTrigger.hoverTip = "Use door : [LMB]";
		GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 0);
		localPlayerInControl = false;
		DisableVehicleCollisionForAllPlayers();
		if (((Vector3)(ref averageVelocity)).magnitude < 3f)
		{
			limitTruckVelocityTimer = 0.7f;
		}
		if (!((Object)(object)currentDriver != (Object)(object)GameNetworkManager.Instance.localPlayerController))
		{
			DisableControl();
			steeringAnimValue = 0f;
			keyIsInDriverHand = false;
			CancelIgnitionAnimation();
			chanceToStartIgnition = 20f;
			if (!testingVehicleInEditor)
			{
				RemovePlayerControlOfVehicleServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId, ((Component)this).transform.position, ((Component)this).transform.rotation, ignitionStarted);
			}
			if ((Object)(object)GameNetworkManager.Instance.localPlayerController.currentlyHeldObjectServer != (Object)null)
			{
				GameNetworkManager.Instance.localPlayerController.currentlyHeldObjectServer.SetControlTipsForItem();
			}
			else
			{
				HUDManager.Instance.ClearControlTips();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetPlayerInControlOfVehicleServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2687785832u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2687785832u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[playerId];
		if ((Object)(object)playerControllerB == (Object)null || playerControllerB.isPlayerDead || !playerControllerB.isPlayerControlled)
		{
			return;
		}
		if ((Object)(object)currentDriver != (Object)null && !((NetworkBehaviour)playerControllerB).IsServer)
		{
			CancelPlayerInControlOfVehicleClientRpc(playerId);
			return;
		}
		currentDriver = StartOfRound.Instance.allPlayerScripts[playerId];
		((NetworkBehaviour)this).NetworkObject.ChangeOwnership(StartOfRound.Instance.allPlayerScripts[playerId].actualClientId);
		if (((Vector3)(ref averageVelocity)).magnitude < 3f)
		{
			limitTruckVelocityTimer = 0.7f;
		}
		SetPlayerInControlOfVehicleClientRpc(playerId);
	}

	[ClientRpc]
	public void CancelPlayerInControlOfVehicleClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1621098866u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1621098866u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerId == (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				ExitDriverSideSeat();
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void RemovePlayerControlOfVehicleServerRpc(int playerId, Vector3 carLocation, Quaternion carRotation, bool setKeyInIgnition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2345405857u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref carLocation);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref carRotation);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setKeyInIgnition, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2345405857u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !((Object)(object)StartOfRound.Instance.allPlayerScripts[playerId] == (Object)null))
			{
				syncedPosition = carLocation;
				syncedRotation = carRotation;
				((NetworkBehaviour)this).NetworkObject.ChangeOwnership(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
				RemovePlayerControlOfVehicleClientRpc(playerId, setKeyInIgnition);
			}
		}
	}

	[ClientRpc]
	public void SetPlayerInControlOfVehicleClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2569589533u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2569589533u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerId)
		{
			if (((Vector3)(ref averageVelocity)).magnitude < 3f)
			{
				limitTruckVelocityTimer = 0.7f;
			}
			Debug.Log((object)$"Set player in control: {playerId} ");
			currentDriver = StartOfRound.Instance.allPlayerScripts[playerId];
			StartOfRound.Instance.allPlayerScripts[playerId].playerBodyAnimator.SetFloat("animationSpeed", 0.5f);
			SetVehicleCollisionForPlayer(setEnabled: false, currentDriver);
		}
	}

	[ClientRpc]
	public void RemovePlayerControlOfVehicleClientRpc(int playerId, bool setIgnitionStarted)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1936869671u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setIgnitionStarted, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1936869671u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerId)
			{
				CancelIgnitionAnimation();
				SetIgnition(setIgnitionStarted);
				currentDriver = null;
				steeringAnimValue = 0f;
			}
		}
	}

	public void DisableVehicleCollisionForAllPlayers()
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (!localPlayerInControl && (Object)(object)StartOfRound.Instance.allPlayerScripts[i] == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				((Collider)((Component)StartOfRound.Instance.allPlayerScripts[i]).GetComponent<CharacterController>()).excludeLayers = LayerMask.op_Implicit(0);
			}
			else
			{
				((Collider)((Component)StartOfRound.Instance.allPlayerScripts[i]).GetComponent<CharacterController>()).excludeLayers = LayerMask.op_Implicit(1073741824);
			}
		}
	}

	public void EnableVehicleCollisionForAllPlayers()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if ((Object)(object)StartOfRound.Instance.allPlayerScripts[i] != (Object)(object)currentPassenger)
			{
				((Collider)((Component)StartOfRound.Instance.allPlayerScripts[i]).GetComponent<CharacterController>()).excludeLayers = LayerMask.op_Implicit(0);
			}
		}
	}

	public void SetVehicleCollisionForPlayer(bool setEnabled, PlayerControllerB player)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (!setEnabled)
		{
			((Collider)((Component)player).GetComponent<CharacterController>()).excludeLayers = LayerMask.op_Implicit(1073741824);
		}
		else
		{
			((Collider)((Component)player).GetComponent<CharacterController>()).excludeLayers = LayerMask.op_Implicit(0);
		}
	}

	private void ActivateControl()
	{
		InputActionAsset val = ((!testingVehicleInEditor) ? IngamePlayerSettings.Instance.playerInput.actions : input.actions);
		val.FindAction("Jump", false).performed += DoTurboBoost;
		localPlayerInControl = true;
		if (!testingVehicleInEditor)
		{
			currentDriver = GameNetworkManager.Instance.localPlayerController;
		}
	}

	private void DisableControl()
	{
		InputActionAsset val = ((!testingVehicleInEditor) ? IngamePlayerSettings.Instance.playerInput.actions : input.actions);
		val.FindAction("Jump", false).performed -= DoTurboBoost;
		localPlayerInControl = false;
		drivePedalPressed = false;
		brakePedalPressed = false;
		currentDriver = null;
	}

	public void ShiftGearForward()
	{
		if (gear != CarGearShift.Park)
		{
			if (gear == CarGearShift.Reverse)
			{
				Debug.Log((object)"Switching gears forward; 3");
				ShiftToGear(3);
			}
			else if (gear == CarGearShift.Drive)
			{
				Debug.Log((object)"Switching gears forward; 2");
				ShiftToGear(2);
			}
		}
	}

	private void ShiftGearForwardInput(CallbackContext context)
	{
		if (((CallbackContext)(ref context)).performed)
		{
			ShiftGearForward();
		}
	}

	private void ShiftGearBack()
	{
		if (gear != CarGearShift.Drive)
		{
			if (gear == CarGearShift.Park)
			{
				Debug.Log((object)"Switching gears; 2");
				ShiftToGear(2);
			}
			else if (gear == CarGearShift.Reverse)
			{
				Debug.Log((object)"Switching gears; 1");
				ShiftToGear(1);
			}
		}
	}

	private void ShiftToGear(int setGear)
	{
		gear = (CarGearShift)setGear;
		gearStickAudio.PlayOneShot(gearStickAudios[setGear - 1]);
		if (gear != CarGearShift.Park)
		{
			Debug.Log((object)"Enabling switch gears boost");
			switchGearsBoostEnabled = true;
		}
		else
		{
			Debug.Log((object)"Disabling switch gears boost");
			switchGearsBoostEnabled = false;
		}
	}

	public void ShiftToGearAndSync(int setGear)
	{
		if (gear != (CarGearShift)setGear)
		{
			timeAtLastGearShift = Time.realtimeSinceStartup;
			gear = (CarGearShift)setGear;
			gearStickAudio.PlayOneShot(gearStickAudios[setGear - 1]);
			if (gear != CarGearShift.Park)
			{
				Debug.Log((object)"Shift to gear and sync; gear is not park");
				switchGearsBoostEnabled = true;
			}
			ShiftToGearServerRpc(setGear, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ShiftToGearServerRpc(int setGear, int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1427257619u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, setGear);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1427257619u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ShiftToGearClientRpc(setGear, playerId);
			}
		}
	}

	[ClientRpc]
	public void ShiftToGearClientRpc(int setGear, int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2335366121u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, setGear);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2335366121u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerId)
		{
			timeAtLastGearShift = Time.realtimeSinceStartup;
			gear = (CarGearShift)setGear;
			gearStickAudio.PlayOneShot(gearStickAudios[setGear - 1]);
			if (gear != CarGearShift.Park)
			{
				switchGearsBoostEnabled = true;
			}
		}
	}

	private void ShiftGearBackInput(CallbackContext context)
	{
		if (((CallbackContext)(ref context)).performed)
		{
			ShiftGearBack();
		}
	}

	private void GetVehicleInput()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (localPlayerInControl)
		{
			if (testingVehicleInEditor)
			{
				moveInputVector = input.actions.FindAction("Move", false).ReadValue<Vector2>();
			}
			else
			{
				moveInputVector = IngamePlayerSettings.Instance.playerInput.actions.FindAction("Move", false).ReadValue<Vector2>();
			}
			float num = steeringWheelTurnSpeed;
			steeringInput = Mathf.Clamp(steeringInput + moveInputVector.x * num * Time.deltaTime, -3f, 3f);
			if (Mathf.Abs(moveInputVector.x) > 0.1f)
			{
				steeringWheelAudio.volume = Mathf.Lerp(steeringWheelAudio.volume, Mathf.Abs(moveInputVector.x), 5f * Time.deltaTime);
			}
			else
			{
				steeringWheelAudio.volume = Mathf.Lerp(steeringWheelAudio.volume, 0f, 5f * Time.deltaTime);
			}
			steeringAnimValue = moveInputVector.x;
			drivePedalPressed = moveInputVector.y > 0.1f;
			brakePedalPressed = moveInputVector.y < -0.1f;
		}
	}

	[ServerRpc]
	public void SyncCarPositionServerRpc(Vector3 carPosition, Vector3 carRotation, float steeringInput, float EngineRPM)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Invalid comparison between Unknown and I4
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2803421723u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref carPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref carRotation);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref steeringInput, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref EngineRPM, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2803421723u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncCarPositionClientRpc(carPosition, carRotation, steeringInput, EngineRPM);
		}
	}

	[ClientRpc]
	public void SyncCarPositionClientRpc(Vector3 carPosition, Vector3 carRotation, float steeringInput, float engineSpeed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3105401376u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref carPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref carRotation);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref steeringInput, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref engineSpeed, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3105401376u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				((Component)this).gameObject.GetComponent<Rigidbody>().isKinematic = true;
				syncedPosition = carPosition;
				syncedRotation = Quaternion.Euler(carRotation);
				steeringAnimValue = steeringInput;
				EngineRPM = engineSpeed;
			}
		}
	}

	[ServerRpc]
	public void MagnetCarServerRpc(Vector3 targetPosition, Vector3 targetRotation, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Invalid comparison between Unknown and I4
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2451439781u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetRotation);
			BytePacker.WriteValueBitPacked(val2, playerWhoSent);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2451439781u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			MagnetCarClientRpc(targetPosition, targetRotation, playerWhoSent);
		}
	}

	[ClientRpc]
	public void MagnetCarClientRpc(Vector3 targetPosition, Vector3 targetRotation, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2845017736u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetRotation);
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2845017736u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerWhoSent)
			{
				magnetedToShip = true;
				magnetTime = 0f;
				magnetRotationTime = 0f;
				StartOfRound.Instance.isObjectAttachedToMagnet = true;
				StartOfRound.Instance.attachedVehicle = this;
				magnetStartPosition = ((Component)this).transform.position;
				magnetStartRotation = ((Component)this).transform.rotation;
				magnetTargetPosition = targetPosition;
				magnetTargetRotation = Quaternion.Euler(targetRotation);
				CollectItemsInTruck();
			}
		}
	}

	public void SetHonkingLocalClient(bool honk)
	{
		honkingHorn = honk;
		SetHonkServerRpc(honk, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetHonkServerRpc(bool honk, int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(735895017u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref honk, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 735895017u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetHonkClientRpc(honk, playerId);
			}
		}
	}

	[ClientRpc]
	public void SetHonkClientRpc(bool honk, int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2121824285u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref honk, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2121824285u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerId)
			{
				honkingHorn = honk;
			}
		}
	}

	public void CollectItemsInTruck()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)"Collect items in truck A");
		Collider[] array = Physics.OverlapSphere(((Component)this).transform.position, 25f, 64, (QueryTriggerInteraction)1);
		Debug.Log((object)$"Collect items in truck B; {array.Length}");
		for (int i = 0; i < array.Length; i++)
		{
			GrabbableObject component = ((Component)array[i]).GetComponent<GrabbableObject>();
			Debug.Log((object)$"Collect items in truck C; {(Object)(object)component != (Object)null}");
			if ((Object)(object)component != (Object)null)
			{
				Debug.Log((object)$"{!component.isHeld}; {!component.isHeldByEnemy}; {(Object)(object)((Component)array[i]).transform.parent == (Object)(object)((Component)this).transform}");
				Debug.Log((object)$"Magneted? : {magnetedToShip}");
			}
			if ((Object)(object)component != (Object)null && !component.isHeld && !component.isHeldByEnemy && (Object)(object)((Component)array[i]).transform.parent == (Object)(object)((Component)this).transform)
			{
				GameNetworkManager.Instance.localPlayerController.SetItemInElevator(magnetedToShip, magnetedToShip, component);
			}
		}
	}

	public void StartMagneting()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_0270: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_034c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_0367: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0321: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		magnetTime = 0f;
		magnetRotationTime = 0f;
		StartOfRound.Instance.isObjectAttachedToMagnet = true;
		StartOfRound.Instance.attachedVehicle = this;
		magnetedToShip = true;
		averageVelocityAtMagnetStart = averageVelocity;
		((Component)this).gameObject.GetComponent<Rigidbody>().isKinematic = true;
		RoundManager.Instance.tempTransform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
		Debug.DrawRay(((Component)this).transform.position, RoundManager.Instance.tempTransform.forward * 5f, Color.green, 2f);
		Debug.DrawRay(((Component)this).transform.position, -StartOfRound.Instance.magnetPoint.forward * 5f, Color.red, 2f);
		float num = Vector3.Angle(RoundManager.Instance.tempTransform.forward, -StartOfRound.Instance.magnetPoint.forward);
		Debug.Log((object)$"Truck initial angle to magnet: {num}");
		Vector3 eulerAngles = ((Component)this).transform.eulerAngles;
		if (num < 47f || num > 133f)
		{
			if (eulerAngles.y < 0f)
			{
				eulerAngles.y -= 46f - num;
			}
			else
			{
				eulerAngles.y += 46f - num;
			}
		}
		Debug.DrawRay(((Component)this).transform.position, eulerAngles * 4f, Color.white, 2f);
		eulerAngles.y = Mathf.Round(eulerAngles.y / 90f) * 90f;
		eulerAngles.z = Mathf.Round(eulerAngles.z / 90f) * 90f;
		eulerAngles.x += Random.Range(-5f, 5f);
		Debug.DrawRay(((Component)this).transform.position, eulerAngles * 4f, Color.cyan, 2f);
		magnetTargetRotation = Quaternion.Euler(eulerAngles);
		magnetStartRotation = ((Component)this).transform.rotation;
		Quaternion rotation = ((Component)this).transform.rotation;
		((Component)this).transform.rotation = magnetTargetRotation;
		magnetTargetPosition = ((Collider)boundsCollider).ClosestPoint(StartOfRound.Instance.magnetPoint.position) - ((Component)this).transform.position;
		float y = magnetTargetPosition.y;
		Bounds bounds = ((Collider)boundsCollider).bounds;
		if (y >= ((Bounds)(ref bounds)).extents.y)
		{
			ref float y2 = ref magnetTargetPosition.y;
			float num2 = y2;
			bounds = ((Collider)boundsCollider).bounds;
			y2 = num2 - ((Bounds)(ref bounds)).extents.y / 2f;
		}
		else
		{
			float y3 = magnetTargetPosition.y;
			bounds = ((Collider)boundsCollider).bounds;
			if (y3 <= ((Bounds)(ref bounds)).extents.y * 0.4f)
			{
				ref float y4 = ref magnetTargetPosition.y;
				float num3 = y4;
				bounds = ((Collider)boundsCollider).bounds;
				y4 = num3 + ((Bounds)(ref bounds)).extents.y / 2f;
			}
		}
		magnetTargetPosition = StartOfRound.Instance.magnetPoint.position - magnetTargetPosition;
		Debug.DrawLine(((Component)this).transform.position, magnetTargetPosition);
		magnetTargetPosition.z = Mathf.Min(-20.4f, magnetTargetPosition.z);
		magnetTargetPosition.y = Mathf.Max(2.5f, magnetStartPosition.y);
		magnetTargetPosition = StartOfRound.Instance.elevatorTransform.InverseTransformPoint(magnetTargetPosition);
		((Component)this).transform.rotation = rotation;
		magnetStartPosition = ((Component)this).transform.position;
		CollectItemsInTruck();
		MagnetCarServerRpc(magnetTargetPosition, eulerAngles, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
	}

	public void AddTurboBoost()
	{
		int setTurboBoosts = Mathf.Min(turboBoosts + 1, 5);
		AddTurboBoostOnLocalClient(setTurboBoosts);
		AddTurboBoostServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId, setTurboBoosts);
	}

	public void AddTurboBoostOnLocalClient(int setTurboBoosts)
	{
		hoodAudio.PlayOneShot(pourTurbo);
		turboBoosts = setTurboBoosts;
	}

	[ServerRpc(RequireOwnership = false)]
	public void AddTurboBoostServerRpc(int playerId, int setTurboBoosts)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2416458891u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				BytePacker.WriteValueBitPacked(val2, setTurboBoosts);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2416458891u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				AddTurboBoostClientRpc(playerId, setTurboBoosts);
			}
		}
	}

	[ClientRpc]
	public void AddTurboBoostClientRpc(int playerId, int setTurboBoosts)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4268487771u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				BytePacker.WriteValueBitPacked(val2, setTurboBoosts);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4268487771u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerId)
			{
				AddTurboBoostOnLocalClient(setTurboBoosts);
			}
		}
	}

	public void AddEngineOil()
	{
		int num = Mathf.Min(carHP + 4, baseCarHP);
		AddEngineOilOnLocalClient(num);
		AddEngineOilServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId, num);
	}

	public void AddEngineOilOnLocalClient(int setCarHP)
	{
		hoodAudio.PlayOneShot(pourOil);
		carHP = setCarHP;
	}

	[ServerRpc(RequireOwnership = false)]
	public void AddEngineOilServerRpc(int playerId, int setHP)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(548979688u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				BytePacker.WriteValueBitPacked(val2, setHP);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 548979688u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				AddEngineOilClientRpc(playerId, setHP);
			}
		}
	}

	[ClientRpc]
	public void AddEngineOilClientRpc(int playerId, int setHP)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2079068163u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				BytePacker.WriteValueBitPacked(val2, setHP);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2079068163u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerId)
			{
				AddEngineOilOnLocalClient(setHP);
			}
		}
	}

	private void DoTurboBoost(CallbackContext context)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		if (((CallbackContext)(ref context)).performed && localPlayerInControl && !jumpingInCar && !keyIsInDriverHand)
		{
			Vector2 dir = IngamePlayerSettings.Instance.playerInput.actions.FindAction("Move", false).ReadValue<Vector2>();
			UseTurboBoostLocalClient(dir);
			UseTurboBoostServerRpc();
		}
	}

	public void UseTurboBoostLocalClient(Vector2 dir = default(Vector2))
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (turboBoosts == 0 || !ignitionStarted)
			{
				jumpingInCar = true;
				GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetTrigger("SA_JumpInCar");
				((MonoBehaviour)this).StartCoroutine(jerkCarUpward(Vector2.op_Implicit(dir)));
			}
			else
			{
				Vector3 val = ((Component)this).transform.TransformDirection(new Vector3(dir.x, 0f, dir.y));
				mainRigidbody.AddForce(val * turboBoostForce + Vector3.up * turboBoostUpwardForce * 0.6f, (ForceMode)1);
			}
		}
		if (turboBoosts > 0 && ignitionStarted)
		{
			turboBoosts = Mathf.Max(0, turboBoosts - 1);
			turboBoostAudio.PlayOneShot(turboBoostSFX);
			engineAudio1.PlayOneShot(turboBoostSFX2);
			turboBoostParticle.Play(true);
			if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)turboBoostAudio).transform.position) < 10f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
		}
		else
		{
			springAudio.PlayOneShot(jumpInCarSFX);
		}
	}

	private IEnumerator jerkCarUpward(Vector3 dir)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		yield return (object)new WaitForSeconds(0.16f);
		if (!((NetworkBehaviour)this).IsOwner)
		{
			jumpingInCar = false;
			yield break;
		}
		Vector3 val = ((Component)this).transform.TransformDirection(new Vector3(dir.x, 0f, dir.y));
		Debug.DrawRay(((Component)this).transform.position, val * 20f, Color.blue, 5f);
		mainRigidbody.AddForce(val * turboBoostForce * 0.22f + Vector3.up * turboBoostUpwardForce * 0.1f, (ForceMode)1);
		mainRigidbody.AddForceAtPosition(Vector3.up * jumpForce, ((Component)hoodFireAudio).transform.position - Vector3.up * 2f, (ForceMode)1);
		yield return (object)new WaitForSeconds(0.15f);
		jumpingInCar = false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void UseTurboBoostServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1878146525u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1878146525u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				UseTurboBoostClientRpc();
			}
		}
	}

	[ClientRpc]
	public void UseTurboBoostClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4076738570u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4076738570u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				UseTurboBoostLocalClient();
			}
		}
	}

	public void OnDisable()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		DisableControl();
		if (localPlayerInControl || localPlayerInPassengerSeat)
		{
			GameNetworkManager.Instance.localPlayerController.CancelSpecialTriggerAnimations();
		}
		GrabbableObject[] componentsInChildren = ((Component)physicsRegion.physicsTransform).GetComponentsInChildren<GrabbableObject>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if ((Object)(object)RoundManager.Instance.mapPropsContainer != (Object)null)
			{
				((Component)componentsInChildren[i]).transform.SetParent(RoundManager.Instance.mapPropsContainer.transform, true);
			}
			else
			{
				((Component)componentsInChildren[i]).transform.SetParent((Transform)null, true);
			}
			if (!componentsInChildren[i].isHeld)
			{
				componentsInChildren[i].FallToGround();
			}
		}
		physicsRegion.disablePhysicsRegion = true;
		if (StartOfRound.Instance.CurrentPlayerPhysicsRegions.Contains(physicsRegion))
		{
			StartOfRound.Instance.CurrentPlayerPhysicsRegions.Remove(physicsRegion);
		}
	}

	private void Update()
	{
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_036c: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0445: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_053b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0551: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_0573: Unknown result type (might be due to invalid IL or missing references)
		//IL_0578: Unknown result type (might be due to invalid IL or missing references)
		//IL_057c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0581: Unknown result type (might be due to invalid IL or missing references)
		//IL_0583: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_0596: Unknown result type (might be due to invalid IL or missing references)
		//IL_059b: Unknown result type (might be due to invalid IL or missing references)
		//IL_059d: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0704: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_09fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a11: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b13: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b22: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3c: Unknown result type (might be due to invalid IL or missing references)
		if (destroyNextFrame)
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				Debug.Log((object)$"Is networkobject spawned: {((NetworkBehaviour)this).NetworkObject.IsSpawned}");
				Debug.Log((object)"Destroying car on local client");
				Object.Destroy((Object)(object)((Component)windwiperPhysicsBody1).gameObject);
				Object.Destroy((Object)(object)((Component)windwiperPhysicsBody2).gameObject);
				Object.Destroy((Object)(object)((Component)ragdollPhysicsBody).gameObject);
				Object.Destroy((Object)(object)((Component)this).gameObject);
			}
			return;
		}
		if ((Object)(object)((NetworkBehaviour)this).NetworkObject != (Object)null && !((NetworkBehaviour)this).NetworkObject.IsSpawned)
		{
			physicsRegion.disablePhysicsRegion = true;
			if (StartOfRound.Instance.CurrentPlayerPhysicsRegions.Contains(physicsRegion))
			{
				StartOfRound.Instance.CurrentPlayerPhysicsRegions.Remove(physicsRegion);
			}
			if (localPlayerInControl || localPlayerInPassengerSeat)
			{
				GameNetworkManager.Instance.localPlayerController.CancelSpecialTriggerAnimations();
			}
			GrabbableObject[] componentsInChildren = ((Component)physicsRegion.physicsTransform).GetComponentsInChildren<GrabbableObject>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				if ((Object)(object)RoundManager.Instance.mapPropsContainer != (Object)null)
				{
					((Component)componentsInChildren[i]).transform.SetParent(RoundManager.Instance.mapPropsContainer.transform, true);
				}
				else
				{
					((Component)componentsInChildren[i]).transform.SetParent((Transform)null, true);
				}
				if (!componentsInChildren[i].isHeld)
				{
					componentsInChildren[i].FallToGround();
				}
			}
			Debug.Log((object)"Destroying car on local client, next frame");
			destroyNextFrame = true;
			return;
		}
		ReactToDamage();
		driverSideDoorTrigger.interactable = Time.realtimeSinceStartup - timeSinceSpringingDriverSeat > 1.6f;
		passengerSideDoorTrigger.interactable = Time.realtimeSinceStartup - timeSinceSpringingDriverSeat > 1.6f;
		if (magnetedToShip)
		{
			if (!StartOfRound.Instance.magnetOn)
			{
				magnetedToShip = false;
				StartOfRound.Instance.isObjectAttachedToMagnet = false;
				CollectItemsInTruck();
				return;
			}
			pressedTurbo = false;
			limitTruckVelocityTimer = 1.3f;
			EngineRPM = Mathf.Lerp(EngineRPM, 0f, 3f * Time.deltaTime);
			physicsRegion.priority = 0;
			magnetTime = Mathf.Min(magnetTime + Time.deltaTime, 1f);
			magnetRotationTime = Mathf.Min(magnetTime + Time.deltaTime * 0.75f, 1f);
			if (StartOfRound.Instance.inShipPhase)
			{
				carHP = baseCarHP;
			}
			if (!finishedMagneting && magnetTime > 0.7f)
			{
				finishedMagneting = true;
				if (!loadedVehicleFromSave)
				{
					turbulenceAmount = 2f;
					turbulenceAudio.volume = 0.6f;
					turbulenceAudio.PlayOneShot(maxCollisions[Random.Range(0, maxCollisions.Length)]);
				}
			}
		}
		else
		{
			physicsRegion.priority = 1;
			finishedMagneting = false;
			if ((Object)(object)StartOfRound.Instance.attachedVehicle == (Object)(object)this)
			{
				StartOfRound.Instance.attachedVehicle = null;
			}
			if (((NetworkBehaviour)this).IsOwner && !StartOfRound.Instance.isObjectAttachedToMagnet && StartOfRound.Instance.magnetOn && Vector3.Distance(((Component)this).transform.position, StartOfRound.Instance.magnetPoint.position) < 10f && !Physics.Linecast(((Component)this).transform.position, StartOfRound.Instance.magnetPoint.position, 256, (QueryTriggerInteraction)1))
			{
				StartMagneting();
				return;
			}
			if (((NetworkBehaviour)this).IsOwner)
			{
				if (enabledCollisionForAllPlayers)
				{
					enabledCollisionForAllPlayers = false;
					DisableVehicleCollisionForAllPlayers();
				}
				SyncCarPhysicsToOtherClients();
			}
			else
			{
				if (!enabledCollisionForAllPlayers)
				{
					enabledCollisionForAllPlayers = true;
					EnableVehicleCollisionForAllPlayers();
				}
				((Component)this).gameObject.GetComponent<Rigidbody>().isKinematic = true;
			}
		}
		if (honkingHorn)
		{
			if (!hornAudio.isPlaying)
			{
				hornAudio.Play();
				hornAudio.pitch = 1f;
			}
			else if (Time.realtimeSinceStartup - timeAtLastHornPing > 2f)
			{
				timeAtLastHornPing = Time.realtimeSinceStartup;
				RoundManager.Instance.PlayAudibleNoise(((Component)hornAudio).transform.position, 28f, 0.85f, 0, noiseIsInsideClosedShip: false, 106217);
			}
		}
		else
		{
			hornAudio.pitch = Mathf.Max(hornAudio.pitch - Time.deltaTime * 6f, 0.01f);
			if (hornAudio.pitch < 0.02f)
			{
				hornAudio.Stop();
			}
		}
		FrontLeftWheel.steerAngle = 15f * steeringInput;
		FrontRightWheel.steerAngle = 15f * steeringInput;
		if (carDestroyed)
		{
			return;
		}
		if (keyIsInDriverHand && (Object)(object)currentDriver != (Object)null)
		{
			((Renderer)keyObject).enabled = true;
			Transform val = ((!localPlayerInControl) ? currentDriver.serverItemHolder : currentDriver.localItemHolder);
			((Component)keyObject).transform.rotation = val.rotation;
			((Component)keyObject).transform.Rotate(rotationOffset);
			((Component)keyObject).transform.position = val.position;
			Vector3 val2 = positionOffset;
			val2 = val.rotation * val2;
			Transform transform = ((Component)keyObject).transform;
			transform.position += val2;
		}
		else
		{
			if (Time.realtimeSinceStartup - timeAtLastGearShift < 1.7f && (Object)(object)currentDriver != (Object)null)
			{
				currentDriver.playerBodyAnimator.SetFloat("SA_CarMotionTime", gearStickAnimValue);
			}
			if (localPlayerInControl && ignitionStarted && keyIgnitionCoroutine == null)
			{
				if (GameNetworkManager.Instance.localPlayerController.ladderCameraHorizontal > 52f)
				{
					if (Time.realtimeSinceStartup - timeAtLastGearShift < 1.7f)
					{
						GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 5);
					}
					else
					{
						GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 4);
					}
				}
				else
				{
					GameNetworkManager.Instance.localPlayerController.playerBodyAnimator.SetInteger("SA_CarAnim", 1);
				}
			}
			if (keyIsInIgnition)
			{
				((Renderer)keyObject).enabled = true;
				if (ignitionStarted)
				{
					((Component)keyObject).transform.position = ignitionTurnedPosition.position;
					((Component)keyObject).transform.rotation = ignitionTurnedPosition.rotation;
				}
				else
				{
					((Component)keyObject).transform.position = ignitionNotTurnedPosition.position;
					((Component)keyObject).transform.rotation = ignitionNotTurnedPosition.rotation;
				}
			}
			else
			{
				((Renderer)keyObject).enabled = false;
			}
		}
		if (!localPlayerInControl || !((NetworkBehaviour)this).IsOwner)
		{
			SetCarEffects(steeringAnimValue);
			return;
		}
		if (ignitionStarted)
		{
			GetVehicleInput();
		}
		if (limitTruckVelocityTimer <= 0f)
		{
			mainRigidbody.maxAngularVelocity = 4f;
			mainRigidbody.maxLinearVelocity = 50f;
			mainRigidbody.maxDepenetrationVelocity = 7f;
		}
		else
		{
			limitTruckVelocityTimer -= Time.deltaTime * 0.5f;
			mainRigidbody.maxDepenetrationVelocity = Mathf.Lerp(0.3f, 7f, Mathf.Clamp(limitTruckVelocityTimer, 0f, 1f));
			mainRigidbody.maxAngularVelocity = Mathf.Lerp(0.1f, 4f, Mathf.Clamp(limitTruckVelocityTimer, 0f, 1f));
			mainRigidbody.maxLinearVelocity = Mathf.Lerp(0.1f, 60f, Mathf.Clamp(limitTruckVelocityTimer, 0f, 1f));
		}
		SetCarEffects(steeringAnimValue);
		float num = 0f;
		EngineRPM = (FrontLeftWheel.rpm + FrontRightWheel.rpm) / 2f;
		vehicleEngineAudio.pitch = Mathf.Min(Mathf.Abs(EngineRPM / MaxEngineRPM) + 1f, 1.3f);
		if (brakePedalPressed)
		{
			if (drivePedalPressed)
			{
				num += 2f;
				lastStressType += "; Accelerating while braking";
			}
			FrontLeftWheel.brakeTorque = 2000f;
			FrontRightWheel.brakeTorque = 2000f;
			BackLeftWheel.brakeTorque = 2000f;
			BackRightWheel.brakeTorque = 2000f;
			for (int j = 0; j < otherWheels.Length; j++)
			{
				otherWheels[j].brakeTorque = 2000f;
			}
		}
		else
		{
			FrontLeftWheel.brakeTorque = 0f;
			FrontRightWheel.brakeTorque = 0f;
			BackLeftWheel.brakeTorque = 0f;
			BackRightWheel.brakeTorque = 0f;
			for (int k = 0; k < otherWheels.Length; k++)
			{
				otherWheels[k].brakeTorque = 0f;
			}
		}
		if (drivePedalPressed && ignitionStarted)
		{
			switch (gear)
			{
			case CarGearShift.Drive:
			{
				if (switchGearsBoostEnabled)
				{
					mainRigidbody.AddForce(0.35f * turboBoostForce * ((Component)this).transform.TransformDirection(new Vector3(0f, 0f, 1f)) + 0.06f * turboBoostUpwardForce * Vector3.up, (ForceMode)1);
					switchGearsBoostEnabled = false;
				}
				FrontLeftWheel.motorTorque = Mathf.Clamp(Mathf.MoveTowards(FrontLeftWheel.motorTorque, EngineTorque, carAcceleration * Time.deltaTime), 325f, 1000f);
				FrontRightWheel.motorTorque = FrontLeftWheel.motorTorque;
				BackLeftWheel.motorTorque = FrontLeftWheel.motorTorque;
				BackRightWheel.motorTorque = FrontLeftWheel.motorTorque;
				for (int m = 0; m < otherWheels.Length; m++)
				{
					otherWheels[m].motorTorque = FrontLeftWheel.motorTorque;
				}
				break;
			}
			case CarGearShift.Reverse:
			{
				if (switchGearsBoostEnabled)
				{
					mainRigidbody.AddForce(((Component)this).transform.TransformDirection(new Vector3(0f, 0f, -1f)) * turboBoostForce * 0.3f + Vector3.up * turboBoostUpwardForce * 0.06f, (ForceMode)1);
					switchGearsBoostEnabled = false;
				}
				if (EngineRPM > 5000f)
				{
					num += Mathf.Min((EngineRPM - 5000f) / 10000f, 0f);
					lastStressType += "; Reversing while at high speed";
				}
				FrontLeftWheel.motorTorque = 0f - EngineTorque;
				FrontRightWheel.motorTorque = 0f - EngineTorque;
				BackLeftWheel.motorTorque = 0f - EngineTorque;
				BackRightWheel.motorTorque = 0f - EngineTorque;
				for (int l = 0; l < otherWheels.Length; l++)
				{
					otherWheels[l].motorTorque = 0f - EngineTorque;
				}
				break;
			}
			}
		}
		else if (pressedTurbo)
		{
			pressedTurbo = false;
		}
		if (gear == CarGearShift.Park || !ignitionStarted)
		{
			if (Mathf.Abs(EngineRPM) > 3000f && ignitionStarted)
			{
				num += Mathf.Clamp((EngineRPM - 200f) / 350f, 0f, 1.3f);
				lastStressType += "; In park while at high speed";
			}
			if (drivePedalPressed && ignitionStarted)
			{
				num += 1.2f;
				lastStressType += "; Accelerating while in park";
			}
			FrontLeftWheel.motorTorque = 0f;
			FrontRightWheel.motorTorque = 0f;
			BackLeftWheel.motorTorque = 0f;
			BackRightWheel.motorTorque = 0f;
			FrontLeftWheel.brakeTorque = 2000f;
			FrontRightWheel.brakeTorque = 2000f;
			BackLeftWheel.brakeTorque = 2000f;
			BackRightWheel.brakeTorque = 2000f;
			for (int n = 0; n < otherWheels.Length; n++)
			{
				otherWheels[n].brakeTorque = 2000f;
				otherWheels[n].motorTorque = 0f;
			}
		}
		else if (!drivePedalPressed)
		{
			float num2 = 1f;
			if (gear == CarGearShift.Reverse)
			{
				num2 = -1f;
			}
			FrontLeftWheel.motorTorque = idleSpeed * num2;
			FrontRightWheel.motorTorque = idleSpeed * num2;
			BackLeftWheel.motorTorque = idleSpeed * num2;
			BackRightWheel.motorTorque = idleSpeed * num2;
			for (int num3 = 0; num3 < otherWheels.Length; num3++)
			{
				otherWheels[num3].motorTorque = idleSpeed * num2;
			}
		}
		SetInternalStress(num);
		stressPerSecond = num;
	}

	public void ChangeRadioStation()
	{
		if (!radioOn)
		{
			SetRadioOnLocalClient(on: true, setClip: false);
		}
		currentRadioClip = (currentRadioClip + 1) % radioClips.Length;
		radioAudio.clip = radioClips[currentRadioClip];
		radioAudio.time = Mathf.Clamp(currentSongTime % radioAudio.clip.length, 0.01f, radioAudio.clip.length - 0.1f);
		radioAudio.Play();
		int num = (int)Mathf.Round(radioSignalQuality);
		switch (num)
		{
		case 3:
			radioSignalQuality = 1f;
			radioSignalDecreaseThreshold = 10f;
			break;
		case 0:
			radioSignalQuality = 3f;
			radioSignalDecreaseThreshold = 90f;
			break;
		case 1:
			radioSignalQuality = 2f;
			radioSignalDecreaseThreshold = 70f;
			break;
		case 2:
			radioSignalQuality = 1f;
			radioSignalDecreaseThreshold = 30f;
			break;
		}
		SetRadioStationServerRpc(currentRadioClip, num);
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetRadioStationServerRpc(int radioStation, int signalQuality)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(721150963u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, radioStation);
				BytePacker.WriteValueBitPacked(val2, signalQuality);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 721150963u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetRadioStationClientRpc(radioStation, signalQuality);
			}
		}
	}

	[ClientRpc]
	public void SetRadioStationClientRpc(int radioStation, int signalQuality)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3091363772u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, radioStation);
			BytePacker.WriteValueBitPacked(val2, signalQuality);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3091363772u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && currentRadioClip != radioStation)
		{
			if (!radioOn)
			{
				SetRadioOnLocalClient(on: true, setClip: false);
			}
			currentRadioClip = radioStation;
			radioSignalQuality = signalQuality;
			radioAudio.Play();
		}
	}

	public void SwitchRadio()
	{
		radioOn = !radioOn;
		if (radioOn)
		{
			radioAudio.clip = radioClips[currentRadioClip];
			radioAudio.Play();
			radioInterference.Play();
		}
		else
		{
			radioAudio.Stop();
			radioInterference.Stop();
		}
		SetRadioOnServerRpc(radioOn);
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetRadioOnServerRpc(bool on)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2416589835u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref on, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2416589835u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetRadioOnClientRpc(on);
			}
		}
	}

	[ClientRpc]
	public void SetRadioOnClientRpc(bool on)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2165949877u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref on, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2165949877u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && radioOn != on)
			{
				SetRadioOnLocalClient(on);
			}
		}
	}

	private void SetRadioOnLocalClient(bool on, bool setClip = true)
	{
		radioOn = on;
		if (on)
		{
			if (setClip)
			{
				radioAudio.clip = radioClips[currentRadioClip];
			}
			radioAudio.Play();
			radioInterference.Play();
		}
		else
		{
			radioAudio.Stop();
			radioInterference.Stop();
		}
	}

	public void SetRadioValues()
	{
		if (radioTurnedOnBefore)
		{
			currentSongTime += Time.deltaTime;
		}
		if (!radioOn)
		{
			return;
		}
		if (!radioAudio.isPlaying)
		{
			radioAudio.Play();
		}
		radioTurnedOnBefore = true;
		if (((NetworkBehaviour)this).IsOwner)
		{
			float num = Random.Range(0, 100);
			float num2 = (3f - radioSignalQuality - 1.5f) * radioSignalTurbulence;
			radioSignalDecreaseThreshold = Mathf.Clamp(radioSignalDecreaseThreshold + Time.deltaTime * num2, 0f, 100f);
			if (num > radioSignalDecreaseThreshold)
			{
				radioSignalQuality = Mathf.Clamp(radioSignalQuality - Time.deltaTime, 0f, 3f);
			}
			else
			{
				radioSignalQuality = Mathf.Clamp(radioSignalQuality + Time.deltaTime, 0f, 3f);
			}
			if (Time.realtimeSinceStartup - changeRadioSignalTime > 0.3f)
			{
				changeRadioSignalTime = Time.realtimeSinceStartup;
				if (radioSignalQuality < 1.2f && Random.Range(0, 100) < 6)
				{
					radioSignalQuality = Mathf.Min(radioSignalQuality + 1.5f, 3f);
					radioSignalDecreaseThreshold = Mathf.Min(radioSignalDecreaseThreshold + 30f, 100f);
				}
				SetRadioSignalQualityServerRpc((int)Mathf.Round(radioSignalQuality));
			}
		}
		switch ((int)Mathf.Round(radioSignalQuality))
		{
		case 3:
			radioAudio.volume = Mathf.Lerp(radioAudio.volume, 1f, 2f * Time.deltaTime);
			radioInterference.volume = Mathf.Lerp(radioInterference.volume, 0f, 2f * Time.deltaTime);
			break;
		case 2:
			radioAudio.volume = Mathf.Lerp(radioAudio.volume, 0.85f, 2f * Time.deltaTime);
			radioInterference.volume = Mathf.Lerp(radioInterference.volume, 0.4f, 2f * Time.deltaTime);
			break;
		case 1:
			radioAudio.volume = Mathf.Lerp(radioAudio.volume, 0.6f, 2f * Time.deltaTime);
			radioInterference.volume = Mathf.Lerp(radioInterference.volume, 0.8f, 2f * Time.deltaTime);
			break;
		case 0:
			radioAudio.volume = Mathf.Lerp(radioAudio.volume, 0.4f, 2f * Time.deltaTime);
			radioInterference.volume = Mathf.Lerp(radioInterference.volume, 1f, 2f * Time.deltaTime);
			break;
		}
	}

	[ServerRpc]
	public void SetRadioSignalQualityServerRpc(int signalQuality)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2043456042u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, signalQuality);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2043456042u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetRadioSignalQualityClientRpc(signalQuality);
		}
	}

	[ClientRpc]
	public void SetRadioSignalQualityClientRpc(int signalQuality)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(894646603u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, signalQuality);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 894646603u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				radioSignalQuality = signalQuality;
			}
		}
	}

	private void MatchWheelMeshToCollider(MeshRenderer wheelMesh, WheelCollider wheelCollider)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = ((Component)wheelCollider).transform.position;
		if (Physics.Raycast(position, -((Component)wheelCollider).transform.up, ref hit, wheelCollider.suspensionDistance + wheelCollider.radius, 2304))
		{
			((Component)wheelMesh).transform.position = ((RaycastHit)(ref hit)).point + ((Component)wheelCollider).transform.up * wheelCollider.radius;
		}
		else
		{
			((Component)wheelMesh).transform.position = position - ((Component)wheelCollider).transform.up * wheelCollider.suspensionDistance;
		}
		((Component)wheelMesh).transform.Rotate(Vector3.right, EngineRPM * 0.5f, (Space)1);
	}

	[ServerRpc]
	public void SyncExtremeStressServerRpc(bool underStress)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3603115648u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref underStress, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3603115648u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncExtremeStressClientRpc(underStress);
		}
	}

	[ClientRpc]
	public void SyncExtremeStressClientRpc(bool underStress)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3722438677u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref underStress, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3722438677u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (carDestroyed)
			{
				underExtremeStress = false;
			}
			else
			{
				underExtremeStress = underStress;
			}
		}
	}

	private void SetCarEffects(float setSteering)
	{
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0622: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f5: Unknown result type (might be due to invalid IL or missing references)
		steeringWheelAnimFloat = Mathf.Clamp(steeringWheelAnimFloat + setSteering * steeringWheelTurnSpeed * Time.deltaTime / 6f, -0.99f, 0.99f);
		float num = Mathf.Clamp((steeringWheelAnimFloat + 1f) / 2f, 0.01f, 0.99f) - steeringWheelAnimator.GetFloat("steeringWheelTurnSpeed");
		steeringWheelAnimator.SetFloat("steeringWheelTurnSpeed", Mathf.Clamp((steeringWheelAnimFloat + 1f) / 2f, 0.01f, 0.99f));
		if ((Object)(object)currentDriver != (Object)null)
		{
			currentDriver.playerBodyAnimator.SetFloat("animationSpeed", currentDriver.playerBodyAnimator.GetFloat("animationSpeed") + num * 2f);
		}
		((Component)leftWheelMesh).transform.localEulerAngles = new Vector3(((Component)leftWheelMesh).transform.localEulerAngles.x, steeringWheelAnimFloat * 50f, 0f);
		MatchWheelMeshToCollider(leftWheelMesh, FrontLeftWheel);
		((Component)rightWheelMesh).transform.localEulerAngles = new Vector3(((Component)rightWheelMesh).transform.localEulerAngles.x, steeringWheelAnimFloat * 50f, 0f);
		MatchWheelMeshToCollider(rightWheelMesh, FrontRightWheel);
		MatchWheelMeshToCollider(backLeftWheelMesh, BackLeftWheel);
		MatchWheelMeshToCollider(backRightWheelMesh, BackRightWheel);
		if (gear == CarGearShift.Reverse)
		{
			gearStickAnimValue = Mathf.MoveTowards(gearStickAnimValue, 0.5f, 15f * Time.deltaTime * (Time.realtimeSinceStartup - timeAtLastGearShift));
		}
		else if (gear == CarGearShift.Park)
		{
			gearStickAnimValue = Mathf.MoveTowards(gearStickAnimValue, 1f, 15f * Time.deltaTime * (Time.realtimeSinceStartup - timeAtLastGearShift));
		}
		else
		{
			gearStickAnimValue = Mathf.MoveTowards(gearStickAnimValue, 0f, 15f * Time.deltaTime * (Time.realtimeSinceStartup - timeAtLastGearShift));
		}
		gearStickAnimator.SetFloat("gear", Mathf.Clamp(gearStickAnimValue, 0.01f, 0.99f));
		if (EngineRPM < -5f)
		{
			if (!backLightsOn)
			{
				backLightsOn = true;
				((Renderer)backLightsMesh).material = backLightOnMat;
				backLightsContainer.SetActive(true);
			}
		}
		else if (backLightsOn)
		{
			backLightsOn = false;
			((Renderer)backLightsMesh).material = headlightsOffMat;
			backLightsContainer.SetActive(false);
		}
		SetVehicleAudioProperties(extremeStressAudio, underExtremeStress, 0.2f, 1f, 3f, useVolumeInsteadOfPitch: true);
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (!syncedExtremeStress && underExtremeStress && extremeStressAudio.volume > 0.35f)
			{
				syncedExtremeStress = true;
				SyncExtremeStressServerRpc(underExtremeStress);
			}
			else if (syncedExtremeStress && !underExtremeStress && extremeStressAudio.volume < 0.5f)
			{
				syncedExtremeStress = false;
				SyncExtremeStressServerRpc(underExtremeStress);
			}
		}
		SetRadioValues();
		float num2 = Vector3.Dot(Vector3.Normalize(mainRigidbody.velocity * 1000f), ((Component)this).transform.forward);
		bool audioActive = num2 > -0.6f && num2 < 0.4f && (((Vector3)(ref averageVelocity)).magnitude > 4f || EngineRPM > 400f);
		if ((!FrontLeftWheel.isGrounded && !FrontRightWheel.isGrounded) || (!BackLeftWheel.isGrounded && !BackRightWheel.isGrounded))
		{
			audioActive = false;
		}
		if (FrontLeftWheel.motorTorque > 900f && FrontRightWheel.motorTorque > 900f)
		{
			audioActive = true;
			num2 = Mathf.Max(num2, 0.8f);
			if (((Vector3)(ref averageVelocity)).magnitude > 8f && !tireSparks.isPlaying)
			{
				tireSparks.Play(true);
			}
		}
		else
		{
			tireSparks.Stop(true, (ParticleSystemStopBehavior)1);
		}
		SetVehicleAudioProperties(skiddingAudio, audioActive, 0f, num2, 3f, useVolumeInsteadOfPitch: true);
		carEngine2AudioActive = ignitionStarted;
		float num3 = Mathf.Abs(EngineRPM);
		float highest = Mathf.Clamp(num3 / engineIntensityPercentage, 0.7f, 1.5f);
		SetVehicleAudioProperties(engineAudio2, carEngine2AudioActive, 0.7f, highest, 3f, useVolumeInsteadOfPitch: false, 0.5f);
		highest = Mathf.Clamp(num3 / engineIntensityPercentage, 0.65f, 1.15f);
		float highest2 = highest;
		if (!ignitionStarted)
		{
			highest2 = 1f;
		}
		SetVehicleAudioProperties(engineAudio1, carEngine1AudioActive, 0.7f, highest2, 2f, useVolumeInsteadOfPitch: false, 0.7f);
		if (engineAudio1.volume > 0.3f && engineAudio1.isPlaying && Time.realtimeSinceStartup - timeAtLastEngineAudioPing > 2f)
		{
			timeAtLastEngineAudioPing = Time.realtimeSinceStartup;
			if (EngineRPM > 130f)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)engineAudio1).transform.position, 32f, 0.75f, 0, noiseIsInsideClosedShip: false, 2692);
			}
			if (EngineRPM > 60f)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)engineAudio1).transform.position, 25f, 0.6f, 0, noiseIsInsideClosedShip: false, 2692);
			}
			else if (!ignitionStarted)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)engineAudio1).transform.position, 15f, 0.6f, 0, noiseIsInsideClosedShip: false, 2692);
			}
			else
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)engineAudio1).transform.position, 11f, 0.5f, 0, noiseIsInsideClosedShip: false, 2692);
			}
		}
		carRollingAudioActive = num3 > 10f;
		highest = Mathf.Clamp(num3 / (engineIntensityPercentage * 0.35f), 0f, 1f);
		SetVehicleAudioProperties(rollingAudio, carRollingAudioActive, 0f, highest, 5f, useVolumeInsteadOfPitch: true);
		turbulenceAudio.volume = Mathf.Lerp(turbulenceAudio.volume, Mathf.Min(1f, turbulenceAmount), 10f * Time.deltaTime);
		turbulenceAmount = Mathf.Max(turbulenceAmount - Time.deltaTime, 0f);
		if (turbulenceAudio.volume > 0.02f)
		{
			if (!turbulenceAudio.isPlaying)
			{
				turbulenceAudio.Play();
			}
		}
		else if (turbulenceAudio.isPlaying)
		{
			turbulenceAudio.Stop();
		}
	}

	private void SetVehicleAudioProperties(AudioSource audio, bool audioActive, float lowest, float highest, float lerpSpeed, bool useVolumeInsteadOfPitch = false, float onVolume = 1f)
	{
		if (audioActive)
		{
			if (!audio.isPlaying)
			{
				audio.Play();
			}
			if (useVolumeInsteadOfPitch)
			{
				audio.volume = Mathf.Max(Mathf.Lerp(audio.volume, highest, lerpSpeed * Time.deltaTime), lowest);
				return;
			}
			audio.volume = Mathf.Lerp(audio.volume, onVolume, 20f * Time.deltaTime);
			audio.pitch = Mathf.Lerp(audio.pitch, highest, lerpSpeed * Time.deltaTime);
		}
		else
		{
			if (useVolumeInsteadOfPitch)
			{
				audio.volume = Mathf.Lerp(audio.volume, 0f, lerpSpeed * Time.deltaTime);
			}
			else
			{
				audio.volume = Mathf.Lerp(audio.volume, 0f, 4f * Time.deltaTime);
				audio.pitch = Mathf.Lerp(audio.pitch, lowest, 4f * Time.deltaTime);
			}
			if (audio.isPlaying && audio.volume == 0f)
			{
				audio.Stop();
			}
		}
	}

	private void FixedUpdate()
	{
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_0392: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0422: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_0409: Unknown result type (might be due to invalid IL or missing references)
		//IL_0458: Unknown result type (might be due to invalid IL or missing references)
		//IL_045e: Unknown result type (might be due to invalid IL or missing references)
		//IL_043c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0448: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0315: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_033f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		if (!StartOfRound.Instance.inShipPhase)
		{
			if ((Object)(object)itemShip == (Object)null)
			{
				itemShip = Object.FindObjectOfType<ItemDropship>();
			}
			if ((Object)(object)itemShip != (Object)null && !hasBeenSpawned)
			{
				if (itemShip.untetheredVehicle)
				{
					mainRigidbody.MovePosition(itemShip.deliverVehiclePoint.position);
					mainRigidbody.MoveRotation(itemShip.deliverVehiclePoint.rotation);
					hasBeenSpawned = true;
				}
				else if (itemShip.deliveringVehicle)
				{
					mainRigidbody.isKinematic = true;
					mainRigidbody.MovePosition(itemShip.deliverVehiclePoint.position);
					mainRigidbody.MoveRotation(itemShip.deliverVehiclePoint.rotation);
					if (((NetworkBehaviour)this).IsOwner)
					{
						syncedPosition = ((Component)this).transform.position;
						syncedRotation = ((Component)this).transform.rotation;
					}
				}
				else
				{
					mainRigidbody.isKinematic = true;
					mainRigidbody.MovePosition(StartOfRound.Instance.notSpawnedPosition.position + Vector3.forward * 30f);
				}
			}
		}
		Vector3 angularVelocity = mainRigidbody.angularVelocity;
		Vector3 val = Vector3.Cross(Quaternion.AngleAxis(((Vector3)(ref angularVelocity)).magnitude * 57.29578f * stability / speed, mainRigidbody.angularVelocity) * ((Component)this).transform.up, Vector3.up);
		mainRigidbody.AddTorque(val * speed * speed);
		if (magnetedToShip)
		{
			mainRigidbody.MovePosition(Vector3.Lerp(magnetStartPosition, StartOfRound.Instance.elevatorTransform.position + magnetTargetPosition, magnetPositionCurve.Evaluate(magnetTime)));
			mainRigidbody.MoveRotation(Quaternion.Lerp(magnetStartRotation, magnetTargetRotation, magnetRotationCurve.Evaluate(magnetRotationTime)));
			averageVelocityAtMagnetStart = Vector3.Lerp(averageVelocityAtMagnetStart, Vector3.ClampMagnitude(averageVelocityAtMagnetStart, 4f), 4f * Time.deltaTime);
			if (!finishedMagneting)
			{
				magnetStartPosition += Vector3.ClampMagnitude(averageVelocityAtMagnetStart, 5f) * Time.fixedDeltaTime;
			}
		}
		if (!((NetworkBehaviour)this).IsOwner && !testingVehicleInEditor && !magnetedToShip)
		{
			((Component)this).gameObject.GetComponent<Rigidbody>().isKinematic = true;
			Mathf.Clamp(syncSpeedMultiplier * Vector3.Distance(((Component)this).transform.position, syncedPosition), 1.3f, 300f);
			Vector3 val2 = Vector3.Lerp(((Component)this).transform.position, syncedPosition, Time.fixedDeltaTime * syncSpeedMultiplier);
			mainRigidbody.MovePosition(val2);
			mainRigidbody.MoveRotation(Quaternion.Lerp(((Component)this).transform.rotation, syncedRotation, syncRotationSpeed));
			truckVelocityLastFrame = mainRigidbody.velocity;
		}
		ragdollPhysicsBody.Move(((Component)this).transform.position, ((Component)this).transform.rotation);
		windwiperPhysicsBody1.Move(windwiper1.position, windwiper1.rotation);
		windwiperPhysicsBody2.Move(windwiper2.position, windwiper2.rotation);
		averageCount++;
		if (averageCount > movingAverageLength)
		{
			averageVelocity += (mainRigidbody.velocity - averageVelocity) / (float)(movingAverageLength + 1);
		}
		else
		{
			averageVelocity += mainRigidbody.velocity;
			if (averageCount == movingAverageLength)
			{
				averageVelocity /= (float)averageCount;
			}
		}
		Debug.DrawRay(((Component)this).transform.position, averageVelocity);
	}

	private void SyncCarPhysicsToOtherClients()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).gameObject.GetComponent<Rigidbody>().isKinematic = false;
		if (syncCarPositionInterval > 0.12f)
		{
			if (Vector3.Distance(syncedPosition, ((Component)this).transform.position) > 0.06f)
			{
				syncCarPositionInterval = 0f;
				syncedPosition = ((Component)this).transform.position;
				syncedRotation = ((Component)this).transform.rotation;
				SyncCarPositionServerRpc(((Component)this).transform.position, ((Component)this).transform.eulerAngles, moveInputVector.x, EngineRPM);
			}
			else if (Vector3.Angle(((Component)this).transform.forward, syncedRotation * Vector3.forward) > 2f)
			{
				syncCarPositionInterval = 0f;
				syncedPosition = ((Component)this).transform.position;
				syncedRotation = ((Component)this).transform.rotation;
				SyncCarPositionServerRpc(((Component)this).transform.position, ((Component)this).transform.eulerAngles, moveInputVector.x, EngineRPM);
			}
		}
		else
		{
			syncCarPositionInterval += Time.deltaTime;
		}
	}

	public bool CarReactToObstacle(Vector3 vel, Vector3 position, Vector3 impulse, CarObstacleType type, float obstacleSize = 1f, EnemyAI enemyScript = null, bool dealDamage = true)
	{
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_034d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		switch (type)
		{
		case CarObstacleType.Object:
			if (carHP < 10)
			{
				mainRigidbody.AddForceAtPosition(Vector3.up * torqueForce + vel, position, (ForceMode)1);
			}
			else
			{
				mainRigidbody.AddForceAtPosition((Vector3.up * torqueForce + vel) * 0.5f, position, (ForceMode)1);
			}
			CarBumpServerRpc(averageVelocity * 0.7f);
			if (dealDamage)
			{
				DealPermanentDamage(1, position);
			}
			return true;
		case CarObstacleType.Player:
			PlayCollisionAudio(position, 5, Mathf.Clamp(((Vector3)(ref vel)).magnitude / 7f, 0.65f, 1f));
			if (((Vector3)(ref vel)).magnitude < 4.25f)
			{
				mainRigidbody.velocity = Vector3.Normalize(-impulse * 100000000f) * 9f;
				DealPermanentDamage(1);
				return true;
			}
			mainRigidbody.AddForceAtPosition(Vector3.up * torqueForce, position, (ForceMode)2);
			return false;
		case CarObstacleType.Enemy:
		{
			if (obstacleSize <= 1f)
			{
				return false;
			}
			float num;
			if (obstacleSize <= 2f)
			{
				num = 9f;
				_ = carReactToPlayerHitMultiplier;
			}
			else
			{
				num = 15f;
				_ = carReactToPlayerHitMultiplier;
			}
			vel = Vector3.Scale(vel, new Vector3(1f, 0f, 1f));
			mainRigidbody.AddForceAtPosition(Vector3.up * torqueForce, position, (ForceMode)2);
			bool result = false;
			if (((Vector3)(ref vel)).magnitude < num)
			{
				Debug.DrawRay(((Component)this).transform.position, Vector3.Normalize(-impulse * 100000000f) * carReactToPlayerHitMultiplier);
				if (obstacleSize <= 1f)
				{
					mainRigidbody.AddForce(Vector3.Normalize(-impulse * 1E+09f) * 4f, (ForceMode)1);
					if (((Vector3)(ref vel)).magnitude > 1f)
					{
						enemyScript.KillEnemyOnOwnerClient();
					}
				}
				else
				{
					CarBumpServerRpc(averageVelocity);
					mainRigidbody.velocity = Vector3.Normalize(-impulse * 100000000f) * 9f;
					if ((Object)(object)currentDriver != (Object)null)
					{
						_ = currentDriver;
					}
					if (((Vector3)(ref vel)).magnitude > 2f && dealDamage)
					{
						enemyScript.HitEnemy(2, currentDriver, playHitSFX: true, 331);
					}
					result = true;
					if (obstacleSize > 2f)
					{
						DealPermanentDamage(1, position);
					}
				}
				Debug.DrawRay(position, -impulse * Mathf.Max(carReactToPlayerHitMultiplier, 500f), Color.red, 5f);
			}
			else
			{
				mainRigidbody.AddForce(Vector3.Normalize(-impulse * 1E+09f) * (carReactToPlayerHitMultiplier - 220f), (ForceMode)1);
				if (dealDamage)
				{
					DealPermanentDamage(1, position);
				}
				PlayerControllerB playerWhoHit = ((!((Object)(object)currentDriver != (Object)null)) ? currentPassenger : currentDriver);
				enemyScript.HitEnemy(12, playerWhoHit);
				Debug.DrawRay(position, (Vector3.up + -impulse / 2f) * Mathf.Max(((Vector3)(ref vel)).magnitude * carReactToPlayerHitMultiplier, 500f), Color.magenta, 5f);
			}
			PlayCollisionAudio(position, 5, 1f);
			return result;
		}
		default:
			return false;
		}
	}

	private void LateUpdate()
	{
		if (localPlayerInControl && !setControlTips)
		{
			setControlTips = true;
			HUDManager.Instance.ChangeControlTipMultiple(carTooltips);
		}
	}

	private void OnCollisionEnter(Collision collision)
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_030b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0315: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner || magnetedToShip || !hasBeenSpawned || ((Component)collision.collider).gameObject.layer != 8 || averageCount < 18)
		{
			return;
		}
		float num = 0f;
		int num2 = collision.GetContacts(contacts);
		Vector3 val = Vector3.zero;
		Vector3 damagePosition;
		for (int i = 0; i < num2; i++)
		{
			damagePosition = ((ContactPoint)(ref contacts[i])).impulse;
			if (((Vector3)(ref damagePosition)).magnitude > num)
			{
				damagePosition = ((ContactPoint)(ref contacts[i])).impulse;
				num = ((Vector3)(ref damagePosition)).magnitude;
			}
			val += ((ContactPoint)(ref contacts[i])).point;
		}
		val /= (float)num2;
		Debug.DrawRay(val, Vector3.up, Color.blue, 2f);
		num /= Time.fixedDeltaTime;
		if (num < minimalBumpForce || ((Vector3)(ref averageVelocity)).magnitude < 4f)
		{
			if (num2 > 3 && ((Vector3)(ref averageVelocity)).magnitude > 2.5f)
			{
				SetInternalStress(0.2f);
				lastStressType = "Scraping";
			}
			return;
		}
		float setVolume = 0.5f;
		int num3 = -1;
		if (((Vector3)(ref averageVelocity)).magnitude > 31f)
		{
			if (carHP < 3)
			{
				DestroyCar();
				DestroyCarServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
				return;
			}
			int damageAmount = carHP - 2;
			damagePosition = default(Vector3);
			DealPermanentDamage(damageAmount, damagePosition);
		}
		else if (((Vector3)(ref averageVelocity)).magnitude > 28f)
		{
			damagePosition = default(Vector3);
			DealPermanentDamage(2, damagePosition);
		}
		if (num > maximumBumpForce && ((Vector3)(ref averageVelocity)).magnitude > 11f)
		{
			num3 = 2;
			setVolume = Mathf.Clamp((num - maximumBumpForce) / 20000f, 0.8f, 1f);
			setVolume = Mathf.Clamp(setVolume + Random.Range(-0.15f, 0.25f), 0.7f, 1f);
		}
		else if (num > mediumBumpForce && ((Vector3)(ref averageVelocity)).magnitude > 3f)
		{
			num3 = 1;
			setVolume = Mathf.Clamp((num - mediumBumpForce) / (maximumBumpForce - mediumBumpForce), 0.67f, 1f);
			setVolume = Mathf.Clamp(setVolume + Random.Range(-0.15f, 0.25f), 0.5f, 1f);
		}
		else if (((Vector3)(ref averageVelocity)).magnitude > 1.5f)
		{
			num3 = 0;
			setVolume = Mathf.Clamp((num - mediumBumpForce) / (maximumBumpForce - mediumBumpForce), 0.25f, 1f);
			setVolume = Mathf.Clamp(setVolume + Random.Range(-0.15f, 0.25f), 0.25f, 1f);
		}
		if (num3 != -1)
		{
			PlayCollisionAudio(val, num3, setVolume);
			if (num > maximumBumpForce + 10000f && ((Vector3)(ref averageVelocity)).magnitude > 19f)
			{
				DamagePlayerInVehicle(Vector3.ClampMagnitude(-collision.relativeVelocity, 60f), ((Vector3)(ref averageVelocity)).magnitude);
				BreakWindshield();
				CarCollisionServerRpc(Vector3.ClampMagnitude(-collision.relativeVelocity, 60f), ((Vector3)(ref averageVelocity)).magnitude);
				damagePosition = default(Vector3);
				DealPermanentDamage(2, damagePosition);
			}
			else
			{
				CarBumpServerRpc(Vector3.ClampMagnitude(-collision.relativeVelocity, 40f));
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void CarBumpServerRpc(Vector3 vel)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2627964612u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref vel);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2627964612u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				CarBumpClientRpc(vel);
			}
		}
	}

	[ClientRpc]
	public void CarBumpClientRpc(Vector3 vel)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3157053164u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref vel);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3157053164u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (Object)(object)physicsRegion.physicsTransform == (Object)(object)GameNetworkManager.Instance.localPlayerController.physicsParent && ((!localPlayerInControl && !localPlayerInPassengerSeat) || !(((Vector3)(ref vel)).magnitude < 50f)))
			{
				PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
				localPlayerController.externalForceAutoFade += vel;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void CarCollisionServerRpc(Vector3 vel, float magn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2778459828u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref vel);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref magn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2778459828u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				CarCollisionClientRpc(vel, magn);
			}
		}
	}

	[ClientRpc]
	public void CarCollisionClientRpc(Vector3 vel, float magn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1258964565u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref vel);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref magn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1258964565u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				DamagePlayerInVehicle(vel, magn);
				BreakWindshield();
			}
		}
	}

	private void DamagePlayerInVehicle(Vector3 vel, float magnitude)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		if (localPlayerInPassengerSeat || localPlayerInControl)
		{
			Debug.DrawRay(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, vel, Color.yellow, 10f);
			if (magnitude > 28f)
			{
				GameNetworkManager.Instance.localPlayerController.KillPlayer(vel, spawnBody: true, CauseOfDeath.Inertia, 0, ((Component)this).transform.up * 0.77f);
			}
			else if (magnitude > 24f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.VeryStrong);
				if (GameNetworkManager.Instance.localPlayerController.health < 20)
				{
					GameNetworkManager.Instance.localPlayerController.KillPlayer(vel, spawnBody: true, CauseOfDeath.Inertia, 0, ((Component)this).transform.up * 0.77f);
				}
				else
				{
					GameNetworkManager.Instance.localPlayerController.DamagePlayer(40, hasDamageSFX: true, callRPC: true, CauseOfDeath.Inertia, 0, fallDamage: false, vel);
				}
			}
			else
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
				GameNetworkManager.Instance.localPlayerController.DamagePlayer(30, hasDamageSFX: true, callRPC: true, CauseOfDeath.Inertia, 0, fallDamage: false, vel);
			}
		}
		else if ((Object)(object)physicsRegion.physicsTransform == (Object)(object)GameNetworkManager.Instance.localPlayerController.physicsParent && (Object)(object)GameNetworkManager.Instance.localPlayerController.overridePhysicsParent == (Object)null)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
			GameNetworkManager.Instance.localPlayerController.DamagePlayer(10, hasDamageSFX: true, callRPC: true, CauseOfDeath.Inertia, 0, fallDamage: false, vel);
			PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
			localPlayerController.externalForceAutoFade += vel;
		}
	}

	private void BreakWindshield()
	{
		if (!windshieldBroken)
		{
			windshieldBroken = true;
			((Collider)windshieldPhysicsCollider).enabled = false;
			Material[] materials = ((Renderer)mainBodyMesh).materials;
			materials[2] = windshieldBrokenMat;
			((Renderer)mainBodyMesh).materials = materials;
			glassParticle.Play();
			miscAudio.PlayOneShot(windshieldBreak);
		}
	}

	public void PlayCollisionAudio(Vector3 setPosition, int audioType, float setVolume)
	{
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"Play collision audio with type {audioType} A");
		if (Time.realtimeSinceStartup - audio1Time > Time.realtimeSinceStartup - audio2Time)
		{
			bool flag = Time.realtimeSinceStartup - audio1Time >= collisionAudio1.clip.length * 0.8f;
			if (audio1Type <= audioType || flag)
			{
				audio1Time = Time.realtimeSinceStartup;
				audio1Type = audioType;
				((Component)collisionAudio1).transform.position = setPosition;
				PlayRandomClipAndPropertiesFromAudio(collisionAudio1, setVolume, flag, audioType);
				CarCollisionSFXServerRpc(((Component)collisionAudio1).transform.localPosition, 0, audioType, setVolume);
			}
		}
		else
		{
			bool flag = Time.realtimeSinceStartup - audio2Time >= collisionAudio2.clip.length * 0.8f;
			if (audio1Type <= audioType || flag)
			{
				audio2Time = Time.realtimeSinceStartup;
				audio2Type = audioType;
				((Component)collisionAudio2).transform.position = setPosition;
				PlayRandomClipAndPropertiesFromAudio(collisionAudio2, setVolume, flag, audioType);
				CarCollisionSFXServerRpc(((Component)collisionAudio2).transform.localPosition, 1, audioType, setVolume);
			}
		}
	}

	[ServerRpc]
	public void CarCollisionSFXServerRpc(Vector3 audioPosition, int audio, int audioType, float vol)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Invalid comparison between Unknown and I4
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1149255829u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref audioPosition);
			BytePacker.WriteValueBitPacked(val2, audio);
			BytePacker.WriteValueBitPacked(val2, audioType);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref vol, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1149255829u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			CarCollisionSFXClientRpc(audioPosition, audio, audioType, vol);
		}
	}

	[ClientRpc]
	public void CarCollisionSFXClientRpc(Vector3 audioPosition, int audio, int audioType, float vol)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(794211159u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref audioPosition);
				BytePacker.WriteValueBitPacked(val2, audio);
				BytePacker.WriteValueBitPacked(val2, audioType);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref vol, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 794211159u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				AudioSource val3 = ((audio != 0) ? collisionAudio2 : collisionAudio1);
				bool audioFinished = val3.clip.length - val3.time < 0.2f;
				((Component)val3).transform.localPosition = audioPosition;
				PlayRandomClipAndPropertiesFromAudio(val3, vol, audioFinished, audioType);
			}
		}
	}

	private void PlayRandomClipAndPropertiesFromAudio(AudioSource audio, float setVolume, bool audioFinished, int audioType)
	{
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		if (!audioFinished)
		{
			audio.Stop();
		}
		AudioClip[] array;
		switch (audioType)
		{
		case 0:
			array = minCollisions;
			turbulenceAmount = Mathf.Min(turbulenceAmount + 0.4f, 2f);
			break;
		case 1:
			array = medCollisions;
			turbulenceAmount = Mathf.Min(turbulenceAmount + 0.75f, 2f);
			break;
		case 2:
			array = maxCollisions;
			turbulenceAmount = Mathf.Min(turbulenceAmount + 1.4f, 2f);
			break;
		default:
			array = obstacleCollisions;
			turbulenceAmount = Mathf.Min(turbulenceAmount + 0.75f, 2f);
			break;
		}
		AudioClip val = array[Random.Range(0, array.Length)];
		if ((Object)(object)val == (Object)(object)audio.clip && Random.Range(0, 10) <= 5)
		{
			val = array[Random.Range(0, array.Length)];
		}
		if (audioFinished)
		{
			audio.pitch = Random.Range(0.8f, 1.2f);
		}
		audio.clip = val;
		audio.PlayOneShot(val, setVolume);
		if (audioType >= 2)
		{
			RoundManager.Instance.PlayAudibleNoise(((Component)engineAudio1).transform.position, 18f + setVolume / 1f * 7f, 0.6f, 0, noiseIsInsideClosedShip: false, 2692);
		}
		else if (audioType >= 1)
		{
			RoundManager.Instance.PlayAudibleNoise(((Component)engineAudio1).transform.position, 12f + setVolume / 1f * 7f, 0.6f, 0, noiseIsInsideClosedShip: false, 2692);
		}
		if (audioType == -1)
		{
			array = minCollisions;
			val = array[Random.Range(0, array.Length)];
			audio.PlayOneShot(val);
		}
	}

	private void SetInternalStress(float carStressIncrease = 0f)
	{
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)StartOfRound.Instance.testRoom == (Object)null) || !StartOfRound.Instance.inShipPhase)
		{
			if (carStressIncrease <= 0f)
			{
				carStressChange = Mathf.Clamp(carStressChange - Time.deltaTime, -0.25f, 0.5f);
			}
			else
			{
				carStressChange = Mathf.Clamp(carStressChange + Time.deltaTime * carStressIncrease, 0f, 10f);
			}
			underExtremeStress = carStressIncrease >= 1f;
			carStress = Mathf.Clamp(carStress + carStressChange, 0f, 100f);
			if (carStress > 7f)
			{
				carStress = 0f;
				DealPermanentDamage(2);
				lastDamageType = "Stress";
			}
		}
	}

	private void DealPermanentDamage(int damageAmount, Vector3 damagePosition = default(Vector3))
	{
		if ((!((Object)(object)StartOfRound.Instance.testRoom == (Object)null) || !StartOfRound.Instance.inShipPhase) && !magnetedToShip && !carDestroyed && ((NetworkBehaviour)this).IsOwner)
		{
			timeAtLastDamage = Time.realtimeSinceStartup;
			carHP -= damageAmount;
			if (carHP <= 0)
			{
				DestroyCar();
				DestroyCarServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
			else
			{
				DealDamageServerRpc(damageAmount, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	[ServerRpc]
	public void DealDamageServerRpc(int amount, int sentByClient)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(410929414u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, amount);
			BytePacker.WriteValueBitPacked(val2, sentByClient);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 410929414u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DealDamageClientRpc(amount, sentByClient);
		}
	}

	[ClientRpc]
	public void DealDamageClientRpc(int amount, int sentByClient)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(625279901u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, amount);
				BytePacker.WriteValueBitPacked(val2, sentByClient);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 625279901u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != sentByClient)
			{
				carHP -= amount;
				timeAtLastDamage = Time.realtimeSinceStartup;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void DestroyCarServerRpc(int sentByClient)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4012624473u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, sentByClient);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4012624473u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DestroyCarClientRpc(sentByClient);
			}
		}
	}

	[ClientRpc]
	public void DestroyCarClientRpc(int sentByClient)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1707315732u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, sentByClient);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1707315732u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !carDestroyed)
			{
				DestroyCar();
			}
		}
	}

	private void DestroyCar()
	{
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0338: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		if (!carDestroyed)
		{
			carDestroyed = true;
			magnetedToShip = false;
			StartOfRound.Instance.isObjectAttachedToMagnet = false;
			CollectItemsInTruck();
			underExtremeStress = false;
			Debug.Log((object)"Destroy truck");
			((Renderer)keyObject).enabled = false;
			engineAudio1.Stop();
			engineAudio2.Stop();
			turbulenceAudio.Stop();
			rollingAudio.Stop();
			radioAudio.Stop();
			extremeStressAudio.Stop();
			honkingHorn = false;
			hornAudio.Stop();
			tireSparks.Stop();
			skiddingAudio.Stop();
			turboBoostAudio.Stop();
			turboBoostParticle.Stop();
			RoundManager.Instance.PlayAudibleNoise(((Component)engineAudio1).transform.position, 20f, 0.8f, 0, noiseIsInsideClosedShip: false, 2692);
			FrontLeftWheel.motorTorque = 0f;
			FrontRightWheel.motorTorque = 0f;
			FrontRightWheel.brakeTorque = 0f;
			FrontLeftWheel.brakeTorque = 0f;
			for (int i = 0; i < otherWheels.Length; i++)
			{
				otherWheels[i].motorTorque = 0f;
				otherWheels[i].brakeTorque = 0f;
			}
			((Renderer)leftWheelMesh).enabled = false;
			((Renderer)rightWheelMesh).enabled = false;
			((Renderer)backLeftWheelMesh).enabled = false;
			((Renderer)backRightWheelMesh).enabled = false;
			((Renderer)((Component)carHoodAnimator).gameObject.GetComponentInChildren<MeshRenderer>()).enabled = false;
			backDoorContainer.SetActive(false);
			headlightsContainer.SetActive(false);
			BreakWindshield();
			destroyedTruckMesh.SetActive(true);
			((Component)mainBodyMesh).gameObject.SetActive(false);
			WheelCollider[] componentsInChildren = ((Component)this).gameObject.GetComponentsInChildren<WheelCollider>();
			for (int j = 0; j < componentsInChildren.Length; j++)
			{
				((Collider)componentsInChildren[j]).enabled = false;
			}
			mainRigidbody.ResetCenterOfMass();
			mainRigidbody.AddForceAtPosition(Vector3.up * 1560f, ((Component)hoodFireAudio).transform.position - Vector3.up, (ForceMode)1);
			if (localPlayerInControl || localPlayerInPassengerSeat)
			{
				Vector3 val = Vector3.up * 27f + 20f * Random.insideUnitSphere;
				Debug.Log((object)$"Killing player with force magnitude of : {((Vector3)(ref val)).magnitude}");
				GameNetworkManager.Instance.localPlayerController.KillPlayer(Vector3.up * 27f + 20f * Random.insideUnitSphere, spawnBody: true, CauseOfDeath.Blast, 6, Vector3.up * 1.5f);
			}
			InteractTrigger[] componentsInChildren2 = ((Component)this).gameObject.GetComponentsInChildren<InteractTrigger>();
			for (int k = 0; k < componentsInChildren2.Length; k++)
			{
				componentsInChildren2[k].interactable = false;
				componentsInChildren2[k].CancelAnimationExternally();
			}
			Landmine.SpawnExplosion(((Component)this).transform.position + ((Component)this).transform.forward + Vector3.up * 1.5f, spawnExplosionEffect: true, 6f, 10f, 30, 200f, truckDestroyedExplosion, goThroughCar: true);
		}
	}

	private void ReactToDamage()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		healthMeter.localScale = new Vector3(1f, 1f, Mathf.Lerp(healthMeter.localScale.z, Mathf.Clamp((float)carHP / (float)baseCarHP, 0.01f, 1f), 6f * Time.deltaTime));
		turboMeter.localScale = new Vector3(1f, 1f, Mathf.Lerp(turboMeter.localScale.z, Mathf.Clamp((float)turboBoosts / 5f, 0.01f, 1f), 6f * Time.deltaTime));
		if (carHP < 25 && Time.realtimeSinceStartup - timeAtLastDamage > 5f)
		{
			timeAtLastDamage = Time.realtimeSinceStartup;
			carHP++;
		}
		if (carHP < 3)
		{
			if (!isHoodOnFire)
			{
				if (!hoodPoppedUp && ((NetworkBehaviour)this).IsOwner)
				{
					hoodPoppedUp = true;
					SetHoodOpenLocalClient(setOpen: true);
				}
				isHoodOnFire = true;
				hoodFireAudio.Play();
				hoodFireParticle.Play();
			}
		}
		else if (isHoodOnFire)
		{
			isHoodOnFire = false;
			hoodFireAudio.Stop();
			hoodFireParticle.Stop(true, (ParticleSystemStopBehavior)1);
		}
	}

	public void PushTruckWithArms()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)GameNetworkManager.Instance.localPlayerController.physicsParent == (Object)(object)((Component)physicsRegion).transform) && !localPlayerInControl && !localPlayerInPassengerSeat && Physics.Raycast(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward, ref hit, 10f, 1073742656, (QueryTriggerInteraction)1))
		{
			Vector3 point = ((RaycastHit)(ref hit)).point;
			Vector3 forward = ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.forward;
			if (((NetworkBehaviour)this).IsOwner)
			{
				mainRigidbody.AddForceAtPosition(Vector3.Normalize(forward * 1000f) * Random.Range(40f, 50f) * pushForceMultiplier, point - ((Component)mainRigidbody).transform.up * pushVerticalOffsetAmount, (ForceMode)1);
				PushTruckFromOwnerServerRpc(point);
			}
			else
			{
				PushTruckServerRpc(point, forward);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PushTruckServerRpc(Vector3 pos, Vector3 dir)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4058179333u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref dir);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4058179333u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PushTruckClientRpc(pos, dir);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PushTruckFromOwnerServerRpc(Vector3 pos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1326342869u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1326342869u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PushTruckFromOwnerClientRpc(pos);
			}
		}
	}

	[ClientRpc]
	public void PushTruckClientRpc(Vector3 pushPosition, Vector3 dir)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3138260670u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref pushPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref dir);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3138260670u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			((Component)pushAudio).transform.position = pushPosition;
			pushAudio.Play();
			turbulenceAmount = Mathf.Min(turbulenceAmount + 0.5f, 2f);
			if (((NetworkBehaviour)this).IsOwner)
			{
				mainRigidbody.AddForceAtPosition(Vector3.Normalize(dir * 1000f) * Random.Range(40f, 50f) * pushForceMultiplier, pushPosition - ((Component)mainRigidbody).transform.up * pushVerticalOffsetAmount, (ForceMode)1);
			}
		}
	}

	[ClientRpc]
	public void PushTruckFromOwnerClientRpc(Vector3 pos)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4025368226u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4025368226u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				((Component)pushAudio).transform.position = pos;
				pushAudio.Play();
				turbulenceAmount = Mathf.Min(turbulenceAmount + 0.5f, 2f);
			}
		}
	}

	public void ToggleHoodOpenLocalClient()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		carHoodOpen = !carHoodOpen;
		carHoodAnimator.SetBool("hoodOpen", carHoodOpen);
		((Component)miscAudio).transform.position = ((Component)carHoodAnimator).transform.position;
		if (carHoodOpen)
		{
			miscAudio.PlayOneShot(carHoodOpenSFX);
		}
		else
		{
			miscAudio.PlayOneShot(carHoodCloseSFX);
		}
		SetHoodOpenServerRpc(carHoodOpen);
	}

	public void SetHoodOpenLocalClient(bool setOpen)
	{
		if (carHoodOpen != setOpen)
		{
			SetHoodOpenServerRpc(open: true);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetHoodOpenServerRpc(bool open)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3804995530u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref open, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3804995530u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetHoodOpenClientRpc(open);
			}
		}
	}

	[ClientRpc]
	public void SetHoodOpenClientRpc(bool open)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(673717576u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref open, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 673717576u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && carHoodOpen != open)
		{
			carHoodOpen = open;
			carHoodAnimator.SetBool("hoodOpen", open);
			((Component)miscAudio).transform.position = ((Component)carHoodAnimator).transform.position;
			if (open)
			{
				miscAudio.PlayOneShot(carHoodOpenSFX);
			}
			else
			{
				miscAudio.PlayOneShot(carHoodCloseSFX);
			}
		}
	}

	public void ToggleHeadlightsLocalClient()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		headlightsContainer.SetActive(!headlightsContainer.activeSelf);
		((Component)miscAudio).transform.position = headlightsContainer.transform.position;
		miscAudio.PlayOneShot(headlightsToggleSFX);
		SetHeadlightMaterial(headlightsContainer.activeSelf);
		ToggleHeadlightsServerRpc(headlightsContainer.activeSelf);
	}

	[ServerRpc(RequireOwnership = false)]
	public void ToggleHeadlightsServerRpc(bool setLightsOn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(369816798u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setLightsOn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 369816798u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ToggleHeadlightsClientRpc(setLightsOn);
			}
		}
	}

	[ClientRpc]
	public void ToggleHeadlightsClientRpc(bool setLightsOn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3014013968u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setLightsOn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3014013968u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && headlightsContainer.activeSelf != setLightsOn)
			{
				headlightsContainer.SetActive(setLightsOn);
				((Component)miscAudio).transform.position = headlightsContainer.transform.position;
				miscAudio.PlayOneShot(headlightsToggleSFX);
				SetHeadlightMaterial(setLightsOn);
			}
		}
	}

	private void SetHeadlightMaterial(bool on)
	{
		Material val = ((!on) ? headlightsOffMat : headlightsOnMat);
		Material[] sharedMaterials = ((Renderer)mainBodyMesh).sharedMaterials;
		sharedMaterials[1] = val;
		((Renderer)mainBodyMesh).sharedMaterials = sharedMaterials;
		sharedMaterials = ((Renderer)lod1Mesh).sharedMaterials;
		sharedMaterials[1] = val;
		((Renderer)mainBodyMesh).sharedMaterials = sharedMaterials;
		sharedMaterials = ((Renderer)mainBodyMesh).sharedMaterials;
		sharedMaterials[1] = val;
		((Renderer)mainBodyMesh).sharedMaterials = sharedMaterials;
	}

	public void SpringDriverSeatLocalClient()
	{
		if (!(Time.realtimeSinceStartup - timeSinceSpringingDriverSeat < 3f))
		{
			timeSinceSpringingDriverSeat = Time.realtimeSinceStartup;
			SpringDriverSeatServerRpc();
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SpringDriverSeatServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(46143233u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 46143233u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SpringDriverSeatClientRpc();
			}
		}
	}

	[ClientRpc]
	public void SpringDriverSeatClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(818134562u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 818134562u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			timeSinceSpringingDriverSeat = Time.realtimeSinceStartup;
			springAudio.Play();
			driverSeatSpringAnimator.SetTrigger("spring");
			if (localPlayerInControl || Vector3.Distance(((Component)this).transform.position, ((Component)springAudio).transform.position) < 1.25f)
			{
				PlayerControllerB playerControllerB = currentDriver;
				playerControllerB.externalForceAutoFade += ((Component)this).transform.up * springForce;
			}
			RoundManager.Instance.PlayAudibleNoise(((Component)springAudio).transform.position, 30f, 1f, 0, noiseIsInsideClosedShip: false, 2692);
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_VehicleController()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Expected O, but got Unknown
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Expected O, but got Unknown
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Expected O, but got Unknown
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Expected O, but got Unknown
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Expected O, but got Unknown
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Expected O, but got Unknown
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Expected O, but got Unknown
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Expected O, but got Unknown
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Expected O, but got Unknown
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Expected O, but got Unknown
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Expected O, but got Unknown
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Expected O, but got Unknown
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Expected O, but got Unknown
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Expected O, but got Unknown
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Expected O, but got Unknown
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Expected O, but got Unknown
		//IL_0413: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Expected O, but got Unknown
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Expected O, but got Unknown
		//IL_0449: Unknown result type (might be due to invalid IL or missing references)
		//IL_0453: Expected O, but got Unknown
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Expected O, but got Unknown
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Expected O, but got Unknown
		//IL_049a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a4: Expected O, but got Unknown
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bf: Expected O, but got Unknown
		//IL_04d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Expected O, but got Unknown
		//IL_04eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f5: Expected O, but got Unknown
		//IL_0506: Unknown result type (might be due to invalid IL or missing references)
		//IL_0510: Expected O, but got Unknown
		//IL_0521: Unknown result type (might be due to invalid IL or missing references)
		//IL_052b: Expected O, but got Unknown
		//IL_053c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0546: Expected O, but got Unknown
		//IL_0557: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Expected O, but got Unknown
		//IL_0572: Unknown result type (might be due to invalid IL or missing references)
		//IL_057c: Expected O, but got Unknown
		//IL_058d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0597: Expected O, but got Unknown
		//IL_05a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b2: Expected O, but got Unknown
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cd: Expected O, but got Unknown
		//IL_05de: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e8: Expected O, but got Unknown
		//IL_05f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0603: Expected O, but got Unknown
		//IL_0614: Unknown result type (might be due to invalid IL or missing references)
		//IL_061e: Expected O, but got Unknown
		//IL_062f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0639: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(269855870u, new RpcReceiveHandler(__rpc_handler_269855870));
		NetworkManager.__rpc_func_table.Add(1127926854u, new RpcReceiveHandler(__rpc_handler_1127926854));
		NetworkManager.__rpc_func_table.Add(1319663544u, new RpcReceiveHandler(__rpc_handler_1319663544));
		NetworkManager.__rpc_func_table.Add(3214494774u, new RpcReceiveHandler(__rpc_handler_3214494774));
		NetworkManager.__rpc_func_table.Add(2403570091u, new RpcReceiveHandler(__rpc_handler_2403570091));
		NetworkManager.__rpc_func_table.Add(3273216474u, new RpcReceiveHandler(__rpc_handler_3273216474));
		NetworkManager.__rpc_func_table.Add(835626980u, new RpcReceiveHandler(__rpc_handler_835626980));
		NetworkManager.__rpc_func_table.Add(3548459446u, new RpcReceiveHandler(__rpc_handler_3548459446));
		NetworkManager.__rpc_func_table.Add(4283235241u, new RpcReceiveHandler(__rpc_handler_4283235241));
		NetworkManager.__rpc_func_table.Add(2096620717u, new RpcReceiveHandler(__rpc_handler_2096620717));
		NetworkManager.__rpc_func_table.Add(2150817317u, new RpcReceiveHandler(__rpc_handler_2150817317));
		NetworkManager.__rpc_func_table.Add(46680660u, new RpcReceiveHandler(__rpc_handler_46680660));
		NetworkManager.__rpc_func_table.Add(2687785832u, new RpcReceiveHandler(__rpc_handler_2687785832));
		NetworkManager.__rpc_func_table.Add(1621098866u, new RpcReceiveHandler(__rpc_handler_1621098866));
		NetworkManager.__rpc_func_table.Add(2345405857u, new RpcReceiveHandler(__rpc_handler_2345405857));
		NetworkManager.__rpc_func_table.Add(2569589533u, new RpcReceiveHandler(__rpc_handler_2569589533));
		NetworkManager.__rpc_func_table.Add(1936869671u, new RpcReceiveHandler(__rpc_handler_1936869671));
		NetworkManager.__rpc_func_table.Add(1427257619u, new RpcReceiveHandler(__rpc_handler_1427257619));
		NetworkManager.__rpc_func_table.Add(2335366121u, new RpcReceiveHandler(__rpc_handler_2335366121));
		NetworkManager.__rpc_func_table.Add(2803421723u, new RpcReceiveHandler(__rpc_handler_2803421723));
		NetworkManager.__rpc_func_table.Add(3105401376u, new RpcReceiveHandler(__rpc_handler_3105401376));
		NetworkManager.__rpc_func_table.Add(2451439781u, new RpcReceiveHandler(__rpc_handler_2451439781));
		NetworkManager.__rpc_func_table.Add(2845017736u, new RpcReceiveHandler(__rpc_handler_2845017736));
		NetworkManager.__rpc_func_table.Add(735895017u, new RpcReceiveHandler(__rpc_handler_735895017));
		NetworkManager.__rpc_func_table.Add(2121824285u, new RpcReceiveHandler(__rpc_handler_2121824285));
		NetworkManager.__rpc_func_table.Add(2416458891u, new RpcReceiveHandler(__rpc_handler_2416458891));
		NetworkManager.__rpc_func_table.Add(4268487771u, new RpcReceiveHandler(__rpc_handler_4268487771));
		NetworkManager.__rpc_func_table.Add(548979688u, new RpcReceiveHandler(__rpc_handler_548979688));
		NetworkManager.__rpc_func_table.Add(2079068163u, new RpcReceiveHandler(__rpc_handler_2079068163));
		NetworkManager.__rpc_func_table.Add(1878146525u, new RpcReceiveHandler(__rpc_handler_1878146525));
		NetworkManager.__rpc_func_table.Add(4076738570u, new RpcReceiveHandler(__rpc_handler_4076738570));
		NetworkManager.__rpc_func_table.Add(721150963u, new RpcReceiveHandler(__rpc_handler_721150963));
		NetworkManager.__rpc_func_table.Add(3091363772u, new RpcReceiveHandler(__rpc_handler_3091363772));
		NetworkManager.__rpc_func_table.Add(2416589835u, new RpcReceiveHandler(__rpc_handler_2416589835));
		NetworkManager.__rpc_func_table.Add(2165949877u, new RpcReceiveHandler(__rpc_handler_2165949877));
		NetworkManager.__rpc_func_table.Add(2043456042u, new RpcReceiveHandler(__rpc_handler_2043456042));
		NetworkManager.__rpc_func_table.Add(894646603u, new RpcReceiveHandler(__rpc_handler_894646603));
		NetworkManager.__rpc_func_table.Add(3603115648u, new RpcReceiveHandler(__rpc_handler_3603115648));
		NetworkManager.__rpc_func_table.Add(3722438677u, new RpcReceiveHandler(__rpc_handler_3722438677));
		NetworkManager.__rpc_func_table.Add(2627964612u, new RpcReceiveHandler(__rpc_handler_2627964612));
		NetworkManager.__rpc_func_table.Add(3157053164u, new RpcReceiveHandler(__rpc_handler_3157053164));
		NetworkManager.__rpc_func_table.Add(2778459828u, new RpcReceiveHandler(__rpc_handler_2778459828));
		NetworkManager.__rpc_func_table.Add(1258964565u, new RpcReceiveHandler(__rpc_handler_1258964565));
		NetworkManager.__rpc_func_table.Add(1149255829u, new RpcReceiveHandler(__rpc_handler_1149255829));
		NetworkManager.__rpc_func_table.Add(794211159u, new RpcReceiveHandler(__rpc_handler_794211159));
		NetworkManager.__rpc_func_table.Add(410929414u, new RpcReceiveHandler(__rpc_handler_410929414));
		NetworkManager.__rpc_func_table.Add(625279901u, new RpcReceiveHandler(__rpc_handler_625279901));
		NetworkManager.__rpc_func_table.Add(4012624473u, new RpcReceiveHandler(__rpc_handler_4012624473));
		NetworkManager.__rpc_func_table.Add(1707315732u, new RpcReceiveHandler(__rpc_handler_1707315732));
		NetworkManager.__rpc_func_table.Add(4058179333u, new RpcReceiveHandler(__rpc_handler_4058179333));
		NetworkManager.__rpc_func_table.Add(1326342869u, new RpcReceiveHandler(__rpc_handler_1326342869));
		NetworkManager.__rpc_func_table.Add(3138260670u, new RpcReceiveHandler(__rpc_handler_3138260670));
		NetworkManager.__rpc_func_table.Add(4025368226u, new RpcReceiveHandler(__rpc_handler_4025368226));
		NetworkManager.__rpc_func_table.Add(3804995530u, new RpcReceiveHandler(__rpc_handler_3804995530));
		NetworkManager.__rpc_func_table.Add(673717576u, new RpcReceiveHandler(__rpc_handler_673717576));
		NetworkManager.__rpc_func_table.Add(369816798u, new RpcReceiveHandler(__rpc_handler_369816798));
		NetworkManager.__rpc_func_table.Add(3014013968u, new RpcReceiveHandler(__rpc_handler_3014013968));
		NetworkManager.__rpc_func_table.Add(46143233u, new RpcReceiveHandler(__rpc_handler_46143233));
		NetworkManager.__rpc_func_table.Add(818134562u, new RpcReceiveHandler(__rpc_handler_818134562));
	}

	private static void __rpc_handler_269855870(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).RemoveKeyFromIgnitionServerRpc(driverId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1127926854(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).RemoveKeyFromIgnitionClientRpc(driverId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1319663544(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).RevCarServerRpc(driverId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3214494774(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).RevCarClientRpc(driverId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2403570091(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).StartIgnitionServerRpc(driverId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3273216474(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).StartIgnitionClientRpc(driverId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_835626980(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			bool keyIsIn = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref keyIsIn, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).TryIgnitionServerRpc(driverId, keyIsIn);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3548459446(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			bool keyIsIn = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref keyIsIn, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).TryIgnitionClientRpc(driverId, keyIsIn);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4283235241(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			bool setKeyInSlot = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setKeyInSlot, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).CancelTryIgnitionServerRpc(driverId, setKeyInSlot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2096620717(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int driverId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref driverId);
			bool setKeyInSlot = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setKeyInSlot, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).CancelTryIgnitionClientRpc(driverId, setKeyInSlot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2150817317(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			Vector3 exitPoint = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref exitPoint);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).PassengerLeaveVehicleServerRpc(playerId, exitPoint);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_46680660(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			Vector3 exitPoint = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref exitPoint);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).PassengerLeaveVehicleClientRpc(playerId, exitPoint);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2687785832(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerInControlOfVehicleServerRpc = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerInControlOfVehicleServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).SetPlayerInControlOfVehicleServerRpc(playerInControlOfVehicleServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1621098866(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).CancelPlayerInControlOfVehicleClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2345405857(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			Vector3 carLocation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref carLocation);
			Quaternion carRotation = default(Quaternion);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref carRotation);
			bool setKeyInIgnition = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setKeyInIgnition, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).RemovePlayerControlOfVehicleServerRpc(playerId, carLocation, carRotation, setKeyInIgnition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2569589533(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerInControlOfVehicleClientRpc = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerInControlOfVehicleClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SetPlayerInControlOfVehicleClientRpc(playerInControlOfVehicleClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1936869671(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			bool setIgnitionStarted = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setIgnitionStarted, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).RemovePlayerControlOfVehicleClientRpc(playerId, setIgnitionStarted);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1427257619(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int setGear = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setGear);
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).ShiftToGearServerRpc(setGear, playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2335366121(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int setGear = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setGear);
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).ShiftToGearClientRpc(setGear, playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2803421723(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 carPosition = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref carPosition);
		Vector3 carRotation = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref carRotation);
		float num = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref num, default(ForPrimitives));
		float engineRPM = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref engineRPM, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((VehicleController)(object)target).SyncCarPositionServerRpc(carPosition, carRotation, num, engineRPM);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_3105401376(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 carPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref carPosition);
			Vector3 carRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref carRotation);
			float num = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref num, default(ForPrimitives));
			float engineSpeed = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref engineSpeed, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SyncCarPositionClientRpc(carPosition, carRotation, num, engineSpeed);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2451439781(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 targetPosition = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref targetPosition);
		Vector3 targetRotation = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref targetRotation);
		int playerWhoSent = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((VehicleController)(object)target).MagnetCarServerRpc(targetPosition, targetRotation, playerWhoSent);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_2845017736(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 targetPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetPosition);
			Vector3 targetRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetRotation);
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).MagnetCarClientRpc(targetPosition, targetRotation, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_735895017(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool honk = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref honk, default(ForPrimitives));
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).SetHonkServerRpc(honk, playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2121824285(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool honk = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref honk, default(ForPrimitives));
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SetHonkClientRpc(honk, playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2416458891(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int setTurboBoosts = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setTurboBoosts);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).AddTurboBoostServerRpc(playerId, setTurboBoosts);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4268487771(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int setTurboBoosts = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setTurboBoosts);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).AddTurboBoostClientRpc(playerId, setTurboBoosts);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_548979688(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int setHP = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setHP);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).AddEngineOilServerRpc(playerId, setHP);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2079068163(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			int setHP = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref setHP);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).AddEngineOilClientRpc(playerId, setHP);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1878146525(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).UseTurboBoostServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4076738570(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).UseTurboBoostClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_721150963(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int radioStation = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref radioStation);
			int signalQuality = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref signalQuality);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).SetRadioStationServerRpc(radioStation, signalQuality);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3091363772(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int radioStation = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref radioStation);
			int signalQuality = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref signalQuality);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SetRadioStationClientRpc(radioStation, signalQuality);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2416589835(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool radioOnServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref radioOnServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).SetRadioOnServerRpc(radioOnServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2165949877(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool radioOnClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref radioOnClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SetRadioOnClientRpc(radioOnClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2043456042(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int radioSignalQualityServerRpc = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref radioSignalQualityServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).SetRadioSignalQualityServerRpc(radioSignalQualityServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_894646603(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int radioSignalQualityClientRpc = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref radioSignalQualityClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SetRadioSignalQualityClientRpc(radioSignalQualityClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3603115648(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool underStress = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref underStress, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).SyncExtremeStressServerRpc(underStress);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3722438677(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool underStress = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref underStress, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SyncExtremeStressClientRpc(underStress);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2627964612(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 vel = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref vel);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).CarBumpServerRpc(vel);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3157053164(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 vel = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref vel);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).CarBumpClientRpc(vel);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2778459828(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 vel = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref vel);
			float magn = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref magn, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).CarCollisionServerRpc(vel, magn);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1258964565(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 vel = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref vel);
			float magn = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref magn, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).CarCollisionClientRpc(vel, magn);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1149255829(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 audioPosition = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref audioPosition);
		int audio = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref audio);
		int audioType = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref audioType);
		float vol = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref vol, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((VehicleController)(object)target).CarCollisionSFXServerRpc(audioPosition, audio, audioType, vol);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_794211159(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 audioPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref audioPosition);
			int audio = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref audio);
			int audioType = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref audioType);
			float vol = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref vol, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).CarCollisionSFXClientRpc(audioPosition, audio, audioType, vol);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_410929414(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int amount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref amount);
			int sentByClient = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref sentByClient);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).DealDamageServerRpc(amount, sentByClient);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_625279901(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int amount = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref amount);
			int sentByClient = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref sentByClient);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).DealDamageClientRpc(amount, sentByClient);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4012624473(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int sentByClient = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref sentByClient);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).DestroyCarServerRpc(sentByClient);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1707315732(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int sentByClient = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref sentByClient);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).DestroyCarClientRpc(sentByClient);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4058179333(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			Vector3 dir = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref dir);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).PushTruckServerRpc(pos, dir);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1326342869(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).PushTruckFromOwnerServerRpc(pos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3138260670(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pushPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pushPosition);
			Vector3 dir = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref dir);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).PushTruckClientRpc(pushPosition, dir);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4025368226(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).PushTruckFromOwnerClientRpc(pos);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3804995530(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool hoodOpenServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref hoodOpenServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).SetHoodOpenServerRpc(hoodOpenServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_673717576(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool hoodOpenClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref hoodOpenClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SetHoodOpenClientRpc(hoodOpenClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_369816798(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool setLightsOn = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setLightsOn, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).ToggleHeadlightsServerRpc(setLightsOn);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3014013968(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool setLightsOn = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setLightsOn, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).ToggleHeadlightsClientRpc(setLightsOn);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_46143233(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((VehicleController)(object)target).SpringDriverSeatServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_818134562(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((VehicleController)(object)target).SpringDriverSeatClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "VehicleController";
	}
}
