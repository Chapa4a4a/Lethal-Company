public enum TurretMode
{
	Detection,
	Charging,
	Firing,
	Berserk
}
