using UnityEngine;
using UnityEngine.Events;

public class PowerSwitchable : MonoBehaviour
{
	public OnSwitchPowerEvent powerSwitchEvent;

	public void OnPowerSwitch(bool switchedOn)
	{
		((UnityEvent<bool>)powerSwitchEvent).Invoke(switchedOn);
	}

	private void OnEnable()
	{
		((UnityEvent<bool>)RoundManager.Instance.onPowerSwitch).AddListener((UnityAction<bool>)OnPowerSwitch);
	}

	private void OnDisable()
	{
		((UnityEvent<bool>)RoundManager.Instance.onPowerSwitch).RemoveListener((UnityAction<bool>)OnPowerSwitch);
	}
}
