using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;

public class CentipedeAI : EnemyAI
{
	public PlayerControllerB clingingToPlayer;

	public AudioClip fallShriek;

	public AudioClip hitGroundSFX;

	public AudioClip hitCentipede;

	public AudioClip[] shriekClips;

	private int offsetNodeAmount = 6;

	private Vector3 mainEntrancePosition;

	public AnimationCurve fallToGroundCurve;

	public Vector3 ceilingHidingPoint;

	private RaycastHit rayHit;

	public Transform tempTransform;

	private Ray ray;

	private bool clingingToCeiling;

	private Coroutine ceilingAnimationCoroutine;

	private bool startedCeilingAnimationCoroutine;

	private Coroutine killAnimationCoroutine;

	private Vector3 propelVelocity = Vector3.zero;

	private float damagePlayerInterval;

	private bool clingingToLocalClient;

	private bool clingingToDeadBody;

	private bool inDroppingOffPlayerAnim;

	private Vector3 firstKilledPlayerPosition = Vector3.zero;

	private bool pathToFirstKilledBodyIsClear = true;

	private bool syncedPositionInPrepForCeilingAnimation;

	public Transform modelContainer;

	private float updateOffsetPositionInterval;

	private Vector3 offsetTargetPos;

	private bool triggeredFall;

	public AudioSource clingingToPlayer2DAudio;

	public AudioClip clingToPlayer3D;

	private float chaseTimer;

	private float stuckTimer;

	private Coroutine beginClingingToCeilingCoroutine;

	private Coroutine dropFromCeilingCoroutine;

	private bool singlePlayerSecondChanceGiven;

	private bool choseHidingSpotNoPlayersNearby;

	public override void Start()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		mainEntrancePosition = RoundManager.FindMainEntrancePosition();
		offsetTargetPos = ((Component)this).transform.position;
		base.Start();
	}

	public override void DoAIInterval()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.livingPlayers == 0 || isEnemyDead)
		{
			return;
		}
		if (currentBehaviourStateIndex == 0 && firstKilledPlayerPosition != Vector3.zero && pathToFirstKilledBodyIsClear && Vector3.Distance(((Component)this).transform.position, firstKilledPlayerPosition) < 13f)
		{
			choseHidingSpotNoPlayersNearby = false;
			ChooseHidingSpotNearPlayer(firstKilledPlayerPosition, targetingPositionOfFirstKilledPlayer: true);
		}
		else if (!TargetClosestPlayer())
		{
			if (!choseHidingSpotNoPlayersNearby)
			{
				choseHidingSpotNoPlayersNearby = true;
				SetDestinationToNode(ChooseFarthestNodeFromPosition(mainEntrancePosition, avoidLineOfSight: false, (allAINodes.Length / 2 + thisEnemyIndex) % allAINodes.Length));
			}
			else if (PathIsIntersectedByLineOfSight(destination, calculatePathDistance: false, avoidLineOfSight: false))
			{
				choseHidingSpotNoPlayersNearby = false;
			}
			if (currentBehaviourStateIndex == 2)
			{
				SwitchToBehaviourState(0);
			}
		}
		else
		{
			choseHidingSpotNoPlayersNearby = false;
			if (currentBehaviourStateIndex == 0)
			{
				ChooseHidingSpotNearPlayer(((Component)targetPlayer).transform.position);
			}
			else if (currentBehaviourStateIndex == 2)
			{
				movingTowardsTargetPlayer = true;
			}
		}
	}

	public void ChooseHidingSpotNearPlayer(Vector3 targetPos, bool targetingPositionOfFirstKilledPlayer = false)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		movingTowardsTargetPlayer = false;
		if ((Object)(object)targetNode != (Object)null)
		{
			if (!PathIsIntersectedByLineOfSight(targetNode.position))
			{
				SetDestinationToNode(targetNode);
				return;
			}
			if (targetingPositionOfFirstKilledPlayer)
			{
				pathToFirstKilledBodyIsClear = false;
			}
		}
		_ = (offsetNodeAmount + thisEnemyIndex) % allAINodes.Length;
		if (targetingPositionOfFirstKilledPlayer)
		{
			Random.Range(0, 3);
		}
		Transform val = ChooseClosestNodeToPosition(targetPos, avoidLineOfSight: true, offsetNodeAmount);
		if ((Object)(object)val != (Object)null)
		{
			SetDestinationToNode(val);
			return;
		}
		if (targetingPositionOfFirstKilledPlayer)
		{
			pathToFirstKilledBodyIsClear = false;
			return;
		}
		val = ChooseClosestNodeToPosition(((Component)this).transform.position);
		SetDestinationToNode(val);
	}

	private void SetDestinationToNode(Transform moveTowardsNode)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		targetNode = moveTowardsNode;
		SetDestinationToPosition(targetNode.position);
	}

	private void LateUpdate()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if (isEnemyDead)
		{
			((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
		}
		else if ((Object)(object)clingingToPlayer == (Object)null)
		{
			if (!clingingToCeiling)
			{
				if (updateOffsetPositionInterval <= 0f)
				{
					offsetTargetPos = RoundManager.Instance.RandomlyOffsetPosition(((Component)this).transform.position, 1.5f);
					updateOffsetPositionInterval = 0.04f;
				}
				else
				{
					modelContainer.position = Vector3.Lerp(modelContainer.position, offsetTargetPos, 3f * Time.deltaTime);
					updateOffsetPositionInterval -= Time.deltaTime;
				}
			}
			else
			{
				modelContainer.localPosition = Vector3.zero;
			}
		}
		else
		{
			modelContainer.localPosition = Vector3.zero;
			if (clingingToDeadBody && (Object)(object)clingingToPlayer.deadBody != (Object)null)
			{
				((Component)this).transform.position = ((Component)clingingToPlayer.deadBody.bodyParts[0]).transform.position;
				((Component)this).transform.eulerAngles = ((Component)clingingToPlayer.deadBody.bodyParts[0]).transform.eulerAngles;
			}
			else
			{
				UpdatePositionToClingingPlayerHead();
			}
		}
	}

	private void UpdatePositionToClingingPlayerHead()
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (clingingToLocalClient)
		{
			((Component)this).transform.position = ((Component)clingingToPlayer.gameplayCamera).transform.position;
			((Component)this).transform.eulerAngles = ((Component)clingingToPlayer.gameplayCamera).transform.eulerAngles;
		}
		else
		{
			((Component)this).transform.position = clingingToPlayer.playerGlobalHead.position + clingingToPlayer.playerGlobalHead.up * 0.38f;
			((Component)this).transform.eulerAngles = clingingToPlayer.playerGlobalHead.eulerAngles;
		}
	}

	public override void Update()
	{
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (((NetworkBehaviour)this).IsOwner)
			{
				IncreaseSpeedSlowly(10f);
				movingTowardsTargetPlayer = false;
				if ((Object)(object)targetNode != (Object)null)
				{
					tempTransform.position = new Vector3(targetNode.position.x, ((Component)this).transform.position.y, targetNode.position.z);
					float num = Vector3.Distance(((Component)this).transform.position, tempTransform.position);
					if (num < 0.3f && !Physics.Linecast(((Component)this).transform.position, targetNode.position, 256))
					{
						RaycastToCeiling();
					}
					else if (num < 2.5f && !syncedPositionInPrepForCeilingAnimation)
					{
						syncedPositionInPrepForCeilingAnimation = true;
						SyncPositionToClients();
					}
				}
				Vector3 velocity = agent.velocity;
				if (((Vector3)(ref velocity)).sqrMagnitude < 0.002f)
				{
					stuckTimer += Time.deltaTime;
					if (stuckTimer > 4f)
					{
						stuckTimer = 0f;
						offsetNodeAmount++;
						targetNode = null;
					}
				}
			}
			chaseTimer = 0f;
			break;
		case 1:
			if (!clingingToCeiling)
			{
				if (!startedCeilingAnimationCoroutine && ceilingAnimationCoroutine == null)
				{
					startedCeilingAnimationCoroutine = true;
					ceilingAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(clingToCeiling());
				}
				break;
			}
			((Component)this).transform.position = Vector3.SmoothDamp(((Component)this).transform.position, ceilingHidingPoint, ref propelVelocity, 0.1f);
			ray = new Ray(((Component)this).transform.position, Vector3.down);
			if (Physics.SphereCast(ray, 2.15f, ref rayHit, 20f, StartOfRound.Instance.playersMask) && (Object)(object)((RaycastHit)(ref rayHit)).transform == (Object)(object)((Component)GameNetworkManager.Instance.localPlayerController).transform && !Object.op_Implicit((Object)(object)clingingToPlayer) && !Physics.Linecast(((RaycastHit)(ref rayHit)).transform.position, ((Component)this).transform.position, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1) && !triggeredFall)
			{
				triggeredFall = true;
				TriggerCentipedeFallServerRpc(NetworkManager.Singleton.LocalClientId);
			}
			break;
		case 2:
			triggeredFall = false;
			if (clingingToCeiling)
			{
				if (!startedCeilingAnimationCoroutine && ceilingAnimationCoroutine == null)
				{
					startedCeilingAnimationCoroutine = true;
					ceilingAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(fallFromCeiling());
				}
			}
			else if (((NetworkBehaviour)this).IsOwner)
			{
				IncreaseSpeedSlowly();
				chaseTimer += Time.deltaTime;
				if (chaseTimer > 10f)
				{
					chaseTimer = 0f;
					SwitchToBehaviourState(0);
				}
			}
			break;
		case 3:
			if (!((Object)(object)clingingToPlayer != (Object)null))
			{
				break;
			}
			if (((NetworkBehaviour)this).IsOwner && !clingingToPlayer.isInsideFactory && !clingingToPlayer.isPlayerDead)
			{
				KillEnemyOnOwnerClient();
				break;
			}
			if (clingingToLocalClient)
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(1f);
				DamagePlayerOnIntervals();
			}
			else if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position, 60f, 12))
			{
				GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(0.6f, 0.9f);
			}
			if ((Object)(object)clingingToPlayer != (Object)null && clingingToPlayer.isPlayerDead && !inDroppingOffPlayerAnim)
			{
				inDroppingOffPlayerAnim = true;
				StopClingingToPlayer(playerDead: true);
			}
			break;
		}
	}

	private void DamagePlayerOnIntervals()
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		if (damagePlayerInterval <= 0f && !inDroppingOffPlayerAnim)
		{
			if (stunNormalizedTimer > 0f || (StartOfRound.Instance.connectedPlayersAmount <= 0 && clingingToPlayer.health <= 15 && !singlePlayerSecondChanceGiven))
			{
				singlePlayerSecondChanceGiven = true;
				inDroppingOffPlayerAnim = true;
				StopClingingServerRpc(playerDead: false);
			}
			else
			{
				clingingToPlayer.DamagePlayer(10, hasDamageSFX: true, callRPC: true, CauseOfDeath.Suffocation);
				damagePlayerInterval = 2f;
			}
		}
		else
		{
			damagePlayerInterval -= Time.deltaTime;
		}
	}

	private void IncreaseSpeedSlowly(float increaseSpeed = 1.5f)
	{
		if (stunNormalizedTimer > 0f)
		{
			creatureAnimator.SetBool("stunned", true);
			agent.speed = 0f;
		}
		else
		{
			creatureAnimator.SetBool("stunned", false);
			agent.speed = Mathf.Clamp(agent.speed + Time.deltaTime * 1.5f, 0f, 5.5f);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StopClingingServerRpc(bool playerDead)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4105250505u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref playerDead, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4105250505u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				StopClingingClientRpc(playerDead);
			}
		}
	}

	[ClientRpc]
	public void StopClingingClientRpc(bool playerDead)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1106241822u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref playerDead, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1106241822u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				inDroppingOffPlayerAnim = true;
				StopClingingToPlayer(playerDead);
			}
		}
	}

	private void OnEnable()
	{
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).AddListener((UnityAction<PlayerControllerB>)OnPlayerTeleport);
	}

	private void OnDisable()
	{
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).RemoveListener((UnityAction<PlayerControllerB>)OnPlayerTeleport);
	}

	private void OnPlayerTeleport(PlayerControllerB playerTeleported)
	{
		if ((Object)(object)clingingToPlayer == (Object)(object)playerTeleported && ((NetworkBehaviour)this).IsOwner)
		{
			KillEnemyOnOwnerClient();
		}
	}

	private void StopClingingToPlayer(bool playerDead)
	{
		if ((Object)(object)clingingToPlayer.currentVoiceChatAudioSource == (Object)null)
		{
			StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
		}
		if ((Object)(object)clingingToPlayer.currentVoiceChatAudioSource != (Object)null)
		{
			((Component)clingingToPlayer.currentVoiceChatAudioSource).GetComponent<AudioLowPassFilter>().lowpassResonanceQ = 1f;
			OccludeAudio component = ((Component)clingingToPlayer.currentVoiceChatAudioSource).GetComponent<OccludeAudio>();
			component.overridingLowPass = false;
			component.lowPassOverride = 20000f;
			clingingToPlayer.voiceMuffledByEnemy = false;
		}
		if (clingingToLocalClient)
		{
			clingingToPlayer2DAudio.Stop();
		}
		else
		{
			creatureSFX.Stop();
		}
		clingingToLocalClient = false;
		if (killAnimationCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(killAnimationCoroutine);
		}
		killAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(UnclingFromPlayer(clingingToPlayer, playerDead));
	}

	private IEnumerator UnclingFromPlayer(PlayerControllerB playerBeingKilled, bool playerDead = true)
	{
		if (playerDead)
		{
			clingingToDeadBody = true;
			yield return (object)new WaitForSeconds(1.5f);
			clingingToDeadBody = false;
		}
		clingingToPlayer = null;
		creatureAnimator.SetBool("clingingToPlayer", false);
		ray = new Ray(((Component)this).transform.position, Vector3.down);
		_ = ((Component)this).transform.position;
		Vector3 startPosition = ((Component)this).transform.position;
		Vector3 groundPosition = ((!Physics.Raycast(ray, ref rayHit, 40f, 256)) ? RoundManager.Instance.GetNavMeshPosition(((Component)this).transform.position) : ((RaycastHit)(ref rayHit)).point);
		float fallTime = 0.2f;
		while (fallTime < 1f)
		{
			yield return null;
			fallTime += Time.deltaTime * 4f;
			((Component)this).transform.position = Vector3.Lerp(startPosition, groundPosition, fallToGroundCurve.Evaluate(fallTime));
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			agent.speed = 0f;
		}
		else
		{
			((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
		}
		serverPosition = ((Component)this).transform.position;
		inSpecialAnimation = false;
		inDroppingOffPlayerAnim = false;
		SwitchToBehaviourStateOnLocalClient(0);
		if (playerDead)
		{
			firstKilledPlayerPosition = ((Component)this).transform.position;
			pathToFirstKilledBodyIsClear = true;
		}
		movingTowardsTargetPlayer = false;
		targetNode = null;
	}

	public override void CancelSpecialAnimationWithPlayer()
	{
		base.CancelSpecialAnimationWithPlayer();
		_ = ((NetworkBehaviour)this).IsOwner;
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		base.OnCollideWithPlayer(other);
		if (!(stunNormalizedTimer >= 0f) && currentBehaviourStateIndex == 2 && !((Object)(object)clingingToPlayer != (Object)null))
		{
			PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				clingingToPlayer = playerControllerB;
				ClingToPlayerServerRpc(playerControllerB.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ClingToPlayerServerRpc(ulong playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2791977891u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2791977891u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClingToPlayerClientRpc(playerObjectId);
			}
		}
	}

	[ClientRpc]
	public void ClingToPlayerClientRpc(ulong playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2474017466u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2474017466u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				ClingToPlayer(StartOfRound.Instance.allPlayerScripts[playerObjectId]);
			}
		}
	}

	private void ClingToPlayer(PlayerControllerB playerScript)
	{
		if (ceilingAnimationCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(ceilingAnimationCoroutine);
			ceilingAnimationCoroutine = null;
		}
		startedCeilingAnimationCoroutine = false;
		clingingToCeiling = false;
		clingingToLocalClient = (Object)(object)playerScript == (Object)(object)GameNetworkManager.Instance.localPlayerController;
		clingingToPlayer = playerScript;
		inSpecialAnimation = true;
		((Behaviour)agent).enabled = false;
		playerScript.DropAllHeldItems();
		creatureAnimator.SetBool("clingingToPlayer", true);
		if ((Object)(object)clingingToPlayer.currentVoiceChatAudioSource == (Object)null)
		{
			StartOfRound.Instance.RefreshPlayerVoicePlaybackObjects();
		}
		if ((Object)(object)clingingToPlayer.currentVoiceChatAudioSource != (Object)null)
		{
			((Component)clingingToPlayer.currentVoiceChatAudioSource).GetComponent<AudioLowPassFilter>().lowpassResonanceQ = 5f;
			OccludeAudio component = ((Component)clingingToPlayer.currentVoiceChatAudioSource).GetComponent<OccludeAudio>();
			component.overridingLowPass = true;
			component.lowPassOverride = 500f;
			clingingToPlayer.voiceMuffledByEnemy = true;
		}
		if (clingingToLocalClient)
		{
			clingingToPlayer2DAudio.Play();
			GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(1f);
		}
		else
		{
			creatureSFX.clip = clingToPlayer3D;
			creatureSFX.Play();
		}
		inDroppingOffPlayerAnim = false;
		SwitchToBehaviourStateOnLocalClient(3);
	}

	private IEnumerator fallFromCeiling()
	{
		targetNode = null;
		Vector3 startPosition = ((Component)this).transform.position;
		Vector3 groundPosition = ((Component)this).transform.position;
		ray = new Ray(((Component)this).transform.position, Vector3.down);
		if (Physics.Raycast(ray, ref rayHit, 20f, 268435712))
		{
			groundPosition = ((RaycastHit)(ref rayHit)).point;
		}
		else
		{
			Debug.LogError((object)"Centipede: I could not get a raycast to the ground after falling from the ceiling! Choosing the closest nav mesh position to self.");
			startPosition = RoundManager.Instance.GetNavMeshPosition(((Ray)(ref ray)).GetPoint(4f), default(NavMeshHit), 7f);
			if (((NetworkBehaviour)this).IsOwner && !RoundManager.Instance.GotNavMeshPositionResult)
			{
				KillEnemyOnOwnerClient(overrideDestroy: true);
			}
		}
		float fallTime = 0f;
		while (fallTime < 1f)
		{
			yield return null;
			fallTime += Time.deltaTime * 2.5f;
			((Component)this).transform.position = Vector3.Lerp(startPosition, groundPosition, fallToGroundCurve.Evaluate(fallTime));
		}
		creatureSFX.PlayOneShot(hitGroundSFX);
		float distToPlayer = Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position);
		if (distToPlayer < 13f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
		}
		serverPosition = ((Component)this).transform.position;
		if (((NetworkBehaviour)this).IsOwner)
		{
			agent.speed = 0f;
		}
		else
		{
			((Component)this).transform.eulerAngles = new Vector3(0f, ((Component)this).transform.eulerAngles.y, 0f);
		}
		clingingToCeiling = false;
		inSpecialAnimation = false;
		yield return (object)new WaitForSeconds(0.5f);
		RoundManager.PlayRandomClip(creatureSFX, shriekClips);
		if (distToPlayer < 7f)
		{
			GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.5f);
		}
		ceilingAnimationCoroutine = null;
		startedCeilingAnimationCoroutine = false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void TriggerCentipedeFallServerRpc(ulong clientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1047857261u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clientId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1047857261u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				thisNetworkObject.ChangeOwnership(clientId);
				SwitchToBehaviourClientRpc(2);
			}
		}
	}

	private IEnumerator clingToCeiling()
	{
		yield return (object)new WaitForSeconds(0.52f);
		if (currentBehaviourStateIndex != 1)
		{
			clingingToCeiling = false;
			startedCeilingAnimationCoroutine = false;
		}
		else
		{
			clingingToCeiling = true;
			ceilingAnimationCoroutine = null;
			startedCeilingAnimationCoroutine = false;
		}
	}

	private void RaycastToCeiling()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		ray = new Ray(((Component)this).transform.position, Vector3.up);
		if (Physics.Raycast(ray, ref rayHit, 20f, 256))
		{
			ceilingHidingPoint = ((Ray)(ref ray)).GetPoint(((RaycastHit)(ref rayHit)).distance - 0.8f);
			ceilingHidingPoint = RoundManager.Instance.RandomlyOffsetPosition(ceilingHidingPoint, 2.25f);
			SwitchToBehaviourStateOnLocalClient(1);
			syncedPositionInPrepForCeilingAnimation = false;
			inSpecialAnimation = true;
			((Behaviour)agent).enabled = false;
			SwitchToHidingOnCeilingServerRpc(ceilingHidingPoint);
		}
		else
		{
			offsetNodeAmount++;
			targetNode = null;
			Debug.LogError((object)"Centipede: Raycast to ceiling failed. Setting different node offset and resuming search for a hiding spot.");
		}
	}

	[ServerRpc]
	public void SwitchToHidingOnCeilingServerRpc(Vector3 ceilingPoint)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2005305321u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref ceilingPoint);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2005305321u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SwitchToHidingOnCeilingClientRpc(ceilingPoint);
		}
	}

	[ClientRpc]
	public void SwitchToHidingOnCeilingClientRpc(Vector3 ceilingPoint)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2626887057u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref ceilingPoint);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2626887057u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SwitchToBehaviourStateOnLocalClient(1);
				syncedPositionInPrepForCeilingAnimation = false;
				inSpecialAnimation = true;
				((Behaviour)agent).enabled = false;
				ceilingHidingPoint = ceilingPoint;
			}
		}
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		creatureSFX.PlayOneShot(hitCentipede);
		((MonoBehaviour)this).StartCoroutine(delayedShriek());
		if (((NetworkBehaviour)this).IsServer)
		{
			ReactBehaviourToBeingHurt();
		}
		enemyHP -= force;
		if (enemyHP <= 0 && ((NetworkBehaviour)this).IsOwner)
		{
			KillEnemyOnOwnerClient();
		}
	}

	public override void SetEnemyStunned(bool setToStunned, float setToStunTime = 1f, PlayerControllerB setStunnedByPlayer = null)
	{
		base.SetEnemyStunned(setToStunned, setToStunTime);
		if (((NetworkBehaviour)this).IsServer)
		{
			ReactBehaviourToBeingHurt();
		}
	}

	public void ReactBehaviourToBeingHurt()
	{
		switch (currentBehaviourStateIndex)
		{
		case 2:
			GetHitAndRunAwayServerRpc();
			targetNode = null;
			break;
		case 3:
			if (!inDroppingOffPlayerAnim)
			{
				inDroppingOffPlayerAnim = true;
				StopClingingServerRpc(playerDead: false);
			}
			break;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void GetHitAndRunAwayServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3824648183u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3824648183u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				GetHitAndRunAwayClientRpc();
			}
		}
	}

	[ClientRpc]
	public void GetHitAndRunAwayClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2602771441u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2602771441u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SwitchToBehaviourStateOnLocalClient(0);
				targetNode = null;
			}
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		base.KillEnemy();
		((Behaviour)agent).enabled = false;
		if ((Object)(object)clingingToPlayer != (Object)null)
		{
			UpdatePositionToClingingPlayerHead();
			StopClingingToPlayer(playerDead: false);
		}
		if (clingingToCeiling && ceilingAnimationCoroutine == null)
		{
			ceilingAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(fallFromCeiling());
		}
		modelContainer.localPosition = Vector3.zero;
	}

	private IEnumerator delayedShriek()
	{
		yield return (object)new WaitForSeconds(0.2f);
		creatureVoice.pitch = 1.7f;
		RoundManager.PlayRandomClip(creatureVoice, shriekClips, randomize: false);
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_CentipedeAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(4105250505u, new RpcReceiveHandler(__rpc_handler_4105250505));
		NetworkManager.__rpc_func_table.Add(1106241822u, new RpcReceiveHandler(__rpc_handler_1106241822));
		NetworkManager.__rpc_func_table.Add(2791977891u, new RpcReceiveHandler(__rpc_handler_2791977891));
		NetworkManager.__rpc_func_table.Add(2474017466u, new RpcReceiveHandler(__rpc_handler_2474017466));
		NetworkManager.__rpc_func_table.Add(1047857261u, new RpcReceiveHandler(__rpc_handler_1047857261));
		NetworkManager.__rpc_func_table.Add(2005305321u, new RpcReceiveHandler(__rpc_handler_2005305321));
		NetworkManager.__rpc_func_table.Add(2626887057u, new RpcReceiveHandler(__rpc_handler_2626887057));
		NetworkManager.__rpc_func_table.Add(3824648183u, new RpcReceiveHandler(__rpc_handler_3824648183));
		NetworkManager.__rpc_func_table.Add(2602771441u, new RpcReceiveHandler(__rpc_handler_2602771441));
	}

	private static void __rpc_handler_4105250505(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool playerDead = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref playerDead, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CentipedeAI)(object)target).StopClingingServerRpc(playerDead);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1106241822(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool playerDead = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref playerDead, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CentipedeAI)(object)target).StopClingingClientRpc(playerDead);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2791977891(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong playerObjectId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CentipedeAI)(object)target).ClingToPlayerServerRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2474017466(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong playerObjectId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CentipedeAI)(object)target).ClingToPlayerClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1047857261(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong clientId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CentipedeAI)(object)target).TriggerCentipedeFallServerRpc(clientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2005305321(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 ceilingPoint = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref ceilingPoint);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CentipedeAI)(object)target).SwitchToHidingOnCeilingServerRpc(ceilingPoint);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2626887057(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 ceilingPoint = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref ceilingPoint);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CentipedeAI)(object)target).SwitchToHidingOnCeilingClientRpc(ceilingPoint);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3824648183(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((CentipedeAI)(object)target).GetHitAndRunAwayServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2602771441(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((CentipedeAI)(object)target).GetHitAndRunAwayClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "CentipedeAI";
	}
}
