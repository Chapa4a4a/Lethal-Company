using System;
using System.Collections.Generic;
using System.Linq;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class MoldSpreadManager : NetworkBehaviour
{
	private bool finishedGeneratingMold;

	public PlanetMoldState[] planetMoldStates;

	public List<GameObject> generatedMold = new List<GameObject>();

	public GameObject moldPrefab;

	public Transform moldContainer;

	public int moldBranchCount = 3;

	public int maxSporesInSingleIteration = 25;

	public int maxIterations = 25;

	public int moldDistance = 9;

	private Collider[] weedColliders;

	public GameObject destroyParticle;

	public AudioSource destroyAudio;

	public int iterationsThisDay;

	private void Start()
	{
		planetMoldStates = new PlanetMoldState[StartOfRound.Instance.levels.Length];
		for (int i = 0; i < planetMoldStates.Length; i++)
		{
			planetMoldStates[i] = new PlanetMoldState();
			if (((NetworkBehaviour)this).IsServer)
			{
				planetMoldStates[i].destroyedMold = ES3.Load<int[]>($"Level{StartOfRound.Instance.levels[i].levelID}DestroyedMold", GameNetworkManager.Instance.currentSaveFileName, new int[0]).ToList();
			}
			else
			{
				planetMoldStates[i].destroyedMold = new List<int>();
			}
		}
		Debug.Log((object)$"planet mold states length: ${planetMoldStates.Length}");
		weedColliders = (Collider[])(object)new Collider[3];
	}

	public void ResetMoldData()
	{
		for (int i = 0; i < planetMoldStates.Length; i++)
		{
			planetMoldStates[i].destroyedMold.Clear();
			generatedMold.Clear();
		}
	}

	public void SyncDestroyedMoldPositions(int[] destroyedMoldSpots)
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			Debug.Log((object)$"Sync A; {destroyedMoldSpots.Length}");
			for (int i = 0; i < destroyedMoldSpots.Length; i++)
			{
				Debug.Log((object)$"Sync B{i}; {destroyedMoldSpots[i]}");
				DestroyMoldAtIndex(destroyedMoldSpots[i], 2f);
			}
		}
	}

	public void DestroyMoldAtIndex(int index, float radius = 1.5f, bool playEffect = false)
	{
		Debug.Log((object)$"C {planetMoldStates[StartOfRound.Instance.currentLevelID] != null}");
		Debug.Log((object)$"D {planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold != null}");
		if (!planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Contains(index))
		{
			planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Add(index);
		}
		if (index < generatedMold.Count)
		{
			Debug.Log((object)$"E; null? {(Object)(object)generatedMold[index] == (Object)null}");
			generatedMold[index].SetActive(false);
		}
	}

	public void DestroyMoldAtPosition(Vector3 pos, bool playEffect = false)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		int num = Physics.OverlapSphereNonAlloc(pos, 0.5f, weedColliders, 65536, (QueryTriggerInteraction)2);
		Debug.Log((object)$"weeds found at pos {pos}: {num}");
		for (int i = 0; i < num; i++)
		{
			int num2 = generatedMold.IndexOf(((Component)weedColliders[i]).gameObject);
			if (num2 != -1)
			{
				((Component)weedColliders[i]).gameObject.SetActive(false);
				if (!planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Contains(num2))
				{
					planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Add(num2);
				}
				if (playEffect)
				{
					Object.Instantiate<GameObject>(destroyParticle, ((Component)weedColliders[i]).transform.position + Vector3.up * 0.5f, Quaternion.identity, (Transform)null);
					destroyAudio.Stop();
					((Component)destroyAudio).transform.position = ((Component)weedColliders[i]).transform.position + Vector3.up * 0.5f;
					destroyAudio.Play();
					RoundManager.Instance.PlayAudibleNoise(((Component)destroyAudio).transform.position, 6f, 0.5f, 0, noiseIsInsideClosedShip: false, 99611);
				}
			}
			Debug.Log((object)$"Index: {num2}");
		}
		CheckIfAllSporesDestroyed();
	}

	private void CheckIfAllSporesDestroyed()
	{
		bool flag = true;
		for (int i = 0; i < generatedMold.Count; i++)
		{
			if (generatedMold[i].activeSelf)
			{
				flag = false;
			}
		}
		if (flag)
		{
			StartOfRound.Instance.currentLevel.moldSpreadIterations = 0;
			StartOfRound.Instance.currentLevel.moldStartPosition = -1;
		}
	}

	private Vector3 ChooseMoldSpawnPosition(Vector3 pos, int xOffset, int zOffset)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		pos += new Vector3((float)xOffset, pos.y, (float)zOffset);
		pos = RoundManager.Instance.GetNavMeshPosition(pos, default(NavMeshHit), 12f, 1);
		if (!RoundManager.Instance.GotNavMeshPositionResult)
		{
			return Vector3.zero;
		}
		return pos;
	}

	public void GenerateMold(Vector3 startingPosition, int iterations)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0521: Unknown result type (might be due to invalid IL or missing references)
		//IL_063d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_064a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0665: Unknown result type (might be due to invalid IL or missing references)
		//IL_066a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0687: Unknown result type (might be due to invalid IL or missing references)
		//IL_0691: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_0409: Unknown result type (might be due to invalid IL or missing references)
		//IL_0433: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Unknown result type (might be due to invalid IL or missing references)
		//IL_0443: Unknown result type (might be due to invalid IL or missing references)
		//IL_0448: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_046c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0477: Unknown result type (might be due to invalid IL or missing references)
		//IL_047c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0481: Unknown result type (might be due to invalid IL or missing references)
		if (iterations == 0 || finishedGeneratingMold)
		{
			return;
		}
		iterationsThisDay = iterations;
		Random random = new Random((int)startingPosition.x + (int)startingPosition.z);
		Vector3 val = startingPosition;
		RaycastHit val2 = default(RaycastHit);
		if (Physics.Raycast(startingPosition, Vector3.down, ref val2, 100f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			((Vector3)(ref val))._002Ector(Mathf.Round(((RaycastHit)(ref val2)).point.x), Mathf.Round(((RaycastHit)(ref val2)).point.y), Mathf.Round(((RaycastHit)(ref val2)).point.z));
		}
		GameObject item = Object.Instantiate<GameObject>(moldPrefab, val, Quaternion.Euler(new Vector3(0f, Random.Range(-180f, 180f), 0f)), moldContainer);
		generatedMold.Add(item);
		List<MoldSpore> list = new List<MoldSpore>();
		List<MoldSpore> list2 = new List<MoldSpore>();
		Vector3 zero = Vector3.zero;
		list.Add(new MoldSpore(val, marked: false, 0));
		int num = 0;
		bool flag = true;
		bool flag2 = false;
		iterations = Mathf.Min(iterations, maxIterations);
		List<MoldSpore> list3 = new List<MoldSpore>();
		for (int i = 0; i < iterations; i++)
		{
			GameObject val3 = GameObject.FindGameObjectWithTag("MoldAttractionPoint");
			bool flag3 = (Object)(object)val3 != (Object)null;
			int num2 = Mathf.Min(list.Count, maxSporesInSingleIteration);
			for (int j = 0; j < num2; j++)
			{
				int num3 = random.Next(1, moldBranchCount);
				for (int k = 0; k < num3; k++)
				{
					int num4;
					int num5;
					if (flag3 && Vector3.Distance(list[j].spawnPosition, val3.transform.position) > 35f && Vector3.Distance(list[j].spawnPosition, StartOfRound.Instance.elevatorTransform.position) > 35f)
					{
						num4 = ((!(list[j].spawnPosition.x < val3.transform.position.x)) ? random.Next(-moldDistance, -1) : random.Next(1, moldDistance));
						num5 = ((!(list[j].spawnPosition.z < val3.transform.position.z)) ? random.Next(-moldDistance, -1) : random.Next(1, moldDistance));
					}
					else
					{
						num4 = random.Next(-moldDistance, moldDistance);
						num5 = random.Next(-moldDistance, moldDistance);
					}
					zero = ChooseMoldSpawnPosition(xOffset: (num4 >= 0) ? Mathf.Max(num4, 4) : Mathf.Min(num4, -4), zOffset: (num5 >= 0) ? Mathf.Max(num5, 4) : Mathf.Min(num5, -4), pos: list[j].spawnPosition);
					flag2 = zero != Vector3.zero;
					bool flag4 = false;
					float num6 = (float)random.Next(75, 130) / 100f;
					num++;
					MoldSpore moldSpore = new MoldSpore(zero, flag4, num);
					bool flag5 = Physics.CheckSphere(zero, 1f, 65536, (QueryTriggerInteraction)1);
					if (!flag5 && (planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Contains(num) || (list[j].destroyedByPlayer && i + 1 == iterations)))
					{
						list3.Add(moldSpore);
						moldSpore.destroyedByPlayer = true;
					}
					else if (!flag2 || list[j].markedForDestruction || flag5)
					{
						flag4 = true;
					}
					else
					{
						item = Object.Instantiate<GameObject>(moldPrefab, zero, Quaternion.Euler(new Vector3(0f, Random.Range(-180f, 180f), 0f)), moldContainer);
						item.transform.localScale = item.transform.localScale * num6;
						flag = false;
						generatedMold.Add(item);
					}
					moldSpore.markedForDestruction = flag4;
					list2.Add(moldSpore);
					if (num == 1)
					{
						Debug.DrawRay(zero, Vector3.up * 10f, Color.yellow, 10f);
					}
					if (moldSpore.destroyedByPlayer || moldSpore.markedForDestruction)
					{
						Debug.DrawRay(list[j].spawnPosition, zero - list[j].spawnPosition, Color.red, 10f);
					}
					else
					{
						Debug.DrawRay(list[j].spawnPosition, zero - list[j].spawnPosition, Color.green, 10f);
					}
				}
			}
			if (!flag)
			{
				list = new List<MoldSpore>(list2);
				list2.Clear();
				continue;
			}
			Debug.Log((object)"No spores generated; setting iterations to 0");
			if (i == 0)
			{
				iterationsThisDay = 0;
				StartOfRound.Instance.currentLevel.moldSpreadIterations = 0;
				StartOfRound.Instance.currentLevel.moldStartPosition = -1;
			}
			break;
		}
		list.Clear();
		for (int l = 0; l < list3.Count; l++)
		{
			if (Physics.CheckSphere(list3[l].spawnPosition, 8f, 65536, (QueryTriggerInteraction)1))
			{
				if (planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Contains(list3[l].generationId))
				{
					planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Remove(list3[l].generationId);
					list.Add(list3[l]);
					Debug.Log((object)$"Growing back mold at index {list3[l].generationId}");
				}
			}
			else if (!planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Contains(list3[l].generationId))
			{
				planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Add(list3[l].generationId);
			}
		}
		for (int m = 0; m < list.Count; m++)
		{
			zero = list[m].spawnPosition;
			item = Object.Instantiate<GameObject>(moldPrefab, zero, Quaternion.Euler(new Vector3(0f, Random.Range(-180f, 180f), 0f)), moldContainer);
			item.transform.localScale = item.transform.localScale * 1f;
		}
		finishedGeneratingMold = true;
	}

	public void RemoveAllMold()
	{
		for (int i = 0; i < generatedMold.Count; i++)
		{
			if ((Object)(object)generatedMold[i] != (Object)null)
			{
				Object.Destroy((Object)(object)generatedMold[i]);
			}
		}
		generatedMold.Clear();
		finishedGeneratingMold = false;
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "MoldSpreadManager";
	}
}
