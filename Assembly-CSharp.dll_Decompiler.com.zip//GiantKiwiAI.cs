using System;
using System.Collections.Generic;
using System.Linq;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Animations.Rigging;

public class GiantKiwiAI : EnemyAI, IVisibleThreat
{
	public bool inKillAnimation;

	[Space(7f)]
	public float idlePatrolSpeed = 8f;

	public GameObject eggPrefab;

	public List<KiwiBabyItem> eggs = new List<KiwiBabyItem>();

	private bool syncedEggsPosition;

	private bool hasSpawnedEggs;

	private int idleBehaviour;

	private float behaviourTimer;

	private float idleTimer;

	private int previousBehaviour;

	public Transform[] nestEggSpawnPositions;

	private Random idleRandom;

	private int previousIdleBehaviour;

	private Collider[] treeColliders;

	public Transform peckingTree;

	private bool isPeckingTree;

	public float peckTreeDistance = 4f;

	private float miscTimer;

	private Vector3 agentLocalVelocity;

	private float velX;

	private float velZ;

	public Transform animationContainer;

	private Vector3 previousPosition;

	[Header("Animation values")]
	private bool inMovement;

	[Header("Audios")]
	public AudioClip[] footstepSFX;

	public AudioClip[] footstepBassSFX;

	public AudioClip peckTreeSFX;

	public AudioSource peckAudio;

	public AudioSource longDistanceAudio;

	public DampedTransform dampedHeadTransform;

	public ParticleSystem woodChipParticle;

	[Header("Sight")]
	public Transform lookTarget;

	public Transform headLookTarget;

	public Transform eyesLookTarget;

	public MultiAimConstraint headLookRig;

	public MultiAimConstraint eyesLookRigA;

	public MultiAimConstraint eyesLookRigB;

	private float pingAttentionTimer;

	private int focusLevel;

	private Vector3 pingAttentionPosition;

	private float timeSincePingingAttention;

	private float timeAtLastHeardNoise;

	public Collider ownCollider;

	private int visibleThreatsMask = 524296;

	private int lookMask = 1073744129;

	private IVisibleThreat seenThreat;

	private IVisibleThreat watchingThreat;

	public Transform watchingThreatTransform;

	public Transform turnCompass;

	public Transform leftEyeMesh;

	public Transform rightEyeMesh;

	public Transform neck2;

	private float eyeTwitchInterval;

	private float turnHeadInterval;

	private float turnHeadOffset;

	public float eyeTwitchAmount;

	private Vector3 baseEyeRotation;

	private Vector3 baseEyeRotationLeft;

	[Header("Nest behaviour")]
	public float protectNestRadius = 7f;

	private List<KiwiBabyItem> LostEggs = new List<KiwiBabyItem>(3);

	private List<KiwiBabyItem> LostEggsFound = new List<KiwiBabyItem>(3);

	private KiwiBabyItem patrollingEgg;

	private KiwiBabyItem takeEggBackToNest;

	private float eggDist;

	public bool carryingEgg;

	public Transform grabTarget;

	private List<Transform> seenThreatsHoldingEgg = new List<Transform>();

	private IVisibleThreat attackingThreat;

	private bool attackingLastFrame;

	private bool attacking;

	public GameObject birdNest;

	public GameObject birdNestPrefab;

	public string defenseBehaviour;

	private float timeSinceSeeingThreat;

	private float checkLOSDistance;

	private Vector3 lastSeenPositionOfWatchedThreat;

	private bool checkingLastSeenPosition;

	private bool patrollingInAttackMode;

	public AudioClip[] attackSFX;

	public float hitVelocityForce = 3f;

	private float timeSinceHittingPlayer;

	public ParticleSystem rocksParticle;

	public ParticleSystem runningParticle;

	private float walkAnimSpeed = 1f;

	public AudioClip[] screamSFX;

	public AudioClip squawkSFX;

	private bool wasPatrollingEgg;

	private bool wasOwnerLastFrame;

	public AISearchRoutine searchForLostEgg;

	public GameObject playerExplodePrefab;

	private float timeSinceHittingGround;

	private int destroyTreesInterval;

	private Random birdRandom;

	private float attackSpeedMultiplier;

	public float chaseAccelerationMultiplier;

	private float longChaseBonusSpeed;

	public GameObject feathersPrefab;

	public AudioClip wakeUpSFX;

	public EnemyType baboonHawkType;

	public bool pryingOpenDoor;

	public HangarShipDoor shipDoor;

	private float pryingDoorAnimTime;

	public float pryOpenDoorAnimLength;

	public AudioClip breakAndEnter;

	public AudioClip shipAlarm;

	public AudioSource breakDownDoorAudio;

	private AudioSource birdNestAmbience;

	private bool wasLookingForEggs;

	private PlayerControllerB lastPlayerWhoAttacked;

	private float timeSinceGettingHit;

	private NavMeshHit navHitB;

	private float sampleNavAreaInterval;

	public PlayerControllerB abandonedThreat;

	private float timeSpentChasingThreat;

	private float timeSinceExitingAttackMode;

	private bool triedRandomDance;

	private bool targetPlayerIsInTruck;

	private float timeSinceHittingEnemy;

	ThreatType IVisibleThreat.type => ThreatType.GiantKiwi;

	int IVisibleThreat.GetThreatLevel(Vector3 seenByPosition)
	{
		if (currentBehaviourStateIndex == 2)
		{
			return 18;
		}
		return 10;
	}

	int IVisibleThreat.GetInterestLevel()
	{
		return 0;
	}

	Transform IVisibleThreat.GetThreatLookTransform()
	{
		return eye;
	}

	Transform IVisibleThreat.GetThreatTransform()
	{
		return ((Component)this).transform;
	}

	Vector3 IVisibleThreat.GetThreatVelocity()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			return agent.velocity;
		}
		return agentLocalVelocity;
	}

	float IVisibleThreat.GetVisibility()
	{
		if (creatureAnimator.GetBool("Asleep"))
		{
			return 0.4f;
		}
		return 0.77f;
	}

	int IVisibleThreat.SendSpecialBehaviour(int id)
	{
		return 0;
	}

	GrabbableObject IVisibleThreat.GetHeldObject()
	{
		if (carryingEgg)
		{
			return takeEggBackToNest;
		}
		return null;
	}

	bool IVisibleThreat.IsThreatDead()
	{
		return isEnemyDead;
	}

	public override void Start()
	{
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		treeColliders = (Collider[])(object)new Collider[10];
		if (StartOfRound.Instance.inShipPhase)
		{
			Debug.Log((object)"Giant kiwi has detected the game is in test mode.");
			if ((Object)(object)birdNest == (Object)null)
			{
				birdNest = ((Component)Object.FindObjectOfType<EnemyAINestSpawnObject>()).gameObject;
				((Behaviour)agent).enabled = false;
				((Component)this).transform.position = birdNest.transform.position;
				((Component)this).transform.rotation = birdNest.transform.rotation;
				((Behaviour)agent).enabled = true;
			}
		}
		if (((NetworkBehaviour)this).IsServer)
		{
			if (!StartOfRound.Instance.inShipPhase)
			{
				SpawnBirdNest();
			}
			SpawnNestEggs();
			syncedEggsPosition = true;
		}
		birdRandom = new Random(StartOfRound.Instance.randomMapSeed + 33);
		idleTimer = 15f;
		baseEyeRotationLeft = leftEyeMesh.localEulerAngles;
		baseEyeRotation = rightEyeMesh.localEulerAngles;
		shipDoor = Object.FindObjectOfType<HangarShipDoor>();
	}

	private Vector3 GetRandomPositionAroundObject(Vector3 objectPos, float radius = 16f, Random seed = null)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		return RoundManager.Instance.GetRandomNavMeshPositionInBoxPredictable(objectPos, radius, default(NavMeshHit), seed, -1, 0.5f);
	}

	[ServerRpc(RequireOwnership = false)]
	public void PeckTreeServerRpc(bool isPecking)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1509496551u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isPecking, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1509496551u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PeckTreeClientRpc(isPecking);
			}
		}
	}

	[ClientRpc]
	public void PeckTreeClientRpc(bool isPecking)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2329433375u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isPecking, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2329433375u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				isPeckingTree = isPecking;
				creatureAnimator.SetBool("peckTree", isPecking);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetSleepingServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(538806819u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 538806819u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetSleepingClientRpc();
			}
		}
	}

	[ClientRpc]
	public void SetSleepingClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1965629606u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1965629606u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				creatureSFX.Play();
				creatureAnimator.SetBool("Asleep", true);
			}
		}
	}

	public override void OnDrawGizmos()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		base.OnDrawGizmos();
		if (!((Object)(object)HUDManager.Instance == (Object)null) && debugEnemyAI)
		{
			Gizmos.DrawWireSphere(eye.position + eye.forward * 38f + eye.up * 8f, 40f);
		}
	}

	private void LookAtTargetInterest()
	{
	}

	private bool CheckLOSForCreatures(Vector3 protectingPosition, bool protectAllEggs = false, bool mustHavePath = false)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_061c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0621: Unknown result type (might be due to invalid IL or missing references)
		//IL_0659: Unknown result type (might be due to invalid IL or missing references)
		//IL_067f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0684: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_058d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0592: Unknown result type (might be due to invalid IL or missing references)
		//IL_0584: Unknown result type (might be due to invalid IL or missing references)
		//IL_0589: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		//IL_037d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0382: Unknown result type (might be due to invalid IL or missing references)
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_043c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		int num = Physics.OverlapSphereNonAlloc(eye.position + eye.up * 8f, 40f, RoundManager.Instance.tempColliderResults, visibleThreatsMask, (QueryTriggerInteraction)2);
		IVisibleThreat visibleThreat = watchingThreat;
		checkLOSDistance = 1000f;
		IVisibleThreat visibleThreat2 = null;
		IVisibleThreat visibleThreat3 = null;
		float num2 = 1000f;
		int num3 = -1;
		RaycastHit val = default(RaycastHit);
		RaycastHit val3 = default(RaycastHit);
		for (int i = 0; i < num; i++)
		{
			if ((Object)(object)RoundManager.Instance.tempColliderResults[i] == (Object)(object)ownCollider)
			{
				continue;
			}
			float num4 = Vector3.Distance(eye.position, ((Component)RoundManager.Instance.tempColliderResults[i]).transform.position);
			Vector3.Angle(((Component)RoundManager.Instance.tempColliderResults[i]).transform.position - eye.position, eye.forward);
			if (!((Component)((Component)RoundManager.Instance.tempColliderResults[i]).transform).TryGetComponent<IVisibleThreat>(ref seenThreat))
			{
				continue;
			}
			bool flag = false;
			PlayerControllerB playerControllerB = null;
			if (seenThreat.type == ThreatType.Player)
			{
				playerControllerB = ((Component)seenThreat.GetThreatTransform()).GetComponent<PlayerControllerB>();
				if ((Object)(object)abandonedThreat != (Object)null && (Object)(object)playerControllerB == (Object)(object)abandonedThreat)
				{
					continue;
				}
				flag = playerControllerB.isInHangarShipRoom && isInsidePlayerShip;
			}
			if (!flag && Physics.Linecast(eye.position, seenThreat.GetThreatLookTransform().position, ref val, 33556737, (QueryTriggerInteraction)1))
			{
				if (!debugEnemyAI)
				{
				}
				continue;
			}
			EnemyAI component = ((Component)seenThreat.GetThreatTransform()).GetComponent<EnemyAI>();
			if ((Object)(object)component != (Object)null && (component.isEnemyDead || seenThreat.type == ThreatType.Bees || seenThreat.type == ThreatType.ForestGiant || (seenThreat.type == ThreatType.EyelessDog && num4 > 6f) || num4 > 16f))
			{
				continue;
			}
			float visibility = seenThreat.GetVisibility();
			if (visibility < 1f)
			{
				if (visibility == 0f)
				{
					continue;
				}
				if (visibility < 0.2f && num4 > 10f)
				{
					if (currentBehaviourStateIndex != 2 || timeSinceSeeingThreat > 0.25f)
					{
						continue;
					}
				}
				else if (visibility < 0.6f && num4 > 20f)
				{
					if (currentBehaviourStateIndex != 2 || timeSinceSeeingThreat > 0.5f)
					{
						continue;
					}
				}
				else if (visibility < 0.8f && num4 > 24f)
				{
					continue;
				}
			}
			if (debugEnemyAI)
			{
				Debug.Log((object)$"Bird: Seeing visible threat: {((Object)((Component)RoundManager.Instance.tempColliderResults[i]).transform).name}; type: {seenThreat.type}");
			}
			Transform threatTransform = seenThreat.GetThreatTransform();
			if (mustHavePath && !flag)
			{
				bool flag2 = false;
				if (i > 10 && (Object)(object)playerControllerB == (Object)null)
				{
					if (num4 > 12f)
					{
						continue;
					}
					if (num4 < 8f)
					{
						flag2 = true;
					}
				}
				if (num4 < 1f)
				{
					flag2 = true;
				}
				if (!flag2)
				{
					Vector3 val2 = threatTransform.position;
					if (Physics.Raycast(threatTransform.position + Vector3.up * 0.25f, Vector3.down, ref val3, 10f, 33556737, (QueryTriggerInteraction)1))
					{
						val2 = ((RaycastHit)(ref val3)).point;
						Debug.DrawRay(threatTransform.position + Vector3.up * 0.25f, Vector3.down * ((RaycastHit)(ref val3)).distance, Color.blue, AIIntervalTime);
					}
					if (num4 < 30f && (Object)(object)playerControllerB != (Object)null && (Object)(object)playerControllerB != (Object)null && playerControllerB.isInHangarShipRoom)
					{
						val2 = StartOfRound.Instance.shipStrictInnerRoomBounds.ClosestPoint(val2);
					}
					float sampleRadius = 2f;
					int areaMask = -1;
					VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
					if ((Object)(object)vehicleController != (Object)null && Vector3.Distance(threatTransform.position, ((Component)vehicleController).transform.position) < 20f)
					{
						sampleRadius = 6f;
						areaMask = -33;
					}
					if (PathIsIntersectedByLineOfSight(RoundManager.Instance.GetNavMeshPosition(threatTransform.position, navHitB, sampleRadius, areaMask), calculatePathDistance: true, avoidLineOfSight: false) || pathDistance - num4 > 20f)
					{
						continue;
					}
				}
			}
			bool flag3 = seenThreatsHoldingEgg.Contains(threatTransform);
			if (!flag3)
			{
				for (int j = 0; j < eggs.Count; j++)
				{
					if ((Object)(object)playerControllerB != (Object)null && eggs[j].isInShipRoom && playerControllerB.isInHangarShipRoom)
					{
						seenThreatsHoldingEgg.Add(threatTransform);
						num3 = (int)((Component)seenThreat.GetThreatTransform()).GetComponent<PlayerControllerB>().playerClientId;
						flag3 = true;
						break;
					}
					if (Vector3.Distance(((Component)eggs[j]).transform.position, threatTransform.position) < 3f)
					{
						seenThreatsHoldingEgg.Add(threatTransform);
						if (seenThreat.type == ThreatType.Player)
						{
							num3 = (int)((Component)seenThreat.GetThreatTransform()).GetComponent<PlayerControllerB>().playerClientId;
						}
						flag3 = true;
						break;
					}
				}
			}
			int num5 = 1;
			if (protectAllEggs)
			{
				num5 = eggs.Count;
			}
			for (int k = 0; k < num5; k++)
			{
				if (protectAllEggs)
				{
					protectingPosition = ((Component)eggs[k]).transform.position;
				}
				num4 = Vector3.Distance(threatTransform.position, protectingPosition);
				if (flag3 && num4 < num2)
				{
					num2 = num4;
					visibleThreat3 = seenThreat;
				}
				if (num4 < checkLOSDistance)
				{
					checkLOSDistance = num4;
					visibleThreat2 = seenThreat;
				}
			}
		}
		if (num2 < 20f && visibleThreat3 != null)
		{
			checkLOSDistance = num2;
			visibleThreat2 = visibleThreat3;
		}
		if (num3 != -1)
		{
			AddToThreatsHoldingEggListServerRpc(num3);
		}
		if (visibleThreat2 != null)
		{
			if (watchingThreat == null || Vector3.Distance(watchingThreat.GetThreatTransform().position, protectingPosition) - checkLOSDistance > 4f)
			{
				watchingThreat = visibleThreat2;
				if (visibleThreat == null || watchingThreat != visibleThreat)
				{
					SyncWatchingThreatServerRpc(NetworkObjectReference.op_Implicit(((Component)watchingThreat.GetThreatTransform()).GetComponent<NetworkObject>()), (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
				}
			}
			lastSeenPositionOfWatchedThreat = watchingThreat.GetThreatTransform().position;
			return true;
		}
		return false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void AddToThreatsHoldingEggListServerRpc(int idOfPlayerAdded)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2757245750u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, idOfPlayerAdded);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2757245750u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				AddToThreatsHoldingEggListClientRpc(idOfPlayerAdded);
			}
		}
	}

	[ClientRpc]
	public void AddToThreatsHoldingEggListClientRpc(int idOfPlayerAdded)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(321322077u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, idOfPlayerAdded);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 321322077u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !seenThreatsHoldingEgg.Contains(((Component)StartOfRound.Instance.allPlayerScripts[idOfPlayerAdded]).transform))
			{
				seenThreatsHoldingEgg.Add(((Component)StartOfRound.Instance.allPlayerScripts[idOfPlayerAdded]).transform);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncWatchingThreatServerRpc(NetworkObjectReference seenThreatNetworkObject, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2000046764u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref seenThreatNetworkObject, default(ForNetworkSerializable));
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2000046764u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SyncWatchingThreatClientRpc(seenThreatNetworkObject, playerWhoSent);
			}
		}
	}

	[ClientRpc]
	public void SyncWatchingThreatClientRpc(NetworkObjectReference seenThreatNetworkObject, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4160656602u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref seenThreatNetworkObject, default(ForNetworkSerializable));
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4160656602u, val, (RpcDelivery)0);
			}
			NetworkObject val3 = default(NetworkObject);
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerWhoSent != (int)GameNetworkManager.Instance.localPlayerController.playerClientId && ((NetworkObjectReference)(ref seenThreatNetworkObject)).TryGet(ref val3, (NetworkManager)null) && !((Component)val3).TryGetComponent<IVisibleThreat>(ref watchingThreat))
			{
				Debug.LogWarning((object)"Threat seen by bird synced across server did not have IVisibleThreat interface?");
			}
		}
	}

	private KiwiBabyItem GetClosestLostEgg(bool foundEggs = false, KiwiBabyItem excludeEgg = null, bool checkPath = false, bool allEggs = false)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		float num = 2000f;
		int num2 = -1;
		if (allEggs)
		{
			for (int i = 0; i < eggs.Count; i++)
			{
				if (!eggs[i].deactivated && !eggs[i].isInFactory)
				{
					float num3 = Vector3.Distance(((Component)this).transform.position, ((Component)eggs[i]).transform.position);
					if (num3 < num)
					{
						num = num3;
						num2 = i;
					}
				}
			}
			if (num2 == -1)
			{
				return null;
			}
			return eggs[num2];
		}
		if (foundEggs)
		{
			for (int j = 0; j < LostEggsFound.Count; j++)
			{
				if (!LostEggsFound[j].isInFactory && !LostEggsFound[j].deactivated && (!((Object)(object)excludeEgg != (Object)null) || !((Object)(object)LostEggsFound[j] == (Object)(object)excludeEgg)))
				{
					float num3 = Vector3.Distance(((Component)this).transform.position, ((Component)LostEggsFound[j]).transform.position);
					if ((!checkPath || (agent.isOnNavMesh && agent.CalculatePath(((Component)LostEggsFound[j]).transform.position, path1) && !(Vector3.Distance(path1.corners[path1.corners.Length - 1], ((Component)LostEggsFound[j]).transform.position) > 3f))) && num3 < num)
					{
						num = num3;
						num2 = j;
					}
				}
			}
			eggDist = num;
			if (num2 == -1)
			{
				return null;
			}
			return LostEggsFound[num2];
		}
		for (int k = 0; k < LostEggs.Count; k++)
		{
			if (!LostEggs[k].isInFactory && (LostEggs[k].screaming || LostEggs[k].hasScreamed) && !LostEggs[k].deactivated && (!((Object)(object)excludeEgg != (Object)null) || !((Object)(object)LostEggs[k] == (Object)(object)excludeEgg)))
			{
				float num3 = Vector3.Distance(((Component)this).transform.position, ((Component)LostEggs[k]).transform.position);
				if (num3 < num)
				{
					num = num3;
					num2 = k;
				}
			}
		}
		eggDist = num;
		if (num2 == -1)
		{
			return null;
		}
		return LostEggs[num2];
	}

	private void PickUpEgg(KiwiBabyItem egg)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)takeEggBackToNest != (Object)null && carryingEgg)
		{
			Debug.LogError((object)"Bird Error: GrabItemAndSync called when baboon is already carrying scrap!");
		}
		NetworkObject component = ((Component)egg).GetComponent<NetworkObject>();
		GrabScrap(component);
		GrabScrapServerRpc(NetworkObjectReference.op_Implicit(component), (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
	}

	[ServerRpc]
	public void GrabScrapServerRpc(NetworkObjectReference item, int clientWhoSentRPC)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2370506911u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref item, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, clientWhoSentRPC);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2370506911u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			NetworkObject val3 = default(NetworkObject);
			if (!((NetworkObjectReference)(ref item)).TryGet(ref val3, (NetworkManager)null))
			{
				Debug.LogError((object)$"Baboon #{thisEnemyIndex} error: Could not get grabbed network object from reference on server");
			}
			else if (Object.op_Implicit((Object)(object)((Component)val3).GetComponent<GrabbableObject>()) && !((Component)val3).GetComponent<GrabbableObject>().heldByPlayerOnServer)
			{
				GrabScrapClientRpc(item, clientWhoSentRPC);
			}
		}
	}

	[ClientRpc]
	public void GrabScrapClientRpc(NetworkObjectReference item, int clientWhoSentRPC)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3612179633u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref item, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, clientWhoSentRPC);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3612179633u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && clientWhoSentRPC != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
		{
			NetworkObject item2 = default(NetworkObject);
			if (((NetworkObjectReference)(ref item)).TryGet(ref item2, (NetworkManager)null))
			{
				GrabScrap(item2);
			}
			else
			{
				Debug.LogError((object)$"Baboon #{thisEnemyIndex}; Error, was not able to get id from grabbed item client rpc");
			}
		}
	}

	private void GrabScrap(NetworkObject item)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)takeEggBackToNest != (Object)null && carryingEgg)
		{
			DropScrap(takeEggBackToNest.GetItemFloorPosition());
		}
		KiwiBabyItem component = ((Component)item).gameObject.GetComponent<KiwiBabyItem>();
		carryingEgg = true;
		takeEggBackToNest = component;
		component.parentObject = grabTarget;
		component.hasHitGround = false;
		component.GrabItemFromEnemy(this);
		component.isHeldByEnemy = true;
		component.EnablePhysics(enable: false);
	}

	private void DropEgg(bool dropInNest = false)
	{
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)takeEggBackToNest == (Object)null || !carryingEgg)
		{
			Debug.LogError((object)"Bird Error: DropItemAndSync called when baboon has no scrap!");
		}
		NetworkObject networkObject = ((NetworkBehaviour)takeEggBackToNest).NetworkObject;
		if (!networkObject.IsSpawned)
		{
			Debug.LogError((object)"Bird Error: Bird egg not spawned for clients");
			return;
		}
		Vector3 targetFloorPosition;
		if (dropInNest)
		{
			int num = -1;
			for (int i = 0; i < eggs.Count; i++)
			{
				if ((Object)(object)takeEggBackToNest == (Object)(object)eggs[i])
				{
					num = i;
					break;
				}
			}
			targetFloorPosition = birdNest.GetComponent<EnemyAINestSpawnObject>().nestPositions[num].position;
		}
		else
		{
			targetFloorPosition = takeEggBackToNest.GetItemFloorPosition();
		}
		DropScrap(targetFloorPosition, dropInNest);
		DropScrapServerRpc(NetworkObjectReference.op_Implicit(networkObject), targetFloorPosition, dropInNest, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
	}

	[ServerRpc(RequireOwnership = false)]
	public void DropScrapServerRpc(NetworkObjectReference item, Vector3 targetFloorPosition, bool droppedInNest, int clientWhoSentRPC)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3671496547u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref item, default(ForNetworkSerializable));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetFloorPosition);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref droppedInNest, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, clientWhoSentRPC);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3671496547u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DropScrapClientRpc(item, targetFloorPosition, droppedInNest, clientWhoSentRPC);
			}
		}
	}

	[ClientRpc]
	public void DropScrapClientRpc(NetworkObjectReference item, Vector3 targetFloorPosition, bool droppedInNest, int clientWhoSentRPC)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1775051963u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref item, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref targetFloorPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref droppedInNest, default(ForPrimitives));
			BytePacker.WriteValueBitPacked(val2, clientWhoSentRPC);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1775051963u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && clientWhoSentRPC != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
		{
			NetworkObject val3 = default(NetworkObject);
			if (((NetworkObjectReference)(ref item)).TryGet(ref val3, (NetworkManager)null))
			{
				DropScrap(targetFloorPosition);
			}
			else
			{
				Debug.LogError((object)"Bird: Error, was not able to get network object from dropped item client rpc");
			}
		}
	}

	private void DropScrap(Vector3 targetFloorPosition, bool droppedInNest = false)
	{
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)takeEggBackToNest == (Object)null)
		{
			Debug.LogError((object)"Bird: my held item is null when attempting to drop it!!");
			return;
		}
		if (takeEggBackToNest.isHeld)
		{
			takeEggBackToNest.DiscardItemFromEnemy();
			takeEggBackToNest.isHeldByEnemy = false;
			takeEggBackToNest = null;
			return;
		}
		takeEggBackToNest.parentObject = null;
		((Component)takeEggBackToNest).transform.SetParent(StartOfRound.Instance.propsContainer, true);
		takeEggBackToNest.EnablePhysics(enable: true);
		takeEggBackToNest.fallTime = 0f;
		takeEggBackToNest.startFallingPosition = ((Component)takeEggBackToNest).transform.parent.InverseTransformPoint(((Component)takeEggBackToNest).transform.position);
		takeEggBackToNest.targetFloorPosition = ((Component)takeEggBackToNest).transform.parent.InverseTransformPoint(targetFloorPosition);
		takeEggBackToNest.floorYRot = -1;
		takeEggBackToNest.DiscardItemFromEnemy();
		takeEggBackToNest.isHeldByEnemy = false;
		if (droppedInNest)
		{
			if (LostEggsFound.Contains(takeEggBackToNest))
			{
				LostEggsFound.Remove(takeEggBackToNest);
			}
			if (LostEggs.Contains(takeEggBackToNest))
			{
				LostEggs.Remove(takeEggBackToNest);
			}
		}
		carryingEgg = false;
		takeEggBackToNest = null;
	}

	private bool AttackIfThreatened(bool onlyWhenAwake, Vector3 protectPosition, float aggroDistance = 10f, bool forget = false)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		if (onlyWhenAwake && currentBehaviourStateIndex == 0 && ((idleBehaviour == 2 && creatureAnimator.GetBool("Asleep") && miscTimer < 0.4f) || (idleBehaviour == 0 && miscTimer > 0.5f)))
		{
			return false;
		}
		if (CheckLOSForCreatures(protectPosition, protectAllEggs: false, mustHavePath: true))
		{
			float num = Vector3.Distance(watchingThreat.GetThreatTransform().position, protectPosition);
			bool flag = false;
			VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
			if ((Object)(object)vehicleController != (Object)null && Vector3.Distance(((Component)vehicleController).transform.position, protectPosition) < 20f)
			{
				flag = true;
			}
			if (flag || num < aggroDistance || seenThreatsHoldingEgg.Contains(watchingThreat.GetThreatTransform()))
			{
				if (num < 2f && !seenThreatsHoldingEgg.Contains(watchingThreat.GetThreatTransform()))
				{
					seenThreatsHoldingEgg.Add(watchingThreat.GetThreatTransform());
				}
				return true;
			}
			if (forget)
			{
				if (num < 22f)
				{
					timeSinceSeeingThreat = 0f;
				}
				else
				{
					timeSinceSeeingThreat += AIIntervalTime;
				}
			}
		}
		else if (forget)
		{
			timeSinceSeeingThreat += AIIntervalTime;
		}
		return false;
	}

	private void CarryEggBackToNest()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		_ = miscTimer;
		_ = 0f;
		SetDestinationToPosition(birdNest.transform.position);
		if (Vector3.Distance(((Component)this).transform.position, birdNest.transform.position) < 3f)
		{
			DropEgg(dropInNest: true);
		}
	}

	private void PatrolAroundEgg()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		if (!patrollingEgg.screaming)
		{
			behaviourTimer -= AIIntervalTime;
		}
		else
		{
			SetDestinationToPosition(((Component)patrollingEgg).transform.position);
			if (Vector3.Distance(((Component)this).transform.position, ((Component)patrollingEgg).transform.position) < 14f)
			{
				behaviourTimer -= AIIntervalTime * 0.65f;
			}
		}
		if (behaviourTimer < 0f)
		{
			if (LostEggs.Contains(patrollingEgg))
			{
				LostEggs.Remove(patrollingEgg);
			}
			if (!LostEggsFound.Contains(patrollingEgg))
			{
				LostEggsFound.Add(patrollingEgg);
			}
			patrollingEgg = null;
			miscTimer = 0f;
		}
		else if (miscTimer < 0f)
		{
			miscTimer = 1.5f;
			wasPatrollingEgg = true;
			Vector3 val = GetRandomPositionAroundObject(((Component)patrollingEgg).transform.position, 12f, idleRandom);
			if (PathIsIntersectedByLineOfSight(val, calculatePathDistance: true, avoidLineOfSight: false) || pathDistance > 35f)
			{
				val = birdNest.transform.position;
			}
			SetDestinationToPosition(val);
		}
	}

	private void AbandonLostEgg(KiwiBabyItem egg)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (LostEggs.Contains(egg))
		{
			egg.timeLastAbandoned = Time.realtimeSinceStartup;
			egg.positionWhenLastAbandoned = ((Component)egg).transform.position;
			LostEggs.Remove(egg);
			if (LostEggsFound.Contains(egg))
			{
				LostEggsFound.Remove(egg);
			}
		}
	}

	private bool TryAbandonEgg(KiwiBabyItem egg, bool gotPath, Vector3 actualEggPosition)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (!gotPath || (Vector3.Distance(((Component)this).transform.position, destination) < 16f && Vector3.Distance(destination, actualEggPosition) >= 3f))
		{
			if (!(eggDist > 20f))
			{
				AbandonLostEgg(egg);
				return true;
			}
			if (behaviourTimer < 0f)
			{
				behaviourTimer = 3f;
				AbandonLostEgg(egg);
				return true;
			}
		}
		return false;
	}

	private Vector3 GetActualEggPosition(KiwiBabyItem closestEgg)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((Component)closestEgg).transform.position;
		if (IsEggInsideClosedTruck(closestEgg))
		{
			RaycastHit val2 = default(RaycastHit);
			if (Physics.Raycast(((Component)closestEgg).transform.position + Vector3.up * 0.5f, Vector3.down, ref val2, 25f, 33556737, (QueryTriggerInteraction)1))
			{
				val = RoundManager.Instance.GetNavMeshPosition(((RaycastHit)(ref val2)).point, navHitB, 10f, -33);
			}
		}
		else if (closestEgg.isHeld && (Object)(object)closestEgg.playerHeldBy != (Object)null)
		{
			RaycastHit val3 = default(RaycastHit);
			val = ((!Physics.Raycast(((Component)closestEgg.playerHeldBy).transform.position + Vector3.up * 0.5f, Vector3.down, ref val3, 25f, 33556737, (QueryTriggerInteraction)1)) ? ((Component)closestEgg.playerHeldBy).transform.position : ((RaycastHit)(ref val3)).point);
		}
		else if (closestEgg.isHeldByEnemy)
		{
			for (int i = 0; i < RoundManager.Instance.SpawnedEnemies.Count; i++)
			{
				if (RoundManager.Instance.SpawnedEnemies[i].enemyType.isOutsideEnemy && !RoundManager.Instance.SpawnedEnemies[i].enemyType.isDaytimeEnemy && (Object)(object)RoundManager.Instance.SpawnedEnemies[i].enemyType == (Object)(object)baboonHawkType)
				{
					val = ((Component)RoundManager.Instance.SpawnedEnemies[i]).transform.position;
				}
			}
		}
		if (closestEgg.isInShipRoom || ((Object)(object)closestEgg.playerHeldBy != (Object)null && closestEgg.playerHeldBy.isInHangarShipRoom))
		{
			val = StartOfRound.Instance.shipStrictInnerRoomBounds.ClosestPoint(val);
			val.y = StartOfRound.Instance.playerSpawnPositions[0].position.y;
		}
		return val;
	}

	private void BeginPryOpenDoor()
	{
		StartPryOpenDoorAnimationOnLocalClient();
		PryOpenDoorServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
	}

	private void FinishPryOpenDoor(bool cancelledEarly)
	{
		FinishPryOpenDoorAnimationOnLocalClient(cancelledEarly);
		PryOpenDoorServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId, finishAnim: true, cancelledEarly);
	}

	[ServerRpc(RequireOwnership = false)]
	public void PryOpenDoorServerRpc(int playerWhoSent, bool finishAnim = false, bool cancelledEarly = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4019607224u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref finishAnim, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref cancelledEarly, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4019607224u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PryOpenDoorClientRpc(playerWhoSent, finishAnim, cancelledEarly);
			}
		}
	}

	[ClientRpc]
	public void PryOpenDoorClientRpc(int playerWhoSent, bool finishAnim = false, bool cancelledEarly = false)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2152766841u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerWhoSent);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref finishAnim, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref cancelledEarly, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2152766841u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerWhoSent)
		{
			if (!finishAnim)
			{
				StartPryOpenDoorAnimationOnLocalClient();
			}
			else
			{
				FinishPryOpenDoorAnimationOnLocalClient(cancelledEarly);
			}
		}
	}

	private void FinishPryOpenDoorAnimationOnLocalClient(bool cancelledEarly = false)
	{
		if (!cancelledEarly)
		{
			shipDoor.shipDoorsAnimator.SetBool("Closed", false);
			StartOfRound.Instance.SetShipDoorsClosed(closed: false);
			StartOfRound.Instance.SetShipDoorsOverheatLocalClient();
			shipDoor.doorPower = 0f;
		}
		pryingOpenDoor = false;
		inSpecialAnimation = false;
		creatureAnimator.SetBool("PryingOpenDoor", false);
		shipDoor.shipDoorsAnimator.SetBool("PryingOpenDoor", false);
		creatureAnimator.SetLayerWeight(1, 1f);
	}

	private void StartPryOpenDoorAnimationOnLocalClient()
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		((Behaviour)agent).enabled = false;
		pryingOpenDoor = true;
		inSpecialAnimation = true;
		creatureAnimator.SetBool("PryingOpenDoor", true);
		shipDoor.shipDoorsAnimator.SetBool("PryingOpenDoor", true);
		shipDoor.shipDoorsAnimator.SetFloat("pryOpenDoor", 0f);
		breakDownDoorAudio.PlayOneShot(breakAndEnter);
		WalkieTalkie.TransmitOneShotAudio(breakDownDoorAudio, breakAndEnter);
		RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 15f, 0.9f);
		StartOfRound.Instance.speakerAudioSource.PlayOneShot(shipAlarm);
		WalkieTalkie.TransmitOneShotAudio(StartOfRound.Instance.speakerAudioSource, shipAlarm);
		if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position) < 18f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.VeryStrong);
		}
	}

	public bool BreakIntoShip()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)shipDoor == (Object)null)
		{
			Debug.LogError((object)"Bird error: ship door is null");
			return false;
		}
		if (pryingOpenDoor)
		{
			if (pryingDoorAnimTime >= 1f)
			{
				FinishPryOpenDoor(cancelledEarly: false);
			}
			return true;
		}
		if (StartOfRound.Instance.hangarDoorsClosed)
		{
			Bounds bounds = StartOfRound.Instance.shipStrictInnerRoomBounds.bounds;
			if (((Bounds)(ref bounds)).Contains(destination) && Vector3.Distance(((Component)this).transform.position, shipDoor.outsideDoorPoint.position) < 4f)
			{
				BeginPryOpenDoor();
				return true;
			}
		}
		return false;
	}

	private bool IsEggInsideClosedTruck(KiwiBabyItem egg, bool closedTruck = false)
	{
		VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
		if ((Object)(object)vehicleController == (Object)null)
		{
			return false;
		}
		if ((Object)(object)egg.parentObject == (Object)(object)((Component)vehicleController.physicsRegion.parentNetworkObject).transform)
		{
			if (closedTruck)
			{
				return !vehicleController.backDoorOpen;
			}
			return true;
		}
		return false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetDancingServerRpc(bool setDance)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1803512774u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setDance, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1803512774u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetDancingClientRpc(setDance);
			}
		}
	}

	[ClientRpc]
	public void SetDancingClientRpc(bool setDance)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(712000225u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setDance, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 712000225u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				creatureAnimator.SetBool("Dancing", setDance);
			}
		}
	}

	private bool HasLOSToEgg(KiwiBabyItem egg)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (Physics.Linecast(((Component)egg).transform.position + Vector3.up * 1.6f, ((Component)this).transform.position + Vector3.up * 1.6f, 256, (QueryTriggerInteraction)1))
		{
			if (isInsidePlayerShip)
			{
				return egg.isInShipRoom;
			}
			return false;
		}
		return true;
	}

	public bool PreoccupiedWithDefensePriorities()
	{
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_045d: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_051a: Unknown result type (might be due to invalid IL or missing references)
		//IL_051f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0571: Unknown result type (might be due to invalid IL or missing references)
		//IL_0580: Unknown result type (might be due to invalid IL or missing references)
		//IL_0540: Unknown result type (might be due to invalid IL or missing references)
		//IL_0545: Unknown result type (might be due to invalid IL or missing references)
		//IL_054a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		agent.stoppingDistance = 1f;
		if (carryingEgg && (Object)(object)takeEggBackToNest != (Object)null)
		{
			behaviourTimer = 3f;
			if (searchForLostEgg.inProgress)
			{
				StopSearch(searchForLostEgg);
			}
			if (AttackIfThreatened(onlyWhenAwake: false, ((Component)this).transform.position, 8f))
			{
				StartAttackingAndSync();
				return true;
			}
			miscTimer -= AIIntervalTime;
			CarryEggBackToNest();
			return true;
		}
		if (Object.op_Implicit((Object)(object)patrollingEgg))
		{
			miscTimer -= AIIntervalTime;
			if (searchForLostEgg.inProgress)
			{
				StopSearch(searchForLostEgg);
			}
			if (AttackIfThreatened(onlyWhenAwake: false, ((Component)patrollingEgg).transform.position, 12f))
			{
				StartAttackingAndSync();
				return true;
			}
			PatrolAroundEgg();
			return true;
		}
		if (LostEggs.Count > 0)
		{
			if (carryingEgg && (Object)(object)takeEggBackToNest != (Object)null)
			{
				DropEgg(Object.op_Implicit((Object)(object)takeEggBackToNest));
			}
			if (wasPatrollingEgg)
			{
				wasPatrollingEgg = false;
			}
			if (!wasLookingForEggs)
			{
				wasLookingForEggs = true;
				Screech(enraged: true, sync: true);
			}
			KiwiBabyItem closestLostEgg = GetClosestLostEgg();
			if ((Object)(object)closestLostEgg == (Object)null)
			{
				if (!searchForLostEgg.inProgress)
				{
					if (watchingThreat != null)
					{
						StartSearch(watchingThreat.GetThreatTransform().position, searchForLostEgg);
					}
					else
					{
						StartSearch(StartOfRound.Instance.shipLandingPosition.position, searchForLostEgg);
					}
				}
				if (AttackIfThreatened(onlyWhenAwake: false, ((Component)this).transform.position))
				{
					StartAttackingAndSync();
					return true;
				}
				for (int i = 0; i < LostEggs.Count; i++)
				{
					if (HasLOSToEgg(LostEggs[i]) && Vector3.Distance(((Component)this).transform.position, ((Component)LostEggs[i]).transform.position) < 24f)
					{
						patrollingEgg = LostEggs[i];
						behaviourTimer = 3f;
						miscTimer = 1f;
						return true;
					}
				}
				return true;
			}
			if (searchForLostEgg.inProgress)
			{
				StopSearch(searchForLostEgg);
			}
			if (AttackIfThreatened(onlyWhenAwake: false, ((Component)closestLostEgg).transform.position))
			{
				StartAttackingAndSync();
				return true;
			}
			Vector3 actualEggPosition = GetActualEggPosition(closestLostEgg);
			SetDestinationToPosition(actualEggPosition);
			if (closestLostEgg.isInShipRoom)
			{
				destination = StartOfRound.Instance.shipStrictInnerRoomBounds.ClosestPoint(destination);
				destination.y = StartOfRound.Instance.playerSpawnPositions[0].position.y;
			}
			bool gotPath = SetDestinationToPosition(actualEggPosition, checkForPath: true);
			if (TryAbandonEgg(closestLostEgg, gotPath, actualEggPosition))
			{
				behaviourTimer = 3f;
				return true;
			}
			behaviourTimer -= AIIntervalTime * 0.65f;
			if (HasLOSToEgg(closestLostEgg) && eggDist < 6f)
			{
				if (AttackIfThreatened(onlyWhenAwake: false, ((Component)closestLostEgg).transform.position))
				{
					StartAttackingAndSync();
					return true;
				}
				patrollingEgg = closestLostEgg;
				behaviourTimer = 3f;
				miscTimer = 1f;
				closestLostEgg = GetClosestLostEgg(foundEggs: false, closestLostEgg);
				if ((Object)(object)closestLostEgg != (Object)null && eggDist < 20f)
				{
					LostEggs.Remove(patrollingEgg);
					if (!LostEggsFound.Contains(patrollingEgg))
					{
						LostEggsFound.Add(patrollingEgg);
					}
					miscTimer = 0f;
					patrollingEgg = null;
				}
			}
			return true;
		}
		if (LostEggsFound.Count > 0)
		{
			behaviourTimer = 3f;
			if (searchForLostEgg.inProgress)
			{
				StopSearch(searchForLostEgg);
			}
			defenseBehaviour = "return eggs";
			if ((Object)(object)takeEggBackToNest != (Object)null)
			{
				if (HasLOSToEgg(takeEggBackToNest) && Vector3.Distance(((Component)this).transform.position, ((Component)takeEggBackToNest).transform.position) <= 3f)
				{
					PickUpEgg(takeEggBackToNest);
					miscTimer = 0.7f;
					return true;
				}
				if (AttackIfThreatened(onlyWhenAwake: false, ((Component)takeEggBackToNest).transform.position))
				{
					StartAttackingAndSync();
					return true;
				}
			}
			else if (AttackIfThreatened(onlyWhenAwake: false, ((Component)this).transform.position))
			{
				StartAttackingAndSync();
				return true;
			}
			miscTimer -= AIIntervalTime;
			if (miscTimer <= 0f)
			{
				miscTimer = 6f;
				KiwiBabyItem closestLostEgg2 = GetClosestLostEgg(foundEggs: true, null, checkPath: true);
				if ((Object)(object)closestLostEgg2 != (Object)null)
				{
					Vector3 actualEggPosition2 = GetActualEggPosition(closestLostEgg2);
					SetDestinationToPosition(actualEggPosition2);
					if (closestLostEgg2.isInShipRoom)
					{
						destination = StartOfRound.Instance.shipStrictInnerRoomBounds.ClosestPoint(destination);
						destination.y = StartOfRound.Instance.playerSpawnPositions[0].position.y;
					}
					bool gotPath2 = SetDestinationToPosition(actualEggPosition2, checkForPath: true);
					if (TryAbandonEgg(closestLostEgg2, gotPath2, actualEggPosition2))
					{
						behaviourTimer = 3f;
						takeEggBackToNest = null;
						return true;
					}
					behaviourTimer -= AIIntervalTime * 0.65f;
					takeEggBackToNest = closestLostEgg2;
				}
			}
			return true;
		}
		return false;
	}

	private bool CheckNestForLostEgg()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		bool result = false;
		if (Vector3.Distance(((Component)this).transform.position, birdNest.transform.position) < 12f && !Physics.Linecast(eye.position, birdNest.transform.position + Vector3.up * 1.2f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			int num = 0;
			for (int i = 0; i < eggs.Count; i++)
			{
				if (Vector3.Distance(((Component)eggs[i]).transform.position, birdNest.transform.position) > 6f)
				{
					num++;
				}
			}
			if (num >= 2)
			{
				for (int j = 0; j < eggs.Count; j++)
				{
					if (Vector3.Distance(((Component)eggs[j]).transform.position, birdNest.transform.position) > 6f && !LostEggs.Contains(eggs[j]))
					{
						LostEggs.Add(eggs[j]);
						result = true;
					}
				}
			}
		}
		return result;
	}

	private void ReactToThreatAttack(IVisibleThreat threat, bool doLOSCheck = false)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (threat != null && Vector3.Distance(((Component)this).transform.position, threat.GetThreatTransform().position) < 22f && (!doLOSCheck || !Physics.Linecast(eye.position, threat.GetThreatLookTransform().position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)))
		{
			if (!seenThreatsHoldingEgg.Contains(threat.GetThreatTransform()))
			{
				seenThreatsHoldingEgg.Add(threat.GetThreatTransform());
			}
			if (currentBehaviourStateIndex != 2)
			{
				watchingThreat = threat;
				attackingThreat = threat;
				StartAttackingAndSync();
			}
		}
	}

	public override void NavigateTowardsTargetPlayer()
	{
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		if (setDestinationToPlayerInterval <= 0f)
		{
			setDestinationToPlayerInterval = 0.25f;
			VehicleController vehicleController = Object.FindObjectOfType<VehicleController>();
			if ((Object)(object)vehicleController != (Object)null)
			{
				Debug.Log((object)$"dist: {Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)vehicleController).transform.position)}");
			}
			if ((Object)(object)vehicleController != (Object)null && Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)vehicleController).transform.position) < 10f)
			{
				bool num = (Object)(object)vehicleController.currentDriver == (Object)(object)targetPlayer || (Object)(object)vehicleController.currentPassenger == (Object)(object)targetPlayer;
				bool flag = ((Collider)vehicleController.boundsCollider).ClosestPoint(((Component)targetPlayer).transform.position) == ((Component)targetPlayer).transform.position;
				int areaMask = -1;
				if (num || (flag && !vehicleController.backDoorOpen) || vehicleController.ontopOfTruckCollider.ClosestPoint(((Component)targetPlayer).transform.position) == ((Component)targetPlayer).transform.position)
				{
					targetPlayerIsInTruck = true;
					areaMask = -33;
				}
				destination = RoundManager.Instance.GetNavMeshPosition(((Component)targetPlayer).transform.position, RoundManager.Instance.navHit, 5.5f, areaMask);
			}
			else
			{
				targetPlayerIsInTruck = false;
				destination = RoundManager.Instance.GetNavMeshPosition(((Component)targetPlayer).transform.position, RoundManager.Instance.navHit, 2.7f);
			}
		}
		else
		{
			if (!targetPlayerIsInTruck)
			{
				destination = new Vector3(((Component)targetPlayer).transform.position.x, destination.y, ((Component)targetPlayer).transform.position.z);
			}
			setDestinationToPlayerInterval -= Time.deltaTime;
		}
		if (addPlayerVelocityToDestination > 0f)
		{
			if ((Object)(object)targetPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				destination += Vector3.Normalize(targetPlayer.thisController.velocity * 100f) * addPlayerVelocityToDestination;
			}
			else if (targetPlayer.timeSincePlayerMoving < 0.25f)
			{
				destination += Vector3.Normalize((targetPlayer.serverPlayerPosition - targetPlayer.oldPlayerPosition) * 100f) * addPlayerVelocityToDestination;
			}
		}
	}

	public override void DoAIInterval()
	{
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0656: Unknown result type (might be due to invalid IL or missing references)
		//IL_065c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a24: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_056e: Unknown result type (might be due to invalid IL or missing references)
		//IL_075d: Unknown result type (might be due to invalid IL or missing references)
		//IL_09be: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_09eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0801: Unknown result type (might be due to invalid IL or missing references)
		//IL_0811: Unknown result type (might be due to invalid IL or missing references)
		//IL_0836: Unknown result type (might be due to invalid IL or missing references)
		//IL_083c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0847: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Unknown result type (might be due to invalid IL or missing references)
		//IL_049e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04af: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04be: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_051d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_052a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0532: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ca4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d32: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d51: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d47: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d49: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d4e: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (stunNormalizedTimer > 0f)
		{
			IVisibleThreat threat = default(IVisibleThreat);
			if ((Object)(object)stunnedByPlayer != (Object)null && ((Component)stunnedByPlayer).TryGetComponent<IVisibleThreat>(ref threat))
			{
				ReactToThreatAttack(threat);
			}
		}
		else if (currentBehaviourStateIndex != 2 && !((NetworkBehaviour)this).IsServer)
		{
			if (((NetworkBehaviour)this).IsOwner)
			{
				ChangeOwnershipOfEnemy(((NetworkBehaviour)StartOfRound.Instance).OwnerClientId);
			}
		}
		else
		{
			if ((Object)(object)birdNest == (Object)null || StartOfRound.Instance.livingPlayers == 0)
			{
				return;
			}
			if (currentBehaviourStateIndex == 0 && (idleBehaviour != 2 || miscTimer > 0f) && CheckNestForLostEgg())
			{
				Screech(enraged: true, sync: true);
				SwitchToBehaviourState(1);
				return;
			}
			switch (currentBehaviourStateIndex)
			{
			case 0:
				if (LostEggs.Count > 0)
				{
					SwitchToBehaviourState(1);
					break;
				}
				if (searchForLostEgg.inProgress)
				{
					StopSearch(searchForLostEgg);
				}
				timeSinceExitingAttackMode += AIIntervalTime;
				abandonedThreat = null;
				agent.acceleration = 41f;
				if (AttackIfThreatened(onlyWhenAwake: true, birdNest.transform.position, 22f, forget: true))
				{
					if (checkLOSDistance < 6f)
					{
						StartAttackingAndSync();
						break;
					}
					if (Random.Range(0, 100) < 50)
					{
						Screech(enraged: false, sync: true);
					}
					timeSinceSeeingThreat = 0f;
					SwitchToBehaviourState(1);
					break;
				}
				if (timeSinceSeeingThreat > 2f)
				{
					watchingThreat = null;
				}
				if (idleBehaviour == 0)
				{
					if (miscTimer > 0f)
					{
						miscTimer -= AIIntervalTime;
						agent.speed = 0f;
						break;
					}
					agent.speed = idlePatrolSpeed;
					agent.stoppingDistance = 0f;
					idleTimer -= AIIntervalTime;
					if (!triedRandomDance && Vector3.Distance(((Component)this).transform.position, destination) < 1f)
					{
						triedRandomDance = true;
						if (Random.Range(0, 100) < 7)
						{
							creatureAnimator.SetBool("Dancing", true);
							SetDancingServerRpc(setDance: true);
						}
					}
					if (idleTimer < 0f)
					{
						idleTimer = 7f;
						Vector3 val2 = GetRandomPositionAroundObject(birdNest.transform.position, 16f, idleRandom);
						if (PathIsIntersectedByLineOfSight(val2, calculatePathDistance: true, avoidLineOfSight: false) || pathDistance > 25f)
						{
							val2 = birdNest.transform.position;
						}
						Debug.DrawRay(val2, Vector3.up * 5f, Color.cyan);
						SetDestinationToPosition(val2);
						triedRandomDance = false;
						creatureAnimator.SetBool("Dancing", false);
						SetDancingServerRpc(setDance: false);
					}
					break;
				}
				if (idleBehaviour == 1)
				{
					agent.stoppingDistance = 1f;
					agent.speed = idlePatrolSpeed;
					idleTimer -= AIIntervalTime;
					if (idleTimer < 0f || (Object)(object)peckingTree == (Object)null)
					{
						idleTimer = 12f;
						if (isPeckingTree)
						{
							isPeckingTree = false;
							PeckTreeServerRpc(isPecking: false);
							creatureAnimator.SetBool("peckTree", false);
						}
						int num = Physics.OverlapSphereNonAlloc(birdNest.transform.position, 20f, treeColliders, 33554432);
						if (num <= 0)
						{
							idleBehaviour = 2;
							ChangeIdleBehaviorClientRpc(2);
							break;
						}
						int num2 = idleRandom.Next(0, num);
						peckingTree = ((Component)treeColliders[num2]).transform;
						SetDestinationToPosition(RoundManager.Instance.GetNavMeshPosition(peckingTree.position, navHitB));
					}
					float num3 = Vector3.Distance(((Component)this).transform.position, destination);
					if (num3 < 4f)
					{
						if (!isPeckingTree)
						{
							isPeckingTree = true;
							PeckTreeServerRpc(isPecking: true);
							creatureAnimator.SetBool("peckTree", true);
						}
						Vector3 val3 = default(Vector3);
						((Vector3)(ref val3))._002Ector(((Component)peckingTree).transform.position.x, ((Component)this).transform.position.y, ((Component)peckingTree).transform.position.z);
						Ray val4 = default(Ray);
						((Ray)(ref val4))._002Ector(val3, ((Component)this).transform.position - val3);
						SetDestinationToPosition(((Ray)(ref val4)).GetPoint(peckTreeDistance));
					}
					else if (num3 > 5f)
					{
						if (isPeckingTree)
						{
							isPeckingTree = false;
							PeckTreeServerRpc(isPecking: false);
							creatureAnimator.SetBool("peckTree", false);
						}
						SetDestinationToPosition(RoundManager.Instance.GetNavMeshPosition(peckingTree.position));
					}
					break;
				}
				agent.stoppingDistance = 0f;
				idleTimer -= AIIntervalTime;
				if (Vector3.Distance(((Component)this).transform.position, destination) < 2f)
				{
					miscTimer -= AIIntervalTime;
					agent.speed = 0f;
					if (miscTimer < 0.5f)
					{
						watchingThreat = null;
					}
					if (miscTimer < 0f && !creatureAnimator.GetBool("Asleep"))
					{
						creatureAnimator.SetBool("Asleep", true);
						creatureSFX.Play();
						SetSleepingServerRpc();
					}
				}
				else
				{
					agent.speed = idlePatrolSpeed;
				}
				break;
			case 1:
			{
				if (BreakIntoShip())
				{
					break;
				}
				timeSinceExitingAttackMode += AIIntervalTime;
				if ((Object)(object)abandonedThreat != (Object)null && timeSinceExitingAttackMode > 11f)
				{
					abandonedThreat = null;
				}
				float num4 = Vector3.Distance(((Component)this).transform.position, destination);
				if (num4 > 8f)
				{
					agent.speed = 18f;
					if (walkAnimSpeed < 1.5f)
					{
						walkAnimSpeed = 1.8f;
						creatureAnimator.SetFloat("WalkSpeed", walkAnimSpeed);
						SyncWalkAnimSpeedServerRpc(walkAnimSpeed);
					}
				}
				else if (num4 < 6f)
				{
					agent.speed = 12f;
					if (walkAnimSpeed > 1.5f)
					{
						walkAnimSpeed = 1f;
						creatureAnimator.SetFloat("WalkSpeed", walkAnimSpeed);
						SyncWalkAnimSpeedServerRpc(walkAnimSpeed);
					}
				}
				agent.acceleration = 41f;
				if (PreoccupiedWithDefensePriorities())
				{
					break;
				}
				if (searchForLostEgg.inProgress)
				{
					StopSearch(searchForLostEgg);
				}
				behaviourTimer = 3f;
				if (AttackIfThreatened(onlyWhenAwake: false, birdNest.transform.position, 12f, forget: true))
				{
					StartAttackingAndSync();
					break;
				}
				if (timeSinceSeeingThreat > 4f)
				{
					watchingThreat = null;
				}
				if (watchingThreat == null)
				{
					SwitchToBehaviourState(0);
					break;
				}
				agent.stoppingDistance = 4f;
				agent.acceleration = 51f;
				Ray val5 = default(Ray);
				((Ray)(ref val5))._002Ector(birdNest.transform.position, watchingThreat.GetThreatTransform().position - birdNest.transform.position);
				float num5 = Vector3.Distance(watchingThreat.GetThreatTransform().position, birdNest.transform.position);
				SetDestinationToPosition(RoundManager.Instance.GetNavMeshPosition(((Ray)(ref val5)).GetPoint(Mathf.Max(num5 * 0.5f, protectNestRadius)), navHitB, 8f));
				break;
			}
			case 2:
			{
				if (searchForLostEgg.inProgress)
				{
					StopSearch(searchForLostEgg);
				}
				if (!wasOwnerLastFrame)
				{
					wasOwnerLastFrame = true;
					timeSpentChasingThreat = 0f;
				}
				if (BreakIntoShip())
				{
					break;
				}
				bool flag = false;
				bool flag2 = attackingThreat.IsThreatDead();
				if (attackingThreat != null)
				{
					timeSpentChasingThreat += AIIntervalTime;
					if (flag2 && LostEggs.Count > 0)
					{
						timeSinceSeeingThreat += AIIntervalTime;
					}
					if (timeSpentChasingThreat > 12f && attackingThreat.type == ThreatType.Player && LostEggs.Count > 0)
					{
						abandonedThreat = targetPlayer;
						for (int i = 0; i < LostEggs.Count; i++)
						{
							if (LostEggs[i].isHeld && (Object)(object)LostEggs[i].playerHeldBy != (Object)null && (Object)(object)LostEggs[i].playerHeldBy == (Object)(object)abandonedThreat)
							{
								AbandonLostEgg(LostEggs[i]);
							}
						}
					}
				}
				if ((Object)(object)lastPlayerWhoAttacked != (Object)null && timeSinceGettingHit < 0.5f && Vector3.Distance(((Component)this).transform.position, ((Component)lastPlayerWhoAttacked).transform.position) < 5f && !PathIsIntersectedByLineOfSight(((Component)lastPlayerWhoAttacked).transform.position, calculatePathDistance: false, avoidLineOfSight: false))
				{
					((Component)lastPlayerWhoAttacked).TryGetComponent<IVisibleThreat>(ref watchingThreat);
					attackingThreat = watchingThreat;
					flag = true;
				}
				else
				{
					flag = CheckLOSForCreatures(((Component)this).transform.position, protectAllEggs: true, mustHavePath: true);
				}
				if (flag)
				{
					if (checkLOSDistance >= 17f && !seenThreatsHoldingEgg.Contains(watchingThreat.GetThreatTransform()))
					{
						timeSinceSeeingThreat += AIIntervalTime;
					}
					else
					{
						timeSinceSeeingThreat = 0f;
					}
					if (watchingThreat != attackingThreat)
					{
						timeSpentChasingThreat = 0f;
						attackingThreat = watchingThreat;
						if (watchingThreat.type == ThreatType.Player)
						{
							PlayerControllerB component = ((Component)watchingThreat.GetThreatTransform()).GetComponent<PlayerControllerB>();
							if ((Object)(object)component != (Object)(object)GameNetworkManager.Instance.localPlayerController && currentOwnershipOnThisClient == (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
							{
								wasOwnerLastFrame = false;
								ChangeOwnershipOfEnemy(component.actualClientId);
							}
							break;
						}
						if (currentOwnershipOnThisClient != 0)
						{
							targetPlayer = null;
							movingTowardsTargetPlayer = false;
							ChangeOwnershipOfEnemy(((NetworkBehaviour)StartOfRound.Instance).OwnerClientId);
							break;
						}
					}
				}
				else
				{
					timeSinceSeeingThreat += AIIntervalTime;
				}
				if (timeSinceSeeingThreat > 4f)
				{
					SwitchToBehaviourState(1);
					ChangeOwnershipOfEnemy(((NetworkBehaviour)StartOfRound.Instance).OwnerClientId);
					break;
				}
				if (attackingThreat != null)
				{
					bool flag3 = false;
					for (int j = 0; j < eggs.Count; j++)
					{
						if (eggs[j].screaming && Vector3.Distance(((Component)eggs[j]).transform.position, attackingThreat.GetThreatTransform().position) < 3f)
						{
							flag3 = true;
							break;
						}
					}
					if (flag || flag3 || (timeSinceSeeingThreat < 0.5f && attackingThreat != null))
					{
						if (attackingThreat.type == ThreatType.Player)
						{
							targetPlayer = ((Component)attackingThreat.GetThreatTransform()).GetComponent<PlayerControllerB>();
							movingTowardsTargetPlayer = true;
							if (!targetPlayerIsInTruck)
							{
								addPlayerVelocityToDestination = 1f;
							}
							else
							{
								addPlayerVelocityToDestination = 0f;
							}
							agent.stoppingDistance = 0f;
						}
						else
						{
							SetDestinationToPosition(attackingThreat.GetThreatTransform().position);
						}
						checkingLastSeenPosition = true;
						miscTimer = 0f;
					}
					else
					{
						watchingThreat = null;
						if (checkingLastSeenPosition && !flag2)
						{
							if (Vector3.Distance(((Component)this).transform.position, lastSeenPositionOfWatchedThreat) > 3f)
							{
								SetDestinationToPosition(lastSeenPositionOfWatchedThreat);
							}
							else
							{
								checkingLastSeenPosition = false;
							}
						}
						else
						{
							KiwiBabyItem closestLostEgg = GetClosestLostEgg(foundEggs: false, null, checkPath: false, allEggs: true);
							if ((Object)(object)closestLostEgg != (Object)null)
							{
								miscTimer -= AIIntervalTime;
								if (miscTimer < 0f)
								{
									miscTimer = 1.5f;
									Vector3 val = GetRandomPositionAroundObject(((Component)closestLostEgg).transform.position, 8f, birdRandom);
									if (closestLostEgg.isInShipRoom)
									{
										val = StartOfRound.Instance.shipStrictInnerRoomBounds.ClosestPoint(val);
									}
									SetDestinationToPosition(val);
								}
							}
						}
					}
				}
				agent.stoppingDistance = 0f;
				break;
			}
			}
		}
	}

	private void SpawnExplosionAtDeadBodyAndSync()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsOwner)
		{
			targetPlayer.deadBody.DeactivateBody(setActive: false);
			Object.Instantiate<GameObject>(playerExplodePrefab, ((Component)targetPlayer.deadBody).transform.position, ((Component)targetPlayer).transform.rotation, RoundManager.Instance.mapPropsContainer.transform);
			int deactivatePlayerBody = (int)targetPlayer.playerClientId;
			SpawnExplosionAtPlayerBodyServerRpc(((Component)targetPlayer.deadBody).transform.position, ((Component)targetPlayer).transform.rotation, (int)GameNetworkManager.Instance.localPlayerController.playerClientId, deactivatePlayerBody);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SpawnExplosionAtPlayerBodyServerRpc(Vector3 pos, Quaternion rot, int playerWhoSent, int deactivatePlayerBody)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3238921108u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref rot);
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				BytePacker.WriteValueBitPacked(val2, deactivatePlayerBody);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3238921108u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SpawnExplosionAtPlayerBodyClientRpc(pos, rot, playerWhoSent, deactivatePlayerBody);
			}
		}
	}

	[ClientRpc]
	public void SpawnExplosionAtPlayerBodyClientRpc(Vector3 pos, Quaternion rot, int playerWhoSent, int deactivatePlayerBody)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1143323347u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref rot);
			BytePacker.WriteValueBitPacked(val2, playerWhoSent);
			BytePacker.WriteValueBitPacked(val2, deactivatePlayerBody);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1143323347u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerWhoSent)
		{
			targetPlayer.deadBody.DeactivateBody(setActive: false);
			Object.Instantiate<GameObject>(playerExplodePrefab, pos, rot, RoundManager.Instance.mapPropsContainer.transform);
			if ((Object)(object)StartOfRound.Instance.allPlayerScripts[deactivatePlayerBody].deadBody != (Object)null)
			{
				StartOfRound.Instance.allPlayerScripts[deactivatePlayerBody].deadBody.DeactivateBody(setActive: false);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncWalkAnimSpeedServerRpc(float speed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4085505192u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref speed, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4085505192u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SyncWalkAnimSpeedClientRpc(speed);
			}
		}
	}

	[ClientRpc]
	public void SyncWalkAnimSpeedClientRpc(float speed)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2658683365u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref speed, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2658683365u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				walkAnimSpeed = speed;
			}
		}
	}

	private void StartAttackingAndSync()
	{
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		if (watchingThreat == null)
		{
			Debug.LogError((object)"StartAttackingAndSync called with no watchingThreat currently set");
			return;
		}
		if (watchingThreat.type == ThreatType.Player)
		{
			targetPlayer = ((Component)watchingThreat.GetThreatTransform()).gameObject.GetComponent<PlayerControllerB>();
			currentOwnershipOnThisClient = (int)targetPlayer.playerClientId;
		}
		else
		{
			targetPlayer = null;
			currentOwnershipOnThisClient = (int)StartOfRound.Instance.allPlayerScripts[0].playerClientId;
		}
		attackingThreat = watchingThreat;
		if (((NetworkBehaviour)this).IsServer)
		{
			if ((Object)(object)targetPlayer != (Object)null)
			{
				if (((Component)this).gameObject.GetComponent<NetworkObject>().OwnerClientId != targetPlayer.actualClientId)
				{
					thisNetworkObject.ChangeOwnership(targetPlayer.actualClientId);
				}
			}
			else if (((Component)this).gameObject.GetComponent<NetworkObject>().OwnerClientId != StartOfRound.Instance.allPlayerScripts[0].actualClientId)
			{
				thisNetworkObject.ChangeOwnership(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
			}
		}
		Screech();
		timeSpentChasingThreat = 0f;
		SwitchToBehaviourStateOnLocalClient(2);
		List<int> list = new List<int>();
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (seenThreatsHoldingEgg.Contains(((Component)StartOfRound.Instance.allPlayerScripts[i]).transform))
			{
				list.Add((int)StartOfRound.Instance.allPlayerScripts[i].playerClientId);
			}
		}
		int abandonedThreatInt = -1;
		if ((Object)(object)abandonedThreat != (Object)null)
		{
			abandonedThreatInt = (int)abandonedThreat.playerClientId;
		}
		StartAttackingThreatServerRpc(NetworkObjectReference.op_Implicit(((Component)attackingThreat.GetThreatTransform()).gameObject.GetComponent<NetworkObject>()), (int)GameNetworkManager.Instance.localPlayerController.playerClientId, list.ToArray(), abandonedThreatInt);
	}

	private void AddPlayerIDsToSeenThreatsHoldingEggsList(int[] IDs)
	{
		for (int i = 0; i < IDs.Length; i++)
		{
			if (!seenThreatsHoldingEgg.Contains(((Component)StartOfRound.Instance.allPlayerScripts[IDs[i]]).transform))
			{
				seenThreatsHoldingEgg.Add(((Component)StartOfRound.Instance.allPlayerScripts[IDs[i]]).transform);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StartAttackingThreatServerRpc(NetworkObjectReference threatObjectRef, int playerWhoSent, int[] seenThreatsHoldingEggsPlayerIDs, int abandonedThreatInt)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(639546879u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref threatObjectRef, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, playerWhoSent);
			bool flag = seenThreatsHoldingEggsPlayerIDs != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(seenThreatsHoldingEggsPlayerIDs, default(ForPrimitives));
			}
			BytePacker.WriteValueBitPacked(val2, abandonedThreatInt);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 639546879u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (!((NetworkObjectReference)(ref threatObjectRef)).TryGet(ref val3, (NetworkManager)null))
		{
			Debug.LogError((object)$"Bird error: Unable to get network object out of synced net object ref for StartAttackingServerRpc; id: {((NetworkObjectReference)(ref threatObjectRef)).NetworkObjectId}");
			return;
		}
		if (!((Component)val3).gameObject.TryGetComponent<IVisibleThreat>(ref attackingThreat))
		{
			Debug.LogError((object)("Bird error: Unable to get IVisibleThreat interface out of synced network object ref for StartAttackingServerRpc; object: '" + ((Object)((Component)val3).gameObject).name + "'"));
			return;
		}
		ulong num;
		int value;
		if (attackingThreat.type != 0)
		{
			num = ((NetworkBehaviour)StartOfRound.Instance).OwnerClientId;
			if (!StartOfRound.Instance.ClientPlayerList.TryGetValue(num, out value))
			{
				Debug.LogError((object)$"Bird: Unable to get player value from clientplayerlist for client id: {num} which should be host.");
			}
			targetPlayer = null;
		}
		else
		{
			PlayerControllerB component = ((Component)attackingThreat.GetThreatTransform()).GetComponent<PlayerControllerB>();
			num = component.actualClientId;
			targetPlayer = component;
			if (!StartOfRound.Instance.ClientPlayerList.TryGetValue(num, out value))
			{
				Debug.LogError((object)$"Bird: Unable to get player value from clientplayerlist for client id: {num}");
				targetPlayer = null;
			}
		}
		if (((Component)this).gameObject.GetComponent<NetworkObject>().OwnerClientId != num)
		{
			thisNetworkObject.ChangeOwnership(num);
		}
		currentOwnershipOnThisClient = value;
		if (playerWhoSent != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
		{
			Screech();
			timeSpentChasingThreat = 0f;
			AddPlayerIDsToSeenThreatsHoldingEggsList(seenThreatsHoldingEggsPlayerIDs);
			if (abandonedThreatInt != -1)
			{
				abandonedThreat = StartOfRound.Instance.allPlayerScripts[abandonedThreatInt];
			}
		}
		StartAttackingClientRpc(NetworkObjectReference.op_Implicit(((Component)attackingThreat.GetThreatTransform()).gameObject.GetComponent<NetworkObject>()), value, playerWhoSent, seenThreatsHoldingEggsPlayerIDs, abandonedThreatInt);
	}

	[ClientRpc]
	public void StartAttackingClientRpc(NetworkObjectReference threat, int playerVal, int playerWhoSent, int[] seenThreatsHoldingEggsPlayerIDs, int abandonedThreatInt)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2397901577u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref threat, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, playerVal);
			BytePacker.WriteValueBitPacked(val2, playerWhoSent);
			bool flag = seenThreatsHoldingEggsPlayerIDs != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(seenThreatsHoldingEggsPlayerIDs, default(ForPrimitives));
			}
			BytePacker.WriteValueBitPacked(val2, abandonedThreatInt);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2397901577u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || (int)GameNetworkManager.Instance.localPlayerController.playerClientId == playerWhoSent)
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref threat)).TryGet(ref val3, (NetworkManager)null))
		{
			IVisibleThreat visibleThreat = default(IVisibleThreat);
			if (!((Component)val3).gameObject.TryGetComponent<IVisibleThreat>(ref visibleThreat))
			{
				Debug.LogError((object)("Bird Error: StartAttackingClientRpc - Could not get an IVisibleThreat interface from synced NetworkObject '" + ((Object)((Component)val3).gameObject).name + "'"));
			}
			else
			{
				if (visibleThreat.type == ThreatType.Player)
				{
					targetPlayer = StartOfRound.Instance.allPlayerScripts[playerVal];
				}
				else
				{
					targetPlayer = null;
				}
				attackingThreat = visibleThreat;
				watchingThreat = visibleThreat;
			}
		}
		Screech();
		timeSpentChasingThreat = 0f;
		if (abandonedThreatInt != -1)
		{
			abandonedThreat = StartOfRound.Instance.allPlayerScripts[abandonedThreatInt];
		}
		currentOwnershipOnThisClient = playerVal;
		SwitchToBehaviourStateOnLocalClient(2);
		AddPlayerIDsToSeenThreatsHoldingEggsList(seenThreatsHoldingEggsPlayerIDs);
	}

	public override void Update()
	{
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		//IL_0943: Unknown result type (might be due to invalid IL or missing references)
		//IL_0949: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dfc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e01: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e10: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e15: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0708: Unknown result type (might be due to invalid IL or missing references)
		//IL_0717: Unknown result type (might be due to invalid IL or missing references)
		//IL_0727: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c27: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c37: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0603: Unknown result type (might be due to invalid IL or missing references)
		//IL_0608: Unknown result type (might be due to invalid IL or missing references)
		//IL_060a: Unknown result type (might be due to invalid IL or missing references)
		//IL_060c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0616: Unknown result type (might be due to invalid IL or missing references)
		//IL_061b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0626: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d20: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d25: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d41: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd1: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (watchingThreat != null)
		{
			watchingThreatTransform = watchingThreat.GetThreatTransform();
		}
		else
		{
			watchingThreatTransform = null;
		}
		if (isEnemyDead)
		{
			creatureAnimator.SetLayerWeight(1, Mathf.Max(0f, creatureAnimator.GetLayerWeight(1) - Time.deltaTime * 5f));
		}
		else
		{
			if (inKillAnimation)
			{
				return;
			}
			if ((Object)(object)birdNest == (Object)null)
			{
				if (((NetworkBehaviour)this).IsServer)
				{
					return;
				}
				EnemyAINestSpawnObject[] array = Object.FindObjectsByType<EnemyAINestSpawnObject>((FindObjectsSortMode)0);
				for (int i = 0; i < array.Length; i++)
				{
					if ((Object)(object)array[i].enemyType == (Object)(object)enemyType)
					{
						birdNest = ((Component)array[i]).gameObject;
						birdNestAmbience = ((Component)array[i]).GetComponent<AudioSource>();
						break;
					}
				}
				return;
			}
			creatureAnimator.SetBool("Stunned", stunNormalizedTimer > 0f);
			if (pryingOpenDoor && inSpecialAnimation)
			{
				((Component)this).transform.position = Vector3.Lerp(((Component)this).transform.position, shipDoor.outsideDoorPoint.position, 7f * Time.deltaTime);
				((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, shipDoor.outsideDoorPoint.rotation, 7f * Time.deltaTime);
				pryingDoorAnimTime = Mathf.Min(pryingDoorAnimTime + Time.deltaTime / pryOpenDoorAnimLength, 1f);
				creatureAnimator.SetFloat("pryOpenDoor", pryingDoorAnimTime);
				shipDoor.shipDoorsAnimator.SetFloat("pryOpenDoor", pryingDoorAnimTime);
				creatureAnimator.SetLayerWeight(1, Mathf.Max(0f, creatureAnimator.GetLayerWeight(1) - Time.deltaTime * 5f));
				if (pryingDoorAnimTime > 0.12f)
				{
					EnableEnemyMesh(enable: true);
				}
				BreakIntoShip();
				return;
			}
			if (stunNormalizedTimer > 0f)
			{
				if (((NetworkBehaviour)this).IsOwner)
				{
					agent.speed = 0f;
					agent.acceleration = 5000f;
				}
				creatureAnimator.SetBool("Attacking", false);
				return;
			}
			pingAttentionTimer -= Time.deltaTime;
			timeSinceHittingPlayer += Time.deltaTime;
			timeSincePingingAttention += Time.deltaTime;
			timeSinceHittingGround += Time.deltaTime;
			timeSinceGettingHit += Time.deltaTime;
			CalculateAnimationDirection(1.2f);
			CalculateLookingAnimation();
			creatureAnimator.SetBool("holdEgg", carryingEgg);
			for (int j = 0; j < eggs.Count; j++)
			{
				if (!LostEggs.Contains(eggs[j]) && eggs[j].screaming && (!(Time.realtimeSinceStartup - eggs[j].timeLastAbandoned < 25f) || (!(Vector3.Distance(((Component)eggs[j]).transform.position, eggs[j].positionWhenLastAbandoned) < 10f) && (!((Object)(object)abandonedThreat != (Object)null) || !eggs[j].isHeld || !((Object)(object)eggs[j].playerHeldBy != (Object)null) || !((Object)(object)eggs[j].playerHeldBy == (Object)(object)abandonedThreat)))))
				{
					LostEggs.Add(eggs[j]);
					if (LostEggsFound.Contains(eggs[j]))
					{
						LostEggsFound.Remove(eggs[j]);
					}
				}
			}
			if (!((NetworkBehaviour)this).IsOwner)
			{
				wasOwnerLastFrame = false;
			}
			switch (currentBehaviourStateIndex)
			{
			case 0:
				if (currentBehaviourStateIndex != previousBehaviour)
				{
					idleBehaviour = 0;
					wasLookingForEggs = false;
					creatureAnimator.SetBool("Running", false);
					agent.speed = idlePatrolSpeed;
					behaviourTimer = 15f;
					idleTimer = 4f;
					previousBehaviour = currentBehaviourStateIndex;
				}
				if (previousIdleBehaviour != idleBehaviour)
				{
					if (idleBehaviour != 2 && birdNestAmbience.isPlaying)
					{
						birdNestAmbience.Stop();
					}
					if (idleBehaviour == 0 && previousIdleBehaviour == 2)
					{
						if (creatureSFX.isPlaying)
						{
							creatureSFX.Stop();
						}
						creatureSFX.PlayOneShot(wakeUpSFX);
						miscTimer = 2f;
					}
					else
					{
						miscTimer = 0f;
					}
					if (idleBehaviour != 1)
					{
						creatureAnimator.SetBool("peckTree", false);
						isPeckingTree = false;
						peckingTree = null;
					}
					if (idleBehaviour != 2)
					{
						creatureAnimator.SetBool("Asleep", false);
					}
					if (idleBehaviour != 0)
					{
						creatureAnimator.SetBool("Dancing", false);
					}
					idleRandom = new Random(StartOfRound.Instance.randomMapSeed + 33 + idleBehaviour);
					if (idleBehaviour == 2)
					{
						miscTimer = 1.5f;
						if (((NetworkBehaviour)this).IsOwner)
						{
							Vector3 val = GetRandomPositionAroundObject(birdNest.transform.position, 5f, idleRandom);
							if (PathIsIntersectedByLineOfSight(val, calculatePathDistance: true, avoidLineOfSight: false) || pathDistance > 35f)
							{
								val = birdNest.transform.position;
							}
							Debug.DrawRay(val, Vector3.up * 5f, Color.green);
							SetDestinationToPosition(val);
						}
					}
					attacking = false;
					creatureAnimator.SetBool("Attacking", false);
					previousIdleBehaviour = idleBehaviour;
				}
				if (idleBehaviour != 0)
				{
					if (idleBehaviour == 1)
					{
						if (isPeckingTree && (Object)(object)peckingTree != (Object)null && ((NetworkBehaviour)this).IsOwner)
						{
							RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
							RoundManager.Instance.tempTransform.LookAt(((Component)peckingTree).transform.position);
							RoundManager.Instance.tempTransform.eulerAngles = new Vector3(0f, RoundManager.Instance.tempTransform.eulerAngles.y, 0f);
							((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, RoundManager.Instance.tempTransform.rotation, 10f * Time.deltaTime);
						}
					}
					else
					{
						if (!birdNestAmbience.isPlaying)
						{
							birdNestAmbience.Play();
						}
						birdNestAmbience.volume = Mathf.Min(birdNestAmbience.volume + Time.deltaTime * 0.5f, 1f);
					}
				}
				if (((NetworkBehaviour)this).IsServer)
				{
					if (idleBehaviour == 2)
					{
						behaviourTimer -= Time.deltaTime * 0.82f;
					}
					else
					{
						behaviourTimer -= Time.deltaTime;
					}
					if (behaviourTimer < 0f)
					{
						behaviourTimer = 18f;
						idleBehaviour = (idleBehaviour + 1) % 3;
						ChangeIdleBehaviorClientRpc(idleBehaviour);
					}
				}
				creatureAnimator.SetFloat("WalkSpeed", 1f);
				break;
			case 1:
				if (currentBehaviourStateIndex != previousBehaviour)
				{
					creatureAnimator.SetBool("peckTree", false);
					isPeckingTree = false;
					if (creatureSFX.isPlaying)
					{
						creatureSFX.Stop();
					}
					if (birdNestAmbience.isPlaying)
					{
						birdNestAmbience.Stop();
					}
					creatureAnimator.SetBool("Asleep", false);
					creatureAnimator.SetBool("Dancing", false);
					agent.speed = 12f;
					attacking = false;
					creatureAnimator.SetBool("Attacking", false);
					previousBehaviour = currentBehaviourStateIndex;
					timeSinceSeeingThreat = 0f;
				}
				if (((NetworkBehaviour)this).IsOwner && carryingEgg && (Object)(object)takeEggBackToNest != (Object)null && miscTimer > 0f)
				{
					agent.speed = 0f;
				}
				if (!((NetworkBehaviour)this).IsOwner)
				{
					creatureAnimator.SetFloat("WalkSpeed", walkAnimSpeed);
					creatureAnimator.SetBool("Running", velZ > 0.5f && velX < 0.4f && Vector3.Distance(((Component)this).transform.position, destination) > 5f);
				}
				break;
			case 2:
				if (currentBehaviourStateIndex != previousBehaviour)
				{
					creatureAnimator.SetBool("PeckTree", false);
					isPeckingTree = false;
					if (creatureSFX.isPlaying)
					{
						creatureSFX.Stop();
					}
					creatureAnimator.SetBool("Asleep", false);
					creatureAnimator.SetBool("Dancing", false);
					timeSinceSeeingThreat = 0f;
					timeSinceExitingAttackMode = 0f;
					if (birdNestAmbience.isPlaying)
					{
						birdNestAmbience.Stop();
					}
					patrollingInAttackMode = false;
					checkingLastSeenPosition = true;
					miscTimer = 0f;
					attackSpeedMultiplier = 0.45f;
					longChaseBonusSpeed = 0f;
					behaviourTimer = 0.8f;
					if (((NetworkBehaviour)this).IsServer && carryingEgg && (Object)(object)takeEggBackToNest != (Object)null)
					{
						DropEgg();
					}
					previousBehaviour = currentBehaviourStateIndex;
				}
				behaviourTimer -= Time.deltaTime;
				if (behaviourTimer > 0f)
				{
					attacking = false;
					creatureAnimator.SetFloat("WalkSpeed", 0f);
					creatureAnimator.SetBool("Attacking", false);
					if (((NetworkBehaviour)this).IsOwner)
					{
						agent.speed = 0f;
					}
					break;
				}
				attackSpeedMultiplier = Mathf.Min(1.4f, attackSpeedMultiplier + Time.deltaTime * chaseAccelerationMultiplier);
				if (attackSpeedMultiplier > 0.85f)
				{
					agent.acceleration = Mathf.Min(140f, agent.acceleration + Time.deltaTime * 2f);
				}
				if (attackSpeedMultiplier >= 1.1f)
				{
					longChaseBonusSpeed += Time.deltaTime * 0.5f;
				}
				else if (attackSpeedMultiplier <= 0.85f)
				{
					agent.acceleration = Mathf.Max(45f, agent.acceleration - Time.deltaTime * 3f);
					longChaseBonusSpeed = Mathf.Clamp(longChaseBonusSpeed - Time.deltaTime * 2f, 6.3f, 40f);
				}
				if (((NetworkBehaviour)this).IsOwner)
				{
					agent.speed = 10f * (attackSpeedMultiplier * 1.4f) + longChaseBonusSpeed;
				}
				if (watchingThreat != null)
				{
					attacking = Vector3.Distance(((Component)this).transform.position, watchingThreat.GetThreatTransform().position) < 10f;
					if (!attacking)
					{
						if (Physics.Linecast(eye.position, watchingThreat.GetThreatLookTransform().position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
						{
							attackSpeedMultiplier = Mathf.Max(0.7f, attackSpeedMultiplier - Time.deltaTime * (chaseAccelerationMultiplier * 1.5f));
						}
						if (watchingThreat.type == ThreatType.Player)
						{
							PlayerControllerB component = ((Component)watchingThreat.GetThreatTransform()).GetComponent<PlayerControllerB>();
							if ((Object)(object)component.deadBody != (Object)null && !component.deadBody.deactivated && Vector3.Distance(((Component)this).transform.position, ((Component)component.deadBody.bodyParts[0]).transform.position) < 5f)
							{
								attacking = true;
							}
						}
					}
					if (((NetworkBehaviour)this).IsOwner && movingTowardsTargetPlayer && (Object)(object)targetPlayer != (Object)null && targetPlayer.isInHangarShipRoom)
					{
						destination = StartOfRound.Instance.shipStrictInnerRoomBounds.ClosestPoint(destination);
						destination.y = StartOfRound.Instance.playerSpawnPositions[0].position.y;
					}
				}
				else
				{
					attacking = false;
				}
				creatureAnimator.SetFloat("attackSpeed", attackSpeedMultiplier);
				creatureAnimator.SetBool("Attacking", attacking);
				creatureAnimator.SetFloat("WalkSpeed", attackSpeedMultiplier + 1.2f);
				break;
			}
			sampleNavAreaInterval -= Time.deltaTime;
			if (sampleNavAreaInterval < 0f)
			{
				sampleNavAreaInterval = 0.2f;
				if (!creatureAnimator.GetBool("Crawling"))
				{
					if (!isInsidePlayerShip && !pryingOpenDoor && Physics.Raycast(((Component)this).transform.position + Vector3.up * 0.2f, Vector3.up, 4.55f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
					{
						creatureAnimator.SetBool("Crawling", true);
						agent.acceleration = 500f;
					}
				}
				else if (isInsidePlayerShip || pryingOpenDoor || !Physics.Raycast(((Component)this).transform.position + Vector3.up * 0.2f, Vector3.up, 4.55f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					creatureAnimator.SetBool("Crawling", false);
					agent.acceleration = 50f;
				}
			}
			if (((NetworkBehaviour)this).IsOwner && creatureAnimator.GetBool("Crawling"))
			{
				agent.speed = Mathf.Min(agent.speed, 4f);
			}
		}
	}

	[ClientRpc]
	public void ChangeIdleBehaviorClientRpc(int newIdleBehavior)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3575423690u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, newIdleBehavior);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3575423690u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				idleBehaviour = newIdleBehavior;
			}
		}
	}

	private bool CheckPathFromNodeToShip(Transform node)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Expected O, but got Unknown
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		NavMeshPath val = new NavMeshPath();
		RaycastHit val2 = default(RaycastHit);
		if (Physics.Raycast(((Component)node).transform.position, Vector3.down, ref val2, 5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) && NavMesh.CalculatePath(((RaycastHit)(ref val2)).point, StartOfRound.Instance.outsideDoorPosition.position, -1, val) && (int)val.status == 0)
		{
			return true;
		}
		return false;
	}

	private void SpawnBirdNest()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		GameObject[] array = (from x in GameObject.FindGameObjectsWithTag("OutsideAINode")
			orderby Vector3.Distance(x.transform.position, ((Component)StartOfRound.Instance.shipLandingPosition).transform.position) descending
			select x).ToArray();
		Vector3 val = array[0].transform.position;
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 288);
		int num = random.Next(0, array.Length / 3);
		bool flag = false;
		Vector3 val2 = Vector3.zero;
		for (int i = 0; i < array.Length; i++)
		{
			val = array[num].transform.position;
			val = RoundManager.Instance.GetRandomNavMeshPositionInBoxPredictable(val, 15f, default(NavMeshHit), random, RoundManager.Instance.GetLayermaskForEnemySizeLimit(enemyType));
			val = RoundManager.Instance.PositionWithDenialPointsChecked(val, array, enemyType, enemyType.nestDistanceFromShip);
			flag = CheckPathFromNodeToShip(array[num].transform);
			if (flag)
			{
				val2 = RoundManager.Instance.PositionEdgeCheck(val, enemyType.nestSpawnPrefabWidth);
			}
			if (val2 == Vector3.zero || !flag)
			{
				num++;
				if (num > array.Length - 1)
				{
					val = RoundManager.Instance.GetRandomNavMeshPositionInBoxPredictable(array[0].transform.position, 15f, default(NavMeshHit), random, RoundManager.Instance.GetLayermaskForEnemySizeLimit(enemyType));
					break;
				}
				continue;
			}
			val = val2;
			break;
		}
		GameObject val3 = Object.Instantiate<GameObject>(birdNestPrefab, val, Quaternion.Euler(Vector3.zero), RoundManager.Instance.mapPropsContainer.transform);
		val3.transform.Rotate(Vector3.up, (float)random.Next(-180, 180), (Space)0);
		if (!Object.op_Implicit((Object)(object)val3.gameObject.GetComponentInChildren<NetworkObject>()))
		{
			Debug.LogError((object)("Error: No NetworkObject found in enemy nest spawn prefab that was just spawned on the host: '" + ((Object)val3).name + "'"));
		}
		else
		{
			val3.gameObject.GetComponentInChildren<NetworkObject>().Spawn(true);
		}
		birdNestAmbience = val3.GetComponent<AudioSource>();
		birdNest = val3;
		((Behaviour)agent).enabled = false;
		((Component)this).transform.position = birdNest.transform.position;
		((Component)this).transform.rotation = birdNest.transform.rotation;
		((Behaviour)agent).enabled = true;
	}

	private void SpawnNestEggs()
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if ((Object)(object)birdNest == (Object)null)
		{
			Debug.LogError((object)$"{enemyType.enemyName} #{thisEnemyIndex}: Nest object is null!");
			return;
		}
		nestEggSpawnPositions = birdNest.GetComponent<EnemyAINestSpawnObject>().nestPositions;
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 1316 + enemyType.numberSpawned);
		NetworkObjectReference[] array = (NetworkObjectReference[])(object)new NetworkObjectReference[3];
		int[] array2 = new int[3];
		for (int i = 0; i < 3; i++)
		{
			GameObject obj = Object.Instantiate<GameObject>(eggPrefab, nestEggSpawnPositions[i].position + Vector3.up * 0.2f, Quaternion.Euler(Vector3.zero), RoundManager.Instance.spawnedScrapContainer);
			obj.SetActive(true);
			NetworkObject component = obj.GetComponent<NetworkObject>();
			component.Spawn(false);
			array[i] = NetworkObjectReference.op_Implicit(component);
			int num = ((!(Vector3.Distance(birdNest.transform.position, ((Component)StartOfRound.Instance.shipLandingPosition).transform.position) > 100f)) ? random.Next(40, 70) : ((Random.Range(0, 100) >= 30) ? random.Next(70, 120) : random.Next(70, 200)));
			array2[i] = num;
		}
		Vector3[] array3 = (Vector3[])(object)new Vector3[3];
		for (int j = 0; j < array3.Length; j++)
		{
			array3[j] = nestEggSpawnPositions[j].position;
		}
		SpawnEggsClientRpc(array, array2, array3);
	}

	[ClientRpc]
	public void SpawnEggsClientRpc(NetworkObjectReference[] eggNetworkReferences, int[] eggScrapValues, Vector3[] nestSpawnPositions)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(276418090u, val, (RpcDelivery)0);
			bool flag = eggNetworkReferences != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(eggNetworkReferences, default(ForNetworkSerializable));
			}
			bool flag2 = eggScrapValues != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag2, default(ForPrimitives));
			if (flag2)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(eggScrapValues, default(ForPrimitives));
			}
			bool flag3 = nestSpawnPositions != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag3, default(ForPrimitives));
			if (flag3)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe(nestSpawnPositions);
			}
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 276418090u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		for (int i = 0; i < 3; i++)
		{
			if (((NetworkObjectReference)(ref eggNetworkReferences[i])).TryGet(ref val3, (NetworkManager)null))
			{
				KiwiBabyItem component = ((Component)val3).gameObject.GetComponent<KiwiBabyItem>();
				eggs.Add(component);
				component.scrapValue = eggScrapValues[i];
				ScanNodeProperties componentInChildren = ((Component)component).gameObject.GetComponentInChildren<ScanNodeProperties>();
				if ((Object)(object)componentInChildren != (Object)null)
				{
					componentInChildren.scrapValue = eggScrapValues[i];
					componentInChildren.headerText = "Egg";
					componentInChildren.subText = $"VALUE: ${eggScrapValues[i]}";
				}
				component.targetFloorPosition = nestSpawnPositions[i] + Vector3.up * 0.2f;
				RoundManager.Instance.totalScrapValueInLevel += eggScrapValues[i];
				hasSpawnedEggs = true;
			}
			else
			{
				Debug.LogError((object)"Bird: Error! Egg could not be accessed from network object reference");
			}
		}
	}

	public void Screech(bool enraged = true, bool sync = false)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position);
		if (enraged)
		{
			creatureAnimator.SetTrigger("ScreamEnraged");
			RoundManager.PlayRandomClip(creatureVoice, screamSFX, randomize: true, 1f, 10111);
			WalkieTalkie.TransmitOneShotAudio(creatureSFX, screamSFX[1]);
			if (num < 20f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.VeryStrong);
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.7f);
			}
			else if (num < 50f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.5f);
			}
		}
		else
		{
			creatureAnimator.SetTrigger("Scream");
			peckAudio.pitch = Random.Range(0.9f, 1.1f);
			peckAudio.PlayOneShot(squawkSFX);
			WalkieTalkie.TransmitOneShotAudio(peckAudio, squawkSFX);
			if (num < 16f)
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.2f);
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
		}
		if (sync)
		{
			ScreechServerRpc(enraged, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ScreechServerRpc(bool enraged, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2934149737u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enraged, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2934149737u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ScreechClientRpc(enraged, playerWhoSent);
			}
		}
	}

	[ClientRpc]
	public void ScreechClientRpc(bool enraged, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3785748456u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enraged, default(ForPrimitives));
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3785748456u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerWhoSent != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				Screech(enraged);
			}
		}
	}

	private void CalculateLookingAnimation()
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0504: Unknown result type (might be due to invalid IL or missing references)
		//IL_050f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0514: Unknown result type (might be due to invalid IL or missing references)
		//IL_0519: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_049e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_059c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_060a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0615: Unknown result type (might be due to invalid IL or missing references)
		//IL_0625: Unknown result type (might be due to invalid IL or missing references)
		//IL_0635: Unknown result type (might be due to invalid IL or missing references)
		//IL_0640: Unknown result type (might be due to invalid IL or missing references)
		//IL_064b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0650: Unknown result type (might be due to invalid IL or missing references)
		if (stunNormalizedTimer > 0f || (currentBehaviourStateIndex == 0 && idleBehaviour == 2) || (currentBehaviourStateIndex == 0 && idleBehaviour == 0 && miscTimer > 0.4f) || (isPeckingTree && currentBehaviourStateIndex == 0))
		{
			if (watchingThreat != null)
			{
				eyesLookTarget.position = watchingThreat.GetThreatLookTransform().position;
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigA).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigA).weight, 1f, Time.deltaTime * 16f);
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigB).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigB).weight, 1f, Time.deltaTime * 16f);
			}
			agent.angularSpeed = 520f;
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 0f, Time.deltaTime * 16f);
			return;
		}
		bool flag = currentBehaviourStateIndex == 1 && LostEggsFound.Count > 0 && carryingEgg && miscTimer > 0f;
		bool @bool = creatureAnimator.GetBool("Attacking");
		bool flag2 = currentBehaviourStateIndex == 2 && Vector3.Distance(((Component)this).transform.position, destination) > 4f && Mathf.Abs(velX) > 0.3f;
		if (eyeTwitchInterval <= 0f)
		{
			eyeTwitchInterval = Random.Range(0.1f, 0.6f);
			leftEyeMesh.localEulerAngles = baseEyeRotationLeft + new Vector3(Random.Range(-1f, 1f) * eyeTwitchAmount, Random.Range(-1f, 1f) * eyeTwitchAmount, Random.Range(-1f, 1f) * eyeTwitchAmount);
			rightEyeMesh.localEulerAngles = baseEyeRotation + new Vector3(Random.Range(-1f, 1f) * eyeTwitchAmount, Random.Range(-1f, 1f) * eyeTwitchAmount, Random.Range(-1f, 1f) * eyeTwitchAmount);
		}
		if (pingAttentionTimer >= 0f && !flag && !@bool)
		{
			lookTarget.position = Vector3.Lerp(lookTarget.position, pingAttentionPosition, 12f * Time.deltaTime);
		}
		else
		{
			if (watchingThreat == null || flag || @bool || Physics.Linecast(eye.position, watchingThreat.GetThreatLookTransform().position, lookMask, (QueryTriggerInteraction)1))
			{
				agent.angularSpeed = 520f;
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 0f, Time.deltaTime * 16f);
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigA).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigA).weight, 0f, Time.deltaTime * 16f);
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigB).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigB).weight, 0f, Time.deltaTime * 16f);
				return;
			}
			lookTarget.position = Vector3.Lerp(lookTarget.position, watchingThreat.GetThreatLookTransform().position, 16f * Time.deltaTime);
		}
		if (((NetworkBehaviour)this).IsOwner && !flag2 && Vector3.Angle(((Component)this).transform.forward, Vector3.Scale(new Vector3(1f, 0f, 1f), lookTarget.position - ((Component)this).transform.position)) > 4f * Mathf.Min(Vector3.Distance(((Component)this).transform.position, lookTarget.position) * 0.5f, 10f))
		{
			agent.angularSpeed = 0f;
			turnCompass.LookAt(lookTarget);
			turnCompass.eulerAngles = new Vector3(0f, turnCompass.eulerAngles.y, 0f);
			float num = 7f;
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, turnCompass.rotation, num * Time.deltaTime);
			((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.localEulerAngles.y, 0f);
		}
		float num2 = ((!(Vector3.Dot(((Component)this).transform.right, Vector3.Normalize(Vector3.Scale(new Vector3(1f, 0f, 1f), lookTarget.position - ((Component)this).transform.position))) > 0f)) ? 90f : (-90f));
		turnHeadInterval -= Time.deltaTime;
		if (turnHeadInterval < 0f)
		{
			turnHeadOffset = Random.Range(-30f, 30f);
			turnHeadInterval = Random.Range(0.6f, 1.6f);
		}
		((MultiAimConstraintData)(ref ((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).data)).offset = Vector3.Lerp(((MultiAimConstraintData)(ref ((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).data)).offset, new Vector3(0f, num2 + turnHeadOffset, 0f), Time.deltaTime * 50f);
		headLookTarget.position = Vector3.Lerp(headLookTarget.position, lookTarget.position, 8f * Time.deltaTime);
		eyesLookTarget.position = Vector3.Lerp(eyesLookTarget.position, lookTarget.position, 15f * Time.deltaTime);
		float num3 = Vector3.Angle(((Component)this).transform.forward, lookTarget.position - ((Component)this).transform.position);
		if (num3 > 22f)
		{
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 1f * (Mathf.Abs(num3 - 180f) / 180f), Time.deltaTime * 11f);
		}
		else
		{
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 1f, Time.deltaTime * 11f);
		}
		((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigA).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigA).weight, 1f, Time.deltaTime * 16f);
		((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigB).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)eyesLookRigB).weight, 1f, Time.deltaTime * 16f);
	}

	public override void AnimationEventA()
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		base.AnimationEventA();
		if (!inMovement)
		{
			return;
		}
		int num = Random.Range(0, footstepSFX.Length);
		if (!((Object)(object)footstepSFX[num] == (Object)null))
		{
			creatureSFX.PlayOneShot(footstepSFX[num]);
			WalkieTalkie.TransmitOneShotAudio(creatureSFX, footstepSFX[num]);
			if (currentBehaviourStateIndex > 0 && Vector3.Distance(((Component)this).transform.position, destination) > 5f && !creatureAnimator.GetBool("Crawling"))
			{
				runningParticle.Play(true);
			}
			if (currentBehaviourStateIndex > 0 && creatureAnimator.GetFloat("WalkSpeed") > 1f)
			{
				longDistanceAudio.PlayOneShot(footstepBassSFX[num]);
				WalkieTalkie.TransmitOneShotAudio(longDistanceAudio, footstepBassSFX[num]);
			}
			RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 12f, 0.6f, 0, isInsidePlayerShip && StartOfRound.Instance.hangarDoorsClosed, 675189);
		}
	}

	public override void AnimationEventB()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		base.AnimationEventA();
		peckAudio.pitch = Random.Range(0.95f, 1.05f);
		RoundManager.Instance.PlayAudibleNoise(eye.position, 25f, 0.85f, 0, isInsidePlayerShip && StartOfRound.Instance.hangarDoorsClosed, 675188);
		if (attacking && !isEnemyDead)
		{
			rocksParticle.Play();
			RoundManager.PlayRandomClip(peckAudio, attackSFX, randomize: true, 1f, 91911);
			timeSinceHittingGround = 0f;
			float num = Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, ((Component)this).transform.position);
			if (num < 5f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
			else if (num < 13f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
			}
			destroyTreesInterval = (destroyTreesInterval + 1) % 4;
			if (destroyTreesInterval == 0)
			{
				RoundManager.Instance.DestroyTreeAtPosition(((Component)this).transform.position + ((Component)this).transform.forward * 0.75f, 1.5f);
			}
			if (timeSinceHittingPlayer < 0.1f)
			{
				PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
				_ = ((Component)localPlayerController).transform.position;
				Vector3 val = ((Component)localPlayerController).transform.position + Vector3.up * 3f - ((Component)this).transform.position;
				localPlayerController.externalForceAutoFade += val * hitVelocityForce;
				localPlayerController.DamagePlayer(10, hasDamageSFX: true, callRPC: true, CauseOfDeath.Stabbing, 9, fallDamage: false, val * hitVelocityForce * 0.4f);
				timeSinceHittingPlayer = 0f;
			}
		}
		else
		{
			woodChipParticle.Play();
			peckAudio.PlayOneShot(peckTreeSFX);
			WalkieTalkie.TransmitOneShotAudio(peckAudio, peckTreeSFX);
		}
	}

	public override void AnimationEventC()
	{
		base.AnimationEventC();
		if (isEnemyDead)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	public override void AnimationEventD()
	{
		base.AnimationEventD();
		if (((NetworkBehaviour)this).IsOwner && Random.Range(0, 100) < 50)
		{
			Screech(enraged: false, sync: true);
		}
	}

	public override void OnDestroy()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		base.OnDestroy();
		if (isEnemyDead)
		{
			Object.Instantiate<GameObject>(feathersPrefab, ((Component)this).transform.position, ((Component)this).transform.rotation, RoundManager.Instance.mapPropsContainer.transform);
		}
	}

	private void CalculateAnimationDirection(float maxSpeed = 1f)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		inMovement = velX > 0.2f || velZ > 0.2f;
		agentLocalVelocity = animationContainer.InverseTransformDirection(Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 2f));
		velX = Mathf.Lerp(velX, agentLocalVelocity.x, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityX", Mathf.Clamp(velX, 0f - maxSpeed, maxSpeed));
		velZ = Mathf.Lerp(velZ, agentLocalVelocity.z, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityZ", Mathf.Clamp(velZ, 0f - maxSpeed, maxSpeed));
		previousPosition = ((Component)this).transform.position;
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesPlayedInOneSpot, noiseID);
		if (!((NetworkBehaviour)this).IsOwner || (!((NetworkBehaviour)this).IsOwner && noiseID != 75) || isEnemyDead || Time.realtimeSinceStartup - timeAtLastHeardNoise < 3f || Vector3.Distance(noisePosition, ((Component)this).transform.position + Vector3.up * 0.4f) < 0.5f || (watchingThreat != null && timeSinceSeeingThreat < 1f && Vector3.Distance(noisePosition + Vector3.up * 0.4f, watchingThreat.GetThreatTransform().position) < 1f) || (currentBehaviourStateIndex == 2 && Vector3.Angle(((Component)this).transform.forward, noisePosition - ((Component)this).transform.position) < 60f))
		{
			return;
		}
		float num = Vector3.Distance(noisePosition, ((Component)this).transform.position);
		float num2 = noiseLoudness / num;
		if (Physics.Linecast(((Component)this).transform.position, noisePosition, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			num2 *= 0.6f;
		}
		if (pingAttentionTimer > 0f)
		{
			if (focusLevel >= 3)
			{
				if (num > 3f || num2 <= 0.12f)
				{
					return;
				}
			}
			else if (focusLevel == 2)
			{
				if (num > 25f || num2 <= 0.075f)
				{
					return;
				}
			}
			else if (focusLevel <= 1 && (num > 40f || num2 <= 0.06f))
			{
				return;
			}
		}
		if (!(num2 <= 0.022f))
		{
			timeAtLastHeardNoise = Time.realtimeSinceStartup;
			PingAttention(2, 0.5f, noisePosition + Vector3.up * 0.6f);
		}
	}

	public void PingAttention(int newFocusLevel, float timeToLook, Vector3 attentionPosition, bool sync = true)
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		if ((!(pingAttentionTimer >= 0f) || newFocusLevel >= focusLevel) && (currentBehaviourStateIndex != 0 || !(timeSincePingingAttention < 0.7f)) && (currentBehaviourStateIndex != 1 || !(timeSincePingingAttention < 0.4f)) && (currentBehaviourStateIndex != 2 || !(timeSincePingingAttention < 1f)))
		{
			focusLevel = newFocusLevel;
			pingAttentionTimer = timeToLook;
			pingAttentionPosition = attentionPosition;
			if (((NetworkBehaviour)this).IsOwner && currentBehaviourStateIndex == 0 && idleBehaviour == 2)
			{
				idleBehaviour = 0;
				ChangeIdleBehaviorClientRpc(0);
			}
			if (sync)
			{
				PingBirdAttentionServerRpc(timeToLook, attentionPosition, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PingBirdAttentionServerRpc(float timeToLook, Vector3 attentionPosition, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2000979301u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToLook, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref attentionPosition);
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2000979301u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PingBirdAttentionClientRpc(timeToLook, attentionPosition, playerWhoSent);
			}
		}
	}

	[ClientRpc]
	public void PingBirdAttentionClientRpc(float timeToLook, Vector3 attentionPosition, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3294500800u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToLook, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref attentionPosition);
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3294500800u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerWhoSent != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				pingAttentionTimer = timeToLook;
				pingAttentionPosition = attentionPosition;
			}
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other, inKillAnimation);
		if ((Object)(object)playerControllerB != (Object)null && (!playerControllerB.isInHangarShipRoom || isInsidePlayerShip || !(((Component)playerControllerB).transform.position.y - ((Component)this).transform.position.y > 1.6f) || !Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.45f, ((Component)playerControllerB).transform.position + Vector3.up * 0.45f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)))
		{
			timeSinceHittingPlayer = 0f;
			if (attacking)
			{
				GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(1f);
			}
		}
	}

	public override void OnCollideWithEnemy(Collider other, EnemyAI collidedEnemy = null)
	{
		base.OnCollideWithEnemy(other, collidedEnemy);
		if (!collidedEnemy.isEnemyDead && attacking && timeSinceHittingGround < 0.2f)
		{
			if (collidedEnemy.enemyType.EnemySize == EnemySize.Tiny)
			{
				collidedEnemy.KillEnemy();
			}
			else if (Time.realtimeSinceStartup - timeSinceHittingEnemy > 0.15f)
			{
				timeSinceHittingEnemy = Time.realtimeSinceStartup;
				collidedEnemy.HitEnemy(4);
			}
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		if ((Object)(object)creatureVoice != (Object)null)
		{
			creatureVoice.Stop();
		}
		creatureSFX.Stop();
		if (((NetworkBehaviour)this).IsOwner)
		{
			FinishPryOpenDoor(cancelledEarly: true);
		}
		base.KillEnemy();
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (isEnemyDead)
		{
			return;
		}
		enemyHP -= force;
		timeSinceGettingHit = 0f;
		if (((NetworkBehaviour)this).IsOwner && enemyHP <= 0)
		{
			KillEnemyOnOwnerClient();
		}
		if ((Object)(object)playerWhoHit != (Object)null)
		{
			lastPlayerWhoAttacked = playerWhoHit;
			IVisibleThreat threat = default(IVisibleThreat);
			if (((Component)playerWhoHit).TryGetComponent<IVisibleThreat>(ref threat))
			{
				ReactToThreatAttack(threat);
			}
			return;
		}
		lastPlayerWhoAttacked = null;
		int num = Physics.OverlapSphereNonAlloc(eye.position, 6f, RoundManager.Instance.tempColliderResults, 524288, (QueryTriggerInteraction)2);
		float num2 = 100f;
		int num3 = -1;
		for (int i = 0; i < num; i++)
		{
			float num4 = Vector3.Distance(eye.position, ((Component)RoundManager.Instance.tempColliderResults[i]).transform.position);
			if (num4 < num2)
			{
				num2 = num4;
				num3 = i;
			}
		}
		EnemyAICollisionDetect component = ((Component)((Component)RoundManager.Instance.tempColliderResults[num3]).transform).GetComponent<EnemyAICollisionDetect>();
		IVisibleThreat threat2 = default(IVisibleThreat);
		if ((Object)(object)component != (Object)null && !component.mainScript.isEnemyDead && ((Component)component.mainScript).TryGetComponent<IVisibleThreat>(ref threat2))
		{
			ReactToThreatAttack(threat2, doLOSCheck: true);
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_GiantKiwiAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Expected O, but got Unknown
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Expected O, but got Unknown
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Expected O, but got Unknown
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Expected O, but got Unknown
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Expected O, but got Unknown
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1509496551u, new RpcReceiveHandler(__rpc_handler_1509496551));
		NetworkManager.__rpc_func_table.Add(2329433375u, new RpcReceiveHandler(__rpc_handler_2329433375));
		NetworkManager.__rpc_func_table.Add(538806819u, new RpcReceiveHandler(__rpc_handler_538806819));
		NetworkManager.__rpc_func_table.Add(1965629606u, new RpcReceiveHandler(__rpc_handler_1965629606));
		NetworkManager.__rpc_func_table.Add(2757245750u, new RpcReceiveHandler(__rpc_handler_2757245750));
		NetworkManager.__rpc_func_table.Add(321322077u, new RpcReceiveHandler(__rpc_handler_321322077));
		NetworkManager.__rpc_func_table.Add(2000046764u, new RpcReceiveHandler(__rpc_handler_2000046764));
		NetworkManager.__rpc_func_table.Add(4160656602u, new RpcReceiveHandler(__rpc_handler_4160656602));
		NetworkManager.__rpc_func_table.Add(2370506911u, new RpcReceiveHandler(__rpc_handler_2370506911));
		NetworkManager.__rpc_func_table.Add(3612179633u, new RpcReceiveHandler(__rpc_handler_3612179633));
		NetworkManager.__rpc_func_table.Add(3671496547u, new RpcReceiveHandler(__rpc_handler_3671496547));
		NetworkManager.__rpc_func_table.Add(1775051963u, new RpcReceiveHandler(__rpc_handler_1775051963));
		NetworkManager.__rpc_func_table.Add(4019607224u, new RpcReceiveHandler(__rpc_handler_4019607224));
		NetworkManager.__rpc_func_table.Add(2152766841u, new RpcReceiveHandler(__rpc_handler_2152766841));
		NetworkManager.__rpc_func_table.Add(1803512774u, new RpcReceiveHandler(__rpc_handler_1803512774));
		NetworkManager.__rpc_func_table.Add(712000225u, new RpcReceiveHandler(__rpc_handler_712000225));
		NetworkManager.__rpc_func_table.Add(3238921108u, new RpcReceiveHandler(__rpc_handler_3238921108));
		NetworkManager.__rpc_func_table.Add(1143323347u, new RpcReceiveHandler(__rpc_handler_1143323347));
		NetworkManager.__rpc_func_table.Add(4085505192u, new RpcReceiveHandler(__rpc_handler_4085505192));
		NetworkManager.__rpc_func_table.Add(2658683365u, new RpcReceiveHandler(__rpc_handler_2658683365));
		NetworkManager.__rpc_func_table.Add(639546879u, new RpcReceiveHandler(__rpc_handler_639546879));
		NetworkManager.__rpc_func_table.Add(2397901577u, new RpcReceiveHandler(__rpc_handler_2397901577));
		NetworkManager.__rpc_func_table.Add(3575423690u, new RpcReceiveHandler(__rpc_handler_3575423690));
		NetworkManager.__rpc_func_table.Add(276418090u, new RpcReceiveHandler(__rpc_handler_276418090));
		NetworkManager.__rpc_func_table.Add(2934149737u, new RpcReceiveHandler(__rpc_handler_2934149737));
		NetworkManager.__rpc_func_table.Add(3785748456u, new RpcReceiveHandler(__rpc_handler_3785748456));
		NetworkManager.__rpc_func_table.Add(2000979301u, new RpcReceiveHandler(__rpc_handler_2000979301));
		NetworkManager.__rpc_func_table.Add(3294500800u, new RpcReceiveHandler(__rpc_handler_3294500800));
	}

	private static void __rpc_handler_1509496551(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool isPecking = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isPecking, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).PeckTreeServerRpc(isPecking);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2329433375(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool isPecking = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isPecking, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).PeckTreeClientRpc(isPecking);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_538806819(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).SetSleepingServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1965629606(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).SetSleepingClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2757245750(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int idOfPlayerAdded = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref idOfPlayerAdded);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).AddToThreatsHoldingEggListServerRpc(idOfPlayerAdded);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_321322077(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int idOfPlayerAdded = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref idOfPlayerAdded);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).AddToThreatsHoldingEggListClientRpc(idOfPlayerAdded);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2000046764(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference seenThreatNetworkObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref seenThreatNetworkObject, default(ForNetworkSerializable));
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).SyncWatchingThreatServerRpc(seenThreatNetworkObject, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4160656602(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference seenThreatNetworkObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref seenThreatNetworkObject, default(ForNetworkSerializable));
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).SyncWatchingThreatClientRpc(seenThreatNetworkObject, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2370506911(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			NetworkObjectReference item = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref item, default(ForNetworkSerializable));
			int clientWhoSentRPC = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientWhoSentRPC);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).GrabScrapServerRpc(item, clientWhoSentRPC);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3612179633(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference item = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref item, default(ForNetworkSerializable));
			int clientWhoSentRPC = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientWhoSentRPC);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).GrabScrapClientRpc(item, clientWhoSentRPC);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3671496547(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference item = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref item, default(ForNetworkSerializable));
			Vector3 targetFloorPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetFloorPosition);
			bool droppedInNest = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref droppedInNest, default(ForPrimitives));
			int clientWhoSentRPC = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientWhoSentRPC);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).DropScrapServerRpc(item, targetFloorPosition, droppedInNest, clientWhoSentRPC);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1775051963(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference item = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref item, default(ForNetworkSerializable));
			Vector3 targetFloorPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref targetFloorPosition);
			bool droppedInNest = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref droppedInNest, default(ForPrimitives));
			int clientWhoSentRPC = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientWhoSentRPC);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).DropScrapClientRpc(item, targetFloorPosition, droppedInNest, clientWhoSentRPC);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4019607224(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			bool finishAnim = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref finishAnim, default(ForPrimitives));
			bool cancelledEarly = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref cancelledEarly, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).PryOpenDoorServerRpc(playerWhoSent, finishAnim, cancelledEarly);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2152766841(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			bool finishAnim = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref finishAnim, default(ForPrimitives));
			bool cancelledEarly = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref cancelledEarly, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).PryOpenDoorClientRpc(playerWhoSent, finishAnim, cancelledEarly);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1803512774(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool dancingServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref dancingServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).SetDancingServerRpc(dancingServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_712000225(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool dancingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref dancingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).SetDancingClientRpc(dancingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3238921108(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			Quaternion rot = default(Quaternion);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref rot);
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			int deactivatePlayerBody = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref deactivatePlayerBody);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).SpawnExplosionAtPlayerBodyServerRpc(pos, rot, playerWhoSent, deactivatePlayerBody);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1143323347(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			Quaternion rot = default(Quaternion);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref rot);
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			int deactivatePlayerBody = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref deactivatePlayerBody);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).SpawnExplosionAtPlayerBodyClientRpc(pos, rot, playerWhoSent, deactivatePlayerBody);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4085505192(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float speed = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref speed, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).SyncWalkAnimSpeedServerRpc(speed);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2658683365(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float speed = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref speed, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).SyncWalkAnimSpeedClientRpc(speed);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_639546879(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference threatObjectRef = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref threatObjectRef, default(ForNetworkSerializable));
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			int[] seenThreatsHoldingEggsPlayerIDs = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref seenThreatsHoldingEggsPlayerIDs, default(ForPrimitives));
			}
			int abandonedThreatInt = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref abandonedThreatInt);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).StartAttackingThreatServerRpc(threatObjectRef, playerWhoSent, seenThreatsHoldingEggsPlayerIDs, abandonedThreatInt);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2397901577(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference threat = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref threat, default(ForNetworkSerializable));
			int playerVal = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerVal);
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			int[] seenThreatsHoldingEggsPlayerIDs = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref seenThreatsHoldingEggsPlayerIDs, default(ForPrimitives));
			}
			int abandonedThreatInt = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref abandonedThreatInt);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).StartAttackingClientRpc(threat, playerVal, playerWhoSent, seenThreatsHoldingEggsPlayerIDs, abandonedThreatInt);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3575423690(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int newIdleBehavior = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newIdleBehavior);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).ChangeIdleBehaviorClientRpc(newIdleBehavior);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_276418090(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			NetworkObjectReference[] eggNetworkReferences = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref eggNetworkReferences, default(ForNetworkSerializable));
			}
			bool flag2 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag2, default(ForPrimitives));
			int[] eggScrapValues = null;
			if (flag2)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref eggScrapValues, default(ForPrimitives));
			}
			bool flag3 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag3, default(ForPrimitives));
			Vector3[] nestSpawnPositions = null;
			if (flag3)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe(ref nestSpawnPositions);
			}
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).SpawnEggsClientRpc(eggNetworkReferences, eggScrapValues, nestSpawnPositions);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2934149737(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enraged = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enraged, default(ForPrimitives));
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).ScreechServerRpc(enraged, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3785748456(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enraged = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enraged, default(ForPrimitives));
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).ScreechClientRpc(enraged, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2000979301(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timeToLook = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToLook, default(ForPrimitives));
			Vector3 attentionPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref attentionPosition);
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((GiantKiwiAI)(object)target).PingBirdAttentionServerRpc(timeToLook, attentionPosition, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3294500800(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timeToLook = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToLook, default(ForPrimitives));
			Vector3 attentionPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref attentionPosition);
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((GiantKiwiAI)(object)target).PingBirdAttentionClientRpc(timeToLook, attentionPosition, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "GiantKiwiAI";
	}
}
