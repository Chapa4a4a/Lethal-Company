using UnityEngine;

public class FootprintsManager : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
