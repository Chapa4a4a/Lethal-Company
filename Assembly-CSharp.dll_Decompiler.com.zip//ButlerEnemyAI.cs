using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Animations.Rigging;

public class ButlerEnemyAI : EnemyAI
{
	private Vector3[] lastSeenPlayerPositions;

	private bool[] seenPlayers;

	private float[] timeOfLastSeenPlayers;

	private float timeSinceSeeingMultiplePlayers;

	private float timeSinceCheckingForMultiplePlayers;

	private float timeUntilNextCheck;

	private int playersInVicinity;

	private int currentSpecialAnimation;

	private float timeSinceLastSpecialAnimation;

	private bool doingKillAnimation;

	private int previousBehaviourState = -1;

	private int playersInView;

	private Vector3 agentLocalVelocity;

	public Transform animationContainer;

	private float velX;

	private float velZ;

	private Vector3 previousPosition;

	private PlayerControllerB watchingPlayer;

	public Transform lookTarget;

	public MultiAimConstraint headLookRig;

	public Transform turnCompass;

	public Transform headLookTarget;

	private float sweepFloorTimer;

	private bool isSweeping;

	public AISearchRoutine roamAndSweepFloor;

	public AISearchRoutine hoverAroundTargetPlayer;

	public float idleMovementSpeedBase = 3.5f;

	public float timeSinceChangingItem;

	private float timeSinceHittingPlayer;

	public AudioSource ambience1;

	public AudioSource buzzingAmbience;

	public AudioSource sweepingAudio;

	public AudioClip[] footsteps;

	public AudioClip[] broomSweepSFX;

	private float timeAtLastFootstep;

	private float pingAttentionTimer;

	private int focusLevel;

	private Vector3 pingAttentionPosition;

	private float timeSincePingingAttention;

	private Coroutine checkForPlayersCoroutine;

	private bool hasPlayerInSight;

	private float timeSinceNoticingFirstPlayer;

	private bool lostPlayerInChase;

	private float loseInChaseTimer;

	private bool startedMurderMusic;

	private PlayerControllerB targetedPlayerAlonePreviously;

	private bool checkedForTargetedPlayerPosition;

	private float timeAtLastTargetPlayerSync;

	private PlayerControllerB syncedTargetPlayer;

	private bool trackingTargetPlayerDownToMurder;

	private float premeditationTimeMultiplier = 1f;

	private float timeSpentWaitingForPlayer;

	[Space(3f)]
	[Header("Death sequence")]
	private bool startedButlerDeathAnimation;

	public ParticleSystem popParticle;

	public AudioSource popAudio;

	public AudioSource popAudioFar;

	public EnemyType butlerBeesEnemyType;

	private float timeAtLastButlerDamage;

	public ParticleSystem stabBloodParticle;

	private float timeAtLastHeardNoise;

	private bool killedLastTarget;

	private bool startedCrimeSceneTimer;

	private float leaveCrimeSceneTimer;

	private PlayerControllerB lastMurderedTarget;

	public GameObject knifePrefab;

	public AudioSource ambience2;

	public static AudioSource murderMusicAudio;

	public static bool increaseMurderMusicVolume;

	public static float murderMusicVolume;

	public bool madlySearchingForPlayers;

	private float ambushSpeedMeter;

	private float timeSinceStealthStab;

	private float berserkModeTimer;

	private void LateUpdate()
	{
		if ((Object)(object)ambience2 == (Object)(object)murderMusicAudio)
		{
			if (increaseMurderMusicVolume)
			{
				increaseMurderMusicVolume = false;
			}
			else
			{
				murderMusicVolume = Mathf.Max(murderMusicVolume - Time.deltaTime * 0.4f, 0f);
			}
			if ((Object)(object)murderMusicAudio != (Object)null)
			{
				murderMusicAudio.volume = murderMusicVolume;
			}
		}
	}

	public override void Start()
	{
		base.Start();
		lastSeenPlayerPositions = (Vector3[])(object)new Vector3[4];
		seenPlayers = new bool[4];
		timeOfLastSeenPlayers = new float[4];
		if ((Object)(object)murderMusicAudio == (Object)null)
		{
			((Component)ambience2).transform.SetParent(RoundManager.Instance.spawnedScrapContainer);
			murderMusicAudio = ambience2;
		}
		if (StartOfRound.Instance.connectedPlayersAmount == 0)
		{
			enemyHP = 2;
			idleMovementSpeedBase *= 0.75f;
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		base.KillEnemy(destroy);
		if (currentSearch.inProgress)
		{
			StopSearch(currentSearch);
		}
		ambience1.Stop();
		ambience1.volume = 0f;
		ambience2.Stop();
		ambience2.volume = 0f;
		agent.speed = 0f;
		agent.acceleration = 1000f;
		if (!startedButlerDeathAnimation)
		{
			startedButlerDeathAnimation = true;
			((MonoBehaviour)this).StartCoroutine(ButlerBlowUpAndPop());
		}
	}

	private IEnumerator ButlerBlowUpAndPop()
	{
		creatureAnimator.SetTrigger("Popping");
		creatureAnimator.SetLayerWeight(1, 0f);
		popAudio.PlayOneShot(enemyType.audioClips[3]);
		yield return (object)new WaitForSeconds(1.1f);
		creatureAnimator.SetBool("popFinish", true);
		popAudio.Play();
		popAudioFar.Play();
		popParticle.Play(true);
		float num = Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)this).transform.position);
		if (num < 8f)
		{
			Landmine.SpawnExplosion(((Component)this).transform.position + Vector3.up * 0.15f, spawnExplosionEffect: false, 0f, 2f, 30, 80f);
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			SoundManager.Instance.earsRingingTimer = 0.8f;
		}
		else if (num < 27f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
		}
		if (((NetworkBehaviour)this).IsServer)
		{
			RoundManager.Instance.SpawnEnemyGameObject(((Component)this).transform.position, 0f, -1, butlerBeesEnemyType);
			Object.Instantiate<GameObject>(knifePrefab, ((Component)this).transform.position + Vector3.up * 0.5f, Quaternion.identity, RoundManager.Instance.spawnedScrapContainer).GetComponent<NetworkObject>().Spawn(false);
		}
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		enemyHP -= force;
		if (hitID == 5)
		{
			enemyHP -= 100;
		}
		if ((Object)(object)playerWhoHit != (Object)null)
		{
			berserkModeTimer = 8f;
		}
		if (enemyHP <= 0 && ((NetworkBehaviour)this).IsOwner)
		{
			KillEnemyOnOwnerClient();
		}
		else if ((Object)(object)playerWhoHit != (Object)null && (currentBehaviourStateIndex != 2 || (Object)(object)playerWhoHit != (Object)(object)targetPlayer))
		{
			PingAttention(5, 0.6f, ((Component)playerWhoHit).transform.position, sync: false);
			timeAtLastButlerDamage = Time.realtimeSinceStartup;
		}
	}

	public override void DoAIInterval()
	{
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead || previousBehaviourState != currentBehaviourStateIndex)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (killedLastTarget && !startedCrimeSceneTimer)
			{
				Debug.Log((object)"Starting leave crime scene timer");
				Debug.Log((object)$"Target player: {targetPlayer.playerClientId}");
				startedCrimeSceneTimer = true;
				leaveCrimeSceneTimer = 15f;
				movingTowardsTargetPlayer = false;
				if (hoverAroundTargetPlayer.inProgress)
				{
					StopSearch(hoverAroundTargetPlayer);
				}
				if (roamAndSweepFloor.inProgress)
				{
					StopSearch(roamAndSweepFloor);
				}
				SetDestinationToPosition(ChooseFarthestNodeFromPosition(((Component)this).transform.position).position);
			}
			LookForChanceToMurder(2f);
			break;
		case 1:
			LookForChanceToMurder(8f);
			break;
		case 2:
		{
			if ((Object)(object)GameNetworkManager.Instance.localPlayerController != (Object)(object)targetPlayer || !((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			if (targetPlayer.isPlayerDead && CheckLineOfSightForPosition(((Component)targetPlayer.deadBody.bodyParts[5]).transform.position, 120f, 60, 2f))
			{
				if (playersInVicinity < 2 || berserkModeTimer > 0f)
				{
					PlayerControllerB playerControllerB = CheckLineOfSightForPlayer(100f, 50, 2);
					if ((Object)(object)playerControllerB != (Object)null)
					{
						targetPlayer = playerControllerB;
						SwitchOwnershipAndSetToStateServerRpc(2, targetPlayer.actualClientId, berserkModeTimer);
						Debug.Log((object)"State 2, changing ownership A");
						break;
					}
				}
				Debug.Log((object)"State 2, Switching to state 0, killed target");
				SyncKilledLastTargetServerRpc((int)targetPlayer.playerClientId);
				SwitchToBehaviourState(0);
				ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
				break;
			}
			if (timeSinceChangingItem < 1.7f || (pingAttentionTimer > 0f && berserkModeTimer <= 0f) || stunNormalizedTimer > 0f)
			{
				agent.speed = 0f;
				break;
			}
			agent.speed = 8f;
			creatureAnimator.SetBool("Running", true);
			if (lostPlayerInChase)
			{
				if (!hoverAroundTargetPlayer.inProgress)
				{
					movingTowardsTargetPlayer = false;
					StartSearch(lastSeenPlayerPositions[targetPlayer.playerClientId], hoverAroundTargetPlayer);
				}
				PlayerControllerB playerControllerB2 = CheckLineOfSightForPlayer(100f, 50, 2);
				if ((Object)(object)playerControllerB2 == (Object)null)
				{
					loseInChaseTimer += AIIntervalTime;
					if (loseInChaseTimer > 12f)
					{
						targetedPlayerAlonePreviously = targetPlayer;
						Debug.Log((object)"State 2, Switching to state 0, lost in chase");
						SwitchToBehaviourState(0);
						ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
					}
				}
				else if ((Object)(object)playerControllerB2 == (Object)(object)targetPlayer && playersInVicinity < 2)
				{
					lostPlayerInChase = false;
					loseInChaseTimer = 0f;
				}
				else if (berserkModeTimer <= 0f)
				{
					targetedPlayerAlonePreviously = targetPlayer;
					Debug.Log((object)"State 2, Switching to state 0, found another player or multiple players 1");
					SwitchToBehaviourState(0);
					ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
				}
				break;
			}
			PlayerControllerB playerControllerB3 = CheckLineOfSightForPlayer(100f, 50, 2);
			if ((Object)(object)playerControllerB3 == (Object)null)
			{
				loseInChaseTimer += AIIntervalTime;
				if (loseInChaseTimer > 3.5f)
				{
					lostPlayerInChase = true;
				}
			}
			else
			{
				if (((Object)(object)playerControllerB3 != (Object)(object)targetPlayer || playersInVicinity > 1) && berserkModeTimer <= 0f)
				{
					targetedPlayerAlonePreviously = targetPlayer;
					Debug.Log((object)"State 2, Switching to state 0, found another player or multiple players 2");
					SwitchToBehaviourState(0);
					ChangeOwnershipOfEnemy(StartOfRound.Instance.allPlayerScripts[0].actualClientId);
					break;
				}
				if ((Object)(object)playerControllerB3 == (Object)(object)targetPlayer)
				{
					loseInChaseTimer = 0f;
				}
			}
			SetMovingTowardsTargetPlayer(targetPlayer);
			break;
		}
		}
	}

	public void LookForChanceToMurder(float waitForTime = 5f)
	{
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0535: Unknown result type (might be due to invalid IL or missing references)
		//IL_053a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0439: Unknown result type (might be due to invalid IL or missing references)
		//IL_0444: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_045b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0468: Unknown result type (might be due to invalid IL or missing references)
		//IL_062b: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (currentBehaviourStateIndex == 1 && playersInVicinity > 1)
		{
			SwitchToBehaviourState(0);
		}
		if (playersInVicinity <= 0)
		{
			if (killedLastTarget)
			{
				leaveCrimeSceneTimer -= AIIntervalTime;
				if (leaveCrimeSceneTimer <= 0f)
				{
					killedLastTarget = false;
					startedCrimeSceneTimer = false;
					creatureAnimator.SetInteger("HeldItem", 1);
					creatureAnimator.SetBool("Running", false);
					SyncKilledLastTargetFalseClientRpc();
					Debug.Log((object)"Exiting leave crime scene mode, 0");
				}
				return;
			}
			if (!roamAndSweepFloor.inProgress)
			{
				StartSearch(((Component)this).transform.position, roamAndSweepFloor);
				sweepFloorTimer = 5f;
			}
			hasPlayerInSight = false;
			checkedForTargetedPlayerPosition = false;
			timeSinceSeeingMultiplePlayers = 0f;
			timeSinceCheckingForMultiplePlayers = 3f;
			timeSpentWaitingForPlayer += AIIntervalTime;
			if (timeSpentWaitingForPlayer > 6f && !madlySearchingForPlayers)
			{
				madlySearchingForPlayers = true;
				roamAndSweepFloor.searchPrecision = 16f;
				SyncSearchingMadlyServerRpc(isSearching: true);
			}
			return;
		}
		if (!hasPlayerInSight)
		{
			hasPlayerInSight = true;
			timeSpentWaitingForPlayer = 0f;
			timeSinceNoticingFirstPlayer = 0f;
			ButlerNoticePlayerServerRpc();
			if (killedLastTarget)
			{
				if (playersInVicinity < 2 && !Physics.Linecast(((Component)targetPlayer.gameplayCamera).transform.position, ((Component)lastMurderedTarget.deadBody.bodyParts[6]).transform.position + Vector3.up * 0.5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					killedLastTarget = false;
					startedCrimeSceneTimer = false;
					SwitchToBehaviourStateOnLocalClient(2);
					SwitchOwnershipAndSetToStateServerRpc(2, targetPlayer.actualClientId);
					Debug.Log((object)"Found a player; Caught red-handed, entering murder state");
					for (int i = 0; i < seenPlayers.Length; i++)
					{
						Debug.Log((object)$"Seen player {i}: {seenPlayers[i]}");
					}
				}
				else
				{
					killedLastTarget = false;
					startedCrimeSceneTimer = false;
					leaveCrimeSceneTimer = 0f;
					creatureAnimator.SetInteger("HeldItem", 1);
					creatureAnimator.SetBool("Running", false);
					SyncKilledLastTargetFalseClientRpc();
					PingAttention(4, 0.6f, ((Component)lastMurderedTarget.deadBody.bodyParts[0]).transform.position);
				}
			}
			if (roamAndSweepFloor.inProgress)
			{
				StopSearch(roamAndSweepFloor);
			}
			if (!hoverAroundTargetPlayer.inProgress)
			{
				StartSearch(((Component)targetPlayer).transform.position, hoverAroundTargetPlayer);
			}
			if (currentBehaviourStateIndex == 1 && (Object)(object)CheckLineOfSightForPlayer(120f, 50, 2) == (Object)(object)targetPlayer && playersInVicinity < 2 && timeSpentWaitingForPlayer > 8f)
			{
				SwitchToBehaviourStateOnLocalClient(2);
				SwitchOwnershipAndSetToStateServerRpc(2, targetPlayer.actualClientId);
				return;
			}
			premeditationTimeMultiplier -= AIIntervalTime * 0.04f;
			if (!checkedForTargetedPlayerPosition && Time.realtimeSinceStartup - timeOfLastSeenPlayers[targetPlayer.playerClientId] > 4f)
			{
				checkedForTargetedPlayerPosition = true;
				PingAttention(4, 0.8f, lastSeenPlayerPositions[targetPlayer.playerClientId]);
			}
		}
		if (madlySearchingForPlayers)
		{
			madlySearchingForPlayers = false;
			SyncSearchingMadlyServerRpc(isSearching: false);
			roamAndSweepFloor.searchPrecision = 10f;
		}
		if (Time.realtimeSinceStartup - timeAtLastButlerDamage < 3f)
		{
			SwitchToBehaviourStateOnLocalClient(2);
			SwitchOwnershipAndSetToStateServerRpc(2, targetPlayer.actualClientId);
			return;
		}
		if (berserkModeTimer <= 0f)
		{
			ButlerEnemyAI[] array = Object.FindObjectsByType<ButlerEnemyAI>((FindObjectsSortMode)0);
			for (int j = 0; j < array.Length; j++)
			{
				if (array[j].berserkModeTimer > 2f && Vector3.Distance(((Component)array[j]).transform.position, ((Component)this).transform.position) < 15f && !Physics.Linecast(eye.position, array[j].eye.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					berserkModeTimer = array[j].berserkModeTimer;
					break;
				}
			}
		}
		if (playersInVicinity > 1 && currentBehaviourStateIndex == 1 && berserkModeTimer <= 0f)
		{
			SwitchToBehaviourState(0);
		}
		else if (trackingTargetPlayerDownToMurder || berserkModeTimer > 0f)
		{
			PlayerControllerB playerControllerB = CheckLineOfSightForPlayer(100f, 50, 2);
			if ((Object)(object)playerControllerB != (Object)null)
			{
				if ((Object)(object)playerControllerB == (Object)(object)targetPlayer)
				{
					SwitchToBehaviourStateOnLocalClient(2);
					SwitchOwnershipAndSetToStateServerRpc(2, targetPlayer.actualClientId, berserkModeTimer);
				}
				else
				{
					SwitchToBehaviourState(0);
				}
			}
		}
		hoverAroundTargetPlayer.currentSearchStartPosition = ((Component)targetPlayer).transform.position;
		if (timeSinceCheckingForMultiplePlayers > timeUntilNextCheck && timeSinceNoticingFirstPlayer > 1.5f)
		{
			StartCheckForPlayers();
		}
		else
		{
			timeSinceCheckingForMultiplePlayers += AIIntervalTime;
		}
		if (timeSinceSeeingMultiplePlayers > waitForTime * premeditationTimeMultiplier && !trackingTargetPlayerDownToMurder)
		{
			if (timeSinceCheckingForMultiplePlayers > 5f)
			{
				StartCheckForPlayers();
			}
			else
			{
				if (!(timeSinceCheckingForMultiplePlayers > 2f) || !(timeSinceCheckingForMultiplePlayers < 4f))
				{
					return;
				}
				if (currentBehaviourStateIndex == 0)
				{
					if ((Object)(object)targetPlayer == (Object)(object)targetedPlayerAlonePreviously)
					{
						SwitchOwnershipAndSetToStateServerRpc(2, targetPlayer.actualClientId);
					}
					else
					{
						SwitchToBehaviourState(1);
					}
				}
				else if (currentBehaviourStateIndex == 1)
				{
					trackingTargetPlayerDownToMurder = true;
					PingAttention(4, 0.5f, lastSeenPlayerPositions[targetPlayer.playerClientId]);
				}
			}
		}
		else
		{
			timeSinceSeeingMultiplePlayers += AIIntervalTime;
		}
	}

	private void ForgetSeenPlayers()
	{
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < timeOfLastSeenPlayers.Length; i++)
		{
			if (seenPlayers[i])
			{
				if (StartOfRound.Instance.allPlayerScripts[i].isPlayerDead)
				{
					seenPlayers[i] = false;
				}
				float num = Time.realtimeSinceStartup - timeOfLastSeenPlayers[i];
				float num2 = ((i != (int)targetPlayer.playerClientId) ? 6f : 12f);
				if (num > num2 || (Time.realtimeSinceStartup - timeOfLastSeenPlayers[i] > 2f && timeSinceCheckingForMultiplePlayers > 2f && timeSinceCheckingForMultiplePlayers < 4f))
				{
					seenPlayers[i] = false;
				}
			}
		}
		if (currentBehaviourStateIndex != 2 && (Object)(object)targetPlayer != (Object)null && Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.7f, ((Component)targetPlayer.gameplayCamera).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1) && isSweeping)
		{
			isSweeping = false;
			SetSweepingAnimServerRpc(sweeping: false);
		}
	}

	public override void DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		base.DetectNoise(noisePosition, noiseLoudness, timesPlayedInOneSpot, noiseID);
		if ((!((NetworkBehaviour)this).IsOwner && noiseID != 75) || isEnemyDead || Time.realtimeSinceStartup - timeAtLastHeardNoise < 3f || Vector3.Distance(noisePosition, ((Component)this).transform.position + Vector3.up * 0.4f) < 0.75f || ((Object)(object)targetPlayer != (Object)null && Time.realtimeSinceStartup - timeOfLastSeenPlayers[targetPlayer.playerClientId] < 7f && Vector3.Distance(noisePosition + Vector3.up * 0.4f, ((Component)targetPlayer).transform.position) < 1f) || (currentBehaviourStateIndex == 2 && (Vector3.Angle(((Component)this).transform.forward, noisePosition - ((Component)this).transform.position) < 60f || (!lostPlayerInChase && Vector3.Distance(((Component)targetPlayer).transform.position, noisePosition) < 2f))))
		{
			return;
		}
		float num = Vector3.Distance(noisePosition, ((Component)this).transform.position);
		float num2 = noiseLoudness / num;
		if (Physics.Linecast(((Component)this).transform.position, noisePosition, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			num2 *= 0.5f;
		}
		if (pingAttentionTimer > 0f)
		{
			if (focusLevel >= 3)
			{
				if (num > 3f || num2 <= 0.12f)
				{
					return;
				}
			}
			else if (focusLevel == 2)
			{
				if (num > 25f || num2 <= 0.09f)
				{
					return;
				}
			}
			else if (focusLevel <= 1 && (num > 40f || num2 <= 0.06f))
			{
				return;
			}
		}
		if (!(num2 <= 0.03f))
		{
			timeAtLastHeardNoise = Time.realtimeSinceStartup;
			PingAttention(3, 0.5f, noisePosition + Vector3.up * 0.6f);
		}
	}

	public override void Update()
	{
		//IL_0521: Unknown result type (might be due to invalid IL or missing references)
		//IL_0526: Unknown result type (might be due to invalid IL or missing references)
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_0535: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0805: Unknown result type (might be due to invalid IL or missing references)
		//IL_080a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0770: Unknown result type (might be due to invalid IL or missing references)
		//IL_0775: Unknown result type (might be due to invalid IL or missing references)
		//IL_077f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0784: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead)
		{
			ambience2.volume = Mathf.Lerp(ambience2.volume, 0f, AIIntervalTime * 9f);
		}
		if (!ventAnimationFinished || isEnemyDead)
		{
			creatureAnimator.SetLayerWeight(1, 0f);
		}
		else
		{
			creatureAnimator.SetLayerWeight(1, 1f);
		}
		if (isEnemyDead || StartOfRound.Instance.allPlayersDead)
		{
			return;
		}
		timeSinceLastSpecialAnimation += Time.deltaTime;
		if (berserkModeTimer > 0f)
		{
			timeSinceChangingItem += Time.deltaTime * 6f;
		}
		else
		{
			timeSinceChangingItem += Time.deltaTime;
		}
		timeSinceHittingPlayer += Time.deltaTime;
		timeSinceNoticingFirstPlayer += Time.deltaTime;
		pingAttentionTimer -= Time.deltaTime;
		timeSincePingingAttention += Time.deltaTime;
		berserkModeTimer -= Time.deltaTime;
		CalculateAnimationDirection();
		if (((NetworkBehaviour)this).IsOwner)
		{
			CheckLOS();
			ForgetSeenPlayers();
		}
		AnimateLooking();
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (previousBehaviourState != currentBehaviourStateIndex)
			{
				if ((Object)(object)targetPlayer != (Object)null)
				{
					Debug.Log((object)$"Target player: {targetPlayer.playerClientId}; is dead?: {targetPlayer.isPlayerDead}");
				}
				creatureSFX.PlayOneShot(enemyType.audioClips[1]);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[1]);
				timeSinceChangingItem = 0f;
				buzzingAmbience.pitch = 1f;
				buzzingAmbience.volume = 0.6f;
				checkedForTargetedPlayerPosition = false;
				timeSinceSeeingMultiplePlayers = 0f;
				movingTowardsTargetPlayer = false;
				trackingTargetPlayerDownToMurder = false;
				addPlayerVelocityToDestination = 0f;
				agent.acceleration = 26f;
				previousBehaviourState = currentBehaviourStateIndex;
			}
			if (killedLastTarget || madlySearchingForPlayers)
			{
				creatureAnimator.SetInteger("HeldItem", 0);
				creatureAnimator.SetBool("Running", true);
			}
			else
			{
				creatureAnimator.SetInteger("HeldItem", 1);
				creatureAnimator.SetBool("Running", false);
			}
			if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.75f, 70f, 30, 2f))
			{
				ambience1.volume = Mathf.Lerp(ambience1.volume, 1f, Time.deltaTime * 1.5f);
			}
			else
			{
				ambience1.volume = Mathf.Lerp(ambience1.volume, 0f, Time.deltaTime * 8f);
			}
			if (murderMusicAudio.isPlaying && murderMusicAudio.volume <= 0.01f)
			{
				murderMusicAudio.Stop();
			}
			if (!ambience1.isPlaying)
			{
				ambience1.Play();
			}
			startedMurderMusic = false;
			if (!((NetworkBehaviour)this).IsOwner)
			{
				break;
			}
			SetButlerWalkSpeed();
			if (timeSinceNoticingFirstPlayer > 1f && !madlySearchingForPlayers)
			{
				if (sweepFloorTimer <= 0f)
				{
					sweepFloorTimer = Random.Range(3.5f, 8f);
					isSweeping = !isSweeping;
					SetSweepingAnimServerRpc(isSweeping);
				}
				else
				{
					sweepFloorTimer -= Time.deltaTime;
				}
			}
			break;
		case 1:
			if (previousBehaviourState != currentBehaviourStateIndex)
			{
				creatureAnimator.SetInteger("HeldItem", 0);
				creatureSFX.PlayOneShot(enemyType.audioClips[1]);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[1]);
				creatureAnimator.SetBool("Sweeping", false);
				creatureAnimator.SetBool("Running", false);
				sweepingAudio.Stop();
				isSweeping = false;
				buzzingAmbience.pitch = 1.15f;
				buzzingAmbience.volume = 0.8f;
				checkedForTargetedPlayerPosition = false;
				movingTowardsTargetPlayer = false;
				startedCrimeSceneTimer = false;
				killedLastTarget = false;
				madlySearchingForPlayers = false;
				previousBehaviourState = currentBehaviourStateIndex;
			}
			if (murderMusicAudio.isPlaying && murderMusicAudio.volume <= 0.01f)
			{
				murderMusicAudio.Stop();
			}
			if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.75f, 70f, 30, 2f))
			{
				ambience1.volume = Mathf.Lerp(ambience1.volume, 1f, Time.deltaTime * 0.75f);
			}
			else
			{
				ambience1.volume = Mathf.Lerp(ambience1.volume, 0f, Time.deltaTime * 8f);
			}
			SetButlerWalkSpeed();
			break;
		case 2:
			if (previousBehaviourState != currentBehaviourStateIndex)
			{
				creatureAnimator.SetInteger("HeldItem", 2);
				creatureSFX.PlayOneShot(enemyType.audioClips[2]);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, enemyType.audioClips[2]);
				timeSinceChangingItem = 0f;
				creatureAnimator.SetBool("Sweeping", false);
				sweepingAudio.Stop();
				buzzingAmbience.pitch = 1.5f;
				buzzingAmbience.volume = 1f;
				if (roamAndSweepFloor.inProgress)
				{
					StopSearch(roamAndSweepFloor);
				}
				if (hoverAroundTargetPlayer.inProgress)
				{
					StopSearch(hoverAroundTargetPlayer);
				}
				ambushSpeedMeter = 1f;
				startedCrimeSceneTimer = false;
				killedLastTarget = false;
				madlySearchingForPlayers = false;
				hasPlayerInSight = false;
				previousBehaviourState = currentBehaviourStateIndex;
			}
			addPlayerVelocityToDestination = Mathf.Lerp(addPlayerVelocityToDestination, 2f, Time.deltaTime);
			if (timeSinceChangingItem > 1.7f)
			{
				ambushSpeedMeter = Mathf.Max(ambushSpeedMeter - Time.deltaTime * 1.2f, 0f);
			}
			if (lostPlayerInChase && ((NetworkBehaviour)this).IsOwner)
			{
				if (startedMurderMusic && murderMusicAudio.isPlaying && murderMusicAudio.volume <= 0.01f)
				{
					murderMusicAudio.Stop();
				}
				break;
			}
			if (!startedMurderMusic)
			{
				if (GameNetworkManager.Instance.localPlayerController.isInsideFactory && GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.7f, 100f, 18, 1f))
				{
					startedMurderMusic = true;
				}
				break;
			}
			ambience1.volume = Mathf.Lerp(ambience1.volume, 0f, Time.deltaTime * 7f);
			if (GameNetworkManager.Instance.localPlayerController.isInsideFactory)
			{
				if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.7f, 100f, 18, 1f))
				{
					murderMusicVolume = Mathf.Max(murderMusicVolume, Mathf.Lerp(murderMusicVolume, 0.7f, Time.deltaTime * 3f));
				}
				else
				{
					murderMusicVolume = Mathf.Max(murderMusicVolume, Mathf.Lerp(murderMusicVolume, 0.36f, Time.deltaTime * 3f));
				}
				increaseMurderMusicVolume = true;
			}
			if (ambience1.isPlaying && ambience1.volume <= 0.01f)
			{
				ambience1.Stop();
			}
			if (!murderMusicAudio.isPlaying)
			{
				murderMusicAudio.Play();
			}
			break;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncSearchingMadlyServerRpc(bool isSearching)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2190308677u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isSearching, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2190308677u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				madlySearchingForPlayers = isSearching;
				SyncSearchingMadlyClientRpc(isSearching);
			}
		}
	}

	[ClientRpc]
	public void SyncSearchingMadlyClientRpc(bool isSearching)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2530454374u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isSearching, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2530454374u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				madlySearchingForPlayers = isSearching;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncKilledLastTargetServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(975656535u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 975656535u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				killedLastTarget = true;
				lastMurderedTarget = StartOfRound.Instance.allPlayerScripts[playerId];
				SyncKilledLastTargetClientRpc();
			}
		}
	}

	[ClientRpc]
	public void SyncKilledLastTargetClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(670254571u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 670254571u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				killedLastTarget = true;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncKilledLastTargetFalseServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1587139060u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1587139060u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				killedLastTarget = false;
				SyncKilledLastTargetClientRpc();
			}
		}
	}

	[ClientRpc]
	public void SyncKilledLastTargetFalseClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(657734107u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 657734107u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				Debug.Log((object)"Client received sync killed last target false client rpc");
				killedLastTarget = false;
			}
		}
	}

	[ServerRpc]
	public void SwitchOwnershipAndSetToStateServerRpc(int state, ulong newOwner, float berserkTimer = -1f)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3982620855u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, state);
			BytePacker.WriteValueBitPacked(val2, newOwner);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref berserkTimer, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3982620855u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && StartOfRound.Instance.ClientPlayerList.TryGetValue(newOwner, out var value))
		{
			if (((Component)this).gameObject.GetComponent<NetworkObject>().OwnerClientId != newOwner)
			{
				thisNetworkObject.ChangeOwnership(newOwner);
			}
			else
			{
				Debug.LogError((object)"Butler Error: SwitchOwnerShipAndSetToStateServerRpc tried to set owner to a player that is already the owner on the server");
			}
			currentOwnershipOnThisClient = value;
			targetPlayer = StartOfRound.Instance.allPlayerScripts[value];
			watchingPlayer = targetPlayer;
			if (berserkTimer != -1f)
			{
				berserkModeTimer = berserkTimer;
			}
			SwitchOwnershipAndSetToStateClientRpc(value, state, berserkModeTimer);
		}
	}

	[ClientRpc]
	public void SwitchOwnershipAndSetToStateClientRpc(int playerVal, int state, float berserkTimer)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2060562543u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerVal);
				BytePacker.WriteValueBitPacked(val2, state);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref berserkTimer, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2060562543u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				currentOwnershipOnThisClient = playerVal;
				SwitchToBehaviourStateOnLocalClient(state);
				targetPlayer = StartOfRound.Instance.allPlayerScripts[playerVal];
				watchingPlayer = targetPlayer;
				berserkModeTimer = berserkTimer;
			}
		}
	}

	public void SetButlerWalkSpeed()
	{
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (timeSinceCheckingForMultiplePlayers < 2f || timeSinceChangingItem < 2f || isSweeping || stunNormalizedTimer > 0f)
		{
			agent.speed = 0f;
		}
		else if (trackingTargetPlayerDownToMurder || creatureAnimator.GetBool("Running"))
		{
			if (currentBehaviourStateIndex == 2)
			{
				agent.speed = idleMovementSpeedBase + 5f + 4f * ambushSpeedMeter;
				agent.acceleration = 38f + 16f * ambushSpeedMeter;
			}
			agent.speed = idleMovementSpeedBase + 5f;
		}
		else
		{
			agent.speed = idleMovementSpeedBase;
		}
	}

	private void StartCheckForPlayers()
	{
		timeSinceCheckingForMultiplePlayers = 0f;
		timeUntilNextCheck = Random.Range(8f, 11f);
		TurnAndCheckForPlayers();
		Debug.Log((object)"Butler: Checking for players");
	}

	[ServerRpc]
	public void SetButlerRunningServerRpc(bool isRunning)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3907946013u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isRunning, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3907946013u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetButlerRunningClientRpc(isRunning);
		}
	}

	[ClientRpc]
	public void SetButlerRunningClientRpc(bool isRunning)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(4157200979u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref isRunning, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 4157200979u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				creatureAnimator.SetBool("Running", isRunning);
			}
		}
	}

	[ServerRpc]
	public void SetSweepingAnimServerRpc(bool sweeping)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2751847406u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref sweeping, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2751847406u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetSweepingAnimClientRpc(sweeping);
		}
	}

	[ClientRpc]
	public void SetSweepingAnimClientRpc(bool sweeping)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3652150845u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref sweeping, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3652150845u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				creatureAnimator.SetBool("Sweeping", sweeping);
				sweepingAudio.Play();
			}
		}
	}

	private void CalculateAnimationDirection(float maxSpeed = 1f)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		agentLocalVelocity = animationContainer.InverseTransformDirection(Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 2f));
		velX = Mathf.Lerp(velX, agentLocalVelocity.x, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("MoveX", Mathf.Clamp(velX, 0f - maxSpeed, maxSpeed));
		velZ = Mathf.Lerp(velZ, agentLocalVelocity.z, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("MoveZ", Mathf.Clamp(velZ, 0f - maxSpeed, maxSpeed));
		previousPosition = ((Component)this).transform.position;
	}

	public void PingAttention(int newFocusLevel, float timeToLook, Vector3 attentionPosition, bool sync = true)
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		if ((pingAttentionTimer >= 0f && newFocusLevel < focusLevel) || (currentBehaviourStateIndex == 0 && timeSincePingingAttention < 0.5f) || (currentBehaviourStateIndex == 1 && timeSincePingingAttention < 0.2f) || (currentBehaviourStateIndex == 2 && timeSincePingingAttention < 1f))
		{
			return;
		}
		if (berserkModeTimer > 0f)
		{
			if (timeSincePingingAttention < 4f)
			{
				return;
			}
			timeToLook *= 0.5f;
		}
		Debug.Log((object)"Butler: pinged attention to position");
		Debug.DrawLine(eye.position, attentionPosition, Color.yellow, timeToLook);
		focusLevel = newFocusLevel;
		pingAttentionTimer = timeToLook;
		pingAttentionPosition = attentionPosition;
		if (sync)
		{
			PingButlerAttentionServerRpc(timeToLook, attentionPosition);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void PingButlerAttentionServerRpc(float timeToLook, Vector3 attentionPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1640413327u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToLook, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref attentionPosition);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1640413327u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PingButlerAttentionClientRpc(timeToLook, attentionPosition);
			}
		}
	}

	[ClientRpc]
	public void PingButlerAttentionClientRpc(float timeToLook, Vector3 attentionPosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(112823024u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToLook, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref attentionPosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 112823024u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsOwner)
			{
				pingAttentionTimer = timeToLook;
				pingAttentionPosition = attentionPosition;
			}
		}
	}

	[ServerRpc]
	public void ButlerNoticePlayerServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2544993960u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2544993960u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			ButlerNoticePlayerClientRpc();
		}
	}

	[ClientRpc]
	public void ButlerNoticePlayerClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(515028741u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 515028741u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				timeSinceNoticingFirstPlayer = 0f;
				hasPlayerInSight = true;
				pingAttentionTimer = -1f;
			}
		}
	}

	public void TurnAndCheckForPlayers()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
		float num = RoundManager.Instance.YRotationThatFacesTheFarthestFromPosition(((Component)this).transform.position, 40f, 8);
		CheckForPlayersServerRpc(Random.Range(0.4f, 0.8f), Random.Range(0.4f, 0.8f), (int)num);
	}

	[ServerRpc]
	public void CheckForPlayersServerRpc(float timeToCheck, float timeToCheckB, int yRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3725839143u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToCheck, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToCheckB, default(ForPrimitives));
			BytePacker.WriteValueBitPacked(val2, yRot);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3725839143u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			CheckForPlayersClientRpc(timeToCheck, timeToCheckB, yRot);
		}
	}

	[ClientRpc]
	public void CheckForPlayersClientRpc(float timeToCheck, float timeToCheckB, int yRot)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2363265612u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToCheck, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeToCheckB, default(ForPrimitives));
			BytePacker.WriteValueBitPacked(val2, yRot);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2363265612u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (checkForPlayersCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(checkForPlayersCoroutine);
			}
			checkForPlayersCoroutine = ((MonoBehaviour)this).StartCoroutine(CheckForPlayersAnim(timeToCheck, timeToCheckB, yRot));
		}
	}

	private IEnumerator CheckForPlayersAnim(float timeToCheck, float timeToCheckB, int yRot)
	{
		RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
		RoundManager.Instance.tempTransform.eulerAngles = new Vector3(0f, (float)yRot, 0f);
		PingAttention(2, 2f, ((Component)this).transform.position + Vector3.up * 0.4f + RoundManager.Instance.tempTransform.forward * 14f, sync: false);
		yield return (object)new WaitForSeconds(timeToCheck);
		RoundManager.Instance.tempTransform.position = ((Component)this).transform.position;
		RoundManager.Instance.tempTransform.eulerAngles = new Vector3(0f, (float)yRot + 144f * timeToCheckB, 0f);
		PingAttention(2, 2f, ((Component)this).transform.position + Vector3.up * 0.4f + RoundManager.Instance.tempTransform.forward * 14f, sync: false);
	}

	private void AnimateLooking()
	{
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0560: Unknown result type (might be due to invalid IL or missing references)
		//IL_056b: Unknown result type (might be due to invalid IL or missing references)
		//IL_057b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0372: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0437: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_044e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0469: Unknown result type (might be due to invalid IL or missing references)
		//IL_0478: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_030d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		if (stunNormalizedTimer > 0f)
		{
			agent.angularSpeed = 220f;
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 0f, Time.deltaTime * 16f);
			return;
		}
		bool flag = false;
		if (Object.op_Implicit((Object)(object)watchingPlayer) && currentBehaviourStateIndex != 2 && timeSinceNoticingFirstPlayer > 1f && Time.realtimeSinceStartup - timeSinceStealthStab > 3f)
		{
			flag = watchingPlayer.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.7f, 30f, 50);
		}
		if (pingAttentionTimer >= 0f && timeSinceNoticingFirstPlayer > 1f)
		{
			lookTarget.position = Vector3.Lerp(lookTarget.position, pingAttentionPosition, 12f * Time.deltaTime);
			flag = false;
		}
		else
		{
			if (!((Object)(object)watchingPlayer != (Object)null) || Physics.Linecast(((Component)this).transform.position + Vector3.up * 0.6f, ((Component)watchingPlayer.gameplayCamera).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				agent.angularSpeed = 220f;
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 0f, Time.deltaTime * 16f);
				return;
			}
			lookTarget.position = Vector3.Lerp(lookTarget.position, ((Component)watchingPlayer.gameplayCamera).transform.position, 10f * Time.deltaTime);
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (flag)
			{
				float num = Vector3.Angle(((Component)this).transform.forward, Vector3.Scale(new Vector3(1f, 0f, 1f), lookTarget.position - ((Component)this).transform.position));
				if (num < 22f)
				{
					if (velZ >= 0f)
					{
						agent.angularSpeed = 0f;
						if (Vector3.Dot(new Vector3(lookTarget.position.x, ((Component)this).transform.position.y, lookTarget.position.z) - ((Component)this).transform.position, ((Component)this).transform.right) > 0f)
						{
							Transform transform = ((Component)this).transform;
							transform.rotation *= Quaternion.Euler(0f, -55f * Time.deltaTime, 0f);
						}
						else
						{
							Transform transform2 = ((Component)this).transform;
							transform2.rotation *= Quaternion.Euler(0f, 55f * Time.deltaTime, 0f);
						}
					}
					else
					{
						agent.angularSpeed = 220f;
					}
				}
				else if (num > 30f)
				{
					agent.angularSpeed = 220f;
				}
				else
				{
					agent.angularSpeed = 25f;
				}
			}
			else if (currentBehaviourStateIndex == 2 || Vector3.Angle(((Component)this).transform.forward, Vector3.Scale(new Vector3(1f, 0f, 1f), lookTarget.position - ((Component)this).transform.position)) > 15f)
			{
				agent.angularSpeed = 0f;
				turnCompass.LookAt(lookTarget);
				turnCompass.eulerAngles = new Vector3(0f, turnCompass.eulerAngles.y, 0f);
				float num2 = 3f;
				if (berserkModeTimer > 0f && timeSinceChangingItem < 3f)
				{
					num2 = 10f;
				}
				((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, turnCompass.rotation, num2 * Time.deltaTime);
				((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.localEulerAngles.y, 0f);
			}
		}
		if (flag)
		{
			((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 0f, 15f * Time.deltaTime);
		}
		else
		{
			float num3 = Vector3.Angle(((Component)this).transform.forward, lookTarget.position - ((Component)this).transform.position);
			if (num3 > 22f)
			{
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 1f * (Mathf.Abs(num3 - 180f) / 180f), Time.deltaTime * 11f);
			}
			else
			{
				((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight = Mathf.Lerp(((RigConstraint<MultiAimConstraintJob, MultiAimConstraintData, MultiAimConstraintJobBinder<MultiAimConstraintData>>)(object)headLookRig).weight, 1f, Time.deltaTime * 11f);
			}
		}
		headLookTarget.position = Vector3.Lerp(headLookTarget.position, lookTarget.position, 8f * Time.deltaTime);
	}

	private void StartAnimation(int anim)
	{
		if (!isEnemyDead)
		{
			timeSinceLastSpecialAnimation = 0f;
			StartAnimationServerRpc(anim);
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (isEnemyDead)
		{
			return;
		}
		if (currentBehaviourStateIndex != 2)
		{
			if (Time.realtimeSinceStartup - timeSinceStealthStab < 10f)
			{
				return;
			}
			timeSinceStealthStab = Time.realtimeSinceStartup;
			if (Random.Range(0, 100) < 95)
			{
				return;
			}
		}
		if (timeSinceHittingPlayer < 0.25f)
		{
			return;
		}
		PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
		if (!((Object)(object)playerControllerB != (Object)null))
		{
			return;
		}
		timeSinceHittingPlayer = 0f;
		if ((Object)(object)playerControllerB == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			if (currentBehaviourStateIndex != 2)
			{
				berserkModeTimer = 3f;
			}
			playerControllerB.DamagePlayer(10, hasDamageSFX: true, callRPC: true, CauseOfDeath.Stabbing);
			StabPlayerServerRpc((int)playerControllerB.playerClientId, currentBehaviourStateIndex != 2);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void StabPlayerServerRpc(int playerId, bool setBerserkMode)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(939171591u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setBerserkMode, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 939171591u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (setBerserkMode)
			{
				berserkModeTimer = 3f;
				targetPlayer = StartOfRound.Instance.allPlayerScripts[playerId];
				watchingPlayer = targetPlayer;
				SwitchOwnershipAndSetToStateServerRpc(2, targetPlayer.actualClientId);
				seenPlayers[playerId] = true;
			}
			StabPlayerClientRpc(playerId, setBerserkMode);
		}
	}

	[ClientRpc]
	public void StabPlayerClientRpc(int playerId, bool setBerserkMode)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3839735893u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setBerserkMode, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3839735893u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				timeSinceStealthStab = Time.realtimeSinceStartup;
				creatureAnimator.SetTrigger("Stab");
				stabBloodParticle.Play(true);
				creatureSFX.PlayOneShot(enemyType.audioClips[0]);
			}
		}
	}

	[ServerRpc]
	public void StartAnimationServerRpc(int animationId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(581084606u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, animationId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 581084606u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !isEnemyDead && enemyType.miscAnimations.Length > animationId && !((Object)(object)creatureVoice == (Object)null) && (currentSpecialAnimation == -1 || enemyType.miscAnimations[currentSpecialAnimation].priority <= enemyType.miscAnimations[animationId].priority))
		{
			StartAnimationClientRpc(animationId);
		}
	}

	[ClientRpc]
	public void StartAnimationClientRpc(int animationId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2091884461u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, animationId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2091884461u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !isEnemyDead && enemyType.miscAnimations.Length > animationId && !((Object)(object)creatureVoice == (Object)null) && (currentSpecialAnimation == -1 || enemyType.miscAnimations[currentSpecialAnimation].priority <= enemyType.miscAnimations[animationId].priority))
		{
			currentSpecialAnimation = animationId;
			if (!inSpecialAnimation || doingKillAnimation)
			{
				creatureVoice.pitch = Random.Range(0.8f, 1.2f);
				creatureVoice.PlayOneShot(enemyType.miscAnimations[animationId].AnimVoiceclip, Random.Range(0.6f, 1f));
				WalkieTalkie.TransmitOneShotAudio(creatureVoice, enemyType.miscAnimations[animationId].AnimVoiceclip, 0.7f);
				creatureAnimator.ResetTrigger(enemyType.miscAnimations[animationId].AnimString);
				creatureAnimator.SetTrigger(enemyType.miscAnimations[animationId].AnimString);
			}
		}
	}

	public void CheckLOS()
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		float num2 = 10000f;
		int num3 = -1;
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if (StartOfRound.Instance.allPlayerScripts[i].isPlayerDead || !StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled)
			{
				seenPlayers[i] = false;
				continue;
			}
			if (CheckLineOfSightForPosition(((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position, 110f, 60, 2f))
			{
				num++;
				lastSeenPlayerPositions[i] = ((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position;
				seenPlayers[i] = true;
				timeOfLastSeenPlayers[i] = Time.realtimeSinceStartup;
			}
			else if (seenPlayers[i])
			{
				num++;
			}
			if (seenPlayers[i])
			{
				float num4 = Vector3.Distance(eye.position, ((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position);
				if (num4 < num2)
				{
					num2 = num4;
					num3 = i;
				}
			}
		}
		if (num > 1)
		{
			timeSinceSeeingMultiplePlayers = 0f;
		}
		playersInVicinity = num;
		if (currentBehaviourStateIndex == 2)
		{
			return;
		}
		if (num3 != -1)
		{
			watchingPlayer = StartOfRound.Instance.allPlayerScripts[num3];
			if (currentBehaviourStateIndex != 2)
			{
				targetPlayer = watchingPlayer;
			}
		}
		if (Time.realtimeSinceStartup - timeAtLastTargetPlayerSync > 0.25f && (Object)(object)syncedTargetPlayer != (Object)(object)targetPlayer)
		{
			timeAtLastTargetPlayerSync = Time.realtimeSinceStartup;
			syncedTargetPlayer = targetPlayer;
			SyncTargetServerRpc((int)targetPlayer.playerClientId);
		}
	}

	[ServerRpc]
	public void SyncTargetServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1143004490u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1143004490u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncTargetClientRpc(playerId);
		}
	}

	[ClientRpc]
	public void SyncTargetClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1535807017u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1535807017u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				watchingPlayer = StartOfRound.Instance.allPlayerScripts[playerId];
				targetPlayer = watchingPlayer;
				syncedTargetPlayer = targetPlayer;
			}
		}
	}

	public override void AnimationEventA()
	{
		base.AnimationEventA();
		if (!(Mathf.Abs(velX + velZ) < 0.14f) && !(Time.realtimeSinceStartup - timeAtLastFootstep < 0.07f))
		{
			timeAtLastFootstep = Time.realtimeSinceStartup;
			int num = Random.Range(0, footsteps.Length);
			if (!((Object)(object)footsteps[num] == (Object)null))
			{
				creatureSFX.PlayOneShot(footsteps[num]);
				WalkieTalkie.TransmitOneShotAudio(creatureSFX, footsteps[num]);
			}
		}
	}

	public override void AnimationEventB()
	{
		base.AnimationEventB();
		int num = Random.Range(0, broomSweepSFX.Length);
		if (!((Object)(object)broomSweepSFX[num] == (Object)null))
		{
			creatureSFX.PlayOneShot(broomSweepSFX[num]);
			WalkieTalkie.TransmitOneShotAudio(creatureSFX, broomSweepSFX[num]);
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_ButlerEnemyAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Expected O, but got Unknown
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Expected O, but got Unknown
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Expected O, but got Unknown
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Expected O, but got Unknown
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2190308677u, new RpcReceiveHandler(__rpc_handler_2190308677));
		NetworkManager.__rpc_func_table.Add(2530454374u, new RpcReceiveHandler(__rpc_handler_2530454374));
		NetworkManager.__rpc_func_table.Add(975656535u, new RpcReceiveHandler(__rpc_handler_975656535));
		NetworkManager.__rpc_func_table.Add(670254571u, new RpcReceiveHandler(__rpc_handler_670254571));
		NetworkManager.__rpc_func_table.Add(1587139060u, new RpcReceiveHandler(__rpc_handler_1587139060));
		NetworkManager.__rpc_func_table.Add(657734107u, new RpcReceiveHandler(__rpc_handler_657734107));
		NetworkManager.__rpc_func_table.Add(3982620855u, new RpcReceiveHandler(__rpc_handler_3982620855));
		NetworkManager.__rpc_func_table.Add(2060562543u, new RpcReceiveHandler(__rpc_handler_2060562543));
		NetworkManager.__rpc_func_table.Add(3907946013u, new RpcReceiveHandler(__rpc_handler_3907946013));
		NetworkManager.__rpc_func_table.Add(4157200979u, new RpcReceiveHandler(__rpc_handler_4157200979));
		NetworkManager.__rpc_func_table.Add(2751847406u, new RpcReceiveHandler(__rpc_handler_2751847406));
		NetworkManager.__rpc_func_table.Add(3652150845u, new RpcReceiveHandler(__rpc_handler_3652150845));
		NetworkManager.__rpc_func_table.Add(1640413327u, new RpcReceiveHandler(__rpc_handler_1640413327));
		NetworkManager.__rpc_func_table.Add(112823024u, new RpcReceiveHandler(__rpc_handler_112823024));
		NetworkManager.__rpc_func_table.Add(2544993960u, new RpcReceiveHandler(__rpc_handler_2544993960));
		NetworkManager.__rpc_func_table.Add(515028741u, new RpcReceiveHandler(__rpc_handler_515028741));
		NetworkManager.__rpc_func_table.Add(3725839143u, new RpcReceiveHandler(__rpc_handler_3725839143));
		NetworkManager.__rpc_func_table.Add(2363265612u, new RpcReceiveHandler(__rpc_handler_2363265612));
		NetworkManager.__rpc_func_table.Add(939171591u, new RpcReceiveHandler(__rpc_handler_939171591));
		NetworkManager.__rpc_func_table.Add(3839735893u, new RpcReceiveHandler(__rpc_handler_3839735893));
		NetworkManager.__rpc_func_table.Add(581084606u, new RpcReceiveHandler(__rpc_handler_581084606));
		NetworkManager.__rpc_func_table.Add(2091884461u, new RpcReceiveHandler(__rpc_handler_2091884461));
		NetworkManager.__rpc_func_table.Add(1143004490u, new RpcReceiveHandler(__rpc_handler_1143004490));
		NetworkManager.__rpc_func_table.Add(1535807017u, new RpcReceiveHandler(__rpc_handler_1535807017));
	}

	private static void __rpc_handler_2190308677(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool isSearching = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isSearching, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).SyncSearchingMadlyServerRpc(isSearching);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2530454374(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool isSearching = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref isSearching, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).SyncSearchingMadlyClientRpc(isSearching);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_975656535(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).SyncKilledLastTargetServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_670254571(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).SyncKilledLastTargetClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1587139060(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).SyncKilledLastTargetFalseServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_657734107(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).SyncKilledLastTargetFalseClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3982620855(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		int state = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref state);
		ulong newOwner = default(ulong);
		ByteUnpacker.ReadValueBitPacked(reader, ref newOwner);
		float berserkTimer = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref berserkTimer, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((ButlerEnemyAI)(object)target).SwitchOwnershipAndSetToStateServerRpc(state, newOwner, berserkTimer);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_2060562543(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerVal = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerVal);
			int state = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref state);
			float berserkTimer = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref berserkTimer, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).SwitchOwnershipAndSetToStateClientRpc(playerVal, state, berserkTimer);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3907946013(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool butlerRunningServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref butlerRunningServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).SetButlerRunningServerRpc(butlerRunningServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4157200979(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool butlerRunningClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref butlerRunningClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).SetButlerRunningClientRpc(butlerRunningClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2751847406(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool sweepingAnimServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref sweepingAnimServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).SetSweepingAnimServerRpc(sweepingAnimServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3652150845(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool sweepingAnimClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref sweepingAnimClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).SetSweepingAnimClientRpc(sweepingAnimClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1640413327(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timeToLook = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToLook, default(ForPrimitives));
			Vector3 attentionPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref attentionPosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).PingButlerAttentionServerRpc(timeToLook, attentionPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_112823024(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timeToLook = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToLook, default(ForPrimitives));
			Vector3 attentionPosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref attentionPosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).PingButlerAttentionClientRpc(timeToLook, attentionPosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2544993960(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).ButlerNoticePlayerServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_515028741(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).ButlerNoticePlayerClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3725839143(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		float timeToCheck = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToCheck, default(ForPrimitives));
		float timeToCheckB = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToCheckB, default(ForPrimitives));
		int yRot = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref yRot);
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((ButlerEnemyAI)(object)target).CheckForPlayersServerRpc(timeToCheck, timeToCheckB, yRot);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_2363265612(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timeToCheck = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToCheck, default(ForPrimitives));
			float timeToCheckB = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeToCheckB, default(ForPrimitives));
			int yRot = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref yRot);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).CheckForPlayersClientRpc(timeToCheck, timeToCheckB, yRot);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_939171591(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			bool setBerserkMode = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setBerserkMode, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).StabPlayerServerRpc(playerId, setBerserkMode);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3839735893(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			bool setBerserkMode = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setBerserkMode, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).StabPlayerClientRpc(playerId, setBerserkMode);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_581084606(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int animationId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref animationId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).StartAnimationServerRpc(animationId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2091884461(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int animationId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref animationId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).StartAnimationClientRpc(animationId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1143004490(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((ButlerEnemyAI)(object)target).SyncTargetServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1535807017(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((ButlerEnemyAI)(object)target).SyncTargetClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "ButlerEnemyAI";
	}
}
