using Unity.Netcode;

public struct ServerAudio : INetworkSerializable
{
	public NetworkObjectReference audioObj;

	public bool oneshot;

	public bool looped;

	public unsafe void NetworkSerialize<T>(BufferSerializer<T> serializer) where T : IReaderWriter
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		((BufferSerializer<NetworkObjectReference>*)(&serializer))->SerializeValue<NetworkObjectReference>(ref audioObj, default(ForNetworkSerializable));
		((BufferSerializer<bool>*)(&serializer))->SerializeValue<bool>(ref oneshot, default(ForPrimitives));
		if (!oneshot)
		{
			((BufferSerializer<bool>*)(&serializer))->SerializeValue<bool>(ref looped, default(ForPrimitives));
		}
	}
}
