using System.Collections;
using GameNetcodeStuff;
using TMPro;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class TerminalAccessibleObject : NetworkBehaviour
{
	public string objectCode;

	public float codeAccessCooldownTimer;

	private float currentCooldownTimer;

	private bool inCooldown;

	public InteractEvent terminalCodeEvent;

	public InteractEvent terminalCodeCooldownEvent;

	public bool setCodeRandomlyFromRoundManager = true;

	[Space(3f)]
	public MeshRenderer[] codeMaterials;

	public int rows;

	public int columns;

	[Space(3f)]
	public bool isBigDoor = true;

	private TextMeshProUGUI mapRadarText;

	private Image mapRadarBox;

	private Image mapRadarBoxSlider;

	private bool initializedValues;

	private bool playerHitDoorTrigger;

	private bool isDoorOpen;

	private bool isPoweredOn = true;

	public GameObject mapRadarObject;

	public void CallFunctionFromTerminal()
	{
		if (!inCooldown)
		{
			((UnityEvent<PlayerControllerB>)terminalCodeEvent).Invoke(GameNetworkManager.Instance.localPlayerController);
			if (codeAccessCooldownTimer > 0f)
			{
				currentCooldownTimer = codeAccessCooldownTimer;
				((MonoBehaviour)this).StartCoroutine(countCodeAccessCooldown());
			}
			Debug.Log((object)("calling terminal function for code : " + objectCode + "; object name: " + ((Object)((Component)this).gameObject).name));
		}
	}

	public void TerminalCodeCooldownReached()
	{
		((UnityEvent<PlayerControllerB>)terminalCodeCooldownEvent).Invoke((PlayerControllerB)null);
		Debug.Log((object)("cooldown reached for object with code : " + objectCode + "; object name: " + ((Object)((Component)this).gameObject).name));
	}

	private IEnumerator countCodeAccessCooldown()
	{
		inCooldown = true;
		if (!initializedValues)
		{
			InitializeValues();
		}
		Image cooldownBar = mapRadarBox;
		Image[] componentsInChildren = ((Component)mapRadarText).gameObject.GetComponentsInChildren<Image>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if ((int)componentsInChildren[i].type == 3)
			{
				cooldownBar = componentsInChildren[i];
			}
		}
		((Behaviour)cooldownBar).enabled = true;
		((Graphic)mapRadarText).color = Color.red;
		((Graphic)mapRadarBox).color = Color.red;
		while (currentCooldownTimer > 0f)
		{
			yield return null;
			currentCooldownTimer -= Time.deltaTime;
			cooldownBar.fillAmount = currentCooldownTimer / codeAccessCooldownTimer;
		}
		TerminalCodeCooldownReached();
		((Graphic)mapRadarText).color = Color.green;
		((Graphic)mapRadarBox).color = Color.green;
		currentCooldownTimer = 1.5f;
		int frameNum = 0;
		while (currentCooldownTimer > 0f)
		{
			yield return null;
			currentCooldownTimer -= Time.deltaTime;
			cooldownBar.fillAmount = Mathf.Abs(currentCooldownTimer / 1.5f - 1f);
			frameNum++;
			if (frameNum % 7 == 0)
			{
				((Behaviour)mapRadarText).enabled = !((Behaviour)mapRadarText).enabled;
			}
		}
		((Behaviour)mapRadarText).enabled = true;
		((Behaviour)cooldownBar).enabled = false;
		inCooldown = false;
	}

	public void OnPowerSwitch(bool switchedOn)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		isPoweredOn = switchedOn;
		if (!switchedOn)
		{
			((Graphic)mapRadarText).color = Color.gray;
			((Graphic)mapRadarBox).color = Color.gray;
			if (!isDoorOpen)
			{
				((Component)this).gameObject.GetComponent<AnimatedObjectTrigger>().SetBoolOnClientOnly(setTo: true);
			}
		}
		else if (!isDoorOpen)
		{
			((Graphic)mapRadarText).color = Color.red;
			((Graphic)mapRadarBox).color = Color.red;
			((Component)this).gameObject.GetComponent<AnimatedObjectTrigger>().SetBoolOnClientOnly(setTo: false);
		}
		else
		{
			((Graphic)mapRadarText).color = Color.green;
			((Graphic)mapRadarBox).color = Color.green;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetDoorOpenServerRpc(bool open)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1181174413u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref open, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1181174413u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SetDoorOpenClientRpc(open);
			}
		}
	}

	[ClientRpc]
	public void SetDoorOpenClientRpc(bool open)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(635686545u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref open, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 635686545u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				SetDoorOpen(open);
			}
		}
	}

	public void SetDoorToggleLocalClient()
	{
		if (isPoweredOn)
		{
			SetDoorOpen(!isDoorOpen);
			SetDoorOpenServerRpc(isDoorOpen);
		}
	}

	public void SetDoorLocalClient(bool open)
	{
		SetDoorOpen(open);
		SetDoorOpenServerRpc(isDoorOpen);
	}

	public void SetDoorOpen(bool open)
	{
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		if (isBigDoor && isDoorOpen != open && isPoweredOn)
		{
			isDoorOpen = open;
			if (open)
			{
				Debug.Log((object)("Setting door " + ((Object)((Component)this).gameObject).name + " with code " + objectCode + " to open"));
				((Graphic)mapRadarText).color = Color.green;
				((Graphic)mapRadarBox).color = Color.green;
			}
			else
			{
				Debug.Log((object)("Setting door " + ((Object)((Component)this).gameObject).name + " with code " + objectCode + " to closed"));
				((Graphic)mapRadarText).color = Color.red;
				((Graphic)mapRadarBox).color = Color.red;
			}
			Debug.Log((object)$"setting big door open for door {((Object)((Component)this).gameObject).name}; {isDoorOpen}; {open}");
			((Component)this).gameObject.GetComponent<AnimatedObjectTrigger>().SetBoolOnClientOnly(open);
		}
	}

	public void SetCodeTo(int codeIndex)
	{
		if (!setCodeRandomlyFromRoundManager)
		{
			return;
		}
		if (codeIndex > RoundManager.Instance.possibleCodesForBigDoors.Length)
		{
			Debug.LogError((object)"Attempted setting code to an index higher than the amount of possible codes in TerminalAccessibleObject");
			return;
		}
		objectCode = RoundManager.Instance.possibleCodesForBigDoors[codeIndex];
		SetMaterialUV(codeIndex);
		if ((Object)(object)mapRadarText == (Object)null)
		{
			InitializeValues();
		}
		((TMP_Text)mapRadarText).text = objectCode;
	}

	private void Start()
	{
		InitializeValues();
	}

	private void Update()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		if (GameNetworkManager.Instance.localPlayerController.isInHangarShipRoom || StartOfRound.Instance.mapScreen.overrideRadarCameraOnAlways)
		{
			if (Vector3.Distance(((Component)StartOfRound.Instance.mapScreen.mapCamera).transform.position, mapRadarObject.transform.position) < 8f)
			{
				mapRadarObject.transform.localScale = Vector3.Lerp(mapRadarObject.transform.localScale, new Vector3(1.8f, 1.8f, 1.8f), Time.deltaTime * 10f);
			}
			else
			{
				mapRadarObject.transform.localScale = Vector3.Lerp(mapRadarObject.transform.localScale, new Vector3(1f, 1f, 1f), Time.deltaTime * 10f);
			}
		}
	}

	public void InitializeValues()
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		if (initializedValues)
		{
			return;
		}
		initializedValues = true;
		mapRadarObject = Object.Instantiate<GameObject>(StartOfRound.Instance.objectCodePrefab, StartOfRound.Instance.mapScreen.mapCameraStationaryUI, false);
		Debug.Log((object)$"{((Object)((Component)this).gameObject).name} creating doorcode object in parent {StartOfRound.Instance.mapScreen.mapCameraStationaryUI}: {((Object)mapRadarObject).name}");
		RectTransform component = mapRadarObject.GetComponent<RectTransform>();
		((Transform)component).position = ((Component)this).transform.position + Vector3.up * 1.35f;
		((Transform)component).position = ((Transform)component).position + (((Transform)component).up * 1.2f - ((Transform)component).right * 1.2f);
		mapRadarText = mapRadarObject.GetComponentInChildren<TextMeshProUGUI>();
		((TMP_Text)mapRadarText).text = objectCode;
		mapRadarBox = mapRadarObject.GetComponentInChildren<Image>();
		if (isBigDoor)
		{
			SetDoorOpen(((Component)this).gameObject.GetComponent<AnimatedObjectTrigger>().boolValue);
			if (((Component)this).gameObject.GetComponent<AnimatedObjectTrigger>().boolValue)
			{
				((Graphic)mapRadarText).color = Color.green;
				((Graphic)mapRadarBox).color = Color.green;
			}
			else
			{
				((Graphic)mapRadarText).color = Color.red;
				((Graphic)mapRadarBox).color = Color.red;
			}
		}
	}

	public override void OnDestroy()
	{
		if ((Object)(object)mapRadarText != (Object)null && (Object)(object)((Component)mapRadarText).gameObject != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)mapRadarText).gameObject);
		}
		((NetworkBehaviour)this).OnDestroy();
	}

	private void SetMaterialUV(int codeIndex)
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		float num2 = 0f;
		for (int i = 0; i < codeIndex; i++)
		{
			num += 1f / (float)columns;
			if (num >= 1f)
			{
				num = 0f;
				num2 += 1f / (float)rows;
				if (num2 >= 1f)
				{
					num2 = 0f;
				}
			}
		}
		if (codeMaterials != null && codeMaterials.Length != 0)
		{
			Material material = ((Renderer)codeMaterials[0]).material;
			material.SetTextureOffset("_BaseColorMap", new Vector2(num, num2));
			for (int j = 0; j < codeMaterials.Length; j++)
			{
				((Renderer)codeMaterials[j]).sharedMaterial = material;
			}
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (isBigDoor && !playerHitDoorTrigger && (!isDoorOpen || !isPoweredOn) && ((Component)other).CompareTag("Player") && (Object)(object)((Component)other).gameObject.GetComponent<PlayerControllerB>() == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			playerHitDoorTrigger = true;
			HUDManager.Instance.DisplayTip("TIP:", "Use the ship computer terminal to access secure doors.", isWarning: false, useSave: true, "LCTip_SecureDoors");
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_TerminalAccessibleObject()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1181174413u, new RpcReceiveHandler(__rpc_handler_1181174413));
		NetworkManager.__rpc_func_table.Add(635686545u, new RpcReceiveHandler(__rpc_handler_635686545));
	}

	private static void __rpc_handler_1181174413(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool doorOpenServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref doorOpenServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((TerminalAccessibleObject)(object)target).SetDoorOpenServerRpc(doorOpenServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_635686545(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool doorOpenClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref doorOpenClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((TerminalAccessibleObject)(object)target).SetDoorOpenClientRpc(doorOpenClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "TerminalAccessibleObject";
	}
}
