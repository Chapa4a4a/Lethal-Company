using System.Collections;
using System.Linq;
using Steamworks;
using Steamworks.Data;
using Steamworks.ServerList;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SteamLobbyManager : MonoBehaviour
{
	private Internet Request;

	private Lobby[] currentLobbyList;

	public TextMeshProUGUI serverListBlankText;

	public Transform levelListContainer;

	public GameObject LobbySlotPrefab;

	public GameObject LobbySlotPrefabChallenge;

	private float lobbySlotPositionOffset;

	public int sortByDistanceSetting = 2;

	private float refreshServerListTimer;

	public bool censorOffensiveLobbyNames = true;

	private Coroutine loadLobbyListCoroutine;

	public Image sortWithChallengeMoonsCheckbox;

	private bool sortWithChallengeMoons = true;

	public TMP_InputField serverTagInputField;

	public void ToggleSortWithChallengeMoons()
	{
		sortWithChallengeMoons = !sortWithChallengeMoons;
		((Behaviour)sortWithChallengeMoonsCheckbox).enabled = sortWithChallengeMoons;
	}

	public void ChangeDistanceSort(int newValue)
	{
		sortByDistanceSetting = newValue;
	}

	private void OnEnable()
	{
		serverTagInputField.text = string.Empty;
	}

	private void DebugLogServerList()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (currentLobbyList != null)
		{
			for (int i = 0; i < currentLobbyList.Length; i++)
			{
				Debug.Log((object)$"Lobby #{i} id: {((Lobby)(ref currentLobbyList[i])).Id}; members: {((Lobby)(ref currentLobbyList[i])).MemberCount}");
				uint num = 0u;
				ushort num2 = 0;
				SteamId val = default(SteamId);
				Debug.Log((object)$"Is lobby #{i} valid?: {((Lobby)(ref currentLobbyList[i])).GetGameServer(ref num, ref num2, ref val)}");
			}
		}
		else
		{
			Debug.Log((object)"Server list null");
		}
	}

	public void RefreshServerListButton()
	{
		if (!(refreshServerListTimer < 0.5f))
		{
			LoadServerList();
		}
	}

	public async void LoadServerList()
	{
		if (GameNetworkManager.Instance.waitingForLobbyDataRefresh)
		{
			return;
		}
		if (loadLobbyListCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(loadLobbyListCoroutine);
		}
		refreshServerListTimer = 0f;
		((TMP_Text)serverListBlankText).text = "Loading server list...";
		currentLobbyList = null;
		LobbySlot[] array = Object.FindObjectsOfType<LobbySlot>();
		for (int i = 0; i < array.Length; i++)
		{
			Object.Destroy((Object)(object)((Component)array[i]).gameObject);
		}
		LobbyQuery val = SteamMatchmaking.LobbyList;
		((LobbyQuery)(ref val)).WithMaxResults(20);
		val = SteamMatchmaking.LobbyList;
		((LobbyQuery)(ref val)).WithKeyValue("started", "0");
		val = SteamMatchmaking.LobbyList;
		((LobbyQuery)(ref val)).WithKeyValue("versNum", GameNetworkManager.Instance.gameVersionNum.ToString());
		val = SteamMatchmaking.LobbyList;
		((LobbyQuery)(ref val)).WithSlotsAvailable(1);
		switch (sortByDistanceSetting)
		{
		case 0:
			val = SteamMatchmaking.LobbyList;
			((LobbyQuery)(ref val)).FilterDistanceClose();
			break;
		case 1:
			val = SteamMatchmaking.LobbyList;
			((LobbyQuery)(ref val)).FilterDistanceFar();
			break;
		case 2:
			val = SteamMatchmaking.LobbyList;
			((LobbyQuery)(ref val)).FilterDistanceWorldwide();
			break;
		}
		currentLobbyList = null;
		Debug.Log((object)"Requested server list");
		GameNetworkManager.Instance.waitingForLobbyDataRefresh = true;
		val = SteamMatchmaking.LobbyList;
		LobbyQuery val2 = ((LobbyQuery)(ref val)).WithSlotsAvailable(1);
		switch (sortByDistanceSetting)
		{
		case 0:
			val = SteamMatchmaking.LobbyList;
			val = ((LobbyQuery)(ref val)).FilterDistanceClose();
			val = ((LobbyQuery)(ref val)).WithSlotsAvailable(1);
			val2 = ((LobbyQuery)(ref val)).WithKeyValue("vers", GameNetworkManager.Instance.gameVersionNum.ToString());
			break;
		case 1:
			val = SteamMatchmaking.LobbyList;
			val = ((LobbyQuery)(ref val)).FilterDistanceFar();
			val = ((LobbyQuery)(ref val)).WithSlotsAvailable(1);
			val2 = ((LobbyQuery)(ref val)).WithKeyValue("vers", GameNetworkManager.Instance.gameVersionNum.ToString());
			break;
		default:
			val = SteamMatchmaking.LobbyList;
			val = ((LobbyQuery)(ref val)).FilterDistanceWorldwide();
			val = ((LobbyQuery)(ref val)).WithSlotsAvailable(1);
			val2 = ((LobbyQuery)(ref val)).WithKeyValue("vers", GameNetworkManager.Instance.gameVersionNum.ToString());
			break;
		}
		if (!sortWithChallengeMoons)
		{
			val2 = ((LobbyQuery)(ref val2)).WithKeyValue("chal", "f");
		}
		val2 = ((!(serverTagInputField.text != string.Empty)) ? ((LobbyQuery)(ref val2)).WithKeyValue("tag", "none") : ((LobbyQuery)(ref val2)).WithKeyValue("tag", serverTagInputField.text.Substring(0, Mathf.Min(19, serverTagInputField.text.Length)).ToLower()));
		currentLobbyList = await ((LobbyQuery)(ref val2)).RequestAsync();
		GameNetworkManager.Instance.waitingForLobbyDataRefresh = false;
		if (currentLobbyList != null)
		{
			if (currentLobbyList.Length == 0)
			{
				((TMP_Text)serverListBlankText).text = "No available servers to join.";
			}
			else
			{
				((TMP_Text)serverListBlankText).text = "";
			}
			lobbySlotPositionOffset = 0f;
			loadLobbyListCoroutine = ((MonoBehaviour)this).StartCoroutine(loadLobbyListAndFilter(currentLobbyList));
		}
		else
		{
			Debug.Log((object)"Lobby list is null after request.");
			((TMP_Text)serverListBlankText).text = "No available servers to join.";
		}
	}

	private IEnumerator loadLobbyListAndFilter(Lobby[] lobbyList)
	{
		string[] offensiveWords = new string[26]
		{
			"nigger", "faggot", "n1g", "nigers", "cunt", "pussies", "pussy", "minors", "children", "kids",
			"chink", "buttrape", "molest", "rape", "coon", "negro", "beastiality", "cocks", "cumshot", "ejaculate",
			"pedophile", "furfag", "necrophilia", "yiff", "sex", "porn"
		};
		for (int i = 0; i < lobbyList.Length; i++)
		{
			Friend[] array = SteamFriends.GetBlocked().ToArray();
			if (array != null)
			{
				for (int j = 0; j < array.Length; j++)
				{
					Debug.Log((object)$"blocked user: {((Friend)(ref array[j])).Name}; id: {array[j].Id}");
					((Lobby)(ref lobbyList[i])).IsOwnedBy(array[j].Id);
				}
			}
			else
			{
				Debug.Log((object)"Blocked users list is null");
			}
			string lobbyName = ((Lobby)(ref lobbyList[i])).GetData("name");
			if (lobbyName.Length == 0)
			{
				Debug.Log((object)"lobby name is length of 0, skipping");
				continue;
			}
			string lobbyNameNoCapitals = lobbyName.ToLower();
			if (censorOffensiveLobbyNames)
			{
				bool nameIsOffensive = false;
				for (int b = 0; b < offensiveWords.Length; b++)
				{
					if (lobbyNameNoCapitals.Contains(offensiveWords[b]))
					{
						nameIsOffensive = true;
						break;
					}
					if (b % 5 == 0)
					{
						yield return null;
					}
				}
				if (nameIsOffensive)
				{
					Debug.Log((object)("Lobby name is offensive: " + lobbyNameNoCapitals + "; skipping"));
					continue;
				}
			}
			GameObject val = ((!(((Lobby)(ref lobbyList[i])).GetData("chal") == "t")) ? LobbySlotPrefab : LobbySlotPrefabChallenge);
			GameObject obj = Object.Instantiate<GameObject>(val, levelListContainer);
			obj.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, 0f + lobbySlotPositionOffset);
			lobbySlotPositionOffset -= 42f;
			LobbySlot componentInChildren = obj.GetComponentInChildren<LobbySlot>();
			((TMP_Text)componentInChildren.LobbyName).text = lobbyName.Substring(0, Mathf.Min(lobbyName.Length, 40));
			((TMP_Text)componentInChildren.playerCount).text = $"{((Lobby)(ref lobbyList[i])).MemberCount} / 4";
			componentInChildren.lobbyId = ((Lobby)(ref lobbyList[i])).Id;
			componentInChildren.thisLobby = lobbyList[i];
		}
	}

	private void Update()
	{
		refreshServerListTimer += Time.deltaTime;
	}
}
