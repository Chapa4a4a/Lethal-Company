using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using DunGen;
using DunGen.Tags;
using TMPro;
using Unity.AI.Navigation;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;
using UnityEngine.Rendering.HighDefinition;
using UnityEngine.SceneManagement;

public class RoundManager : NetworkBehaviour
{
	public StartOfRound playersManager;

	public Transform itemPooledObjectsContainer;

	[Header("Global Game Variables / Balancing")]
	public float scrapValueMultiplier = 1f;

	public float scrapAmountMultiplier = 1f;

	public float mapSizeMultiplier = 1f;

	[Space(3f)]
	public int increasedInsideEnemySpawnRateIndex = -1;

	public int increasedOutsideEnemySpawnRateIndex = -1;

	public int increasedMapPropSpawnRateIndex = -1;

	public int increasedScrapSpawnRateIndex = -1;

	public int increasedMapHazardSpawnRateIndex = -1;

	[Space(5f)]
	[Space(5f)]
	public float currentMaxInsidePower;

	public float currentMaxOutsidePower;

	public float currentEnemyPower;

	public float currentOutsideEnemyPower;

	public float currentDaytimeEnemyPower;

	public TimeOfDay timeScript;

	private int currentHour;

	public float currentHourTime;

	[Header("Gameplay events")]
	public List<int> enemySpawnTimes = new List<int>();

	public int currentEnemySpawnIndex;

	public bool isSpawningEnemies;

	public bool begunSpawningEnemies;

	[Header("Elevator Properties")]
	public bool ElevatorCharging;

	public float elevatorCharge;

	public bool ElevatorPowered;

	public bool elevatorUp;

	public bool ElevatorLowering;

	public bool ElevatorRunning;

	public bool ReturnToSurface;

	[Header("Elevator Variables")]
	public Animator ElevatorAnimator;

	public Animator ElevatorLightAnimator;

	public AudioSource elevatorMotorAudio;

	public AudioClip startMotor;

	public Animator PanelButtons;

	public Animator PanelLights;

	public AudioSource elevatorButtonsAudio;

	public AudioClip PressButtonSFX1;

	public AudioClip PressButtonSFX2;

	public TextMeshProUGUI PanelScreenText;

	public Canvas PanelScreen;

	public NetworkObject lungPlacePosition;

	public InteractTrigger elevatorSocketTrigger;

	private Coroutine loadLevelCoroutine;

	private Coroutine flickerLightsCoroutine;

	private Coroutine powerLightsCoroutine;

	[Header("Enemies")]
	public EnemyVent[] allEnemyVents;

	public List<Anomaly> SpawnedAnomalies = new List<Anomaly>();

	public List<EnemyAI> SpawnedEnemies = new List<EnemyAI>();

	private List<int> SpawnProbabilities = new List<int>();

	public int hourTimeBetweenEnemySpawnBatches = 2;

	public int numberOfEnemiesInScene;

	public int minEnemiesToSpawn;

	public int minOutsideEnemiesToSpawn;

	[Header("Hazards")]
	public SpawnableMapObject[] spawnableMapObjects;

	public GameObject mapPropsContainer;

	public Transform VehiclesContainer;

	public Transform[] shipSpawnPathPoints;

	public GameObject[] spawnDenialPoints;

	public string[] possibleCodesForBigDoors;

	public GameObject quicksandPrefab;

	public GameObject keyPrefab;

	[Space(3f)]
	public GameObject breakTreePrefab;

	public GameObject breakSnowmanPrefab;

	public AudioClip breakTreeAudio1;

	public AudioClip breakTreeAudio2;

	public AudioClip breakSnowmanAudio1;

	[Space(5f)]
	public GameObject[] outsideAINodes;

	public GameObject[] insideAINodes;

	[Header("Dungeon generation")]
	public IndoorMapType[] dungeonFlowTypes;

	public RuntimeDungeon dungeonGenerator;

	public bool dungeonCompletedGenerating;

	public bool bakedNavMesh;

	public bool dungeonFinishedGeneratingForAllPlayers;

	public AudioClip[] firstTimeDungeonAudios;

	public int currentDungeonType = -1;

	[Space(3f)]
	public GameObject caveEntranceProp;

	public Tag CaveDoorwayTag;

	public Tag MineshaftTunnelTag;

	public MineshaftElevatorController currentMineshaftElevator;

	[Header("Scrap-collection")]
	public Transform spawnedScrapContainer;

	public int scrapCollectedInLevel;

	public float totalScrapValueInLevel;

	public int valueOfFoundScrapItems;

	public List<GrabbableObject> scrapCollectedThisRound = new List<GrabbableObject>();

	public SelectableLevel currentLevel;

	public Random LevelRandom;

	public Random AnomalyRandom;

	public Random EnemySpawnRandom;

	public Random OutsideEnemySpawnRandom;

	public Random BreakerBoxRandom;

	public Random ScrapValuesRandom;

	public Random ChallengeMoonRandom;

	public bool powerOffPermanently;

	public bool hasInitializedLevelRandomSeed;

	public List<ulong> playersFinishedGeneratingFloor = new List<ulong>(4);

	public PowerSwitchEvent onPowerSwitch = new PowerSwitchEvent();

	public List<Animator> allPoweredLightsAnimators = new List<Animator>();

	public List<Light> allPoweredLights = new List<Light>();

	public List<GameObject> spawnedSyncedObjects = new List<GameObject>();

	public float stabilityMeter;

	private Coroutine elevatorRunningCoroutine;

	public int collisionsMask = 2305;

	public bool cannotSpawnMoreInsideEnemies;

	public Collider[] tempColliderResults = (Collider[])(object)new Collider[20];

	public Transform tempTransform;

	public bool GotNavMeshPositionResult;

	public NavMeshHit navHit;

	private bool firstTimeSpawningEnemies;

	private bool firstTimeSpawningOutsideEnemies;

	private bool firstTimeSpawningWeedEnemies;

	private bool firstTimeSpawningDaytimeEnemies;

	private int enemyRushIndex;

	public LocalVolumetricFog indoorFog;

	public List<EnemyAINestSpawnObject> enemyNestSpawnObjects = new List<EnemyAINestSpawnObject>();

	public AudioClip[] snowmanLaughSFX;

	public static RoundManager Instance { get; private set; }

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
		}
		else
		{
			Object.Destroy((Object)(object)((Component)Instance).gameObject);
		}
	}

	public void SpawnScrapInLevel()
	{
		//IL_04b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0503: Unknown result type (might be due to invalid IL or missing references)
		//IL_0508: Unknown result type (might be due to invalid IL or missing references)
		//IL_0527: Unknown result type (might be due to invalid IL or missing references)
		//IL_0529: Unknown result type (might be due to invalid IL or missing references)
		//IL_054a: Unknown result type (might be due to invalid IL or missing references)
		//IL_054f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0498: Unknown result type (might be due to invalid IL or missing references)
		//IL_049d: Unknown result type (might be due to invalid IL or missing references)
		//IL_065a: Unknown result type (might be due to invalid IL or missing references)
		int num = (int)((float)AnomalyRandom.Next(currentLevel.minScrap, currentLevel.maxScrap) * scrapAmountMultiplier);
		if (currentDungeonType == 4)
		{
			num += 6;
		}
		if (StartOfRound.Instance.isChallengeFile)
		{
			int num2 = AnomalyRandom.Next(10, 30);
			num += num2;
			Debug.Log((object)$"Anomaly random 0b: {num2}");
		}
		int num3 = -1;
		if (AnomalyRandom.Next(0, 500) <= 20)
		{
			num3 = AnomalyRandom.Next(0, currentLevel.spawnableScrap.Count);
			bool flag = false;
			for (int j = 0; j < 2; j++)
			{
				if (currentLevel.spawnableScrap[num3].rarity < 5 || currentLevel.spawnableScrap[num3].spawnableItem.twoHanded)
				{
					num3 = AnomalyRandom.Next(0, currentLevel.spawnableScrap.Count);
					continue;
				}
				flag = true;
				break;
			}
			if (!flag && AnomalyRandom.Next(0, 100) < 60)
			{
				num3 = -1;
			}
		}
		List<Item> ScrapToSpawn = new List<Item>();
		List<int> list = new List<int>();
		int num4 = 0;
		List<int> list2 = new List<int>(currentLevel.spawnableScrap.Count);
		for (int k = 0; k < currentLevel.spawnableScrap.Count; k++)
		{
			if (k == increasedScrapSpawnRateIndex)
			{
				list2.Add(100);
			}
			else if (currentLevel.spawnableScrap[k].spawnableItem.itemId == 152767)
			{
				list2.Add(Mathf.Min(currentLevel.spawnableScrap[k].rarity + 30, 99));
			}
			else
			{
				list2.Add(currentLevel.spawnableScrap[k].rarity);
			}
		}
		int[] weights = list2.ToArray();
		for (int l = 0; l < num; l++)
		{
			if (num3 != -1)
			{
				ScrapToSpawn.Add(currentLevel.spawnableScrap[num3].spawnableItem);
			}
			else
			{
				ScrapToSpawn.Add(currentLevel.spawnableScrap[GetRandomWeightedIndex(weights)].spawnableItem);
			}
		}
		Debug.Log((object)$"Number of scrap to spawn: {ScrapToSpawn.Count}. minTotalScrapValue: {currentLevel.minTotalScrapValue}. Total value of items: {num4}.");
		RandomScrapSpawn randomScrapSpawn = null;
		RandomScrapSpawn[] source = Object.FindObjectsOfType<RandomScrapSpawn>();
		List<NetworkObjectReference> list3 = new List<NetworkObjectReference>();
		List<RandomScrapSpawn> usedSpawns = new List<RandomScrapSpawn>();
		int i;
		for (i = 0; i < ScrapToSpawn.Count; i++)
		{
			if ((Object)(object)ScrapToSpawn[i] == (Object)null)
			{
				Debug.Log((object)"Error!!!!! Found null element in list ScrapToSpawn. Skipping it.");
				continue;
			}
			List<RandomScrapSpawn> list4 = ((ScrapToSpawn[i].spawnPositionTypes != null && ScrapToSpawn[i].spawnPositionTypes.Count != 0 && num3 == -1) ? source.Where((RandomScrapSpawn x) => ScrapToSpawn[i].spawnPositionTypes.Contains(x.spawnableItems) && !x.spawnUsed).ToList() : source.ToList());
			if (list4.Count <= 0)
			{
				Debug.Log((object)("No tiles containing a scrap spawn with item type: " + ScrapToSpawn[i].itemName));
				continue;
			}
			if (usedSpawns.Count > 0 && list4.Contains(randomScrapSpawn))
			{
				list4.RemoveAll((RandomScrapSpawn x) => usedSpawns.Contains(x));
				if (list4.Count <= 0)
				{
					usedSpawns.Clear();
					i--;
					continue;
				}
			}
			randomScrapSpawn = list4[AnomalyRandom.Next(0, list4.Count)];
			usedSpawns.Add(randomScrapSpawn);
			Vector3 val;
			if (randomScrapSpawn.spawnedItemsCopyPosition)
			{
				randomScrapSpawn.spawnUsed = true;
				val = ((!Object.op_Implicit((Object)(object)randomScrapSpawn.spawnWithParent)) ? ((Component)randomScrapSpawn).transform.position : ((Component)randomScrapSpawn.spawnWithParent).transform.position);
			}
			else
			{
				val = GetRandomNavMeshPositionInBoxPredictable(((Component)randomScrapSpawn).transform.position, randomScrapSpawn.itemSpawnRange, navHit, AnomalyRandom) + Vector3.up * ScrapToSpawn[i].verticalOffset;
			}
			GameObject obj = Object.Instantiate<GameObject>(ScrapToSpawn[i].spawnPrefab, val, Quaternion.identity, (Transform)null);
			GrabbableObject component = obj.GetComponent<GrabbableObject>();
			((Component)component).transform.rotation = Quaternion.Euler(component.itemProperties.restingRotation);
			component.fallTime = 0f;
			if (num3 != -1)
			{
				list.Add(Mathf.Clamp((int)((float)AnomalyRandom.Next(ScrapToSpawn[i].minValue, ScrapToSpawn[i].maxValue) * scrapValueMultiplier), 50, 170));
			}
			else
			{
				list.Add((int)((float)AnomalyRandom.Next(ScrapToSpawn[i].minValue, ScrapToSpawn[i].maxValue) * scrapValueMultiplier));
			}
			num4 += list[list.Count - 1];
			component.scrapValue = list[list.Count - 1];
			NetworkObject component2 = obj.GetComponent<NetworkObject>();
			component2.Spawn(false);
			list3.Add(NetworkObjectReference.op_Implicit(component2));
		}
		if (num3 != -1)
		{
			float num5 = 600f;
			if (currentLevel.spawnableScrap[num3].spawnableItem.twoHanded)
			{
				num5 = 1500f;
			}
			if (num4 > 4500)
			{
				num4 = 0;
				for (int m = 0; m < list.Count; m++)
				{
					list[m] = (int)((float)list[m] * 0.7f);
					num4 += list[m];
				}
			}
			else if ((float)num4 < num5)
			{
				num4 = 0;
				for (int n = 0; n < list.Count; n++)
				{
					list[n] = (int)((float)list[n] * 1.4f);
					num4 += list[n];
				}
			}
		}
		((MonoBehaviour)this).StartCoroutine(waitForScrapToSpawnToSync(list3.ToArray(), list.ToArray()));
	}

	private IEnumerator waitForScrapToSpawnToSync(NetworkObjectReference[] spawnedScrap, int[] scrapValues)
	{
		yield return (object)new WaitForSeconds(11f);
		SyncScrapValuesClientRpc(spawnedScrap, scrapValues);
	}

	[ClientRpc]
	public void SyncScrapValuesClientRpc(NetworkObjectReference[] spawnedScrap, int[] allScrapValue)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1659269112u, val, (RpcDelivery)0);
			bool flag = spawnedScrap != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(spawnedScrap, default(ForNetworkSerializable));
			}
			bool flag2 = allScrapValue != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag2, default(ForPrimitives));
			if (flag2)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(allScrapValue, default(ForPrimitives));
			}
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1659269112u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		Debug.Log((object)$"clientRPC scrap values length: {allScrapValue.Length}");
		ScrapValuesRandom = new Random(StartOfRound.Instance.randomMapSeed + 210);
		int num = 0;
		NetworkObject val3 = default(NetworkObject);
		for (int i = 0; i < spawnedScrap.Length; i++)
		{
			if (((NetworkObjectReference)(ref spawnedScrap[i])).TryGet(ref val3, (NetworkManager)null))
			{
				GrabbableObject component = ((Component)val3).GetComponent<GrabbableObject>();
				if ((Object)(object)component != (Object)null)
				{
					if (i >= allScrapValue.Length)
					{
						Debug.LogError((object)$"spawnedScrap amount exceeded allScrapValue!: {spawnedScrap.Length}");
						break;
					}
					component.SetScrapValue(allScrapValue[i]);
					num += allScrapValue[i];
					if (component.itemProperties.meshVariants.Length != 0)
					{
						((Component)component).gameObject.GetComponent<MeshFilter>().mesh = component.itemProperties.meshVariants[ScrapValuesRandom.Next(0, component.itemProperties.meshVariants.Length)];
					}
					try
					{
						if (component.itemProperties.materialVariants.Length != 0)
						{
							((Renderer)((Component)component).gameObject.GetComponent<MeshRenderer>()).sharedMaterial = component.itemProperties.materialVariants[ScrapValuesRandom.Next(0, component.itemProperties.materialVariants.Length)];
						}
					}
					catch (Exception arg)
					{
						Debug.Log((object)$"Item name: {((Object)((Component)component).gameObject).name}; {arg}");
					}
				}
				else
				{
					Debug.LogError((object)("Scrap networkobject object did not contain grabbable object!: " + ((Object)((Component)val3).gameObject).name));
				}
			}
			else
			{
				Debug.LogError((object)$"Failed to get networkobject reference for scrap. id: {((NetworkObjectReference)(ref spawnedScrap[i])).NetworkObjectId}");
			}
		}
		totalScrapValueInLevel = num;
		scrapCollectedInLevel = 0;
		valueOfFoundScrapItems = 0;
	}

	public void SpawnSyncedProps()
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			spawnedSyncedObjects.Clear();
			SpawnSyncedObject[] array = Object.FindObjectsOfType<SpawnSyncedObject>();
			if (array == null)
			{
				return;
			}
			mapPropsContainer = GameObject.FindGameObjectWithTag("MapPropsContainer");
			Debug.Log((object)$"Spawning synced props on server. Length: {array.Length}");
			for (int i = 0; i < array.Length; i++)
			{
				GameObject val = Object.Instantiate<GameObject>(array[i].spawnPrefab, ((Component)array[i]).transform.position, ((Component)array[i]).transform.rotation, mapPropsContainer.transform);
				if ((Object)(object)val != (Object)null)
				{
					val.GetComponent<NetworkObject>().Spawn(true);
					spawnedSyncedObjects.Add(val);
				}
			}
		}
		catch (Exception arg)
		{
			Debug.Log((object)$"Exception! Unable to sync spawned objects on host; {arg}");
		}
	}

	public void SpawnMapObjects()
	{
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0325: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		if (currentLevel.spawnableMapObjects.Length == 0)
		{
			return;
		}
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 587);
		mapPropsContainer = GameObject.FindGameObjectWithTag("MapPropsContainer");
		RandomMapObject[] array = Object.FindObjectsOfType<RandomMapObject>();
		EntranceTeleport[] array2 = Object.FindObjectsByType<EntranceTeleport>((FindObjectsSortMode)0);
		List<Vector3> list = new List<Vector3>();
		List<RandomMapObject> list2 = new List<RandomMapObject>();
		RaycastHit val2 = default(RaycastHit);
		for (int i = 0; i < currentLevel.spawnableMapObjects.Length; i++)
		{
			list2.Clear();
			int num = (int)currentLevel.spawnableMapObjects[i].numberToSpawn.Evaluate((float)random.NextDouble());
			if (increasedMapHazardSpawnRateIndex == i)
			{
				num = Mathf.Min(num * 2, 150);
			}
			if (num <= 0)
			{
				continue;
			}
			for (int j = 0; j < array.Length; j++)
			{
				if (array[j].spawnablePrefabs.Contains(currentLevel.spawnableMapObjects[i].prefabToSpawn))
				{
					list2.Add(array[j]);
				}
			}
			if (list2.Count == 0)
			{
				Debug.Log((object)("NO SPAWNERS WERE COMPATIBLE WITH THE SPAWNABLE MAP OBJECT: '" + ((Object)currentLevel.spawnableMapObjects[i].prefabToSpawn.gameObject).name + "'"));
				continue;
			}
			list.Clear();
			for (int k = 0; k < num; k++)
			{
				RandomMapObject randomMapObject = list2[random.Next(0, list2.Count)];
				Vector3 position = ((Component)randomMapObject).transform.position;
				position = GetRandomNavMeshPositionInBoxPredictable(position, randomMapObject.spawnRange, default(NavMeshHit), random);
				if (currentLevel.spawnableMapObjects[i].disallowSpawningNearEntrances)
				{
					for (int l = 0; l < array2.Length; l++)
					{
						if (!array2[l].isEntranceToBuilding)
						{
							Vector3.Distance(((Component)array2[l].entrancePoint).transform.position, position);
							_ = 5.5f;
						}
					}
				}
				if (currentLevel.spawnableMapObjects[i].requireDistanceBetweenSpawns)
				{
					bool flag = false;
					for (int m = 0; m < list.Count; m++)
					{
						if (Vector3.Distance(position, list[m]) < 5f)
						{
							flag = true;
							break;
						}
					}
					if (flag)
					{
						continue;
					}
				}
				GameObject val = Object.Instantiate<GameObject>(currentLevel.spawnableMapObjects[i].prefabToSpawn, position, Quaternion.identity, mapPropsContainer.transform);
				if (currentLevel.spawnableMapObjects[i].spawnFacingAwayFromWall)
				{
					val.transform.eulerAngles = new Vector3(0f, YRotationThatFacesTheFarthestFromPosition(position + Vector3.up * 0.2f), 0f);
				}
				else if (currentLevel.spawnableMapObjects[i].spawnFacingWall)
				{
					val.transform.eulerAngles = new Vector3(0f, YRotationThatFacesTheNearestFromPosition(position + Vector3.up * 0.2f), 0f);
				}
				else
				{
					val.transform.eulerAngles = new Vector3(val.transform.eulerAngles.x, (float)random.Next(0, 360), val.transform.eulerAngles.z);
				}
				if (currentLevel.spawnableMapObjects[i].spawnWithBackToWall && Physics.Raycast(val.transform.position, -val.transform.forward, ref val2, 100f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
				{
					val.transform.position = ((RaycastHit)(ref val2)).point;
					if (currentLevel.spawnableMapObjects[i].spawnWithBackFlushAgainstWall)
					{
						val.transform.forward = ((RaycastHit)(ref val2)).normal;
						val.transform.eulerAngles = new Vector3(0f, val.transform.eulerAngles.y, 0f);
					}
				}
				val.GetComponent<NetworkObject>().Spawn(true);
			}
		}
		for (int n = 0; n < array.Length; n++)
		{
			Object.Destroy((Object)(object)((Component)array[n]).gameObject);
		}
	}

	public float YRotationThatFacesTheFarthestFromPosition(Vector3 pos, float maxDistance = 25f, int resolution = 6)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		float num2 = 0f;
		RaycastHit val = default(RaycastHit);
		for (int i = 0; i < 360; i += 360 / resolution)
		{
			tempTransform.eulerAngles = new Vector3(0f, (float)i, 0f);
			if (Physics.Raycast(pos, tempTransform.forward, ref val, maxDistance, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
			{
				if (((RaycastHit)(ref val)).distance > num2)
				{
					num2 = ((RaycastHit)(ref val)).distance;
					num = i;
				}
				continue;
			}
			num = i;
			break;
		}
		if (!hasInitializedLevelRandomSeed)
		{
			return Random.Range(num - 15, num + 15);
		}
		int num3 = AnomalyRandom.Next(num - 15, num + 15);
		Debug.Log((object)$"Anomaly random yrotation farthest: {num3}");
		return num3;
	}

	public float YRotationThatFacesTheNearestFromPosition(Vector3 pos, float maxDistance = 25f, int resolution = 6)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		float num2 = 100f;
		bool flag = false;
		RaycastHit val = default(RaycastHit);
		for (int i = 0; i < 360; i += 360 / resolution)
		{
			tempTransform.eulerAngles = new Vector3(0f, (float)i, 0f);
			if (Physics.Raycast(pos, tempTransform.forward, ref val, maxDistance, StartOfRound.Instance.collidersAndRoomMask, (QueryTriggerInteraction)1))
			{
				flag = true;
				if (((RaycastHit)(ref val)).distance < num2)
				{
					num2 = ((RaycastHit)(ref val)).distance;
					num = i;
				}
			}
		}
		if (!flag)
		{
			return -777f;
		}
		if (!hasInitializedLevelRandomSeed)
		{
			return Random.Range(num - 15, num + 15);
		}
		int num3 = AnomalyRandom.Next(num - 15, num + 15);
		Debug.Log((object)$"Anomaly random yrotation nearest: {num3}");
		return num3;
	}

	public void GenerateNewFloor()
	{
		int num = -1;
		if (currentLevel.dungeonFlowTypes != null && currentLevel.dungeonFlowTypes.Length != 0)
		{
			List<int> list = new List<int>();
			for (int i = 0; i < currentLevel.dungeonFlowTypes.Length; i++)
			{
				list.Add(currentLevel.dungeonFlowTypes[i].rarity);
			}
			int randomWeightedIndex = GetRandomWeightedIndex(list.ToArray(), LevelRandom);
			num = currentLevel.dungeonFlowTypes[randomWeightedIndex].id;
			dungeonGenerator.Generator.DungeonFlow = dungeonFlowTypes[num].dungeonFlow;
			currentDungeonType = num;
			if ((Object)(object)currentLevel.dungeonFlowTypes[randomWeightedIndex].overrideLevelAmbience != (Object)null)
			{
				SoundManager.Instance.currentLevelAmbience = currentLevel.dungeonFlowTypes[randomWeightedIndex].overrideLevelAmbience;
			}
			else if ((Object)(object)currentLevel.levelAmbienceClips != (Object)null)
			{
				SoundManager.Instance.currentLevelAmbience = currentLevel.levelAmbienceClips;
			}
		}
		else
		{
			if ((Object)(object)currentLevel.levelAmbienceClips != (Object)null)
			{
				SoundManager.Instance.currentLevelAmbience = currentLevel.levelAmbienceClips;
			}
			currentDungeonType = 0;
		}
		dungeonGenerator.Generator.ShouldRandomizeSeed = false;
		dungeonGenerator.Generator.Seed = LevelRandom.Next();
		float num2;
		if (num != -1)
		{
			num2 = currentLevel.factorySizeMultiplier / dungeonFlowTypes[num].MapTileSize * mapSizeMultiplier;
			num2 = (float)((double)Mathf.Round(num2 * 100f) / 100.0);
		}
		else
		{
			num2 = currentLevel.factorySizeMultiplier * mapSizeMultiplier;
		}
		dungeonGenerator.Generator.LengthMultiplier = num2;
		dungeonGenerator.Generate();
	}

	public void GeneratedFloorPostProcessing()
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			SpawnScrapInLevel();
			SpawnMapObjects();
		}
	}

	private void SpawnCaveDoorLights()
	{
		if (currentDungeonType != 4)
		{
			return;
		}
		Tile[] array = Object.FindObjectsByType<Tile>((FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if (!array[i].Tags.HasTag(MineshaftTunnelTag))
			{
				continue;
			}
			for (int j = 0; j < array[i].UsedDoorways.Count; j++)
			{
				if (!array[i].UsedDoorways[j].ConnectedDoorway.Tags.HasTag(CaveDoorwayTag))
				{
					continue;
				}
				Object.Instantiate<GameObject>(caveEntranceProp, ((Component)array[i].UsedDoorways[j]).transform, false);
				Transform[] componentsInChildren = ((Component)array[i]).gameObject.GetComponentsInChildren<Transform>(false);
				if (componentsInChildren.Length == 0)
				{
					continue;
				}
				Transform[] array2 = componentsInChildren;
				foreach (Transform val in array2)
				{
					if (((Component)val).tag == "PoweredLight")
					{
						Object.Destroy((Object)(object)((Component)val).gameObject);
					}
				}
			}
		}
	}

	public void TurnBreakerSwitchesOff()
	{
		BreakerBox breakerBox = Object.FindObjectOfType<BreakerBox>();
		if ((Object)(object)breakerBox != (Object)null)
		{
			Debug.Log((object)"Switching breaker switches off");
			breakerBox.SetSwitchesOff();
			SwitchPower(on: false);
			((UnityEvent<bool>)onPowerSwitch).Invoke(false);
		}
	}

	public void LoadNewLevel(int randomSeed, SelectableLevel newLevel)
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			currentLevel = newLevel;
			dungeonFinishedGeneratingForAllPlayers = false;
			playersManager.fullyLoadedPlayers.Clear();
			if ((Object)(object)dungeonGenerator != (Object)null)
			{
				dungeonGenerator.Generator.OnGenerationStatusChanged -= Generator_OnGenerationStatusChanged;
			}
			if (loadLevelCoroutine != null)
			{
				loadLevelCoroutine = null;
			}
			loadLevelCoroutine = ((MonoBehaviour)this).StartCoroutine(LoadNewLevelWait(randomSeed));
		}
	}

	private void SetChallengeFileRandomModifiers()
	{
		if (!StartOfRound.Instance.isChallengeFile)
		{
			return;
		}
		int[] array = new int[5];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = AnomalyRandom.Next(0, 100);
		}
		if (array[0] < 45)
		{
			increasedInsideEnemySpawnRateIndex = AnomalyRandom.Next(0, currentLevel.Enemies.Count);
			if (currentLevel.Enemies[increasedInsideEnemySpawnRateIndex].enemyType.spawningDisabled)
			{
				increasedInsideEnemySpawnRateIndex = AnomalyRandom.Next(0, currentLevel.Enemies.Count);
			}
		}
		if (array[1] < 45)
		{
			increasedOutsideEnemySpawnRateIndex = AnomalyRandom.Next(0, currentLevel.OutsideEnemies.Count);
		}
		if (array[2] < 45)
		{
			increasedMapHazardSpawnRateIndex = AnomalyRandom.Next(0, currentLevel.spawnableMapObjects.Length);
		}
		if (array[3] < 45)
		{
			increasedMapPropSpawnRateIndex = AnomalyRandom.Next(0, currentLevel.spawnableOutsideObjects.Length);
		}
		if (array[4] < 45)
		{
			increasedScrapSpawnRateIndex = AnomalyRandom.Next(0, currentLevel.spawnableScrap.Count);
		}
	}

	private IEnumerator LoadNewLevelWait(int randomSeed)
	{
		yield return null;
		yield return null;
		playersFinishedGeneratingFloor.Clear();
		if (currentLevel.moldSpreadIterations > 0)
		{
			MoldSpreadManager moldSpreadManager = Object.FindObjectOfType<MoldSpreadManager>();
			outsideAINodes = (from x in GameObject.FindGameObjectsWithTag("OutsideAINode")
				orderby Vector3.Distance(x.transform.position, StartOfRound.Instance.elevatorTransform.position)
				select x).ToArray();
			int moldStartPosition;
			if (StartOfRound.Instance.currentLevel.moldStartPosition == -1)
			{
				Random random = new Random(StartOfRound.Instance.randomMapSeed + 2017);
				int num = random.Next(0, outsideAINodes.Length);
				if (Vector3.Distance(outsideAINodes[num].transform.position, StartOfRound.Instance.elevatorTransform.position) < 40f)
				{
					for (int i = 0; i < outsideAINodes.Length; i++)
					{
						if (!(Vector3.Distance(StartOfRound.Instance.elevatorTransform.position, outsideAINodes[i].transform.position) < 40f) && (random.Next(0, 100) < 13 || outsideAINodes.Length - i < 20))
						{
							num = i;
						}
					}
				}
				StartOfRound.Instance.currentLevel.moldStartPosition = num;
				moldStartPosition = num;
			}
			else
			{
				moldStartPosition = StartOfRound.Instance.currentLevel.moldStartPosition;
			}
			if (moldSpreadManager.planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.Count > 0)
			{
				GenerateNewLevelClientRpc(randomSeed, currentLevel.levelID, currentLevel.moldSpreadIterations, moldStartPosition, moldSpreadManager.planetMoldStates[StartOfRound.Instance.currentLevelID].destroyedMold.ToArray());
			}
			else
			{
				GenerateNewLevelClientRpc(randomSeed, currentLevel.levelID, currentLevel.moldSpreadIterations, moldStartPosition);
			}
		}
		else
		{
			GenerateNewLevelClientRpc(randomSeed, currentLevel.levelID);
		}
		if (currentLevel.spawnEnemiesAndScrap)
		{
			yield return (object)new WaitUntil((Func<bool>)(() => dungeonCompletedGenerating));
			yield return null;
			yield return (object)new WaitUntil((Func<bool>)(() => playersFinishedGeneratingFloor.Count >= GameNetworkManager.Instance.connectedPlayers));
			Debug.Log((object)"Players finished generating the new floor");
		}
		yield return (object)new WaitForSeconds(0.3f);
		SpawnSyncedProps();
		if (currentLevel.spawnEnemiesAndScrap)
		{
			GeneratedFloorPostProcessing();
		}
		yield return null;
		playersFinishedGeneratingFloor.Clear();
		dungeonFinishedGeneratingForAllPlayers = true;
		RefreshEnemyVents();
		FinishGeneratingNewLevelClientRpc();
	}

	[ClientRpc]
	public void GenerateNewLevelClientRpc(int randomSeed, int levelID, int moldIterations = 0, int moldStartPosition = 0, int[] syncDestroyedMold = null)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3073943002u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, randomSeed);
			BytePacker.WriteValueBitPacked(val2, levelID);
			BytePacker.WriteValueBitPacked(val2, moldIterations);
			BytePacker.WriteValueBitPacked(val2, moldStartPosition);
			bool flag = syncDestroyedMold != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<int>(syncDestroyedMold, default(ForPrimitives));
			}
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3073943002u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		outsideAINodes = (from x in GameObject.FindGameObjectsWithTag("OutsideAINode")
			orderby Vector3.Distance(x.transform.position, StartOfRound.Instance.elevatorTransform.position)
			select x).ToArray();
		currentLevel.moldSpreadIterations = moldIterations;
		currentLevel.moldStartPosition = moldStartPosition;
		if (moldIterations > 0)
		{
			Vector3 position = outsideAINodes[Mathf.Min(moldStartPosition, outsideAINodes.Length - 1)].transform.position;
			if (syncDestroyedMold != null)
			{
				Object.FindObjectOfType<MoldSpreadManager>().SyncDestroyedMoldPositions(syncDestroyedMold);
			}
			Object.FindObjectOfType<MoldSpreadManager>().GenerateMold(position, moldIterations);
		}
		playersManager.randomMapSeed = randomSeed;
		currentLevel = playersManager.levels[levelID];
		InitializeRandomNumberGenerators();
		SetChallengeFileRandomModifiers();
		((TMP_Text)HUDManager.Instance.loadingText).text = $"Random seed: {randomSeed}";
		((Behaviour)HUDManager.Instance.loadingDarkenScreen).enabled = true;
		dungeonCompletedGenerating = false;
		mapPropsContainer = GameObject.FindGameObjectWithTag("MapPropsContainer");
		if (!currentLevel.spawnEnemiesAndScrap)
		{
			return;
		}
		dungeonGenerator = Object.FindObjectOfType<RuntimeDungeon>(false);
		if ((Object)(object)dungeonGenerator != (Object)null)
		{
			GenerateNewFloor();
			if (dungeonGenerator.Generator.Status == GenerationStatus.Complete)
			{
				FinishGeneratingLevel();
				Debug.Log((object)"Dungeon finished generating in one frame.");
			}
			else
			{
				dungeonGenerator.Generator.OnGenerationStatusChanged += Generator_OnGenerationStatusChanged;
				Debug.Log((object)"Now listening to dungeon generator status.");
			}
		}
		else
		{
			Debug.LogError((object)$"This client could not find dungeon generator! scene count: {SceneManager.sceneCount}");
		}
	}

	private void FinishGeneratingLevel()
	{
		insideAINodes = GameObject.FindGameObjectsWithTag("AINode");
		dungeonCompletedGenerating = true;
		SpawnCaveDoorLights();
		SetToCurrentLevelWeather();
		SpawnOutsideHazards();
		FinishedGeneratingLevelServerRpc(NetworkManager.Singleton.LocalClientId);
	}

	private void Generator_OnGenerationStatusChanged(DungeonGenerator generator, GenerationStatus status)
	{
		if (status == GenerationStatus.Complete && !dungeonCompletedGenerating)
		{
			FinishGeneratingLevel();
			Debug.Log((object)"Dungeon has finished generating on this client after multiple frames");
		}
		dungeonGenerator.Generator.OnGenerationStatusChanged -= Generator_OnGenerationStatusChanged;
	}

	[ServerRpc(RequireOwnership = false)]
	public void FinishedGeneratingLevelServerRpc(ulong clientId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(192551691u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clientId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 192551691u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				playersFinishedGeneratingFloor.Add(clientId);
			}
		}
	}

	public void DespawnPropsAtEndOfRound(bool despawnAllItems = false)
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		GrabbableObject[] array = Object.FindObjectsOfType<GrabbableObject>();
		try
		{
			VehicleController[] array2 = Object.FindObjectsByType<VehicleController>((FindObjectsSortMode)0);
			for (int i = 0; i < array2.Length; i++)
			{
				if (!array2[i].magnetedToShip)
				{
					if ((Object)(object)((NetworkBehaviour)array2[i]).NetworkObject != (Object)null)
					{
						Debug.Log((object)"Despawn vehicle");
						((NetworkBehaviour)array2[i]).NetworkObject.Despawn(false);
					}
				}
				else
				{
					array2[i].CollectItemsInTruck();
				}
			}
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"Error despawning vehicle: {arg}");
		}
		BeltBagItem[] array3 = Object.FindObjectsByType<BeltBagItem>((FindObjectsSortMode)0);
		for (int j = 0; j < array3.Length; j++)
		{
			if (Object.op_Implicit((Object)(object)array3[j].insideAnotherBeltBag) && (array3[j].insideAnotherBeltBag.isInShipRoom || array3[j].insideAnotherBeltBag.isHeld))
			{
				array3[j].isInElevator = true;
				array3[j].isInShipRoom = true;
			}
			if (array3[j].isInShipRoom || array3[j].isHeld)
			{
				for (int k = 0; k < array3[j].objectsInBag.Count; k++)
				{
					array3[j].objectsInBag[k].isInElevator = true;
					array3[j].objectsInBag[k].isInShipRoom = true;
				}
			}
		}
		for (int l = 0; l < array.Length; l++)
		{
			if ((Object)(object)array[l] == (Object)null)
			{
				continue;
			}
			if (despawnAllItems || (!array[l].isHeld && !array[l].isInShipRoom) || array[l].deactivated || (StartOfRound.Instance.allPlayersDead && array[l].itemProperties.isScrap))
			{
				if (array[l].isHeld && (Object)(object)array[l].playerHeldBy != (Object)null)
				{
					array[l].playerHeldBy.DropAllHeldItemsAndSync();
				}
				NetworkObject component = ((Component)array[l]).gameObject.GetComponent<NetworkObject>();
				if ((Object)(object)component != (Object)null && component.IsSpawned)
				{
					Debug.Log((object)"Despawning prop");
					((Component)array[l]).gameObject.GetComponent<NetworkObject>().Despawn(true);
				}
				else
				{
					Debug.Log((object)("Error/warning: prop '" + ((Object)((Component)array[l]).gameObject).name + "' was not spawned or did not have a NetworkObject component! Skipped despawning and destroyed it instead."));
					Object.Destroy((Object)(object)((Component)array[l]).gameObject);
				}
			}
			else
			{
				array[l].scrapPersistedThroughRounds = true;
			}
			if (spawnedSyncedObjects.Contains(((Component)array[l]).gameObject))
			{
				spawnedSyncedObjects.Remove(((Component)array[l]).gameObject);
			}
		}
		GameObject[] array4 = GameObject.FindGameObjectsWithTag("TemporaryEffect");
		for (int m = 0; m < array4.Length; m++)
		{
			Object.Destroy((Object)(object)array4[m]);
		}
	}

	public void UnloadSceneObjectsEarly()
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		Debug.Log((object)"Despawning props and enemies #3");
		isSpawningEnemies = false;
		EnemyAI[] array = Object.FindObjectsOfType<EnemyAI>();
		Debug.Log((object)$"Enemies on map: {array.Length}");
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].thisNetworkObject.IsSpawned)
			{
				Debug.Log((object)"despawn enemies on map");
				array[i].thisNetworkObject.Despawn(true);
			}
			else
			{
				Debug.Log((object)$"{array[i].thisNetworkObject} was not spawned on network, so it could not be removed.");
			}
		}
		SpawnedEnemies.Clear();
		EnemyAINestSpawnObject[] array2 = Object.FindObjectsByType<EnemyAINestSpawnObject>((FindObjectsSortMode)0);
		for (int j = 0; j < array2.Length; j++)
		{
			NetworkObject component = ((Component)array2[j]).gameObject.GetComponent<NetworkObject>();
			if ((Object)(object)component != (Object)null && component.IsSpawned)
			{
				Debug.Log((object)"despawn nest spawn object");
				component.Despawn(true);
			}
			else
			{
				Object.Destroy((Object)(object)((Component)array2[j]).gameObject);
			}
		}
		currentEnemyPower = 0f;
		currentDaytimeEnemyPower = 0f;
		currentOutsideEnemyPower = 0f;
	}

	public override void OnDestroy()
	{
		if ((Object)(object)dungeonGenerator != (Object)null)
		{
			dungeonGenerator.Generator.OnGenerationStatusChanged -= Generator_OnGenerationStatusChanged;
		}
		((NetworkBehaviour)this).OnDestroy();
	}

	[ServerRpc]
	public void FinishGeneratingNewLevelServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(710372063u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 710372063u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			FinishGeneratingNewLevelClientRpc();
		}
	}

	private void SetToCurrentLevelWeather()
	{
		TimeOfDay.Instance.currentLevelWeather = currentLevel.currentWeather;
		if (TimeOfDay.Instance.currentLevelWeather == LevelWeatherType.None || currentLevel.randomWeathers == null)
		{
			return;
		}
		for (int i = 0; i < currentLevel.randomWeathers.Length; i++)
		{
			if (currentLevel.randomWeathers[i].weatherType != currentLevel.currentWeather)
			{
				continue;
			}
			TimeOfDay.Instance.currentWeatherVariable = currentLevel.randomWeathers[i].weatherVariable;
			TimeOfDay.Instance.currentWeatherVariable2 = currentLevel.randomWeathers[i].weatherVariable2;
			if (StartOfRound.Instance.isChallengeFile)
			{
				Random random = new Random(StartOfRound.Instance.randomMapSeed);
				if (random.Next(0, 100) < 20)
				{
					TimeOfDay.Instance.currentWeatherVariable *= (float)random.Next(20, 80) * 0.02f;
				}
				if (random.Next(0, 100) < 20)
				{
					TimeOfDay.Instance.currentWeatherVariable2 *= (float)random.Next(20, 80) * 0.02f;
				}
			}
			if (TimeOfDay.Instance.currentLevelWeather == LevelWeatherType.Foggy)
			{
				TimeOfDay.Instance.currentWeatherVariable = Mathf.Max(4f, TimeOfDay.Instance.currentWeatherVariable);
			}
			TimeOfDay.Instance.SetWeatherBasedOnVariables();
		}
	}

	[ClientRpc]
	public void FinishGeneratingNewLevelClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2729232387u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2729232387u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			((Behaviour)HUDManager.Instance.loadingText).enabled = false;
			((Behaviour)HUDManager.Instance.loadingDarkenScreen).enabled = false;
			RefreshLightsList();
			((MonoBehaviour)StartOfRound.Instance).StartCoroutine(playersManager.openingDoorsSequence());
			if (currentLevel.spawnEnemiesAndScrap)
			{
				SetLevelObjectVariables();
			}
			ResetEnemySpawningVariables();
			ResetEnemyTypesSpawnedCounts();
			playersManager.newGameIsLoading = false;
			FlashlightItem.globalFlashlightInterferenceLevel = 0;
			powerOffPermanently = false;
			RefreshEnemiesList();
			try
			{
				PredictAllOutsideEnemies();
			}
			catch (Exception arg)
			{
				Debug.Log((object)$"Error caught when predicting outside enemies: {arg}");
			}
			if (StartOfRound.Instance.currentLevel.levelIncludesSnowFootprints)
			{
				StartOfRound.Instance.InstantiateFootprintsPooledObjects();
			}
		}
	}

	public void PredictAllOutsideEnemies()
	{
		//IL_05ac: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		enemyNestSpawnObjects.Clear();
		int num = 0;
		float num2 = 0f;
		bool flag = true;
		Random random = new Random(playersManager.randomMapSeed + 41);
		Random randomSeed = new Random(playersManager.randomMapSeed + 21);
		while (num < TimeOfDay.Instance.numberOfHours)
		{
			num += hourTimeBetweenEnemySpawnBatches;
			float num3 = timeScript.lengthOfHours * (float)num;
			float num4 = currentLevel.outsideEnemySpawnChanceThroughDay.Evaluate(num3 / timeScript.totalTime);
			if (StartOfRound.Instance.isChallengeFile)
			{
				num4 += 1f;
			}
			float num5 = num4 + (float)Mathf.Abs(TimeOfDay.Instance.daysUntilDeadline - 3) / 1.6f;
			int num6 = Mathf.Clamp(random.Next((int)(num5 - 3f), (int)(num4 + 3f)), minOutsideEnemiesToSpawn, 20);
			Debug.Log((object)"D");
			Debug.Log((object)$"hour: {num}; timeUpToCurrentHour: {num3}; baseChance: {num4}, enemiesToSpawn: {num6}");
			for (int i = 0; i < num6; i++)
			{
				Debug.Log((object)$"E{i}");
				SpawnProbabilities.Clear();
				int num7 = 0;
				for (int j = 0; j < currentLevel.OutsideEnemies.Count; j++)
				{
					Debug.Log((object)$"F{j}");
					EnemyType enemyType = currentLevel.OutsideEnemies[j].enemyType;
					if (flag)
					{
						enemyType.numberSpawned = 0;
					}
					Debug.Log((object)"G");
					if (enemyType.PowerLevel > currentMaxOutsidePower - num2 || enemyType.numberSpawned >= enemyType.MaxCount || enemyType.spawningDisabled)
					{
						Debug.Log((object)"I");
						Debug.Log((object)$"Setting prob to 0; {enemyType.PowerLevel} > {currentMaxOutsidePower - num2}; {enemyType.numberSpawned}");
						SpawnProbabilities.Add(0);
						continue;
					}
					Debug.Log((object)"H");
					int num8;
					if (increasedOutsideEnemySpawnRateIndex == j)
					{
						num8 = 100;
					}
					else if (enemyType.useNumberSpawnedFalloff)
					{
						num8 = (int)((float)currentLevel.OutsideEnemies[j].rarity * (enemyType.probabilityCurve.Evaluate(num3 / timeScript.totalTime) * enemyType.numberSpawnedFalloff.Evaluate((float)enemyType.numberSpawned / 10f)));
						Debug.Log((object)$"Enemy '{currentLevel.OutsideEnemies[j].enemyType.enemyName}' rarity: {currentLevel.OutsideEnemies[j].rarity}; time multiplier: {enemyType.probabilityCurve.Evaluate(num3 / timeScript.totalTime)}");
						Debug.Log((object)$"Enemy probability without number falloff: {(int)((float)currentLevel.OutsideEnemies[j].rarity * enemyType.probabilityCurve.Evaluate(num3 / timeScript.totalTime))}");
						Debug.Log((object)$"Enemy number falloff probability: {num8}; number falloff multiplier y: {enemyType.numberSpawnedFalloff.Evaluate((float)enemyType.numberSpawned / 10f)}; x : {(float)enemyType.numberSpawned / 10f}");
					}
					else
					{
						num8 = (int)((float)currentLevel.OutsideEnemies[j].rarity * enemyType.probabilityCurve.Evaluate(num3 / timeScript.totalTime));
					}
					Debug.Log((object)"J");
					SpawnProbabilities.Add(num8);
					num7 += num8;
				}
				flag = false;
				Debug.Log((object)"K");
				if (num7 <= 0)
				{
					if (num2 >= currentMaxOutsidePower)
					{
						Debug.Log((object)$"Round manager: No more spawnable outside enemies. Power count: {currentOutsideEnemyPower} ; max : {currentLevel.maxOutsideEnemyPowerCount}");
					}
					continue;
				}
				Debug.Log((object)"L");
				int randomWeightedIndex = GetRandomWeightedIndex(SpawnProbabilities.ToArray(), random);
				EnemyType enemyType2 = currentLevel.OutsideEnemies[randomWeightedIndex].enemyType;
				num2 += enemyType2.PowerLevel;
				enemyType2.numberSpawned++;
				Debug.Log((object)"M");
				Debug.Log((object)$"Got enemy that will spawn for hour #{num}: {enemyType2.enemyName}");
				if (!((Object)(object)enemyType2.nestSpawnPrefab != (Object)null))
				{
					continue;
				}
				Debug.Log((object)"N");
				if (!enemyType2.useMinEnemyThresholdForNest)
				{
					Debug.Log((object)"O");
					SpawnNestObjectForOutsideEnemy(enemyType2, randomSeed);
					continue;
				}
				Debug.Log((object)"P");
				if (enemyType2.nestsSpawned >= 1)
				{
					Debug.Log((object)"Q");
					Debug.Log((object)"Nests spawned was > 1; continuing without spawning nest");
					continue;
				}
				Debug.Log((object)"R");
				if (enemyType2.numberSpawned >= enemyType2.minEnemiesToSpawnNest)
				{
					Debug.Log((object)"S");
					SpawnNestObjectForOutsideEnemy(enemyType2, randomSeed);
				}
			}
		}
		Debug.Log((object)"T");
		enemyNestSpawnObjects.TrimExcess();
		List<NetworkObjectReference> list = new List<NetworkObjectReference>();
		for (int k = 0; k < enemyNestSpawnObjects.Count; k++)
		{
			NetworkObject component = ((Component)enemyNestSpawnObjects[k]).GetComponent<NetworkObject>();
			if ((Object)(object)component != (Object)null)
			{
				list.Add(NetworkObjectReference.op_Implicit(component));
			}
		}
		if (list.Count > 0)
		{
			SyncNestSpawnObjectsOrderServerRpc(list.ToArray());
		}
	}

	public void SpawnNestObjectForOutsideEnemy(EnemyType enemyType, Random randomSeed)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		GameObject[] array = GameObject.FindGameObjectsWithTag("OutsideAINode");
		int num = randomSeed.Next(0, array.Length);
		Vector3 val = array[0].transform.position;
		for (int i = 0; i < array.Length; i++)
		{
			val = array[num].transform.position;
			val = GetRandomNavMeshPositionInBoxPredictable(val, 15f, default(NavMeshHit), randomSeed, GetLayermaskForEnemySizeLimit(enemyType));
			val = PositionWithDenialPointsChecked(val, array, enemyType, enemyType.nestDistanceFromShip);
			Vector3 val2 = PositionEdgeCheck(val, enemyType.nestSpawnPrefabWidth);
			if (val2 == Vector3.zero)
			{
				num = (num + 1) % array.Length;
				continue;
			}
			val = val2;
			break;
		}
		GameObject val3 = Object.Instantiate<GameObject>(enemyType.nestSpawnPrefab, val, Quaternion.Euler(Vector3.zero));
		val3.transform.Rotate(Vector3.up, (float)randomSeed.Next(-180, 180), (Space)0);
		if (!Object.op_Implicit((Object)(object)val3.gameObject.GetComponentInChildren<NetworkObject>()))
		{
			Debug.LogError((object)("Error: No NetworkObject found in enemy nest spawn prefab that was just spawned on the host: '" + ((Object)val3).name + "'"));
		}
		else
		{
			val3.gameObject.GetComponentInChildren<NetworkObject>().Spawn(true);
		}
		if (!Object.op_Implicit((Object)(object)val3.GetComponent<EnemyAINestSpawnObject>()))
		{
			Debug.LogError((object)("Error: No EnemyAINestSpawnObject component in nest object prefab that was just spawned on the host: '" + ((Object)val3).name + "'"));
		}
		else
		{
			enemyNestSpawnObjects.Add(val3.GetComponent<EnemyAINestSpawnObject>());
		}
		enemyType.nestsSpawned++;
	}

	[ServerRpc]
	public void SyncNestSpawnObjectsOrderServerRpc(NetworkObjectReference[] nestObjects)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(988261632u, val, (RpcDelivery)0);
			bool flag = nestObjects != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(nestObjects, default(ForNetworkSerializable));
			}
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 988261632u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SyncNestSpawnPositionsClientRpc(nestObjects);
		}
	}

	[ClientRpc]
	public void SyncNestSpawnPositionsClientRpc(NetworkObjectReference[] nestObjects)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2813371831u, val, (RpcDelivery)0);
			bool flag = nestObjects != null;
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref flag, default(ForPrimitives));
			if (flag)
			{
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(nestObjects, default(ForNetworkSerializable));
			}
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2813371831u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost) || ((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		enemyNestSpawnObjects.Clear();
		NetworkObject val3 = default(NetworkObject);
		for (int i = 0; i < nestObjects.Length; i++)
		{
			if (((NetworkObjectReference)(ref nestObjects[i])).TryGet(ref val3, (NetworkManager)null))
			{
				EnemyAINestSpawnObject component = ((Component)val3).gameObject.GetComponent<EnemyAINestSpawnObject>();
				if ((Object)(object)component != (Object)null)
				{
					enemyNestSpawnObjects.Add(component);
				}
			}
		}
	}

	private void ResetEnemySpawningVariables()
	{
		begunSpawningEnemies = false;
		currentHour = 0;
		cannotSpawnMoreInsideEnemies = false;
		minEnemiesToSpawn = 0;
		minOutsideEnemiesToSpawn = 0;
		for (int i = 0; i < currentLevel.OutsideEnemies.Count; i++)
		{
			currentLevel.OutsideEnemies[i].enemyType.nestsSpawned = 0;
		}
	}

	public void ResetEnemyVariables()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		HoarderBugAI.grabbableObjectsInMap.Clear();
		HoarderBugAI.HoarderBugItems.Clear();
		BaboonBirdAI.baboonCampPosition = Vector3.zero;
		FlowerSnakeEnemy.mainSnakes = null;
	}

	public void CollectNewScrapForThisRound(GrabbableObject scrapObject)
	{
		if (scrapObject.itemProperties.isScrap && !scrapCollectedThisRound.Contains(scrapObject) && !scrapObject.scrapPersistedThroughRounds)
		{
			scrapCollectedThisRound.Add(scrapObject);
			HUDManager.Instance.AddNewScrapFoundToDisplay(scrapObject);
		}
	}

	public void DetectElevatorIsRunning()
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			Debug.Log((object)"Ship is leaving. Despawning props and enemies.");
			if (elevatorRunningCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(elevatorRunningCoroutine);
			}
			elevatorRunningCoroutine = ((MonoBehaviour)this).StartCoroutine(DetectElevatorRunning());
		}
	}

	private IEnumerator DetectElevatorRunning()
	{
		isSpawningEnemies = false;
		yield return (object)new WaitForSeconds(1.5f);
		Debug.Log((object)"Despawning props and enemies #2");
		UnloadSceneObjectsEarly();
	}

	public void BeginEnemySpawning()
	{
		if (((NetworkBehaviour)this).IsServer)
		{
			if (allEnemyVents.Length != 0 && currentLevel.maxEnemyPowerCount > 0)
			{
				currentEnemySpawnIndex = 0;
				PlotOutEnemiesForNextHour();
				isSpawningEnemies = true;
			}
			else
			{
				Debug.Log((object)"Not able to spawn enemies on map; no vents were detected or maxEnemyPowerCount is 0.");
			}
		}
	}

	public void SpawnEnemiesOutside()
	{
		if (currentOutsideEnemyPower > currentMaxOutsidePower)
		{
			Debug.Log((object)"Cannot spawn more outside enemies: max power count has been reached");
			return;
		}
		float num = timeScript.lengthOfHours * (float)currentHour;
		float num2 = (float)(int)(currentLevel.outsideEnemySpawnChanceThroughDay.Evaluate(num / timeScript.totalTime) * 100f) / 100f;
		if (StartOfRound.Instance.isChallengeFile)
		{
			num2 += 1f;
		}
		float num3 = num2 + (float)Mathf.Abs(TimeOfDay.Instance.daysUntilDeadline - 3) / 1.6f;
		int num4 = Mathf.Clamp(OutsideEnemySpawnRandom.Next((int)(num3 - 3f), (int)(num2 + 3f)), minOutsideEnemiesToSpawn, 20);
		GameObject[] spawnPoints = GameObject.FindGameObjectsWithTag("OutsideAINode");
		for (int i = 0; i < num4; i++)
		{
			if (!SpawnRandomOutsideEnemy(spawnPoints, num))
			{
				break;
			}
		}
	}

	public void SpawnDaytimeEnemiesOutside()
	{
		if (currentLevel.DaytimeEnemies == null || currentLevel.DaytimeEnemies.Count <= 0 || currentDaytimeEnemyPower > (float)currentLevel.maxDaytimeEnemyPowerCount)
		{
			return;
		}
		float num = timeScript.lengthOfHours * (float)currentHour;
		float num2 = currentLevel.daytimeEnemySpawnChanceThroughDay.Evaluate(num / timeScript.totalTime);
		int num3 = Mathf.Clamp(AnomalyRandom.Next((int)(num2 - currentLevel.daytimeEnemiesProbabilityRange), (int)(num2 + currentLevel.daytimeEnemiesProbabilityRange)), 0, 20);
		GameObject[] spawnPoints = GameObject.FindGameObjectsWithTag("OutsideAINode");
		for (int i = 0; i < num3; i++)
		{
			if (!SpawnRandomDaytimeEnemy(spawnPoints, num))
			{
				break;
			}
		}
	}

	private bool SpawnRandomDaytimeEnemy(GameObject[] spawnPoints, float timeUpToCurrentHour)
	{
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		SpawnProbabilities.Clear();
		int num = 0;
		for (int i = 0; i < currentLevel.DaytimeEnemies.Count; i++)
		{
			EnemyType enemyType = currentLevel.DaytimeEnemies[i].enemyType;
			if (firstTimeSpawningDaytimeEnemies)
			{
				enemyType.numberSpawned = 0;
			}
			if (enemyType.PowerLevel > (float)currentLevel.maxDaytimeEnemyPowerCount - currentDaytimeEnemyPower || enemyType.numberSpawned >= currentLevel.DaytimeEnemies[i].enemyType.MaxCount || enemyType.normalizedTimeInDayToLeave < TimeOfDay.Instance.normalizedTimeOfDay || enemyType.spawningDisabled)
			{
				SpawnProbabilities.Add(0);
				continue;
			}
			int num2 = (int)((float)currentLevel.DaytimeEnemies[i].rarity * enemyType.probabilityCurve.Evaluate(timeUpToCurrentHour / timeScript.totalTime));
			SpawnProbabilities.Add(num2);
			num += num2;
		}
		firstTimeSpawningDaytimeEnemies = false;
		if (num <= 0)
		{
			_ = currentDaytimeEnemyPower;
			_ = (float)currentLevel.maxDaytimeEnemyPowerCount;
			return false;
		}
		int randomWeightedIndex = GetRandomWeightedIndex(SpawnProbabilities.ToArray(), EnemySpawnRandom);
		EnemyType enemyType2 = currentLevel.DaytimeEnemies[randomWeightedIndex].enemyType;
		bool result = false;
		float num3 = Mathf.Max(enemyType2.spawnInGroupsOf, 1);
		for (int j = 0; (float)j < num3; j++)
		{
			if (enemyType2.PowerLevel > (float)currentLevel.maxDaytimeEnemyPowerCount - currentDaytimeEnemyPower)
			{
				break;
			}
			currentDaytimeEnemyPower += currentLevel.DaytimeEnemies[randomWeightedIndex].enemyType.PowerLevel;
			Vector3 position = spawnPoints[AnomalyRandom.Next(0, spawnPoints.Length)].transform.position;
			position = GetRandomNavMeshPositionInBoxPredictable(position, 10f, default(NavMeshHit), EnemySpawnRandom, GetLayermaskForEnemySizeLimit(enemyType2));
			position = PositionWithDenialPointsChecked(position, spawnPoints, enemyType2);
			GameObject val = Object.Instantiate<GameObject>(enemyType2.enemyPrefab, position, Quaternion.Euler(Vector3.zero));
			val.gameObject.GetComponentInChildren<NetworkObject>().Spawn(true);
			SpawnedEnemies.Add(val.GetComponent<EnemyAI>());
			val.GetComponent<EnemyAI>().enemyType.numberSpawned++;
			result = true;
		}
		return result;
	}

	private bool SpawnRandomOutsideEnemy(GameObject[] spawnPoints, float timeUpToCurrentHour)
	{
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		SpawnProbabilities.Clear();
		int num = 0;
		MoldSpreadManager moldSpreadManager = Object.FindObjectOfType<MoldSpreadManager>();
		int num2 = 0;
		if ((Object)(object)moldSpreadManager != (Object)null)
		{
			num2 = moldSpreadManager.generatedMold.Count;
		}
		for (int i = 0; i < currentLevel.OutsideEnemies.Count; i++)
		{
			EnemyType enemyType = currentLevel.OutsideEnemies[i].enemyType;
			if (firstTimeSpawningOutsideEnemies)
			{
				enemyType.numberSpawned = 0;
			}
			if (enemyType.PowerLevel > currentMaxOutsidePower - currentOutsideEnemyPower || enemyType.numberSpawned >= enemyType.MaxCount || enemyType.spawningDisabled)
			{
				SpawnProbabilities.Add(0);
				continue;
			}
			int num3 = ((increasedOutsideEnemySpawnRateIndex == i) ? 100 : ((!enemyType.useNumberSpawnedFalloff) ? ((int)((float)currentLevel.OutsideEnemies[i].rarity * enemyType.probabilityCurve.Evaluate(timeUpToCurrentHour / timeScript.totalTime))) : ((int)((float)currentLevel.OutsideEnemies[i].rarity * (enemyType.probabilityCurve.Evaluate(timeUpToCurrentHour / timeScript.totalTime) * enemyType.numberSpawnedFalloff.Evaluate((float)enemyType.numberSpawned / 10f))))));
			if (enemyType.spawnFromWeeds)
			{
				num3 = (int)Mathf.Clamp((float)num3 * ((float)num2 / 60f), 0f, 200f);
			}
			SpawnProbabilities.Add(num3);
			num += num3;
		}
		firstTimeSpawningOutsideEnemies = false;
		if (num <= 0)
		{
			_ = currentOutsideEnemyPower;
			_ = currentMaxOutsidePower;
			return false;
		}
		bool result = false;
		int randomWeightedIndex = GetRandomWeightedIndex(SpawnProbabilities.ToArray(), OutsideEnemySpawnRandom);
		EnemyType enemyType2 = currentLevel.OutsideEnemies[randomWeightedIndex].enemyType;
		if (enemyType2.requireNestObjectsToSpawn)
		{
			bool flag = false;
			EnemyAINestSpawnObject[] array = Object.FindObjectsByType<EnemyAINestSpawnObject>((FindObjectsSortMode)0);
			for (int j = 0; j < array.Length; j++)
			{
				if ((Object)(object)array[j].enemyType == (Object)(object)enemyType2)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				return false;
			}
		}
		float num4 = Mathf.Max(enemyType2.spawnInGroupsOf, 1);
		for (int k = 0; (float)k < num4; k++)
		{
			if (enemyType2.PowerLevel > currentMaxOutsidePower - currentOutsideEnemyPower)
			{
				break;
			}
			currentOutsideEnemyPower += currentLevel.OutsideEnemies[randomWeightedIndex].enemyType.PowerLevel;
			Vector3 position = spawnPoints[AnomalyRandom.Next(0, spawnPoints.Length)].transform.position;
			position = GetRandomNavMeshPositionInBoxPredictable(position, 10f, default(NavMeshHit), AnomalyRandom, GetLayermaskForEnemySizeLimit(enemyType2));
			position = PositionWithDenialPointsChecked(position, spawnPoints, enemyType2);
			GameObject val = Object.Instantiate<GameObject>(enemyType2.enemyPrefab, position, Quaternion.Euler(Vector3.zero));
			val.gameObject.GetComponentInChildren<NetworkObject>().Spawn(true);
			SpawnedEnemies.Add(val.GetComponent<EnemyAI>());
			val.GetComponent<EnemyAI>().enemyType.numberSpawned++;
			result = true;
		}
		Debug.Log((object)("Spawned enemy: " + enemyType2.enemyName));
		return result;
	}

	public int GetLayermaskForEnemySizeLimit(EnemyType enemyType)
	{
		if (enemyType.SizeLimit == NavSizeLimit.MediumSpaces)
		{
			return -97;
		}
		if (enemyType.SizeLimit == NavSizeLimit.SmallSpaces)
		{
			return -33;
		}
		return -1;
	}

	public Vector3 PositionWithDenialPointsChecked(Vector3 spawnPosition, GameObject[] spawnPoints, EnemyType enemyType, float distanceFromShip = -1f)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (spawnPoints.Length == 0)
		{
			Debug.LogError((object)"Spawn points array was null in denial points check function!");
			return spawnPosition;
		}
		int num = 0;
		bool flag = false;
		for (int i = 0; i < spawnPoints.Length - 1; i++)
		{
			for (int j = 0; j < spawnDenialPoints.Length; j++)
			{
				flag = true;
				if (Vector3.Distance(spawnPosition, spawnDenialPoints[j].transform.position) < 16f || (distanceFromShip != -1f && Vector3.Distance(spawnPosition, ((Component)StartOfRound.Instance.shipLandingPosition).transform.position) < distanceFromShip))
				{
					num = (num + 1) % spawnPoints.Length;
					spawnPosition = spawnPoints[num].transform.position;
					spawnPosition = GetRandomNavMeshPositionInBoxPredictable(spawnPosition, 10f, default(NavMeshHit), AnomalyRandom, GetLayermaskForEnemySizeLimit(enemyType));
					flag = false;
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		return spawnPosition;
	}

	public void PlotOutEnemiesForNextHour()
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		List<EnemyVent> list = new List<EnemyVent>();
		for (int i = 0; i < allEnemyVents.Length; i++)
		{
			if (!allEnemyVents[i].occupied)
			{
				list.Add(allEnemyVents[i]);
			}
		}
		enemySpawnTimes.Clear();
		float num = currentLevel.enemySpawnChanceThroughoutDay.Evaluate(timeScript.currentDayTime / timeScript.totalTime);
		if (StartOfRound.Instance.isChallengeFile)
		{
			num += 1f;
		}
		float num2 = num + (float)Mathf.Abs(TimeOfDay.Instance.daysUntilDeadline - 3) / 1.6f;
		int num3 = Mathf.Clamp(AnomalyRandom.Next((int)(num2 - currentLevel.spawnProbabilityRange), (int)(num + currentLevel.spawnProbabilityRange)), minEnemiesToSpawn, 20);
		if (enemyRushIndex != -1)
		{
			num3 += 2;
		}
		num3 = Mathf.Clamp(num3, 0, list.Count);
		if (currentEnemyPower >= currentMaxInsidePower)
		{
			cannotSpawnMoreInsideEnemies = true;
			return;
		}
		float num4 = timeScript.lengthOfHours * (float)currentHour;
		for (int j = 0; j < num3; j++)
		{
			int num5 = AnomalyRandom.Next((int)(10f + num4), (int)(timeScript.lengthOfHours * (float)hourTimeBetweenEnemySpawnBatches + num4));
			int index = AnomalyRandom.Next(list.Count);
			if (!AssignRandomEnemyToVent(list[index], num5))
			{
				break;
			}
			list.RemoveAt(index);
			enemySpawnTimes.Add(num5);
		}
		enemySpawnTimes.Sort();
	}

	public void LogEnemySpawnTimes(bool couldNotFinish)
	{
		if (couldNotFinish)
		{
			Debug.Log((object)"Stopped assigning enemies to vents early as there was no enemy with a power count low enough to fit.");
		}
		Debug.Log((object)"Enemy spawn times:");
		for (int i = 0; i < enemySpawnTimes.Count; i++)
		{
			Debug.Log((object)$"time {i}: {enemySpawnTimes[i]}");
		}
	}

	private bool AssignRandomEnemyToVent(EnemyVent vent, float spawnTime)
	{
		SpawnProbabilities.Clear();
		int num = 0;
		for (int i = 0; i < currentLevel.Enemies.Count; i++)
		{
			EnemyType enemyType = currentLevel.Enemies[i].enemyType;
			if (firstTimeSpawningEnemies)
			{
				enemyType.numberSpawned = 0;
			}
			if (EnemyCannotBeSpawned(i))
			{
				SpawnProbabilities.Add(0);
				continue;
			}
			Debug.Log((object)$"enemy rush index is {enemyRushIndex}; current index {i}");
			int num2 = ((enemyRushIndex != -1) ? ((enemyRushIndex != i) ? 1 : 100) : ((increasedInsideEnemySpawnRateIndex == i) ? 100 : ((!enemyType.useNumberSpawnedFalloff) ? ((int)((float)currentLevel.Enemies[i].rarity * enemyType.probabilityCurve.Evaluate(timeScript.normalizedTimeOfDay))) : ((int)((float)currentLevel.Enemies[i].rarity * (enemyType.probabilityCurve.Evaluate(timeScript.normalizedTimeOfDay) * enemyType.numberSpawnedFalloff.Evaluate((float)enemyType.numberSpawned / 10f)))))));
			if (enemyType.increasedChanceInterior != -1 && currentDungeonType == enemyType.increasedChanceInterior)
			{
				num2 = (int)Mathf.Min((float)num2 * 1.7f, 100f);
			}
			Debug.Log((object)$"Probability: {num2}; enemy type: {enemyType.enemyName}");
			SpawnProbabilities.Add(num2);
			num += num2;
		}
		firstTimeSpawningEnemies = false;
		if (num <= 0)
		{
			if (currentEnemyPower >= currentMaxInsidePower)
			{
				Debug.Log((object)$"Round manager: No more spawnable enemies. Power count: {currentLevel.maxEnemyPowerCount} Max: {currentLevel.maxEnemyPowerCount}");
				cannotSpawnMoreInsideEnemies = true;
			}
			return false;
		}
		int randomWeightedIndex = GetRandomWeightedIndex(SpawnProbabilities.ToArray(), EnemySpawnRandom);
		Debug.Log((object)$"ADDING ENEMY #{randomWeightedIndex}: {currentLevel.Enemies[randomWeightedIndex].enemyType.enemyName}");
		Debug.Log((object)$"Adding {currentLevel.Enemies[randomWeightedIndex].enemyType.PowerLevel} to power level, enemy: {currentLevel.Enemies[randomWeightedIndex].enemyType.enemyName}");
		currentEnemyPower += currentLevel.Enemies[randomWeightedIndex].enemyType.PowerLevel;
		vent.enemyType = currentLevel.Enemies[randomWeightedIndex].enemyType;
		vent.enemyTypeIndex = randomWeightedIndex;
		vent.occupied = true;
		vent.spawnTime = spawnTime;
		if (timeScript.hour - currentHour > 0)
		{
			Debug.Log((object)"RoundManager is catching up to current time! Not syncing vent SFX with clients since enemy will spawn from vent almost immediately.");
		}
		else
		{
			vent.SyncVentSpawnTimeClientRpc((int)spawnTime, randomWeightedIndex);
		}
		currentLevel.Enemies[randomWeightedIndex].enemyType.numberSpawned++;
		return true;
	}

	private bool EnemyCannotBeSpawned(int enemyIndex)
	{
		if (!currentLevel.Enemies[enemyIndex].enemyType.spawningDisabled)
		{
			if (!(currentLevel.Enemies[enemyIndex].enemyType.PowerLevel > currentMaxInsidePower - currentEnemyPower))
			{
				return currentLevel.Enemies[enemyIndex].enemyType.numberSpawned >= currentLevel.Enemies[enemyIndex].enemyType.MaxCount;
			}
			return true;
		}
		return true;
	}

	public void InitializeRandomNumberGenerators()
	{
		SoundManager.Instance.InitializeRandom();
		LevelRandom = new Random(playersManager.randomMapSeed);
		AnomalyRandom = new Random(playersManager.randomMapSeed + 5);
		EnemySpawnRandom = new Random(playersManager.randomMapSeed + 40);
		OutsideEnemySpawnRandom = new Random(playersManager.randomMapSeed + 41);
		BreakerBoxRandom = new Random(playersManager.randomMapSeed + 20);
	}

	public void SpawnEnemyFromVent(EnemyVent vent)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = vent.floorNode.position;
		float y = vent.floorNode.eulerAngles.y;
		SpawnEnemyOnServer(position, y, vent.enemyTypeIndex);
		Debug.Log((object)"Spawned enemy from vent");
		vent.OpenVentClientRpc();
		vent.occupied = false;
	}

	public void SpawnEnemyOnServer(Vector3 spawnPosition, float yRot, int enemyNumber = -1)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			SpawnEnemyServerRpc(spawnPosition, yRot, enemyNumber);
		}
		else
		{
			SpawnEnemyGameObject(spawnPosition, yRot, enemyNumber);
		}
	}

	[ServerRpc]
	public void SpawnEnemyServerRpc(Vector3 spawnPosition, float yRot, int enemyNumber)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Invalid comparison between Unknown and I4
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(46494176u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref spawnPosition);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref yRot, default(ForPrimitives));
			BytePacker.WriteValueBitPacked(val2, enemyNumber);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 46494176u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SpawnEnemyGameObject(spawnPosition, yRot, enemyNumber);
		}
	}

	public NetworkObjectReference SpawnEnemyGameObject(Vector3 spawnPosition, float yRot, int enemyNumber, EnemyType enemyType = null)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			return NetworkObjectReference.op_Implicit(currentLevel.Enemies[0].enemyType.enemyPrefab.GetComponent<NetworkObject>());
		}
		if ((Object)(object)enemyType != (Object)null)
		{
			GameObject val = Object.Instantiate<GameObject>(enemyType.enemyPrefab, spawnPosition, Quaternion.Euler(new Vector3(0f, yRot, 0f)));
			val.GetComponentInChildren<NetworkObject>().Spawn(true);
			SpawnedEnemies.Add(val.GetComponent<EnemyAI>());
			return NetworkObjectReference.op_Implicit(val.GetComponentInChildren<NetworkObject>());
		}
		int index = enemyNumber;
		switch (enemyNumber)
		{
		case -1:
			index = Random.Range(0, currentLevel.Enemies.Count);
			break;
		case -2:
		{
			GameObject val3 = Object.Instantiate<GameObject>(currentLevel.DaytimeEnemies[Random.Range(0, currentLevel.DaytimeEnemies.Count)].enemyType.enemyPrefab, spawnPosition, Quaternion.Euler(new Vector3(0f, yRot, 0f)));
			val3.GetComponentInChildren<NetworkObject>().Spawn(true);
			SpawnedEnemies.Add(val3.GetComponent<EnemyAI>());
			return NetworkObjectReference.op_Implicit(val3.GetComponentInChildren<NetworkObject>());
		}
		case -3:
		{
			GameObject val2 = Object.Instantiate<GameObject>(currentLevel.OutsideEnemies[Random.Range(0, currentLevel.OutsideEnemies.Count)].enemyType.enemyPrefab, spawnPosition, Quaternion.Euler(new Vector3(0f, yRot, 0f)));
			val2.GetComponentInChildren<NetworkObject>().Spawn(true);
			SpawnedEnemies.Add(val2.GetComponent<EnemyAI>());
			return NetworkObjectReference.op_Implicit(val2.GetComponentInChildren<NetworkObject>());
		}
		}
		GameObject val4 = Object.Instantiate<GameObject>(currentLevel.Enemies[index].enemyType.enemyPrefab, spawnPosition, Quaternion.Euler(new Vector3(0f, yRot, 0f)));
		val4.GetComponentInChildren<NetworkObject>().Spawn(true);
		SpawnedEnemies.Add(val4.GetComponent<EnemyAI>());
		return NetworkObjectReference.op_Implicit(val4.GetComponentInChildren<NetworkObject>());
	}

	public void DespawnEnemyOnServer(NetworkObject enemyNetworkObject)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsServer)
		{
			DespawnEnemyServerRpc(NetworkObjectReference.op_Implicit(enemyNetworkObject));
		}
		else
		{
			DespawnEnemyGameObject(NetworkObjectReference.op_Implicit(enemyNetworkObject));
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void DespawnEnemyServerRpc(NetworkObjectReference enemyNetworkObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3840785488u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref enemyNetworkObject, default(ForNetworkSerializable));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3840785488u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				DespawnEnemyGameObject(enemyNetworkObject);
			}
		}
	}

	private void DespawnEnemyGameObject(NetworkObjectReference enemyNetworkObject)
	{
		NetworkObject val = default(NetworkObject);
		if (((NetworkObjectReference)(ref enemyNetworkObject)).TryGet(ref val, (NetworkManager)null))
		{
			EnemyAI component = ((Component)val).gameObject.GetComponent<EnemyAI>();
			SpawnedEnemies.Remove(component);
			if (component.enemyType.isOutsideEnemy)
			{
				currentOutsideEnemyPower -= component.enemyType.PowerLevel;
			}
			else if (component.enemyType.isDaytimeEnemy)
			{
				currentDaytimeEnemyPower -= component.enemyType.PowerLevel;
			}
			else
			{
				currentEnemyPower -= component.enemyType.PowerLevel;
			}
			cannotSpawnMoreInsideEnemies = false;
			Debug.Log((object)"Despawning enemy");
			((Component)component).gameObject.GetComponent<NetworkObject>().Despawn(true);
		}
		else
		{
			Debug.LogError((object)"Round manager despawn enemy gameobject: Could not get network object from reference!");
		}
	}

	public void SwitchPower(bool on)
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (on)
		{
			if (!powerOffPermanently)
			{
				PowerSwitchOnClientRpc();
			}
		}
		else
		{
			PowerSwitchOffClientRpc();
		}
	}

	[ClientRpc]
	public void PowerSwitchOnClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1061166170u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1061166170u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				((UnityEvent<bool>)onPowerSwitch).Invoke(true);
				TurnOnAllLights(on: true);
			}
		}
	}

	[ClientRpc]
	public void PowerSwitchOffClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1586488299u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1586488299u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				Debug.Log((object)"Calling power switch off event from roundmanager");
				((UnityEvent<bool>)onPowerSwitch).Invoke(false);
				TurnOnAllLights(on: false);
			}
		}
	}

	public void TurnOnAllLights(bool on)
	{
		if (powerLightsCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(powerLightsCoroutine);
		}
		powerLightsCoroutine = ((MonoBehaviour)this).StartCoroutine(turnOnLights(on));
	}

	private IEnumerator turnOnLights(bool turnOn)
	{
		yield return null;
		BreakerBox breakerBox = Object.FindObjectOfType<BreakerBox>();
		if ((Object)(object)breakerBox != (Object)null)
		{
			breakerBox.thisAudioSource.PlayOneShot(breakerBox.switchPowerSFX);
			breakerBox.isPowerOn = turnOn;
		}
		int b = 4;
		while (b > 0 && b != 0)
		{
			for (int i = 0; i < allPoweredLightsAnimators.Count / b; i++)
			{
				allPoweredLightsAnimators[i].SetBool("on", turnOn);
			}
			yield return (object)new WaitForSeconds(0.03f);
			b--;
		}
	}

	public void FlickerLights(bool flickerFlashlights = false, bool disableFlashlights = false)
	{
		if (flickerLightsCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(flickerLightsCoroutine);
		}
		flickerLightsCoroutine = ((MonoBehaviour)this).StartCoroutine(FlickerPoweredLights(flickerFlashlights, disableFlashlights));
	}

	private IEnumerator FlickerPoweredLights(bool flickerFlashlights = false, bool disableFlashlights = false)
	{
		Debug.Log((object)"Flickering lights");
		if (flickerFlashlights)
		{
			Debug.Log((object)"Flickering flashlights");
			FlashlightItem.globalFlashlightInterferenceLevel = 1;
			FlashlightItem[] array = Object.FindObjectsOfType<FlashlightItem>();
			if (array != null)
			{
				for (int i = 0; i < array.Length; i++)
				{
					array[i].flashlightAudio.PlayOneShot(array[i].flashlightFlicker);
					WalkieTalkie.TransmitOneShotAudio(array[i].flashlightAudio, array[i].flashlightFlicker, 0.8f);
					if (disableFlashlights && (Object)(object)array[i].playerHeldBy != (Object)null && array[i].playerHeldBy.isInsideFactory)
					{
						array[i].flashlightInterferenceLevel = 2;
					}
				}
			}
		}
		if (allPoweredLightsAnimators.Count > 0 && (Object)(object)allPoweredLightsAnimators[0] != (Object)null)
		{
			int loopCount = 0;
			int b = 4;
			while (b > 0 && b != 0)
			{
				for (int j = loopCount; j < allPoweredLightsAnimators.Count / b; j++)
				{
					loopCount++;
					allPoweredLightsAnimators[j].SetTrigger("Flicker");
				}
				yield return (object)new WaitForSeconds(0.05f);
				b--;
			}
		}
		if (!flickerFlashlights)
		{
			yield break;
		}
		yield return (object)new WaitForSeconds(0.3f);
		FlashlightItem[] array2 = Object.FindObjectsOfType<FlashlightItem>();
		if (array2 != null)
		{
			for (int k = 0; k < array2.Length; k++)
			{
				array2[k].flashlightInterferenceLevel = 0;
			}
		}
		FlashlightItem.globalFlashlightInterferenceLevel = 0;
	}

	private void Start()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		RefreshLightsList();
		RefreshEnemyVents();
		timeScript = Object.FindObjectOfType<TimeOfDay>();
		FlashlightItem.globalFlashlightInterferenceLevel = 0;
		navHit = default(NavMeshHit);
		if ((Object)(object)StartOfRound.Instance.testRoom != (Object)null)
		{
			outsideAINodes = GameObject.FindGameObjectsWithTag("OutsideAINode");
		}
	}

	private void ResetEnemyTypesSpawnedCounts()
	{
		EnemyAI[] array = Object.FindObjectsOfType<EnemyAI>();
		for (int i = 0; i < currentLevel.Enemies.Count; i++)
		{
			currentLevel.Enemies[i].enemyType.numberSpawned = 0;
			for (int j = 0; j < array.Length; j++)
			{
				if ((Object)(object)array[j].enemyType == (Object)(object)currentLevel.Enemies[i].enemyType)
				{
					currentLevel.Enemies[i].enemyType.numberSpawned++;
				}
			}
		}
		for (int k = 0; k < currentLevel.OutsideEnemies.Count; k++)
		{
			currentLevel.OutsideEnemies[k].enemyType.numberSpawned = 0;
			for (int l = 0; l < array.Length; l++)
			{
				if ((Object)(object)array[l].enemyType == (Object)(object)currentLevel.OutsideEnemies[k].enemyType)
				{
					currentLevel.OutsideEnemies[k].enemyType.numberSpawned++;
				}
			}
		}
	}

	private void RefreshEnemiesList()
	{
		SpawnedEnemies.Clear();
		EnemyAI[] array = Object.FindObjectsOfType<EnemyAI>();
		SpawnedEnemies.AddRange(array);
		numberOfEnemiesInScene = array.Length;
		firstTimeSpawningEnemies = true;
		firstTimeSpawningOutsideEnemies = true;
		firstTimeSpawningDaytimeEnemies = true;
		firstTimeSpawningWeedEnemies = true;
		if (StartOfRound.Instance.isChallengeFile)
		{
			Random random = new Random(StartOfRound.Instance.randomMapSeed + 5781);
			currentMaxInsidePower = currentLevel.maxEnemyPowerCount + random.Next(0, 8);
			currentMaxOutsidePower = currentLevel.maxOutsideEnemyPowerCount + random.Next(0, 8);
			enemyRushIndex = -1;
			return;
		}
		enemyRushIndex = -1;
		currentMaxInsidePower = currentLevel.maxEnemyPowerCount;
		DateTime dateTime = new DateTime(DateTime.Now.Year, 10, 23);
		bool num = DateTime.Today == dateTime;
		Random random2 = new Random(StartOfRound.Instance.randomMapSeed + 5781);
		if ((!num && random2.Next(0, 210) < 4) || random2.Next(0, 1000) < 7)
		{
			((Component)indoorFog).gameObject.SetActive(random2.Next(0, 100) < 20);
			if (random2.Next(0, 100) < 25)
			{
				for (int i = 0; i < currentLevel.Enemies.Count; i++)
				{
					if (currentLevel.Enemies[i].enemyType.enemyName == "Nutcracker")
					{
						enemyRushIndex = i;
						currentMaxInsidePower = 20f;
						break;
					}
				}
				if (enemyRushIndex == -1)
				{
					for (int j = 0; j < currentLevel.Enemies.Count; j++)
					{
						if (currentLevel.Enemies[j].enemyType.enemyName == "Hoarding bug")
						{
							enemyRushIndex = j;
							currentMaxInsidePower = 30f;
							break;
						}
					}
				}
			}
			else
			{
				for (int k = 0; k < currentLevel.Enemies.Count; k++)
				{
					if (currentLevel.Enemies[k].enemyType.enemyName == "Hoarding bug")
					{
						enemyRushIndex = k;
						currentMaxInsidePower = 30f;
						break;
					}
				}
			}
		}
		else
		{
			((Component)indoorFog).gameObject.SetActive(random2.Next(0, 150) < 3);
		}
		currentMaxOutsidePower = currentLevel.maxOutsideEnemyPowerCount;
	}

	private void Update()
	{
		if (!((NetworkBehaviour)this).IsServer || !dungeonFinishedGeneratingForAllPlayers)
		{
			return;
		}
		if (isSpawningEnemies)
		{
			SpawnInsideEnemiesFromVentsIfReady();
			if (timeScript.hour > currentHour && currentEnemySpawnIndex >= enemySpawnTimes.Count)
			{
				AdvanceHourAndSpawnNewBatchOfEnemies();
			}
		}
		else if (timeScript.currentDayTime > 85f && !begunSpawningEnemies)
		{
			begunSpawningEnemies = true;
			BeginEnemySpawning();
		}
	}

	private void SpawnInsideEnemiesFromVentsIfReady()
	{
		if (enemySpawnTimes.Count <= currentEnemySpawnIndex || !(timeScript.currentDayTime > (float)enemySpawnTimes[currentEnemySpawnIndex]))
		{
			return;
		}
		for (int i = 0; i < allEnemyVents.Length; i++)
		{
			if (allEnemyVents[i].occupied && timeScript.currentDayTime > allEnemyVents[i].spawnTime)
			{
				Debug.Log((object)("Found enemy vent which has its time up: " + ((Object)((Component)allEnemyVents[i]).gameObject).name + ". Spawning " + allEnemyVents[i].enemyType.enemyName + " from vent."));
				SpawnEnemyFromVent(allEnemyVents[i]);
			}
		}
		currentEnemySpawnIndex++;
	}

	private void AdvanceHourAndSpawnNewBatchOfEnemies()
	{
		currentHour += hourTimeBetweenEnemySpawnBatches;
		SpawnDaytimeEnemiesOutside();
		SpawnEnemiesOutside();
		if (allEnemyVents.Length != 0 && !cannotSpawnMoreInsideEnemies)
		{
			currentEnemySpawnIndex = 0;
			if (StartOfRound.Instance.connectedPlayersAmount + 1 > 0 && TimeOfDay.Instance.daysUntilDeadline <= 2 && (((float)(valueOfFoundScrapItems / TimeOfDay.Instance.profitQuota) > 0.8f && TimeOfDay.Instance.normalizedTimeOfDay > 0.3f) || (float)valueOfFoundScrapItems / totalScrapValueInLevel > 0.65f || StartOfRound.Instance.daysPlayersSurvivedInARow >= 5) && minEnemiesToSpawn == 0)
			{
				Debug.Log((object)"Min enemy spawn chance per hour set to 1!!!");
				minEnemiesToSpawn = 1;
			}
			PlotOutEnemiesForNextHour();
		}
		else
		{
			Debug.Log((object)$"Could not spawn more enemies; vents #: {allEnemyVents.Length}. CannotSpawnMoreInsideEnemies: {cannotSpawnMoreInsideEnemies}");
		}
	}

	public void RefreshLightsList()
	{
		allPoweredLights.Clear();
		allPoweredLightsAnimators.Clear();
		GameObject[] array = GameObject.FindGameObjectsWithTag("PoweredLight");
		if (array == null)
		{
			return;
		}
		for (int i = 0; i < array.Length; i++)
		{
			Animator componentInChildren = array[i].GetComponentInChildren<Animator>();
			if (!((Object)(object)componentInChildren == (Object)null))
			{
				allPoweredLightsAnimators.Add(componentInChildren);
				allPoweredLights.Add(array[i].GetComponentInChildren<Light>(true));
			}
		}
		for (int j = 0; j < allPoweredLightsAnimators.Count; j++)
		{
			allPoweredLightsAnimators[j].SetFloat("flickerSpeed", Random.Range(0.6f, 1.4f));
		}
	}

	public void RefreshEnemyVents()
	{
		allEnemyVents = Object.FindObjectsOfType<EnemyVent>();
	}

	private void SpawnOutsideHazards()
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0428: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0432: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_0477: Unknown result type (might be due to invalid IL or missing references)
		//IL_0481: Unknown result type (might be due to invalid IL or missing references)
		//IL_0486: Unknown result type (might be due to invalid IL or missing references)
		//IL_049b: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0528: Unknown result type (might be due to invalid IL or missing references)
		//IL_0557: Unknown result type (might be due to invalid IL or missing references)
		//IL_057f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bb: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 2);
		outsideAINodes = (from x in GameObject.FindGameObjectsWithTag("OutsideAINode")
			orderby Vector3.Distance(x.transform.position, Vector3.zero)
			select x).ToArray();
		NavMeshHit val = default(NavMeshHit);
		int num = 0;
		if (TimeOfDay.Instance.currentLevelWeather == LevelWeatherType.Rainy)
		{
			num = random.Next(5, 15);
			if (random.Next(0, 100) < 7)
			{
				num = random.Next(5, 30);
			}
			for (int i = 0; i < num; i++)
			{
				Vector3 position = outsideAINodes[random.Next(0, outsideAINodes.Length)].transform.position;
				Vector3 val2 = GetRandomNavMeshPositionInBoxPredictable(position, 30f, val, random) + Vector3.up;
				GameObject val3 = Object.Instantiate<GameObject>(quicksandPrefab, val2, Quaternion.identity, mapPropsContainer.transform);
			}
		}
		int num2 = 0;
		List<Vector3> list = new List<Vector3>();
		spawnDenialPoints = GameObject.FindGameObjectsWithTag("SpawnDenialPoint");
		if (currentLevel.spawnableOutsideObjects != null)
		{
			RaycastHit val4 = default(RaycastHit);
			for (int j = 0; j < currentLevel.spawnableOutsideObjects.Length; j++)
			{
				double num3 = random.NextDouble();
				num = (int)currentLevel.spawnableOutsideObjects[j].randomAmount.Evaluate((float)num3);
				if (increasedMapPropSpawnRateIndex == j)
				{
					num += 12;
				}
				if ((float)random.Next(0, 100) < 20f)
				{
					num *= 2;
				}
				for (int k = 0; k < num; k++)
				{
					int num4 = random.Next(0, outsideAINodes.Length);
					Vector3 val2 = GetRandomNavMeshPositionInBoxPredictable(outsideAINodes[num4].transform.position, 30f, val, random);
					if (currentLevel.spawnableOutsideObjects[j].spawnableObject.spawnableFloorTags != null)
					{
						bool flag = false;
						if (Physics.Raycast(val2 + Vector3.up, Vector3.down, ref val4, 5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault))
						{
							for (int l = 0; l < currentLevel.spawnableOutsideObjects[j].spawnableObject.spawnableFloorTags.Length; l++)
							{
								if (((Component)((Component)((RaycastHit)(ref val4)).collider).transform).CompareTag(currentLevel.spawnableOutsideObjects[j].spawnableObject.spawnableFloorTags[l]))
								{
									flag = true;
									break;
								}
							}
						}
						if (!flag)
						{
							continue;
						}
					}
					val2 = PositionEdgeCheck(val2, currentLevel.spawnableOutsideObjects[j].spawnableObject.objectWidth);
					if (val2 == Vector3.zero)
					{
						continue;
					}
					bool flag2 = false;
					for (int m = 0; m < shipSpawnPathPoints.Length; m++)
					{
						if (Vector3.Distance(((Component)shipSpawnPathPoints[m]).transform.position, val2) < (float)currentLevel.spawnableOutsideObjects[j].spawnableObject.objectWidth + 6f)
						{
							flag2 = true;
							break;
						}
					}
					if (flag2)
					{
						continue;
					}
					for (int n = 0; n < spawnDenialPoints.Length; n++)
					{
						if (Vector3.Distance(spawnDenialPoints[n].transform.position, val2) < (float)currentLevel.spawnableOutsideObjects[j].spawnableObject.objectWidth + 6f)
						{
							flag2 = true;
							break;
						}
					}
					if (flag2)
					{
						continue;
					}
					if (Vector3.Distance(GameObject.FindGameObjectWithTag("ItemShipLandingNode").transform.position, val2) < (float)currentLevel.spawnableOutsideObjects[j].spawnableObject.objectWidth + 4f)
					{
						flag2 = true;
						break;
					}
					if (flag2)
					{
						continue;
					}
					if (currentLevel.spawnableOutsideObjects[j].spawnableObject.objectWidth > 4)
					{
						flag2 = false;
						for (int num5 = 0; num5 < list.Count; num5++)
						{
							if (Vector3.Distance(val2, list[num5]) < (float)currentLevel.spawnableOutsideObjects[j].spawnableObject.objectWidth)
							{
								flag2 = true;
								break;
							}
						}
						if (flag2)
						{
							continue;
						}
					}
					list.Add(val2);
					GameObject val3 = Object.Instantiate<GameObject>(currentLevel.spawnableOutsideObjects[j].spawnableObject.prefabToSpawn, val2 - Vector3.up * 0.7f, Quaternion.identity, mapPropsContainer.transform);
					num2++;
					if (currentLevel.spawnableOutsideObjects[j].spawnableObject.spawnFacingAwayFromWall)
					{
						val3.transform.eulerAngles = new Vector3(0f, YRotationThatFacesTheFarthestFromPosition(val2 + Vector3.up * 0.2f), 0f);
					}
					else
					{
						int num6 = random.Next(0, 360);
						val3.transform.eulerAngles = new Vector3(val3.transform.eulerAngles.x, (float)num6, val3.transform.eulerAngles.z);
					}
					val3.transform.localEulerAngles = new Vector3(val3.transform.localEulerAngles.x + currentLevel.spawnableOutsideObjects[j].spawnableObject.rotationOffset.x, val3.transform.localEulerAngles.y + currentLevel.spawnableOutsideObjects[j].spawnableObject.rotationOffset.y, val3.transform.localEulerAngles.z + currentLevel.spawnableOutsideObjects[j].spawnableObject.rotationOffset.z);
				}
			}
		}
		if (num2 > 0)
		{
			GameObject val5 = GameObject.FindGameObjectWithTag("OutsideLevelNavMesh");
			if ((Object)(object)val5 != (Object)null)
			{
				val5.GetComponent<NavMeshSurface>().BuildNavMesh();
			}
		}
		bakedNavMesh = true;
	}

	public Vector3 PositionEdgeCheck(Vector3 position, float width)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (NavMesh.FindClosestEdge(position, ref navHit, -1) && ((NavMeshHit)(ref navHit)).distance < width)
		{
			Vector3 position2 = ((NavMeshHit)(ref navHit)).position;
			Ray val = default(Ray);
			((Ray)(ref val))._002Ector(position2, position - position2);
			if (NavMesh.SamplePosition(((Ray)(ref val)).GetPoint(width + 0.5f), ref navHit, 10f, -1))
			{
				position = ((NavMeshHit)(ref navHit)).position;
				return position;
			}
			return Vector3.zero;
		}
		return position;
	}

	private void SpawnRandomStoryLogs()
	{
	}

	public void SetLevelObjectVariables()
	{
		((MonoBehaviour)this).StartCoroutine(waitForMainEntranceTeleportToSpawn());
	}

	private IEnumerator waitForMainEntranceTeleportToSpawn()
	{
		float startTime = Time.timeSinceLevelLoad;
		while (FindMainEntrancePosition() == Vector3.zero && Time.timeSinceLevelLoad - startTime < 15f)
		{
			yield return (object)new WaitForSeconds(1f);
		}
		Vector3 val = FindMainEntrancePosition();
		SetLockedDoors(val);
		SetSteamValveTimes(val);
		SetBigDoorCodes(val);
		SetExitIDs(val);
		SetPowerOffAtStart();
	}

	private void SetPowerOffAtStart()
	{
		if (new Random(StartOfRound.Instance.randomMapSeed + 3).NextDouble() < 0.07999999821186066)
		{
			TurnBreakerSwitchesOff();
			if (!((NetworkBehaviour)this).IsServer)
			{
				((UnityEvent<bool>)onPowerSwitch).Invoke(false);
				TurnOnAllLights(on: false);
			}
			Debug.Log((object)"Turning lights off at start");
		}
		else
		{
			TurnOnAllLights(on: true);
			Debug.Log((object)"Turning lights on at start");
		}
	}

	private void SetBigDoorCodes(Vector3 mainEntrancePosition)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 17);
		TerminalAccessibleObject[] array = Object.FindObjectsOfType<TerminalAccessibleObject>().OrderBy(delegate(TerminalAccessibleObject x)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			Vector3 val = ((Component)x).transform.position - mainEntrancePosition;
			return ((Vector3)(ref val)).sqrMagnitude;
		}).ToArray();
		int num = 3;
		int num2 = 0;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].InitializeValues();
			array[i].SetCodeTo(random.Next(possibleCodesForBigDoors.Length));
			if (array[i].isBigDoor && (num2 < num || random.NextDouble() < 0.2199999988079071))
			{
				num2++;
				array[i].SetDoorOpen(open: true);
			}
		}
	}

	private void SetExitIDs(Vector3 mainEntrancePosition)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		int num = 1;
		EntranceTeleport[] array = Object.FindObjectsOfType<EntranceTeleport>().OrderBy(delegate(EntranceTeleport x)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			Vector3 val = ((Component)x).transform.position - mainEntrancePosition;
			return ((Vector3)(ref val)).sqrMagnitude;
		}).ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].entranceId == 1 && !array[i].isEntranceToBuilding)
			{
				array[i].entranceId = num;
				num++;
			}
		}
	}

	private void SetSteamValveTimes(Vector3 mainEntrancePosition)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 513);
		SteamValveHazard[] array = Object.FindObjectsOfType<SteamValveHazard>().OrderBy(delegate(SteamValveHazard x)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			Vector3 val = ((Component)x).transform.position - mainEntrancePosition;
			return ((Vector3)(ref val)).sqrMagnitude;
		}).ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			if (random.NextDouble() < 0.75)
			{
				array[i].valveBurstTime = Mathf.Clamp((float)random.NextDouble(), 0.2f, 1f);
				array[i].valveCrackTime = array[i].valveBurstTime * (float)random.NextDouble();
				array[i].fogSizeMultiplier = Mathf.Clamp((float)random.NextDouble(), 0.6f, 0.98f);
			}
			else if (random.NextDouble() < 0.25)
			{
				array[i].valveCrackTime = Mathf.Clamp((float)random.NextDouble(), 0.3f, 0.9f);
			}
		}
	}

	private void SetLockedDoors(Vector3 mainEntrancePosition)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		if (mainEntrancePosition == Vector3.zero)
		{
			Debug.Log((object)"Main entrance teleport was not spawned on local client within 12 seconds. Locking doors based on origin instead.");
		}
		List<DoorLock> list = Object.FindObjectsOfType<DoorLock>().ToList();
		for (int num = list.Count - 1; num >= 0; num--)
		{
			if (((Component)list[num]).transform.position.y > -160f || !list[num].canBeLocked)
			{
				list.RemoveAt(num);
			}
		}
		list = list.OrderByDescending(delegate(DoorLock x)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			Vector3 val = mainEntrancePosition - ((Component)x).transform.position;
			return ((Vector3)(ref val)).sqrMagnitude;
		}).ToList();
		float num2 = 1.1f;
		int num3 = 0;
		for (int i = 0; i < list.Count; i++)
		{
			if (LevelRandom.NextDouble() < (double)num2)
			{
				float timeToLockPick = Mathf.Clamp((float)LevelRandom.Next(2, 90), 2f, 32f);
				list[i].LockDoor(timeToLockPick);
				num3++;
			}
			num2 /= 1.55f;
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		GameObject[] array;
		int maxValue;
		if (currentDungeonType != 4)
		{
			array = insideAINodes;
			maxValue = insideAINodes.Length;
		}
		else
		{
			array = insideAINodes.OrderBy((GameObject x) => Vector3.Distance(x.transform.position, mainEntrancePosition)).ToArray();
			maxValue = array.Length / 3;
		}
		for (int j = 0; j < num3; j++)
		{
			int num4 = AnomalyRandom.Next(0, maxValue);
			Vector3 randomNavMeshPositionInBoxPredictable = GetRandomNavMeshPositionInBoxPredictable(array[num4].transform.position, 8f, navHit, AnomalyRandom);
			Object.Instantiate<GameObject>(keyPrefab, randomNavMeshPositionInBoxPredictable, Quaternion.identity, spawnedScrapContainer).GetComponent<NetworkObject>().Spawn(false);
		}
	}

	public void DestroyTreeOnLocalClient(Vector3 pos)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (DestroyTreeAtPosition(pos))
		{
			BreakTreeServerRpc(pos, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
		}
	}

	public bool DestroyTreeAtPosition(Vector3 pos, float range = 5f)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		int num = Physics.OverlapSphereNonAlloc(pos, range, tempColliderResults, 33554432, (QueryTriggerInteraction)1);
		if (num == 0)
		{
			return false;
		}
		float num2 = Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, pos);
		if (num2 < 15f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
		}
		else if (num2 < 25f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Small);
		}
		GameObject val;
		AudioClip clip;
		AudioClip clip2;
		if (((Component)tempColliderResults[0]).gameObject.CompareTag("Wood"))
		{
			val = breakTreePrefab;
			clip = breakTreeAudio1;
			clip2 = breakTreeAudio2;
		}
		else
		{
			val = breakSnowmanPrefab;
			clip = breakSnowmanAudio1;
			clip2 = breakSnowmanAudio1;
		}
		for (int i = 0; i < num; i++)
		{
			Object.Destroy((Object)(object)((Component)tempColliderResults[i]).gameObject);
			AudioSource component = Object.Instantiate<GameObject>(val, ((Component)tempColliderResults[i]).gameObject.transform.position + Vector3.up, Quaternion.identity).GetComponent<AudioSource>();
			if (Random.Range(0, 20) < 10)
			{
				component.clip = clip;
			}
			else
			{
				component.clip = clip2;
			}
			component.Play();
		}
		return true;
	}

	[ServerRpc]
	public void TurnSnowmanServerRpc(Vector3 pos, Vector3 turnRotation, bool laugh)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Invalid comparison between Unknown and I4
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2148210082u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref turnRotation);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref laugh, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2148210082u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			TurnSnowmanClientRpc(pos, turnRotation, laugh);
		}
	}

	[ClientRpc]
	public void TurnSnowmanClientRpc(Vector3 pos, Vector3 turnRotation, bool laugh)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2670749869u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref turnRotation);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref laugh, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2670749869u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		int num = Physics.OverlapSphereNonAlloc(pos, 10f, tempColliderResults, 33554432, (QueryTriggerInteraction)1);
		for (int i = 0; i < num; i++)
		{
			if (!((Component)tempColliderResults[i]).gameObject.CompareTag("Snowman"))
			{
				continue;
			}
			((Component)tempColliderResults[i]).gameObject.transform.eulerAngles = turnRotation;
			if (!laugh)
			{
				continue;
			}
			AudioSource component = ((Component)tempColliderResults[i]).gameObject.GetComponent<AudioSource>();
			if (Object.op_Implicit((Object)(object)component))
			{
				if (Random.Range(0, 100) < 7)
				{
					component.pitch = Random.Range(0.2f, 0.4f);
				}
				component.pitch = Random.Range(0.93f, 1.1f);
				component.PlayOneShot(snowmanLaughSFX[Random.Range(0, snowmanLaughSFX.Length)]);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void BreakTreeServerRpc(Vector3 pos, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(759068055u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 759068055u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				BreakTreeClientRpc(pos, playerWhoSent);
			}
		}
	}

	[ClientRpc]
	public void BreakTreeClientRpc(Vector3 pos, int playerWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1487127043u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref pos);
				BytePacker.WriteValueBitPacked(val2, playerWhoSent);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1487127043u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerWhoSent)
			{
				DestroyTreeAtPosition(pos);
			}
		}
	}

	[ServerRpc]
	public void LightningStrikeServerRpc(Vector3 strikePosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Invalid comparison between Unknown and I4
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1145714957u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref strikePosition);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1145714957u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			LightningStrikeClientRpc(strikePosition);
		}
	}

	[ClientRpc]
	public void LightningStrikeClientRpc(Vector3 strikePosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(112447504u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref strikePosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 112447504u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				Object.FindObjectOfType<StormyWeather>(true).LightningStrike(strikePosition, useTargetedObject: true);
			}
		}
	}

	[ServerRpc]
	public void ShowStaticElectricityWarningServerRpc(NetworkObjectReference warningObject, float timeLeft)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Invalid comparison between Unknown and I4
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(445397880u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref warningObject, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeLeft, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 445397880u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			ShowStaticElectricityWarningClientRpc(warningObject, timeLeft);
		}
	}

	[ClientRpc]
	public void ShowStaticElectricityWarningClientRpc(NetworkObjectReference warningObject, float timeLeft)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3840203489u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref warningObject, default(ForNetworkSerializable));
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref timeLeft, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3840203489u, val, (RpcDelivery)0);
			}
			NetworkObject warningObject2 = default(NetworkObject);
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && ((NetworkObjectReference)(ref warningObject)).TryGet(ref warningObject2, (NetworkManager)null))
			{
				Object.FindObjectOfType<StormyWeather>(true).SetStaticElectricityWarning(warningObject2, timeLeft);
			}
		}
	}

	public Vector3 RandomlyOffsetPosition(Vector3 pos, float maxRadius, float padding = 1f)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		tempTransform.position = pos;
		tempTransform.eulerAngles = Vector3.forward;
		Ray val = default(Ray);
		RaycastHit val2 = default(RaycastHit);
		for (int i = 0; i < 5; i++)
		{
			float num = Random.Range(-180f, 180f);
			tempTransform.localEulerAngles = new Vector3(0f, tempTransform.localEulerAngles.y + num, 0f);
			((Ray)(ref val))._002Ector(tempTransform.position, tempTransform.forward);
			if (Physics.Raycast(val, ref val2, 6f, 2304))
			{
				float num2 = ((RaycastHit)(ref val2)).distance - padding;
				if (num2 < 0f)
				{
					return ((Ray)(ref val)).GetPoint(num2);
				}
				float num3 = Mathf.Clamp(Random.Range(0.1f, maxRadius), 0f, num2);
				return ((Ray)(ref val)).GetPoint(num3);
			}
		}
		return pos;
	}

	public static Vector3 RandomPointInBounds(Bounds bounds)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		return new Vector3(Random.Range(((Bounds)(ref bounds)).min.x, ((Bounds)(ref bounds)).max.x), Random.Range(((Bounds)(ref bounds)).min.y, ((Bounds)(ref bounds)).max.y), Random.Range(((Bounds)(ref bounds)).min.z, ((Bounds)(ref bounds)).max.z));
	}

	public Vector3 GetNavMeshPosition(Vector3 pos, NavMeshHit navMeshHit = default(NavMeshHit), float sampleRadius = 5f, int areaMask = -1)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		if (NavMesh.SamplePosition(pos, ref navMeshHit, sampleRadius, areaMask))
		{
			GotNavMeshPositionResult = true;
			return ((NavMeshHit)(ref navMeshHit)).position;
		}
		GotNavMeshPositionResult = false;
		return pos;
	}

	public Transform GetClosestNode(Vector3 pos, bool outside = true)
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		GameObject[] array;
		if (outside)
		{
			if (outsideAINodes == null)
			{
				outsideAINodes = GameObject.FindGameObjectsWithTag("OutsideAINode");
			}
			array = outsideAINodes;
		}
		else
		{
			if (insideAINodes == null)
			{
				outsideAINodes = GameObject.FindGameObjectsWithTag("AINode");
			}
			array = insideAINodes;
		}
		float num = 99999f;
		int num2 = 0;
		for (int i = 0; i < array.Length; i++)
		{
			Vector3 val = array[i].transform.position - pos;
			float sqrMagnitude = ((Vector3)(ref val)).sqrMagnitude;
			if (sqrMagnitude < num)
			{
				num = sqrMagnitude;
				num2 = i;
			}
		}
		return array[num2].transform;
	}

	public Vector3 GetRandomNavMeshPositionInRadius(Vector3 pos, float radius = 10f, NavMeshHit navHit = default(NavMeshHit))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		float y = pos.y;
		pos = Random.insideUnitSphere * radius + pos;
		pos.y = y;
		if (NavMesh.SamplePosition(pos, ref navHit, radius, -1))
		{
			return ((NavMeshHit)(ref navHit)).position;
		}
		Debug.Log((object)"Unable to get random nav mesh position in radius! Returning old pos");
		return pos;
	}

	public Vector3 GetRandomNavMeshPositionInBoxPredictable(Vector3 pos, float radius = 10f, NavMeshHit navHit = default(NavMeshHit), Random randomSeed = null, int layerMask = -1, float verticalScale = 1f)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		float y = pos.y;
		float num = RandomNumberInRadius(radius, randomSeed);
		float num2 = RandomNumberInRadius(radius * verticalScale, randomSeed);
		float num3 = RandomNumberInRadius(radius, randomSeed);
		Vector3 val = new Vector3(num, num2, num3) + pos;
		val.y = y;
		float num4 = Vector3.Distance(pos, val);
		if (NavMesh.SamplePosition(val, ref navHit, num4 + 2f, layerMask))
		{
			return ((NavMeshHit)(ref navHit)).position;
		}
		return pos;
	}

	public Vector3 GetRandomPositionInBoxPredictable(Vector3 pos, float radius = 10f, Random randomSeed = null)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		float num = RandomNumberInRadius(radius, randomSeed);
		float num2 = RandomNumberInRadius(radius, randomSeed);
		float num3 = RandomNumberInRadius(radius, randomSeed);
		return new Vector3(num, num2, num3) + pos;
	}

	private float RandomNumberInRadius(float radius, Random randomSeed)
	{
		return ((float)randomSeed.NextDouble() - 0.5f) * radius;
	}

	public Vector3 GetRandomNavMeshPositionInRadiusSpherical(Vector3 pos, float radius = 10f, NavMeshHit navHit = default(NavMeshHit))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		pos = Random.insideUnitSphere * radius + pos;
		if (NavMesh.SamplePosition(pos, ref navHit, radius + 2f, 1))
		{
			Debug.DrawRay(pos + Vector3.forward * 0.01f, Vector3.up * 2f, Color.blue);
			return ((NavMeshHit)(ref navHit)).position;
		}
		Debug.DrawRay(pos + Vector3.forward * 0.01f, Vector3.up * 2f, Color.yellow);
		return pos;
	}

	public Vector3 GetRandomPositionInRadius(Vector3 pos, float minRadius, float radius, Random randomGen = null)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		radius *= 2f;
		float num = RandomFloatWithinRadius(minRadius, radius, randomGen);
		float num2 = RandomFloatWithinRadius(minRadius, radius, randomGen);
		float num3 = RandomFloatWithinRadius(minRadius, radius, randomGen);
		return new Vector3(pos.x + num, pos.y + num2, pos.z + num3);
	}

	private float RandomFloatWithinRadius(float minValue, float radius, Random randomGenerator)
	{
		if (randomGenerator == null)
		{
			return Random.Range(minValue, radius) * ((Random.value > 0.5f) ? 1f : (-1f));
		}
		return (float)randomGenerator.Next((int)minValue, (int)radius) * ((randomGenerator.NextDouble() > 0.5) ? 1f : (-1f));
	}

	public static Vector3 AverageOfLivingGroupedPlayerPositions()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.zero;
		for (int i = 0; i < StartOfRound.Instance.connectedPlayersAmount + 1; i++)
		{
			if (StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled && !StartOfRound.Instance.allPlayerScripts[i].isPlayerAlone)
			{
				val += ((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.position;
			}
		}
		return val / (float)(StartOfRound.Instance.connectedPlayersAmount + 1);
	}

	public void PlayAudibleNoise(Vector3 noisePosition, float noiseRange = 10f, float noiseLoudness = 0.5f, int timesPlayedInSameSpot = 0, bool noiseIsInsideClosedShip = false, int noiseID = 0)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		if (noiseIsInsideClosedShip)
		{
			noiseRange /= 2f;
		}
		int num = Physics.OverlapSphereNonAlloc(noisePosition, noiseRange, tempColliderResults, 8912896);
		INoiseListener noiseListener = default(INoiseListener);
		for (int i = 0; i < num; i++)
		{
			if (!((Component)((Component)tempColliderResults[i]).transform).TryGetComponent<INoiseListener>(ref noiseListener))
			{
				continue;
			}
			if (noiseIsInsideClosedShip)
			{
				EnemyAI component = ((Component)tempColliderResults[i]).gameObject.GetComponent<EnemyAI>();
				if (((Object)(object)component == (Object)null || !component.isInsidePlayerShip) && noiseLoudness < 0.9f)
				{
					continue;
				}
			}
			noiseListener.DetectNoise(noisePosition, noiseLoudness, timesPlayedInSameSpot, noiseID);
		}
	}

	public static int PlayRandomClip(AudioSource audioSource, AudioClip[] clipsArray, bool randomize = true, float oneShotVolume = 1f, int audibleNoiseID = 0, int maxIndex = 1000)
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (randomize)
		{
			audioSource.pitch = Random.Range(0.94f, 1.06f);
		}
		int num = Random.Range(0, Mathf.Min(maxIndex, clipsArray.Length));
		audioSource.PlayOneShot(clipsArray[num], Random.Range(oneShotVolume - 0.18f, oneShotVolume));
		WalkieTalkie.TransmitOneShotAudio(audioSource, clipsArray[num], 0.85f);
		if (audioSource.spatialBlend > 0f && audibleNoiseID >= 0)
		{
			Instance.PlayAudibleNoise(((Component)audioSource).transform.position, 4f * oneShotVolume, oneShotVolume / 2f, 0, noiseIsInsideClosedShip: true, audibleNoiseID);
		}
		return num;
	}

	public static EntranceTeleport FindMainEntranceScript(bool getOutsideEntrance = false)
	{
		EntranceTeleport[] array = Object.FindObjectsOfType<EntranceTeleport>(false);
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].entranceId != 0)
			{
				continue;
			}
			if (!getOutsideEntrance)
			{
				if (!array[i].isEntranceToBuilding)
				{
					return array[i];
				}
			}
			else if (array[i].isEntranceToBuilding)
			{
				return array[i];
			}
		}
		if (array.Length == 0)
		{
			Debug.LogError((object)"Main entrance was not spawned and could not be found; returning null");
			return null;
		}
		Debug.LogError((object)"Main entrance script could not be found. Returning first entrance teleport script found.");
		return array[0];
	}

	public static Vector3 FindMainEntrancePosition(bool getTeleportPosition = false, bool getOutsideEntrance = false)
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		EntranceTeleport[] array = Object.FindObjectsOfType<EntranceTeleport>(false);
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].entranceId != 0)
			{
				continue;
			}
			if (!getOutsideEntrance)
			{
				if (!array[i].isEntranceToBuilding)
				{
					if (getTeleportPosition)
					{
						return array[i].entrancePoint.position;
					}
					return ((Component)array[i]).transform.position;
				}
			}
			else if (array[i].isEntranceToBuilding)
			{
				if (getTeleportPosition)
				{
					return array[i].entrancePoint.position;
				}
				return ((Component)array[i]).transform.position;
			}
		}
		Debug.LogError((object)"Main entrance position could not be found. Returning origin.");
		return Vector3.zero;
	}

	public int GetRandomWeightedIndex(int[] weights, Random randomSeed = null)
	{
		if (randomSeed == null)
		{
			randomSeed = AnomalyRandom;
		}
		if (weights == null || weights.Length == 0)
		{
			Debug.Log((object)"Could not get random weighted index; array is empty or null.");
			return -1;
		}
		int num = 0;
		for (int i = 0; i < weights.Length; i++)
		{
			if (weights[i] >= 0)
			{
				num += weights[i];
			}
		}
		if (num <= 0)
		{
			return randomSeed.Next(0, weights.Length);
		}
		float num2 = (float)randomSeed.NextDouble();
		float num3 = 0f;
		for (int i = 0; i < weights.Length; i++)
		{
			if (!((float)weights[i] <= 0f))
			{
				num3 += (float)weights[i] / (float)num;
				if (num3 >= num2)
				{
					return i;
				}
			}
		}
		Debug.LogError((object)"Error while calculating random weighted index. Choosing randomly. Weights given:");
		for (int i = 0; i < weights.Length; i++)
		{
			Debug.LogError((object)$"{weights[i]},");
		}
		if (!hasInitializedLevelRandomSeed)
		{
			InitializeRandomNumberGenerators();
		}
		return randomSeed.Next(0, weights.Length);
	}

	public int GetRandomWeightedIndexList(List<int> weights, Random randomSeed = null)
	{
		if (weights == null || weights.Count == 0)
		{
			Debug.Log((object)"Could not get random weighted index; array is empty or null.");
			return -1;
		}
		int num = 0;
		for (int i = 0; i < weights.Count; i++)
		{
			if (weights[i] >= 0)
			{
				num += weights[i];
			}
		}
		float num2 = ((randomSeed != null) ? ((float)randomSeed.NextDouble()) : Random.value);
		float num3 = 0f;
		for (int i = 0; i < weights.Count; i++)
		{
			if (!((float)weights[i] <= 0f))
			{
				num3 += (float)weights[i] / (float)num;
				if (num3 >= num2)
				{
					return i;
				}
			}
		}
		Debug.LogError((object)"Error while calculating random weighted index.");
		for (int i = 0; i < weights.Count; i++)
		{
			Debug.LogError((object)$"{weights[i]},");
		}
		if (!hasInitializedLevelRandomSeed)
		{
			InitializeRandomNumberGenerators();
		}
		return randomSeed.Next(0, weights.Count);
	}

	public int GetWeightedValue(int indexLength)
	{
		return Mathf.Clamp(Random.Range(0, indexLength * 2) - (indexLength - 1), 0, indexLength);
	}

	private static int SortBySize(int p1, int p2)
	{
		return p1.CompareTo(p2);
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_RoundManager()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected O, but got Unknown
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Expected O, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected O, but got Unknown
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1659269112u, new RpcReceiveHandler(__rpc_handler_1659269112));
		NetworkManager.__rpc_func_table.Add(3073943002u, new RpcReceiveHandler(__rpc_handler_3073943002));
		NetworkManager.__rpc_func_table.Add(192551691u, new RpcReceiveHandler(__rpc_handler_192551691));
		NetworkManager.__rpc_func_table.Add(710372063u, new RpcReceiveHandler(__rpc_handler_710372063));
		NetworkManager.__rpc_func_table.Add(2729232387u, new RpcReceiveHandler(__rpc_handler_2729232387));
		NetworkManager.__rpc_func_table.Add(988261632u, new RpcReceiveHandler(__rpc_handler_988261632));
		NetworkManager.__rpc_func_table.Add(2813371831u, new RpcReceiveHandler(__rpc_handler_2813371831));
		NetworkManager.__rpc_func_table.Add(46494176u, new RpcReceiveHandler(__rpc_handler_46494176));
		NetworkManager.__rpc_func_table.Add(3840785488u, new RpcReceiveHandler(__rpc_handler_3840785488));
		NetworkManager.__rpc_func_table.Add(1061166170u, new RpcReceiveHandler(__rpc_handler_1061166170));
		NetworkManager.__rpc_func_table.Add(1586488299u, new RpcReceiveHandler(__rpc_handler_1586488299));
		NetworkManager.__rpc_func_table.Add(2148210082u, new RpcReceiveHandler(__rpc_handler_2148210082));
		NetworkManager.__rpc_func_table.Add(2670749869u, new RpcReceiveHandler(__rpc_handler_2670749869));
		NetworkManager.__rpc_func_table.Add(759068055u, new RpcReceiveHandler(__rpc_handler_759068055));
		NetworkManager.__rpc_func_table.Add(1487127043u, new RpcReceiveHandler(__rpc_handler_1487127043));
		NetworkManager.__rpc_func_table.Add(1145714957u, new RpcReceiveHandler(__rpc_handler_1145714957));
		NetworkManager.__rpc_func_table.Add(112447504u, new RpcReceiveHandler(__rpc_handler_112447504));
		NetworkManager.__rpc_func_table.Add(445397880u, new RpcReceiveHandler(__rpc_handler_445397880));
		NetworkManager.__rpc_func_table.Add(3840203489u, new RpcReceiveHandler(__rpc_handler_3840203489));
	}

	private static void __rpc_handler_1659269112(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			NetworkObjectReference[] spawnedScrap = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref spawnedScrap, default(ForNetworkSerializable));
			}
			bool flag2 = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag2, default(ForPrimitives));
			int[] allScrapValue = null;
			if (flag2)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref allScrapValue, default(ForPrimitives));
			}
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).SyncScrapValuesClientRpc(spawnedScrap, allScrapValue);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3073943002(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int randomSeed = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref randomSeed);
			int levelID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref levelID);
			int moldIterations = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref moldIterations);
			int moldStartPosition = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref moldStartPosition);
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			int[] syncDestroyedMold = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<int>(ref syncDestroyedMold, default(ForPrimitives));
			}
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).GenerateNewLevelClientRpc(randomSeed, levelID, moldIterations, moldStartPosition, syncDestroyedMold);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_192551691(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			ulong clientId = default(ulong);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RoundManager)(object)target).FinishedGeneratingLevelServerRpc(clientId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_710372063(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RoundManager)(object)target).FinishGeneratingNewLevelServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2729232387(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).FinishGeneratingNewLevelClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_988261632(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		bool flag = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
		NetworkObjectReference[] nestObjects = null;
		if (flag)
		{
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref nestObjects, default(ForNetworkSerializable));
		}
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((RoundManager)(object)target).SyncNestSpawnObjectsOrderServerRpc(nestObjects);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_2813371831(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool flag = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref flag, default(ForPrimitives));
			NetworkObjectReference[] nestObjects = null;
			if (flag)
			{
				((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref nestObjects, default(ForNetworkSerializable));
			}
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).SyncNestSpawnPositionsClientRpc(nestObjects);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_46494176(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 spawnPosition = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref spawnPosition);
		float yRot = default(float);
		((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref yRot, default(ForPrimitives));
		int enemyNumber = default(int);
		ByteUnpacker.ReadValueBitPacked(reader, ref enemyNumber);
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((RoundManager)(object)target).SpawnEnemyServerRpc(spawnPosition, yRot, enemyNumber);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_3840785488(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference enemyNetworkObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref enemyNetworkObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RoundManager)(object)target).DespawnEnemyServerRpc(enemyNetworkObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1061166170(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).PowerSwitchOnClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1586488299(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).PowerSwitchOffClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2148210082(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
			return;
		}
		Vector3 pos = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
		Vector3 turnRotation = default(Vector3);
		((FastBufferReader)(ref reader)).ReadValueSafe(ref turnRotation);
		bool laugh = default(bool);
		((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref laugh, default(ForPrimitives));
		target.__rpc_exec_stage = (__RpcExecStage)1;
		((RoundManager)(object)target).TurnSnowmanServerRpc(pos, turnRotation, laugh);
		target.__rpc_exec_stage = (__RpcExecStage)0;
	}

	private static void __rpc_handler_2670749869(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			Vector3 turnRotation = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref turnRotation);
			bool laugh = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref laugh, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).TurnSnowmanClientRpc(pos, turnRotation, laugh);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_759068055(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RoundManager)(object)target).BreakTreeServerRpc(pos, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1487127043(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 pos = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref pos);
			int playerWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).BreakTreeClientRpc(pos, playerWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1145714957(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			Vector3 strikePosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref strikePosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RoundManager)(object)target).LightningStrikeServerRpc(strikePosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_112447504(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 strikePosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref strikePosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).LightningStrikeClientRpc(strikePosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_445397880(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			NetworkObjectReference warningObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref warningObject, default(ForNetworkSerializable));
			float timeLeft = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeLeft, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RoundManager)(object)target).ShowStaticElectricityWarningServerRpc(warningObject, timeLeft);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3840203489(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference warningObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref warningObject, default(ForNetworkSerializable));
			float timeLeft = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timeLeft, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RoundManager)(object)target).ShowStaticElectricityWarningClientRpc(warningObject, timeLeft);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "RoundManager";
	}
}
