using TMPro;
using UnityEngine;

public class DisplayCompanyBuyingRate : MonoBehaviour
{
	public TextMeshProUGUI displayText;

	private void Update()
	{
		((TMP_Text)displayText).text = $"{Mathf.RoundToInt(StartOfRound.Instance.companyBuyingRate * 100f)}%";
	}
}
