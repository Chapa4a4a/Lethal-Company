using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class PlayerPhysicsRegion : MonoBehaviour
{
	public Transform physicsTransform;

	public NetworkObject parentNetworkObject;

	public bool allowDroppingItems;

	private float checkInterval;

	private bool hasLocalPlayer;

	public int priority;

	public bool disablePhysicsRegion;

	public Collider physicsCollider;

	public Collider itemDropCollider;

	public Vector3 addPositionOffsetToItems;

	public float maxTippingAngle = 180f;

	private bool removePlayerNextFrame;

	private void OnDestroy()
	{
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		disablePhysicsRegion = true;
		if (StartOfRound.Instance.CurrentPlayerPhysicsRegions.Contains(this))
		{
			StartOfRound.Instance.CurrentPlayerPhysicsRegions.Remove(this);
		}
		for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
		{
			if ((Object)(object)((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.parent == (Object)(object)physicsTransform)
			{
				((Component)StartOfRound.Instance.allPlayerScripts[i]).transform.SetParent((Transform)null);
				Debug.Log((object)$"Player {i} setting parent null since physics region was destroyed");
			}
		}
		GrabbableObject[] componentsInChildren = ((Component)physicsTransform).GetComponentsInChildren<GrabbableObject>();
		for (int j = 0; j < componentsInChildren.Length; j++)
		{
			if ((Object)(object)RoundManager.Instance.mapPropsContainer != (Object)null)
			{
				((Component)componentsInChildren[j]).transform.SetParent(RoundManager.Instance.mapPropsContainer.transform, true);
			}
			else
			{
				((Component)componentsInChildren[j]).transform.SetParent((Transform)null, true);
			}
			if (!componentsInChildren[j].isHeld)
			{
				componentsInChildren[j].FallToGround();
			}
		}
	}

	private void OnTriggerStay(Collider other)
	{
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			hasLocalPlayer = false;
			return;
		}
		string tag = ((Component)other).gameObject.tag;
		if (tag.StartsWith("PlayerRagdoll") && ((Object)((Component)other).gameObject).name == "spine.002")
		{
			PlayerControllerB playerControllerB = null;
			switch (tag)
			{
			case "PlayerRagdoll":
				playerControllerB = StartOfRound.Instance.allPlayerScripts[0];
				break;
			case "PlayerRagdoll1":
				playerControllerB = StartOfRound.Instance.allPlayerScripts[1];
				break;
			case "PlayerRagdoll2":
				playerControllerB = StartOfRound.Instance.allPlayerScripts[2];
				break;
			case "PlayerRagdoll3":
				playerControllerB = StartOfRound.Instance.allPlayerScripts[3];
				break;
			}
			if ((Object)(object)playerControllerB != (Object)null && (Object)(object)playerControllerB.deadBody != (Object)null && !playerControllerB.deadBody.isParentedToPhysicsRegion)
			{
				playerControllerB.deadBody.SetPhysicsParent(physicsTransform, physicsCollider);
			}
		}
		else
		{
			if (!((Component)other).gameObject.CompareTag("Player"))
			{
				return;
			}
			PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if (Object.op_Implicit((Object)(object)component) && !((Object)(object)component != (Object)(object)GameNetworkManager.Instance.localPlayerController))
			{
				checkInterval = 0f;
				removePlayerNextFrame = false;
				if (StartOfRound.Instance.CurrentPlayerPhysicsRegions != null && !StartOfRound.Instance.CurrentPlayerPhysicsRegions.Contains(this))
				{
					StartOfRound.Instance.CurrentPlayerPhysicsRegions.Add(this);
					hasLocalPlayer = true;
				}
			}
		}
	}

	private bool IsPhysicsRegionActive()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Angle(((Component)this).transform.up, Vector3.up) > maxTippingAngle)
		{
			return false;
		}
		if (disablePhysicsRegion)
		{
			return false;
		}
		return true;
	}

	private void Update()
	{
		physicsCollider.enabled = IsPhysicsRegionActive();
		if (!hasLocalPlayer)
		{
			return;
		}
		if (checkInterval > 0.15f)
		{
			if (!removePlayerNextFrame)
			{
				removePlayerNextFrame = true;
				return;
			}
			removePlayerNextFrame = false;
			checkInterval = 0f;
			hasLocalPlayer = false;
			StartOfRound.Instance.CurrentPlayerPhysicsRegions.Remove(this);
		}
		else
		{
			checkInterval += Time.deltaTime;
		}
	}
}
