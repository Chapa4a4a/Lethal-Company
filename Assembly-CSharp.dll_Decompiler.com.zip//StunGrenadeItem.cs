using System;
using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class StunGrenadeItem : GrabbableObject
{
	[Header("Stun grenade settings")]
	public float TimeToExplode = 2.25f;

	public bool DestroyGrenade;

	public string playerAnimation = "PullGrenadePin";

	[Space(5f)]
	public bool explodeOnCollision;

	public bool dontRequirePullingPin;

	public float chanceToExplode = 100f;

	public bool spawnDamagingShockwave;

	private bool explodeOnThrow;

	private bool gotExplodeOnThrowRPC;

	private bool hasCollided;

	[Space(3f)]
	public bool pinPulled;

	public bool inPullingPinAnimation;

	public string throwString = "Throw grenade: [RMB]";

	private Coroutine pullPinCoroutine;

	public Animator itemAnimator;

	public AudioSource itemAudio;

	public AudioClip pullPinSFX;

	public AudioClip explodeSFX;

	public AnimationCurve grenadeFallCurve;

	public AnimationCurve grenadeVerticalFallCurve;

	public AnimationCurve grenadeVerticalFallCurveNoBounce;

	public RaycastHit grenadeHit;

	public Ray grenadeThrowRay;

	private int stunGrenadeMask = 268437761;

	public float explodeTimer;

	public bool hasExploded;

	public GameObject stunGrenadeExplosion;

	private PlayerControllerB playerThrownBy;

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		base.ItemActivate(used, buttonDown);
		if (inPullingPinAnimation)
		{
			return;
		}
		if (!pinPulled)
		{
			if (pullPinCoroutine == null)
			{
				playerHeldBy.activatingItem = true;
				pullPinCoroutine = ((MonoBehaviour)this).StartCoroutine(pullPinAnimation());
			}
		}
		else if (((NetworkBehaviour)this).IsOwner)
		{
			playerHeldBy.DiscardHeldObject(placeObject: true, null, GetGrenadeThrowDestination());
		}
	}

	public override void DiscardItem()
	{
		if ((Object)(object)playerHeldBy != (Object)null && !explodeOnCollision)
		{
			playerHeldBy.activatingItem = false;
		}
		base.DiscardItem();
	}

	public override void EquipItem()
	{
		if (explodeOnCollision)
		{
			playerThrownBy = playerHeldBy;
		}
		gotExplodeOnThrowRPC = false;
		hasCollided = false;
		SetControlTipForGrenade();
		EnableItemMeshes(enable: true);
		isPocketed = false;
		if (chanceToExplode < 100f)
		{
			SetExplodeOnThrowServerRpc();
		}
		if (!hasBeenHeld)
		{
			hasBeenHeld = true;
			if (!isInShipRoom && !StartOfRound.Instance.inShipPhase && StartOfRound.Instance.currentLevel.spawnEnemiesAndScrap)
			{
				RoundManager.Instance.valueOfFoundScrapItems += scrapValue;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetExplodeOnThrowServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2106007416u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2106007416u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				bool explodeOnThrowClientRpc = (float)new Random(StartOfRound.Instance.randomMapSeed + 10 + (int)((Component)this).transform.position.x + (int)((Component)this).transform.position.z).Next(0, 100) <= chanceToExplode;
				SetExplodeOnThrowClientRpc(explodeOnThrowClientRpc);
			}
		}
	}

	[ClientRpc]
	public void SetExplodeOnThrowClientRpc(bool explode)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1175066890u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref explode, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1175066890u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				gotExplodeOnThrowRPC = true;
				explodeOnThrow = explode;
			}
		}
	}

	private void SetControlTipForGrenade()
	{
		string[] allLines = ((!pinPulled) ? new string[1] { "Pull pin: [RMB]" } : new string[1] { throwString });
		if (((NetworkBehaviour)this).IsOwner)
		{
			HUDManager.Instance.ChangeControlTipMultiple(allLines, holdingItem: true, itemProperties);
		}
	}

	public override void FallWithCurve()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = startFallingPosition - targetFloorPosition;
		float magnitude = ((Vector3)(ref val)).magnitude;
		((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, Quaternion.Euler(itemProperties.restingRotation.x, ((Component)this).transform.eulerAngles.y, itemProperties.restingRotation.z), 14f * Time.deltaTime / magnitude);
		((Component)this).transform.localPosition = Vector3.Lerp(startFallingPosition, targetFloorPosition, grenadeFallCurve.Evaluate(fallTime));
		if (magnitude > 5f)
		{
			((Component)this).transform.localPosition = Vector3.Lerp(new Vector3(((Component)this).transform.localPosition.x, startFallingPosition.y, ((Component)this).transform.localPosition.z), new Vector3(((Component)this).transform.localPosition.x, targetFloorPosition.y, ((Component)this).transform.localPosition.z), grenadeVerticalFallCurveNoBounce.Evaluate(fallTime));
		}
		else
		{
			((Component)this).transform.localPosition = Vector3.Lerp(new Vector3(((Component)this).transform.localPosition.x, startFallingPosition.y, ((Component)this).transform.localPosition.z), new Vector3(((Component)this).transform.localPosition.x, targetFloorPosition.y, ((Component)this).transform.localPosition.z), grenadeVerticalFallCurve.Evaluate(fallTime));
		}
		fallTime += Mathf.Abs(Time.deltaTime * 12f / magnitude);
	}

	private IEnumerator pullPinAnimation()
	{
		inPullingPinAnimation = true;
		playerHeldBy.activatingItem = true;
		playerHeldBy.doingUpperBodyEmote = 1.16f;
		playerHeldBy.playerBodyAnimator.SetTrigger(playerAnimation);
		itemAnimator.SetTrigger("pullPin");
		itemAudio.PlayOneShot(pullPinSFX);
		WalkieTalkie.TransmitOneShotAudio(itemAudio, pullPinSFX, 0.8f);
		yield return (object)new WaitForSeconds(1f);
		if ((Object)(object)playerHeldBy != (Object)null)
		{
			if (!DestroyGrenade)
			{
				playerHeldBy.activatingItem = false;
			}
			playerThrownBy = playerHeldBy;
		}
		inPullingPinAnimation = false;
		pinPulled = true;
		itemUsedUp = true;
		if (((NetworkBehaviour)this).IsOwner && (Object)(object)playerHeldBy != (Object)null)
		{
			SetControlTipForGrenade();
		}
	}

	public override void Update()
	{
		base.Update();
		if (hasCollided)
		{
			if (gotExplodeOnThrowRPC)
			{
				gotExplodeOnThrowRPC = false;
				ExplodeStunGrenade(DestroyGrenade);
			}
		}
		else if (!dontRequirePullingPin && pinPulled && !hasExploded)
		{
			explodeTimer += Time.deltaTime;
			if (explodeTimer > TimeToExplode)
			{
				ExplodeStunGrenade(DestroyGrenade);
			}
		}
	}

	public override void Start()
	{
		base.Start();
		if (dontRequirePullingPin)
		{
			pinPulled = true;
		}
	}

	public override void OnHitGround()
	{
		base.OnHitGround();
		if (!((Object)(object)playerThrownBy == (Object)null) && explodeOnCollision && pinPulled)
		{
			hasCollided = true;
		}
	}

	private void ExplodeStunGrenade(bool destroy = false)
	{
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		if (hasExploded)
		{
			return;
		}
		if ((chanceToExplode < 100f && !explodeOnThrow) || (explodeOnCollision && !StartOfRound.Instance.currentLevel.spawnEnemiesAndScrap && (Object)(object)parentObject == (Object)(object)Object.FindObjectOfType<DepositItemsDesk>().deskObjectsContainer))
		{
			if ((Object)(object)playerThrownBy != (Object)null)
			{
				playerThrownBy.activatingItem = false;
			}
			return;
		}
		hasExploded = true;
		Transform val = ((!isInElevator) ? RoundManager.Instance.mapPropsContainer.transform : StartOfRound.Instance.elevatorTransform);
		if (spawnDamagingShockwave)
		{
			Landmine.SpawnExplosion(((Component)this).transform.position + Vector3.up * 0.2f, spawnExplosionEffect: false, 0.5f, 3f, 40, 45f);
		}
		else
		{
			StunExplosion(((Component)this).transform.position, affectAudio: true, 1f, 7.5f, 1f, isHeld, playerHeldBy, playerThrownBy);
		}
		Object.Instantiate<GameObject>(stunGrenadeExplosion, ((Component)this).transform.position, Quaternion.identity, val);
		itemAudio.PlayOneShot(explodeSFX);
		WalkieTalkie.TransmitOneShotAudio(itemAudio, explodeSFX);
		if (DestroyGrenade)
		{
			DestroyObjectInHand(playerThrownBy);
		}
	}

	public static void StunExplosion(Vector3 explosionPosition, bool affectAudio, float flashSeverityMultiplier, float enemyStunTime, float flashSeverityDistanceRolloff = 1f, bool isHeldItem = false, PlayerControllerB playerHeldBy = null, PlayerControllerB playerThrownBy = null, float addToFlashSeverity = 0f)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB playerControllerB = GameNetworkManager.Instance.localPlayerController;
		if (GameNetworkManager.Instance.localPlayerController.isPlayerDead && (Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript != (Object)null)
		{
			playerControllerB = GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript;
		}
		float num = Vector3.Distance(((Component)playerControllerB).transform.position, explosionPosition);
		float num2 = 7f / (num * flashSeverityDistanceRolloff);
		if (Physics.Linecast(explosionPosition + Vector3.up * 0.5f, ((Component)playerControllerB.gameplayCamera).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			num2 /= 13f;
		}
		else if (num < 2f)
		{
			num2 = 1f;
		}
		else if (!playerControllerB.HasLineOfSightToPosition(explosionPosition, 60f, 15, 2f))
		{
			num2 = Mathf.Clamp(num2 / 3f, 0f, 1f);
		}
		if (isHeldItem && (Object)(object)playerHeldBy == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			num2 = 1f;
			GameNetworkManager.Instance.localPlayerController.DamagePlayer(20, hasDamageSFX: false, callRPC: true, CauseOfDeath.Blast);
		}
		num2 = Mathf.Clamp(num2 * flashSeverityMultiplier, 0f, 1f);
		if (num2 > 0.6f)
		{
			num2 += addToFlashSeverity;
		}
		HUDManager.Instance.flashFilter = num2;
		if (affectAudio)
		{
			SoundManager.Instance.earsRingingTimer = num2;
		}
		if (enemyStunTime <= 0f)
		{
			return;
		}
		Collider[] array = Physics.OverlapSphere(explosionPosition, 12f, 524288);
		if (array.Length == 0)
		{
			return;
		}
		for (int i = 0; i < array.Length; i++)
		{
			EnemyAICollisionDetect component = ((Component)array[i]).GetComponent<EnemyAICollisionDetect>();
			if ((Object)(object)component == (Object)null)
			{
				continue;
			}
			Vector3 val = ((Component)component.mainScript).transform.position + Vector3.up * 0.5f;
			if (component.mainScript.CheckLineOfSightForPosition(explosionPosition + Vector3.up * 0.5f, 120f, 23, 7f) || (!Physics.Linecast(explosionPosition + Vector3.up * 0.5f, ((Component)component.mainScript).transform.position + Vector3.up * 0.5f, 256) && Vector3.Distance(explosionPosition, val) < 11f))
			{
				if ((Object)(object)playerThrownBy != (Object)null)
				{
					component.mainScript.SetEnemyStunned(setToStunned: true, enemyStunTime, playerThrownBy);
				}
				else
				{
					component.mainScript.SetEnemyStunned(setToStunned: true, enemyStunTime);
				}
			}
		}
	}

	public Vector3 GetGrenadeThrowDestination()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = ((Component)this).transform.position;
		Debug.DrawRay(((Component)playerHeldBy.gameplayCamera).transform.position, ((Component)playerHeldBy.gameplayCamera).transform.forward, Color.yellow, 15f);
		grenadeThrowRay = new Ray(((Component)playerHeldBy.gameplayCamera).transform.position, ((Component)playerHeldBy.gameplayCamera).transform.forward);
		position = ((!Physics.Raycast(grenadeThrowRay, ref grenadeHit, 12f, stunGrenadeMask, (QueryTriggerInteraction)1)) ? ((Ray)(ref grenadeThrowRay)).GetPoint(10f) : ((Ray)(ref grenadeThrowRay)).GetPoint(((RaycastHit)(ref grenadeHit)).distance - 0.05f));
		Debug.DrawRay(position, Vector3.down, Color.blue, 15f);
		grenadeThrowRay = new Ray(position, Vector3.down);
		if (Physics.Raycast(grenadeThrowRay, ref grenadeHit, 30f, stunGrenadeMask, (QueryTriggerInteraction)1))
		{
			return ((RaycastHit)(ref grenadeHit)).point + Vector3.up * 0.05f;
		}
		return ((Ray)(ref grenadeThrowRay)).GetPoint(30f);
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_StunGrenadeItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2106007416u, new RpcReceiveHandler(__rpc_handler_2106007416));
		NetworkManager.__rpc_func_table.Add(1175066890u, new RpcReceiveHandler(__rpc_handler_1175066890));
	}

	private static void __rpc_handler_2106007416(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((StunGrenadeItem)(object)target).SetExplodeOnThrowServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1175066890(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool explodeOnThrowClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref explodeOnThrowClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((StunGrenadeItem)(object)target).SetExplodeOnThrowClientRpc(explodeOnThrowClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "StunGrenadeItem";
	}
}
