using UnityEngine;

public class HoarderBugItem
{
	public GrabbableObject itemGrabbableObject;

	public Vector3 itemNestPosition;

	public HoarderBugItemStatus status;

	public HoarderBugItem(GrabbableObject newObject, HoarderBugItemStatus newStatus, Vector3 bugNestPosition)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		itemGrabbableObject = newObject;
		status = newStatus;
		itemNestPosition = bugNestPosition;
	}
}
