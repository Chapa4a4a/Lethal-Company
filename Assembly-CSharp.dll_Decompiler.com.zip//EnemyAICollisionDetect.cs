using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class EnemyAICollisionDetect : MonoBehaviour, IHittable, INoiseListener, IShockableWithGun
{
	public EnemyAI mainScript;

	public bool canCollideWithEnemies;

	public bool onlyCollideWhenGrounded;

	private void OnTriggerStay(Collider other)
	{
		if (((Component)other).CompareTag("Player"))
		{
			if (onlyCollideWhenGrounded)
			{
				CharacterController component = ((Component)other).gameObject.GetComponent<CharacterController>();
				if (!((Object)(object)component != (Object)null) || !component.isGrounded)
				{
					return;
				}
				mainScript.OnCollideWithPlayer(other);
			}
			mainScript.OnCollideWithPlayer(other);
		}
		else if (!onlyCollideWhenGrounded && canCollideWithEnemies && ((Component)other).CompareTag("Enemy"))
		{
			EnemyAICollisionDetect component2 = ((Component)other).gameObject.GetComponent<EnemyAICollisionDetect>();
			if ((Object)(object)component2 != (Object)null && (Object)(object)component2.mainScript != (Object)(object)mainScript)
			{
				mainScript.OnCollideWithEnemy(other, component2.mainScript);
			}
		}
	}

	bool IHittable.Hit(int force, Vector3 hitDirection, PlayerControllerB playerWhoHit, bool playHitSFX, int hitID)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (onlyCollideWhenGrounded)
		{
			Debug.Log((object)"Enemy collision detect returned false");
			return false;
		}
		mainScript.HitEnemyOnLocalClient(force, hitDirection, playerWhoHit, playHitSFX, hitID);
		return true;
	}

	void INoiseListener.DetectNoise(Vector3 noisePosition, float noiseLoudness, int timesNoisePlayedInOneSpot, int noiseID)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (!onlyCollideWhenGrounded)
		{
			mainScript.DetectNoise(noisePosition, noiseLoudness, timesNoisePlayedInOneSpot, noiseID);
		}
	}

	bool IShockableWithGun.CanBeShocked()
	{
		if (!onlyCollideWhenGrounded && mainScript.postStunInvincibilityTimer <= 0f && mainScript.enemyType.canBeStunned)
		{
			return !mainScript.isEnemyDead;
		}
		return false;
	}

	Vector3 IShockableWithGun.GetShockablePosition()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)mainScript.eye != (Object)null)
		{
			return mainScript.eye.position;
		}
		return ((Component)this).transform.position + Vector3.up * 0.5f;
	}

	float IShockableWithGun.GetDifficultyMultiplier()
	{
		return mainScript.enemyType.stunGameDifficultyMultiplier;
	}

	void IShockableWithGun.ShockWithGun(PlayerControllerB shockedByPlayer)
	{
		mainScript.SetEnemyStunned(setToStunned: true, 0.25f, shockedByPlayer);
		mainScript.stunnedIndefinitely++;
	}

	Transform IShockableWithGun.GetShockableTransform()
	{
		return ((Component)this).transform;
	}

	NetworkObject IShockableWithGun.GetNetworkObject()
	{
		return ((NetworkBehaviour)mainScript).NetworkObject;
	}

	void IShockableWithGun.StopShockingWithGun()
	{
		mainScript.stunnedIndefinitely = Mathf.Clamp(mainScript.stunnedIndefinitely - 1, 0, 100);
	}
}
