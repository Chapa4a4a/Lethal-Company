using Unity.Netcode;
using UnityEngine;

public class EnemyVent : NetworkBehaviour
{
	public float spawnTime;

	public bool occupied;

	[Space(5f)]
	public EnemyType enemyType;

	public int enemyTypeIndex;

	[Space(10f)]
	public AudioSource ventAudio;

	public AudioLowPassFilter lowPassFilter;

	public AudioClip ventCrawlSFX;

	public Transform floorNode;

	private bool isPlayingAudio;

	private RoundManager roundManager;

	public Animator ventAnimator;

	public bool ventIsOpen;

	public bool caveVent;

	private void Start()
	{
		roundManager = Object.FindObjectOfType<RoundManager>();
	}

	private void BeginVentSFX()
	{
		if ((Object)(object)enemyType.overrideVentSFX != (Object)null)
		{
			ventAudio.clip = enemyType.overrideVentSFX;
			ventAudio.Play();
			ventAudio.volume = 0f;
		}
		else if (!caveVent)
		{
			ventAudio.clip = ventCrawlSFX;
			ventAudio.Play();
			ventAudio.volume = 0f;
		}
	}

	[ClientRpc]
	public void OpenVentClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2182253155u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2182253155u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (!ventIsOpen)
			{
				ventIsOpen = true;
				ventAnimator.SetTrigger("openVent");
				lowPassFilter.lowpassResonanceQ = 0f;
			}
			occupied = false;
		}
	}

	[ClientRpc]
	public void SyncVentSpawnTimeClientRpc(int time, int enemyIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3841281693u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, time);
				BytePacker.WriteValueBitPacked(val2, enemyIndex);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3841281693u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				enemyTypeIndex = enemyIndex;
				enemyType = roundManager.currentLevel.Enemies[enemyIndex].enemyType;
				spawnTime = time;
				occupied = true;
			}
		}
	}

	private void Update()
	{
		if (occupied)
		{
			if (!isPlayingAudio)
			{
				if (spawnTime - roundManager.timeScript.currentDayTime < enemyType.timeToPlayAudio)
				{
					isPlayingAudio = true;
					BeginVentSFX();
				}
			}
			else
			{
				ventAudio.volume = Mathf.Abs((spawnTime - roundManager.timeScript.currentDayTime) / enemyType.timeToPlayAudio - 1f);
				lowPassFilter.lowpassResonanceQ = Mathf.Abs(ventAudio.volume * 2f - 2f);
			}
		}
		else if (isPlayingAudio)
		{
			isPlayingAudio = false;
			ventAudio.Stop();
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_EnemyVent()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2182253155u, new RpcReceiveHandler(__rpc_handler_2182253155));
		NetworkManager.__rpc_func_table.Add(3841281693u, new RpcReceiveHandler(__rpc_handler_3841281693));
	}

	private static void __rpc_handler_2182253155(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EnemyVent)(object)target).OpenVentClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3841281693(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int time = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref time);
			int enemyIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref enemyIndex);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((EnemyVent)(object)target).SyncVentSpawnTimeClientRpc(time, enemyIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "EnemyVent";
	}
}
