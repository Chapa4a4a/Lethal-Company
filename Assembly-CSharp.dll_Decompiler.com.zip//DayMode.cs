public enum DayMode
{
	None = -1,
	Dawn,
	Noon,
	Sundown,
	Midnight
}
