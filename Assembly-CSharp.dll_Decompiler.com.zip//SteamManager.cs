using Steamworks;
using UnityEngine;

public class SteamManager : MonoBehaviour
{
	public static SteamManager Instance { get; private set; }

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void OnDisable()
	{
		SteamClient.Shutdown();
	}

	private void Update()
	{
		SteamClient.RunCallbacks();
	}
}
