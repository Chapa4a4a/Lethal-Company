public enum CarGearShift
{
	Park = 3,
	Reverse = 2,
	Drive = 1
}
