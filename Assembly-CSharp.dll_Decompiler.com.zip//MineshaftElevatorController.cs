using Unity.Netcode;
using UnityEngine;

public class MineshaftElevatorController : NetworkBehaviour
{
	public Animator elevatorAnimator;

	public Transform elevatorPoint;

	public bool elevatorFinishedMoving;

	public float elevatorFinishTimer;

	public bool elevatorIsAtBottom;

	public bool elevatorCalled;

	public bool elevatorMovingDown;

	private bool movingDownLastFrame = true;

	public bool calledDown;

	public float callCooldown;

	public AudioSource elevatorAudio;

	public AudioClip elevatorStartUpSFX;

	public AudioClip elevatorStartDownSFX;

	public AudioClip elevatorTravelSFX;

	public AudioClip elevatorFinishUpSFX;

	public AudioClip elevatorFinishDownSFX;

	public GameObject elevatorCalledBottomButton;

	public GameObject elevatorCalledTopButton;

	public Transform elevatorTopPoint;

	public Transform elevatorBottomPoint;

	public Transform elevatorInsidePoint;

	public Vector3 previousElevatorPosition;

	public bool elevatorDoorOpen;

	public AudioSource elevatorJingleMusic;

	private bool playMusic;

	private bool startedMusic;

	private float stopPlayingMusicTimer;

	public AudioClip[] elevatorHalloweenClips;

	public AudioClip[] elevatorHalloweenClipsLoop;

	[ServerRpc]
	public void SetElevatorMusicServerRpc(bool setOn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(248132445u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setOn, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 248132445u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetElevatorMusicClientRpc(setOn);
		}
	}

	[ClientRpc]
	public void SetElevatorMusicClientRpc(bool setOn)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2139513831u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setOn, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2139513831u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				playMusic = setOn;
			}
		}
	}

	private void OnEnable()
	{
		RoundManager.Instance.currentMineshaftElevator = this;
	}

	private void OnDisable()
	{
		RoundManager.Instance.currentMineshaftElevator = null;
	}

	public void LateUpdate()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		previousElevatorPosition = elevatorInsidePoint.position;
	}

	public void Update()
	{
		if (!playMusic)
		{
			if (stopPlayingMusicTimer <= 0f)
			{
				if (elevatorJingleMusic.isPlaying)
				{
					if (elevatorJingleMusic.pitch < 0.5f)
					{
						AudioSource obj = elevatorJingleMusic;
						obj.volume -= Time.deltaTime * 3f;
						if (elevatorJingleMusic.volume <= 0.01f)
						{
							elevatorJingleMusic.Stop();
						}
					}
					else
					{
						AudioSource obj2 = elevatorJingleMusic;
						obj2.pitch -= Time.deltaTime;
						elevatorJingleMusic.volume = Mathf.Max(elevatorJingleMusic.volume - Time.deltaTime * 2f, 0.4f);
					}
				}
			}
			else
			{
				stopPlayingMusicTimer -= Time.deltaTime;
			}
		}
		else
		{
			stopPlayingMusicTimer = 1.5f;
			if (!elevatorJingleMusic.isPlaying)
			{
				if (elevatorMovingDown)
				{
					elevatorJingleMusic.Play();
					elevatorJingleMusic.volume = 1f;
				}
				else
				{
					elevatorJingleMusic.Play();
					elevatorJingleMusic.volume = 1f;
				}
			}
			AudioSource obj3 = elevatorJingleMusic;
			AudioSource obj4 = elevatorJingleMusic;
			float num2 = (obj4.pitch += Time.deltaTime * 2f);
			obj3.pitch = Mathf.Clamp(num2, 0.3f, 1f);
		}
		elevatorAnimator.SetBool("ElevatorGoingUp", !elevatorMovingDown);
		elevatorCalledTopButton.SetActive(!elevatorMovingDown || elevatorCalled);
		elevatorCalledBottomButton.SetActive(elevatorMovingDown || elevatorCalled);
		if (elevatorMovingDown != movingDownLastFrame)
		{
			movingDownLastFrame = elevatorMovingDown;
			if (elevatorMovingDown)
			{
				elevatorAudio.PlayOneShot(elevatorStartDownSFX);
			}
			else
			{
				elevatorAudio.PlayOneShot(elevatorStartUpSFX);
			}
			if (((NetworkBehaviour)this).IsServer)
			{
				SetElevatorMovingServerRpc(elevatorMovingDown);
			}
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		if (elevatorFinishedMoving)
		{
			if (((NetworkBehaviour)this).IsServer && startedMusic)
			{
				playMusic = false;
				startedMusic = false;
				SetElevatorMusicServerRpc(setOn: false);
			}
		}
		else if (((NetworkBehaviour)this).IsServer && !startedMusic)
		{
			startedMusic = true;
			playMusic = true;
			SetElevatorMusicServerRpc(setOn: true);
		}
		if (elevatorFinishedMoving)
		{
			if (elevatorCalled)
			{
				if (callCooldown <= 0f)
				{
					SwitchElevatorDirection();
					SetElevatorCalledClientRpc(setCalled: false, elevatorMovingDown);
				}
				else
				{
					callCooldown -= Time.deltaTime;
				}
			}
		}
		else if (elevatorFinishTimer <= 0f)
		{
			elevatorFinishedMoving = true;
			Debug.Log((object)"Elevator finished moving!");
			PlayFinishAudio(!elevatorMovingDown);
			ElevatorFinishServerRpc(!elevatorMovingDown);
		}
		else
		{
			elevatorFinishTimer -= Time.deltaTime;
		}
	}

	private void SwitchElevatorDirection()
	{
		elevatorMovingDown = !elevatorMovingDown;
		elevatorFinishedMoving = false;
		elevatorFinishTimer = 14f;
		elevatorCalled = false;
		SetElevatorFinishedMovingClientRpc(finished: false);
	}

	[ClientRpc]
	public void SetElevatorFinishedMovingClientRpc(bool finished)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3289543899u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref finished, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3289543899u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				elevatorFinishedMoving = finished;
			}
		}
	}

	public void AnimationEvent_ElevatorFinishTop()
	{
		if (!elevatorMovingDown && !elevatorFinishedMoving)
		{
			elevatorFinishedMoving = true;
			if (((NetworkBehaviour)this).IsServer)
			{
				PlayFinishAudio(!elevatorMovingDown);
				ElevatorFinishServerRpc(!elevatorMovingDown);
			}
		}
	}

	public void AnimationEvent_ElevatorStartFromBottom()
	{
		ShakePlayerCamera(shakeHard: false);
	}

	public void AnimationEvent_ElevatorHitBottom()
	{
		ShakePlayerCamera(shakeHard: true);
	}

	public void AnimationEvent_ElevatorTravel()
	{
		elevatorAudio.PlayOneShot(elevatorTravelSFX);
	}

	public void AnimationEvent_ElevatorFinishBottom()
	{
		if (elevatorMovingDown && !elevatorFinishedMoving)
		{
			elevatorFinishedMoving = true;
			if (((NetworkBehaviour)this).IsServer)
			{
				Debug.Log((object)"Elevator finished moving B!");
				PlayFinishAudio(!elevatorMovingDown);
				ElevatorFinishServerRpc(!elevatorMovingDown);
			}
		}
	}

	private void ShakePlayerCamera(bool shakeHard)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(((Component)StartOfRound.Instance.audioListener).transform.position, elevatorPoint.position) < 4f)
		{
			if (shakeHard)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
			else
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
			}
		}
	}

	[ServerRpc]
	public void ElevatorFinishServerRpc(bool atTop)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1003104612u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref atTop, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1003104612u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			ElevatorFinishClientRpc(atTop);
		}
	}

	[ClientRpc]
	public void ElevatorFinishClientRpc(bool atTop)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3032205731u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref atTop, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3032205731u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				PlayFinishAudio(atTop);
				elevatorFinishedMoving = true;
			}
		}
	}

	private void PlayFinishAudio(bool atTop)
	{
		if (atTop)
		{
			elevatorAudio.PlayOneShot(elevatorFinishUpSFX);
		}
		else
		{
			elevatorAudio.PlayOneShot(elevatorFinishDownSFX);
		}
	}

	[ServerRpc]
	public void SetElevatorMovingServerRpc(bool movingDown)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2622819109u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref movingDown, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2622819109u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SetElevatorMovingClientRpc(movingDown);
		}
	}

	[ClientRpc]
	public void SetElevatorMovingClientRpc(bool movingDown)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(316684258u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref movingDown, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 316684258u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				elevatorMovingDown = movingDown;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void CallElevatorServerRpc(bool callDown)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(816247597u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref callDown, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 816247597u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				CallElevatorOnServer(callDown);
			}
		}
	}

	public void CallElevatorOnServer(bool callDown)
	{
		if (elevatorMovingDown != callDown)
		{
			elevatorCalled = true;
			callCooldown = 4f;
			SetElevatorCalledClientRpc(elevatorCalled, elevatorMovingDown);
		}
	}

	public void SetElevatorDoorOpen()
	{
		elevatorDoorOpen = true;
	}

	public void SetElevatorDoorClosed()
	{
		elevatorDoorOpen = false;
	}

	[ClientRpc]
	public void SetElevatorCalledClientRpc(bool setCalled, bool elevatorDown)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2906284547u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setCalled, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref elevatorDown, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2906284547u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				elevatorCalled = setCalled;
				elevatorMovingDown = elevatorDown;
			}
		}
	}

	public void CallElevator(bool callDown)
	{
		Debug.Log((object)$"Call elevator 0; call down: {callDown}; elevator moving down: {elevatorMovingDown}");
		CallElevatorServerRpc(callDown);
	}

	[ServerRpc(RequireOwnership = false)]
	public void PressElevatorButtonServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3485555877u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3485555877u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PressElevatorButtonOnServer();
			}
		}
	}

	public void PressElevatorButtonOnServer(bool requireFinishedMoving = false)
	{
		if (elevatorFinishedMoving || (elevatorFinishTimer < 0.16f && !requireFinishedMoving))
		{
			SwitchElevatorDirection();
		}
	}

	public void PressElevatorButton()
	{
		PressElevatorButtonServerRpc();
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_MineshaftElevatorController()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(248132445u, new RpcReceiveHandler(__rpc_handler_248132445));
		NetworkManager.__rpc_func_table.Add(2139513831u, new RpcReceiveHandler(__rpc_handler_2139513831));
		NetworkManager.__rpc_func_table.Add(3289543899u, new RpcReceiveHandler(__rpc_handler_3289543899));
		NetworkManager.__rpc_func_table.Add(1003104612u, new RpcReceiveHandler(__rpc_handler_1003104612));
		NetworkManager.__rpc_func_table.Add(3032205731u, new RpcReceiveHandler(__rpc_handler_3032205731));
		NetworkManager.__rpc_func_table.Add(2622819109u, new RpcReceiveHandler(__rpc_handler_2622819109));
		NetworkManager.__rpc_func_table.Add(316684258u, new RpcReceiveHandler(__rpc_handler_316684258));
		NetworkManager.__rpc_func_table.Add(816247597u, new RpcReceiveHandler(__rpc_handler_816247597));
		NetworkManager.__rpc_func_table.Add(2906284547u, new RpcReceiveHandler(__rpc_handler_2906284547));
		NetworkManager.__rpc_func_table.Add(3485555877u, new RpcReceiveHandler(__rpc_handler_3485555877));
	}

	private static void __rpc_handler_248132445(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool elevatorMusicServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref elevatorMusicServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MineshaftElevatorController)(object)target).SetElevatorMusicServerRpc(elevatorMusicServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2139513831(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool elevatorMusicClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref elevatorMusicClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MineshaftElevatorController)(object)target).SetElevatorMusicClientRpc(elevatorMusicClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3289543899(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool elevatorFinishedMovingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref elevatorFinishedMovingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MineshaftElevatorController)(object)target).SetElevatorFinishedMovingClientRpc(elevatorFinishedMovingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1003104612(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool atTop = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref atTop, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MineshaftElevatorController)(object)target).ElevatorFinishServerRpc(atTop);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3032205731(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool atTop = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref atTop, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MineshaftElevatorController)(object)target).ElevatorFinishClientRpc(atTop);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2622819109(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			bool elevatorMovingServerRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref elevatorMovingServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MineshaftElevatorController)(object)target).SetElevatorMovingServerRpc(elevatorMovingServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_316684258(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool elevatorMovingClientRpc = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref elevatorMovingClientRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MineshaftElevatorController)(object)target).SetElevatorMovingClientRpc(elevatorMovingClientRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_816247597(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool callDown = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref callDown, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MineshaftElevatorController)(object)target).CallElevatorServerRpc(callDown);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2906284547(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool setCalled = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setCalled, default(ForPrimitives));
			bool elevatorDown = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref elevatorDown, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((MineshaftElevatorController)(object)target).SetElevatorCalledClientRpc(setCalled, elevatorDown);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3485555877(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((MineshaftElevatorController)(object)target).PressElevatorButtonServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "MineshaftElevatorController";
	}
}
