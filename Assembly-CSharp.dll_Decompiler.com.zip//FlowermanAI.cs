using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;

public class FlowermanAI : EnemyAI
{
	private bool evadeModeStareDown;

	private bool stopTurningTowardsPlayers;

	public float evadeStealthTimer;

	private int stareDownChanceIncrease;

	public PlayerControllerB lookAtPlayer;

	private Transform localPlayerCamera;

	private RaycastHit rayHit;

	private Ray playerRay;

	public Transform turnCompass;

	private int roomAndEnemiesMask = 8915200;

	private Vector3 agentLocalVelocity;

	public Collider thisEnemyCollider;

	private Vector3 previousPosition;

	private float velX;

	private float velZ;

	[Header("Kill animation")]
	public bool inKillAnimation;

	private Coroutine killAnimationCoroutine;

	public bool carryingPlayerBody;

	public DeadBodyInfo bodyBeingCarried;

	public Transform rightHandGrip;

	public Transform animationContainer;

	private bool wasInEvadeMode;

	public List<Transform> ignoredNodes = new List<Transform>();

	private Vector3 mainEntrancePosition;

	[Header("Anger phase")]
	public float angerMeter;

	public float angerCheckInterval;

	public bool isInAngerMode;

	public AudioSource creatureAngerVoice;

	public AudioSource crackNeckAudio;

	public AudioClip crackNeckSFX;

	public int timesThreatened;

	private Vector3 waitAroundEntrancePosition;

	private int timesFoundSneaking;

	private bool stunnedByPlayerLastFrame;

	private bool startingKillAnimationLocalClient;

	private float getPathToFavoriteNodeInterval;

	private bool gettingFarthestNodeFromPlayerAsync;

	private Transform farthestNodeFromTargetPlayer;

	[Space(5f)]
	public int maxAsync = 50;

	public override void Start()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		movingTowardsTargetPlayer = true;
		localPlayerCamera = ((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform;
		mainEntrancePosition = RoundManager.FindMainEntrancePosition();
	}

	public override void DoAIInterval()
	{
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		if (StartOfRound.Instance.livingPlayers == 0)
		{
			base.DoAIInterval();
			return;
		}
		if (TargetClosestPlayer())
		{
			if (currentBehaviourStateIndex == 2)
			{
				SetMovingTowardsTargetPlayer(targetPlayer);
				if (!inKillAnimation && (Object)(object)targetPlayer != (Object)(object)GameNetworkManager.Instance.localPlayerController)
				{
					ChangeOwnershipOfEnemy(targetPlayer.actualClientId);
				}
				base.DoAIInterval();
				return;
			}
			if (currentBehaviourStateIndex == 1)
			{
				if ((Object)(object)favoriteSpot != (Object)null && carryingPlayerBody)
				{
					if (mostOptimalDistance < 5f || PathIsIntersectedByLineOfSight(favoriteSpot.position))
					{
						AvoidClosestPlayer();
					}
					else
					{
						targetNode = favoriteSpot;
						if (Time.realtimeSinceStartup - getPathToFavoriteNodeInterval > 1f)
						{
							SetDestinationToPosition(favoriteSpot.position, checkForPath: true);
							getPathToFavoriteNodeInterval = Time.realtimeSinceStartup;
						}
					}
				}
				else
				{
					AvoidClosestPlayer();
				}
			}
			else
			{
				ChooseClosestNodeToPlayer();
			}
		}
		else
		{
			if (currentBehaviourStateIndex == 2)
			{
				SetDestinationToPosition(waitAroundEntrancePosition);
				base.DoAIInterval();
				return;
			}
			Transform val = ChooseFarthestNodeFromPosition(mainEntrancePosition);
			if ((Object)(object)favoriteSpot == (Object)null)
			{
				favoriteSpot = val;
			}
			targetNode = val;
			SetDestinationToPosition(val.position, checkForPath: true);
		}
		base.DoAIInterval();
	}

	public void AvoidClosestPlayer()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)farthestNodeFromTargetPlayer == (Object)null)
		{
			gettingFarthestNodeFromPlayerAsync = true;
			return;
		}
		Transform val = farthestNodeFromTargetPlayer;
		farthestNodeFromTargetPlayer = null;
		if ((Object)(object)val != (Object)null && mostOptimalDistance > 5f && Physics.Linecast(((Component)val).transform.position, ((Component)targetPlayer.gameplayCamera).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			targetNode = val;
			SetDestinationToPosition(targetNode.position);
			return;
		}
		if (carryingPlayerBody)
		{
			DropPlayerBody();
			DropPlayerBodyServerRpc();
		}
		AddToAngerMeter(AIIntervalTime);
		agent.speed = 0f;
	}

	public void AddToAngerMeter(float amountToAdd)
	{
		if (stunNormalizedTimer > 0f)
		{
			if ((Object)(object)stunnedByPlayer != (Object)null)
			{
				stunnedByPlayerLastFrame = true;
				angerMeter = 12f;
			}
			else
			{
				angerMeter = 2f;
			}
			return;
		}
		angerMeter += amountToAdd;
		if (angerMeter <= 0.4f)
		{
			return;
		}
		angerCheckInterval += amountToAdd;
		if (!(angerCheckInterval > 1f))
		{
			return;
		}
		angerCheckInterval = 0f;
		float num = Mathf.Clamp(0.09f * angerMeter, 0f, 0.99f);
		if (Random.Range(0f, 1f) < num)
		{
			if (angerMeter < 2.5f)
			{
				timesThreatened++;
			}
			angerMeter += (float)timesThreatened / 1.75f;
			SwitchToBehaviourStateOnLocalClient(2);
			EnterAngerModeServerRpc(angerMeter);
		}
	}

	[ServerRpc]
	public void EnterAngerModeServerRpc(float angerTime)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(80027368u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref angerTime, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 80027368u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			EnterAngerModeClientRpc(angerTime);
		}
	}

	[ClientRpc]
	public void EnterAngerModeClientRpc(float angerTime)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2307050878u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref angerTime, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2307050878u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				angerMeter = angerTime;
				agent.speed = 9f;
				SwitchToBehaviourStateOnLocalClient(2);
				waitAroundEntrancePosition = RoundManager.Instance.GetRandomNavMeshPositionInRadius(mainEntrancePosition, 6f);
			}
		}
	}

	public void ChooseClosestNodeToPlayer()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)targetNode == (Object)null)
		{
			targetNode = allAINodes[0].transform;
		}
		Transform val = ChooseClosestNodeToPosition(((Component)targetPlayer).transform.position, avoidLineOfSight: true);
		if ((Object)(object)val != (Object)null)
		{
			targetNode = val;
		}
		float num = Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)this).transform.position);
		if (num - mostOptimalDistance < 0.1f && (!PathIsIntersectedByLineOfSight(((Component)targetPlayer).transform.position, calculatePathDistance: true) || num < 3f))
		{
			if (pathDistance > 10f && !ignoredNodes.Contains(targetNode) && ignoredNodes.Count < 4)
			{
				ignoredNodes.Add(targetNode);
			}
			movingTowardsTargetPlayer = true;
		}
		else
		{
			SetDestinationToPosition(targetNode.position);
		}
	}

	public override void Update()
	{
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0660: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0594: Unknown result type (might be due to invalid IL or missing references)
		//IL_059a: Unknown result type (might be due to invalid IL or missing references)
		//IL_059f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0554: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_0872: Unknown result type (might be due to invalid IL or missing references)
		//IL_0811: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (isEnemyDead || inKillAnimation || (Object)(object)GameNetworkManager.Instance == (Object)null)
		{
			return;
		}
		if (((NetworkBehaviour)this).IsOwner && gettingFarthestNodeFromPlayerAsync && (Object)(object)targetPlayer != (Object)null)
		{
			float num = Vector3.Distance(((Component)this).transform.position, ((Component)targetPlayer).transform.position);
			if (num < 16f)
			{
				maxAsync = 100;
			}
			else if (num < 40f)
			{
				maxAsync = 25;
			}
			else
			{
				maxAsync = 4;
			}
			Transform val = ChooseFarthestNodeFromPosition(((Component)targetPlayer).transform.position, avoidLineOfSight: true, 0, doAsync: true, maxAsync, capDistance: true);
			if (!gotFarthestNodeAsync)
			{
				return;
			}
			farthestNodeFromTargetPlayer = val;
			gettingFarthestNodeFromPlayerAsync = false;
		}
		if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position + Vector3.up * 0.5f, 30f))
		{
			if (currentBehaviourStateIndex == 0)
			{
				SwitchToBehaviourState(1);
				if (!thisNetworkObject.IsOwner)
				{
					ChangeOwnershipOfEnemy(GameNetworkManager.Instance.localPlayerController.actualClientId);
				}
				if (Vector3.Distance(((Component)this).transform.position, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position) < 5f)
				{
					GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.6f);
				}
				else
				{
					GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.3f);
				}
				agent.speed = 0f;
				evadeStealthTimer = 0f;
			}
			else if (evadeStealthTimer > 0.5f)
			{
				int playerObj = (int)GameNetworkManager.Instance.localPlayerController.playerClientId;
				LookAtFlowermanTrigger(playerObj);
				ResetFlowermanStealthTimerServerRpc(playerObj);
			}
		}
		Vector3 val2;
		switch (currentBehaviourStateIndex)
		{
		case 1:
		{
			if (isInAngerMode)
			{
				isInAngerMode = false;
				creatureAnimator.SetBool("anger", false);
			}
			if (!wasInEvadeMode)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 7f, 0.8f);
				wasInEvadeMode = true;
				movingTowardsTargetPlayer = false;
				if ((Object)(object)favoriteSpot != (Object)null && !carryingPlayerBody && Vector3.Distance(((Component)this).transform.position, favoriteSpot.position) < 7f)
				{
					favoriteSpot = null;
				}
			}
			if (stunNormalizedTimer > 0f)
			{
				creatureAnimator.SetLayerWeight(2, 1f);
			}
			else
			{
				creatureAnimator.SetLayerWeight(2, 0f);
			}
			evadeStealthTimer += Time.deltaTime;
			if (thisNetworkObject.IsOwner)
			{
				float num2 = ((timesFoundSneaking % 3 != 0) ? 11f : 24f);
				if ((Object)(object)favoriteSpot != (Object)null && carryingPlayerBody)
				{
					num2 = ((!(Vector3.Distance(((Component)this).transform.position, favoriteSpot.position) > 8f)) ? 3f : 24f);
				}
				if (evadeStealthTimer > num2)
				{
					evadeStealthTimer = 0f;
					SwitchToBehaviourState(0);
				}
				if (!carryingPlayerBody && evadeModeStareDown && evadeStealthTimer < 1.25f)
				{
					AddToAngerMeter(Time.deltaTime * 1.5f);
					agent.speed = 0f;
				}
				else
				{
					evadeModeStareDown = false;
					if (stunNormalizedTimer > 0f)
					{
						DropPlayerBody();
						AddToAngerMeter(0f);
						agent.speed = 0f;
					}
					else
					{
						if (stunnedByPlayerLastFrame)
						{
							stunnedByPlayerLastFrame = false;
							AddToAngerMeter(0f);
						}
						if (carryingPlayerBody)
						{
							agent.speed = Mathf.Clamp(agent.speed + Time.deltaTime * 7.25f, 4f, 9f);
						}
						else
						{
							agent.speed = Mathf.Clamp(agent.speed + Time.deltaTime * 4.25f, 0f, 6f);
						}
					}
				}
				if (!carryingPlayerBody && ventAnimationFinished)
				{
					LookAtPlayerOfInterest();
				}
			}
			if (!carryingPlayerBody)
			{
				CalculateAnimationDirection();
				break;
			}
			Animator obj2 = creatureAnimator;
			val2 = Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f);
			obj2.SetFloat("speedMultiplier", ((Vector3)(ref val2)).sqrMagnitude / (Time.deltaTime * 2f));
			previousPosition = ((Component)this).transform.position;
			break;
		}
		case 0:
		{
			if (isInAngerMode)
			{
				isInAngerMode = false;
				creatureAnimator.SetBool("anger", false);
			}
			if (wasInEvadeMode)
			{
				wasInEvadeMode = false;
				evadeStealthTimer = 0f;
				if (carryingPlayerBody)
				{
					DropPlayerBody();
					((Behaviour)agent).enabled = true;
					favoriteSpot = ChooseClosestNodeToPosition(((Component)this).transform.position, avoidLineOfSight: true);
					if (!((NetworkBehaviour)this).IsOwner)
					{
						((Behaviour)agent).enabled = false;
					}
					Debug.Log((object)"Flowerman: Dropped player body");
				}
			}
			Animator obj = creatureAnimator;
			val2 = Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f);
			obj.SetFloat("speedMultiplier", ((Vector3)(ref val2)).sqrMagnitude / (Time.deltaTime / 4f));
			previousPosition = ((Component)this).transform.position;
			agent.speed = 6f;
			break;
		}
		case 2:
		{
			bool flag = false;
			if (!isInAngerMode)
			{
				isInAngerMode = true;
				DropPlayerBody();
				creatureAngerVoice.Play();
				creatureAngerVoice.pitch = Random.Range(0.9f, 1.3f);
				creatureAnimator.SetBool("anger", true);
				creatureAnimator.SetBool("sneak", false);
				if (GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position, 60f, 15, 2.5f))
				{
					flag = true;
					GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.5f);
				}
			}
			if (!flag && GameNetworkManager.Instance.localPlayerController.HasLineOfSightToPosition(((Component)this).transform.position, 60f, 13, 4f))
			{
				GameNetworkManager.Instance.localPlayerController.IncreaseFearLevelOverTime(0.8f);
			}
			CalculateAnimationDirection(3f);
			if (stunNormalizedTimer > 0f)
			{
				creatureAnimator.SetLayerWeight(2, 1f);
				agent.speed = 0f;
				angerMeter = 6f;
			}
			else
			{
				creatureAnimator.SetLayerWeight(2, 0f);
				agent.speed = Mathf.Clamp(agent.speed + Time.deltaTime * 1.2f, 3f, 12f);
			}
			angerMeter -= Time.deltaTime;
			if (((NetworkBehaviour)this).IsOwner && angerMeter <= 0f)
			{
				SwitchToBehaviourState(1);
			}
			break;
		}
		}
		if (isInAngerMode)
		{
			creatureAngerVoice.volume = Mathf.Lerp(creatureAngerVoice.volume, 1f, 10f * Time.deltaTime);
		}
		else
		{
			creatureAngerVoice.volume = Mathf.Lerp(creatureAngerVoice.volume, 0f, 2f * Time.deltaTime);
		}
		Vector3 localEulerAngles = animationContainer.localEulerAngles;
		if (carryingPlayerBody)
		{
			agent.angularSpeed = 50f;
			localEulerAngles.z = Mathf.Lerp(localEulerAngles.z, 179f, 10f * Time.deltaTime);
			creatureAnimator.SetLayerWeight(1, Mathf.Lerp(creatureAnimator.GetLayerWeight(1), 1f, 10f * Time.deltaTime));
		}
		else
		{
			agent.angularSpeed = 220f;
			localEulerAngles.z = Mathf.Lerp(localEulerAngles.z, 0f, 10f * Time.deltaTime);
			creatureAnimator.SetLayerWeight(1, Mathf.Lerp(creatureAnimator.GetLayerWeight(1), 0f, 10f * Time.deltaTime));
		}
		animationContainer.localEulerAngles = localEulerAngles;
	}

	[ServerRpc]
	public void DropPlayerBodyServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2817453984u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2817453984u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			DropPlayerBodyClientRpc();
		}
	}

	[ClientRpc]
	public void DropPlayerBodyClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1942952026u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1942952026u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				DropPlayerBody();
			}
		}
	}

	private void DropPlayerBody()
	{
		if (carryingPlayerBody)
		{
			carryingPlayerBody = false;
			bodyBeingCarried.matchPositionExactly = false;
			bodyBeingCarried.attachedTo = null;
			bodyBeingCarried = null;
			creatureAnimator.SetBool("carryingBody", false);
		}
	}

	private void LookAtPlayerOfInterest()
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		if (isInAngerMode)
		{
			lookAtPlayer = targetPlayer;
		}
		else
		{
			lookAtPlayer = GetClosestPlayer();
		}
		if ((Object)(object)lookAtPlayer != (Object)null)
		{
			turnCompass.LookAt(((Component)lookAtPlayer.gameplayCamera).transform.position);
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, Quaternion.Euler(new Vector3(0f, turnCompass.eulerAngles.y, 0f)), 30f * Time.deltaTime);
		}
	}

	private void CalculateAnimationDirection(float maxSpeed = 1f)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		agentLocalVelocity = animationContainer.InverseTransformDirection(Vector3.ClampMagnitude(((Component)this).transform.position - previousPosition, 1f) / (Time.deltaTime * 2f));
		velX = Mathf.Lerp(velX, agentLocalVelocity.x, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityX", Mathf.Clamp(velX, 0f - maxSpeed, maxSpeed));
		velZ = Mathf.Lerp(velZ, 0f - agentLocalVelocity.y, 10f * Time.deltaTime);
		creatureAnimator.SetFloat("VelocityZ", Mathf.Clamp(velZ, 0f - maxSpeed, maxSpeed));
		previousPosition = ((Component)this).transform.position;
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		base.OnCollideWithPlayer(other);
		PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other, inKillAnimation || startingKillAnimationLocalClient || carryingPlayerBody);
		if ((Object)(object)playerControllerB != (Object)null)
		{
			KillPlayerAnimationServerRpc((int)playerControllerB.playerClientId);
			startingKillAnimationLocalClient = true;
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KillPlayerAnimationServerRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2920701539u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerObjectId);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2920701539u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (!inKillAnimation && !carryingPlayerBody)
			{
				inKillAnimation = true;
				inSpecialAnimation = true;
				isClientCalculatingAI = false;
				inSpecialAnimationWithPlayer = StartOfRound.Instance.allPlayerScripts[playerObjectId];
				inSpecialAnimationWithPlayer.inAnimationWithEnemy = this;
				KillPlayerAnimationClientRpc(playerObjectId);
			}
			else
			{
				CancelKillAnimationClientRpc(playerObjectId);
			}
		}
	}

	[ClientRpc]
	public void CancelKillAnimationClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2215703370u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObjectId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2215703370u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId == playerObjectId)
			{
				startingKillAnimationLocalClient = false;
			}
		}
	}

	[ClientRpc]
	public void KillPlayerAnimationClientRpc(int playerObjectId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(114605325u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerObjectId);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 114605325u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			inSpecialAnimationWithPlayer = StartOfRound.Instance.allPlayerScripts[playerObjectId];
			if ((Object)(object)inSpecialAnimationWithPlayer == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				startingKillAnimationLocalClient = false;
			}
			if ((Object)(object)inSpecialAnimationWithPlayer == (Object)null || inSpecialAnimationWithPlayer.isPlayerDead || !inSpecialAnimationWithPlayer.isInsideFactory)
			{
				FinishKillAnimation(carryingBody: false);
			}
			inSpecialAnimationWithPlayer.inAnimationWithEnemy = this;
			inKillAnimation = true;
			inSpecialAnimation = true;
			creatureAnimator.SetBool("killing", true);
			((Behaviour)agent).enabled = false;
			inSpecialAnimationWithPlayer.inSpecialInteractAnimation = true;
			inSpecialAnimationWithPlayer.snapToServerPosition = true;
			Vector3 val3 = ((!((NetworkBehaviour)inSpecialAnimationWithPlayer).IsOwner) ? ((Component)inSpecialAnimationWithPlayer).transform.parent.TransformPoint(inSpecialAnimationWithPlayer.serverPlayerPosition) : ((Component)inSpecialAnimationWithPlayer).transform.position);
			Vector3 position = ((Component)this).transform.position;
			position.y = ((Component)inSpecialAnimationWithPlayer).transform.position.y;
			playerRay = new Ray(val3, position - ((Component)inSpecialAnimationWithPlayer).transform.position);
			turnCompass.LookAt(val3);
			position = ((Component)this).transform.eulerAngles;
			position.y = turnCompass.eulerAngles.y;
			((Component)this).transform.eulerAngles = position;
			if (killAnimationCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(killAnimationCoroutine);
			}
			killAnimationCoroutine = ((MonoBehaviour)this).StartCoroutine(killAnimation());
		}
	}

	private IEnumerator killAnimation()
	{
		WalkieTalkie.TransmitOneShotAudio(crackNeckAudio, crackNeckSFX);
		crackNeckAudio.PlayOneShot(crackNeckSFX);
		Vector3 endPosition = ((Ray)(ref playerRay)).GetPoint(1f);
		if (endPosition.y < -80f)
		{
			Vector3 startingPosition = ((Component)this).transform.position;
			for (int i = 0; i < 5; i++)
			{
				((Component)this).transform.position = Vector3.Lerp(startingPosition, endPosition, (float)i / 5f);
				yield return null;
			}
			((Component)this).transform.position = endPosition;
		}
		creatureAnimator.SetBool("killing", false);
		creatureAnimator.SetBool("carryingBody", true);
		yield return (object)new WaitForSeconds(0.65f);
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null)
		{
			inSpecialAnimationWithPlayer.KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Strangulation);
			inSpecialAnimationWithPlayer.snapToServerPosition = false;
			float startTime = Time.timeSinceLevelLoad;
			yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)inSpecialAnimationWithPlayer.deadBody != (Object)null || Time.timeSinceLevelLoad - startTime > 2f));
		}
		if ((Object)(object)inSpecialAnimationWithPlayer == (Object)null || (Object)(object)inSpecialAnimationWithPlayer.deadBody == (Object)null)
		{
			Debug.Log((object)"Flowerman: Player body was not spawned or found within 2 seconds.");
			FinishKillAnimation(carryingBody: false);
		}
		else
		{
			inSpecialAnimationWithPlayer.deadBody.bodyBleedingHeavily = true;
			FinishKillAnimation();
		}
	}

	public void FinishKillAnimation(bool carryingBody = true)
	{
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		if (killAnimationCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(killAnimationCoroutine);
		}
		inSpecialAnimation = false;
		inKillAnimation = false;
		startingKillAnimationLocalClient = false;
		creatureAnimator.SetBool("killing", false);
		if ((Object)(object)inSpecialAnimationWithPlayer != (Object)null)
		{
			inSpecialAnimationWithPlayer.inSpecialInteractAnimation = false;
			inSpecialAnimationWithPlayer.snapToServerPosition = false;
			inSpecialAnimationWithPlayer.inAnimationWithEnemy = null;
			if (carryingBody)
			{
				bodyBeingCarried = inSpecialAnimationWithPlayer.deadBody;
				bodyBeingCarried.attachedTo = rightHandGrip;
				bodyBeingCarried.attachedLimb = inSpecialAnimationWithPlayer.deadBody.bodyParts[0];
				bodyBeingCarried.matchPositionExactly = true;
				carryingPlayerBody = true;
			}
		}
		evadeStealthTimer = 0f;
		movingTowardsTargetPlayer = false;
		ignoredNodes.Clear();
		if (!carryingBody)
		{
			creatureAnimator.SetBool("carryingBody", false);
		}
		if (((NetworkBehaviour)this).IsOwner)
		{
			Vector3 position = ((Component)this).transform.position;
			position = RoundManager.Instance.GetNavMeshPosition(position, default(NavMeshHit), 10f);
			if (!RoundManager.Instance.GotNavMeshPositionResult)
			{
				RaycastHit val = default(RaycastHit);
				position = ((!Physics.Raycast(((Component)this).transform.position, -Vector3.up, ref val, 50f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)) ? allAINodes[Random.Range(0, allAINodes.Length)].transform.position : RoundManager.Instance.GetNavMeshPosition(((RaycastHit)(ref val)).point, default(NavMeshHit), 10f));
			}
			((Component)this).transform.position = position;
			((Behaviour)agent).enabled = true;
			isClientCalculatingAI = true;
		}
		SwitchToBehaviourStateOnLocalClient(1);
		if (((NetworkBehaviour)this).IsServer)
		{
			SwitchToBehaviourState(1);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ResetFlowermanStealthTimerServerRpc(int playerObj)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(843847125u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObj);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 843847125u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ResetFlowermanStealthClientRpc(playerObj);
			}
		}
	}

	[ClientRpc]
	public void ResetFlowermanStealthClientRpc(int playerObj)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3273050u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerObj);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3273050u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && playerObj != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				LookAtFlowermanTrigger(playerObj);
			}
		}
	}

	public void LookAtFlowermanTrigger(int playerObj)
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if (!((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		if (!evadeModeStareDown)
		{
			if (Random.Range(0, 70) < stareDownChanceIncrease)
			{
				stareDownChanceIncrease = -6;
				evadeModeStareDown = true;
			}
			else
			{
				stareDownChanceIncrease++;
			}
			evadeStealthTimer = 0f;
		}
		if (carryingPlayerBody && (Object)(object)favoriteSpot != (Object)null && Vector3.Distance(((Component)this).transform.position, ((Component)favoriteSpot).transform.position) < 5f)
		{
			DropPlayerBody();
		}
	}

	public override void KillEnemy(bool destroy = false)
	{
		if ((Object)(object)creatureVoice != (Object)null)
		{
			creatureVoice.Stop();
		}
		creatureSFX.Stop();
		creatureAngerVoice.Stop();
		creatureAnimator.SetLayerWeight(2, 0f);
		base.KillEnemy();
		if (carryingPlayerBody)
		{
			carryingPlayerBody = false;
			if ((Object)(object)bodyBeingCarried != (Object)null)
			{
				bodyBeingCarried.matchPositionExactly = false;
				bodyBeingCarried.attachedTo = null;
			}
		}
		if (inKillAnimation)
		{
			FinishKillAnimation(carryingBody: false);
		}
	}

	public override void HitEnemy(int force = 1, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		base.HitEnemy(force, playerWhoHit, playHitSFX, hitID);
		if (isEnemyDead)
		{
			return;
		}
		enemyHP -= force;
		if (((NetworkBehaviour)this).IsOwner)
		{
			if (enemyHP <= 0)
			{
				KillEnemyOnOwnerClient();
				return;
			}
			angerMeter = 11f;
			angerCheckInterval = 1f;
			AddToAngerMeter(0.1f);
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_FlowermanAI()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(80027368u, new RpcReceiveHandler(__rpc_handler_80027368));
		NetworkManager.__rpc_func_table.Add(2307050878u, new RpcReceiveHandler(__rpc_handler_2307050878));
		NetworkManager.__rpc_func_table.Add(2817453984u, new RpcReceiveHandler(__rpc_handler_2817453984));
		NetworkManager.__rpc_func_table.Add(1942952026u, new RpcReceiveHandler(__rpc_handler_1942952026));
		NetworkManager.__rpc_func_table.Add(2920701539u, new RpcReceiveHandler(__rpc_handler_2920701539));
		NetworkManager.__rpc_func_table.Add(2215703370u, new RpcReceiveHandler(__rpc_handler_2215703370));
		NetworkManager.__rpc_func_table.Add(114605325u, new RpcReceiveHandler(__rpc_handler_114605325));
		NetworkManager.__rpc_func_table.Add(843847125u, new RpcReceiveHandler(__rpc_handler_843847125));
		NetworkManager.__rpc_func_table.Add(3273050u, new RpcReceiveHandler(__rpc_handler_3273050));
	}

	private static void __rpc_handler_80027368(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			float angerTime = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref angerTime, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((FlowermanAI)(object)target).EnterAngerModeServerRpc(angerTime);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2307050878(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float angerTime = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref angerTime, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowermanAI)(object)target).EnterAngerModeClientRpc(angerTime);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2817453984(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((FlowermanAI)(object)target).DropPlayerBodyServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1942952026(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowermanAI)(object)target).DropPlayerBodyClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2920701539(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((FlowermanAI)(object)target).KillPlayerAnimationServerRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2215703370(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowermanAI)(object)target).CancelKillAnimationClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_114605325(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObjectId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowermanAI)(object)target).KillPlayerAnimationClientRpc(playerObjectId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_843847125(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObj = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObj);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((FlowermanAI)(object)target).ResetFlowermanStealthTimerServerRpc(playerObj);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3273050(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerObj = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerObj);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((FlowermanAI)(object)target).ResetFlowermanStealthClientRpc(playerObj);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "FlowermanAI";
	}
}
