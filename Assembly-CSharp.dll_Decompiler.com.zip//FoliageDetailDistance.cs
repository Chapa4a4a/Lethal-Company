using System.Collections.Generic;
using UnityEngine;

public class FoliageDetailDistance : MonoBehaviour
{
	public List<MeshRenderer> allBushRenderers = new List<MeshRenderer>();

	private float updateInterval;

	private int bushIndex;

	private Coroutine updateBushesLODCoroutine;

	public Material highDetailMaterial;

	public Material lowDetailMaterial;

	public Transform localPlayerTransform;

	private void Start()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("Bush");
		for (int i = 0; i < array.Length; i++)
		{
			MeshRenderer component = array[i].GetComponent<MeshRenderer>();
			if (Object.op_Implicit((Object)(object)component))
			{
				allBushRenderers.Add(component);
			}
		}
		localPlayerTransform = ((Component)Object.FindObjectOfType<StartOfRound>().localPlayerController).transform;
	}

	private void Update()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)localPlayerTransform == (Object)null)
		{
			return;
		}
		if (updateInterval >= 0f)
		{
			updateInterval -= Time.deltaTime;
		}
		else if (bushIndex < allBushRenderers.Count)
		{
			if ((Object)(object)allBushRenderers[bushIndex] == (Object)null)
			{
				return;
			}
			if (Vector3.Distance(localPlayerTransform.position, ((Component)allBushRenderers[bushIndex]).transform.position) > 75f)
			{
				if ((Object)(object)((Renderer)allBushRenderers[bushIndex]).material != (Object)(object)lowDetailMaterial)
				{
					((Renderer)allBushRenderers[bushIndex]).material = lowDetailMaterial;
				}
			}
			else if ((Object)(object)((Renderer)allBushRenderers[bushIndex]).material != (Object)(object)highDetailMaterial)
			{
				((Renderer)allBushRenderers[bushIndex]).material = highDetailMaterial;
			}
			bushIndex++;
		}
		else
		{
			bushIndex = 0;
			updateInterval = 1f;
		}
	}
}
