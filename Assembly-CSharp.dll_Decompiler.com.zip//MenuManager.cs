using System;
using System.Collections;
using Dissonance;
using Steamworks;
using Steamworks.Data;
using TMPro;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuManager : MonoBehaviour
{
	public GameObject menuButtons;

	public bool isInitScene;

	[Space(5f)]
	public GameObject menuNotification;

	public TextMeshProUGUI menuNotificationText;

	public TextMeshProUGUI menuNotificationButtonText;

	public TextMeshProUGUI versionNumberText;

	[Space(5f)]
	public TextMeshProUGUI loadingText;

	public GameObject loadingScreen;

	[Space(5f)]
	public GameObject lanButtonContainer;

	public GameObject lanWarningContainer;

	public GameObject joinCrewButtonContainer;

	public TextMeshProUGUI launchedInLanModeText;

	[Space(3f)]
	public GameObject serverListUIContainer;

	public AudioListener menuListener;

	public TextMeshProUGUI tipTextHostSettings;

	[Space(5f)]
	public TextMeshProUGUI logText;

	public GameObject inputFieldGameObject;

	[Space(5f)]
	public GameObject NewsPanel;

	[Space(5f)]
	public GameObject HostSettingsScreen;

	public TMP_InputField lobbyNameInputField;

	public TMP_InputField lobbyTagInputField;

	public bool hostSettings_LobbyPublic;

	public Animator setPublicButtonAnimator;

	public Animator setPrivateButtonAnimator;

	public TextMeshProUGUI privatePublicDescription;

	[SerializeField]
	private Button startHostButton;

	[SerializeField]
	private Button startClientButton;

	[SerializeField]
	private Button leaveButton;

	public GameObject HostSettingsOptionsLAN;

	public GameObject HostSettingsOptionsNormal;

	public Animator lanSetLocalButtonAnimator;

	public Animator lanSetAllowRemoteButtonAnimator;

	[SerializeField]
	private TMP_InputField joinCodeInput;

	private bool hasServerStarted;

	private bool startingAClient;

	private int currentMicrophoneDevice;

	public TextMeshProUGUI currentMicrophoneText;

	public DissonanceComms comms;

	public AudioSource MenuAudio;

	public AudioClip menuMusic;

	public AudioClip openMenuSound;

	public Animator menuAnimator;

	public TextMeshProUGUI changesNotAppliedText;

	public TextMeshProUGUI settingsBackButton;

	public GameObject PleaseConfirmChangesSettingsPanel;

	public Button PleaseConfirmChangesSettingsPanelBackButton;

	public GameObject KeybindsPanel;

	private bool selectingUIThisFrame;

	private GameObject lastSelectedGameObject;

	private bool playSelectAudioThisFrame;

	public bool[] filesCompatible;

	private Leaderboard? challengeLeaderboard;

	public GameObject leaderboardContainer;

	public GameObject leaderboardSlotPrefab;

	public Transform leaderboardSlotsContainer;

	public int leaderboardSlotOffset;

	public int leaderboardFilterType;

	public bool requestingLeaderboard;

	public GameObject hostSettingsPanel;

	public bool hasChallengeBeenCompleted;

	public int challengeScore;

	public Animator submittedRankAnimator;

	public AudioClip submitRankSFX;

	public TextMeshProUGUI submittedRankText;

	private Coroutine displayLeaderboardSlotsCoroutine;

	public TextMeshProUGUI leaderboardHeaderText;

	public TextMeshProUGUI leaderboardLoadingText;

	public GameObject removeScoreButton;

	public AudioClip coldOpen2Audio;

	public Texture2D defaultCursor;

	private void Update()
	{
		if ((Object)(object)EventSystem.current == (Object)null)
		{
			return;
		}
		if ((Object)(object)lastSelectedGameObject != (Object)(object)EventSystem.current.currentSelectedGameObject)
		{
			lastSelectedGameObject = EventSystem.current.currentSelectedGameObject;
			if (!playSelectAudioThisFrame)
			{
				playSelectAudioThisFrame = true;
				return;
			}
			MenuAudio.PlayOneShot(GameNetworkManager.Instance.buttonSelectSFX);
		}
		if (!((Object)(object)lobbyTagInputField == (Object)null) && !((Object)(object)((Component)lobbyTagInputField).gameObject == (Object)null))
		{
			if (!((Component)lobbyTagInputField).gameObject.activeSelf && hostSettings_LobbyPublic)
			{
				((Component)lobbyTagInputField).gameObject.SetActive(true);
			}
			else if (((Component)lobbyTagInputField).gameObject.activeSelf && (!hostSettings_LobbyPublic || GameNetworkManager.Instance.disableSteam))
			{
				((Component)lobbyTagInputField).gameObject.SetActive(false);
			}
		}
	}

	public void PlayConfirmSFX()
	{
		playSelectAudioThisFrame = false;
		MenuAudio.PlayOneShot(GameNetworkManager.Instance.buttonPressSFX);
	}

	public void PlayCancelSFX()
	{
		playSelectAudioThisFrame = false;
		MenuAudio.PlayOneShot(GameNetworkManager.Instance.buttonCancelSFX);
	}

	private void Awake()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		Cursor.visible = true;
		Cursor.lockState = (CursorLockMode)0;
		Cursor.SetCursor(defaultCursor, new Vector2(0f, 0f), (CursorMode)0);
		if ((Object)(object)GameNetworkManager.Instance != (Object)null)
		{
			GameNetworkManager.Instance.isDisconnecting = false;
			GameNetworkManager.Instance.isHostingGame = false;
		}
		if ((Object)(object)GameNetworkManager.Instance != (Object)null && (Object)(object)versionNumberText != (Object)null)
		{
			((TMP_Text)versionNumberText).text = $"v{GameNetworkManager.Instance.gameVersionNum}";
		}
		filesCompatible = new bool[3];
		for (int i = 0; i < filesCompatible.Length; i++)
		{
			filesCompatible[i] = true;
		}
		if ((Object)(object)coldOpen2Audio != (Object)null)
		{
			coldOpen2Audio.UnloadAudioData();
		}
	}

	private IEnumerator PlayMenuMusicDelayed()
	{
		if ((Object)(object)GameNetworkManager.Instance != (Object)null && GameNetworkManager.Instance.firstTimeInMenu)
		{
			GameNetworkManager.Instance.firstTimeInMenu = false;
			MenuAudio.PlayOneShot(openMenuSound, 1f);
			yield return (object)new WaitForSeconds(0.3f);
		}
		else
		{
			menuAnimator.SetTrigger("skipOpening");
		}
		yield return (object)new WaitForSeconds(0.1f);
		MenuAudio.clip = menuMusic;
		MenuAudio.Play();
	}

	private void Start()
	{
		if (isInitScene)
		{
			return;
		}
		bool flag = false;
		if (!string.IsNullOrEmpty(GameNetworkManager.Instance.disconnectionReasonMessage))
		{
			SetLoadingScreen(isLoading: false, (RoomEnter)5);
		}
		else if (GameNetworkManager.Instance.disconnectReason != 0)
		{
			if (!string.IsNullOrEmpty(NetworkManager.Singleton.DisconnectReason))
			{
				DisplayMenuNotification(NetworkManager.Singleton.DisconnectReason ?? "", "[ Back ]");
				flag = true;
			}
			else if (GameNetworkManager.Instance.disconnectReason == 1)
			{
				DisplayMenuNotification("The server host disconnected.", "[ Back ]");
				flag = true;
			}
			else if (GameNetworkManager.Instance.disconnectReason == 2)
			{
				DisplayMenuNotification("Your connection timed out.", "[ Back ]");
				flag = true;
			}
			GameNetworkManager.Instance.disconnectReason = 0;
		}
		if (GameNetworkManager.Instance.disableSteam)
		{
			((Behaviour)launchedInLanModeText).enabled = true;
			lanButtonContainer.SetActive(true);
			lanWarningContainer.SetActive(true);
			joinCrewButtonContainer.SetActive(false);
		}
		else
		{
			lanButtonContainer.SetActive(false);
			joinCrewButtonContainer.SetActive(true);
		}
		string text;
		if (GameNetworkManager.Instance.disableSteam)
		{
			text = "Unnamed";
		}
		else if (!SteamClient.IsLoggedOn)
		{
			DisplayMenuNotification("Could not connect to Steam servers! (If you just want to play on your local network, choose LAN on launch.)", "Continue");
			text = "Unnamed";
		}
		else
		{
			text = SteamClient.Name.ToString() + "'s Crew";
		}
		hostSettings_LobbyPublic = ES3.Load<bool>("HostSettings_Public", "LCGeneralSaveData", false);
		lobbyNameInputField.text = ES3.Load<string>("HostSettings_Name", "LCGeneralSaveData", text);
		int num = ES3.Load<int>("LastVerPlayed", "LCGeneralSaveData", -1);
		if (!flag)
		{
			if (GameNetworkManager.Instance.firstTimeInMenu && (GameNetworkManager.Instance.AlwaysDisplayNews || num != GameNetworkManager.Instance.gameVersionNum))
			{
				NewsPanel.SetActive(true);
				EventSystem.current.SetSelectedGameObject(((Component)NewsPanel.gameObject.GetComponentInChildren<Button>()).gameObject);
			}
			else
			{
				EventSystem.current.SetSelectedGameObject(((Component)startHostButton).gameObject);
			}
		}
		string text2 = "noSaveNameSet";
		bool flag2 = true;
		for (int i = 0; i < 3; i++)
		{
			switch (i)
			{
			case 0:
				text2 = "LCSaveFile1";
				break;
			case 1:
				text2 = "LCSaveFile2";
				break;
			case 2:
				text2 = "LCSaveFile3";
				break;
			}
			if (!ES3.FileExists(text2))
			{
				continue;
			}
			try
			{
				if (ES3.Load<int>("FileGameVers", text2, 0) < GameNetworkManager.Instance.compatibleFileCutoffVersion)
				{
					Debug.Log((object)string.Format("file vers: {0} not compatible; {1}", ES3.Load<int>("FileGameVers", text2, 0), GameNetworkManager.Instance.compatibleFileCutoffVersion));
					flag2 = false;
					filesCompatible[i] = false;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError((object)$"Error loading file #{i}! Deleting file since it's likely corrupted. Error: {arg}");
				ES3.DeleteFile(text2);
			}
		}
		if (!flag2)
		{
			DisplayMenuNotification($"Some of your save files may not be compatible with version {GameNetworkManager.Instance.compatibleFileCutoffVersion} and may be corrupted if you play them.", "[ Back ]");
		}
		ES3.Save<int>("LastVerPlayed", GameNetworkManager.Instance.gameVersionNum, "LCGeneralSaveData");
		int num2 = ES3.Load<int>("TimesLoadedGame", "LCGeneralSaveData", 0);
		ES3.Save<int>("TimesLoadedGame", num2 + 1, "LCGeneralSaveData");
		if ((Object)(object)MenuAudio != (Object)null)
		{
			((MonoBehaviour)this).StartCoroutine(PlayMenuMusicDelayed());
		}
		SetIfChallengeMoonHasBeenCompleted();
	}

	private void SetIfChallengeMoonHasBeenCompleted()
	{
		int weekNumber = GameNetworkManager.Instance.GetWeekNumber();
		Debug.Log((object)$"week num: {weekNumber}");
		bool flag = ES3.Load<bool>("FinishedChallenge", "LCChallengeFile", false);
		if (flag && ES3.Load<int>("ChallengeWeekNum", "LCChallengeFile", weekNumber - 1) == weekNumber)
		{
			Debug.Log((object)"Set challenge moon completed A");
			challengeScore = ES3.Load<int>("ProfitEarned", "LCChallengeFile", 0);
			hasChallengeBeenCompleted = true;
		}
		else if (flag)
		{
			Debug.Log((object)"Set challenge moon completed B");
			ES3.Save<bool>("FinishedChallenge", false, "LCChallengeFile");
			ES3.Save<bool>("SetChallengeFileMoney", false, "LCChallengeFile");
			ES3.Save<int>("ChallengeWeekNum", weekNumber, "LCChallengeFile");
			ES3.Save<bool>("FinishedChallenge", false, "LCChallengeFile");
			ES3.Save<int>("ProfitEarned", 0, "LCChallengeFile");
			ES3.Save<bool>("SubmittedScore", false, "LCChallengeFile");
		}
	}

	public void EnableLeaderboardDisplay(bool enable)
	{
		leaderboardContainer.SetActive(enable);
		hostSettingsPanel.SetActive(!enable);
		removeScoreButton.SetActive(enable);
		if (enable)
		{
			bool flag = ES3.Load<bool>("SubmittedScore", "LCChallengeFile", false);
			if (!GameNetworkManager.Instance.disableSteam && !requestingLeaderboard)
			{
				GetLeaderboardForChallenge(!flag);
			}
			else
			{
				ClearLeaderboard();
			}
			if (flag && ES3.Load<int>("ProfitEarned", "LCChallengeFile", 0) != 0)
			{
				removeScoreButton.SetActive(true);
			}
		}
	}

	private async void RemoveLeaderboardScore()
	{
		if (requestingLeaderboard)
		{
			return;
		}
		requestingLeaderboard = true;
		if (!challengeLeaderboard.HasValue || !challengeLeaderboard.HasValue)
		{
			int weekNumber = GameNetworkManager.Instance.GetWeekNumber();
			challengeLeaderboard = await SteamUserStats.FindOrCreateLeaderboardAsync($"challenge{weekNumber}", (LeaderboardSort)2, (LeaderboardDisplay)1);
		}
		int[] array = new int[1] { 2 };
		Leaderboard value = challengeLeaderboard.Value;
		await ((Leaderboard)(ref value)).ReplaceScore(0, array);
		if (challengeLeaderboard.HasValue && challengeLeaderboard.HasValue)
		{
			LeaderboardEntry[] entries = null;
			switch (leaderboardFilterType)
			{
			case 0:
				value = challengeLeaderboard.Value;
				entries = await ((Leaderboard)(ref value)).GetScoresFromFriendsAsync();
				break;
			case 1:
				value = challengeLeaderboard.Value;
				entries = await ((Leaderboard)(ref value)).GetScoresAroundUserAsync(-10, 10);
				break;
			case 2:
				value = challengeLeaderboard.Value;
				entries = await ((Leaderboard)(ref value)).GetScoresAsync(20, 1);
				break;
			}
			DisplayLeaderboardSlots(entries);
		}
		removeScoreButton.SetActive(false);
		requestingLeaderboard = false;
	}

	public void SetLeaderboardFilter(int filterId)
	{
		leaderboardFilterType = filterId;
	}

	public void RefreshLeaderboardButton()
	{
		GetLeaderboardForChallenge();
	}

	public void RemoveScoreFromLeaderboardButton()
	{
		RemoveLeaderboardScore();
	}

	private async void GetLeaderboardForChallenge(bool submitScore = false)
	{
		if (requestingLeaderboard || GameNetworkManager.Instance.disableSteam)
		{
			return;
		}
		requestingLeaderboard = true;
		int weekNumber = GameNetworkManager.Instance.GetWeekNumber();
		((TMP_Text)leaderboardHeaderText).text = "Challenge Moon " + GameNetworkManager.Instance.GetNameForWeekNumber(weekNumber) + " Results";
		challengeLeaderboard = await SteamUserStats.FindOrCreateLeaderboardAsync($"challenge{weekNumber}", (LeaderboardSort)2, (LeaderboardDisplay)1);
		Leaderboard value;
		if (submitScore && !hasChallengeBeenCompleted && !ES3.Load<bool>("SubmittedScore", "LCChallengeFile", false))
		{
			value = challengeLeaderboard.Value;
			LeaderboardUpdate? val = await ((Leaderboard)(ref value)).ReplaceScore(challengeScore, (int[])null);
			if (val.HasValue && val.HasValue)
			{
				ES3.Save<bool>("SubmittedScore", true, "LCChallengeFile");
				if (ES3.Load<int>("ProfitEarned", "LCChallengeFile", 0) != 0)
				{
					removeScoreButton.SetActive(true);
				}
			}
		}
		if (challengeLeaderboard.HasValue && challengeLeaderboard.HasValue)
		{
			LeaderboardEntry[] entries = null;
			switch (leaderboardFilterType)
			{
			case 0:
				value = challengeLeaderboard.Value;
				entries = await ((Leaderboard)(ref value)).GetScoresFromFriendsAsync();
				break;
			case 1:
				value = challengeLeaderboard.Value;
				entries = await ((Leaderboard)(ref value)).GetScoresAroundUserAsync(-10, 10);
				break;
			case 2:
				value = challengeLeaderboard.Value;
				entries = await ((Leaderboard)(ref value)).GetScoresAsync(20, 1);
				break;
			}
			DisplayLeaderboardSlots(entries);
		}
		else
		{
			ClearLeaderboard();
			((TMP_Text)leaderboardLoadingText).text = "No entries to display!";
		}
		requestingLeaderboard = false;
	}

	private void ClearLeaderboard()
	{
		ChallengeLeaderboardSlot[] array = Object.FindObjectsByType<ChallengeLeaderboardSlot>((FindObjectsInactive)1, (FindObjectsSortMode)0);
		if (array.Length != 0)
		{
			for (int i = 0; i < array.Length; i++)
			{
				Object.Destroy((Object)(object)((Component)array[i]).gameObject);
			}
		}
		leaderboardSlotOffset = 0;
	}

	private void DisplayLeaderboardSlots(LeaderboardEntry[] entries)
	{
		ClearLeaderboard();
		if (entries == null)
		{
			((TMP_Text)leaderboardLoadingText).text = "No entries to display!";
			return;
		}
		if (displayLeaderboardSlotsCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(displayLeaderboardSlotsCoroutine);
		}
		((TMP_Text)leaderboardLoadingText).text = "Loading ranking...";
		displayLeaderboardSlotsCoroutine = ((MonoBehaviour)this).StartCoroutine(CreateLeaderboardSlots(entries));
	}

	private IEnumerator CreateLeaderboardSlots(LeaderboardEntry[] entries)
	{
		for (int i = 0; i < entries.Length && i <= 150; i++)
		{
			int entryDetails = ((entries[i].Details == null || entries[i].Details.Length == 0) ? (-1) : entries[i].Details[0]);
			GameObject obj = Object.Instantiate<GameObject>(leaderboardSlotPrefab, leaderboardSlotsContainer);
			obj.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, 0f + (float)leaderboardSlotOffset);
			leaderboardSlotOffset -= 54;
			obj.GetComponent<ChallengeLeaderboardSlot>().SetSlotValues(((Friend)(ref entries[i].User)).Name, entries[i].GlobalRank, entries[i].Score, entries[i].User.Id, entryDetails);
			yield return (object)new WaitForSeconds(0.06f);
		}
	}

	public void SubmitLeaderboardScore()
	{
		if (hasChallengeBeenCompleted)
		{
			GetLeaderboardForChallenge(submitScore: true);
		}
	}

	private IEnumerator connectionTimeOut()
	{
		yield return (object)new WaitForSeconds(10.5f);
		((TMP_Text)logText).text = "Connection failed.";
		SetLoadingScreen(isLoading: false, (RoomEnter)5);
		menuButtons.SetActive(true);
		if (GameNetworkManager.Instance.currentLobby.HasValue)
		{
			Lobby value = GameNetworkManager.Instance.currentLobby.Value;
			GameNetworkManager.Instance.SetCurrentLobbyNull();
			try
			{
				((Lobby)(ref value)).Leave();
			}
			catch (Exception arg)
			{
				Debug.LogError((object)$"Failed to leave lobby; {arg}");
			}
		}
	}

	public void SetLoadingScreen(bool isLoading, RoomEnter result = 5, string overrideMessage = "")
	{
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected I4, but got Unknown
		Debug.Log((object)"Displaying menu message");
		if (isLoading)
		{
			menuButtons.SetActive(false);
			loadingScreen.SetActive(true);
			serverListUIContainer.SetActive(false);
			MenuAudio.volume = 0.2f;
			return;
		}
		MenuAudio.volume = 0.5f;
		menuButtons.SetActive(true);
		loadingScreen.SetActive(false);
		serverListUIContainer.SetActive(false);
		if (!string.IsNullOrEmpty(overrideMessage))
		{
			Debug.Log((object)"Displaying menu message 2");
			DisplayMenuNotification(overrideMessage, "[ Back ]");
			return;
		}
		if (!string.IsNullOrEmpty(GameNetworkManager.Instance.disconnectionReasonMessage))
		{
			Debug.Log((object)"Displaying menu message 3");
			DisplayMenuNotification(GameNetworkManager.Instance.disconnectionReasonMessage ?? "", "[ Back ]");
			GameNetworkManager.Instance.disconnectionReasonMessage = "";
			return;
		}
		Debug.Log((object)"Failed loading; displaying notification");
		Debug.Log((object)("result: " + ((object)(RoomEnter)(ref result)).ToString()));
		switch (result - 2)
		{
		case 2:
			DisplayMenuNotification("The server is full!", "[ Back ]");
			break;
		case 0:
			DisplayMenuNotification("The server no longer exists!", "[ Back ]");
			break;
		case 13:
			DisplayMenuNotification("You are joining/leaving too fast!", "[ Back ]");
			break;
		case 8:
			DisplayMenuNotification("A member of the server has blocked you!", "[ Back ]");
			break;
		case 3:
			DisplayMenuNotification("An error occured!", "[ Back ]");
			break;
		case 1:
			DisplayMenuNotification("Connection was not approved!", "[ Back ]");
			break;
		case 9:
			DisplayMenuNotification("You have blocked someone in this server!", "[ Back ]");
			break;
		case 4:
			DisplayMenuNotification("Unable to join because you have been banned!", "[ Back ]");
			break;
		default:
			DisplayMenuNotification("Something went wrong!", "[ Back ]");
			break;
		}
	}

	public void DisplayMenuNotification(string notificationText, string buttonText)
	{
		if (!isInitScene)
		{
			Debug.Log((object)("Displaying menu notification: " + notificationText));
			((TMP_Text)menuNotificationText).text = notificationText;
			((TMP_Text)menuNotificationButtonText).text = buttonText;
			menuNotification.SetActive(true);
			EventSystem.current.SetSelectedGameObject(((Component)menuNotification.GetComponentInChildren<Button>()).gameObject);
		}
	}

	public void StartConnectionTimeOutTimer()
	{
		((MonoBehaviour)this).StartCoroutine(connectionTimeOut());
	}

	public void StartAClient()
	{
		LAN_HostSetAllowRemoteConnections();
		startingAClient = true;
		((TMP_Text)logText).text = "Connecting to server...";
		try
		{
			GameNetworkManager.Instance.SetConnectionDataBeforeConnecting();
			GameNetworkManager.Instance.SubscribeToConnectionCallbacks();
			if (NetworkManager.Singleton.StartClient())
			{
				Debug.Log((object)"Started a client");
				((TMP_Text)logText).text = "Connecting to host...";
				SetLoadingScreen(isLoading: true, (RoomEnter)5);
			}
			else
			{
				Debug.Log((object)"Could not start client");
				SetLoadingScreen(isLoading: false, (RoomEnter)5);
				startingAClient = false;
				((TMP_Text)logText).text = "Connection failed. Try again?";
			}
		}
		catch (Exception arg)
		{
			((TMP_Text)logText).text = "Connection failed.";
			Debug.Log((object)$"Connection failed: {arg}");
		}
	}

	public void StartHosting()
	{
		SetLoadingScreen(isLoading: true, (RoomEnter)5);
		try
		{
			if (NetworkManager.Singleton.StartHost())
			{
				Debug.Log((object)"started host!");
				Debug.Log((object)$"are we in a server?: {NetworkManager.Singleton.IsServer}");
				NetworkManager.Singleton.SceneManager.SetClientSynchronizationMode((LoadSceneMode)0);
				((MonoBehaviour)this).StartCoroutine(delayedStartScene());
			}
			else
			{
				SetLoadingScreen(isLoading: false, (RoomEnter)5);
				((TMP_Text)logText).text = "Failed to start server; 20";
			}
		}
		catch (Exception arg)
		{
			((TMP_Text)logText).text = "Failed to start server; 30";
			Debug.Log((object)$"Server connection failed: {arg}");
		}
	}

	private IEnumerator delayedStartScene()
	{
		((TMP_Text)logText).text = "Started server, joining...";
		yield return (object)new WaitForSeconds(1f);
		AudioListener.volume = 0f;
		yield return (object)new WaitForSeconds(0.1f);
		NetworkManager.Singleton.SceneManager.LoadScene("SampleSceneRelay", (LoadSceneMode)0);
	}

	private void OnEnable()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected O, but got Unknown
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Expected O, but got Unknown
		Button obj = startHostButton;
		if (obj != null)
		{
			((UnityEvent)obj.onClick).AddListener(new UnityAction(ClickHostButton));
		}
		Button obj2 = leaveButton;
		if (obj2 != null)
		{
			((UnityEvent)obj2.onClick).AddListener(new UnityAction(ClickQuitButton));
		}
	}

	public void ClickHostButton()
	{
		Debug.Log((object)"host button pressed");
		EnableLeaderboardDisplay(enable: false);
		HostSettingsScreen.SetActive(true);
		if (GameNetworkManager.Instance.disableSteam)
		{
			HostSettingsOptionsLAN.SetActive(true);
			HostSettingsOptionsNormal.SetActive(false);
		}
		if (Object.op_Implicit((Object)(object)Object.FindObjectOfType<SaveFileUISlot>()))
		{
			Object.FindObjectOfType<SaveFileUISlot>().SetButtonColorForAllFileSlots();
		}
		HostSetLobbyPublic(hostSettings_LobbyPublic);
	}

	public void ConfirmHostButton()
	{
		if (string.IsNullOrEmpty(lobbyNameInputField.text))
		{
			((TMP_Text)tipTextHostSettings).text = "Enter a lobby name!";
			return;
		}
		HostSettingsScreen.SetActive(false);
		if (lobbyNameInputField.text.Length > 40)
		{
			lobbyNameInputField.text = lobbyNameInputField.text.Substring(0, 40);
		}
		ES3.Save<string>("HostSettings_Name", lobbyNameInputField.text, "LCGeneralSaveData");
		ES3.Save<bool>("HostSettings_Public", hostSettings_LobbyPublic, "LCGeneralSaveData");
		if (!hostSettings_LobbyPublic)
		{
			lobbyTagInputField.text = "";
		}
		GameNetworkManager.Instance.lobbyHostSettings = new HostSettings(lobbyNameInputField.text, hostSettings_LobbyPublic, lobbyTagInputField.text);
		GameNetworkManager.Instance.StartHost();
	}

	public void LAN_HostSetLocal()
	{
		Debug.Log((object)"Clicked local connection only");
		((Component)NetworkManager.Singleton).GetComponent<UnityTransport>().ConnectionData.ServerListenAddress = "127.0.0.1";
		lanSetLocalButtonAnimator.SetBool("isPressed", true);
		lanSetAllowRemoteButtonAnimator.SetBool("isPressed", false);
	}

	public void LAN_HostSetAllowRemoteConnections()
	{
		Debug.Log((object)"Clicked allow remote connections");
		((Component)NetworkManager.Singleton).GetComponent<UnityTransport>().ConnectionData.ServerListenAddress = "0.0.0.0";
		lanSetLocalButtonAnimator.SetBool("isPressed", false);
		lanSetAllowRemoteButtonAnimator.SetBool("isPressed", true);
	}

	public void HostSetLobbyPublic(bool setPublic = false)
	{
		if (GameNetworkManager.Instance.disableSteam)
		{
			lanSetLocalButtonAnimator.SetBool("isPressed", true);
			lanSetAllowRemoteButtonAnimator.SetBool("isPressed", false);
			LAN_HostSetLocal();
			((TMP_Text)privatePublicDescription).text = "";
			return;
		}
		hostSettings_LobbyPublic = setPublic;
		setPrivateButtonAnimator.SetBool("isPressed", !setPublic);
		setPublicButtonAnimator.SetBool("isPressed", setPublic);
		if (setPublic)
		{
			((TMP_Text)privatePublicDescription).text = "PUBLIC means your game will be visible on the server list for all to see.";
		}
		else
		{
			((TMP_Text)privatePublicDescription).text = "PRIVATE means you must send invites through Steam for players to join.";
		}
	}

	public void FilledRoomNameField()
	{
		((TMP_Text)tipTextHostSettings).text = "";
	}

	public void EnableUIPanel(GameObject enablePanel)
	{
		enablePanel.SetActive(true);
	}

	public void DisableUIPanel(GameObject enablePanel)
	{
		enablePanel.SetActive(false);
	}

	private void ClickJoinButton()
	{
		Debug.Log((object)"join button pressed");
		((Component)startClientButton).gameObject.SetActive(false);
		inputFieldGameObject.SetActive(true);
	}

	private void ClickQuitButton()
	{
		Application.Quit();
	}
}
