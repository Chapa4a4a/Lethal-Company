using System.Collections;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Rendering.HighDefinition;

public class AudioReverbTrigger : MonoBehaviour
{
	public PlayerControllerB playerScript;

	public ReverbPreset reverbPreset;

	public int usePreset = -1;

	[Header("CHANGE AUDIO AMBIANCE")]
	public switchToAudio[] audioChanges;

	[Header("MISC")]
	public bool elevatorTriggerForProps;

	public bool setInElevatorTrigger;

	public bool isShipRoom;

	public bool toggleLocalFog;

	public float fogEnabledAmount = 10f;

	public LocalVolumetricFog localFog;

	public Terrain terrainObj;

	[Header("Weather and effects")]
	public bool setInsideAtmosphere;

	public bool insideLighting;

	public int weatherEffect = -1;

	public bool effectEnabled;

	public bool disableAllWeather;

	public bool enableCurrentLevelWeather;

	private bool spectatedClientTriggered;

	private IEnumerator changeVolume(AudioSource aud, float changeVolumeTo)
	{
		if ((Object)(object)localFog != (Object)null)
		{
			float fogTarget = fogEnabledAmount;
			if (!toggleLocalFog)
			{
				fogTarget = 200f;
			}
			for (int i = 0; i < 40; i++)
			{
				aud.volume = Mathf.Lerp(aud.volume, changeVolumeTo, (float)i / 40f);
				localFog.parameters.meanFreePath = Mathf.Lerp(localFog.parameters.meanFreePath, fogTarget, (float)i / 40f);
				yield return (object)new WaitForSeconds(0.004f);
			}
		}
		else
		{
			for (int i = 0; i < 40; i++)
			{
				aud.volume = Mathf.Lerp(aud.volume, changeVolumeTo, (float)i / 40f);
				yield return (object)new WaitForSeconds(0.004f);
			}
		}
		playerScript.audioCoroutines.Remove(aud);
		playerScript.audioCoroutines2.Remove(aud);
	}

	public void ChangeAudioReverbForPlayer(PlayerControllerB pScript)
	{
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		playerScript = pScript;
		if ((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null || (Object)(object)playerScript.currentAudioTrigger == (Object)(object)this || !playerScript.isPlayerControlled)
		{
			return;
		}
		if ((Object)(object)NetworkManager.Singleton == (Object)null)
		{
			Debug.Log((object)"Network manager is null");
		}
		if (usePreset != -1)
		{
			AudioReverbPresets audioReverbPresets = Object.FindObjectOfType<AudioReverbPresets>();
			if ((Object)(object)audioReverbPresets != (Object)null)
			{
				if (audioReverbPresets.audioPresets.Length <= usePreset)
				{
					Debug.LogError((object)("The audio preset set by " + ((Object)((Component)this).gameObject).name + " is not one allowed by the audioreverbpresets in the scene."));
				}
				else if (audioReverbPresets.audioPresets[usePreset].usePreset != -1)
				{
					Debug.LogError((object)"Audio preset AudioReverbTrigger is set to call another audio preset which would crash!");
				}
				else
				{
					audioReverbPresets.audioPresets[usePreset].ChangeAudioReverbForPlayer(pScript);
				}
				return;
			}
		}
		if ((Object)(object)reverbPreset != (Object)null)
		{
			playerScript.reverbPreset = reverbPreset;
		}
		if (elevatorTriggerForProps)
		{
			if (setInElevatorTrigger)
			{
				Bounds bounds = StartOfRound.Instance.shipBounds.bounds;
				if (!((Bounds)(ref bounds)).Contains(((Component)playerScript).transform.position))
				{
					goto IL_01bb;
				}
			}
			if ((Object)(object)playerScript.currentlyHeldObjectServer != (Object)null && playerScript.isHoldingObject)
			{
				playerScript.SetItemInElevator(isShipRoom, setInElevatorTrigger, playerScript.currentlyHeldObjectServer);
			}
			if (playerScript.playersManager.shipDoorsEnabled || setInElevatorTrigger)
			{
				playerScript.isInElevator = setInElevatorTrigger;
				playerScript.isInHangarShipRoom = isShipRoom;
			}
			playerScript.playersManager.SetPlayerSafeInShip();
		}
		goto IL_01bb;
		IL_01bb:
		if ((Object)(object)playerScript != (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			if ((Object)(object)GameNetworkManager.Instance.localPlayerController.spectatedPlayerScript != (Object)(object)playerScript)
			{
				playerScript.currentAudioTrigger = this;
				return;
			}
			spectatedClientTriggered = true;
		}
		else
		{
			spectatedClientTriggered = false;
		}
		if (disableAllWeather)
		{
			TimeOfDay.Instance.DisableAllWeather();
		}
		else
		{
			if (weatherEffect != -1)
			{
				TimeOfDay.Instance.effects[weatherEffect].effectEnabled = effectEnabled;
			}
			if (enableCurrentLevelWeather && TimeOfDay.Instance.currentLevelWeather != LevelWeatherType.None)
			{
				TimeOfDay.Instance.effects[(int)TimeOfDay.Instance.currentLevelWeather].effectEnabled = true;
			}
		}
		if (setInsideAtmosphere)
		{
			TimeOfDay.Instance.insideLighting = insideLighting;
		}
		PlayerControllerB playerControllerB = playerScript;
		playerScript = GameNetworkManager.Instance.localPlayerController;
		for (int i = 0; i < audioChanges.Length; i++)
		{
			AudioSource audio = audioChanges[i].audio;
			if (audioChanges[i].stopAudio)
			{
				audio.Stop();
				continue;
			}
			if ((Object)(object)audioChanges[i].changeToClip != (Object)null && (Object)(object)audio.clip != (Object)(object)audioChanges[i].changeToClip)
			{
				bool flag = false;
				if (audio.isPlaying)
				{
					flag = true;
				}
				audio.clip = audioChanges[i].changeToClip;
				if (flag)
				{
					audio.Play();
				}
			}
			else if ((Object)(object)audioChanges[i].changeToClip == (Object)null && !audio.isPlaying && !audioChanges[i].changeAudioVolume)
			{
				audio.Play();
			}
			if (audioChanges[i].changeAudioVolume && (Object)(object)playerScript.currentAudioTrigger != (Object)(object)this)
			{
				if (playerScript.audioCoroutines.TryGetValue(audio, out var value))
				{
					value.StopAudioCoroutine(audio);
					IEnumerator enumerator = changeVolume(audio, audioChanges[i].audioVolume);
					((MonoBehaviour)this).StartCoroutine(enumerator);
				}
				else
				{
					IEnumerator enumerator2 = changeVolume(audio, audioChanges[i].audioVolume);
					((MonoBehaviour)this).StartCoroutine(enumerator2);
					playerScript.audioCoroutines.Add(audio, this);
					playerScript.audioCoroutines2.Add(audio, enumerator2);
				}
			}
		}
		if (spectatedClientTriggered)
		{
			playerControllerB.currentAudioTrigger = this;
		}
		playerScript.currentAudioTrigger = this;
	}

	private void OnTriggerStay(Collider other)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		if (elevatorTriggerForProps)
		{
			if (setInElevatorTrigger && ((Component)other).gameObject.CompareTag("Enemy"))
			{
				Bounds bounds = ((Component)this).gameObject.GetComponent<Collider>().bounds;
				if (((Bounds)(ref bounds)).Contains(((Component)other).transform.position))
				{
					EnemyAICollisionDetect component = ((Component)other).gameObject.GetComponent<EnemyAICollisionDetect>();
					if ((Object)(object)component != (Object)null)
					{
						bool flag = false;
						if (component.mainScript.isInsidePlayerShip != isShipRoom)
						{
							flag = true;
						}
						component.mainScript.isInsidePlayerShip = isShipRoom;
						if (flag)
						{
							StartOfRound.Instance.SetPlayerSafeInShip();
						}
					}
					return;
				}
			}
			if (((Component)other).gameObject.tag.StartsWith("PlayerRagdoll"))
			{
				DeadBodyInfo component2 = ((Component)other).gameObject.GetComponent<DeadBodyInfo>();
				if ((Object)(object)component2 != (Object)null)
				{
					if ((Object)(object)component2.attachedTo != (Object)null && (Object)(object)component2.attachedLimb != (Object)null)
					{
						return;
					}
					component2.parentedToShip = setInElevatorTrigger;
					if ((Object)(object)component2.attachedLimb == (Object)null || (Object)(object)component2.attachedTo == (Object)null)
					{
						if (setInElevatorTrigger)
						{
							((Component)component2).transform.SetParent(StartOfRound.Instance.elevatorTransform);
						}
						else
						{
							((Component)component2).transform.SetParent((Transform)null);
						}
					}
				}
			}
		}
		if (((Component)other).gameObject.CompareTag("Player") && !((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null))
		{
			playerScript = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if (!((Object)(object)playerScript == (Object)null) && playerScript.isPlayerControlled)
			{
				ChangeAudioReverbForPlayer(playerScript);
			}
		}
	}

	public void StopAudioCoroutine(AudioSource audioKey)
	{
		if (playerScript.audioCoroutines2.TryGetValue(audioKey, out var value))
		{
			((MonoBehaviour)this).StopCoroutine(value);
		}
	}
}
