using UnityEngine.Events;

public class PowerSwitchEvent : UnityEvent<bool>
{
}
