using UnityEngine;
using UnityEngine.Events;

public class FloodWeather : MonoBehaviour
{
	public AudioSource waterAudio;

	private float floodLevelOffset;

	private float previousGlobalTime;

	private void OnEnable()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Expected O, but got Unknown
		if (!((Object)(object)TimeOfDay.Instance == (Object)null))
		{
			((Component)this).transform.position = new Vector3(0f, TimeOfDay.Instance.currentWeatherVariable, 0f);
			TimeOfDay.Instance.onTimeSync.AddListener(new UnityAction(OnGlobalTimeSync));
		}
	}

	private void OnDisable()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		waterAudio.volume = 0f;
		floodLevelOffset = 0f;
		TimeOfDay.Instance.onTimeSync.RemoveListener(new UnityAction(OnGlobalTimeSync));
		((Component)this).transform.position = new Vector3(0f, -50f, 0f);
	}

	private void OnGlobalTimeSync()
	{
		floodLevelOffset = Mathf.Clamp(TimeOfDay.Instance.globalTime / 1080f, 0f, 100f) * TimeOfDay.Instance.currentWeatherVariable2;
	}

	private void Update()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)TimeOfDay.Instance == (Object)null)
		{
			return;
		}
		((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, new Vector3(0f, TimeOfDay.Instance.currentWeatherVariable, 0f) + Vector3.up * floodLevelOffset, 0.5f * Time.deltaTime);
		if (GameNetworkManager.Instance.localPlayerController.isInsideFactory)
		{
			waterAudio.volume = 0f;
			return;
		}
		((Component)waterAudio).transform.position = new Vector3(((Component)GameNetworkManager.Instance.localPlayerController).transform.position.x, ((Component)this).transform.position.y + 3f, ((Component)GameNetworkManager.Instance.localPlayerController).transform.position.z);
		if (Physics.Linecast(((Component)GameNetworkManager.Instance.localPlayerController.gameplayCamera).transform.position, ((Component)waterAudio).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			waterAudio.volume = Mathf.Lerp(waterAudio.volume, 0f, 0.5f * Time.deltaTime);
		}
		else
		{
			waterAudio.volume = Mathf.Lerp(waterAudio.volume, 1f, 0.5f * Time.deltaTime);
		}
	}
}
