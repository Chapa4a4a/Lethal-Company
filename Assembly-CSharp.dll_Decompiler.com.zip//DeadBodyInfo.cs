using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class DeadBodyInfo : MonoBehaviour
{
	public int playerObjectId;

	public bool setMaterialToPlayerSuit = true;

	public PlayerControllerB playerScript;

	public Rigidbody[] bodyParts;

	[Space(3f)]
	public Rigidbody attachedLimb;

	public Transform attachedTo;

	[Space(2f)]
	public Rigidbody secondaryAttachedLimb;

	public Transform secondaryAttachedTo;

	[Space(5f)]
	public int timesOutOfBounds;

	public Vector3 spawnPosition;

	[Space(3f)]
	private Vector3 forceDirection;

	public float maxVelocity;

	public float speedMultiplier;

	public bool matchPositionExactly = true;

	public bool wasMatchingPosition;

	private Rigidbody previousAttachedLimb;

	[Space(3f)]
	public bool bodyBleedingHeavily = true;

	private Vector3 previousBodyPosition;

	private int bloodAmount;

	private int maxBloodAmount = 30;

	public GameObject[] bodyBloodDecals;

	[Space(3f)]
	private bool bodyMovedThisFrame;

	private float syncBodyPositionTimer;

	private bool serverSyncedPositionWithClients;

	public bool seenByLocalPlayer;

	public AudioSource bodyAudio;

	private float velocityLastFrame;

	public Transform radarDot;

	private float timeSinceLastCollisionSFX;

	public bool parentedToShip;

	public bool detachedHead;

	public Transform detachedHeadObject;

	public Vector3 detachedHeadVelocity;

	public ParticleSystem bloodSplashParticle;

	public ParticleSystem beamUpParticle;

	public ParticleSystem beamOutParticle;

	public AudioSource playAudioOnDeath;

	public CauseOfDeath causeOfDeath;

	private float resetBodyPartsTimer;

	public GrabbableObject grabBodyObject;

	private bool bodySetToKinematic;

	public bool lerpBeforeMatchingPosition;

	private float moveToExactPositionTimer;

	public bool canBeGrabbedBackByPlayers;

	public bool isInShip;

	public bool deactivated;

	public bool overrideSpawnPosition;

	public Transform physicsParent;

	private Collider physicsParentCollider;

	public bool isParentedToPhysicsRegion;

	public Light nightVisionRadar;

	private void Awake()
	{
		Debug.Log((object)$"Body spawned with id {playerObjectId}: {((Object)((Component)this).gameObject).name}");
	}

	private void FloatBodyToWaterSurface()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < bodyParts.Length; i++)
		{
			float y = ((Component)playerScript.underwaterCollider).transform.position.y;
			Bounds bounds = playerScript.underwaterCollider.bounds;
			float num = y + ((Bounds)(ref bounds)).extents.y - ((Component)bodyParts[i]).transform.position.y;
			bodyParts[i].AddForce(-Physics.gravity * num * 5f, (ForceMode)0);
			bodyParts[i].drag = 2.5f;
			bodyParts[i].useGravity = false;
		}
	}

	private void StopFloatingBody()
	{
		playerScript.underwaterCollider = null;
		for (int i = 0; i < bodyParts.Length; i++)
		{
			bodyParts[i].drag = 0f;
			bodyParts[i].useGravity = true;
		}
	}

	private void FixedUpdate()
	{
		if (!deactivated && !wasMatchingPosition && causeOfDeath == CauseOfDeath.Drowning && (Object)(object)playerScript != (Object)null && (Object)(object)playerScript.underwaterCollider != (Object)null && !isInShip)
		{
			FloatBodyToWaterSurface();
		}
	}

	private void OnDestroy()
	{
		if ((Object)(object)grabBodyObject != (Object)null)
		{
			grabBodyObject.grabbable = false;
		}
	}

	private void Start()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		Debug.DrawRay(((Component)this).transform.position, ((Component)this).transform.up, Color.blue, 10f);
		spawnPosition = ((Component)this).transform.position;
		previousBodyPosition = Vector3.zero;
		if ((Object)(object)StartOfRound.Instance != (Object)null)
		{
			playerScript = StartOfRound.Instance.allPlayerScripts[playerObjectId];
			Debug.Log((object)$"PlayerScript set for body with id {playerObjectId} {((Object)((Component)this).gameObject).name}");
			if (setMaterialToPlayerSuit)
			{
				((Renderer)((Component)this).gameObject.GetComponentInChildren<SkinnedMeshRenderer>()).sharedMaterial = StartOfRound.Instance.unlockablesList.unlockables[playerScript.currentSuitID].suitMaterial;
				((Renderer)((Component)this).gameObject.GetComponentInChildren<SkinnedMeshRenderer>()).renderingLayerMask = 0x201u | (uint)(1 << playerObjectId + 12);
			}
			for (int i = 0; i < playerScript.bodyParts.Length; i++)
			{
				if (!overrideSpawnPosition)
				{
					bodyParts[i].position = playerScript.bodyParts[i].position;
				}
				if (playerObjectId == 0)
				{
					((Component)bodyParts[i]).gameObject.tag = "PlayerRagdoll";
				}
				else
				{
					((Component)bodyParts[i]).gameObject.tag = $"PlayerRagdoll{playerObjectId}";
				}
			}
		}
		if (detachedHead)
		{
			if ((Object)(object)RoundManager.Instance != (Object)null && (Object)(object)RoundManager.Instance.mapPropsContainer != (Object)null)
			{
				detachedHeadObject.SetParent(RoundManager.Instance.mapPropsContainer.transform);
			}
			((Component)detachedHeadObject).GetComponent<Rigidbody>().AddForce(detachedHeadVelocity * 350f, (ForceMode)1);
		}
		if ((Object)(object)bloodSplashParticle != (Object)null)
		{
			MainModule main = bloodSplashParticle.main;
			((MainModule)(ref main)).customSimulationSpace = RoundManager.Instance.mapPropsContainer.transform;
		}
		if (Object.op_Implicit((Object)(object)playAudioOnDeath))
		{
			playAudioOnDeath.Play();
			WalkieTalkie.TransmitOneShotAudio(playAudioOnDeath, playAudioOnDeath.clip);
		}
	}

	public void SetPhysicsParent(Transform setPhysicsParent, Collider physicsCollider = null)
	{
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		physicsParent = setPhysicsParent;
		if (!((Object)(object)physicsCollider == (Object)null))
		{
			return;
		}
		new List<Collider>();
		PlayerPhysicsRegion[] componentsInChildren = ((Component)physicsParent).GetComponentsInChildren<PlayerPhysicsRegion>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if ((Object)(object)componentsInChildren[i].physicsCollider == (Object)null)
			{
				Debug.LogError((object)("The player physics region '" + ((Object)((Component)componentsInChildren[i]).gameObject).name + "' is missing physicsCollider property!"));
			}
			else if (componentsInChildren[i].physicsCollider.ClosestPoint(bodyParts[5].position) == bodyParts[5].position)
			{
				physicsParentCollider = componentsInChildren[i].physicsCollider;
				break;
			}
		}
	}

	private void Update()
	{
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		if (deactivated)
		{
			isInShip = false;
			if ((Object)(object)grabBodyObject != (Object)null && grabBodyObject.grabbable)
			{
				grabBodyObject.grabbable = false;
				grabBodyObject.grabbableToEnemies = false;
				grabBodyObject.EnablePhysics(enable: false);
				((Component)((Component)this).GetComponentInChildren<ScanNodeProperties>()).GetComponent<Collider>().enabled = false;
			}
			return;
		}
		isInShip = parentedToShip || ((Object)(object)grabBodyObject != (Object)null && grabBodyObject.isHeld && (Object)(object)grabBodyObject.playerHeldBy != (Object)null && grabBodyObject.playerHeldBy.isInElevator);
		if ((Object)(object)attachedLimb != (Object)null && (Object)(object)attachedTo != (Object)null && matchPositionExactly)
		{
			syncBodyPositionTimer = 5f;
			ResetBodyPositionIfTooFarFromAttachment();
			resetBodyPartsTimer += Time.deltaTime;
			if (resetBodyPartsTimer >= 0.25f)
			{
				resetBodyPartsTimer = 0f;
				EnableCollisionOnBodyParts();
			}
		}
		if ((Object)(object)GameNetworkManager.Instance == (Object)null || (Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null)
		{
			return;
		}
		DetectIfSeenByLocalPlayer();
		DetectBodyMovedDistanceThreshold();
		if (bodyMovedThisFrame)
		{
			syncBodyPositionTimer = 5f;
			if (bodyBleedingHeavily && bloodAmount < maxBloodAmount)
			{
				bloodAmount++;
				playerScript.DropBlood(Vector3.down);
			}
		}
		if ((Object)(object)attachedLimb != (Object)null && (Object)(object)attachedTo != (Object)null)
		{
			syncBodyPositionTimer = 5f;
		}
		else if (((NetworkBehaviour)GameNetworkManager.Instance.localPlayerController).IsOwnedByServer && !serverSyncedPositionWithClients)
		{
			if (syncBodyPositionTimer >= 0f)
			{
				syncBodyPositionTimer -= Time.deltaTime;
			}
			else
			{
				if (Physics.CheckSphere(((Component)this).transform.position, 30f, StartOfRound.Instance.playersMask))
				{
					for (int i = 0; i < StartOfRound.Instance.allPlayerScripts.Length; i++)
					{
						if (StartOfRound.Instance.allPlayerScripts[i].isPlayerControlled && !Physics.Linecast(((Component)StartOfRound.Instance.allPlayerScripts[i].gameplayCamera).transform.position, ((Component)this).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault))
						{
							syncBodyPositionTimer = 0.3f;
							return;
						}
					}
				}
				serverSyncedPositionWithClients = true;
				playerScript.SyncBodyPositionWithClients();
			}
		}
		if (timeSinceLastCollisionSFX <= 0.5f)
		{
			timeSinceLastCollisionSFX += Time.deltaTime;
			return;
		}
		timeSinceLastCollisionSFX = 0f;
		Vector3 velocity = bodyParts[5].velocity;
		velocityLastFrame = ((Vector3)(ref velocity)).sqrMagnitude;
	}

	public void DetectIfSeenByLocalPlayer()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (seenByLocalPlayer)
		{
			return;
		}
		PlayerControllerB localPlayerController = GameNetworkManager.Instance.localPlayerController;
		Rigidbody val = null;
		float num = Vector3.Distance(((Component)localPlayerController.gameplayCamera).transform.position, ((Component)this).transform.position);
		for (int i = 0; i < bodyParts.Length; i++)
		{
			if ((Object)(object)bodyParts[i] == (Object)(object)val)
			{
				continue;
			}
			val = bodyParts[i];
			if (localPlayerController.HasLineOfSightToPosition(((Component)bodyParts[i]).transform.position, 30f / (num / 5f)))
			{
				if (num < 10f)
				{
					GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.9f);
				}
				else
				{
					GameNetworkManager.Instance.localPlayerController.JumpToFearLevel(0.55f);
				}
				seenByLocalPlayer = true;
				break;
			}
		}
	}

	private void LateUpdate()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_040d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		//IL_0431: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_0447: Unknown result type (might be due to invalid IL or missing references)
		//IL_0463: Unknown result type (might be due to invalid IL or missing references)
		//IL_0468: Unknown result type (might be due to invalid IL or missing references)
		//IL_046b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_0389: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03af: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04af: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04be: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0504: Unknown result type (might be due to invalid IL or missing references)
		//IL_0515: Unknown result type (might be due to invalid IL or missing references)
		//IL_051a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Unknown result type (might be due to invalid IL or missing references)
		//IL_053b: Unknown result type (might be due to invalid IL or missing references)
		//IL_053e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0549: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		if (deactivated)
		{
			((Component)radarDot).gameObject.SetActive(false);
			if (parentedToShip)
			{
				parentedToShip = false;
				((Component)this).transform.SetParent((Transform)null, true);
			}
			return;
		}
		radarDot.eulerAngles = new Vector3(0f, radarDot.eulerAngles.y, 0f);
		if ((Object)(object)attachedLimb == (Object)null || (Object)(object)attachedTo == (Object)null || (Object)(object)attachedTo.parent == (Object)(object)((Component)this).transform)
		{
			if ((Object)(object)grabBodyObject != (Object)null)
			{
				grabBodyObject.grabbable = true;
			}
			moveToExactPositionTimer = 0f;
			if (!wasMatchingPosition)
			{
				return;
			}
			wasMatchingPosition = false;
			if ((Object)(object)physicsParentCollider != (Object)null && physicsParentCollider.enabled && physicsParentCollider.ClosestPoint(bodyParts[5].position) == bodyParts[5].position)
			{
				isParentedToPhysicsRegion = true;
				((Component)this).transform.SetParent(physicsParent);
				parentedToShip = true;
				StopFloatingBody();
			}
			else
			{
				Bounds bounds = StartOfRound.Instance.shipBounds.bounds;
				if (((Bounds)(ref bounds)).Contains(((Component)this).transform.position))
				{
					((Component)this).transform.SetParent(StartOfRound.Instance.elevatorTransform);
					parentedToShip = true;
					StopFloatingBody();
					isParentedToPhysicsRegion = false;
				}
				else if (isParentedToPhysicsRegion)
				{
					isParentedToPhysicsRegion = false;
					((Component)this).transform.SetParent((Transform)null, true);
				}
			}
			previousAttachedLimb.ResetCenterOfMass();
			previousAttachedLimb.ResetInertiaTensor();
			previousAttachedLimb.freezeRotation = false;
			previousAttachedLimb.isKinematic = false;
			EnableCollisionOnBodyParts();
			return;
		}
		if ((Object)(object)grabBodyObject != (Object)null)
		{
			grabBodyObject.grabbable = canBeGrabbedBackByPlayers;
		}
		if (parentedToShip)
		{
			parentedToShip = false;
			((Component)this).transform.SetParent((Transform)null, true);
		}
		if (matchPositionExactly)
		{
			if (!lerpBeforeMatchingPosition || !(moveToExactPositionTimer < 0.3f))
			{
				if (!wasMatchingPosition)
				{
					wasMatchingPosition = true;
					Vector3 val = ((Component)this).transform.position - attachedLimb.position;
					((Component)((Component)this).transform).GetComponent<Rigidbody>().position = attachedTo.position + val;
					previousAttachedLimb = attachedLimb;
					attachedLimb.freezeRotation = true;
					attachedLimb.isKinematic = true;
					((Component)attachedLimb).transform.position = attachedTo.position;
					((Component)attachedLimb).transform.rotation = attachedTo.rotation;
					for (int i = 0; i < bodyParts.Length; i++)
					{
						bodyParts[i].angularDrag = 1f;
						bodyParts[i].maxAngularVelocity = 2f;
						bodyParts[i].maxDepenetrationVelocity = 0.3f;
						bodyParts[i].velocity = Vector3.zero;
						bodyParts[i].angularVelocity = Vector3.zero;
						bodyParts[i].WakeUp();
					}
				}
				else
				{
					attachedLimb.position = attachedTo.position;
					attachedLimb.rotation = attachedTo.rotation;
					attachedLimb.centerOfMass = Vector3.zero;
					attachedLimb.inertiaTensorRotation = Quaternion.identity;
				}
				return;
			}
			moveToExactPositionTimer += Time.deltaTime;
			speedMultiplier = 25f;
		}
		forceDirection = Vector3.Normalize(attachedTo.position - attachedLimb.position);
		attachedLimb.AddForce(forceDirection * speedMultiplier * Mathf.Clamp(Vector3.Distance(attachedTo.position, attachedLimb.position), 0.2f, 2.5f), (ForceMode)2);
		Vector3 velocity = attachedLimb.velocity;
		if (((Vector3)(ref velocity)).sqrMagnitude > maxVelocity)
		{
			Rigidbody obj = attachedLimb;
			velocity = attachedLimb.velocity;
			obj.velocity = ((Vector3)(ref velocity)).normalized * maxVelocity;
		}
		if (!((Object)(object)secondaryAttachedLimb == (Object)null) && !((Object)(object)secondaryAttachedTo == (Object)null))
		{
			forceDirection = Vector3.Normalize(secondaryAttachedTo.position - secondaryAttachedLimb.position);
			secondaryAttachedLimb.AddForce(forceDirection * speedMultiplier * Mathf.Clamp(Vector3.Distance(secondaryAttachedTo.position, secondaryAttachedLimb.position), 0.2f, 2.5f), (ForceMode)2);
			velocity = secondaryAttachedLimb.velocity;
			if (((Vector3)(ref velocity)).sqrMagnitude > maxVelocity)
			{
				Rigidbody obj2 = secondaryAttachedLimb;
				velocity = secondaryAttachedLimb.velocity;
				obj2.velocity = ((Vector3)(ref velocity)).normalized * maxVelocity;
			}
		}
	}

	private void DetectBodyMovedDistanceThreshold()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		bodyMovedThisFrame = false;
		if (isInShip)
		{
			if (Vector3.Distance(previousBodyPosition, ((Component)this).transform.localPosition) > 1f)
			{
				previousBodyPosition = ((Component)this).transform.localPosition;
				bodyMovedThisFrame = true;
			}
		}
		else if (Vector3.Distance(previousBodyPosition, ((Component)this).transform.position) > 1f)
		{
			previousBodyPosition = ((Component)this).transform.position;
			bodyMovedThisFrame = true;
		}
	}

	private void ResetBodyPositionIfTooFarFromAttachment()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < bodyParts.Length; i++)
		{
			if (Vector3.Distance(bodyParts[i].position, attachedTo.position) > 4f)
			{
				resetBodyPartsTimer = 0f;
				((Component)bodyParts[i]).GetComponent<Collider>().enabled = false;
			}
		}
	}

	private void EnableCollisionOnBodyParts()
	{
		for (int i = 0; i < bodyParts.Length; i++)
		{
			((Component)bodyParts[i]).GetComponent<Collider>().enabled = true;
		}
	}

	public void MakeCorpseBloody()
	{
		for (int i = 0; i < bodyBloodDecals.Length; i++)
		{
			bodyBloodDecals[i].SetActive(true);
		}
	}

	public void SetBodyPartsKinematic(bool setKinematic = true)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		if (setKinematic)
		{
			bodySetToKinematic = true;
			for (int i = 0; i < bodyParts.Length; i++)
			{
				bodyParts[i].velocity = Vector3.zero;
				bodyParts[i].isKinematic = true;
			}
			return;
		}
		for (int j = 0; j < bodyParts.Length; j++)
		{
			bodyParts[j].velocity = Vector3.zero;
			if (!((Object)(object)bodyParts[j] == (Object)(object)attachedLimb) || !matchPositionExactly)
			{
				bodyParts[j].isKinematic = false;
			}
		}
	}

	public void DeactivateBody(bool setActive)
	{
		((Component)this).gameObject.SetActive(setActive);
		SetBodyPartsKinematic();
		isInShip = false;
		deactivated = true;
	}

	public void ResetRagdollPosition()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)attachedLimb != (Object)null && (Object)(object)attachedTo != (Object)null)
		{
			((Component)this).transform.position = attachedTo.position + Vector3.up * 2f;
		}
		else
		{
			((Component)this).transform.position = spawnPosition;
		}
		for (int i = 0; i < bodyParts.Length; i++)
		{
			bodyParts[i].velocity = Vector3.zero;
		}
	}

	public void SetRagdollPositionSafely(Vector3 newPosition, bool disableSpecialEffects = false)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.position = newPosition + Vector3.up * 2.5f;
		if (disableSpecialEffects)
		{
			StopFloatingBody();
		}
		for (int i = 0; i < bodyParts.Length; i++)
		{
			bodyParts[i].velocity = Vector3.zero;
		}
		timeSinceLastCollisionSFX = -1f;
	}

	public void AddForceToBodyPart(int bodyPartIndex, Vector3 force)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		bodyParts[bodyPartIndex].AddForce(force, (ForceMode)1);
	}

	public void ChangeMesh(Mesh changeMesh, Material changeMaterial = null)
	{
		((Component)this).gameObject.GetComponentInChildren<SkinnedMeshRenderer>().sharedMesh = changeMesh;
		if ((Object)(object)changeMaterial != (Object)null)
		{
			((Renderer)((Component)this).gameObject.GetComponentInChildren<SkinnedMeshRenderer>()).sharedMaterial = changeMaterial;
		}
	}
}
