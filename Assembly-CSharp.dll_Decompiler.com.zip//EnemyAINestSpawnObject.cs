using UnityEngine;

public class EnemyAINestSpawnObject : MonoBehaviour
{
	public EnemyType enemyType;

	public Transform[] nestPositions;
}
