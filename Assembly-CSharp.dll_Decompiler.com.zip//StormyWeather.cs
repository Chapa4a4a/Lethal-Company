using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using DigitalRuby.ThunderAndLightning;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;

public class StormyWeather : MonoBehaviour
{
	private float randomThunderTime;

	private float timeAtLastStrike;

	private Vector3 lastRandomStrikePosition;

	private Random seed;

	public AudioClip[] strikeSFX;

	public AudioClip[] distantThunderSFX;

	public LightningBoltPrefabScript randomThunder;

	public LightningBoltPrefabScript targetedThunder;

	public AudioSource randomStrikeAudio;

	public AudioSource randomStrikeAudioB;

	private bool lastStrikeAudioUsed;

	public AudioSource targetedStrikeAudio;

	private RaycastHit rayHit;

	private GameObject[] outsideNodes;

	private NavMeshHit navHit;

	public ParticleSystem explosionEffectParticle;

	private List<GrabbableObject> metalObjects = new List<GrabbableObject>();

	private GrabbableObject targetingMetalObject;

	private float getObjectToTargetInterval;

	private float strikeMetalObjectTimer;

	private bool hasShownStrikeWarning;

	public ParticleSystem staticElectricityParticle;

	private GameObject setStaticToObject;

	private GrabbableObject setStaticGrabbableObject;

	public AudioClip staticElectricityAudio;

	private float lastGlobalTimeUsed;

	private float globalTimeAtLastStrike;

	private Random targetedThunderRandom;

	private void OnEnable()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		TimeOfDay.Instance.onTimeSync.AddListener(new UnityAction(OnGlobalTimeSync));
		BeginDay();
	}

	private void OnDisable()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		TimeOfDay.Instance.onTimeSync.RemoveListener(new UnityAction(OnGlobalTimeSync));
	}

	public void BeginDay()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		lastRandomStrikePosition = Vector3.zero;
		targetedThunderRandom = new Random(StartOfRound.Instance.randomMapSeed);
		globalTimeAtLastStrike = TimeOfDay.Instance.globalTime;
		lastGlobalTimeUsed = 0f;
		randomThunderTime = TimeOfDay.Instance.globalTime + 7f;
		timeAtLastStrike = TimeOfDay.Instance.globalTime;
		navHit = default(NavMeshHit);
		outsideNodes = (from x in GameObject.FindGameObjectsWithTag("OutsideAINode")
			orderby x.transform.position.x + x.transform.position.z
			select x).ToArray();
		if (((Behaviour)StartOfRound.Instance.spectateCamera).enabled)
		{
			SwitchCamera(StartOfRound.Instance.spectateCamera);
		}
		else
		{
			SwitchCamera(GameNetworkManager.Instance.localPlayerController.gameplayCamera);
		}
		seed = new Random(StartOfRound.Instance.randomMapSeed);
		DetermineNextStrikeInterval();
		((MonoBehaviour)this).StartCoroutine(GetMetalObjectsAfterDelay());
	}

	private void OnGlobalTimeSync()
	{
		float num = RoundUpToNearestTen(TimeOfDay.Instance.globalTime);
		if (num != lastGlobalTimeUsed)
		{
			lastGlobalTimeUsed = num;
			seed = new Random((int)num + StartOfRound.Instance.randomMapSeed);
			timeAtLastStrike = TimeOfDay.Instance.globalTime;
		}
	}

	private IEnumerator GetMetalObjectsAfterDelay()
	{
		yield return (object)new WaitForSeconds(15f);
		GrabbableObject[] array = Object.FindObjectsOfType<GrabbableObject>();
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].itemProperties.isConductiveMetal)
			{
				metalObjects.Add(array[i]);
			}
		}
	}

	public void SwitchCamera(Camera newCamera)
	{
		randomThunder.Camera = newCamera;
		targetedThunder.Camera = newCamera;
	}

	private void DetermineNextStrikeInterval()
	{
		timeAtLastStrike = randomThunderTime;
		float num = seed.Next(-5, 110);
		randomThunderTime += Mathf.Clamp(num * 0.25f, 0.6f, 110f) / Mathf.Clamp(TimeOfDay.Instance.currentWeatherVariable, 1f, 100f);
	}

	private int RoundUpToNearestTen(float x)
	{
		return (int)(x / 10f) * 10;
	}

	private void Update()
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		if (!((Component)this).gameObject.activeInHierarchy)
		{
			return;
		}
		if (TimeOfDay.Instance.globalTime > randomThunderTime)
		{
			LightningStrikeRandom();
			DetermineNextStrikeInterval();
		}
		if ((Object)(object)setStaticToObject != (Object)null && (Object)(object)setStaticGrabbableObject != (Object)null)
		{
			if (setStaticGrabbableObject.isInFactory || setStaticGrabbableObject.targetFloorPosition.x == 3000f)
			{
				staticElectricityParticle.Stop();
			}
			((Component)staticElectricityParticle).transform.position = setStaticToObject.transform.position;
		}
		if (!((NetworkBehaviour)RoundManager.Instance).IsOwner)
		{
			return;
		}
		if ((Object)(object)targetingMetalObject == (Object)null)
		{
			if (metalObjects.Count <= 0)
			{
				return;
			}
			if (getObjectToTargetInterval <= 4f)
			{
				getObjectToTargetInterval += Time.deltaTime;
				return;
			}
			hasShownStrikeWarning = false;
			strikeMetalObjectTimer = Mathf.Clamp(Random.Range(1f, 28f), 0f, 20f);
			getObjectToTargetInterval = 0f;
			float num = 1000f;
			for (int i = 0; i < metalObjects.Count; i++)
			{
				if ((Object)(object)metalObjects[i] == (Object)null)
				{
					metalObjects.RemoveAt(i);
				}
				else
				{
					if (metalObjects[i].isInFactory || metalObjects[i].targetFloorPosition.x == 3000f || metalObjects[i].isInShipRoom)
					{
						continue;
					}
					for (int j = 0; j < StartOfRound.Instance.allPlayerScripts.Length; j++)
					{
						if (StartOfRound.Instance.allPlayerScripts[j].isPlayerControlled)
						{
							float num2 = Vector3.Distance(((Component)metalObjects[i]).transform.position, ((Component)StartOfRound.Instance.allPlayerScripts[j]).transform.position);
							if (num2 < num)
							{
								targetingMetalObject = metalObjects[i];
								num = num2;
								break;
							}
						}
					}
					if (Random.Range(0, 100) < 20)
					{
						break;
					}
				}
			}
			if ((Object)(object)targetingMetalObject != (Object)null && targetingMetalObject.isHeld)
			{
				strikeMetalObjectTimer = Mathf.Clamp(strikeMetalObjectTimer + Time.deltaTime, 4f, 20f);
			}
			return;
		}
		strikeMetalObjectTimer -= Time.deltaTime;
		if (strikeMetalObjectTimer <= 0f)
		{
			if (!targetingMetalObject.isInFactory && targetingMetalObject.targetFloorPosition.x != 3000f)
			{
				RoundManager.Instance.LightningStrikeServerRpc(((Component)targetingMetalObject).transform.position);
			}
			getObjectToTargetInterval = 5f;
			targetingMetalObject = null;
		}
		else if (strikeMetalObjectTimer < 10f && !hasShownStrikeWarning)
		{
			hasShownStrikeWarning = true;
			float timeLeft = Mathf.Abs(strikeMetalObjectTimer - 10f);
			RoundManager.Instance.ShowStaticElectricityWarningServerRpc(NetworkObjectReference.op_Implicit(((Component)targetingMetalObject).gameObject.GetComponent<NetworkObject>()), timeLeft);
		}
	}

	public void SetStaticElectricityWarning(NetworkObject warningObject, float particleTime)
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		setStaticToObject = ((Component)warningObject).gameObject;
		GrabbableObject component = ((Component)warningObject).gameObject.GetComponent<GrabbableObject>();
		if ((Object)(object)component != (Object)null)
		{
			setStaticGrabbableObject = ((Component)warningObject).gameObject.GetComponent<GrabbableObject>();
			for (int i = 0; i < GameNetworkManager.Instance.localPlayerController.ItemSlots.Length; i++)
			{
				if ((Object)(object)GameNetworkManager.Instance.localPlayerController.ItemSlots[i] == (Object)(object)component)
				{
					HUDManager.Instance.DisplayTip("ALERT!", "Drop your metallic items now! A static charge has been detected. You have seconds left to live.", isWarning: true, useSave: true, "LC_LightningTip");
				}
			}
		}
		ShapeModule shape = staticElectricityParticle.shape;
		((ShapeModule)(ref shape)).meshRenderer = setStaticToObject.GetComponentInChildren<MeshRenderer>();
		staticElectricityParticle.time = particleTime;
		staticElectricityParticle.Play();
		staticElectricityParticle.time = particleTime;
		((Component)staticElectricityParticle).gameObject.GetComponent<AudioSource>().clip = staticElectricityAudio;
		((Component)staticElectricityParticle).gameObject.GetComponent<AudioSource>().Play();
		((Component)staticElectricityParticle).gameObject.GetComponent<AudioSource>().time = particleTime;
	}

	private void LightningStrikeRandom()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		Vector3 randomNavMeshPositionInBoxPredictable;
		if (seed.Next(0, 100) < 60 && (randomThunderTime - timeAtLastStrike) * TimeOfDay.Instance.currentWeatherVariable < 3f)
		{
			randomNavMeshPositionInBoxPredictable = lastRandomStrikePosition;
		}
		else
		{
			int num = seed.Next(0, outsideNodes.Length);
			if (outsideNodes == null || (Object)(object)outsideNodes[num] == (Object)null)
			{
				outsideNodes = (from x in GameObject.FindGameObjectsWithTag("OutsideAINode")
					orderby x.transform.position.x + x.transform.position.z
					select x).ToArray();
				num = seed.Next(0, outsideNodes.Length);
			}
			randomNavMeshPositionInBoxPredictable = outsideNodes[num].transform.position;
			randomNavMeshPositionInBoxPredictable = RoundManager.Instance.GetRandomNavMeshPositionInBoxPredictable(randomNavMeshPositionInBoxPredictable, 15f, navHit, seed);
		}
		lastRandomStrikePosition = randomNavMeshPositionInBoxPredictable;
		LightningStrike(randomNavMeshPositionInBoxPredictable, useTargetedObject: false);
	}

	public void LightningStrike(Vector3 strikePosition, bool useTargetedObject)
	{
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		Random random;
		AudioSource val;
		LightningBoltPrefabScript lightningBoltPrefabScript;
		if (useTargetedObject)
		{
			random = targetedThunderRandom;
			staticElectricityParticle.Stop();
			((Component)staticElectricityParticle).GetComponent<AudioSource>().Stop();
			setStaticToObject = null;
			val = targetedStrikeAudio;
			lightningBoltPrefabScript = targetedThunder;
		}
		else
		{
			random = new Random(seed.Next(0, 10000));
			val = ((!lastStrikeAudioUsed) ? randomStrikeAudio : randomStrikeAudioB);
			lastStrikeAudioUsed = !lastStrikeAudioUsed;
			lightningBoltPrefabScript = randomThunder;
		}
		bool flag = false;
		Vector3 val2 = Vector3.zero;
		for (int i = 0; i < 7; i++)
		{
			if (i == 6)
			{
				val2 = strikePosition + Vector3.up * 80f;
			}
			else
			{
				float num = random.Next(-32, 32);
				float num2 = random.Next(-32, 32);
				val2 = strikePosition + Vector3.up * 80f + new Vector3(num, 0f, num2);
			}
			if (!Physics.Linecast(val2, strikePosition + Vector3.up * 0.5f, ref rayHit, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			if (!Physics.Raycast(val2, strikePosition - val2, ref rayHit, 100f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				return;
			}
			strikePosition = ((RaycastHit)(ref rayHit)).point;
		}
		Debug.DrawLine(val2, strikePosition, Color.red, 10f);
		lightningBoltPrefabScript.Source.transform.position = val2;
		lightningBoltPrefabScript.Destination.transform.position = strikePosition;
		lightningBoltPrefabScript.AutomaticModeSeconds = 0.2f;
		((Component)val).transform.position = strikePosition + Vector3.up * 0.5f;
		Landmine.SpawnExplosion(strikePosition + Vector3.up * 0.25f, spawnExplosionEffect: false, 2.4f, 5f);
		((Component)explosionEffectParticle).transform.position = strikePosition + Vector3.up * 0.25f;
		explosionEffectParticle.Play();
		PlayThunderEffects(strikePosition, val);
	}

	private void PlayThunderEffects(Vector3 strikePosition, AudioSource audio)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB playerControllerB = GameNetworkManager.Instance.localPlayerController;
		if (playerControllerB.isPlayerDead && (Object)(object)playerControllerB.spectatedPlayerScript != (Object)null)
		{
			playerControllerB = playerControllerB.spectatedPlayerScript;
		}
		float num = Vector3.Distance(((Component)playerControllerB.gameplayCamera).transform.position, strikePosition);
		bool flag = false;
		if (num < 40f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
		}
		else if (num < 110f)
		{
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
		}
		else
		{
			flag = true;
		}
		AudioClip[] array = ((!flag) ? strikeSFX : distantThunderSFX);
		if (!playerControllerB.isInsideFactory)
		{
			RoundManager.PlayRandomClip(audio, array);
		}
		WalkieTalkie.TransmitOneShotAudio(audio, array[Random.Range(0, array.Length)]);
		Bounds bounds = StartOfRound.Instance.shipBounds.bounds;
		if (((Bounds)(ref bounds)).Contains(strikePosition))
		{
			((Component)StartOfRound.Instance.shipAnimatorObject).GetComponent<Animator>().SetTrigger("shipShake");
			RoundManager.PlayRandomClip(StartOfRound.Instance.ship3DAudio, StartOfRound.Instance.shipCreakSFX, randomize: false);
			StartOfRound.Instance.PowerSurgeShip();
		}
	}
}
