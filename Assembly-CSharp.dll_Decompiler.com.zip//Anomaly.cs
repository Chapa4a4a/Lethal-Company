using Unity.Netcode;
using UnityEngine;

public abstract class Anomaly : NetworkBehaviour
{
	public AnomalyType anomalyType;

	public float initialInstability = 10f;

	public float difficultyMultiplier;

	public float normalizedHealth;

	public NetworkObject thisNetworkObject;

	public float maxHealth;

	[HideInInspector]
	public float health;

	[HideInInspector]
	public float removingHealth;

	[HideInInspector]
	public float usedInstability;

	public RoundManager roundManager;

	[Header("Misc properties")]
	public bool raycastToSurface;

	private bool addingInstability;

	public virtual void Start()
	{
		roundManager = Object.FindObjectOfType<RoundManager>(false);
		thisNetworkObject = ((Component)this).gameObject.GetComponent<NetworkObject>();
		addingInstability = true;
		_ = roundManager.hasInitializedLevelRandomSeed;
	}

	public virtual void AnomalyDespawn(bool removedByPatcher = false)
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			DespawnAnomalyServerRpc();
			return;
		}
		addingInstability = false;
		((Component)this).gameObject.GetComponent<NetworkObject>().Despawn(true);
		roundManager.SpawnedAnomalies.Remove(this);
		roundManager.SpawnedAnomalies.TrimExcess();
	}

	[ServerRpc(RequireOwnership = false)]
	public void DespawnAnomalyServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3450772816u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3450772816u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && ((Component)this).gameObject.GetComponent<NetworkObject>().IsSpawned)
			{
				AnomalyDespawn();
			}
		}
	}

	public virtual void Update()
	{
		if (removingHealth > 0f)
		{
			health -= removingHealth * Time.deltaTime;
			if (((NetworkBehaviour)this).IsServer && health <= 0f)
			{
				AnomalyDespawn(removedByPatcher: true);
			}
		}
		else
		{
			health = Mathf.Clamp(health += Time.deltaTime * 1.5f, anomalyType.anomalyMaxHealth / 3f, anomalyType.anomalyMaxHealth);
			if (((NetworkBehaviour)this).IsServer && addingInstability)
			{
				if (usedInstability <= initialInstability)
				{
					usedInstability += Time.deltaTime;
				}
				else
				{
					usedInstability += Time.deltaTime / 3f;
				}
			}
		}
		normalizedHealth = Mathf.Abs(anomalyType.anomalyMaxHealth / health - 1f);
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_Anomaly()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3450772816u, new RpcReceiveHandler(__rpc_handler_3450772816));
	}

	private static void __rpc_handler_3450772816(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((Anomaly)(object)target).DespawnAnomalyServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "Anomaly";
	}
}
