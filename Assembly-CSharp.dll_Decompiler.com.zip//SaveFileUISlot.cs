using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SaveFileUISlot : MonoBehaviour
{
	public Button fileButton;

	public Animator buttonAnimator;

	public TextMeshProUGUI fileStatsText;

	public int fileNum;

	private string fileString;

	public TextMeshProUGUI fileNotCompatibleAlert;

	public TextMeshProUGUI specialTipText;

	public TextMeshProUGUI fileNameText;

	private void Awake()
	{
		switch (fileNum)
		{
		case -1:
			fileString = "LCChallengeFile";
			break;
		case 0:
			fileString = "LCSaveFile1";
			break;
		case 1:
			fileString = "LCSaveFile2";
			break;
		case 2:
			fileString = "LCSaveFile3";
			break;
		default:
			fileString = "LCSaveFile1";
			break;
		}
	}

	private void SetChallengeFileSettings()
	{
		if (Object.FindObjectOfType<MenuManager>().hasChallengeBeenCompleted)
		{
			int num = ES3.Load<int>("ProfitEarned", fileString, 0);
			Debug.Log((object)ES3.Load<int>("ProfitEarned", fileString, 0));
			Debug.Log((object)$"scrapEarnedInFile: {num}");
			((Behaviour)fileStatsText).enabled = true;
			((TMP_Text)fileStatsText).text = $"${num} Collected";
			if (GameNetworkManager.Instance.currentSaveFileName == "LCChallengeFile")
			{
				GameNetworkManager.Instance.currentSaveFileName = "LCSaveFile1";
				GameNetworkManager.Instance.saveFileNum = 0;
				SetButtonColorForAllFileSlots();
			}
		}
		else
		{
			((Behaviour)fileStatsText).enabled = false;
		}
	}

	private void OnEnable()
	{
		if (fileNum == -1)
		{
			((TMP_Text)fileNameText).text = GameNetworkManager.Instance.GetNameForWeekNumber();
		}
		if (ES3.FileExists(fileString))
		{
			if (fileNum == -1)
			{
				SetChallengeFileSettings();
			}
			else
			{
				int num = ES3.Load<int>("GroupCredits", fileString, 0);
				int num2 = ES3.Load<int>("Stats_DaysSpent", fileString, 0);
				((TMP_Text)fileStatsText).text = $"${num}\nDays: {num2}";
			}
		}
		else
		{
			((TMP_Text)fileStatsText).text = "";
		}
		if (fileNum != -1 && !Object.FindObjectOfType<MenuManager>().filesCompatible[fileNum])
		{
			((Behaviour)fileNotCompatibleAlert).enabled = true;
		}
	}

	public void SetButtonColor()
	{
		buttonAnimator.SetBool("isPressed", GameNetworkManager.Instance.currentSaveFileName == fileString);
		if ((Object)(object)specialTipText != (Object)null && GameNetworkManager.Instance.currentSaveFileName != fileString)
		{
			((Behaviour)specialTipText).enabled = false;
		}
	}

	public void SetFileToThis()
	{
		if (Object.FindObjectOfType<MenuManager>().requestingLeaderboard)
		{
			return;
		}
		if (fileNum == -1 && Object.FindObjectOfType<MenuManager>().hasChallengeBeenCompleted)
		{
			Object.FindObjectOfType<MenuManager>().EnableLeaderboardDisplay(enable: true);
		}
		else
		{
			Object.FindObjectOfType<MenuManager>().EnableLeaderboardDisplay(enable: false);
			if (fileNum == -1)
			{
				((TMP_Text)specialTipText).text = "This is the weekly challenge moon. You have one day to make as much profit as possible.";
				((Behaviour)specialTipText).enabled = true;
			}
		}
		GameNetworkManager.Instance.currentSaveFileName = fileString;
		GameNetworkManager.Instance.saveFileNum = fileNum;
		SetButtonColorForAllFileSlots();
	}

	public void SetButtonColorForAllFileSlots()
	{
		SaveFileUISlot[] array = Object.FindObjectsOfType<SaveFileUISlot>();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetButtonColor();
		}
	}
}
