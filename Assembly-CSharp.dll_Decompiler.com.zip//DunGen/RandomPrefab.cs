using UnityEngine;

namespace DunGen;

[AddComponentMenu("DunGen/Random Props/Random Prefab")]
public class RandomPrefab : RandomProp
{
	[AcceptGameObjectTypes(GameObjectFilter.Asset)]
	public GameObjectChanceTable Props = new GameObjectChanceTable();

	public bool ZeroPosition = true;

	public bool ZeroRotation = true;

	public override void Process(RandomStream randomStream, Tile tile)
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		if (Props.Weights.Count > 0)
		{
			GameObject value = Props.GetRandom(randomStream, tile.Placement.IsOnMainPath, tile.Placement.NormalizedDepth, null, allowImmediateRepeats: true, removeFromTable: true).Value;
			GameObject val = Object.Instantiate<GameObject>(value);
			val.transform.parent = ((Component)this).transform;
			if (ZeroPosition)
			{
				val.transform.localPosition = Vector3.zero;
			}
			else
			{
				val.transform.localPosition = value.transform.localPosition;
			}
			if (ZeroRotation)
			{
				val.transform.localRotation = Quaternion.identity;
			}
			else
			{
				val.transform.localRotation = value.transform.localRotation;
			}
		}
	}
}
