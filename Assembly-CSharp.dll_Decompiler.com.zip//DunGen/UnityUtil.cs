using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace DunGen;

public static class UnityUtil
{
	public static Type ProBuilderMeshType { get; private set; }

	public static PropertyInfo ProBuilderPositionsProperty { get; private set; }

	static UnityUtil()
	{
		FindProBuilderObjectType();
	}

	public static void FindProBuilderObjectType()
	{
		if (ProBuilderMeshType != null)
		{
			return;
		}
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			if (!assembly.FullName.Contains("ProBuilder"))
			{
				continue;
			}
			ProBuilderMeshType = assembly.GetType("UnityEngine.ProBuilder.ProBuilderMesh");
			if (ProBuilderMeshType != null)
			{
				ProBuilderPositionsProperty = ProBuilderMeshType.GetProperty("positions");
				if (ProBuilderPositionsProperty != null)
				{
					break;
				}
			}
		}
	}

	public static void Restart(this Stopwatch stopwatch)
	{
		if (stopwatch == null)
		{
			stopwatch = Stopwatch.StartNew();
			return;
		}
		stopwatch.Reset();
		stopwatch.Start();
	}

	public static bool Contains(this Bounds bounds, Bounds other)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		if (((Bounds)(ref other)).min.x < ((Bounds)(ref bounds)).min.x || ((Bounds)(ref other)).min.y < ((Bounds)(ref bounds)).min.y || ((Bounds)(ref other)).min.z < ((Bounds)(ref bounds)).min.z || ((Bounds)(ref other)).max.x > ((Bounds)(ref bounds)).max.x || ((Bounds)(ref other)).max.y > ((Bounds)(ref bounds)).max.y || ((Bounds)(ref other)).max.z > ((Bounds)(ref bounds)).max.z)
		{
			return false;
		}
		return true;
	}

	public static Bounds TransformBounds(this Transform transform, Bounds localBounds)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = transform.TransformPoint(((Bounds)(ref localBounds)).center);
		Vector3 val2 = transform.rotation * ((Bounds)(ref localBounds)).size;
		val2.x = Mathf.Abs(val2.x);
		val2.y = Mathf.Abs(val2.y);
		val2.z = Mathf.Abs(val2.z);
		return new Bounds(val, val2);
	}

	public static Bounds InverseTransformBounds(this Transform transform, Bounds worldBounds)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = transform.InverseTransformPoint(((Bounds)(ref worldBounds)).center);
		Vector3 val2 = Quaternion.Inverse(transform.rotation) * ((Bounds)(ref worldBounds)).size;
		val2.x = Mathf.Abs(val2.x);
		val2.y = Mathf.Abs(val2.y);
		val2.z = Mathf.Abs(val2.z);
		return new Bounds(val, val2);
	}

	public static void SetLayerRecursive(GameObject gameObject, int layer)
	{
		gameObject.layer = layer;
		for (int i = 0; i < gameObject.transform.childCount; i++)
		{
			SetLayerRecursive(((Component)gameObject.transform.GetChild(i)).gameObject, layer);
		}
	}

	public static void Destroy(Object obj)
	{
		if (Application.isPlaying)
		{
			GameObject val = (GameObject)(object)((obj is GameObject) ? obj : null);
			if ((Object)(object)val != (Object)null)
			{
				val.SetActive(false);
			}
			Object.Destroy(obj);
		}
		else
		{
			Object.DestroyImmediate(obj);
		}
	}

	public static string GetUniqueName(string name, IEnumerable<string> usedNames)
	{
		if (string.IsNullOrEmpty(name))
		{
			return GetUniqueName("New", usedNames);
		}
		string text = name;
		int result = 0;
		bool flag = false;
		int num = name.LastIndexOf(' ');
		if (num > -1)
		{
			text = name.Substring(0, num);
			flag = int.TryParse(name.Substring(num + 1), out result);
			result++;
		}
		foreach (string usedName in usedNames)
		{
			if (usedName == name)
			{
				if (flag)
				{
					return GetUniqueName(text + " " + result, usedNames);
				}
				return GetUniqueName(name + " 2", usedNames);
			}
		}
		return name;
	}

	public static Bounds CombineBounds(params Bounds[] bounds)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (bounds.Length == 0)
		{
			return default(Bounds);
		}
		if (bounds.Length == 1)
		{
			return bounds[0];
		}
		Bounds result = bounds[0];
		for (int i = 1; i < bounds.Length; i++)
		{
			((Bounds)(ref result)).Encapsulate(bounds[i]);
		}
		return result;
	}

	public static Bounds CalculateProxyBounds(GameObject prefab, bool ignoreSpriteRendererBounds, Vector3 upVector)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		Bounds result = CalculateObjectBounds(prefab, includeInactive: true, ignoreSpriteRendererBounds);
		if (ProBuilderMeshType != null && ProBuilderPositionsProperty != null)
		{
			Component[] componentsInChildren = prefab.GetComponentsInChildren(ProBuilderMeshType);
			Vector3 val = default(Vector3);
			Vector3 val2 = default(Vector3);
			foreach (Component obj in componentsInChildren)
			{
				((Vector3)(ref val))._002Ector(float.MaxValue, float.MaxValue, float.MaxValue);
				((Vector3)(ref val2))._002Ector(float.MinValue, float.MinValue, float.MinValue);
				foreach (Vector3 item in (IList<Vector3>)ProBuilderPositionsProperty.GetValue(obj, null))
				{
					val = Vector3.Min(val, item);
					val2 = Vector3.Max(val2, item);
				}
				Vector3 val3 = prefab.transform.TransformDirection(val2 - val);
				Vector3 val4 = prefab.transform.TransformPoint(val) + val3 / 2f;
				((Bounds)(ref result)).Encapsulate(new Bounds(val4, val3));
			}
		}
		return result;
	}

	public static Bounds CalculateObjectBounds(GameObject obj, bool includeInactive, bool ignoreSpriteRenderers, bool ignoreTriggerColliders = true)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		Bounds result = default(Bounds);
		bool flag = false;
		Tilemap[] componentsInChildren = obj.GetComponentsInChildren<Tilemap>(includeInactive);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].CompressBounds();
		}
		Renderer[] componentsInChildren2 = obj.GetComponentsInChildren<Renderer>(includeInactive);
		foreach (Renderer val in componentsInChildren2)
		{
			if ((!ignoreSpriteRenderers || !(val is SpriteRenderer)) && !(val is ParticleSystemRenderer))
			{
				if (flag)
				{
					((Bounds)(ref result)).Encapsulate(val.bounds);
				}
				else
				{
					result = val.bounds;
				}
				flag = true;
			}
		}
		Collider[] componentsInChildren3 = obj.GetComponentsInChildren<Collider>(includeInactive);
		foreach (Collider val2 in componentsInChildren3)
		{
			if (!ignoreTriggerColliders || !val2.isTrigger)
			{
				if (flag)
				{
					((Bounds)(ref result)).Encapsulate(val2.bounds);
				}
				else
				{
					result = val2.bounds;
				}
				flag = true;
			}
		}
		Vector3 extents = ((Bounds)(ref result)).extents;
		if (extents.x == 0f)
		{
			extents.x = 0.01f;
		}
		else if (extents.x < 0f)
		{
			extents.x *= -1f;
		}
		if (extents.y == 0f)
		{
			extents.y = 0.01f;
		}
		else if (extents.y < 0f)
		{
			extents.y *= -1f;
		}
		if (extents.z == 0f)
		{
			extents.z = 0.01f;
		}
		else if (extents.z < 0f)
		{
			extents.z *= -1f;
		}
		((Bounds)(ref result)).extents = extents;
		return result;
	}

	public static void PositionObjectBySocket(GameObject objectA, GameObject socketA, GameObject socketB)
	{
		PositionObjectBySocket(objectA.transform, socketA.transform, socketB.transform);
	}

	public static void PositionObjectBySocket(Transform objectA, Transform socketA, Transform socketB)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		Quaternion val = Quaternion.LookRotation(-socketB.forward, socketB.up);
		objectA.rotation = val * Quaternion.Inverse(Quaternion.Inverse(objectA.rotation) * socketA.rotation);
		Vector3 position = socketB.position;
		objectA.position = position - (socketA.position - objectA.position);
	}

	public static Vector3 GetCardinalDirection(Vector3 direction, out float magnitude)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		float num = Math.Abs(direction.x);
		float num2 = Math.Abs(direction.y);
		float num3 = Math.Abs(direction.z);
		float num4 = direction.x / num;
		float num5 = direction.y / num2;
		float num6 = direction.z / num3;
		if (num > num2 && num > num3)
		{
			magnitude = num4;
			return new Vector3(num4, 0f, 0f);
		}
		if (num2 > num && num2 > num3)
		{
			magnitude = num5;
			return new Vector3(0f, num5, 0f);
		}
		if (num3 > num && num3 > num2)
		{
			magnitude = num6;
			return new Vector3(0f, 0f, num6);
		}
		magnitude = num4;
		return new Vector3(num4, 0f, 0f);
	}

	public static Vector3 VectorAbs(Vector3 vector)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		return new Vector3(Math.Abs(vector.x), Math.Abs(vector.y), Math.Abs(vector.z));
	}

	public static void SetVector3Masked(ref Vector3 input, Vector3 value, Vector3 mask)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (mask.x != 0f)
		{
			input.x = value.x;
		}
		if (mask.y != 0f)
		{
			input.y = value.y;
		}
		if (mask.z != 0f)
		{
			input.z = value.z;
		}
	}

	public static Bounds CondenseBounds(Bounds bounds, IEnumerable<Doorway> doorways)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		Vector3 input = ((Bounds)(ref bounds)).center - ((Bounds)(ref bounds)).extents;
		Vector3 input2 = ((Bounds)(ref bounds)).center + ((Bounds)(ref bounds)).extents;
		foreach (Doorway doorway in doorways)
		{
			float magnitude;
			Vector3 cardinalDirection = GetCardinalDirection(((Component)doorway).transform.forward, out magnitude);
			if (magnitude < 0f)
			{
				SetVector3Masked(ref input, ((Component)doorway).transform.position, cardinalDirection);
			}
			else
			{
				SetVector3Masked(ref input2, ((Component)doorway).transform.position, cardinalDirection);
			}
		}
		Vector3 val = input2 - input;
		return new Bounds(input + val / 2f, val);
	}

	public static IEnumerable<T> GetComponentsInParents<T>(GameObject obj, bool includeInactive = false) where T : Component
	{
		if (obj.activeSelf || includeInactive)
		{
			T[] components = obj.GetComponents<T>();
			for (int i = 0; i < components.Length; i++)
			{
				yield return components[i];
			}
		}
		if (!((Object)(object)obj.transform.parent != (Object)null))
		{
			yield break;
		}
		foreach (T componentsInParent in GetComponentsInParents<T>(((Component)obj.transform.parent).gameObject, includeInactive))
		{
			yield return componentsInParent;
		}
	}

	public static T GetComponentInParents<T>(GameObject obj, bool includeInactive = false) where T : Component
	{
		if (obj.activeSelf || includeInactive)
		{
			T[] components = obj.GetComponents<T>();
			int num = 0;
			if (num < components.Length)
			{
				return components[num];
			}
		}
		if ((Object)(object)obj.transform.parent != (Object)null)
		{
			return GetComponentInParents<T>(((Component)obj.transform.parent).gameObject, includeInactive);
		}
		return default(T);
	}

	public static float CalculateOverlap(Bounds boundsA, Bounds boundsB)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		float num = ((Bounds)(ref boundsA)).max.x - ((Bounds)(ref boundsB)).min.x;
		float num2 = ((Bounds)(ref boundsB)).max.x - ((Bounds)(ref boundsA)).min.x;
		float num3 = ((Bounds)(ref boundsA)).max.y - ((Bounds)(ref boundsB)).min.y;
		float num4 = ((Bounds)(ref boundsB)).max.y - ((Bounds)(ref boundsA)).min.y;
		float num5 = ((Bounds)(ref boundsA)).max.z - ((Bounds)(ref boundsB)).min.z;
		float num6 = ((Bounds)(ref boundsB)).max.z - ((Bounds)(ref boundsA)).min.z;
		return Mathf.Min(new float[6] { num, num2, num3, num4, num5, num6 });
	}

	public static Vector3 CalculatePerAxisOverlap(Bounds boundsA, Bounds boundsB)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		float num = ((Bounds)(ref boundsA)).max.x - ((Bounds)(ref boundsB)).min.x;
		float num2 = ((Bounds)(ref boundsB)).max.x - ((Bounds)(ref boundsA)).min.x;
		float num3 = ((Bounds)(ref boundsA)).max.y - ((Bounds)(ref boundsB)).min.y;
		float num4 = ((Bounds)(ref boundsB)).max.y - ((Bounds)(ref boundsA)).min.y;
		float num5 = ((Bounds)(ref boundsA)).max.z - ((Bounds)(ref boundsB)).min.z;
		float num6 = ((Bounds)(ref boundsB)).max.z - ((Bounds)(ref boundsA)).min.z;
		return new Vector3(Mathf.Min(num, num2), Mathf.Min(num3, num4), Mathf.Min(num5, num6));
	}
}
