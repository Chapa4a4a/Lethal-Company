namespace DunGen;

public enum LocalPropSetCountMode
{
	Random,
	DepthBased,
	DepthMultiply
}
