namespace DunGen;

public enum PostProcessPhase
{
	BeforeBuiltIn,
	AfterBuiltIn
}
