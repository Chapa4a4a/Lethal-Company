using System.Collections;
using UnityEngine;

namespace DunGen;

public sealed class CoroutineHelper : MonoBehaviour
{
	private static CoroutineHelper instance;

	private static CoroutineHelper Instance
	{
		get
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			if ((Object)(object)instance == (Object)null)
			{
				instance = new GameObject("DunGen Coroutine Helper")
				{
					hideFlags = (HideFlags)1
				}.AddComponent<CoroutineHelper>();
			}
			return instance;
		}
	}

	public static Coroutine Start(IEnumerator routine)
	{
		return ((MonoBehaviour)Instance).StartCoroutine(routine);
	}

	public static void StopAll()
	{
		((MonoBehaviour)Instance).StopAllCoroutines();
	}
}
