namespace DunGen;

public delegate void GenerationStatusDelegate(DungeonGenerator generator, GenerationStatus status);
