namespace DunGen;

public enum GameObjectFilter
{
	Scene = 1,
	Asset,
	All
}
