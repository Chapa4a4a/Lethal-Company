namespace DunGen;

public enum BranchMode
{
	Local,
	Global
}
