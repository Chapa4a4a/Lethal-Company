using System;

namespace DunGen;

[Flags]
public enum NodeLockPlacement
{
	Entrance = 1,
	Exit = 2
}
