using System.Collections.Generic;
using System.Linq;
using DunGen.Graph;
using UnityEngine;

namespace DunGen;

public sealed class DungeonProxy
{
	public List<TileProxy> AllTiles = new List<TileProxy>();

	public List<TileProxy> MainPathTiles = new List<TileProxy>();

	public List<TileProxy> BranchPathTiles = new List<TileProxy>();

	public List<ProxyDoorwayConnection> Connections = new List<ProxyDoorwayConnection>();

	private Transform visualsRoot;

	private Dictionary<TileProxy, GameObject> tileVisuals = new Dictionary<TileProxy, GameObject>();

	public DungeonProxy(Transform debugVisualsRoot = null)
	{
		visualsRoot = debugVisualsRoot;
	}

	public void ClearDebugVisuals()
	{
		GameObject[] array = tileVisuals.Values.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			Object.DestroyImmediate((Object)(object)array[i]);
		}
		tileVisuals.Clear();
	}

	public void MakeConnection(DoorwayProxy a, DoorwayProxy b)
	{
		DoorwayProxy.Connect(a, b);
		ProxyDoorwayConnection item = new ProxyDoorwayConnection(a, b);
		Connections.Add(item);
	}

	public void RemoveLastConnection()
	{
		RemoveConnection(Connections.Last());
	}

	public void RemoveConnection(ProxyDoorwayConnection connection)
	{
		connection.A.Disconnect();
		Connections.Remove(connection);
	}

	internal void AddTile(TileProxy tile)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		AllTiles.Add(tile);
		if (tile.Placement.IsOnMainPath)
		{
			MainPathTiles.Add(tile);
		}
		else
		{
			BranchPathTiles.Add(tile);
		}
		if ((Object)(object)visualsRoot != (Object)null)
		{
			GameObject val = Object.Instantiate<GameObject>(tile.Prefab, visualsRoot);
			val.transform.localPosition = tile.Placement.Position;
			val.transform.localRotation = tile.Placement.Rotation;
			tileVisuals[tile] = val;
		}
	}

	internal void RemoveTile(TileProxy tile)
	{
		AllTiles.Remove(tile);
		if (tile.Placement.IsOnMainPath)
		{
			MainPathTiles.Remove(tile);
		}
		else
		{
			BranchPathTiles.Remove(tile);
		}
		if (tileVisuals.TryGetValue(tile, out var value))
		{
			Object.DestroyImmediate((Object)(object)value);
			tileVisuals.Remove(tile);
		}
	}

	internal void ConnectOverlappingDoorways(float globalChance, DungeonFlow dungeonFlow, RandomStream randomStream)
	{
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		IEnumerable<DoorwayProxy> enumerable = AllTiles.SelectMany((TileProxy t) => t.UnusedDoorways);
		foreach (DoorwayProxy item in enumerable)
		{
			foreach (DoorwayProxy item2 in enumerable)
			{
				if (item.Used || item2.Used || item == item2 || item.TileProxy == item2.TileProxy || !dungeonFlow.CanDoorwaysConnect(item.TileProxy.PrefabTile, item2.TileProxy.PrefabTile, item.DoorwayComponent, item2.DoorwayComponent))
				{
					continue;
				}
				Vector3 val = item.Position - item2.Position;
				if (((Vector3)(ref val)).sqrMagnitude >= 1E-05f)
				{
					continue;
				}
				if (dungeonFlow.RestrictConnectionToSameSection)
				{
					bool flag = item.TileProxy.Placement.GraphLine == item2.TileProxy.Placement.GraphLine;
					if (item.TileProxy.Placement.GraphLine == null)
					{
						flag = false;
					}
					if (!flag)
					{
						continue;
					}
				}
				float num = globalChance;
				if (item.TileProxy.PrefabTile.OverrideConnectionChance && item2.TileProxy.PrefabTile.OverrideConnectionChance)
				{
					num = Mathf.Min(item.TileProxy.PrefabTile.ConnectionChance, item2.TileProxy.PrefabTile.ConnectionChance);
				}
				else if (item.TileProxy.PrefabTile.OverrideConnectionChance)
				{
					num = item.TileProxy.PrefabTile.ConnectionChance;
				}
				else if (item2.TileProxy.PrefabTile.OverrideConnectionChance)
				{
					num = item2.TileProxy.PrefabTile.ConnectionChance;
				}
				if (!(num <= 0f) && randomStream.NextDouble() < (double)num)
				{
					MakeConnection(item, item2);
				}
			}
		}
	}
}
