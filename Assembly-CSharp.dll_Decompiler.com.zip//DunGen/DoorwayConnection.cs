namespace DunGen;

public sealed class DoorwayConnection
{
	public Doorway A { get; private set; }

	public Doorway B { get; private set; }

	public DoorwayConnection(Doorway a, Doorway b)
	{
		A = a;
		B = b;
	}
}
