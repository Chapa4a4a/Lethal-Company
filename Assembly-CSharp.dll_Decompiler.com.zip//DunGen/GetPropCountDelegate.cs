namespace DunGen;

public delegate int GetPropCountDelegate(LocalPropSet propSet, RandomStream randomStream, Tile tile);
