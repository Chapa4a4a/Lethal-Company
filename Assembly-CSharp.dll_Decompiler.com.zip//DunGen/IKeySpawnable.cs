namespace DunGen;

public interface IKeySpawnable
{
	void SpawnKey(Key key, KeyManager manager);
}
