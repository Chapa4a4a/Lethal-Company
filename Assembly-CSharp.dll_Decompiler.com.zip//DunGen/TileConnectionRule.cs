namespace DunGen;

public sealed class TileConnectionRule
{
	public enum ConnectionResult
	{
		Allow,
		Deny,
		Passthrough
	}

	public delegate ConnectionResult CanTilesConnectDelegate(Tile tileA, Tile tileB, Doorway doorwayA, Doorway doorwayB);

	public int Priority;

	public CanTilesConnectDelegate Delegate;

	public TileConnectionRule(CanTilesConnectDelegate connectionDelegate, int priority = 0)
	{
		Delegate = connectionDelegate;
		Priority = priority;
	}
}
