namespace DunGen;

public enum BranchCapType : byte
{
	InsteadOf,
	AsWellAs
}
