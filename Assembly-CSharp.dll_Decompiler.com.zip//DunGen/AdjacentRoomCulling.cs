using System;
using System.Collections.Generic;
using UnityEngine;

namespace DunGen;

[AddComponentMenu("DunGen/Culling/Adjacent Room Culling")]
public class AdjacentRoomCulling : MonoBehaviour
{
	public delegate void VisibilityChangedDelegate(Tile tile, bool visible);

	public int AdjacentTileDepth = 1;

	public bool CullBehindClosedDoors = true;

	public Transform TargetOverride;

	public bool IncludeDisabledComponents;

	[NonSerialized]
	public Dictionary<Renderer, bool> OverrideRendererVisibilities = new Dictionary<Renderer, bool>();

	[NonSerialized]
	public Dictionary<Light, bool> OverrideLightVisibilities = new Dictionary<Light, bool>();

	protected List<Tile> allTiles;

	protected List<Door> allDoors;

	protected List<Tile> oldVisibleTiles;

	protected List<Tile> visibleTiles;

	protected Dictionary<Tile, bool> tileVisibilities;

	protected Dictionary<Tile, List<Renderer>> tileRenderers;

	protected Dictionary<Tile, List<Light>> lightSources;

	protected Dictionary<Tile, List<ReflectionProbe>> reflectionProbes;

	protected Dictionary<Door, List<Renderer>> doorRenderers;

	private bool dirty;

	private DungeonGenerator generator;

	private Tile currentTile;

	private Queue<Tile> tilesToSearch;

	private List<Tile> searchedTiles;

	public bool Ready { get; protected set; }

	protected Transform targetTransform
	{
		get
		{
			if (!((Object)(object)TargetOverride != (Object)null))
			{
				return ((Component)this).transform;
			}
			return TargetOverride;
		}
	}

	public event VisibilityChangedDelegate TileVisibilityChanged;

	protected virtual void OnEnable()
	{
		RuntimeDungeon runtimeDungeon = Object.FindObjectOfType<RuntimeDungeon>();
		if ((Object)(object)runtimeDungeon != (Object)null)
		{
			generator = runtimeDungeon.Generator;
			generator.OnGenerationStatusChanged += OnDungeonGenerationStatusChanged;
			if (generator.Status == GenerationStatus.Complete)
			{
				SetDungeon(generator.CurrentDungeon);
			}
		}
	}

	protected virtual void OnDisable()
	{
		if (generator != null)
		{
			generator.OnGenerationStatusChanged -= OnDungeonGenerationStatusChanged;
		}
		ClearDungeon();
	}

	public virtual void SetDungeon(Dungeon dungeon)
	{
		if (Ready)
		{
			ClearDungeon();
		}
		if ((Object)(object)dungeon == (Object)null)
		{
			return;
		}
		allTiles = new List<Tile>(dungeon.AllTiles);
		allDoors = new List<Door>(GetAllDoorsInDungeon(dungeon));
		oldVisibleTiles = new List<Tile>(allTiles.Count);
		visibleTiles = new List<Tile>(allTiles.Count);
		tileVisibilities = new Dictionary<Tile, bool>();
		tileRenderers = new Dictionary<Tile, List<Renderer>>();
		lightSources = new Dictionary<Tile, List<Light>>();
		reflectionProbes = new Dictionary<Tile, List<ReflectionProbe>>();
		doorRenderers = new Dictionary<Door, List<Renderer>>();
		UpdateRendererLists();
		foreach (Tile allTile in allTiles)
		{
			SetTileVisibility(allTile, visible: false);
		}
		foreach (Door allDoor in allDoors)
		{
			allDoor.OnDoorStateChanged += OnDoorStateChanged;
			SetDoorVisibility(allDoor, visible: false);
		}
		Ready = true;
		dirty = true;
	}

	public virtual bool IsTileVisible(Tile tile)
	{
		if (tileVisibilities.TryGetValue(tile, out var value))
		{
			return value;
		}
		return false;
	}

	protected IEnumerable<Door> GetAllDoorsInDungeon(Dungeon dungeon)
	{
		foreach (GameObject door in dungeon.Doors)
		{
			if (!((Object)(object)door == (Object)null))
			{
				Door component = door.GetComponent<Door>();
				if ((Object)(object)component != (Object)null)
				{
					yield return component;
				}
			}
		}
	}

	protected virtual void ClearDungeon()
	{
		if (!Ready)
		{
			return;
		}
		foreach (Door allDoor in allDoors)
		{
			SetDoorVisibility(allDoor, visible: true);
			allDoor.OnDoorStateChanged -= OnDoorStateChanged;
		}
		foreach (Tile allTile in allTiles)
		{
			SetTileVisibility(allTile, visible: true);
		}
		Ready = false;
	}

	protected virtual void OnDoorStateChanged(Door door, bool isOpen)
	{
		dirty = true;
	}

	protected virtual void OnDungeonGenerationStatusChanged(DungeonGenerator generator, GenerationStatus status)
	{
		switch (status)
		{
		case GenerationStatus.Complete:
			SetDungeon(generator.CurrentDungeon);
			break;
		case GenerationStatus.Failed:
			ClearDungeon();
			break;
		}
	}

	protected virtual void LateUpdate()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (!Ready)
		{
			return;
		}
		Tile tile = currentTile;
		if ((Object)(object)currentTile == (Object)null)
		{
			currentTile = FindCurrentTile();
		}
		else
		{
			Bounds bounds = currentTile.Bounds;
			if (!((Bounds)(ref bounds)).Contains(targetTransform.position))
			{
				currentTile = SearchForNewCurrentTile();
			}
		}
		if ((Object)(object)currentTile != (Object)(object)tile)
		{
			dirty = true;
		}
		if (dirty)
		{
			RefreshVisibility();
		}
		dirty = false;
	}

	protected virtual void RefreshVisibility()
	{
		List<Tile> list = visibleTiles;
		visibleTiles = oldVisibleTiles;
		oldVisibleTiles = list;
		UpdateVisibleTiles();
		foreach (Tile oldVisibleTile in oldVisibleTiles)
		{
			if (!visibleTiles.Contains(oldVisibleTile))
			{
				SetTileVisibility(oldVisibleTile, visible: false);
			}
		}
		foreach (Tile visibleTile in visibleTiles)
		{
			if (!oldVisibleTiles.Contains(visibleTile))
			{
				SetTileVisibility(visibleTile, visible: true);
			}
		}
		oldVisibleTiles.Clear();
		RefreshDoorVisibilities();
	}

	protected virtual void RefreshDoorVisibilities()
	{
		foreach (Door allDoor in allDoors)
		{
			bool visible = visibleTiles.Contains(allDoor.DoorwayA.Tile) || visibleTiles.Contains(allDoor.DoorwayB.Tile);
			SetDoorVisibility(allDoor, visible);
		}
	}

	protected virtual void SetDoorVisibility(Door door, bool visible)
	{
		if (!doorRenderers.TryGetValue(door, out var value))
		{
			return;
		}
		for (int num = value.Count - 1; num >= 0; num--)
		{
			Renderer val = value[num];
			bool value2;
			if ((Object)(object)val == (Object)null)
			{
				value.RemoveAt(num);
			}
			else if (OverrideRendererVisibilities.TryGetValue(val, out value2))
			{
				val.enabled = value2;
			}
			else
			{
				val.enabled = visible;
			}
		}
	}

	protected virtual void UpdateVisibleTiles()
	{
		visibleTiles.Clear();
		if ((Object)(object)currentTile != (Object)null)
		{
			visibleTiles.Add(currentTile);
		}
		int num = 0;
		for (int i = 0; i < AdjacentTileDepth; i++)
		{
			int count = visibleTiles.Count;
			for (int j = num; j < count; j++)
			{
				foreach (Doorway usedDoorway in visibleTiles[j].UsedDoorways)
				{
					Tile tile = usedDoorway.ConnectedDoorway.Tile;
					if (visibleTiles.Contains(tile))
					{
						continue;
					}
					if (CullBehindClosedDoors)
					{
						Door doorComponent = usedDoorway.DoorComponent;
						if ((Object)(object)doorComponent != (Object)null && doorComponent.ShouldCullBehind)
						{
							continue;
						}
					}
					visibleTiles.Add(tile);
				}
			}
			num = count;
		}
	}

	protected virtual void SetTileVisibility(Tile tile, bool visible)
	{
		tileVisibilities[tile] = visible;
		if (tileRenderers.TryGetValue(tile, out var value))
		{
			for (int num = value.Count - 1; num >= 0; num--)
			{
				Renderer val = value[num];
				bool value2;
				if ((Object)(object)val == (Object)null)
				{
					value.RemoveAt(num);
				}
				else if (OverrideRendererVisibilities.TryGetValue(val, out value2))
				{
					val.enabled = value2;
				}
				else
				{
					val.enabled = visible;
				}
			}
		}
		if (lightSources.TryGetValue(tile, out var value3))
		{
			for (int num2 = value3.Count - 1; num2 >= 0; num2--)
			{
				Light val2 = value3[num2];
				bool value4;
				if ((Object)(object)val2 == (Object)null)
				{
					value3.RemoveAt(num2);
				}
				else if (OverrideLightVisibilities.TryGetValue(val2, out value4))
				{
					((Behaviour)val2).enabled = value4;
				}
				else
				{
					((Behaviour)val2).enabled = visible;
				}
			}
		}
		if (reflectionProbes.TryGetValue(tile, out var value5))
		{
			for (int num3 = value5.Count - 1; num3 >= 0; num3--)
			{
				ReflectionProbe val3 = value5[num3];
				if ((Object)(object)val3 == (Object)null)
				{
					value5.RemoveAt(num3);
				}
				else
				{
					((Behaviour)val3).enabled = visible;
				}
			}
		}
		if (this.TileVisibilityChanged != null)
		{
			this.TileVisibilityChanged(tile, visible);
		}
	}

	public virtual void UpdateRendererLists()
	{
		foreach (Tile allTile in allTiles)
		{
			if (!tileRenderers.TryGetValue(allTile, out var value))
			{
				value = (tileRenderers[allTile] = new List<Renderer>());
			}
			Renderer[] componentsInChildren = ((Component)allTile).GetComponentsInChildren<Renderer>();
			foreach (Renderer val in componentsInChildren)
			{
				if (IncludeDisabledComponents || (val.enabled && ((Component)val).gameObject.activeInHierarchy))
				{
					value.Add(val);
				}
			}
			if (!lightSources.TryGetValue(allTile, out var value2))
			{
				value2 = (lightSources[allTile] = new List<Light>());
			}
			Light[] componentsInChildren2 = ((Component)allTile).GetComponentsInChildren<Light>();
			foreach (Light val2 in componentsInChildren2)
			{
				if (IncludeDisabledComponents || (((Behaviour)val2).enabled && ((Component)val2).gameObject.activeInHierarchy))
				{
					value2.Add(val2);
				}
			}
			if (!reflectionProbes.TryGetValue(allTile, out var value3))
			{
				value3 = (reflectionProbes[allTile] = new List<ReflectionProbe>());
			}
			ReflectionProbe[] componentsInChildren3 = ((Component)allTile).GetComponentsInChildren<ReflectionProbe>();
			foreach (ReflectionProbe val3 in componentsInChildren3)
			{
				if (IncludeDisabledComponents || (((Behaviour)val3).enabled && ((Component)val3).gameObject.activeInHierarchy))
				{
					value3.Add(val3);
				}
			}
		}
		foreach (Door allDoor in allDoors)
		{
			List<Renderer> list4 = new List<Renderer>();
			doorRenderers[allDoor] = list4;
			Renderer[] componentsInChildren = ((Component)allDoor).GetComponentsInChildren<Renderer>(true);
			foreach (Renderer val4 in componentsInChildren)
			{
				if (IncludeDisabledComponents || (val4.enabled && ((Component)val4).gameObject.activeInHierarchy))
				{
					list4.Add(val4);
				}
			}
		}
	}

	protected Tile FindCurrentTile()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		Dungeon dungeon = Object.FindObjectOfType<Dungeon>();
		if ((Object)(object)dungeon == (Object)null)
		{
			return null;
		}
		foreach (Tile allTile in dungeon.AllTiles)
		{
			Bounds bounds = allTile.Bounds;
			if (((Bounds)(ref bounds)).Contains(targetTransform.position))
			{
				return allTile;
			}
		}
		return null;
	}

	protected Tile SearchForNewCurrentTile()
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		if (tilesToSearch == null)
		{
			tilesToSearch = new Queue<Tile>();
		}
		if (searchedTiles == null)
		{
			searchedTiles = new List<Tile>();
		}
		foreach (Doorway usedDoorway in currentTile.UsedDoorways)
		{
			Tile tile = usedDoorway.ConnectedDoorway.Tile;
			if (!tilesToSearch.Contains(tile))
			{
				tilesToSearch.Enqueue(tile);
			}
		}
		while (tilesToSearch.Count > 0)
		{
			Tile tile2 = tilesToSearch.Dequeue();
			Bounds bounds = tile2.Bounds;
			if (((Bounds)(ref bounds)).Contains(targetTransform.position))
			{
				tilesToSearch.Clear();
				searchedTiles.Clear();
				return tile2;
			}
			searchedTiles.Add(tile2);
			foreach (Doorway usedDoorway2 in tile2.UsedDoorways)
			{
				Tile tile3 = usedDoorway2.ConnectedDoorway.Tile;
				if (!tilesToSearch.Contains(tile3) && !searchedTiles.Contains(tile3))
				{
					tilesToSearch.Enqueue(tile3);
				}
			}
		}
		searchedTiles.Clear();
		return null;
	}
}
