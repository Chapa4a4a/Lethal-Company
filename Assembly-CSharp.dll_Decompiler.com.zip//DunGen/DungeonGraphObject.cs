namespace DunGen;

public abstract class DungeonGraphObject
{
}
