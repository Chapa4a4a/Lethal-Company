using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using UnityEngine;

namespace DunGen;

public sealed class TileProxy
{
	private List<DoorwayProxy> doorways = new List<DoorwayProxy>();

	public GameObject Prefab { get; private set; }

	public Tile PrefabTile { get; private set; }

	public TilePlacementData Placement { get; internal set; }

	public DoorwayProxy Entrance { get; private set; }

	public DoorwayProxy Exit { get; private set; }

	public ReadOnlyCollection<DoorwayProxy> Doorways { get; private set; }

	public IEnumerable<DoorwayProxy> UsedDoorways => doorways.Where((DoorwayProxy d) => d.Used);

	public IEnumerable<DoorwayProxy> UnusedDoorways => doorways.Where((DoorwayProxy d) => !d.Used);

	public TileProxy(TileProxy existingTile)
	{
		Prefab = existingTile.Prefab;
		PrefabTile = existingTile.PrefabTile;
		Placement = new TilePlacementData(existingTile.Placement);
		Doorways = new ReadOnlyCollection<DoorwayProxy>(doorways);
		foreach (DoorwayProxy doorway in existingTile.doorways)
		{
			DoorwayProxy doorwayProxy = new DoorwayProxy(this, doorway);
			doorways.Add(doorwayProxy);
			if (existingTile.Entrance == doorway)
			{
				Entrance = doorwayProxy;
			}
			if (existingTile.Exit == doorway)
			{
				Exit = doorwayProxy;
			}
		}
	}

	public TileProxy(GameObject prefab, bool ignoreSpriteRendererBounds, Vector3 upVector)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		prefab.transform.localPosition = Vector3.zero;
		prefab.transform.localRotation = Quaternion.identity;
		Prefab = prefab;
		PrefabTile = prefab.GetComponent<Tile>();
		if ((Object)(object)PrefabTile == (Object)null)
		{
			PrefabTile = prefab.AddComponent<Tile>();
		}
		Placement = new TilePlacementData();
		Doorways = new ReadOnlyCollection<DoorwayProxy>(doorways);
		Doorway[] componentsInChildren = prefab.GetComponentsInChildren<Doorway>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			Doorway doorway = componentsInChildren[i];
			Vector3 position = ((Component)doorway).transform.position;
			Quaternion rotation = ((Component)doorway).transform.rotation;
			DoorwayProxy doorwayProxy = new DoorwayProxy(this, i, doorway, position, rotation);
			doorways.Add(doorwayProxy);
			if ((Object)(object)PrefabTile.Entrance == (Object)(object)doorway)
			{
				Entrance = doorwayProxy;
			}
			if ((Object)(object)PrefabTile.Exit == (Object)(object)doorway)
			{
				Exit = doorwayProxy;
			}
		}
		Bounds bounds = ((!((Object)(object)PrefabTile != (Object)null) || !PrefabTile.OverrideAutomaticTileBounds) ? UnityUtil.CalculateProxyBounds(Prefab, ignoreSpriteRendererBounds, upVector) : PrefabTile.TileBoundsOverride);
		if (((Bounds)(ref bounds)).size.x <= 0f || ((Bounds)(ref bounds)).size.y <= 0f || ((Bounds)(ref bounds)).size.z <= 0f)
		{
			Debug.LogError((object)$"Tile prefab '{prefab}' has automatic bounds that are zero or negative in size. The bounding volume for this tile will need to be manually defined.", (Object)(object)prefab);
		}
		Placement.LocalBounds = UnityUtil.CondenseBounds(bounds, Prefab.GetComponentsInChildren<Doorway>());
	}

	public void PositionBySocket(DoorwayProxy myDoorway, DoorwayProxy otherDoorway)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		Quaternion val = Quaternion.LookRotation(-otherDoorway.Forward, otherDoorway.Up);
		Placement.Rotation = val * Quaternion.Inverse(Quaternion.Inverse(Placement.Rotation) * (Placement.Rotation * myDoorway.LocalRotation));
		Vector3 position = otherDoorway.Position;
		Placement.Position = position - (myDoorway.Position - Placement.Position);
	}

	private Vector3 CalculateOverlap(TileProxy other)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		Bounds bounds = Placement.Bounds;
		Bounds bounds2 = other.Placement.Bounds;
		float num = ((Bounds)(ref bounds)).max.x - ((Bounds)(ref bounds2)).min.x;
		float num2 = ((Bounds)(ref bounds2)).max.x - ((Bounds)(ref bounds)).min.x;
		float num3 = ((Bounds)(ref bounds)).max.y - ((Bounds)(ref bounds2)).min.y;
		float num4 = ((Bounds)(ref bounds2)).max.y - ((Bounds)(ref bounds)).min.y;
		float num5 = ((Bounds)(ref bounds)).max.z - ((Bounds)(ref bounds2)).min.z;
		float num6 = ((Bounds)(ref bounds2)).max.z - ((Bounds)(ref bounds)).min.z;
		return new Vector3(Mathf.Min(num, num2), Mathf.Min(num3, num4), Mathf.Min(num5, num6));
	}

	public bool IsOverlapping(TileProxy other, float maxOverlap)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = CalculateOverlap(other);
		return Mathf.Min(new float[3] { val.x, val.y, val.z }) > maxOverlap;
	}

	public bool IsOverlappingOrOverhanging(TileProxy other, AxisDirection upDirection, float maxOverlap)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = UnityUtil.CalculatePerAxisOverlap(other.Placement.Bounds, Placement.Bounds);
		float num;
		switch (upDirection)
		{
		case AxisDirection.PosX:
		case AxisDirection.NegX:
			num = Mathf.Min(val.y, val.z);
			break;
		case AxisDirection.PosY:
		case AxisDirection.NegY:
			num = Mathf.Min(val.x, val.z);
			break;
		case AxisDirection.PosZ:
		case AxisDirection.NegZ:
			num = Mathf.Min(val.x, val.y);
			break;
		default:
			throw new NotImplementedException("AxisDirection '" + upDirection.ToString() + "' is not implemented");
		}
		return num > maxOverlap;
	}
}
