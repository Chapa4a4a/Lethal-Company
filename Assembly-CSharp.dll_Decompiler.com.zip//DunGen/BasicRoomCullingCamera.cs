using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace DunGen;

[AddComponentMenu("DunGen/Culling/Adjacent Room Culling (Multi-Camera)")]
public class BasicRoomCullingCamera : MonoBehaviour
{
	protected struct RendererData
	{
		public Renderer Renderer;

		public bool Enabled;

		public RendererData(Renderer renderer, bool enabled)
		{
			Renderer = renderer;
			Enabled = enabled;
		}
	}

	protected struct LightData
	{
		public Light Light;

		public bool Enabled;

		public LightData(Light light, bool enabled)
		{
			Light = light;
			Enabled = enabled;
		}
	}

	protected struct ReflectionProbeData
	{
		public ReflectionProbe Probe;

		public bool Enabled;

		public ReflectionProbeData(ReflectionProbe probe, bool enabled)
		{
			Probe = probe;
			Enabled = enabled;
		}
	}

	public int AdjacentTileDepth = 1;

	public bool CullBehindClosedDoors = true;

	public Transform TargetOverride;

	public bool CullInEditor;

	public bool CullLights = true;

	protected bool isCulling;

	protected bool isDirty;

	protected DungeonGenerator generator;

	protected Tile currentTile;

	protected List<Tile> allTiles;

	protected List<Door> allDoors;

	protected List<Tile> visibleTiles;

	protected Dictionary<Tile, List<RendererData>> rendererVisibilities = new Dictionary<Tile, List<RendererData>>();

	protected Dictionary<Tile, List<LightData>> lightVisibilities = new Dictionary<Tile, List<LightData>>();

	protected Dictionary<Tile, List<ReflectionProbeData>> reflectionProbeVisibilities = new Dictionary<Tile, List<ReflectionProbeData>>();

	protected Dictionary<Door, List<RendererData>> doorRendererVisibilities = new Dictionary<Door, List<RendererData>>();

	public bool IsReady { get; protected set; }

	protected virtual void Awake()
	{
		RuntimeDungeon runtimeDungeon = Object.FindObjectOfType<RuntimeDungeon>();
		if ((Object)(object)runtimeDungeon != (Object)null)
		{
			generator = runtimeDungeon.Generator;
			generator.OnGenerationStatusChanged += OnDungeonGenerationStatusChanged;
			if (generator.Status == GenerationStatus.Complete)
			{
				SetDungeon(generator.CurrentDungeon);
			}
		}
	}

	protected virtual void OnDestroy()
	{
		if (generator != null)
		{
			generator.OnGenerationStatusChanged -= OnDungeonGenerationStatusChanged;
		}
	}

	protected virtual void OnEnable()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Expected O, but got Unknown
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Expected O, but got Unknown
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		if (RenderPipelineManager.currentPipeline != null)
		{
			RenderPipelineManager.beginCameraRendering += OnBeginCameraRendering;
			RenderPipelineManager.endCameraRendering += OnEndCameraRendering;
		}
		else
		{
			Camera.onPreCull = (CameraCallback)Delegate.Combine((Delegate?)(object)Camera.onPreCull, (Delegate?)new CameraCallback(EnableCulling));
			Camera.onPostRender = (CameraCallback)Delegate.Combine((Delegate?)(object)Camera.onPostRender, (Delegate?)new CameraCallback(DisableCulling));
		}
	}

	protected virtual void OnDisable()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Expected O, but got Unknown
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Expected O, but got Unknown
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Expected O, but got Unknown
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Expected O, but got Unknown
		RenderPipelineManager.beginCameraRendering -= OnBeginCameraRendering;
		RenderPipelineManager.endCameraRendering -= OnEndCameraRendering;
		Camera.onPreCull = (CameraCallback)Delegate.Remove((Delegate?)(object)Camera.onPreCull, (Delegate?)new CameraCallback(EnableCulling));
		Camera.onPostRender = (CameraCallback)Delegate.Remove((Delegate?)(object)Camera.onPostRender, (Delegate?)new CameraCallback(DisableCulling));
	}

	private void OnBeginCameraRendering(ScriptableRenderContext context, Camera camera)
	{
		EnableCulling(camera);
	}

	private void OnEndCameraRendering(ScriptableRenderContext context, Camera camera)
	{
		DisableCulling(camera);
	}

	protected virtual void OnDungeonGenerationStatusChanged(DungeonGenerator generator, GenerationStatus status)
	{
		switch (status)
		{
		case GenerationStatus.Complete:
			SetDungeon(generator.CurrentDungeon);
			break;
		case GenerationStatus.Failed:
			ClearDungeon();
			break;
		}
	}

	protected virtual void EnableCulling(Camera camera)
	{
		SetCullingEnabled(camera, enabled: true);
	}

	protected virtual void DisableCulling(Camera camera)
	{
		SetCullingEnabled(camera, enabled: false);
	}

	protected void SetCullingEnabled(Camera camera, bool enabled)
	{
		if (IsReady && (Object)(object)((Component)camera).gameObject == (Object)(object)((Component)this).gameObject)
		{
			SetIsCulling(enabled);
		}
	}

	protected virtual void LateUpdate()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (!IsReady)
		{
			return;
		}
		Transform val = (((Object)(object)TargetOverride != (Object)null) ? TargetOverride : ((Component)this).transform);
		Bounds bounds;
		if (!((Object)(object)currentTile == (Object)null))
		{
			bounds = currentTile.Bounds;
			if (((Bounds)(ref bounds)).Contains(val.position))
			{
				goto IL_00b3;
			}
		}
		foreach (Tile allTile in allTiles)
		{
			if (!((Object)(object)allTile == (Object)null))
			{
				bounds = allTile.Bounds;
				if (((Bounds)(ref bounds)).Contains(val.position))
				{
					currentTile = allTile;
					break;
				}
			}
		}
		isDirty = true;
		goto IL_00b3;
		IL_00b3:
		if (!isDirty)
		{
			return;
		}
		UpdateCulling();
		foreach (Tile allTile2 in allTiles)
		{
			if (!visibleTiles.Contains(allTile2))
			{
				UpdateRendererList(allTile2);
			}
		}
	}

	protected void UpdateRendererList(Tile tile)
	{
		if (!rendererVisibilities.TryGetValue(tile, out var value))
		{
			value = (rendererVisibilities[tile] = new List<RendererData>());
		}
		else
		{
			value.Clear();
		}
		Renderer[] componentsInChildren = ((Component)tile).GetComponentsInChildren<Renderer>();
		foreach (Renderer val in componentsInChildren)
		{
			value.Add(new RendererData(val, val.enabled));
		}
		if (CullLights)
		{
			if (!lightVisibilities.TryGetValue(tile, out var value2))
			{
				value2 = (lightVisibilities[tile] = new List<LightData>());
			}
			else
			{
				value2.Clear();
			}
			Light[] componentsInChildren2 = ((Component)tile).GetComponentsInChildren<Light>();
			foreach (Light val2 in componentsInChildren2)
			{
				value2.Add(new LightData(val2, ((Behaviour)val2).enabled));
			}
		}
		if (!reflectionProbeVisibilities.TryGetValue(tile, out var value3))
		{
			value3 = (reflectionProbeVisibilities[tile] = new List<ReflectionProbeData>());
		}
		else
		{
			value3.Clear();
		}
		ReflectionProbe[] componentsInChildren3 = ((Component)tile).GetComponentsInChildren<ReflectionProbe>();
		foreach (ReflectionProbe val3 in componentsInChildren3)
		{
			value3.Add(new ReflectionProbeData(val3, ((Behaviour)val3).enabled));
		}
	}

	protected void SetIsCulling(bool isCulling)
	{
		this.isCulling = isCulling;
		for (int i = 0; i < allTiles.Count; i++)
		{
			Tile tile = allTiles[i];
			if (visibleTiles.Contains(tile))
			{
				continue;
			}
			if (rendererVisibilities.TryGetValue(tile, out var value))
			{
				foreach (RendererData item in value)
				{
					item.Renderer.enabled = !isCulling && item.Enabled;
				}
			}
			if (CullLights && lightVisibilities.TryGetValue(tile, out var value2))
			{
				foreach (LightData item2 in value2)
				{
					((Behaviour)item2.Light).enabled = !isCulling && item2.Enabled;
				}
			}
			if (!reflectionProbeVisibilities.TryGetValue(tile, out var value3))
			{
				continue;
			}
			foreach (ReflectionProbeData item3 in value3)
			{
				((Behaviour)item3.Probe).enabled = !isCulling && item3.Enabled;
			}
		}
		foreach (Door allDoor in allDoors)
		{
			bool flag = visibleTiles.Contains(allDoor.DoorwayA.Tile) || visibleTiles.Contains(allDoor.DoorwayB.Tile);
			if (!doorRendererVisibilities.TryGetValue(allDoor, out var value4))
			{
				continue;
			}
			foreach (RendererData item4 in value4)
			{
				item4.Renderer.enabled = (isCulling ? flag : item4.Enabled);
			}
		}
	}

	protected void UpdateCulling()
	{
		isDirty = false;
		visibleTiles.Clear();
		if ((Object)(object)currentTile != (Object)null)
		{
			visibleTiles.Add(currentTile);
		}
		int num = 0;
		for (int i = 0; i < AdjacentTileDepth; i++)
		{
			int count = visibleTiles.Count;
			for (int j = num; j < count; j++)
			{
				foreach (Doorway usedDoorway in visibleTiles[j].UsedDoorways)
				{
					Tile tile = usedDoorway.ConnectedDoorway.Tile;
					if (visibleTiles.Contains(tile))
					{
						continue;
					}
					if (CullBehindClosedDoors)
					{
						Door doorComponent = usedDoorway.DoorComponent;
						if ((Object)(object)doorComponent != (Object)null && doorComponent.ShouldCullBehind)
						{
							continue;
						}
					}
					visibleTiles.Add(tile);
				}
			}
			num = count;
		}
	}

	public void SetDungeon(Dungeon dungeon)
	{
		if (IsReady)
		{
			ClearDungeon();
		}
		if ((Object)(object)dungeon == (Object)null)
		{
			return;
		}
		allTiles = new List<Tile>(dungeon.AllTiles);
		allDoors = new List<Door>(GetAllDoorsInDungeon(dungeon));
		visibleTiles = new List<Tile>(allTiles.Count);
		doorRendererVisibilities.Clear();
		foreach (Door allDoor in allDoors)
		{
			List<RendererData> list = new List<RendererData>();
			doorRendererVisibilities[allDoor] = list;
			Renderer[] componentsInChildren = ((Component)allDoor).GetComponentsInChildren<Renderer>(true);
			foreach (Renderer val in componentsInChildren)
			{
				list.Add(new RendererData(val, val.enabled));
			}
			allDoor.OnDoorStateChanged += OnDoorStateChanged;
		}
		IsReady = true;
		isDirty = true;
	}

	protected IEnumerable<Door> GetAllDoorsInDungeon(Dungeon dungeon)
	{
		foreach (GameObject door in dungeon.Doors)
		{
			if (!((Object)(object)door == (Object)null))
			{
				Door component = door.GetComponent<Door>();
				if ((Object)(object)component != (Object)null)
				{
					yield return component;
				}
			}
		}
	}

	protected virtual void ClearDungeon()
	{
		foreach (Door allDoor in allDoors)
		{
			allDoor.OnDoorStateChanged -= OnDoorStateChanged;
		}
		IsReady = false;
	}

	protected virtual void OnDoorStateChanged(Door door, bool isOpen)
	{
		isDirty = true;
	}
}
