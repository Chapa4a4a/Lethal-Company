namespace DunGen;

public enum DoorwaySocketType
{
	Default,
	Large,
	Vertical
}
