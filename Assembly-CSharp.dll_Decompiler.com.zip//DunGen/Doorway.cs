using System.Collections.Generic;
using DunGen.Tags;
using UnityEngine;
using UnityEngine.Serialization;

namespace DunGen;

[AddComponentMenu("DunGen/Doorway")]
public class Doorway : MonoBehaviour, ISerializationCallbackReceiver
{
	public const int CurrentFileVersion = 1;

	public int DoorPrefabPriority;

	public List<GameObjectWeight> ConnectorPrefabWeights = new List<GameObjectWeight>();

	public List<GameObjectWeight> BlockerPrefabWeights = new List<GameObjectWeight>();

	public bool AvoidRotatingDoorPrefab;

	public bool AvoidRotatingBlockerPrefab;

	[FormerlySerializedAs("AddWhenInUse")]
	public List<GameObject> ConnectorSceneObjects = new List<GameObject>();

	[FormerlySerializedAs("AddWhenNotInUse")]
	public List<GameObject> BlockerSceneObjects = new List<GameObject>();

	public TagContainer Tags = new TagContainer();

	public int? LockID;

	[SerializeField]
	[FormerlySerializedAs("SocketGroup")]
	private DoorwaySocketType socketGroup_obsolete = (DoorwaySocketType)(-1);

	[SerializeField]
	[FormerlySerializedAs("DoorPrefabs")]
	private List<GameObject> doorPrefabs_obsolete = new List<GameObject>();

	[SerializeField]
	[FormerlySerializedAs("BlockerPrefabs")]
	private List<GameObject> blockerPrefabs_obsolete = new List<GameObject>();

	[SerializeField]
	private DoorwaySocket socket;

	[SerializeField]
	private GameObject doorPrefabInstance;

	[SerializeField]
	private Door doorComponent;

	[SerializeField]
	private Tile tile;

	[SerializeField]
	private Doorway connectedDoorway;

	[SerializeField]
	private bool hideConditionalObjects;

	[SerializeField]
	private int fileVersion;

	internal bool placedByGenerator;

	public bool HasSocketAssigned => (Object)(object)socket != (Object)null;

	public DoorwaySocket Socket
	{
		get
		{
			if (!((Object)(object)socket != (Object)null))
			{
				return DunGenSettings.Instance.DefaultSocket;
			}
			return socket;
		}
	}

	public Tile Tile
	{
		get
		{
			return tile;
		}
		internal set
		{
			tile = value;
		}
	}

	public bool IsLocked => LockID.HasValue;

	public bool HasDoorPrefabInstance => (Object)(object)doorPrefabInstance != (Object)null;

	public GameObject UsedDoorPrefabInstance => doorPrefabInstance;

	public Door DoorComponent => doorComponent;

	public Dungeon Dungeon { get; internal set; }

	public Doorway ConnectedDoorway
	{
		get
		{
			return connectedDoorway;
		}
		internal set
		{
			connectedDoorway = value;
		}
	}

	public bool HideConditionalObjects
	{
		get
		{
			return hideConditionalObjects;
		}
		set
		{
			hideConditionalObjects = value;
			foreach (GameObject connectorSceneObject in ConnectorSceneObjects)
			{
				if ((Object)(object)connectorSceneObject != (Object)null)
				{
					connectorSceneObject.SetActive(!hideConditionalObjects);
				}
			}
			foreach (GameObject blockerSceneObject in BlockerSceneObjects)
			{
				if ((Object)(object)blockerSceneObject != (Object)null)
				{
					blockerSceneObject.SetActive(!hideConditionalObjects);
				}
			}
		}
	}

	private void OnDrawGizmos()
	{
		if (!placedByGenerator)
		{
			DebugDraw();
		}
	}

	internal void SetUsedPrefab(GameObject doorPrefab)
	{
		doorPrefabInstance = doorPrefab;
		if ((Object)(object)doorPrefab != (Object)null)
		{
			doorComponent = doorPrefab.GetComponent<Door>();
		}
	}

	internal void RemoveUsedPrefab()
	{
		if ((Object)(object)doorPrefabInstance != (Object)null)
		{
			UnityUtil.Destroy((Object)(object)doorPrefabInstance);
		}
		doorPrefabInstance = null;
	}

	internal void DebugDraw()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		Vector2 size = Socket.Size;
		Vector2 val = size * 0.5f;
		float num = Mathf.Min(size.x, size.y);
		Gizmos.color = EditorConstants.DoorDirectionColour;
		Gizmos.DrawLine(((Component)this).transform.position + ((Component)this).transform.up * val.y, ((Component)this).transform.position + ((Component)this).transform.up * val.y + ((Component)this).transform.forward * num);
		Gizmos.color = EditorConstants.DoorUpColour;
		Gizmos.DrawLine(((Component)this).transform.position + ((Component)this).transform.up * val.y, ((Component)this).transform.position + ((Component)this).transform.up * size.y);
		Gizmos.color = EditorConstants.DoorRectColour;
		Vector3 val2 = ((Component)this).transform.position - ((Component)this).transform.right * val.x + ((Component)this).transform.up * size.y;
		Vector3 val3 = ((Component)this).transform.position + ((Component)this).transform.right * val.x + ((Component)this).transform.up * size.y;
		Vector3 val4 = ((Component)this).transform.position - ((Component)this).transform.right * val.x;
		Vector3 val5 = ((Component)this).transform.position + ((Component)this).transform.right * val.x;
		Gizmos.DrawLine(val2, val3);
		Gizmos.DrawLine(val3, val5);
		Gizmos.DrawLine(val5, val4);
		Gizmos.DrawLine(val4, val2);
	}

	public void OnBeforeSerialize()
	{
		fileVersion = 1;
	}

	public void OnAfterDeserialize()
	{
		if (fileVersion >= 1)
		{
			return;
		}
		foreach (GameObject item in doorPrefabs_obsolete)
		{
			ConnectorPrefabWeights.Add(new GameObjectWeight(item));
		}
		foreach (GameObject item2 in blockerPrefabs_obsolete)
		{
			BlockerPrefabWeights.Add(new GameObjectWeight(item2));
		}
		doorPrefabs_obsolete.Clear();
		blockerPrefabs_obsolete.Clear();
	}
}
