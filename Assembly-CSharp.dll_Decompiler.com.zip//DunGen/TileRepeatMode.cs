namespace DunGen;

public enum TileRepeatMode
{
	Allow,
	DisallowImmediate,
	Disallow
}
