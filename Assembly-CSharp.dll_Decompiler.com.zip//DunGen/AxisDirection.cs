using UnityEngine;

namespace DunGen;

public enum AxisDirection
{
	[InspectorName("+X")]
	PosX,
	[InspectorName("-X")]
	NegX,
	[InspectorName("+Y")]
	PosY,
	[InspectorName("-Y")]
	NegY,
	[InspectorName("+Z")]
	PosZ,
	[InspectorName("-Z")]
	NegZ
}
