using System.Collections.Generic;
using System.Linq;
using DunGen.Tags;
using UnityEngine;
using UnityEngine.Serialization;

namespace DunGen;

[AddComponentMenu("DunGen/Tile")]
public class Tile : MonoBehaviour, ISerializationCallbackReceiver
{
	public const int CurrentFileVersion = 1;

	[SerializeField]
	[FormerlySerializedAs("AllowImmediateRepeats")]
	private bool allowImmediateRepeats = true;

	public bool AllowRotation = true;

	public TileRepeatMode RepeatMode;

	public bool OverrideAutomaticTileBounds;

	public Bounds TileBoundsOverride = new Bounds(Vector3.zero, Vector3.one);

	public Doorway Entrance;

	public Doorway Exit;

	public bool OverrideConnectionChance;

	public float ConnectionChance;

	public TagContainer Tags = new TagContainer();

	public List<Doorway> AllDoorways = new List<Doorway>();

	public List<Doorway> UsedDoorways = new List<Doorway>();

	public List<Doorway> UnusedDoorways = new List<Doorway>();

	[SerializeField]
	private TilePlacementData placement;

	[SerializeField]
	private int fileVersion;

	[HideInInspector]
	public Bounds Bounds => ((Component)this).transform.TransformBounds(Placement.LocalBounds);

	public TilePlacementData Placement
	{
		get
		{
			return placement;
		}
		internal set
		{
			placement = value;
		}
	}

	public Dungeon Dungeon { get; internal set; }

	internal void AddTriggerVolume()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		BoxCollider obj = ((Component)this).gameObject.AddComponent<BoxCollider>();
		Bounds localBounds = Placement.LocalBounds;
		obj.center = ((Bounds)(ref localBounds)).center;
		localBounds = Placement.LocalBounds;
		obj.size = ((Bounds)(ref localBounds)).size;
		((Collider)obj).isTrigger = true;
	}

	private void OnTriggerEnter(Collider other)
	{
		if (!((Object)(object)other == (Object)null))
		{
			DungenCharacter component = ((Component)other).gameObject.GetComponent<DungenCharacter>();
			if ((Object)(object)component != (Object)null)
			{
				component.OnTileEntered(this);
			}
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (!((Object)(object)other == (Object)null))
		{
			DungenCharacter component = ((Component)other).gameObject.GetComponent<DungenCharacter>();
			if ((Object)(object)component != (Object)null)
			{
				component.OnTileExited(this);
			}
		}
	}

	private void OnDrawGizmosSelected()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.color = Color.red;
		Bounds? val = null;
		if (OverrideAutomaticTileBounds)
		{
			val = ((Component)this).transform.TransformBounds(TileBoundsOverride);
		}
		else if (placement != null)
		{
			val = Bounds;
		}
		if (val.HasValue)
		{
			Bounds value = val.Value;
			Vector3 center = ((Bounds)(ref value)).center;
			value = val.Value;
			Gizmos.DrawWireCube(center, ((Bounds)(ref value)).size);
		}
	}

	public IEnumerable<Tile> GetAdjactedTiles()
	{
		return UsedDoorways.Select((Doorway x) => x.ConnectedDoorway.Tile).Distinct();
	}

	public bool IsAdjacentTo(Tile other)
	{
		foreach (Doorway usedDoorway in UsedDoorways)
		{
			if ((Object)(object)usedDoorway.ConnectedDoorway.Tile == (Object)(object)other)
			{
				return true;
			}
		}
		return false;
	}

	public Doorway GetEntranceDoorway()
	{
		foreach (Doorway usedDoorway in UsedDoorways)
		{
			Tile tile = usedDoorway.ConnectedDoorway.Tile;
			if (Placement.IsOnMainPath)
			{
				if (tile.Placement.IsOnMainPath && Placement.PathDepth > tile.Placement.PathDepth)
				{
					return usedDoorway;
				}
			}
			else if (tile.Placement.IsOnMainPath || Placement.Depth > tile.Placement.Depth)
			{
				return usedDoorway;
			}
		}
		return null;
	}

	public Doorway GetExitDoorway()
	{
		foreach (Doorway usedDoorway in UsedDoorways)
		{
			Tile tile = usedDoorway.ConnectedDoorway.Tile;
			if (Placement.IsOnMainPath)
			{
				if (tile.Placement.IsOnMainPath && Placement.PathDepth < tile.Placement.PathDepth)
				{
					return usedDoorway;
				}
			}
			else if (!tile.Placement.IsOnMainPath && Placement.Depth < tile.Placement.Depth)
			{
				return usedDoorway;
			}
		}
		return null;
	}

	public void OnBeforeSerialize()
	{
		fileVersion = 1;
	}

	public void OnAfterDeserialize()
	{
		if (fileVersion < 1)
		{
			RepeatMode = ((!allowImmediateRepeats) ? TileRepeatMode.DisallowImmediate : TileRepeatMode.Allow);
		}
	}
}
