using UnityEngine;

namespace DunGen;

public sealed class DoorwayProxy
{
	public bool Used => ConnectedDoorway != null;

	public TileProxy TileProxy { get; private set; }

	public int Index { get; private set; }

	public DoorwaySocket Socket { get; private set; }

	public Doorway DoorwayComponent { get; private set; }

	public Vector3 LocalPosition { get; private set; }

	public Quaternion LocalRotation { get; private set; }

	public DoorwayProxy ConnectedDoorway { get; private set; }

	public Vector3 Forward => TileProxy.Placement.Rotation * LocalRotation * Vector3.forward;

	public Vector3 Up => TileProxy.Placement.Rotation * LocalRotation * Vector3.up;

	public Vector3 Position
	{
		get
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			Matrix4x4 transform = TileProxy.Placement.Transform;
			return ((Matrix4x4)(ref transform)).MultiplyPoint(LocalPosition);
		}
	}

	public DoorwayProxy(TileProxy tileProxy, DoorwayProxy other)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		TileProxy = tileProxy;
		Index = other.Index;
		Socket = other.Socket;
		DoorwayComponent = other.DoorwayComponent;
		LocalPosition = other.LocalPosition;
		LocalRotation = other.LocalRotation;
	}

	public DoorwayProxy(TileProxy tileProxy, int index, Doorway doorwayComponent, Vector3 localPosition, Quaternion localRotation)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		TileProxy = tileProxy;
		Index = index;
		Socket = doorwayComponent.Socket;
		DoorwayComponent = doorwayComponent;
		LocalPosition = localPosition;
		LocalRotation = localRotation;
	}

	public static void Connect(DoorwayProxy a, DoorwayProxy b)
	{
		a.ConnectedDoorway = b;
		b.ConnectedDoorway = a;
	}

	public void Disconnect()
	{
		if (ConnectedDoorway != null)
		{
			ConnectedDoorway.ConnectedDoorway = null;
			ConnectedDoorway = null;
		}
	}
}
