namespace DunGen;

public enum TilePlacementResult
{
	None,
	NoFromDoorway,
	NoTilesWithMatchingDoorway,
	NoValidTile,
	TemplateIsNull,
	NoMatchingDoorwayInTile,
	TileIsColliding,
	NewTileIsNull,
	OutOfBounds
}
