using Discord;
using UnityEngine;

public class DiscordController : MonoBehaviour
{
	public Discord discord;

	public string status_Details = "In Menu";

	public string status_State;

	public string status_largeText;

	public string status_smallText;

	public string status_largeImage;

	public string status_smallImage;

	public int currentPartySize;

	public int maxPartySize = 4;

	public int timeElapsed;

	public string status_partyId;

	private float timeAtLastStatusUpdate;

	private bool activityEnabled;

	private bool appQuitting;

	public static DiscordController Instance { get; private set; }

	private void Awake()
	{
		if ((Object)(object)Instance == (Object)null)
		{
			Instance = this;
		}
		else
		{
			Object.Destroy((Object)(object)this);
		}
	}

	private void Start()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected O, but got Unknown
		discord = new Discord(1174275017694007318L, 1uL);
		Application.quitting += Application_quitting;
	}

	private void OnDisable()
	{
		Application.quitting -= Application_quitting;
		discord.Dispose();
	}

	private void Application_quitting()
	{
		appQuitting = true;
	}

	private void Update()
	{
		try
		{
			discord.RunCallbacks();
		}
		catch
		{
			Object.Destroy((Object)(object)this);
		}
	}

	public void UpdateStatus(bool clear)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Expected O, but got Unknown
		if ((clear && !activityEnabled) || Time.realtimeSinceStartup - timeAtLastStatusUpdate < 2f)
		{
			return;
		}
		timeAtLastStatusUpdate = Time.realtimeSinceStartup;
		try
		{
			ActivityManager activityManager = discord.GetActivityManager();
			activityManager.RegisterSteam(1966720u);
			Activity val = new Activity
			{
				Details = status_Details,
				State = status_State,
				Assets = 
				{
					LargeImage = status_largeImage
				},
				Assets = 
				{
					LargeText = status_largeText
				},
				Assets = 
				{
					SmallImage = status_smallImage
				},
				Assets = 
				{
					SmallText = status_smallText
				},
				Party = 
				{
					Id = status_partyId
				},
				Party = 
				{
					Size = 
					{
						CurrentSize = currentPartySize
					}
				},
				Party = 
				{
					Size = 
					{
						MaxSize = maxPartySize
					}
				}
			};
			if (clear)
			{
				val.Details = "In menu";
				val.State = "";
				val.Party.Size.CurrentSize = 1;
			}
			activityManager.UpdateActivity(val, (UpdateActivityHandler)delegate(Result result)
			{
				//IL_0000: Unknown result type (might be due to invalid IL or missing references)
				if ((int)result != 0)
				{
					Debug.LogWarning((object)"Error while updating Discord activity status!");
				}
				else
				{
					activityEnabled = true;
				}
			});
		}
		catch
		{
			Object.Destroy((Object)(object)this);
		}
	}
}
