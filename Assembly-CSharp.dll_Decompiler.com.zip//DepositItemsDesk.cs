using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class DepositItemsDesk : NetworkBehaviour, INoiseListener
{
	public bool inGrabbingObjectsAnimation = true;

	public bool attacking;

	public bool doorOpen;

	private float noiseBehindWallVolume = 1f;

	[Space(3f)]
	public CompanyMood[] allMoodPresets;

	public CompanyMood currentMood;

	public float patienceLevel;

	public float timesHearingNoise;

	[Space(3f)]
	public float grabObjectsWaitTime = 10f;

	private float grabObjectsTimer = 10f;

	[Space(5f)]
	public NetworkObject deskObjectsContainer;

	public BoxCollider triggerCollider;

	public InteractTrigger triggerScript;

	public List<GrabbableObject> itemsOnCounter = new List<GrabbableObject>();

	public List<NetworkObject> itemsOnCounterNetworkObjects = new List<NetworkObject>();

	public int itemsOnCounterAmount;

	public Animator depositDeskAnimator;

	private NetworkObject lastObjectAddedToDesk;

	private Coroutine acceptItemsCoroutine;

	private int angerSFXindex;

	private int clientsRecievedSellItemsRPC;

	private float updateInterval;

	private Random CompanyLevelRandom;

	[Header("AUDIOS")]
	public AudioSource deskAudio;

	[Header("AUDIOS")]
	public AudioSource wallAudio;

	[Header("AUDIOS")]
	public AudioSource constantWallAudio;

	[Header("AUDIOS")]
	public AudioSource doorWindowAudio;

	public AudioClip[] microphoneAudios;

	public AudioClip[] rareMicrophoneAudios;

	public AudioClip doorOpenSFX;

	public AudioClip doorShutSFX;

	public AudioClip rumbleSFX;

	public AudioClip rewardGood;

	public AudioClip rewardBad;

	public AudioSource rewardsMusic;

	public AudioSource speakerAudio;

	[Header("Attack animations")]
	public MonsterAnimation[] monsterAnimations;

	public float killAnimationTimer;

	public float timeSinceAttacking;

	public int playersKilled;

	private float timeSinceMakingWarningNoise;

	private float waitingWithDoorOpenTimer;

	private float timeSinceLoweringPatience;

	private bool inSellingItemsAnimation;

	private void Start()
	{
		grabObjectsTimer = grabObjectsWaitTime;
		CompanyLevelRandom = new Random(StartOfRound.Instance.randomMapSeed + 39);
		SetCompanyMood(TimeOfDay.Instance.currentCompanyMood);
	}

	private void SetCompanyMood(CompanyMood mood)
	{
		currentMood = mood;
		doorWindowAudio.clip = mood.insideWindowSFX;
		doorWindowAudio.Play();
		patienceLevel = mood.startingPatience;
		((MonoBehaviour)this).StartCoroutine(waitForRoundToStart(mood));
	}

	private IEnumerator waitForRoundToStart(CompanyMood mood)
	{
		yield return (object)new WaitUntil((Func<bool>)(() => StartOfRound.Instance.shipDoorsEnabled));
		yield return null;
		if ((Object)(object)mood.behindWallSFX != (Object)null)
		{
			constantWallAudio.clip = mood.behindWallSFX;
			constantWallAudio.Play();
		}
	}

	public void PlaceItemOnCounter(PlayerControllerB playerWhoTriggered)
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		if (((Component)deskObjectsContainer).GetComponentsInChildren<GrabbableObject>().Length < 150 && !inGrabbingObjectsAnimation && (Object)(object)GameNetworkManager.Instance != (Object)null && (Object)(object)playerWhoTriggered == (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			Vector3 val = RoundManager.RandomPointInBounds(((Collider)triggerCollider).bounds);
			Bounds bounds = ((Collider)triggerCollider).bounds;
			val.y = ((Bounds)(ref bounds)).min.y;
			RaycastHit val2 = default(RaycastHit);
			if (Physics.Raycast(new Ray(val + Vector3.up * 3f, Vector3.down), ref val2, 8f, 1048640, (QueryTriggerInteraction)2))
			{
				val = ((RaycastHit)(ref val2)).point;
			}
			val.y += playerWhoTriggered.currentlyHeldObjectServer.itemProperties.verticalOffset;
			val = ((Component)deskObjectsContainer).transform.InverseTransformPoint(val);
			AddObjectToDeskServerRpc(NetworkObjectReference.op_Implicit(((Component)playerWhoTriggered.currentlyHeldObjectServer).gameObject.GetComponent<NetworkObject>()));
			playerWhoTriggered.DiscardHeldObject(placeObject: true, deskObjectsContainer, val, matchRotationOfParent: false);
			Debug.Log((object)"discard held object called from deposit items desk");
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void AddObjectToDeskServerRpc(NetworkObjectReference grabbableObjectNetObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4150038830u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref grabbableObjectNetObject, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4150038830u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		if (((NetworkObjectReference)(ref grabbableObjectNetObject)).TryGet(ref lastObjectAddedToDesk, (NetworkManager)null))
		{
			if (!itemsOnCounter.Contains(((Component)lastObjectAddedToDesk).GetComponentInChildren<GrabbableObject>()))
			{
				itemsOnCounterNetworkObjects.Add(lastObjectAddedToDesk);
				itemsOnCounter.Add(((Component)lastObjectAddedToDesk).GetComponentInChildren<GrabbableObject>());
				AddObjectToDeskClientRpc(grabbableObjectNetObject);
				grabObjectsTimer = Mathf.Clamp(grabObjectsTimer + 6f, 0f, 10f);
				if (!doorOpen && (!currentMood.mustBeWokenUp || timesHearingNoise >= 5f))
				{
					OpenShutDoorClientRpc();
				}
			}
		}
		else
		{
			Debug.LogError((object)"ServerRpc: Could not find networkobject in the object that was placed on desk.");
		}
	}

	[ClientRpc]
	public void AddObjectToDeskClientRpc(NetworkObjectReference grabbableObjectNetObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3889142070u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref grabbableObjectNetObject, default(ForNetworkSerializable));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3889142070u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkObjectReference)(ref grabbableObjectNetObject)).TryGet(ref lastObjectAddedToDesk, (NetworkManager)null))
			{
				((Component)lastObjectAddedToDesk).gameObject.GetComponentInChildren<GrabbableObject>().EnablePhysics(enable: false);
			}
			else
			{
				Debug.LogError((object)"ClientRpc: Could not find networkobject in the object that was placed on desk.");
			}
		}
	}

	private void Update()
	{
		if ((Object)(object)NetworkManager.Singleton == (Object)null)
		{
			return;
		}
		UpdateEffects();
		if (attacking)
		{
			if (killAnimationTimer <= 0f)
			{
				FinishKillAnimation();
			}
			else
			{
				TimeOfDay.Instance.TimeOfDayMusic.volume = Mathf.Lerp(TimeOfDay.Instance.TimeOfDayMusic.volume, 0f, 10f * Time.deltaTime);
				killAnimationTimer -= Time.deltaTime;
			}
		}
		triggerScript.interactable = GameNetworkManager.Instance.localPlayerController.isHoldingObject;
		GrabbableObject[] componentsInChildren = ((Component)this).gameObject.GetComponentsInChildren<GrabbableObject>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if (componentsInChildren[i].grabbable)
			{
				componentsInChildren[i].grabbable = false;
			}
		}
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		timeSinceAttacking += Time.deltaTime;
		if (itemsOnCounter.Count > 0 && !inGrabbingObjectsAnimation && !attacking)
		{
			if (doorOpen)
			{
				if (grabObjectsTimer >= 0f)
				{
					Debug.Log((object)$"Desk: Waiting to grab the items on the desk; {grabObjectsTimer}");
					grabObjectsTimer -= Time.deltaTime;
				}
				else
				{
					grabObjectsTimer = grabObjectsWaitTime;
					TakeItemsOffCounterOnServer();
				}
			}
		}
		else
		{
			if (!(timeSinceAttacking > 25f) || attacking || !doorOpen || itemsOnCounter.Count > 0)
			{
				return;
			}
			waitingWithDoorOpenTimer += Time.deltaTime;
			Debug.Log((object)$"Desk: no objects on counter, waiting with door open; {waitingWithDoorOpenTimer}");
			if (waitingWithDoorOpenTimer > 8f / currentMood.irritability)
			{
				waitingWithDoorOpenTimer = 0f;
				float num = patienceLevel;
				SetPatienceServerRpc(-1f * currentMood.irritability);
				if (num - currentMood.irritability > 0f)
				{
					OpenShutDoorClientRpc(open: false);
				}
			}
		}
	}

	private void UpdateEffects()
	{
		timeSinceLoweringPatience += Time.deltaTime;
		timeSinceMakingWarningNoise += Time.deltaTime;
		if (doorOpen)
		{
			doorWindowAudio.volume = Mathf.Lerp(doorWindowAudio.volume, 1f * noiseBehindWallVolume, 3f * Time.deltaTime);
		}
		else
		{
			doorWindowAudio.volume = Mathf.Lerp(doorWindowAudio.volume, 0f, 10f * Time.deltaTime);
		}
		if (attacking || (currentMood.stopWallSFXWhenOpening && doorOpen))
		{
			constantWallAudio.volume = Mathf.Lerp(constantWallAudio.volume, 0f, 15f * Time.deltaTime);
		}
		else
		{
			constantWallAudio.volume = Mathf.Lerp(constantWallAudio.volume, 1f, Time.deltaTime);
		}
	}

	private void TakeItemsOffCounterOnServer()
	{
		inGrabbingObjectsAnimation = true;
		TakeObjectsClientRpc();
	}

	[ClientRpc]
	public void TakeObjectsClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3132539150u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3132539150u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			inGrabbingObjectsAnimation = true;
			depositDeskAnimator.SetBool("GrabbingItems", true);
			deskAudio.PlayOneShot(currentMood.grabItemsSFX[Random.Range(0, currentMood.grabItemsSFX.Length)]);
			GrabbableObject[] componentsInChildren = ((Component)deskObjectsContainer).GetComponentsInChildren<GrabbableObject>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].ReactToSellingItemOnCounter();
			}
		}
	}

	public void SellItemsOnServer()
	{
		if (!((NetworkBehaviour)this).IsServer)
		{
			return;
		}
		inSellingItemsAnimation = true;
		int num = 0;
		for (int i = 0; i < itemsOnCounter.Count; i++)
		{
			if (!itemsOnCounter[i].itemProperties.isScrap)
			{
				if (itemsOnCounter[i].itemUsedUp)
				{
				}
			}
			else
			{
				num += itemsOnCounter[i].scrapValue;
			}
		}
		num = (int)((float)num * StartOfRound.Instance.companyBuyingRate);
		Terminal terminal = Object.FindObjectOfType<Terminal>();
		terminal.groupCredits += num;
		SellItemsClientRpc(num, terminal.groupCredits, itemsOnCounterAmount, StartOfRound.Instance.companyBuyingRate);
		SellAndDisplayItemProfits(num, terminal.groupCredits);
	}

	[ClientRpc]
	public void SellItemsClientRpc(int itemProfit, int newGroupCredits, int itemsSold, float buyingRate)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3628265478u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, itemProfit);
				BytePacker.WriteValueBitPacked(val2, newGroupCredits);
				BytePacker.WriteValueBitPacked(val2, itemsSold);
				((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref buyingRate, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3628265478u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer)
			{
				itemsOnCounterAmount = itemsSold;
				StartOfRound.Instance.companyBuyingRate = buyingRate;
				SellAndDisplayItemProfits(itemProfit, newGroupCredits);
			}
		}
	}

	private void SellAndDisplayItemProfits(int profit, int newGroupCredits)
	{
		Object.FindObjectOfType<Terminal>().groupCredits = newGroupCredits;
		StartOfRound.Instance.gameStats.scrapValueCollected += profit;
		TimeOfDay.Instance.quotaFulfilled += profit;
		GrabbableObject[] componentsInChildren = ((Component)deskObjectsContainer).GetComponentsInChildren<GrabbableObject>();
		if (acceptItemsCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(acceptItemsCoroutine);
		}
		acceptItemsCoroutine = ((MonoBehaviour)this).StartCoroutine(delayedAcceptanceOfItems(profit, componentsInChildren, newGroupCredits));
		CheckAllPlayersSoldItemsServerRpc();
	}

	[ServerRpc(RequireOwnership = false)]
	public void CheckAllPlayersSoldItemsServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1114072420u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1114072420u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost))
		{
			return;
		}
		clientsRecievedSellItemsRPC++;
		if (clientsRecievedSellItemsRPC < GameNetworkManager.Instance.connectedPlayers)
		{
			return;
		}
		clientsRecievedSellItemsRPC = 0;
		for (int i = 0; i < itemsOnCounterNetworkObjects.Count; i++)
		{
			if (itemsOnCounterNetworkObjects[i].IsSpawned)
			{
				itemsOnCounterNetworkObjects[i].Despawn(true);
			}
		}
		itemsOnCounterNetworkObjects.Clear();
		itemsOnCounter.Clear();
		FinishSellingItemsClientRpc();
	}

	[ClientRpc]
	public void FinishSellingItemsClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2469293577u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2469293577u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				depositDeskAnimator.SetBool("GrabbingItems", false);
				inGrabbingObjectsAnimation = false;
			}
		}
	}

	private IEnumerator delayedAcceptanceOfItems(int profit, GrabbableObject[] objectsOnDesk, int newGroupCredits)
	{
		yield return (object)new WaitUntil((Func<bool>)(() => !inGrabbingObjectsAnimation));
		noiseBehindWallVolume = 0.3f;
		yield return (object)new WaitForSeconds(currentMood.judgementSpeed);
		if ((float)(profit / Mathf.Max(objectsOnDesk.Length, 1)) <= 3f && patienceLevel <= 2f)
		{
			Random random = new Random(objectsOnDesk.Length + newGroupCredits);
			if (!attacking && random.Next(0, 100) < 30)
			{
				Attack();
				yield return (object)new WaitUntil((Func<bool>)(() => !attacking));
				yield return (object)new WaitForSeconds(2f);
			}
		}
		else
		{
			patienceLevel += 3f;
		}
		OpenShutDoor(open: false);
		yield return (object)new WaitForSeconds(0.5f);
		noiseBehindWallVolume = 1f;
		HUDManager.Instance.DisplayCreditsEarning(profit, objectsOnDesk, newGroupCredits);
		PlayRewardEffects(profit);
		yield return (object)new WaitForSeconds(1.25f);
		MicrophoneSpeak();
		inSellingItemsAnimation = false;
		itemsOnCounterAmount = 0;
	}

	private void PlayRewardEffects(int profit)
	{
		Terminal terminal = Object.FindObjectOfType<Terminal>();
		TimeOfDay.Instance.UpdateProfitQuotaCurrentTime();
		if ((float)profit < (float)terminal.groupCredits / 4f)
		{
			rewardsMusic.PlayOneShot(rewardBad);
		}
		else
		{
			rewardsMusic.PlayOneShot(rewardGood);
		}
	}

	private void MicrophoneSpeak()
	{
		AudioClip val = ((!(CompanyLevelRandom.NextDouble() < 0.029999999329447746)) ? microphoneAudios[CompanyLevelRandom.Next(0, microphoneAudios.Length)] : rareMicrophoneAudios[CompanyLevelRandom.Next(0, rareMicrophoneAudios.Length)]);
		speakerAudio.PlayOneShot(val, 1f);
	}

	[ServerRpc(RequireOwnership = false)]
	public void AttackPlayersServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3230280218u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3230280218u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !attacking && !inGrabbingObjectsAnimation)
			{
				attacking = true;
				AttackPlayersClientRpc();
			}
		}
	}

	[ClientRpc]
	public void AttackPlayersClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3277367259u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3277367259u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				Attack();
			}
		}
	}

	public void Attack()
	{
		attacking = true;
		timeSinceAttacking = 0f;
		patienceLevel += 6f;
		if (!doorOpen)
		{
			OpenShutDoor(open: true);
		}
		for (int i = 0; i < monsterAnimations.Length; i++)
		{
			if (currentMood.enableMonsterAnimationIndex == null)
			{
				Debug.Log((object)"Current company monster mood has no monster animations to enable.");
				attacking = false;
				return;
			}
			if (i == currentMood.enableMonsterAnimationIndex[i])
			{
				monsterAnimations[i].monsterAnimator.SetBool("visible", true);
			}
		}
		switch (currentMood.manifestation)
		{
		case CompanyMonster.Tentacles:
			Debug.Log((object)"Tentacles appear");
			killAnimationTimer = 3f;
			break;
		case CompanyMonster.Tongue:
			Debug.Log((object)"Giant tongue appears");
			killAnimationTimer = 2f;
			break;
		case CompanyMonster.GiantHand:
			Debug.Log((object)"Giant hand appears and searches");
			killAnimationTimer = 3f;
			break;
		}
		MakeLoudNoise(2);
	}

	public void CollisionDetect(int monsterAnimationID)
	{
		if (attacking && !monsterAnimations[monsterAnimationID].animatorCollidedOnClient)
		{
			monsterAnimations[monsterAnimationID].animatorCollidedOnClient = true;
			if (((NetworkBehaviour)this).IsServer)
			{
				ConfirmAnimationGrabPlayerClientRpc(monsterAnimationID, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
			else
			{
				CheckAnimationGrabPlayerServerRpc(monsterAnimationID, (int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
			switch (currentMood.manifestation)
			{
			case CompanyMonster.Tentacles:
				Debug.Log((object)"Tentacle collision");
				break;
			case CompanyMonster.Tongue:
				Debug.Log((object)"Tongue collision");
				break;
			case CompanyMonster.GiantHand:
				Debug.Log((object)"Hand collision");
				break;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void CheckAnimationGrabPlayerServerRpc(int monsterAnimationID, int playerID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1392297385u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, monsterAnimationID);
				BytePacker.WriteValueBitPacked(val2, playerID);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1392297385u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && !monsterAnimations[monsterAnimationID].animatorCollidedOnClient)
			{
				monsterAnimations[monsterAnimationID].animatorCollidedOnClient = true;
				ConfirmAnimationGrabPlayerClientRpc(monsterAnimationID, playerID);
			}
		}
	}

	[ClientRpc]
	public void ConfirmAnimationGrabPlayerClientRpc(int monsterAnimationID, int playerID)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3034180067u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, monsterAnimationID);
				BytePacker.WriteValueBitPacked(val2, playerID);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3034180067u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				monsterAnimations[monsterAnimationID].animatorCollidedOnClient = true;
				((MonoBehaviour)this).StartCoroutine(AnimationGrabPlayer(monsterAnimationID, playerID));
			}
		}
	}

	private IEnumerator AnimationGrabPlayer(int monsterAnimationID, int playerID)
	{
		Animator monsterAnimator = monsterAnimations[monsterAnimationID].monsterAnimator;
		Transform monsterAnimatorGrabTarget = monsterAnimations[monsterAnimationID].monsterAnimatorGrabTarget;
		PlayerControllerB playerDying = StartOfRound.Instance.allPlayerScripts[playerID];
		monsterAnimator.SetBool("grabbingPlayer", true);
		monsterAnimatorGrabTarget.position = ((Component)playerDying).transform.position;
		yield return (object)new WaitForSeconds(0.05f);
		if (((NetworkBehaviour)playerDying).IsOwner)
		{
			playerDying.KillPlayer(Vector3.zero);
		}
		float startTime = Time.timeSinceLevelLoad;
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)playerDying.deadBody != (Object)null || Time.timeSinceLevelLoad - startTime > 4f));
		if ((Object)(object)playerDying.deadBody != (Object)null)
		{
			playerDying.deadBody.attachedTo = monsterAnimations[monsterAnimationID].monsterAnimatorGrabPoint;
			playerDying.deadBody.attachedLimb = playerDying.deadBody.bodyParts[6];
			playerDying.deadBody.matchPositionExactly = true;
		}
		else
		{
			Debug.Log((object)"Player body was not spawned in time for animation.");
		}
		monsterAnimator.SetBool("grabbingPlayer", false);
		yield return (object)new WaitForSeconds(currentMood.grabPlayerAnimationTime);
		if ((Object)(object)playerDying.deadBody != (Object)null)
		{
			playerDying.deadBody.attachedTo = null;
			playerDying.deadBody.attachedLimb = null;
			playerDying.deadBody.matchPositionExactly = false;
			((Component)playerDying.deadBody).gameObject.SetActive(false);
		}
		playersKilled++;
		if (playersKilled >= currentMood.maxPlayersToKillBeforeSatisfied)
		{
			FinishKillAnimation();
		}
	}

	public void FinishKillAnimation()
	{
		attacking = false;
		for (int i = 0; i < monsterAnimations.Length; i++)
		{
			monsterAnimations[i].animatorCollidedOnClient = false;
			monsterAnimations[i].monsterAnimator.SetBool("visible", false);
		}
		switch (currentMood.manifestation)
		{
		case CompanyMonster.Tentacles:
			Debug.Log((object)"Tentacles finishing animation");
			break;
		case CompanyMonster.Tongue:
			Debug.Log((object)"Tongue finishing animation");
			break;
		case CompanyMonster.GiantHand:
			Debug.Log((object)"Hand finishing animation");
			break;
		}
		((MonoBehaviour)this).StartCoroutine(closeDoorAfterDelay());
	}

	private IEnumerator closeDoorAfterDelay()
	{
		yield return (object)new WaitForSeconds(1f);
		OpenShutDoor(open: false);
	}

	void INoiseListener.DetectNoise(Vector3 noisePosition, float noiseLoudness = 0.5f, int timesPlayedInOneSpot = 0, int noiseID = 0)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (noiseID != 941 && noiseID != 2692 && !(Vector3.Distance(((Component)triggerCollider).transform.position, noisePosition) > 9f) && !(noiseLoudness <= 0.4f))
		{
			if (currentMood.mustBeWokenUp && !doorOpen)
			{
				SetTimesHeardNoiseServerRpc(currentMood.sensitivity * (noiseLoudness + 0.3f) / (float)(StartOfRound.Instance.connectedPlayersAmount + 1));
			}
			else if (currentMood.desiresSilence && timeSinceLoweringPatience > 1f)
			{
				SetPatienceServerRpc(-1f * (currentMood.irritability / 2f) * noiseLoudness);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetPatienceServerRpc(float valueChange)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(892728304u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref valueChange, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 892728304u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage != 1 || (!networkManager.IsServer && !networkManager.IsHost) || inSellingItemsAnimation)
		{
			return;
		}
		patienceLevel += valueChange;
		if (patienceLevel <= 0f)
		{
			if (attacking || inGrabbingObjectsAnimation)
			{
				return;
			}
			if (Random.Range(0, 100) < 50)
			{
				attacking = true;
				AttackPlayersClientRpc();
				return;
			}
			patienceLevel += 3f;
			if (itemsOnCounter.Count <= 0 && timeSinceLoweringPatience > 2f)
			{
				OpenShutDoorClientRpc(open: false);
			}
		}
		else if (valueChange < 0f && patienceLevel < 1f && timeSinceMakingWarningNoise > 1f)
		{
			MakeWarningNoiseClientRpc();
		}
	}

	[ClientRpc]
	public void MakeWarningNoiseClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(103348088u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 103348088u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				timeSinceMakingWarningNoise = 0f;
				MakeLoudNoise(1);
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SetTimesHeardNoiseServerRpc(float valueChange)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(745684781u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<float>(ref valueChange, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 745684781u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			Debug.Log((object)"NOISE D");
			timesHearingNoise += valueChange;
			if (timesHearingNoise >= 5f && !doorOpen)
			{
				timesHearingNoise = 0f;
				doorOpen = true;
				OpenShutDoorClientRpc();
				timeSinceLoweringPatience = 2.6f;
			}
		}
	}

	[ClientRpc]
	public void OpenShutDoorClientRpc(bool open = true)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1191125720u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref open, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1191125720u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				OpenShutDoor(open);
			}
		}
	}

	public void OpenShutDoor(bool open)
	{
		doorOpen = open;
		depositDeskAnimator.SetBool("doorOpen", open);
		if (open)
		{
			deskAudio.PlayOneShot(doorOpenSFX);
		}
		else
		{
			deskAudio.PlayOneShot(doorShutSFX);
		}
	}

	public void MakeLoudNoise(int noise)
	{
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		switch (noise)
		{
		case 2:
		{
			int num = Random.Range(0, currentMood.attackSFX.Length);
			deskAudio.PlayOneShot(currentMood.attackSFX[num]);
			WalkieTalkie.TransmitOneShotAudio(deskAudio, currentMood.attackSFX[num]);
			wallAudio.PlayOneShot(currentMood.wallAttackSFX);
			if (Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)deskAudio).transform.position) < 12f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.VeryStrong);
			}
			else
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			}
			break;
		}
		case 1:
			wallAudio.PlayOneShot(rumbleSFX);
			if (doorOpen)
			{
				deskAudio.PlayOneShot(currentMood.angerSFX[angerSFXindex]);
				angerSFXindex = (angerSFXindex + 1) % currentMood.angerSFX.Length;
			}
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			break;
		default:
			wallAudio.PlayOneShot(currentMood.noiseBehindWallSFX);
			HUDManager.Instance.ShakeCamera(ScreenShakeType.Big);
			break;
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_DepositItemsDesk()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Expected O, but got Unknown
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Expected O, but got Unknown
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected O, but got Unknown
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(4150038830u, new RpcReceiveHandler(__rpc_handler_4150038830));
		NetworkManager.__rpc_func_table.Add(3889142070u, new RpcReceiveHandler(__rpc_handler_3889142070));
		NetworkManager.__rpc_func_table.Add(3132539150u, new RpcReceiveHandler(__rpc_handler_3132539150));
		NetworkManager.__rpc_func_table.Add(3628265478u, new RpcReceiveHandler(__rpc_handler_3628265478));
		NetworkManager.__rpc_func_table.Add(1114072420u, new RpcReceiveHandler(__rpc_handler_1114072420));
		NetworkManager.__rpc_func_table.Add(2469293577u, new RpcReceiveHandler(__rpc_handler_2469293577));
		NetworkManager.__rpc_func_table.Add(3230280218u, new RpcReceiveHandler(__rpc_handler_3230280218));
		NetworkManager.__rpc_func_table.Add(3277367259u, new RpcReceiveHandler(__rpc_handler_3277367259));
		NetworkManager.__rpc_func_table.Add(1392297385u, new RpcReceiveHandler(__rpc_handler_1392297385));
		NetworkManager.__rpc_func_table.Add(3034180067u, new RpcReceiveHandler(__rpc_handler_3034180067));
		NetworkManager.__rpc_func_table.Add(892728304u, new RpcReceiveHandler(__rpc_handler_892728304));
		NetworkManager.__rpc_func_table.Add(103348088u, new RpcReceiveHandler(__rpc_handler_103348088));
		NetworkManager.__rpc_func_table.Add(745684781u, new RpcReceiveHandler(__rpc_handler_745684781));
		NetworkManager.__rpc_func_table.Add(1191125720u, new RpcReceiveHandler(__rpc_handler_1191125720));
	}

	private static void __rpc_handler_4150038830(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference grabbableObjectNetObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref grabbableObjectNetObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((DepositItemsDesk)(object)target).AddObjectToDeskServerRpc(grabbableObjectNetObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3889142070(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference grabbableObjectNetObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref grabbableObjectNetObject, default(ForNetworkSerializable));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DepositItemsDesk)(object)target).AddObjectToDeskClientRpc(grabbableObjectNetObject);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3132539150(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DepositItemsDesk)(object)target).TakeObjectsClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3628265478(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int itemProfit = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref itemProfit);
			int newGroupCredits = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref newGroupCredits);
			int itemsSold = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref itemsSold);
			float buyingRate = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref buyingRate, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DepositItemsDesk)(object)target).SellItemsClientRpc(itemProfit, newGroupCredits, itemsSold, buyingRate);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1114072420(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((DepositItemsDesk)(object)target).CheckAllPlayersSoldItemsServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2469293577(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DepositItemsDesk)(object)target).FinishSellingItemsClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3230280218(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((DepositItemsDesk)(object)target).AttackPlayersServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3277367259(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DepositItemsDesk)(object)target).AttackPlayersClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1392297385(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int monsterAnimationID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref monsterAnimationID);
			int playerID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerID);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((DepositItemsDesk)(object)target).CheckAnimationGrabPlayerServerRpc(monsterAnimationID, playerID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3034180067(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int monsterAnimationID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref monsterAnimationID);
			int playerID = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerID);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DepositItemsDesk)(object)target).ConfirmAnimationGrabPlayerClientRpc(monsterAnimationID, playerID);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_892728304(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float patienceServerRpc = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref patienceServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((DepositItemsDesk)(object)target).SetPatienceServerRpc(patienceServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_103348088(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DepositItemsDesk)(object)target).MakeWarningNoiseClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_745684781(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			float timesHeardNoiseServerRpc = default(float);
			((FastBufferReader)(ref reader)).ReadValueSafe<float>(ref timesHeardNoiseServerRpc, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((DepositItemsDesk)(object)target).SetTimesHeardNoiseServerRpc(timesHeardNoiseServerRpc);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1191125720(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool open = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref open, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((DepositItemsDesk)(object)target).OpenShutDoorClientRpc(open);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "DepositItemsDesk";
	}
}
