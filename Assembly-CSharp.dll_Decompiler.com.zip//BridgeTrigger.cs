using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;

public class BridgeTrigger : NetworkBehaviour
{
	public float bridgeDurability = 1f;

	private PlayerControllerB playerOnBridge;

	private List<PlayerControllerB> playersOnBridge = new List<PlayerControllerB>();

	public AudioSource bridgeAudioSource;

	public AudioClip[] bridgeCreakSFX;

	public AudioClip bridgeFallSFX;

	public Animator bridgeAnimator;

	private bool hasBridgeFallen;

	public Transform bridgePhysicsPartsContainer;

	private bool giantOnBridge;

	private bool giantOnBridgeLastFrame;

	public Collider[] fallenBridgeColliders;

	public int fallType;

	public float weightCapacityAmount = 0.04f;

	public float playerCapacityAmount = 0.02f;

	private void OnEnable()
	{
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).AddListener((UnityAction<PlayerControllerB>)RemovePlayerFromBridge);
	}

	private void OnDisable()
	{
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).RemoveListener((UnityAction<PlayerControllerB>)RemovePlayerFromBridge);
	}

	private void Update()
	{
		if (hasBridgeFallen)
		{
			return;
		}
		if (giantOnBridge)
		{
			bridgeDurability -= Time.deltaTime / 4.25f;
		}
		if (playersOnBridge.Count > 0)
		{
			bridgeDurability = Mathf.Clamp(bridgeDurability - Time.deltaTime * (playerCapacityAmount * (float)(playersOnBridge.Count * playersOnBridge.Count)), 0f, 1f);
			for (int i = 0; i < playersOnBridge.Count; i++)
			{
				if (playersOnBridge[i].carryWeight > 1.1f)
				{
					bridgeDurability -= Time.deltaTime * (weightCapacityAmount * playersOnBridge[i].carryWeight);
				}
			}
		}
		else if (bridgeDurability < 1f && !giantOnBridge)
		{
			bridgeDurability = Mathf.Clamp(bridgeDurability + Time.deltaTime * 0.2f, 0f, 1f);
		}
		if (((NetworkBehaviour)this).IsServer && bridgeDurability <= 0f && !hasBridgeFallen)
		{
			hasBridgeFallen = true;
			BridgeFallServerRpc();
			Debug.Log((object)"Bridge collapsed! On server");
		}
		bridgeAnimator.SetFloat("durability", Mathf.Clamp(Mathf.Abs(bridgeDurability - 1f), 0f, 1f));
	}

	private void LateUpdate()
	{
		if (giantOnBridge)
		{
			if (giantOnBridgeLastFrame)
			{
				giantOnBridge = false;
				giantOnBridgeLastFrame = false;
			}
			else
			{
				giantOnBridgeLastFrame = true;
			}
		}
	}

	[ServerRpc]
	public void BridgeFallServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Invalid comparison between Unknown and I4
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			if (((NetworkBehaviour)this).OwnerClientId != networkManager.LocalClientId)
			{
				if ((int)networkManager.LogLevel <= 1)
				{
					Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
				}
				return;
			}
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(2883846656u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 2883846656u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			BridgeFallClientRpc();
		}
	}

	[ClientRpc]
	public void BridgeFallClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(123213822u, val, (RpcDelivery)0);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 123213822u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			hasBridgeFallen = true;
			switch (fallType)
			{
			case 0:
				bridgeAnimator.SetTrigger("Fall");
				break;
			case 2:
				bridgeAnimator.SetTrigger("FallType2");
				break;
			}
			EnableFallenBridgeColliders();
			bridgeAudioSource.PlayOneShot(bridgeFallSFX);
			float num = Vector3.Distance(((Component)GameNetworkManager.Instance.localPlayerController).transform.position, ((Component)bridgeAudioSource).transform.position);
			if (num < 30f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.VeryStrong);
			}
			else if (num < 50f)
			{
				HUDManager.Instance.ShakeCamera(ScreenShakeType.Long);
			}
		}
	}

	private void EnableFallenBridgeColliders()
	{
		for (int i = 0; i < fallenBridgeColliders.Length; i++)
		{
			fallenBridgeColliders[i].enabled = true;
		}
	}

	private void OnTriggerStay(Collider other)
	{
		if (((Component)other).gameObject.CompareTag("Player"))
		{
			playerOnBridge = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			if ((Object)(object)playerOnBridge != (Object)null && !playersOnBridge.Contains(playerOnBridge))
			{
				playersOnBridge.Add(playerOnBridge);
				if (Random.Range(playersOnBridge.Count * 25, 100) > 60)
				{
					RoundManager.PlayRandomClip(bridgeAudioSource, bridgeCreakSFX);
				}
			}
		}
		else if (((Component)other).gameObject.CompareTag("Enemy"))
		{
			EnemyAICollisionDetect component = ((Component)other).gameObject.GetComponent<EnemyAICollisionDetect>();
			if ((Object)(object)component != (Object)null && component.mainScript.enemyType.enemyName == "ForestGiant")
			{
				giantOnBridge = true;
				giantOnBridgeLastFrame = false;
			}
		}
	}

	public void RemovePlayerFromBridge(PlayerControllerB playerOnBridge)
	{
		if ((Object)(object)playerOnBridge != (Object)null && playersOnBridge.Contains(playerOnBridge))
		{
			playersOnBridge.Remove(playerOnBridge);
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (((Component)other).gameObject.CompareTag("Player"))
		{
			playerOnBridge = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
			RemovePlayerFromBridge(playerOnBridge);
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_BridgeTrigger()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(2883846656u, new RpcReceiveHandler(__rpc_handler_2883846656));
		NetworkManager.__rpc_func_table.Add(123213822u, new RpcReceiveHandler(__rpc_handler_123213822));
	}

	private static void __rpc_handler_2883846656(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if (rpcParams.Server.Receive.SenderClientId != target.OwnerClientId)
		{
			if ((int)networkManager.LogLevel <= 1)
			{
				Debug.LogError((object)"Only the owner can invoke a ServerRpc that requires ownership!");
			}
		}
		else
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((BridgeTrigger)(object)target).BridgeFallServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_123213822(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((BridgeTrigger)(object)target).BridgeFallClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "BridgeTrigger";
	}
}
