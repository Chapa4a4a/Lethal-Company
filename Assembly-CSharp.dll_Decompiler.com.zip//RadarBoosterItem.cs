using System;
using Unity.Netcode;
using UnityEngine;

public class RadarBoosterItem : GrabbableObject
{
	public bool radarEnabled;

	public Animator radarBoosterAnimator;

	public GameObject radarDot;

	public AudioSource pingAudio;

	public AudioClip pingSFX;

	public AudioSource radarBoosterAudio;

	public AudioClip turnOnSFX;

	public AudioClip turnOffSFX;

	public AudioClip flashSFX;

	public string radarBoosterName;

	private bool setRandomBoosterName;

	private int timesPlayingPingAudioInOneSpot;

	private Vector3 pingAudioLastPosition;

	private float timeSincePlayingPingAudio;

	private int radarBoosterNameIndex = -1;

	private float flashCooldown;

	public Transform radarSpherePosition;

	public override void Start()
	{
		base.Start();
	}

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
		if (radarEnabled)
		{
			RemoveBoosterFromRadar();
		}
	}

	public override int GetItemDataToSave()
	{
		base.GetItemDataToSave();
		return radarBoosterNameIndex;
	}

	public override void LoadItemSaveData(int saveData)
	{
		base.LoadItemSaveData(saveData);
		radarBoosterNameIndex = saveData;
	}

	public void FlashAndSync()
	{
		Flash();
		RadarBoosterFlashServerRpc();
	}

	[ServerRpc(RequireOwnership = false)]
	public void RadarBoosterFlashServerRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3971038271u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3971038271u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				RadarBoosterFlashClientRpc();
			}
		}
	}

	[ClientRpc]
	public void RadarBoosterFlashClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(720948839u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 720948839u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !(flashCooldown >= 0f))
			{
				Flash();
			}
		}
	}

	public void Flash()
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		if (radarEnabled && !(flashCooldown >= 0f))
		{
			flashCooldown = 2.25f;
			radarBoosterAnimator.SetTrigger("Flash");
			radarBoosterAudio.PlayOneShot(flashSFX);
			WalkieTalkie.TransmitOneShotAudio(radarBoosterAudio, flashSFX);
			StunGrenadeItem.StunExplosion(radarSpherePosition.position, affectAudio: false, 0.8f, 1.75f, 2f, isHeldItem: false, null, null, 0.3f);
		}
	}

	public void SetRadarBoosterNameLocal(string newName)
	{
		radarBoosterName = newName;
		((Component)this).gameObject.GetComponentInChildren<ScanNodeProperties>().headerText = radarBoosterName;
		StartOfRound.Instance.mapScreen.ChangeNameOfTargetTransform(((Component)this).transform, newName);
	}

	private void RemoveBoosterFromRadar()
	{
		StartOfRound.Instance.mapScreen.RemoveTargetFromRadar(((Component)this).transform);
	}

	private void AddBoosterToRadar()
	{
		if (!setRandomBoosterName)
		{
			setRandomBoosterName = true;
			int num = (radarBoosterNameIndex = ((radarBoosterNameIndex != -1) ? radarBoosterNameIndex : new Random(Mathf.Min(StartOfRound.Instance.randomMapSeed + (int)((NetworkBehaviour)this).NetworkObjectId, 99999999)).Next(0, StartOfRound.Instance.randomNames.Length)));
			radarBoosterName = StartOfRound.Instance.randomNames[num];
			((Component)this).gameObject.GetComponentInChildren<ScanNodeProperties>().headerText = radarBoosterName;
		}
		string text = StartOfRound.Instance.mapScreen.AddTransformAsTargetToRadar(((Component)this).transform, radarBoosterName, isNonPlayer: true);
		if (!string.IsNullOrEmpty(text))
		{
			((Component)this).gameObject.GetComponentInChildren<ScanNodeProperties>().headerText = text;
		}
		StartOfRound.Instance.mapScreen.SyncOrderOfRadarBoostersInList();
	}

	public void EnableRadarBooster(bool enable)
	{
		radarBoosterAnimator.SetBool("on", enable);
		radarDot.SetActive(enable);
		if (enable)
		{
			AddBoosterToRadar();
			radarBoosterAudio.Play();
			radarBoosterAudio.PlayOneShot(turnOnSFX);
			WalkieTalkie.TransmitOneShotAudio(radarBoosterAudio, turnOnSFX);
		}
		else
		{
			RemoveBoosterFromRadar();
			if (radarBoosterAudio.isPlaying)
			{
				radarBoosterAudio.Stop();
				radarBoosterAudio.PlayOneShot(turnOffSFX);
				WalkieTalkie.TransmitOneShotAudio(radarBoosterAudio, turnOffSFX);
			}
		}
		radarEnabled = enable;
	}

	public void PlayPingAudio()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		timesPlayingPingAudioInOneSpot += 2;
		timeSincePlayingPingAudio = 0f;
		pingAudio.PlayOneShot(pingSFX);
		WalkieTalkie.TransmitOneShotAudio(pingAudio, pingSFX);
		RoundManager.Instance.PlayAudibleNoise(((Component)pingAudio).transform.position, 12f, 0.8f, timesPlayingPingAudioInOneSpot, isInShipRoom && StartOfRound.Instance.hangarDoorsClosed, 1015);
	}

	public void PlayPingAudioAndSync()
	{
		PlayPingAudio();
		PingRadarBoosterServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
	}

	[ServerRpc(RequireOwnership = false)]
	public void PingRadarBoosterServerRpc(int playerWhoPlayedPing)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(577640837u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoPlayedPing);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 577640837u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PingRadarBoosterClientRpc(playerWhoPlayedPing);
			}
		}
	}

	[ClientRpc]
	public void PingRadarBoosterClientRpc(int playerWhoPlayedPing)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3675855655u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoPlayedPing);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3675855655u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && playerWhoPlayedPing != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				PlayPingAudio();
			}
		}
	}

	public override void EquipItem()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		base.EquipItem();
		pingAudioLastPosition = ((Component)this).transform.position;
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		base.ItemActivate(used, buttonDown);
		EnableRadarBooster(used);
	}

	public override void PocketItem()
	{
		base.PocketItem();
		isBeingUsed = false;
		EnableRadarBooster(enable: false);
	}

	public override void DiscardItem()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(((Component)this).transform.position, pingAudioLastPosition) > 5f)
		{
			timesPlayingPingAudioInOneSpot = 0;
		}
		base.DiscardItem();
	}

	public override void Update()
	{
		base.Update();
		if (timeSincePlayingPingAudio > 5f)
		{
			timeSincePlayingPingAudio = 0f;
			timesPlayingPingAudioInOneSpot = Mathf.Max(timesPlayingPingAudioInOneSpot - 1, 0);
		}
		else
		{
			timeSincePlayingPingAudio += Time.deltaTime;
		}
		if (flashCooldown >= 0f)
		{
			flashCooldown -= Time.deltaTime;
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_RadarBoosterItem()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3971038271u, new RpcReceiveHandler(__rpc_handler_3971038271));
		NetworkManager.__rpc_func_table.Add(720948839u, new RpcReceiveHandler(__rpc_handler_720948839));
		NetworkManager.__rpc_func_table.Add(577640837u, new RpcReceiveHandler(__rpc_handler_577640837));
		NetworkManager.__rpc_func_table.Add(3675855655u, new RpcReceiveHandler(__rpc_handler_3675855655));
	}

	private static void __rpc_handler_3971038271(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RadarBoosterItem)(object)target).RadarBoosterFlashServerRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_720948839(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadarBoosterItem)(object)target).RadarBoosterFlashClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_577640837(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoPlayedPing = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoPlayedPing);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RadarBoosterItem)(object)target).PingRadarBoosterServerRpc(playerWhoPlayedPing);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3675855655(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoPlayedPing = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoPlayedPing);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RadarBoosterItem)(object)target).PingRadarBoosterClientRpc(playerWhoPlayedPing);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "RadarBoosterItem";
	}
}
