using System.Collections;
using UnityEngine;

public class AnimatedTextureUV : MonoBehaviour
{
	private Material[] setMaterials;

	public MeshRenderer meshRenderer;

	public SkinnedMeshRenderer skinnedMeshRenderer;

	public int materialIndex;

	public int columns = 1;

	public int rows = 1;

	public float waitFrameTime = 0.005f;

	private float horizontalOffset;

	private float verticalOffset;

	private Coroutine animateMaterial;

	private bool skinnedMesh;

	private void OnEnable()
	{
		if (animateMaterial == null)
		{
			Debug.Log((object)"Animating material now");
			animateMaterial = ((MonoBehaviour)this).StartCoroutine(AnimateUV());
		}
	}

	private void OnDisable()
	{
		if (animateMaterial != null)
		{
			((MonoBehaviour)this).StopCoroutine(animateMaterial);
		}
	}

	private IEnumerator AnimateUV()
	{
		yield return null;
		if ((Object)(object)skinnedMeshRenderer != (Object)null)
		{
			setMaterials = ((Renderer)skinnedMeshRenderer).materials;
			skinnedMesh = true;
		}
		else
		{
			setMaterials = ((Renderer)meshRenderer).materials;
		}
		float maxVertical = 1f - 1f / (float)columns;
		float maxHorizontal = 1f - 1f / (float)rows;
		while (((Behaviour)this).enabled)
		{
			yield return (object)new WaitForSeconds(waitFrameTime);
			horizontalOffset += 1f / (float)rows;
			if (horizontalOffset > maxHorizontal)
			{
				horizontalOffset = 0f;
				verticalOffset += 1f / (float)columns;
				if (verticalOffset > maxVertical)
				{
					verticalOffset = 0f;
				}
			}
			setMaterials[materialIndex].SetTextureOffset("_BaseColorMap", new Vector2(horizontalOffset, verticalOffset));
			if (skinnedMesh)
			{
				((Renderer)skinnedMeshRenderer).materials = setMaterials;
			}
			else
			{
				((Renderer)skinnedMeshRenderer).materials = setMaterials;
			}
		}
	}
}
