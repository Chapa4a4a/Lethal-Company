using System;
using Unity.Netcode;
using UnityEngine;

public class SoccerBallProp : GrabbableObject
{
	[Space(5f)]
	public float ballHitUpwardAmount = 0.5f;

	public AnimationCurve grenadeFallCurve;

	public AnimationCurve grenadeVerticalFallCurve;

	public AnimationCurve soccerBallVerticalOffset;

	public AnimationCurve grenadeVerticalFallCurveNoBounce;

	private Ray soccerRay;

	private RaycastHit soccerHit;

	private int soccerBallMask = 369101057;

	private int previousPlayerHit;

	private float hitTimer;

	public AudioClip[] hitBallSFX;

	public AudioClip[] ballHitFloorSFX;

	public AudioSource soccerBallAudio;

	public Transform ballCollider;

	public override void Start()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		if (new Random(StartOfRound.Instance.randomMapSeed + 51).Next(0, 100) < 15)
		{
			Transform obj = ballCollider;
			obj.localScale *= 1.56f;
		}
	}

	public override void ActivatePhysicsTrigger(Collider other)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		if ((((Component)other).gameObject.CompareTag("Player") || ((Component)other).gameObject.CompareTag("Enemy")) && !Physics.Linecast(((Component)other).gameObject.transform.position + Vector3.up, ((Component)this).transform.position + Vector3.up * 0.5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			BeginKickBall(((Component)other).gameObject.transform.position + Vector3.up, ((Component)other).gameObject.CompareTag("Enemy"));
		}
	}

	public Vector3 GetSoccerKickDestination(Vector3 hitFromPosition)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((Component)this).transform.position;
		Vector3 val2 = (((Component)this).transform.position - hitFromPosition) * 1000f;
		val2 = Vector3.Normalize(val2);
		val2.y = 0.15f;
		soccerRay = new Ray(((Component)this).transform.position + Vector3.up * 0.22f, val2);
		Debug.DrawRay(((Component)this).transform.position, val2, Color.yellow, 15f);
		bool flag = false;
		if (Physics.Raycast(soccerRay, ref soccerHit, 12f, soccerBallMask, (QueryTriggerInteraction)1) && ((Component)((RaycastHit)(ref soccerHit)).collider).gameObject.layer == 28)
		{
			flag = true;
			val = ((!(((RaycastHit)(ref soccerHit)).distance < 2f)) ? ((Ray)(ref soccerRay)).GetPoint(((RaycastHit)(ref soccerHit)).distance - 0.05f) : (((Ray)(ref soccerRay)).GetPoint(((RaycastHit)(ref soccerHit)).distance - 0.05f) + ((RaycastHit)(ref soccerHit)).normal * (((RaycastHit)(ref soccerHit)).distance * 2f)));
		}
		Debug.DrawRay(((Component)this).transform.position, val2, Color.blue, 15f);
		if (!flag)
		{
			val2.y = ballHitUpwardAmount;
			val = ((!Physics.Raycast(soccerRay, ref soccerHit, 12f, soccerBallMask, (QueryTriggerInteraction)1)) ? ((Ray)(ref soccerRay)).GetPoint(10f) : ((!(((RaycastHit)(ref soccerHit)).distance < 2f)) ? ((Ray)(ref soccerRay)).GetPoint(((RaycastHit)(ref soccerHit)).distance - 0.05f) : (((Ray)(ref soccerRay)).GetPoint(((RaycastHit)(ref soccerHit)).distance - 0.05f) + ((RaycastHit)(ref soccerHit)).normal * (((RaycastHit)(ref soccerHit)).distance * 2f))));
		}
		Debug.DrawRay(val, Vector3.down, Color.blue, 15f);
		soccerRay = new Ray(val, Vector3.down);
		if (Physics.Raycast(soccerRay, ref soccerHit, 65f, soccerBallMask, (QueryTriggerInteraction)1))
		{
			Vector3 val3 = ((RaycastHit)(ref soccerHit)).point + Vector3.up * itemProperties.verticalOffset;
			Debug.DrawRay(val3, Vector3.up * 0.5f, Color.green);
			return val3;
		}
		return Vector3.zero;
	}

	public void BeginKickBall(Vector3 hitFromPosition, bool hitByEnemy)
	{
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		if ((hitByEnemy && !((NetworkBehaviour)this).IsServer) || isHeld || (Object)(object)parentObject != (Object)null || ((Object)(object)((Component)this).transform.parent != (Object)(object)StartOfRound.Instance.elevatorTransform && (Object)(object)((Component)this).transform.parent != (Object)(object)RoundManager.Instance.spawnedScrapContainer && (Object)(object)((Component)this).transform.parent != (Object)(object)StartOfRound.Instance.propsContainer) || (previousPlayerHit == (int)GameNetworkManager.Instance.localPlayerController.playerClientId && Time.realtimeSinceStartup - hitTimer < 0.35f))
		{
			return;
		}
		hitTimer = Time.realtimeSinceStartup;
		previousPlayerHit = (int)GameNetworkManager.Instance.localPlayerController.playerClientId;
		Vector3 soccerKickDestination = GetSoccerKickDestination(hitFromPosition);
		if (!(soccerKickDestination == Vector3.zero))
		{
			bool setInShipRoom = false;
			Bounds bounds = StartOfRound.Instance.shipBounds.bounds;
			bool setInElevator;
			if (!((Bounds)(ref bounds)).Contains(soccerKickDestination))
			{
				setInElevator = false;
				soccerKickDestination = StartOfRound.Instance.propsContainer.InverseTransformPoint(soccerKickDestination);
			}
			else
			{
				setInElevator = true;
				bounds = StartOfRound.Instance.shipInnerRoomBounds.bounds;
				setInShipRoom = ((Bounds)(ref bounds)).Contains(soccerKickDestination);
				soccerKickDestination = StartOfRound.Instance.elevatorTransform.InverseTransformPoint(soccerKickDestination);
			}
			KickBallLocalClient(soccerKickDestination, setInElevator, setInShipRoom);
			KickBallServerRpc(soccerKickDestination, (int)GameNetworkManager.Instance.localPlayerController.playerClientId, setInElevator, setInShipRoom);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void KickBallServerRpc(Vector3 dest, int playerWhoKicked, bool setInElevator, bool setInShipRoom)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1444407036u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref dest);
			BytePacker.WriteValueBitPacked(val2, playerWhoKicked);
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setInElevator, default(ForPrimitives));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setInShipRoom, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1444407036u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			if (playerWhoKicked != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				KickBallLocalClient(dest, setInElevator, setInShipRoom);
				previousPlayerHit = playerWhoKicked;
			}
			KickBallClientRpc(dest, playerWhoKicked, setInElevator, setInShipRoom);
		}
	}

	[ClientRpc]
	public void KickBallClientRpc(Vector3 dest, int playerWhoKicked, bool setInElevator, bool setInShipRoom)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1833449416u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref dest);
				BytePacker.WriteValueBitPacked(val2, playerWhoKicked);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setInElevator, default(ForPrimitives));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref setInShipRoom, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1833449416u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && !((NetworkBehaviour)this).IsServer && playerWhoKicked != (int)GameNetworkManager.Instance.localPlayerController.playerClientId)
			{
				previousPlayerHit = playerWhoKicked;
				KickBallLocalClient(dest, setInElevator, setInShipRoom);
			}
		}
	}

	private void KickBallLocalClient(Vector3 destinationPos, bool setInElevator, bool setInShipRoom)
	{
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		RoundManager.PlayRandomClip(soccerBallAudio, hitBallSFX, randomize: true, 1f, 10419);
		WalkieTalkie.TransmitOneShotAudio(soccerBallAudio, hitBallSFX[Random.Range(0, hitBallSFX.Length)]);
		fallTime = 0f;
		hasHitGround = false;
		if (setInElevator)
		{
			((Component)this).transform.SetParent(StartOfRound.Instance.elevatorTransform, true);
		}
		else
		{
			((Component)this).transform.SetParent(StartOfRound.Instance.propsContainer, true);
		}
		GameNetworkManager.Instance.localPlayerController.SetItemInElevator(setInElevator, setInShipRoom, this);
		startFallingPosition = ((Component)this).transform.parent.InverseTransformPoint(((Component)this).transform.position + Vector3.up * 0.07f);
		targetFloorPosition = destinationPos;
	}

	public override void FallWithCurve()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = startFallingPosition - targetFloorPosition;
		float magnitude = ((Vector3)(ref val)).magnitude;
		((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, Quaternion.Euler(itemProperties.restingRotation.x, ((Component)this).transform.eulerAngles.y, itemProperties.restingRotation.z), 14f * Time.deltaTime / magnitude);
		((Component)this).transform.localPosition = Vector3.Lerp(startFallingPosition, targetFloorPosition, grenadeFallCurve.Evaluate(fallTime));
		if (magnitude < 3f)
		{
			((Component)this).transform.localPosition = Vector3.Lerp(new Vector3(((Component)this).transform.localPosition.x, startFallingPosition.y, ((Component)this).transform.localPosition.z), new Vector3(((Component)this).transform.localPosition.x, targetFloorPosition.y, ((Component)this).transform.localPosition.z), grenadeVerticalFallCurveNoBounce.Evaluate(fallTime));
		}
		else
		{
			((Component)this).transform.localPosition = Vector3.Lerp(new Vector3(((Component)this).transform.localPosition.x, startFallingPosition.y, ((Component)this).transform.localPosition.z), new Vector3(((Component)this).transform.localPosition.x, targetFloorPosition.y, ((Component)this).transform.localPosition.z), grenadeVerticalFallCurve.Evaluate(fallTime));
			((Component)this).transform.localPosition = new Vector3(((Component)this).transform.localPosition.x, ((Component)this).transform.localPosition.y + soccerBallVerticalOffset.Evaluate(fallTime) * ballHitUpwardAmount, ((Component)this).transform.localPosition.z);
		}
		fallTime += Mathf.Abs(Time.deltaTime * 12f / magnitude);
	}

	public override void PlayDropSFX()
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)itemProperties.dropSFX != (Object)null)
		{
			RoundManager.PlayRandomClip(soccerBallAudio, ballHitFloorSFX, randomize: true, 1f, 10419);
			WalkieTalkie.TransmitOneShotAudio(soccerBallAudio, itemProperties.dropSFX);
			if (((NetworkBehaviour)this).IsOwner)
			{
				RoundManager.Instance.PlayAudibleNoise(((Component)this).transform.position, 15f, 0.85f, 0, isInElevator && StartOfRound.Instance.hangarDoorsClosed, 941);
			}
		}
		hasHitGround = true;
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_SoccerBallProp()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1444407036u, new RpcReceiveHandler(__rpc_handler_1444407036));
		NetworkManager.__rpc_func_table.Add(1833449416u, new RpcReceiveHandler(__rpc_handler_1833449416));
	}

	private static void __rpc_handler_1444407036(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 dest = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref dest);
			int playerWhoKicked = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoKicked);
			bool setInElevator = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setInElevator, default(ForPrimitives));
			bool setInShipRoom = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setInShipRoom, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SoccerBallProp)(object)target).KickBallServerRpc(dest, playerWhoKicked, setInElevator, setInShipRoom);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1833449416(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 dest = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref dest);
			int playerWhoKicked = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoKicked);
			bool setInElevator = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setInElevator, default(ForPrimitives));
			bool setInShipRoom = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref setInShipRoom, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SoccerBallProp)(object)target).KickBallClientRpc(dest, playerWhoKicked, setInElevator, setInShipRoom);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "SoccerBallProp";
	}
}
