using System;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class RagdollGrabbableObject : GrabbableObject
{
	public NetworkVariable<int> bodyID = new NetworkVariable<int>(0, (NetworkVariableReadPermission)0, (NetworkVariableWritePermission)0);

	public DeadBodyInfo ragdoll;

	private bool foundRagdollObject;

	private bool bodySetToHold;

	public bool testBody;

	private bool setBodyInElevator;

	private PlayerControllerB previousPlayerHeldBy;

	private bool hasBeenPlaced;

	public bool heldByEnemy;

	private bool heldByEnemyThisFrame;

	public override void Start()
	{
		base.Start();
		if (HoarderBugAI.grabbableObjectsInMap != null && !HoarderBugAI.grabbableObjectsInMap.Contains(((Component)this).gameObject))
		{
			HoarderBugAI.grabbableObjectsInMap.Add(((Component)this).gameObject);
		}
		if ((Object)(object)radarIcon != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)radarIcon).gameObject);
		}
	}

	public override void EquipItem()
	{
		base.EquipItem();
		previousPlayerHeldBy = playerHeldBy;
		hasBeenPlaced = false;
	}

	public override void OnPlaceObject()
	{
		base.OnPlaceObject();
		hasBeenPlaced = true;
	}

	public override void OnDestroy()
	{
		((NetworkBehaviour)this).OnDestroy();
		if (foundRagdollObject && (Object)(object)ragdoll != (Object)null)
		{
			Object.Destroy((Object)(object)((Component)ragdoll).gameObject);
		}
	}

	public override void Update()
	{
		base.Update();
		if (NetworkManager.Singleton.ShutdownInProgress || bodyID.Value == -1)
		{
			return;
		}
		if (!foundRagdollObject)
		{
			if (testBody)
			{
				DeadBodyInfo[] array = Object.FindObjectsOfType<DeadBodyInfo>();
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i].playerObjectId == 0)
					{
						ragdoll = array[i];
						break;
					}
				}
				ragdoll.grabBodyObject = this;
				parentObject = ((Component)ragdoll.bodyParts[5]).transform;
				((Component)this).transform.SetParent(((Component)ragdoll.bodyParts[5]).transform);
				foundRagdollObject = true;
			}
			else
			{
				if (!((Object)(object)StartOfRound.Instance.allPlayerScripts[bodyID.Value].deadBody != (Object)null))
				{
					return;
				}
				ragdoll = StartOfRound.Instance.allPlayerScripts[bodyID.Value].deadBody;
				ragdoll.grabBodyObject = this;
				parentObject = ((Component)ragdoll.bodyParts[5]).transform;
				((Component)this).transform.SetParent(((Component)ragdoll.bodyParts[5]).transform);
				foundRagdollObject = true;
			}
		}
		if ((Object)(object)ragdoll == (Object)null)
		{
			return;
		}
		bool flag = hasBeenPlaced && StartOfRound.Instance.currentLevel.levelID == 3 && (Object)(object)Object.FindObjectOfType<DepositItemsDesk>() != (Object)null && (Object)(object)((Component)this).transform.parent == (Object)(object)((Component)Object.FindObjectOfType<DepositItemsDesk>().deskObjectsContainer).transform;
		if (isHeld || heldByEnemy || flag)
		{
			if (flag)
			{
				ragdoll.matchPositionExactly = false;
				ragdoll.attachedLimb.isKinematic = false;
				ragdoll.speedMultiplier = 45f;
				ragdoll.maxVelocity = 0.75f;
			}
			if (!bodySetToHold)
			{
				if (heldByEnemy)
				{
					heldByEnemyThisFrame = true;
				}
				else
				{
					ragdoll.bodyBleedingHeavily = false;
				}
				grabbableToEnemies = false;
				bodySetToHold = true;
				((Component)ragdoll).gameObject.SetActive(true);
				ragdoll.SetBodyPartsKinematic(setKinematic: false);
				ragdoll.attachedTo = ((Component)this).transform;
				ragdoll.attachedLimb = ragdoll.bodyParts[5];
				ragdoll.matchPositionExactly = true;
				ragdoll.lerpBeforeMatchingPosition = true;
				SetRagdollParentToMatchHoldingPlayer();
			}
		}
		else if (bodySetToHold)
		{
			bodySetToHold = false;
			grabbableToEnemies = true;
			ragdoll.attachedTo = null;
			parentObject = ((Component)ragdoll.bodyParts[5]).transform;
			((Component)this).transform.SetParent(((Component)ragdoll.bodyParts[5]).transform);
			ragdoll.attachedLimb = null;
			ragdoll.matchPositionExactly = false;
			ragdoll.lerpBeforeMatchingPosition = false;
			SetRagdollParentToMatchHoldingPlayer();
			heldByEnemyThisFrame = false;
		}
	}

	public override void GrabItemFromEnemy(EnemyAI enemy)
	{
		base.GrabItemFromEnemy(enemy);
		heldByEnemy = true;
	}

	public override void DiscardItemFromEnemy()
	{
		base.DiscardItemFromEnemy();
		heldByEnemy = false;
	}

	private void SetRagdollParentToMatchHoldingPlayer()
	{
		if (!heldByEnemyThisFrame && (Object)(object)previousPlayerHeldBy != (Object)null)
		{
			if (previousPlayerHeldBy.isInElevator && !setBodyInElevator)
			{
				setBodyInElevator = true;
				((Component)ragdoll).transform.SetParent(StartOfRound.Instance.elevatorTransform);
			}
			else if (!previousPlayerHeldBy.isInElevator && setBodyInElevator)
			{
				setBodyInElevator = false;
				((Component)ragdoll).transform.SetParent((Transform)null);
			}
		}
	}

	protected override void __initializeVariables()
	{
		if (bodyID == null)
		{
			throw new Exception("RagdollGrabbableObject.bodyID cannot be null. All NetworkVariableBase instances must be initialized.");
		}
		((NetworkVariableBase)bodyID).Initialize((NetworkBehaviour)(object)this);
		((NetworkBehaviour)this).__nameNetworkVariable((NetworkVariableBase)(object)bodyID, "bodyID");
		((NetworkBehaviour)this).NetworkVariableFields.Add((NetworkVariableBase)(object)bodyID);
		base.__initializeVariables();
	}

	protected internal override string __getTypeName()
	{
		return "RagdollGrabbableObject";
	}
}
