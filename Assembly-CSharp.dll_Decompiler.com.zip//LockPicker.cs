using System;
using System.Collections;
using Unity.Netcode;
using UnityEngine;

public class LockPicker : GrabbableObject
{
	public AudioClip[] placeLockPickerClips;

	public AudioClip[] finishPickingLockClips;

	public Animator armsAnimator;

	private Ray ray;

	private RaycastHit hit;

	public bool isPickingLock;

	public bool isOnDoor;

	public DoorLock currentlyPickingDoor;

	private bool placeOnLockPicker1;

	private AudioSource lockPickerAudio;

	private Coroutine setRotationCoroutine;

	public override void EquipItem()
	{
		base.EquipItem();
		RetractClaws();
	}

	public override void Start()
	{
		base.Start();
		lockPickerAudio = ((Component)this).gameObject.GetComponent<AudioSource>();
	}

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)playerHeldBy == (Object)null || !((NetworkBehaviour)this).IsOwner)
		{
			return;
		}
		ray = new Ray(((Component)playerHeldBy.gameplayCamera).transform.position, ((Component)playerHeldBy.gameplayCamera).transform.forward);
		if (!Physics.Raycast(ray, ref hit, 3f, 2816))
		{
			return;
		}
		DoorLock doorLock = ((Component)((RaycastHit)(ref hit)).transform).GetComponent<DoorLock>();
		if ((Object)(object)doorLock == (Object)null)
		{
			TriggerPointToDoor component = ((Component)((RaycastHit)(ref hit)).transform).GetComponent<TriggerPointToDoor>();
			if ((Object)(object)component != (Object)null)
			{
				doorLock = component.pointToDoor;
			}
		}
		if ((Object)(object)doorLock != (Object)null && doorLock.isLocked && !doorLock.isPickingLock)
		{
			playerHeldBy.DiscardHeldObject(placeObject: true, ((NetworkBehaviour)doorLock).NetworkObject, GetLockPickerDoorPosition(doorLock));
			Debug.Log((object)"discard held object called from lock picker");
			PlaceLockPickerServerRpc(NetworkObjectReference.op_Implicit(((NetworkBehaviour)doorLock).NetworkObject), placeOnLockPicker1);
			PlaceOnDoor(doorLock, placeOnLockPicker1);
		}
	}

	private Vector3 GetLockPickerDoorPosition(DoorLock doorScript)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(doorScript.lockPickerPosition.position, ((Component)playerHeldBy).transform.position) < Vector3.Distance(doorScript.lockPickerPosition2.position, ((Component)playerHeldBy).transform.position))
		{
			placeOnLockPicker1 = true;
			return doorScript.lockPickerPosition.localPosition;
		}
		placeOnLockPicker1 = false;
		return doorScript.lockPickerPosition2.localPosition;
	}

	[ServerRpc(RequireOwnership = false)]
	public void PlaceLockPickerServerRpc(NetworkObjectReference doorObject, bool lockPicker1)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(345501982u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref doorObject, default(ForNetworkSerializable));
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref lockPicker1, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 345501982u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				PlaceLockPickerClientRpc(doorObject, lockPicker1);
			}
		}
	}

	[ClientRpc]
	public void PlaceLockPickerClientRpc(NetworkObjectReference doorObject, bool lockPicker1)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1656348772u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref doorObject, default(ForNetworkSerializable));
			((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref lockPicker1, default(ForPrimitives));
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1656348772u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
		{
			NetworkObject val3 = default(NetworkObject);
			if (((NetworkObjectReference)(ref doorObject)).TryGet(ref val3, (NetworkManager)null))
			{
				DoorLock componentInChildren = ((Component)val3).gameObject.GetComponentInChildren<DoorLock>();
				PlaceOnDoor(componentInChildren, lockPicker1);
			}
			else
			{
				Debug.LogError((object)("Lock picker was placed but we can't get the reference for the door it was placed on; placed by " + ((Object)((Component)playerHeldBy).gameObject).name));
			}
		}
	}

	public void PlaceOnDoor(DoorLock doorScript, bool lockPicker1)
	{
		if (!isOnDoor)
		{
			((Component)this).gameObject.GetComponent<AudioSource>().PlayOneShot(placeLockPickerClips[Random.Range(0, placeLockPickerClips.Length)]);
			armsAnimator.SetBool("mounted", true);
			armsAnimator.SetBool("picking", true);
			lockPickerAudio.Play();
			Debug.Log((object)"Playing lock picker audio");
			lockPickerAudio.pitch = Random.Range(0.94f, 1.06f);
			isOnDoor = true;
			isPickingLock = true;
			doorScript.isPickingLock = true;
			currentlyPickingDoor = doorScript;
			if (setRotationCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(setRotationCoroutine);
			}
			setRotationCoroutine = ((MonoBehaviour)this).StartCoroutine(setRotationOnDoor(doorScript, lockPicker1));
		}
	}

	private IEnumerator setRotationOnDoor(DoorLock doorScript, bool lockPicker1)
	{
		float startTime = Time.timeSinceLevelLoad;
		yield return (object)new WaitUntil((Func<bool>)(() => !isHeld || Time.timeSinceLevelLoad - startTime > 10f));
		Debug.Log((object)"setting rotation of lock picker in lock picker script");
		if (lockPicker1)
		{
			((Component)this).transform.localEulerAngles = doorScript.lockPickerPosition.localEulerAngles;
		}
		else
		{
			((Component)this).transform.localEulerAngles = doorScript.lockPickerPosition2.localEulerAngles;
		}
		setRotationCoroutine = null;
	}

	private void FinishPickingLock()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (isPickingLock)
		{
			RetractClaws();
			currentlyPickingDoor = null;
			Vector3 position = ((Component)this).transform.position;
			((Component)this).transform.SetParent((Transform)null);
			startFallingPosition = position;
			FallToGround();
			lockPickerAudio.PlayOneShot(finishPickingLockClips[Random.Range(0, finishPickingLockClips.Length)]);
		}
	}

	private void RetractClaws()
	{
		isOnDoor = false;
		isPickingLock = false;
		armsAnimator.SetBool("mounted", false);
		armsAnimator.SetBool("picking", false);
		if ((Object)(object)currentlyPickingDoor != (Object)null)
		{
			currentlyPickingDoor.isPickingLock = false;
			currentlyPickingDoor.lockPickTimeLeft = currentlyPickingDoor.maxTimeLeft;
			currentlyPickingDoor = null;
		}
		lockPickerAudio.Stop();
		Debug.Log((object)"pausing lock picker audio");
	}

	public override void Update()
	{
		base.Update();
		if (((NetworkBehaviour)this).IsServer && isPickingLock && (Object)(object)currentlyPickingDoor != (Object)null && !currentlyPickingDoor.isLocked)
		{
			FinishPickingLock();
			FinishPickingClientRpc();
		}
	}

	[ClientRpc]
	public void FinishPickingClientRpc()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2012404935u, val, (RpcDelivery)0);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2012404935u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				FinishPickingLock();
			}
		}
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_LockPicker()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(345501982u, new RpcReceiveHandler(__rpc_handler_345501982));
		NetworkManager.__rpc_func_table.Add(1656348772u, new RpcReceiveHandler(__rpc_handler_1656348772));
		NetworkManager.__rpc_func_table.Add(2012404935u, new RpcReceiveHandler(__rpc_handler_2012404935));
	}

	private static void __rpc_handler_345501982(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference doorObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref doorObject, default(ForNetworkSerializable));
			bool lockPicker = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref lockPicker, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((LockPicker)(object)target).PlaceLockPickerServerRpc(doorObject, lockPicker);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1656348772(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference doorObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref doorObject, default(ForNetworkSerializable));
			bool lockPicker = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref lockPicker, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((LockPicker)(object)target).PlaceLockPickerClientRpc(doorObject, lockPicker);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2012404935(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((LockPicker)(object)target).FinishPickingClientRpc();
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "LockPicker";
	}
}
