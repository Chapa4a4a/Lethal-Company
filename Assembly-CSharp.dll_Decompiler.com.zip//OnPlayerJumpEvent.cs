using UnityEngine;

public class OnPlayerJumpEvent : MonoBehaviour
{
}
