using System;
using System.Collections;
using DigitalRuby.ThunderAndLightning;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.VFX;

public class RedLocustBees : EnemyAI
{
	public int defenseDistance;

	[Space(5f)]
	public GameObject hivePrefab;

	public GrabbableObject hive;

	public Vector3 lastKnownHivePosition;

	private int previousState = -1;

	public VisualEffect beeParticles;

	public Transform beeParticlesTarget;

	public AudioSource beesIdle;

	public AudioSource beesDefensive;

	public AudioSource beesAngry;

	public AISearchRoutine searchForHive;

	private int chasePriority;

	private Vector3 lastSeenPlayerPos;

	private float lostLOSTimer;

	private bool wasInChase;

	private bool hasFoundHiveAfterChasing;

	private bool hasSpawnedHive;

	private float beesZapCurrentTimer;

	private float beesZapTimer;

	public LightningBoltPathScript lightningComponent;

	public Transform[] lightningPoints;

	private int beesZappingMode;

	private int timesChangingZapModes;

	private Random beeZapRandom;

	public AudioSource beeZapAudio;

	private float timeSinceHittingPlayer;

	private float attackZapModeTimer;

	private bool overrideBeeParticleTarget;

	private int beeParticleState = -1;

	private PlayerControllerB killingPlayer;

	private Coroutine killingPlayerCoroutine;

	private bool syncedLastKnownHivePosition;

	public override void Start()
	{
		base.Start();
		if (((NetworkBehaviour)this).IsServer)
		{
			SpawnHiveNearEnemy();
			syncedLastKnownHivePosition = true;
		}
	}

	private void SpawnHiveNearEnemy()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		if (((NetworkBehaviour)this).IsServer)
		{
			Random random = new Random(StartOfRound.Instance.randomMapSeed + 1314 + enemyType.numberSpawned);
			Vector3 randomNavMeshPositionInBoxPredictable = RoundManager.Instance.GetRandomNavMeshPositionInBoxPredictable(((Component)this).transform.position, 10f, RoundManager.Instance.navHit, random, -5);
			GameObject val = Object.Instantiate<GameObject>(hivePrefab, randomNavMeshPositionInBoxPredictable + Vector3.up * 0.2f, Quaternion.Euler(Vector3.zero), RoundManager.Instance.spawnedScrapContainer);
			val.SetActive(true);
			val.GetComponent<NetworkObject>().Spawn(false);
			SpawnHiveClientRpc(hiveScrapValue: (!(Vector3.Distance(randomNavMeshPositionInBoxPredictable, ((Component)StartOfRound.Instance.shipLandingPosition).transform.position) < 40f)) ? random.Next(50, 150) : random.Next(40, 100), hiveObject: NetworkObjectReference.op_Implicit(val.GetComponent<NetworkObject>()), hivePosition: randomNavMeshPositionInBoxPredictable + Vector3.up * 0.2f);
		}
	}

	[ClientRpc]
	public void SpawnHiveClientRpc(NetworkObjectReference hiveObject, int hiveScrapValue, Vector3 hivePosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
		{
			ClientRpcParams val = default(ClientRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3189835108u, val, (RpcDelivery)0);
			((FastBufferWriter)(ref val2)).WriteValueSafe<NetworkObjectReference>(ref hiveObject, default(ForNetworkSerializable));
			BytePacker.WriteValueBitPacked(val2, hiveScrapValue);
			((FastBufferWriter)(ref val2)).WriteValueSafe(ref hivePosition);
			((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3189835108u, val, (RpcDelivery)0);
		}
		if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 || (!networkManager.IsClient && !networkManager.IsHost))
		{
			return;
		}
		NetworkObject val3 = default(NetworkObject);
		if (((NetworkObjectReference)(ref hiveObject)).TryGet(ref val3, (NetworkManager)null))
		{
			hive = ((Component)val3).gameObject.GetComponent<GrabbableObject>();
			hive.scrapValue = hiveScrapValue;
			ScanNodeProperties componentInChildren = ((Component)hive).GetComponentInChildren<ScanNodeProperties>();
			if ((Object)(object)componentInChildren != (Object)null)
			{
				componentInChildren.scrapValue = hiveScrapValue;
				componentInChildren.headerText = "Bee hive";
				componentInChildren.subText = $"VALUE: ${hiveScrapValue}";
			}
			hive.targetFloorPosition = hivePosition;
			Debug.Log((object)$"Set targetfloorposition of hive: {hivePosition}");
			RaycastHit val4 = default(RaycastHit);
			if (Physics.Raycast(RoundManager.Instance.GetNavMeshPosition(((Component)hive).transform.position), ((Component)hive).transform.position + Vector3.up - eye.position, ref val4, 20f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
			{
				lastKnownHivePosition = ((RaycastHit)(ref val4)).point;
			}
			else
			{
				lastKnownHivePosition = ((Component)hive).transform.position;
			}
			RoundManager.Instance.totalScrapValueInLevel += hive.scrapValue;
			hasSpawnedHive = true;
		}
		else
		{
			Debug.LogError((object)"Bees: Error! Hive could not be accessed from network object reference");
		}
	}

	public override void DoAIInterval()
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_036b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0370: Unknown result type (might be due to invalid IL or missing references)
		base.DoAIInterval();
		if (StartOfRound.Instance.allPlayersDead || !hasSpawnedHive || daytimeEnemyLeaving)
		{
			return;
		}
		switch (currentBehaviourStateIndex)
		{
		case 0:
		{
			if (wasInChase)
			{
				wasInChase = false;
			}
			if (Vector3.Distance(((Component)this).transform.position, lastKnownHivePosition) > 2f)
			{
				SetDestinationToPosition(lastKnownHivePosition);
			}
			if (IsHiveMissing())
			{
				SwitchToBehaviourState(2);
				break;
			}
			PlayerControllerB playerControllerB3 = CheckLineOfSightForPlayer(360f, 16, 1);
			if ((Object)(object)playerControllerB3 != (Object)null && Vector3.Distance(((Component)playerControllerB3).transform.position, ((Component)hive).transform.position) < (float)defenseDistance)
			{
				SetMovingTowardsTargetPlayer(playerControllerB3);
				SwitchToBehaviourState(1);
				SwitchOwnershipOfBeesToClient(playerControllerB3);
			}
			break;
		}
		case 1:
			if ((Object)(object)targetPlayer == (Object)null || !PlayerIsTargetable(targetPlayer) || Vector3.Distance(((Component)targetPlayer).transform.position, ((Component)hive).transform.position) > (float)defenseDistance + 5f)
			{
				targetPlayer = null;
				wasInChase = false;
				if (IsHiveMissing())
				{
					SwitchToBehaviourState(2);
				}
				else
				{
					SwitchToBehaviourState(0);
				}
			}
			else if ((Object)(object)targetPlayer.currentlyHeldObjectServer == (Object)(object)hive)
			{
				SwitchToBehaviourState(2);
			}
			break;
		case 2:
		{
			if (IsHivePlacedAndInLOS())
			{
				if (wasInChase)
				{
					wasInChase = false;
				}
				lastKnownHivePosition = ((Component)hive).transform.position + Vector3.up * 0.5f;
				Collider[] array = Physics.OverlapSphere(((Component)hive).transform.position, (float)defenseDistance, StartOfRound.Instance.playersMask, (QueryTriggerInteraction)2);
				PlayerControllerB playerControllerB = null;
				if (array != null && array.Length != 0)
				{
					for (int i = 0; i < array.Length; i++)
					{
						playerControllerB = ((Component)array[0]).gameObject.GetComponent<PlayerControllerB>();
						if ((Object)(object)playerControllerB != (Object)null)
						{
							break;
						}
					}
				}
				if ((Object)(object)playerControllerB != (Object)null && Vector3.Distance(((Component)playerControllerB).transform.position, ((Component)hive).transform.position) < (float)defenseDistance)
				{
					SetMovingTowardsTargetPlayer(playerControllerB);
					SwitchToBehaviourState(1);
					SwitchOwnershipOfBeesToClient(playerControllerB);
				}
				else
				{
					SwitchToBehaviourState(0);
				}
				break;
			}
			bool flag = false;
			PlayerControllerB playerControllerB2 = ChaseWithPriorities();
			if ((Object)(object)playerControllerB2 != (Object)null && (Object)(object)targetPlayer != (Object)(object)playerControllerB2)
			{
				flag = true;
				wasInChase = false;
				SetMovingTowardsTargetPlayer(playerControllerB2);
				StopSearch(searchForHive);
				if (SwitchOwnershipOfBeesToClient(playerControllerB2))
				{
					Debug.Log((object)("Bee10 switching owner to " + playerControllerB2.playerUsername));
					break;
				}
			}
			if ((Object)(object)targetPlayer != (Object)null)
			{
				agent.acceleration = 16f;
				if ((!flag && !Object.op_Implicit((Object)(object)CheckLineOfSightForPlayer(360f, 16, 2))) || !PlayerIsTargetable(targetPlayer))
				{
					lostLOSTimer += AIIntervalTime;
					if (lostLOSTimer >= 4.5f)
					{
						targetPlayer = null;
						lostLOSTimer = 0f;
					}
				}
				else
				{
					wasInChase = true;
					lastSeenPlayerPos = ((Component)targetPlayer).transform.position;
					lostLOSTimer = 0f;
				}
				break;
			}
			agent.acceleration = 13f;
			if (!searchForHive.inProgress)
			{
				if (wasInChase)
				{
					StartSearch(lastSeenPlayerPos, searchForHive);
				}
				else
				{
					StartSearch(((Component)this).transform.position, searchForHive);
				}
			}
			break;
		}
		}
	}

	private bool SwitchOwnershipOfBeesToClient(PlayerControllerB player)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)player != (Object)(object)GameNetworkManager.Instance.localPlayerController)
		{
			syncedLastKnownHivePosition = false;
			lostLOSTimer = 0f;
			SyncLastKnownHivePositionServerRpc(lastKnownHivePosition);
			ChangeOwnershipOfEnemy(player.actualClientId);
			return true;
		}
		return false;
	}

	[ServerRpc(RequireOwnership = false)]
	public void SyncLastKnownHivePositionServerRpc(Vector3 hivePosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4130171556u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref hivePosition);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4130171556u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				SyncLastKnownHivePositionClientRpc(hivePosition);
			}
		}
	}

	[ClientRpc]
	public void SyncLastKnownHivePositionClientRpc(Vector3 hivePosition)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1563228958u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe(ref hivePosition);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1563228958u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				lastKnownHivePosition = hivePosition;
				syncedLastKnownHivePosition = true;
			}
		}
	}

	private PlayerControllerB ChaseWithPriorities()
	{
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB[] allPlayersInLineOfSight = GetAllPlayersInLineOfSight(360f, 16);
		PlayerControllerB playerControllerB = null;
		if (allPlayersInLineOfSight != null)
		{
			float num = 3000f;
			int num2 = 0;
			int num3 = -1;
			for (int i = 0; i < allPlayersInLineOfSight.Length; i++)
			{
				if ((Object)(object)allPlayersInLineOfSight[i].currentlyHeldObjectServer != (Object)null)
				{
					if (num3 == -1 && allPlayersInLineOfSight[i].currentlyHeldObjectServer.itemProperties.itemId == 1531)
					{
						num3 = i;
						continue;
					}
					if ((Object)(object)allPlayersInLineOfSight[i].currentlyHeldObjectServer == (Object)(object)hive)
					{
						return allPlayersInLineOfSight[i];
					}
				}
				if ((Object)(object)targetPlayer == (Object)null)
				{
					float num4 = Vector3.Distance(((Component)this).transform.position, ((Component)allPlayersInLineOfSight[i]).transform.position);
					if (num4 < num)
					{
						num = num4;
						num2 = i;
					}
				}
			}
			if (num3 != -1 && Vector3.Distance(((Component)this).transform.position, ((Component)allPlayersInLineOfSight[num3]).transform.position) - num > 7f)
			{
				playerControllerB = allPlayersInLineOfSight[num2];
			}
			else if ((Object)(object)playerControllerB == (Object)null)
			{
				return allPlayersInLineOfSight[num2];
			}
		}
		return playerControllerB;
	}

	private bool IsHiveMissing()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(eye.position, lastKnownHivePosition);
		if (!syncedLastKnownHivePosition)
		{
			return false;
		}
		if (num < 4f || (num < 8f && !Physics.Linecast(eye.position, lastKnownHivePosition, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1)))
		{
			if ((Vector3.Distance(((Component)hive).transform.position, lastKnownHivePosition) > 6f && !IsHivePlacedAndInLOS()) || hive.isHeld)
			{
				return true;
			}
			lastKnownHivePosition = ((Component)hive).transform.position + Vector3.up * 0.5f;
			return false;
		}
		return false;
	}

	private bool IsHivePlacedAndInLOS()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (hive.isHeld)
		{
			return false;
		}
		if (Vector3.Distance(eye.position, ((Component)hive).transform.position) > 9f || Physics.Linecast(eye.position, ((Component)hive).transform.position, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))
		{
			return false;
		}
		return true;
	}

	public override void Update()
	{
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_042a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0434: Unknown result type (might be due to invalid IL or missing references)
		//IL_0439: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (StartOfRound.Instance.allPlayersDead || daytimeEnemyLeaving)
		{
			return;
		}
		timeSinceHittingPlayer += Time.deltaTime;
		attackZapModeTimer += Time.deltaTime;
		float num = Time.deltaTime * 0.7f;
		switch (currentBehaviourStateIndex)
		{
		case 0:
			if (previousState != currentBehaviourStateIndex)
			{
				previousState = currentBehaviourStateIndex;
				SetBeeParticleMode(0);
				ResetBeeZapTimer();
			}
			if (attackZapModeTimer > 1f)
			{
				beesZappingMode = 0;
				ResetBeeZapTimer();
			}
			agent.speed = 4f;
			agent.acceleration = 13f;
			if (!overrideBeeParticleTarget)
			{
				float num2 = Vector3.Distance(((Component)this).transform.position, ((Component)hive).transform.position);
				if ((Object)(object)hive != (Object)null && (num2 < 2f || (num2 < 5f && !Physics.Linecast(eye.position, ((Component)hive).transform.position + Vector3.up * 0.5f, StartOfRound.Instance.collidersAndRoomMaskAndDefault, (QueryTriggerInteraction)1))))
				{
					beeParticlesTarget.position = ((Component)hive).transform.position;
				}
				else
				{
					beeParticlesTarget.position = ((Component)this).transform.position + Vector3.up * 1.5f;
				}
			}
			beesIdle.volume = Mathf.Min(beesIdle.volume + num, 1f);
			if (!beesIdle.isPlaying)
			{
				beesIdle.Play();
			}
			beesDefensive.volume = Mathf.Max(beesDefensive.volume - num, 0f);
			if (beesDefensive.isPlaying && beesDefensive.volume <= 0f)
			{
				beesDefensive.Stop();
			}
			beesAngry.volume = Mathf.Max(beesAngry.volume - num, 0f);
			if (beesAngry.isPlaying && beesAngry.volume <= 0f)
			{
				beesAngry.Stop();
			}
			break;
		case 1:
			if (previousState != currentBehaviourStateIndex)
			{
				previousState = currentBehaviourStateIndex;
				ResetBeeZapTimer();
				SetBeeParticleMode(1);
				if (!overrideBeeParticleTarget)
				{
					beeParticlesTarget.position = ((Component)this).transform.position + Vector3.up * 1.5f;
				}
			}
			if (attackZapModeTimer > 3f)
			{
				beesZappingMode = 1;
				ResetBeeZapTimer();
			}
			agent.speed = 6f;
			agent.acceleration = 13f;
			beesIdle.volume = Mathf.Max(beesIdle.volume - num, 0f);
			if (beesIdle.isPlaying && beesIdle.volume <= 0f)
			{
				beesIdle.Stop();
			}
			beesDefensive.volume = Mathf.Min(beesDefensive.volume + num, 1f);
			if (!beesDefensive.isPlaying)
			{
				beesDefensive.Play();
			}
			beesAngry.volume = Mathf.Max(beesAngry.volume - num, 0f);
			if (beesAngry.isPlaying && beesAngry.volume <= 0f)
			{
				beesAngry.Stop();
			}
			break;
		case 2:
			if (previousState != currentBehaviourStateIndex)
			{
				previousState = currentBehaviourStateIndex;
				SetBeeParticleMode(2);
				ResetBeeZapTimer();
				if (!overrideBeeParticleTarget)
				{
					beeParticlesTarget.position = ((Component)this).transform.position + Vector3.up * 1.5f;
				}
			}
			beesZappingMode = 2;
			agent.speed = 10.3f;
			beesIdle.volume = Mathf.Max(beesIdle.volume - num, 0f);
			if (beesIdle.isPlaying && beesIdle.volume <= 0f)
			{
				beesIdle.Stop();
			}
			beesDefensive.volume = Mathf.Max(beesDefensive.volume - num, 0f);
			if (beesDefensive.isPlaying && beesDefensive.volume <= 0f)
			{
				beesDefensive.Stop();
			}
			beesAngry.volume = Mathf.Min(beesAngry.volume + num, 1f);
			if (!beesAngry.isPlaying)
			{
				beesAngry.Play();
			}
			break;
		}
		BeesZapOnTimer();
		if (stunNormalizedTimer > 0f || overrideBeeParticleTarget)
		{
			SetBeeParticleMode(2);
			agent.speed = 0f;
		}
	}

	private void ResetBeeZapTimer()
	{
		timesChangingZapModes++;
		beeZapRandom = new Random(StartOfRound.Instance.randomMapSeed + timesChangingZapModes);
		beesZapCurrentTimer = 0f;
		attackZapModeTimer = 0f;
		beeZapAudio.Stop();
	}

	private void BeesZapOnTimer()
	{
		if (beesZappingMode == 0)
		{
			return;
		}
		if (beesZapCurrentTimer > beesZapTimer)
		{
			beesZapCurrentTimer = 0f;
			switch (beesZappingMode)
			{
			case 1:
				beesZapTimer = (float)beeZapRandom.Next(1, 8) * 0.1f;
				break;
			case 2:
				beesZapTimer = (float)beeZapRandom.Next(1, 7) * 0.06f;
				break;
			case 3:
				beesZapTimer = (float)beeZapRandom.Next(1, 5) * 0.04f;
				if (!beeZapAudio.isPlaying)
				{
					beeZapAudio.Play();
				}
				beeZapAudio.pitch = 1f;
				if (attackZapModeTimer > 3f)
				{
					attackZapModeTimer = 0f;
					GetClosestPlayer();
					if (mostOptimalDistance > 3f)
					{
						beesZappingMode = currentBehaviourStateIndex;
						Debug.Log((object)$"Setting bee zap mode to {currentBehaviourState} at end of zapping mode 3");
						beeZapAudio.Stop();
					}
				}
				break;
			}
			BeesZap();
		}
		else
		{
			beesZapCurrentTimer += Time.deltaTime;
		}
	}

	private void SetBeeParticleMode(int newState)
	{
		if (beeParticleState != newState)
		{
			beeParticleState = newState;
			switch (newState)
			{
			case 0:
				beeParticles.SetFloat("NoiseIntensity", 3f);
				beeParticles.SetFloat("NoiseFrequency", 35f);
				beeParticles.SetFloat("MoveToTargetSpeed", 155f);
				beeParticles.SetFloat("MoveToTargetForce", 155f);
				beeParticles.SetFloat("TargetRadius", 0.3f);
				beeParticles.SetFloat("TargetStickiness", 7f);
				break;
			case 1:
				beeParticles.SetFloat("NoiseIntensity", 16f);
				beeParticles.SetFloat("NoiseFrequency", 20f);
				beeParticles.SetFloat("MoveToTargetSpeed", 13f);
				beeParticles.SetFloat("MoveToTargetForce", 13f);
				beeParticles.SetFloat("TargetRadius", 1f);
				beeParticles.SetFloat("TargetStickiness", 0f);
				break;
			case 2:
				beeParticles.SetFloat("NoiseIntensity", 35f);
				beeParticles.SetFloat("NoiseFrequency", 35f);
				beeParticles.SetFloat("MoveToTargetSpeed", 35f);
				beeParticles.SetFloat("MoveToTargetForce", 35f);
				beeParticles.SetFloat("TargetRadius", 1f);
				beeParticles.SetFloat("TargetStickiness", 0f);
				break;
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void EnterAttackZapModeServerRpc(int clientWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1099257450u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clientWhoSent);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1099257450u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost) && beesZappingMode != 3)
			{
				EnterAttackZapModeClientRpc(clientWhoSent);
			}
		}
	}

	[ClientRpc]
	public void EnterAttackZapModeClientRpc(int clientWhoSent)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(753177805u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clientWhoSent);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 753177805u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != clientWhoSent)
			{
				beesZappingMode = 3;
				Debug.Log((object)"Entered zap mode 3");
			}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void BeeKillPlayerServerRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(3246315153u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 3246315153u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				BeeKillPlayerClientRpc(playerId);
			}
		}
	}

	[ClientRpc]
	public void BeeKillPlayerClientRpc(int playerId)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3131319918u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerId);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3131319918u, val, (RpcDelivery)0);
			}
			if ((int)((NetworkBehaviour)this).__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				BeeKillPlayerOnLocalClient(playerId);
			}
		}
	}

	private void BeeKillPlayerOnLocalClient(int playerId)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		PlayerControllerB playerControllerB = StartOfRound.Instance.allPlayerScripts[playerId];
		playerControllerB.KillPlayer(Vector3.zero, spawnBody: true, CauseOfDeath.Electrocution, 3);
		if (killingPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(killingPlayerCoroutine);
		}
		killingPlayerCoroutine = ((MonoBehaviour)this).StartCoroutine(BeesKillPlayer(playerControllerB));
	}

	private IEnumerator BeesKillPlayer(PlayerControllerB killedPlayer)
	{
		float timeAtStart = Time.realtimeSinceStartup;
		yield return (object)new WaitUntil((Func<bool>)(() => (Object)(object)killedPlayer.deadBody != (Object)null || Time.realtimeSinceStartup - timeAtStart > 3f));
		if (!((Object)(object)killedPlayer.deadBody == (Object)null))
		{
			killingPlayer = killedPlayer;
			overrideBeeParticleTarget = true;
			inSpecialAnimation = true;
			Debug.Log((object)"Bees on body");
			beeParticlesTarget.position = ((Component)killedPlayer.deadBody.bodyParts[0]).transform.position;
			yield return (object)new WaitForSeconds(4f);
			overrideBeeParticleTarget = false;
			beeParticlesTarget.position = ((Component)this).transform.position + Vector3.up * 1.5f;
			inSpecialAnimation = false;
			killingPlayer = null;
		}
	}

	private void OnPlayerTeleported(PlayerControllerB playerTeleported)
	{
		if ((Object)(object)playerTeleported == (Object)(object)targetPlayer)
		{
			targetPlayer = null;
		}
		if ((Object)(object)playerTeleported == (Object)(object)killingPlayer && killingPlayerCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(killingPlayerCoroutine);
		}
	}

	public override void OnCollideWithPlayer(Collider other)
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		base.OnCollideWithPlayer(other);
		if (timeSinceHittingPlayer < 0.4f)
		{
			return;
		}
		PlayerControllerB playerControllerB = MeetsStandardPlayerCollisionConditions(other);
		if ((Object)(object)playerControllerB != (Object)null)
		{
			timeSinceHittingPlayer = 0f;
			if (playerControllerB.health <= 10 || playerControllerB.criticallyInjured)
			{
				BeeKillPlayerOnLocalClient((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
				BeeKillPlayerServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
			else
			{
				playerControllerB.DamagePlayer(10, hasDamageSFX: true, callRPC: true, CauseOfDeath.Electrocution, 3);
			}
			if (beesZappingMode != 3)
			{
				beesZappingMode = 3;
				EnterAttackZapModeServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	public void BeesZap()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (beeParticles.GetBool("Alive"))
		{
			for (int i = 0; i < lightningPoints.Length; i++)
			{
				lightningPoints[i].position = RoundManager.Instance.GetRandomPositionInBoxPredictable(beeParticlesTarget.position, 4f, beeZapRandom);
			}
			lightningComponent.Trigger(0.1f);
		}
		if (beesZappingMode != 3)
		{
			beeZapAudio.pitch = Random.Range(0.8f, 1.1f);
			beeZapAudio.PlayOneShot(enemyType.audioClips[Random.Range(0, enemyType.audioClips.Length)], Random.Range(0.6f, 1f));
		}
	}

	public void OnEnable()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Expected O, but got Unknown
		lightningComponent.Camera = StartOfRound.Instance.activeCamera;
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).AddListener((UnityAction<PlayerControllerB>)OnPlayerTeleported);
		((UnityEvent)StartOfRound.Instance.CameraSwitchEvent).AddListener(new UnityAction(OnCameraSwitch));
	}

	public void OnDisable()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		((UnityEvent<PlayerControllerB>)StartOfRound.Instance.playerTeleportedEvent).RemoveListener((UnityAction<PlayerControllerB>)OnPlayerTeleported);
		((UnityEvent)StartOfRound.Instance.CameraSwitchEvent).RemoveListener(new UnityAction(OnCameraSwitch));
	}

	private void OnCameraSwitch()
	{
		lightningComponent.Camera = StartOfRound.Instance.activeCamera;
	}

	public override void EnableEnemyMesh(bool enable, bool overrideDoNotSet = false)
	{
		base.EnableEnemyMesh(enable, overrideDoNotSet);
		beeParticles.SetBool("Alive", enable);
	}

	public override void DaytimeEnemyLeave()
	{
		base.DaytimeEnemyLeave();
		beeParticles.SetFloat("MoveToTargetForce", -15f);
		creatureSFX.PlayOneShot(enemyType.audioClips[0], 0.5f);
		agent.speed = 0f;
		((MonoBehaviour)this).StartCoroutine(bugsLeave());
	}

	private IEnumerator bugsLeave()
	{
		yield return (object)new WaitForSeconds(6f);
		KillEnemyOnOwnerClient(overrideDestroy: true);
	}

	protected override void __initializeVariables()
	{
		base.__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_RedLocustBees()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(3189835108u, new RpcReceiveHandler(__rpc_handler_3189835108));
		NetworkManager.__rpc_func_table.Add(4130171556u, new RpcReceiveHandler(__rpc_handler_4130171556));
		NetworkManager.__rpc_func_table.Add(1563228958u, new RpcReceiveHandler(__rpc_handler_1563228958));
		NetworkManager.__rpc_func_table.Add(1099257450u, new RpcReceiveHandler(__rpc_handler_1099257450));
		NetworkManager.__rpc_func_table.Add(753177805u, new RpcReceiveHandler(__rpc_handler_753177805));
		NetworkManager.__rpc_func_table.Add(3246315153u, new RpcReceiveHandler(__rpc_handler_3246315153));
		NetworkManager.__rpc_func_table.Add(3131319918u, new RpcReceiveHandler(__rpc_handler_3131319918));
	}

	private static void __rpc_handler_3189835108(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			NetworkObjectReference hiveObject = default(NetworkObjectReference);
			((FastBufferReader)(ref reader)).ReadValueSafe<NetworkObjectReference>(ref hiveObject, default(ForNetworkSerializable));
			int hiveScrapValue = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref hiveScrapValue);
			Vector3 hivePosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref hivePosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RedLocustBees)(object)target).SpawnHiveClientRpc(hiveObject, hiveScrapValue, hivePosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4130171556(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 hivePosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref hivePosition);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RedLocustBees)(object)target).SyncLastKnownHivePositionServerRpc(hivePosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1563228958(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			Vector3 hivePosition = default(Vector3);
			((FastBufferReader)(ref reader)).ReadValueSafe(ref hivePosition);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RedLocustBees)(object)target).SyncLastKnownHivePositionClientRpc(hivePosition);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_1099257450(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clientWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RedLocustBees)(object)target).EnterAttackZapModeServerRpc(clientWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_753177805(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clientWhoSent = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clientWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RedLocustBees)(object)target).EnterAttackZapModeClientRpc(clientWhoSent);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3246315153(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((RedLocustBees)(object)target).BeeKillPlayerServerRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3131319918(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerId = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerId);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RedLocustBees)(object)target).BeeKillPlayerClientRpc(playerId);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "RedLocustBees";
	}
}
