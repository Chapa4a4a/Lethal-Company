using System;
using System.Collections;
using UnityEngine;

public class ActivateObjectAfterSceneLoad : MonoBehaviour
{
	private GameObject activateObject;

	private void Start()
	{
	}

	private IEnumerator waitForNavMeshBake()
	{
		yield return (object)new WaitUntil((Func<bool>)(() => RoundManager.Instance.bakedNavMesh));
		activateObject.SetActive(true);
	}

	public void SetInitialState()
	{
	}
}
