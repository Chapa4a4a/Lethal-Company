using System;
using System.Collections;
using System.Collections.Generic;
using GameNetcodeStuff;
using Unity.Netcode;
using UnityEngine;

public class SpikeRoofTrap : NetworkBehaviour
{
	public bool slammingDown;

	public float timeSinceMovingUp;

	public bool trapActive = true;

	public Animator spikeTrapAnimator;

	private Coroutine slamCoroutine;

	private List<DeadBodyInfo> deadBodiesSlammed;

	private List<GameObject> slammedBodyStickingPoints;

	public GameObject deadBodyStickingPointPrefab;

	public Transform stickingPointsContainer;

	public Transform laserEye;

	private RaycastHit hit;

	private bool slamOnIntervals;

	private float slamInterval = 1f;

	private Light laserLight;

	public AudioSource spikeTrapAudio;

	private EntranceTeleport nearEntrance;

	public void ToggleSpikesEnabled(bool enabled)
	{
		if (trapActive != enabled)
		{
			Debug.Log((object)$"Toggling turret to {enabled}!");
			ToggleSpikesEnabledLocalClient(enabled);
			ToggleSpikesServerRpc(enabled);
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void ToggleSpikesServerRpc(bool enabled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
			{
				ServerRpcParams val = default(ServerRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(1039429333u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enabled, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendServerRpc(ref val2, 1039429333u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
			{
				ToggleSpikesClientRpc(enabled);
			}
		}
	}

	[ClientRpc]
	public void ToggleSpikesClientRpc(bool enabled)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(3844133644u, val, (RpcDelivery)0);
				((FastBufferWriter)(ref val2)).WriteValueSafe<bool>(ref enabled, default(ForPrimitives));
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 3844133644u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && trapActive != enabled)
			{
				ToggleSpikesEnabledLocalClient(enabled);
			}
		}
	}

	private void ToggleSpikesEnabledLocalClient(bool enabled)
	{
		trapActive = enabled;
	}

	private bool GetNearEntrance()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		EntranceTeleport[] array = Object.FindObjectsByType<EntranceTeleport>((FindObjectsSortMode)0);
		for (int i = 0; i < array.Length; i++)
		{
			if (!array[i].isEntranceToBuilding && Vector3.Distance(((Component)spikeTrapAudio).transform.position, array[i].entrancePoint.position) < 7f)
			{
				flag = true;
				nearEntrance = array[i];
			}
		}
		if (flag)
		{
			for (int j = 0; j < array.Length; j++)
			{
				if ((Object)(object)array[j].entrancePoint == (Object)(object)nearEntrance.exitPoint)
				{
					nearEntrance = array[j];
					return true;
				}
			}
		}
		return false;
	}

	public void Start()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random(StartOfRound.Instance.randomMapSeed + 30 + (int)((Component)this).transform.position.x + (int)((Component)this).transform.position.z);
		bool flag = GetNearEntrance();
		if (random.Next(0, 10) < 8 || flag)
		{
			slamOnIntervals = true;
			int num = random.Next(0, 100);
			if (num < 10)
			{
				slamInterval = 1f * ((float)random.Next(1, 35) / 1.3f);
			}
			else if (num > 90)
			{
				slamInterval = 1f * ((float)random.Next(1, 4) / 1.4f);
			}
			else
			{
				slamInterval = 1f * ((float)random.Next(1, 15) / 1.3f);
			}
			if (Object.op_Implicit((Object)(object)nearEntrance))
			{
				slamInterval = Mathf.Max(slamInterval, 1.25f);
			}
		}
	}

	public void OnTriggerStay(Collider other)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if (!trapActive || !slammingDown || Time.realtimeSinceStartup - timeSinceMovingUp < 0.75f)
		{
			return;
		}
		PlayerControllerB component = ((Component)other).gameObject.GetComponent<PlayerControllerB>();
		if ((Object)(object)component != (Object)null && (Object)(object)component == (Object)(object)GameNetworkManager.Instance.localPlayerController && !component.isPlayerDead)
		{
			GameNetworkManager.Instance.localPlayerController.KillPlayer(Vector3.down * 17f, spawnBody: true, CauseOfDeath.Crushing);
			return;
		}
		DeadBodyInfo component2 = ((Component)other).gameObject.GetComponent<DeadBodyInfo>();
		if ((Object)(object)component2 != (Object)null && (deadBodiesSlammed == null || !deadBodiesSlammed.Contains(component2)))
		{
			StickBodyToSpikes(component2);
			return;
		}
		EnemyAICollisionDetect component3 = ((Component)other).gameObject.GetComponent<EnemyAICollisionDetect>();
		if ((Object)(object)component3 != (Object)null && (Object)(object)component3.mainScript != (Object)null && ((NetworkBehaviour)component3.mainScript).IsOwner && component3.mainScript.enemyType.canDie && !component3.mainScript.isEnemyDead)
		{
			component3.mainScript.KillEnemyOnOwnerClient();
		}
	}

	private void StickBodyToSpikes(DeadBodyInfo body)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		if (deadBodiesSlammed == null)
		{
			deadBodiesSlammed = new List<DeadBodyInfo>();
		}
		if (slammedBodyStickingPoints == null)
		{
			slammedBodyStickingPoints = new List<GameObject>();
		}
		Vector3 val = default(Vector3);
		((Vector3)(ref val))._002Ector(((Component)body.bodyParts[5]).transform.position.x, stickingPointsContainer.position.y, ((Component)body.bodyParts[5]).transform.position.z);
		GameObject val2 = Object.Instantiate<GameObject>(deadBodyStickingPointPrefab, val, body.bodyParts[5].rotation * Quaternion.Euler(65f, 0f, 0f), stickingPointsContainer);
		deadBodiesSlammed.Add(body);
		body.attachedLimb = body.bodyParts[5];
		body.attachedTo = val2.transform;
		body.matchPositionExactly = true;
		body.canBeGrabbedBackByPlayers = true;
	}

	public void Update()
	{
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if (!trapActive || slammingDown)
		{
			return;
		}
		if ((Object)(object)nearEntrance != (Object)null && Time.realtimeSinceStartup - nearEntrance.timeAtLastUse < 1.2f)
		{
			timeSinceMovingUp = Time.realtimeSinceStartup;
		}
		if (slamOnIntervals)
		{
			if (((NetworkBehaviour)this).IsServer && Time.realtimeSinceStartup - timeSinceMovingUp > slamInterval && (!Physics.CheckSphere(laserEye.position, 8f, 524288, (QueryTriggerInteraction)2) || Physics.CheckSphere(laserEye.position, 14f, 8, (QueryTriggerInteraction)2)))
			{
				slammingDown = true;
				SpikeTrapSlam();
				SpikeTrapSlamServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
		else if (!(Time.realtimeSinceStartup - timeSinceMovingUp < 1.2f) && Physics.Raycast(laserEye.position, laserEye.forward, ref hit, 4.4f, StartOfRound.Instance.collidersRoomMaskDefaultAndPlayers, (QueryTriggerInteraction)1))
		{
			PlayerControllerB component = ((Component)((RaycastHit)(ref hit)).collider).GetComponent<PlayerControllerB>();
			if ((Object)(object)component != (Object)null && !component.isPlayerDead && (Object)(object)component == (Object)(object)GameNetworkManager.Instance.localPlayerController)
			{
				slammingDown = true;
				SpikeTrapSlam();
				SpikeTrapSlamServerRpc((int)GameNetworkManager.Instance.localPlayerController.playerClientId);
			}
		}
	}

	public void SpikeTrapSlam()
	{
		slammingDown = true;
		if (slamCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(slamCoroutine);
		}
		slamCoroutine = ((MonoBehaviour)this).StartCoroutine(SlamSpikeTrapSequence());
	}

	private IEnumerator SlamSpikeTrapSequence()
	{
		spikeTrapAnimator.SetBool("Slamming", true);
		SetRandomSpikeTrapAudioPitch();
		yield return (object)new WaitForSeconds(0.8f);
		spikeTrapAnimator.SetBool("Slamming", false);
		timeSinceMovingUp = Time.realtimeSinceStartup;
		slammingDown = false;
	}

	private void SetRandomSpikeTrapAudioPitch()
	{
		spikeTrapAudio.pitch = 1f;
		switch (Random.Range(1, 7))
		{
		case 1:
		{
			AudioSource obj4 = spikeTrapAudio;
			obj4.pitch *= Mathf.Pow(1.05946f, 2f);
			break;
		}
		case 2:
		{
			AudioSource obj3 = spikeTrapAudio;
			obj3.pitch *= Mathf.Pow(1.05946f, 4f);
			break;
		}
		case 3:
		{
			AudioSource obj2 = spikeTrapAudio;
			obj2.pitch /= Mathf.Pow(1.05946f, 1f);
			break;
		}
		case 4:
		{
			AudioSource obj = spikeTrapAudio;
			obj.pitch /= Mathf.Pow(1.05946f, 3f);
			break;
		}
		}
	}

	[ServerRpc(RequireOwnership = false)]
	public void SpikeTrapSlamServerRpc(int playerWhoTriggered)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager == null || !networkManager.IsListening)
		{
			return;
		}
		if ((int)base.__rpc_exec_stage != 1 && (networkManager.IsClient || networkManager.IsHost))
		{
			ServerRpcParams val = default(ServerRpcParams);
			FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendServerRpc(4061245259u, val, (RpcDelivery)0);
			BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
			((NetworkBehaviour)this).__endSendServerRpc(ref val2, 4061245259u, val, (RpcDelivery)0);
		}
		if ((int)base.__rpc_exec_stage == 1 && (networkManager.IsServer || networkManager.IsHost))
		{
			SpikeTrapSlamClientRpc(playerWhoTriggered);
			if ((int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerWhoTriggered)
			{
				SpikeTrapSlam();
			}
		}
	}

	[ClientRpc]
	public void SpikeTrapSlamClientRpc(int playerWhoTriggered)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(2310390017u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, playerWhoTriggered);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 2310390017u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost) && (int)GameNetworkManager.Instance.localPlayerController.playerClientId != playerWhoTriggered && !((NetworkBehaviour)this).IsServer)
			{
				SpikeTrapSlam();
			}
		}
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_SpikeRoofTrap()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected O, but got Unknown
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1039429333u, new RpcReceiveHandler(__rpc_handler_1039429333));
		NetworkManager.__rpc_func_table.Add(3844133644u, new RpcReceiveHandler(__rpc_handler_3844133644));
		NetworkManager.__rpc_func_table.Add(4061245259u, new RpcReceiveHandler(__rpc_handler_4061245259));
		NetworkManager.__rpc_func_table.Add(2310390017u, new RpcReceiveHandler(__rpc_handler_2310390017));
	}

	private static void __rpc_handler_1039429333(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enabled = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enabled, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SpikeRoofTrap)(object)target).ToggleSpikesServerRpc(enabled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_3844133644(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			bool enabled = default(bool);
			((FastBufferReader)(ref reader)).ReadValueSafe<bool>(ref enabled, default(ForPrimitives));
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SpikeRoofTrap)(object)target).ToggleSpikesClientRpc(enabled);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_4061245259(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)1;
			((SpikeRoofTrap)(object)target).SpikeTrapSlamServerRpc(playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	private static void __rpc_handler_2310390017(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int playerWhoTriggered = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((SpikeRoofTrap)(object)target).SpikeTrapSlamClientRpc(playerWhoTriggered);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "SpikeRoofTrap";
	}
}
