using Unity.Netcode;
using UnityEngine;

public class RandomPeriodicAudioPlayer : NetworkBehaviour
{
	public GrabbableObject attachedGrabbableObject;

	public AudioClip[] randomClips;

	public AudioSource thisAudio;

	public float audioMinInterval;

	public float audioMaxInterval;

	public float audioChancePercent;

	private float currentInterval;

	private float lastIntervalTime;

	private void Update()
	{
		if (((NetworkBehaviour)this).IsServer && !((Object)(object)GameNetworkManager.Instance.localPlayerController == (Object)null) && (!((Object)(object)attachedGrabbableObject != (Object)null) || !attachedGrabbableObject.deactivated) && Time.realtimeSinceStartup - lastIntervalTime > currentInterval)
		{
			lastIntervalTime = Time.realtimeSinceStartup;
			currentInterval = Random.Range(audioMinInterval, audioMaxInterval);
			if (Random.Range(0f, 100f) < audioChancePercent)
			{
				PlayRandomAudioClientRpc(Random.Range(0, randomClips.Length));
			}
		}
	}

	[ClientRpc]
	public void PlayRandomAudioClientRpc(int clipIndex)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = ((NetworkBehaviour)this).NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			if ((int)base.__rpc_exec_stage != 2 && (networkManager.IsServer || networkManager.IsHost))
			{
				ClientRpcParams val = default(ClientRpcParams);
				FastBufferWriter val2 = ((NetworkBehaviour)this).__beginSendClientRpc(1557920159u, val, (RpcDelivery)0);
				BytePacker.WriteValueBitPacked(val2, clipIndex);
				((NetworkBehaviour)this).__endSendClientRpc(ref val2, 1557920159u, val, (RpcDelivery)0);
			}
			if ((int)base.__rpc_exec_stage == 2 && (networkManager.IsClient || networkManager.IsHost))
			{
				PlayAudio(clipIndex);
			}
		}
	}

	private void PlayAudio(int clipIndex)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		AudioClip val = randomClips[clipIndex];
		thisAudio.PlayOneShot(val, 1f);
		WalkieTalkie.TransmitOneShotAudio(thisAudio, val);
		RoundManager.Instance.PlayAudibleNoise(((Component)thisAudio).transform.position, 7f, 0.6f);
	}

	protected override void __initializeVariables()
	{
		((NetworkBehaviour)this).__initializeVariables();
	}

	[RuntimeInitializeOnLoadMethod]
	internal static void InitializeRPCS_RandomPeriodicAudioPlayer()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected O, but got Unknown
		NetworkManager.__rpc_func_table.Add(1557920159u, new RpcReceiveHandler(__rpc_handler_1557920159));
	}

	private static void __rpc_handler_1557920159(NetworkBehaviour target, FastBufferReader reader, __RpcParams rpcParams)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		NetworkManager networkManager = target.NetworkManager;
		if (networkManager != null && networkManager.IsListening)
		{
			int clipIndex = default(int);
			ByteUnpacker.ReadValueBitPacked(reader, ref clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)2;
			((RandomPeriodicAudioPlayer)(object)target).PlayRandomAudioClientRpc(clipIndex);
			target.__rpc_exec_stage = (__RpcExecStage)0;
		}
	}

	protected internal override string __getTypeName()
	{
		return "RandomPeriodicAudioPlayer";
	}
}
