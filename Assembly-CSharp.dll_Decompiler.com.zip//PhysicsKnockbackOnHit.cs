using GameNetcodeStuff;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class PhysicsKnockbackOnHit : MonoBehaviour, IHittable
{
	public AudioClip playSFX;

	public bool Hit(int force, Vector3 hitDirection, PlayerControllerB playerWhoHit = null, bool playHitSFX = false, int hitID = -1)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)((Component)this).gameObject.GetComponent<Rigidbody>() == (Object)null)
		{
			return false;
		}
		((Component)this).gameObject.GetComponent<Rigidbody>().AddForce(hitDirection * (float)force * 10f, (ForceMode)1);
		if ((Object)(object)playSFX != (Object)null && Object.op_Implicit((Object)(object)((Component)this).gameObject.GetComponent<AudioSource>()))
		{
			((Component)this).gameObject.GetComponent<AudioSource>().PlayOneShot(playSFX);
		}
		return true;
	}
}
