using System;
using UnityEngine;

[Serializable]
public class CameraView
{
	public Camera camera;

	public Material cameraMaterial;
}
